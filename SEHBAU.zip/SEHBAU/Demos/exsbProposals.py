"""

Displays shape-based proposals. .qbox, .qdsc

"""
import sys
sys.path.insert(0, '..')
from globalsSB import *

import subprocess
import platform

u_AddGenPath( '../UtilPy/' )
u_AddGenPath( '../DescExtr/UtilPy/' )

# ------------------------------   Image & Options   ------------------------------
pthImg    = 'Imgs/room.png'
pthOut    = 'Desc/room'
optS      = '--saveProp'  # use '--ssepProp' for saving as separate files

# ------------------------------   Run Dscx   ------------------------------
# Construct command
cmnd      = f"../DescExtr/dscx {pthImg} {pthOut} {optS}"

# Adjust for Windows paths if needed
if platform.system() == 'Windows':
    cmnd  = cmnd.replace('/', '\\')  # mimic `u_PathToBackSlash`

Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Sts    = Res.returncode
Out    = Res.stdout + Res.stderr

print(Out)
print(Sts)

# ------------------------------   Load Bboxes   ------------------------------
from OrgFileNames import o_FileExtensions
from LoadProposals import LoadDescPropBbox

Fixt, Dmy = o_FileExtensions()

pthBbox   = pthOut + Fixt.qbbx

BBx, Nr   = LoadDescPropBbox( pthBbox )

#print( Bbx )
#print( Nr.shpGen )
#print( Bbx.ShpGen )

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
import imageio.v3 as iio

from PlotBboxes import p_BboxL
from PlotUtils import imglabN

Irgb     = iio.imread(pthImg)

fig, axs = plt.subplots(2, 2, figsize=(10, 8))
axs      = axs.ravel()

titles = ['ShpGen', 'TtgGen', 'ShpVrt', 'ShpHor']
bboxes = [BBx.ShpGen, BBx.TtgGen, BBx.ShpVrt, BBx.ShpHor]
counts = [Nr.shpGen, Nr.ttgGen, Nr.shpVrt, Nr.shpHor]
colors = [3, 3, 4, 4]

for i in range(4):

    axs[i].imshow(Irgb)
    axs[i].axis('off')

    p_BboxL( axs[i], bboxes[i], colors[i])

    axs[i].set_title(f"{titles[i]} ({counts[i]})")

plt.tight_layout()

#plt.show()
plt.show(block=False), plt.pause(2)


