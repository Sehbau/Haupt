%
% Reads the statistics of the ori-bias maps as saved under w_OtxMAPsts() in
% A_CONT/Itgr/Util/CntTxtIO.h
%
% cf LoadDescSalc, LoadSalcAly.m
%
function [S] = ReadOtxMAPsts( fileID, aTypS )

nTyp = length( aTypS );

S.PrpPres = zeros( nTyp, 1, 'single');
S.Men     = zeros( nTyp, 1, 'single');

for i = 1:nTyp

    S.( aTypS{i} ) = ReadMapBisStat( fileID );
    S.PrpPres(i) = S.( aTypS{i} ).prpPres;
    S.Men(i)     = S.( aTypS{i} ).men;
end

% =====   Trailer   =====
idf    = fread(fileID, 1, 'int32=>int');

assert(idf==46593, 'idf not correct: %d', idf);

end

