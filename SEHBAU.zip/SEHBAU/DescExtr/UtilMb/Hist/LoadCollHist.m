%
% Loads a matrix of histograms, [nImg ntBin], as collected with program
% collhimg. Does not verify file extension.
%
% As saved in C under E_DESC/CollHist/CollHistUtil.h-s_CollHist().
%
function [HST Nbin] = LoadCollHist( pthFile )

fileID      = fopen(pthFile, 'r');
if fileID<0, 
    error('could not open %s.', pthFile); 
end

%% -------   Header (Size)   --------
nImg        = fread(fileID, 1,  'int=>int');
nBin        = fread(fileID, 1,  'int=>int');
fprintf('[%d %d]\n', nImg, nBin);

%% -------   Data Matrix   --------
HST         = fread(fileID, nImg*nBin, 'int=>single');
HST         = reshape(HST, nBin, nImg)';

%% ------   Trailer: Bin Numbers   ------
% s_CollHistTerm in CollHistIO.h
Nbin.Tot    = fread(fileID, 4,  'int=>int');  % flat/biv/spaFlat/spaBiv

Nbin.F1     = fread(fileID, 7,  'int=>int');  % CRASSPB
Nbin.F2     = fread(fileID, 7,  'int=>int');  % CRASSPB
Nbin.S1     = fread(fileID, 7,  'int=>int');  % CRASSPB
Nbin.S2     = fread(fileID, 2,  'int=>int');  % CR
Nbin.S2     = [Nbin.S2; 0; 0; 0]; % add three for ASS

sep         = fread(fileID, 1,  'int=>int');  assert(sep==-1);
Nbin.Cnt1D  = fread(fileID, 4,  'int=>int');  % len/str/ori/crm

sep         = fread(fileID, 1,  'int=>int');  assert(sep==-1);
Nbin.Rsg1D  = fread(fileID, 12, 'int=>int');  % rds/...lof

sep         = fread(fileID, 1,  'int=>int');  assert(sep==-1);
Nbin.Arc1D  = fread(fileID, 8,  'uint8=>int');  % len/...

sep         = fread(fileID, 1,  'int=>int');  assert(sep==-1);
Nbin.Str1D  = fread(fileID, 4,  'int=>int');  % len/...

sep         = fread(fileID, 1,  'int=>int');  assert(sep==-1);
Nbin.shpUni = fread(fileID, 1,  'int=>int');  
Nbin.shpBiv = fread(fileID, 1,  'int=>int');  

sep          = fread(fileID, 1,  'int=>int');  assert(sep==-1);
Nbin.ttrgUni = fread(fileID, 1,  'int=>int');  
Nbin.ttrgBiv = fread(fileID, 1,  'int=>int');  

Nbin.bndgUni = fread(fileID, 1,  'int=>int');  
Nbin.bndgBiv = fread(fileID, 1,  'int=>int');  

% trailer:
idfEof      = fread(fileID, 1,  'int=>int');  
assert(idfEof==444);

fclose(fileID);

DispLoad(pthFile);

%% -----------   Verify   --------------
ntBin   = sum( Nbin.Tot );
nDim    = size( HST,2 );
if ntBin~=nDim
    warning( 'LoadCollHist: sum of bin numbers %d ~= dims of histogram %d', ...
        ntBin, nDim );
end



end

