%
% Loads the full set of parameterized arc and straighter segmetns, as saved
% under CrvPrtIO.h:si_CVPspc.
%
function [V Kt] = LoadCVPfull(lfn) 

fid   = fopen(lfn, 'r');
if (fid<0), error('file %s not found', lfn); end

[nLev Narc]         = ReadDescSpcHead(fid);
[nLev Nstr]         = ReadDescSpcHead(fid);
[V.AARC Kt.Narc]    = ReadArcSpc(fid); 
[V.ASTR Kt.Nstr]    = ReadStrSpc(fid);

fclose(fid);

DispLoad(lfn);


