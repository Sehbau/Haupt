"""

Descriptor extraction in simplest form, without utility/wrapper routines, for reason
of clarity. And we turn the histogram file into a single array with program h2arr.

Analogous to exsbDscxSimp.m

"""
import os
import subprocess
import sys

## ------------------------------   Run 1 Image   ------------------------------
# win with backslash for output directory
if sys.platform.startswith('win'):

    cmnd = r'dscx Imgs/img2.jpg Desc\img2'  # raw string to handle backslash
    
elif sys.platform.startswith('linux') or sys.platform.startswith('darwin'):

    cmnd = 'dscx Imgs/img2.jpg Desc/img2'

Res  = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

# Access status and output
if Res.returncode != 0:
    raise ValueError("dscx did not execute properly somehow")

print( Res.stdout )


## ------------------------------   Load Output   ------------------------------
sys.path.insert(0, '..')
from globalsSB import u_AddGenPath

u_AddGenPath( '../UtilPy/' )
u_AddGenPath( 'UtilPy/' )

# ----------   Saliency   ----------
from LoadDescSalc import *

Txa, Shp, Ens, Dsc = LoadDescSalc( 'Desc/img2.slc' )


# ----------   Description   ----------
from LoadDescImag import LoadDescImag

# so far it loads only contours 
DSC, Hed    = LoadDescImag( 'Desc/img2.dsc' )

print(DSC)
print(Hed)


# ----------   Histograms   ----------
# does not exist yet
# [HFU HFB HSP Nbin HedHst] = LoadDescHist( 'Desc/img2.hst' )


## ------------------------------   h2arr   ------------------------------
# turns a hist file into a single array
if sys.platform.startswith('win'):

    cmnd = r'h2arr Desc/img2.hst Vect\img2'  # raw string to handle backslash
    
elif sys.platform.startswith('linux') or sys.platform.startswith('darwin'):

    cmnd = 'h2arr Desc/img2.hst Vect/img2'

Res  = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

if Res.returncode != 0:
    raise ValueError("h2arr did not execute properly somehow")

# --------------------   Load Hist Array   --------------------
from LoadHist import *

Hari  = LoadHistImgArr( 'Vect/img2.hari' )

print( Hari )

