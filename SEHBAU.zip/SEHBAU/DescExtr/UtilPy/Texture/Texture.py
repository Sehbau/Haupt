"""

Texture 

"""
import numpy as np




""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   u_TxtrGstToArrs   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Texture global stats to array, for the 7 biases.

cf exsbSalBlobs.py

"""
def u_TxtrGstToArrs( T ):

    aBlobLab = list(T.__dict__.keys())
    aBlobLab = aBlobLab[4:11]                   # get rid of __xxx__
    nTyp     = len(aBlobLab)
    
    class S:
        PrpPres = np.zeros(nTyp, dtype=np.float32)
        Men     = np.zeros(nTyp, dtype=np.float32)
        Sdv     = np.zeros(nTyp, dtype=np.float32)

    for i, lb in enumerate(aBlobLab):

        fld = getattr( T, lb )
        
        S.PrpPres[i] = fld.prpPres
        S.Men[i]     = fld.men
        S.Sdv[i]     = fld.sdv

    return S

