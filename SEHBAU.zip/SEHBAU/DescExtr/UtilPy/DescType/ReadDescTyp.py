"""

Read values for each descriptor type.

"""
import numpy as np



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadDescTypSpcF   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads space values for each desc types. As float.

cf LoadDescSalc
"""
def ReadDescTypSpcF(file):

    class S:
        pass

    # Read and validate number of levels
    nLev = np.fromfile(file, dtype=np.uint8, count=1)[0]
    if not (0 < nLev < 10):
        raise ValueError(f"nLev = {nLev}: unreasonable.")
    S.nLev   = int(nLev)

    # Read fields as float32 arrays
    S.Rdg    = np.fromfile(file, dtype=np.float32, count=S.nLev)
    S.Riv    = np.fromfile(file, dtype=np.float32, count=S.nLev)
    S.Edg    = np.fromfile(file, dtype=np.float32, count=S.nLev)
    S.Skl    = np.fromfile(file, dtype=np.float32, count=S.nLev)
    
    S.Rsg    = np.fromfile(file, dtype=np.float32, count=S.nLev)
    S.Arc    = np.fromfile(file, dtype=np.float32, count=S.nLev)
    S.Str    = np.fromfile(file, dtype=np.float32, count=S.nLev)
    S.ArcGst = np.fromfile(file, dtype=np.float32, count=S.nLev)
    S.StrGst = np.fromfile(file, dtype=np.float32, count=S.nLev)
    
    S.Shp    = np.fromfile(file, dtype=np.float32, count=S.nLev)
    S.Ttrg   = np.fromfile(file, dtype=np.float32, count=S.nLev)
    S.Bndg   = np.fromfile(file, dtype=np.float32, count=S.nLev)

    return S


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadDescTypSpcI   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads space values for each desc types. As integer

cf LoadDescSalc
"""
def ReadDescTypSpcI(file):

    class S:
        pass

    # Read and validate number of levels
    nLev = np.fromfile(file, dtype=np.uint8, count=1)[0]
    if not (0 < nLev < 10):
        raise ValueError(f"nLev = {nLev}: unreasonable.")
    S.nLev   = int(nLev)

    # Read fields as int32 arrays
    S.Rdg    = np.fromfile(file, dtype=np.int32, count=S.nLev)
    S.Riv    = np.fromfile(file, dtype=np.int32, count=S.nLev)
    S.Edg    = np.fromfile(file, dtype=np.int32, count=S.nLev)
    S.Skl    = np.fromfile(file, dtype=np.int32, count=S.nLev)
    
    S.Rsg    = np.fromfile(file, dtype=np.int32, count=S.nLev)
    S.Arc    = np.fromfile(file, dtype=np.int32, count=S.nLev)
    S.Str    = np.fromfile(file, dtype=np.int32, count=S.nLev)
    S.ArcGst = np.fromfile(file, dtype=np.int32, count=S.nLev)
    S.StrGst = np.fromfile(file, dtype=np.int32, count=S.nLev)
    
    S.Shp    = np.fromfile(file, dtype=np.int32, count=S.nLev)
    S.Ttrg   = np.fromfile(file, dtype=np.int32, count=S.nLev)
    S.Bndg   = np.fromfile(file, dtype=np.int32, count=S.nLev)

    return S
