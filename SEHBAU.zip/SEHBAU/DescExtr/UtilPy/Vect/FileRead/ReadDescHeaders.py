"""

Headers for descriptor files and attribute lists

"""
from dataclasses import dataclass



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_ReadDescFileHead   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads the header of a descriptor file (.vec) 
"""
@dataclass
class descFileHead:
    nLev: int
    szV:  int
    szH:  int
    ntDsc: int
    vers: int

def ReadDescFileHead( fo, idfExp ):

    nLev    = int.from_bytes( fo.read(4),'little')
    szV     = int.from_bytes( fo.read(4),'little')
    szH     = int.from_bytes( fo.read(4),'little')
    ntDsc   = int.from_bytes( fo.read(4),'little')
    idfLod  = int.from_bytes( fo.read(1),'little', signed = False )

    if idfLod!=idfExp:
        print( 'identifier not correct: ' + idfLod + '. expected' + idfExp )
    
    bGrp    = int.from_bytes( fo.read(1),'little', signed = False )
    bFlg2   = int.from_bytes( fo.read(1),'little', signed = False )
    bFlg3   = int.from_bytes( fo.read(1),'little', signed = False )
    bFlg4   = int.from_bytes( fo.read(1),'little', signed = False )
    bFlg5   = int.from_bytes( fo.read(1),'little', signed = False )
    
    vers    = int.from_bytes( fo.read(2),'little' )

    #print( vers )
    
    Hed = descFileHead( nLev, szV, szH, ntDsc, vers)
    
    return Hed


#assert(idfLod==idfExp,'file idf not correct: %d, expected %d', idfLod, idfExp);
#assert(nLev>0 && nLev<12,'nLev not correct: %d', nLev);
#assert(szV>0 && szV<5000, 'szV unreasonable: %d', szV);
#assert(szH>0 && szH<5000, 'szH unreasnoable: %d', szH);

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_ReadDescAttHead   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
  Reads attributes header (ReadDescAttHead.m )

  cf Read{Dsc}Att.py, ie ReadCntAtt.

"""
@dataclass
class descAttHead:
    nDsc: int
    bTif: int
    bCol = 0

def ReadDescAttHead( fo ):

    nDsc    = int.from_bytes( fo.read(4),'little')
    bTif    = int.from_bytes( fo.read(1),'little', signed = False )
    #H.bCol = fread(fileID, 1, 'uint8=>uint8'); % color info (boolean)

    Hed = descAttHead( nDsc, bTif )
	
    return Hed

