#
# Unpacking an array of attribute values.
# 
import struct
import numpy as np



# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   r_Att1unpackFlt   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
# 
# Array of floats
#
def r_Att1unpackFlt(fo, nDsc):

    A = np.zeros((nDsc), dtype=float)

    for i in range(0,nDsc):
        A[i] = struct.unpack('f', fo.read(4))[0]

    return A


# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   r_Att1Int   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
# 
# Array of ints
#
def r_Att1Int( fo, nDsc ):

    A = np.zeros((nDsc), dtype=int)

    for i in range(0, nDsc):
        A[i] = int.from_bytes( fo.read(4), 'little')

    return A


# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   r_Att1Uch   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
# 
# Array of uint8
#
def r_Att1Uch( fo, nDsc ):

    A = np.zeros((nDsc), dtype=np.uint8)

    for i in range(0, nDsc):
        A[i] = int.from_bytes( fo.read(1), 'little')

    return A


# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttPos   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
#
# Reads contour attributes as saved under CntIO.h-w_CntAtt
# cf ReadCntAtt.m
#
def ReadAttPos( fo ):

    class P:    # returning as structure
        pass    

    P.nPos  = int.from_bytes( fo.read(4), 'little')

    P.Vrt   = r_Att1unpackFlt( fo, P.nPos ) # vertical position
    P.Hor   = r_Att1unpackFlt( fo, P.nPos ) # horizontal position 

    return P


# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttTif   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
#
# Reads Tiefe. af ReadAttTif.m
# cf ReadCntAtt.py
#
def ReadAttTif( fo, nDsc ):

    class P:    # returning as structure
        pass    

    P.Ep1   = r_Att1unpackFlt( fo, nDsc )
    P.Ep2   = r_Att1unpackFlt( fo, nDsc )
    P.Btw   = r_Att1unpackFlt( fo, nDsc )

    return P


# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttRgb   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
#
# Reads Rgb values. af ReadAttRgb.m
# cf ReadCntAtt.py
#
def ReadAttRgb( fo, nDsc ):

    class P:    # returning as structure
        pass    

    P.Red   = r_Att1unpackFlt( fo, nDsc )
    P.Grn   = r_Att1unpackFlt( fo, nDsc )
    P.Blu   = r_Att1unpackFlt( fo, nDsc )

    return P





