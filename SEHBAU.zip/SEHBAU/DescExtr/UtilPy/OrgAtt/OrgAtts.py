"""

Organization of attributes

"""

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   o_BlobLabels   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Blob labels.
 
They are also used in ReadBlobMapGlbSts.m (but NOT passed as variable).

They must match with CntTxtAnf.h, w_CntTXTbis (CntTxtIO.h)

"""
def o_BlobLabels():

    # NB NVHAU
    LS = {'Num', 'Blk', 'Nil', 'Vrt', 'Hor', 'Axi', 'Uni'}

    nTyp    = len( LS );

    return LS, nTyp
