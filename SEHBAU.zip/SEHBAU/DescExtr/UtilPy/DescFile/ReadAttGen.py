"""

Reading general attributes, ie. position, color, etc.

"""
import struct
import numpy as np


# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttPos   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
#
# Reads contour attributes as saved under CntIO.h-w_CntAtt
# cf ReadCntAtt.m
#
def ReadAttPos( fid ):

    class P:
        pass
    
    P.nPos  = int.from_bytes( fid.read(4), 'little')

    P.Vrt   = np.fromfile( fid, dtype=np.float32, count=P.nPos)  # vertical position
    P.Hor   = np.fromfile( fid, dtype=np.float32, count=P.nPos)  # horizontal position



# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttRgb   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
#
# Reads Rgb values. af ReadAttRgb.m
# cf ReadCntAtt.py
#
def ReadAttRgb( fid, nDsc ):

    class P:

        Red = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        Grn = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        Blu = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    return P





