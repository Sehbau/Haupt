"""

Reads pixels and points

"""

import numpy as np



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadPixRCs   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Read pixels as rows and cols in short.

"""
def ReadPixRCs( file ):

    class S:
        pass

    S.nCo = np.fromfile(file, dtype=np.int32, count=1)[0]
    S.szM = tuple(np.fromfile(file, dtype=np.int32, count=2))

    # Read as int16 and convert to int32
    S.Rw = np.fromfile(file, dtype=np.int16, count=S.nCo).astype(np.int32)
    S.Cl = np.fromfile(file, dtype=np.int16, count=S.nCo).astype(np.int32)
    
    S.Pt = np.column_stack((S.Rw, S.Cl))  # Combined [row, col] points
    
    return S



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadPixvRCf   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

ReadPixRCs with (associated) values as float (w_PixvRCf in PixIO.h)

"""
def ReadPixvRCf( fid ):

    class S:
        pass

    S.Px    = ReadPixRCs( fid )                 # above
    
    S.V     = np.fromfile( fid, dtype=np.float32, count=S.Px.nCo)

    return S
