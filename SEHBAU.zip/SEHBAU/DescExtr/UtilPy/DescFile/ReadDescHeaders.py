"""

Headers for descriptor files and attribute lists

"""
import numpy as np

from dataclasses import dataclass



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_ReadDescFileHead   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads the header of a descriptor file (.dsc) 
"""
@dataclass
class descFileHead:
    nLev: int
    szV:  int
    szH:  int
    ntDsc: int
    depth: int
    space: int
    vers: float

def ReadDescFileHead( fo, typExp ):

    versExp = 1.03

    nLev  = np.fromfile( fo, dtype=np.int32, count=1)[0]     # # of pyramid levels
    szV   = np.fromfile( fo, dtype=np.int32, count=1)[0]     # vertical image size
    szH   = np.fromfile( fo, dtype=np.int32, count=1)[0]     # horizontal image size
    ntDsc = np.fromfile( fo, dtype=np.int32, count=1)[0]     # # of total desc
    typ   = np.fromfile( fo, dtype=np.uint8, count=1)[0]     # file typ (imag|focus)

    depth = np.fromfile( fo, dtype=np.uint8, count=1)[0]     # depth of segmentation
    space = np.fromfile( fo, dtype=np.uint8, count=1)[0]     # image space (pyr | ss)
    bFlg3 = np.fromfile( fo, dtype=np.uint8, count=1)[0]     # not used at the moment
    bFlg4 = np.fromfile( fo, dtype=np.uint8, count=1)[0]     # not used at the moment
    bFlg5 = np.fromfile( fo, dtype=np.uint8, count=1)[0]     # not used at the moment

    versLod = np.fromfile( fo, dtype=np.float32, count=1)[0]  # version loaded

    assert typ == typExp, f'file idf not correct: {typ}, expected {typExp}'
    assert nLev > 0 and nLev < 12, f'nLev not correct: {nLev}'
    assert szV > 0 and szV < 5000, f'szV unreasonable: {szV}'
    assert szH > 0 and szH < 5000, f'szH unreasonable: {szH}'
    assert abs(versLod - versExp) < 0.001, f'Version depreciated: is {versLod:.3f}. new {versExp:.3f}'
    Hed = descFileHead( nLev, szV, szH, ntDsc, versLod, depth, space )

    return Hed


def ReadDescFileHeadV1( fo, idfExp ):

    nLev    = int.from_bytes( fo.read(4),'little')
    szV     = int.from_bytes( fo.read(4),'little')
    szH     = int.from_bytes( fo.read(4),'little')
    ntDsc   = int.from_bytes( fo.read(4),'little')
    idfLod  = int.from_bytes( fo.read(1),'little', signed = False )

    if idfLod!=idfExp:
        print( 'identifier not correct: ' + idfLod + '. expected' + idfExp )
    
    bGrp    = int.from_bytes( fo.read(1),'little', signed = False )
    bFlg2   = int.from_bytes( fo.read(1),'little', signed = False )
    bFlg3   = int.from_bytes( fo.read(1),'little', signed = False )
    bFlg4   = int.from_bytes( fo.read(1),'little', signed = False )
    bFlg5   = int.from_bytes( fo.read(1),'little', signed = False )
    
    vers    = int.from_bytes( fo.read(2),'little' )

    #print( vers )
    
    Hed = descFileHead( nLev, szV, szH, ntDsc, vers)
    
    return Hed

#assert(idfLod==idfExp,'file idf not correct: %d, expected %d', idfLod, idfExp);
#assert(nLev>0 && nLev<12,'nLev not correct: %d', nLev);
#assert(szV>0 && szV<5000, 'szV unreasonable: %d', szV);
#assert(szH>0 && szH<5000, 'szH unreasnoable: %d', szH);



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_ReadDescAttHead   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
  Reads attributes header (ReadDescAttHead.m )

  cf Read{Dsc}Att.py, ie ReadCntAtt.

"""
def ReadDescSpcHead(fid):

    nLev = np.fromfile(fid, dtype=np.int32, count=1)[0]  # # of levels
    Ndsc = np.fromfile(fid, dtype=np.int32, count=nLev)  # # of descriptors

    return nLev, Ndsc



@dataclass
class descAttHead:
    nDsc: int
    bTif: int
    bCol = 0

def ReadDescAttHead( fo ):

    nDsc = np.fromfile( fo, dtype=np.int32, count=1)[0] 
    bNap = np.fromfile( fo, dtype=np.uint8, count=1)[0]

    return nDsc

