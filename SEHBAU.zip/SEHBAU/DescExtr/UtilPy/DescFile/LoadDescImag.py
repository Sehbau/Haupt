"""

Reads descriptor attributes. Analogous to LoadDescImag.m

"""

import sys
#from numpy import fromfile, int8, uint8, shape
#import numpy as np

#sys.path.insert( 1, 'c:/klab/ppc/PROD/DescExtr/UtilPy/Vect/FileRead')

import ReadDescHeaders as ReadHed
import ReadCntAtt as Cnt


def LoadDescImag( filePath ):

    fo   = open(filePath, 'rb')

    # --------------------   Header   --------------------
    Hed    = ReadHed.ReadDescFileHead( fo, 10 )

    #print(Hed)

    # --------------------   DescSpaces   --------------------
    DSC = {};
    DSC['ACNT'], Ncnt   = Cnt.ReadCntSpc( fo )
    #VEC    = Cnt.ReadCntAtt( fo )

    fo.close()

    return DSC, Hed

##%% =====  Spaces  =====
##[V.ACNT Kt.Ncnt]        = ReadCntSpc(fileID);
##[V.ARSG Kt.Nrsg]        = ReadRsgSpc(fileID);
##[V.AARCfll Kt.NarcFll]  = ReadArcSpc(fileID); % full set
##[V.ASTRfll Kt.NstrFll]  = ReadStrSpc(fileID);
##[V.ASHP Kt.Nshp]        = ReadShpSpc(fileID); % shape

##idfSpc    = fread(fileID, 1,  'int=>int');    % identifier
##if (idfSpc~=66666) 
##    error('Spaces not properly read (see si_DescVect');
##end

# =====  Vectors  =====
##VEC  = np.zeros((nDsc,nDim), dtype=float, order='C')
##for i in range(0,nDsc):
##    for j in range(0,nDim):
##        VEC[i][j] = struct.unpack('f', fo.read(4))[0]

### =====  Zugehoer  =====
##IxImg = np.zeros((nDsc), dtype=int)
##for i in range(0,nDsc):
##    IxImg[i] = int.from_bytes( fo.read(4),'little')

##LbCat = np.zeros((nDsc), dtype=int)
##for i in range(0,nDsc):
##    LbCat[i] = int.from_bytes( fo.read(4),'little')

##Lev   = np.zeros((nDsc), dtype=np.uint8)
##for i in range(0,nDsc):
##    Lev[i] = int.from_bytes( fo.read(1),'little')


