"""

Plots bounding boxes.

"""

import matplotlib.patches as patches
import numpy as np

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   p_BoundBox1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

    Plots a single bounding box with optional jitter and contrast-based linewidth.
    
    Parameters:
        ax: Matplotlib Axes object to draw on.
        Prm: List or array [top, bottom, left, right] (zero-indexed).
        col: Color for the edge of the box.
        bJit: Whether to add jitter.
        bCtr: Whether to set line width based on contrast (Prm[4]).
    
    Returns:
        hr: The matplotlib Rectangle patch object.

"""
def p_BoundBox1(ax, Prm, col='r', bJit=False, bCtr=False):

    Prm = np.array(Prm)
    
    # Jitter to reduce visual overlap
    if bJit:
        Off = (np.random.rand(4) - 0.5) * 0.66
    else:
        Off = np.zeros(4)

    # Adjust for 1-based indexing and padding as in MATLAB
    top = Prm[0] + Off[0] + 0.75
    bot = Prm[1] + Off[1] + 1.25
    lef = Prm[2] + Off[2] + 0.75
    rit = Prm[3] + Off[3] + 1.25

    wth = max(rit - lef, 0.01)
    hgt = max(bot - top, 0.01)

    # Default line width
    linewidth = 1.0
    if bCtr and len(Prm) > 4:
        ctr = Prm[4]
        if ctr == 0:
            print("Warning: contrast = 0")
            ctr = 1
        linewidth = ctr / 50.0

    hr = patches.Rectangle((lef, top), wth, hgt,
                           linewidth=linewidth,
                           edgecolor=col,
                           facecolor='none')
    ax.add_patch(hr)
    
    return hr


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   p_BboxL   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

    Plots a list of bounding boxes on the given axes.

    Parameters:
        ax         : Matplotlib Axes object to draw on.
        ABbox      : (n, 4) or (n, 5) numpy array of bounding boxes.
        rgb_or_ix  : Color input - either a color index (int), RGB triplet, 
                     'var' for random colors, or None (default beige).
"""
def p_BboxL(ax, ABbox, rgb_or_ix=None):

    nBox = ABbox.shape[0]

    # ---------- Color ----------
    if rgb_or_ix is None:
        RGB = np.tile(np.array([191, 191, 0]) / 255.0, (nBox, 1))  # beige
    elif isinstance(rgb_or_ix, str) and rgb_or_ix == 'var':
        RGB = np.random.rand(nBox, 3)  # random RGB per box
    elif isinstance(rgb_or_ix, int):
        # Predefined palette
        Col = np.array([
            [255, 255,   0],  # yellow
            [255, 128,   0],  # orange
            [191, 191,   0],  # beige
            [255,   0,   0],  # red
            [170,   0, 255],  # magenta
            [  0, 255, 255],  # cyan
            [  0,   0, 255],  # blue
            [255, 255, 255]   # white
        ]) / 255.0
        
        color = Col[rgb_or_ix % len(Col)]
        
        RGB = np.tile(color, (nBox, 1))
        
    else:

        rgb_or_ix = np.array(rgb_or_ix)

        assert rgb_or_ix.shape == (3,), "rgb_or_ix must be a 3-element RGB triplet"

        RGB = np.tile(rgb_or_ix, (nBox, 1))

    # ========== Plot ==========
    for i in range(nBox):
        p_BoundBox1(ax, ABbox[i], col=RGB[i], bJit=True)
        ##plot_bound_box1(axs[i], bbox, col='b', bJit=True, bCtr=True)

