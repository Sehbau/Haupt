"""

Analogous to exsbDscxFull.m

"""
import sys
sys.path.insert(0, '..')
from globalsSB import *

u_AddGenPath( '../UtilPy/' )
u_AddGenPath( '../DescExtr/UtilPy/' )
from u_PathToBackSlash import u_PathToBackSlash

strImg 	= 'img1.jpg'

pthImg	= 'Imgs/' + strImg;          # image path
pthOut 	= 'Desc/' + strImg[:-4]      # outpath 

pthOut  = u_PathToBackSlash( pthOut, bOSisWin )


# ------------------------------   Execute Explicitly   ------------------------------
# https://docs.python.org/3/library/subprocess.html
# python 3.6
import subprocess
cmnd  = 'dscx ' + pthImg + ' ' + pthOut + ' ' + '--depth 2'

Res = subprocess.run( cmnd,
		       stdout = subprocess.PIPE,
		       stderr = subprocess.PIPE,
		       universal_newlines = True )

#Res = subprocess.run( [ 'dscx', pthImg, pthOut, '--depth 1' ],

print( Res.stdout )
print( Res.stderr )
#print( Out )

# ------------------------------   Execute As Function   ------------------------------
from CmndSupp import *
from RennDscx import *

Admin      = adminCmnd
Admin.optS = '--depth 2'
  
RennDscx( pthImg, pthOut, Admin )


# ------------------------------   Load   ------------------------------

print( '------------------------------   Loading Dsc file   ------------------------------' )
from LoadDescImag import LoadDescImag

filePath    = pthOut + '.dsc'

DSC, Hed    = LoadDescImag( filePath )

print(DSC)
print(Hed)


