"""

Read arrays, matrices and spaces thereof.

"""
import numpy as np




""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   n   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

    Reads an index array from a binary file and returns an IxsArr object.
    Equivalent to ReadIxsArr.m
"""
class IxsArr:
    def __init__(self, nEnt, Ix):
        self.nEnt = nEnt      # number of entries
        self.Ix = Ix          # index array

def ReadIxsArr(file):

    nEnt = np.fromfile(file, dtype=np.int32, count=1)[0]

    Ix   = np.fromfile(file, dtype=np.int32, count=nEnt)
    
    return IxsArr(nEnt, Ix)
