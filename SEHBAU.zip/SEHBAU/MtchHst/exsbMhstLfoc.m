% 
% Runs program mhstL (1-versus-List) for two focii:
%
% PREVIOUS  runDscx.m, runFocHistFew.m
%
% af runMvecL.m
%
% script to be run from directory 'MtchHst'
%
clear;
run('../globalsSB');

%cd( PthProg.descExtr );
%RennDscx( 'Imgs/img1.jpg', '../MtchHst/Desc/img1' );
%RennDscx( 'Imgs/img2.jpg', '../MtchHst/Desc/img2' );

cd( PthProg.mtchHst );

% we implement the following command:
%
% mhstL ../FocExtr/Focii/img2_f1.hsf1 Regist/FocHistExamp.txt Mes/FocLst.txt
%
finaProg    = 'mhstL';
pthFocTst   = '../FocExtr/Focii/foc2.hsf1';    % testing image 
finaLst     = '../FocExtr/Regist/FocHistExamp.txt';
finaMesFlst = 'Mes/FocLst.txt';
optS        = ''; % no options so far

%% =========   Command   ========
cmndFoc      = [finaProg ' ' pthFocTst ' ' finaLst ' ' finaMesFlst ' ' optS];

[Sts OutFoc] = dos( cmndFoc );

%% -------   Load Matching Results   -------
nFoc         = 6;
[OrdFoc DisFocOrd] = LoadSortFltTxt( finaMesFlst, nFoc );
DisFocUor    = LoadFltTxt( finaMesHuor, nFoc );
