%
% Plots the outcome for different initialization schemes.
%
clear;

[status, Out] = dos('sgrRGB Imgs\img2.jpg 128 128 128 --init 0');
Icol1     = imread('Desc/Ifore.png');

[status, Out] = dos('sgrRGB Imgs\img2.jpg 128 128 128 --init 1');
Icol2     = imread('Desc/Ifore.png');

[status, Out] = dos('Desc/sgrRGB Imgs\img2.jpg 128 128 128 --init 2');
Icol3     = imread('Desc/Ifore.png');

%% --------     Plot    ------------
figure(1); 
[nr nc]     = deal(2,2);

subplot(nr,nc,1); imagesc(Icol1);
subplot(nr,nc,2); imagesc(Icol2);
subplot(nr,nc,3); imagesc(Icol3);



