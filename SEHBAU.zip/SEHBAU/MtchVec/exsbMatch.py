"""

Matching with binary 'mvec1' in bare form, meaning without wrapper routines and plotting.

Analogous to exsbMatch.m

"""
import os
import subprocess
import sys

## --------------------------------------------------------------
#                          DESC EXTR
#  --------------------------------------------------------------
print('Descriptor extraction for two frames...');

# win with backslash for output directory
if sys.platform.startswith('win'):

    cmndF1 = r'..\DescExtr\dscx Imgs/Frm1.png Desc\Frm1'  # raw string to handle backslash
    cmndF2 = r'..\DescExtr\dscx Imgs/Frm2.png Desc\Frm2' 
    
elif sys.platform.startswith('linux') or sys.platform.startswith('darwin'):

    cmndF1 = '../DescExtr/dscx Imgs/Frm1.png Desc/Frm1'
    cmndF2 = '../DescExtr/dscx Imgs/Frm2.png Desc/Frm2'

Res1  = subprocess.run(cmndF1, shell=True, capture_output=True, text=True)
Res2  = subprocess.run(cmndF2, shell=True, capture_output=True, text=True)


## --------------------------------------------------------------
#                          MATCH
#  --------------------------------------------------------------
# should work for both OSs, as we dont write to file
cmndM = r'mvec1 Desc/Frm1.dsc Desc/Frm2.dsc'  # raw string to handle backslash

ResM  = subprocess.run( cmndM, shell=True, capture_output=True, text=True )


# Access status and output
if ResM.returncode != 0:
    raise ValueError("mvec1 did not execute properly somehow")

print( ResM.stdout )


## ------------------------------   Parse Output   ------------------------------
# no file is generated, only standard output.
sys.path.insert(0, '..')
from globalsSB import *

u_AddGenPath( '../UtilPy/' )
u_AddGenPath( 'UtilPy/' )

from MetricMeas import *

Sto, Hed         = u_MtrMesSecs( ResM.stdout )
AMesDty, mesTot  = u_MtrMesScnf( Sto );

print( mesTot )

