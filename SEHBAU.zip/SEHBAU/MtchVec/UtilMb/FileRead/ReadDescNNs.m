%
% Loads NN descriptors space, as saved under w_DescNNs in DescNNio.h
%
function NN = ReadDescNNs( fid ) 

nDsc    = fread( fid, 1, 'int=>int');      % # of descs

fprintf('%4d ', nDsc);
    
NN.Ix   = fread( fid, nDsc, 'int=>int') + 1;   % convert to one-indexing
NN.Mes  = fread( fid, nDsc, 'float=>single');  % measurement
NN.nDsc = nDsc;

% util:
NN.menMes = mean(NN.Mes);

end


