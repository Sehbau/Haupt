function [] = DispNdscMtc(Ndsc1, Ndsc2)

fprintf('%2d %2d %2d %2d\n', Ndsc1.ntSkl, Ndsc1.ntRsg, Ndsc1.ntArc, Ndsc1.ntStr);
fprintf('%2d %2d %2d %2d\n', Ndsc2.ntSkl, Ndsc2.ntRsg, Ndsc2.ntArc, Ndsc2.ntStr);

end

