function S = u_PrmsColor( val )


Scnt = fprintf('Cnt.wRgb %1.2f', 'asd');

Cnt.wRgb	0
Rsg.wRgb    0
Arc.wRgb    0
Str.wRgb    0
Shp.wRgb    0


end

