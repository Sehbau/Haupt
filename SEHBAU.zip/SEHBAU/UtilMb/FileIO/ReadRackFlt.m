%
% Reads a data matrix. In case of descriptor attributes it corresponds to
% [nAtt nDsc], that is rotated as opposed to the usual [nDsc nAtt] format.
%
% The general terminology is: reads a list of arrays of floats of same
% length, or put differently, a struct of arrays with number of fields
% (nFld [list length]) and number of elements [nElm]. Called 'rack' here.
%
% Data are read as single block [nFld nElm], a quasi matrix, and are then
% manipulated.
%
% Returns the data as matrix (when only 1 input argument is given) or as a
% struct with fieldnames as specified in aFieldNames (2nd argument must be
% given).
%
% ai ReadStrAtt.m, ReadArcAtt.m, ...
%
function [ARR szD] = ReadRackFlt( fid, aFieldNames )

%% ----------   Header   ----------
nFld = fread(fid, 1, 'int=>int'); % number of fields
nElm = fread(fid, 1, 'int=>int'); % number of elements

%% ----------   Matrix   ----------
ARR = fread(fid, nElm * nFld, 'float=>single'); % [nElm*nFld 1]

% nElm 
% nFld

ARR = reshape(ARR, [nElm nFld]);  % -> [nElm nFld] quasi matrix

szD.nFld = nFld;
szD.nElm = nElm;

%% ----------   As Struct   ----------
if nargin==2
    nFn = length(aFieldNames);
    assert( nFn==nFld, 'nFields not matching: %d <> %d', nFn, nFld );

    TMP = ARR;
    ARR = struct;
    for i = 1:nFn
        ARR.( aFieldNames{i} ) = TMP(:,i);
    end
end

end

