%
% Reads as saved under w_IxArr
%
function [S] = ReadIxArr(fileID) 

S.nEnt   = fread( fileID,      1, 'int=>int' );
S.Ix     = fread( fileID, S.nEnt, 'int=>int' );
