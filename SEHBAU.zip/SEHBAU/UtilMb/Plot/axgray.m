%
% Turns axis into small letters in gray
%
function [] = axgray(gray_lev, fontsize)

if ~exist('gray_lev','var');  gray_lev = .4;  end
if ~exist('fontsize','var');  fontsize = 5;   end

col_ax = [1 1 1]*gray_lev;
set(gca, 'xcolor', col_ax);
set(gca, 'ycolor', col_ax);

set(gca, 'fontsize', fontsize);
