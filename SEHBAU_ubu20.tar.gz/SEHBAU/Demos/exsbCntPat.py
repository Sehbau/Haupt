"""
Example contour pattern.
"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')

import AdminPy as sb

from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.DescExtr.DescFile.LoadDescription import LoadCntPat, LoadCntPatVmx, LoadCntRRE
from AdminPy.DescExtr.OrgAtt.OrgAtts import o_AttsLabPat
import AdminPy.DescExtr.Bbox.PlotBboxes as PltBbx

Fixt      = o_FileExtensions()

# ------------------------------   DesxExtr   ------------------------------
imgNa     = 'highway.jpg'
#imgNa     = 'street.jpg'
#imgNa     = 'forest.jpg'

imgNa     = Path( imgNa )
pthImg    = Path( 'Imgs/' ) / imgNa
pthDesc   = Path( 'Desc/' ) / imgNa.stem

cmnd      = [ Path('../DescExtr/dscx'), pthImg, pthDesc, '--saveRRE' ]

# Run descriptor extractor
Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Sts       = Res.returncode
OutDscx   = Res.stdout + Res.stderr

fpDSC     = o_FinaApndExtDscx( str(pthDesc), Fixt )

# ----------   Load   ----------
RRE, Hed  = LoadCntRRE( fpDSC.rre )
#print(RRE.ARDG[0].Pts.Ep1[0:10,:])


# --------------------------------------------------------------------------------
#                               CNTPAT
# --------------------------------------------------------------------------------
print('CntPat...')

cmnd      = [ Path('../DescProc/cntpat'), fpDSC.rre, pthDesc ]

Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Sts       = Res.returncode
Out       = Res.stdout + Res.stderr

Pat, HedP = LoadCntPat( fpDSC.cntPat )
PatVmx    = LoadCntPatVmx( fpDSC.cptVmx )

# ------------------------------   Plot Pattern   ------------------------------
from PIL import Image
import numpy as np
from AdminPy.DescExtr.Plot.PlotDescriptors import p_PatLin

Irgb   = np.array(Image.open(pthImg))

import matplotlib.pyplot as plt

fig, axes = plt.subplots(2, 1, num=2, clear=True)

# Image
axes[0].imshow(Irgb)
axes[0].set_axis_off()

# Pattern lines
ax = axes[1]
p_PatLin( Pat.Vrt, Pat.Vrt.RGB, ax=ax)
p_PatLin( Pat.Hor, Pat.Hor.RGB, ax=ax)

# MATLAB axis ij: origin at top-left, y increases downward
ax.set_ylim(ax.get_ylim()[::-1])

ax.set_title(f"nVrt/Hor {Pat.Vrt.nLin} {Pat.Hor.nLin}")

plt.tight_layout()
plt.show(block=False)

# ------------------------------   Plot Matrices   ------------------------------
LabAtt    = o_AttsLabPat()

# Create a figure with 1 row and 2 columns of subplots
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

# plot the Vrt matrix on the first subplot
nAttSel = 11
im1 = ax1.imshow( PatVmx.Vrt.VEC[:,0:nAttSel], cmap='viridis', aspect='auto')
ax1.set_xticks(range(nAttSel)) 
ax1.set_xticklabels(LabAtt[0:nAttSel], rotation=45, ha='right')
ax1.set_title('Vertical (Vrt)')
fig.colorbar(im1, ax=ax1, label='Intensity')

# plot the Hor matrix on the second subplot
im2 = ax2.imshow( PatVmx.Hor.VEC[:,0:nAttSel], cmap='plasma', aspect='auto')
ax2.set_title('Horizontal (Hor)')
ax2.set_xticks(range(nAttSel)) 
ax2.set_xticklabels(LabAtt[0:nAttSel], rotation=45, ha='right')
fig.colorbar(im2, ax=ax2, label='Intensity')

# Automatically adjust spacing between subplots
plt.tight_layout()
plt.show(block=False)


# ------------------------------   Plot RRE   ------------------------------
# we plot ALL rre contours for comparison
from AdminPy.DescExtr.Plot.PlotFeatures import *
figNo = 5
PlotCntUnvKpt( RRE, Irgb, HedP.space, figNo )

