"""

Scripts in directory Demos.

"""

import os, sys

finaPyExe = sys.executable

os.system(finaPyExe + ' exsbProposals.py')

os.system(finaPyExe + ' exsbSmlObjDet.py')

os.system(finaPyExe + ' exsbTxtrMaps.py')

os.system(finaPyExe + ' exsbSalBlobs.py')

os.system(finaPyExe + ' exsbCntPat.py') 

os.system(finaPyExe + ' exsbRegBon.py')
os.system(finaPyExe + ' exsbFormAxial.py') 
os.system(finaPyExe + ' exsbShape.py')

os.system(finaPyExe + ' exsbSmlObjReg.py') 
