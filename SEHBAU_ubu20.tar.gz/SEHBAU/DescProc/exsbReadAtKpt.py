"""
 Example for executable 'readatkyp' 

 Assumes script is run from dir 'DescProc'

 Three steps:
 1) run executable 'dscx' with options --saveRRE and --saveCVP
 2) 
 3) 

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn



# ------------------------------   Dscx (Step 1)   ------------------------------
strImg          = 'room.png'

fipaImg         = Path( 'Imgs/' + strImg )          # image path
fstmOut         = Path( 'Desc/' + strImg[:-4] )     # output file path

ArgsDscx        = o_CmndArgs('dscx')
ArgsDscx.opt    = ' --saveKeyp';

StdOut          = RennDscx( fipaImg, fstmOut, ArgsDscx, sb.PthProg['descExtr'] )

FixtImg         = o_FileExtensions()
fpDSC           = o_FinaApndExtDscx( fstmOut, FixtImg )

# ------------------------------   Load Depth Map   ------------------------------
from AdminPy.Util.FileIO.LoadData import LoadMapFlt
fipaMap         = 'Imgs/room_dth.mpf'
Mtif, szM       = LoadMapFlt( fipaMap ) 

from AdminPy.Util.Stats.Stats import f_ArrStat
StsMp           = f_ArrStat( Mtif.flatten() )

# ------------------------------   Load Keypoints   ------------------------------
from AdminPy.DescExtr.Features.LoadFeatures import *
KYP, Kt, HedKyp = LoadDescKeyp( fpDSC.kyp )
# KYP.ACNT

# ------------------------------   Plot Desc Points   ------------------------------
from PIL import Image

Irgb    = Image.open( fipaImg )

from AdminPy.DescExtr.Plot.PlotDescKeyp import *

if 0:
    
    PlotDescSpcKeyPts( Irgb, HedKyp.space, KYP.ACNT, 1, 'Contours' )
    PlotDescSpcKeyPts( Irgb, HedKyp.space, KYP.AARC, 2, 'Arcs' )
    PlotDescSpcKeyPts( Irgb, HedKyp.space, KYP.ASTR, 3, 'Straighters' )

    PlotFormSpcKeyPts( Irgb, HedKyp.space, KYP.AFRM, 4, 'Form' )


## ========================================================================
#                            ReadAtDpt   
#
fpExe   = sb.FipaExe['ratkpt']

if sys.platform.startswith('win'):

    cmnd    = f"{fpExe} {fpDSC.kyp} {fipaMap} {fstmOut}"
    
else: 
    cmnd    = f"./{fpExe} {fpDSC.kyp} {fipaMap} {fstmOut}"

import subprocess

Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )

if Res.returncode != 0:
    raise ValueError("readatkpt did not execute properly somehow")

# ------------------------------   Load Values   ------------------------------
VLS, KtVkyp, HedVkyp  = LoadDkypVals( fpDSC.vkyp )


# --------------------------------------------------------------------------------
#                                 P L O T 
# --------------------------------------------------------------------------------

from PIL import Image
from AdminPy.Util.Plot.PlotUtils import p_Img
from AdminPy.DescExtr.Plot.PlotFeatures import *
from AdminPy.DescExtr.Plot.PlotDescKeyp import *

# p_Img( 5, Mtif, '' )

# ------------------------------   Overview   ------------------------------
figDemo = 1
fig = plt.figure(figDemo)
fig.clf()

nr, nc = 2, 2

Irgb = np.asarray(Image.open(fipaImg))

# 1. Original image
ax = fig.add_subplot(nr, nc, 1)
ax.imshow(Irgb)

# 2. Depth / range map
ax = fig.add_subplot(nr, nc, 2)
ax.imshow(Mtif)
ax.set_title('Map (Depth/Range)')

# 3. Contours (Skeleton)
ax = fig.add_subplot(nr, nc, 3)
ax.imshow(np.zeros(szM), cmap='gray')
p_DkypVls( KYP.ACNT[0], VLS.ASKL[0], StsMp, 'btw_is_mip' )#, ax=ax )
ax.set_title('Contours (Skel)')

# 4. Form
ax = fig.add_subplot(nr, nc, 4)
ax.imshow(np.zeros(szM), cmap='gray')

FRM = KYP.AFRM[0]
nRoct = len(FRM.Bole)

p_RoctVls( FRM, np.arange(1, nRoct + 1), VLS.AFRM[0], StsMp, ax=ax )
ax.set_title('Form')

fig.tight_layout()
plt.show(block=False)


# ------------------------------   Entire Spaces   ------------------------------
print('Plotting with values... Geduld...')

PlotDkypVlsSpc( HedKyp.space, szM, StsMp, KYP.ACNT, VLS.ASKL, 5, 'Contours' )

PlotDkypVlsSpc( HedKyp.space, szM, StsMp, KYP.AARC, VLS.AARC, 6, 'Arcs' )

PlotDkypVlsSpc( HedKyp.space, szM, StsMp, KYP.ASTR, VLS.ASTR, 7, 'Straighters' )

PlotFormSpcKypVls( HedKyp.space, szM, StsMp, KYP.AFRM, VLS.AFRM, 8, 'Forms' )

print('done')
