%
% Create a struct-of-arrays.
%
% EXAMPLE
%   aFlds   = {'Hst' 'Kol' 'TxtGrid' 'TxgTot' 'TxtBbx' };
%   MesHKT  = i_StructOfArrays( aFlds, MMemp );
%
function [ S ] = i_StructOfArrays( aFldNa, Arr )

nFldNa   = length( aFldNa );

for f = 1:nFldNa
    fn      = aFldNa{f};
    S.(fn)  = Arr;
end

end

