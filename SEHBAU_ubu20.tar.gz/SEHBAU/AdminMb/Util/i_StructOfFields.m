%
% Create a struct-of-arrays.
%
% EXAMPLE
%
function [ S ] = i_StructOfFields( aFldNa )

nFldNa   = length( aFldNa );

for f = 1:nFldNa
    fn      = aFldNa{f};
    S.(fn)  = struct;
end

end

