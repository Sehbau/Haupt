%
% Saves a command to a shell script.
%
% cf RennRshd.m
%
function [] = s_CmndToSS( cmnd, typOS, sfp )
        
fid     = fopen(sfp, 'wt' );

if fid==-1
    error('Could not open file %s', sfp );
end

if strcmp(typOS,'win')
    fprintf( fid, '%s\n', cmnd );
else
    fclose(fid);
    error('OS %s not specified', typOS );
end

fclose(fid);

end % end of function

