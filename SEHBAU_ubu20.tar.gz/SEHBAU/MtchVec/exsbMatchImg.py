"""

Matching with binary 'mvec1' in bare form, meaning without wrapper routines and plotting.

Followed by plotting correspondence.

Analogous to both exsbMatch.m and exsbFrame.m

"""
import sys
import subprocess

## --------------------------------------------------------------
#                          DESC EXTR
#  --------------------------------------------------------------
print('Descriptor extraction for two frames...');

# win with backslash for output directory
if sys.platform.startswith('win'):
    # raw string to handle backslash
    cmndF1 = r'..\DescExtr\dscx Imgs/Frm1.png Desc\Frm1 --saveBsp' 
    cmndF2 = r'..\DescExtr\dscx Imgs/Frm2.png Desc\Frm2 --saveBsp' 
    
elif sys.platform.startswith('linux') or sys.platform.startswith('darwin'):

    cmndF1 = '../DescExtr/dscx Imgs/Frm1.png Desc/Frm1 --saveBsp'
    cmndF2 = '../DescExtr/dscx Imgs/Frm2.png Desc/Frm2 --saveBsp'

Res1  = subprocess.run( cmndF1, shell=True, capture_output=True, text=True)
Res2  = subprocess.run( cmndF2, shell=True, capture_output=True, text=True)


## --------------------------------------------------------------
#                          MATCH
#  --------------------------------------------------------------
# should work for both OSs, as we dont write to file
if sys.platform.startswith('win'):

    cmndM = r'mvec1 Desc/Frm1.dsc Desc/Frm2.dsc'
else:
    cmndM = r'./mvec1 Desc/Frm1.dsc Desc/Frm2.dsc'  # including ./ for linux

ResM  = subprocess.run( cmndM, shell=True, capture_output=True, text=True )


# Access status and output
if ResM.returncode != 0:
    raise ValueError("mvec1 did not execute properly somehow")

if 0:
    print( ResM.stdout )


## ------------------------------   Parse Output   ------------------------------
# no file is generated with mvec1, only standard output.
sys.path.insert(0, '..')        

from AdminPy.MtchVec.MetricMeas import pso_Mvec1Sections, pso_Mvec1Vals

# parse standard output (pso_)
Sto, Hed         = pso_Mvec1Sections( ResM.stdout )
AMesDty, mesTot  = pso_Mvec1Vals( Sto );

print( f'dis {mesTot.dis}   sim {mesTot.sim}' )


# --------------------------------------------------------------------------------
#                         C O R R E S P O N D E N C E
# --------------------------------------------------------------------------------
print('Correspondence...')

# ------------------------------   Load the 2 Images   ------------------------------
from PIL import Image

Irgb1 = Image.open( 'Imgs/Frm1.png')
Irgb2 = Image.open( 'Imgs/Frm2.png')

# ------------------------------   Load Dscx Output   ------------------------------
from AdminPy.DescExtr.DescFile import * # LoadDescUniv, LoadDbinUniv
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
FixtImg         = o_FileExtensions()

fpDSC1          = o_FinaApndExtDscx( 'Desc/Frm1', FixtImg )
fpDSC2          = o_FinaApndExtDscx( 'Desc/Frm2', FixtImg )

DUV1, Hed1      = LoadDescUniv( fpDSC1.dsc )
DUV2, Hed2      = LoadDescUniv( fpDSC2.dsc )

import AdminPy.DescExtr.Features.LoadFeatures as lodf
ABON1, Jbsp1    = lodf.LoadBonPixSpc( fpDSC1.bspx )
ABON2, Jbsp2    = lodf.LoadBonPixSpc( fpDSC2.bspx )

# ------------------------------   Load Mvec1 Output   ------------------------------
from AdminPy.MtchVec.FileRead.LoadDescNN import *

NN12         = LoadNNDspaces("", "12") # default anyway
NN21         = LoadNNDspaces("", "21") # not used. just verifying I can load

# ------------------------------   Plot the 2 Frames   ------------------------------
from AdminPy.Util.Plot.PlotUtils import *

figImg = 3
PlotTwoFrames( Irgb1, Irgb2, figImg )

# ------------------------------   Plot DescTypes   ------------------------------
from AdminPy.MtchVec.Util.PlotCorrespFlw import * # in one plot, quasi-flow
from AdminPy.MtchVec.Util.PlotCorrespSbS import * # side-by-side

szI    = Irgb1.size
nLev   = Hed1.nLev

if 1:
    figCnt = 5
    PlotCorrespCntSbS( DUV1.ACNT, DUV2.ACNT, nLev, NN12.ACNT, szI, figCnt )

    figCnt = 6
    PlotCorrespCntFlw( DUV1.ACNT, DUV2.ACNT, nLev, NN12.ACNT, szI, figCnt )

if 1:
    figFrm = 7
    PlotCorrespFrmSbS( DUV1.AFRM, DUV2.AFRM, nLev, NN12.AFRM, Jbsp1.SzM, figFrm,
                       ABON1, ABON2 )
    figFrm = 8
    PlotCorrespFrmFlw( DUV1.AFRM, DUV2.AFRM, nLev, NN12.AFRM, Jbsp1.SzM, figFrm,
                       ABON1, ABON2 )

