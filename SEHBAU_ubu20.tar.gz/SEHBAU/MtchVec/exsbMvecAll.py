"""

Runs the python example scripts using mvec.

"""
import os, sys

finaPyExe = sys.executable

os.system(finaPyExe + ' exsbMatchImg.py') # contains correspondence as in exsbFrames.m

os.system(finaPyExe + ' exsbMatchSml.py')

