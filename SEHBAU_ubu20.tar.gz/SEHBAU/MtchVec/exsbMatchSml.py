"""

Matching a smaller image (ie. region) with larger image with mvec1.

Argument order for mvec1:   larger image first, then smaller image.

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn

Fixt            = o_FileExtensions()

fipaPtc1        = Path( 'Imgs/P1_Frm1.png' ) # patch from 1st frame          
fipaPtc2        = Path( 'Imgs/P2_Frm1.png' ) #   "     "   "    "
imgpFrm2        = Path( 'Imgs/Frm2.png' )    # full 2nd frame (similar image)       
imgpImg2        = Path( 'Imgs/img2.jpg' )    # totally different image

fstmPtc1        = Path( 'Desc/P1_Frm1')
fstmPtc2        = Path( 'Desc/P2_Frm1')
fstmFrm2        = Path( 'Desc/Frm2')
fstmImg2        = Path( 'Desc/img2')

# ------------------------------   Dscx (Step 1)   ------------------------------
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
ArgsDscx        = o_CmndArgs('dscx')
ArgsDscx.opt    = '';

print('DescExtr...')
StdOutP1        = RennDscx( fipaPtc1, fstmPtc1, ArgsDscx, sb.PthProg['descExtr'] )
StdOutP2        = RennDscx( fipaPtc2, fstmPtc2, ArgsDscx, sb.PthProg['descExtr'] )
StdOutF2        = RennDscx( imgpFrm2, fstmFrm2, ArgsDscx, sb.PthProg['descExtr'] )
StdOutI2        = RennDscx( imgpImg2, fstmImg2, ArgsDscx, sb.PthProg['descExtr'] )
print('done')

finP1           = o_FinaApndExtDscx( fstmPtc1, Fixt )
finP2           = o_FinaApndExtDscx( fstmPtc2, Fixt )
finF2           = o_FinaApndExtDscx( fstmFrm2, Fixt )
finI2           = o_FinaApndExtDscx( fstmImg2, Fixt )

# ------------------------------   Matching   ------------------------------
from AdminPy.MtchVec.RennMvec import *
from AdminPy.MtchVec.FileRead.LoadDescNN import *
Args            = o_CmndArgs( 'mvec' )
Args.fpPrm      = 'Params/PrmMtch_PosLax.txt'

print('Matching...')
OutM_F2_P1      = RennMvec1( finF2.dsc, finP1.dsc, Args, sb.PthProg['mtchVec'] )
NN_F2_P1_d12    = LoadNNDspaces("","12")
NN_F2_P1_d21    = LoadNNDspaces("","21") # for displacement/translation vector

OutM_F2_P2      = RennMvec1( finF2.dsc, finP2.dsc, Args, sb.PthProg['mtchVec'] )
NN_F2_P2_d12    = LoadNNDspaces("","12")
NN_F2_P2_d21    = LoadNNDspaces("","21")

OutM_I2_P1      = RennMvec1( finI2.dsc, finP1.dsc, Args, sb.PthProg['mtchVec'] )
OutM_I2_P2      = RennMvec1( finI2.dsc, finP2.dsc, Args, sb.PthProg['mtchVec'] )
print('done')


# ------------------------------   Parse Output   ------------------------------
print('Parse output...')
from AdminPy.MtchVec.MetricMeas import * # pso_Mvec1Sections, pso_Mvec1Vals

mesF2P1     = mes_Mvec1( OutM_F2_P1 )
mesF2P2     = mes_Mvec1( OutM_F2_P2 )
mesI2P1     = mes_Mvec1( OutM_I2_P1 )
mesI2P2     = mes_Mvec1( OutM_I2_P2 )

DispMvec1Tot( mesF2P1[0], 'Frm2 Ptc1   ' ) # we expect lower dissimilarity...
DispMvec1Tot( mesF2P2[0], 'Frm2 Ptc2   ' ) # 
DispMvec1Tot( mesI2P1[0], 'Img2 Ptc1   ' ) # ...than with the totally different image
DispMvec1Tot( mesI2P2[0], 'Img2 Ptc2   ' ) # 
print('done')


# ------------------------------   Load the Images   ------------------------------
from PIL import Image

Frm2     = Image.open( imgpFrm2 )
Img2     = Image.open( imgpImg2 )
Ptc1     = Image.open( fipaPtc1 )
Ptc2     = Image.open( fipaPtc2 )

# ------------------------------   Load the Dscx Output   ------------------------------
from AdminPy.DescExtr.DescFile import * # LoadDescUniv, LoadDbinUniv
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
FixtImg         = o_FileExtensions()

fpFRM2             = o_FinaApndExtDscx( fstmFrm2, FixtImg )
fpPtc1             = o_FinaApndExtDscx( fstmPtc1, FixtImg )
fpPtc2             = o_FinaApndExtDscx( fstmPtc2, FixtImg )

DUVfrm2, HedFrm2   = LoadDescUniv( fpFRM2.dsc )
DUVptc1, HedPtc1   = LoadDescUniv( fpPtc1.dsc )
DUVptc2, HedPtc2   = LoadDescUniv( fpPtc2.dsc )


# ------------------------------   Analyze NNs   ------------------------------
from   AdminPy.MtchVec.MtchAlys import *
import AdminPy.MtchVec.MtchAlys as MtchAlys  

nLevP1      = HedPtc1.nLev
nLevP2      = HedPtc2.nLev
TolDuv      = nndTolDuv()

MtchAlys.bDISPMtchAlys = 2
locEstF2P1,_ = f_NNAlyDUV( NN_F2_P1_d21, DUVfrm2, nLevP1, TolDuv, 'F2_P1_d21' )
locEstF2P2,_ = f_NNAlyDUV( NN_F2_P2_d21, DUVfrm2, nLevP2, TolDuv, 'F2_P2_d21' )


# ------------------------------   Plot the 2 Frames   ------------------------------
print('Plotting...Geduld...')
from AdminPy.Util.Plot.PlotUtils import *

figImg   = 3
PlotTwoFrames( Frm2, Ptc1, figImg )

# ------------------------------   Plot DescTypes   ------------------------------
from AdminPy.MtchVec.Util.PlotCorrespFlw import * # in one plot, quasi-flow
from AdminPy.MtchVec.Util.PlotCorrespSbS import * # side-by-side

from copy import deepcopy

#szI    = Irgb1.size

if 1:
    figCnt = 5
    PlotCorrespCntSbS( DUVfrm2.ACNT, DUVptc1.ACNT, nLevP1, NN_F2_P1_d12.ACNT, None, figCnt )

    figCnt = 6
    PlotCorrespCntFlw( DUVfrm2.ACNT, DUVptc1.ACNT, nLevP1, NN_F2_P1_d12.ACNT, None, figCnt )

    figCnt = 7
    PlotCorrespCntSbS( DUVptc1.ACNT, DUVfrm2.ACNT, nLevP1, NN_F2_P1_d21.ACNT, None, figCnt )

    #figCnt = 8
    #PlotCorrespCntFlw( DUVptc1.ACNT, DUVfrm2.ACNT, nLevP1, NN_F2_P1_d21.ACNT, None, figCnt )

"""
menVrt/Hor:    0.4988 0.5712  _____
menVrt/Hor:    0.5904 0.4797  _____
"""
