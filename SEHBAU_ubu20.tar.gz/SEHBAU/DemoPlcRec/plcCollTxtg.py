"""

Collecting texturegrams. 

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')
import numpy as np

import AdminPy as sb
import AdminPy.DescExtr.Texture as sbTxt

# -----  paths  -----
pthOpr      = Path.cwd()
DirNames    = sb.Orga.o_DirNames()
Pths        = sb.Orga.o_DirsPrependPath( DirNames, pthOpr )

IxImg       = [0, 1, 2, 3, 6]

# -----  register  -----
Fixt, Dmy   = sb.Orga.o_FileExtensions()   
RgstFinas   = sb.Mtch.o_RegistFileNames();
RgstFipas   = sb.Orga.o_DirsPrependPath( RgstFinas, Pths.rgst )

dmy         = sb.Mtch.o_RegistSetSave( RgstFipas, Pths.desc, "", IxImg, Fixt, 7) 

sb.Mtch.v_RegistValid( RgstFipas.slc )

fipaMvec    = Path( sb.FipaExe['mvecL'] )  # filepath of program binary mvecL

FixtColl    = sb.Orga.o_FileExtensColl();
FinaColl    = sb.Orga.o_FileNameColl( Pths.coll, FixtColl )

cmnd        = [ sb.FipaExe['collsalc'], RgstFipas.slc, FinaColl.salcFs ]

Res         = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
OutColl     = Res.stdout + Res.stderr

TXTR, Hed   = sbTxt.LoadCollTxtg( FinaColl )

# --------------------   Stats  -----------------------
StsColl     = sbTxt.f_CollTxtrStats( TXTR )
#StsColl         = f_CollTxtrStats( TXTR );

# --------------------   Reshape Output  -----------------------
# reshaping is necessary for learning with a transformer that requires sequence x
# dimensions, in our case grid units x texture biases.

# --- for one image
Txgg        = TXTR.GRD[0,:]                     # take first image
szGrd       = [5,5]
nTxtBis     = 7
MxTxg       = sbTxt.u_TxtrGramGridArrToMtrx( Txgg, szGrd, nTxtBis )
# now we normalize
nrm         = 40
MxNrm       = sbTxt.u_TxtrGramGridArrToMtrx( Txgg, szGrd, nTxtBis, nrm )

# --- for the collection
GNRM        = sbTxt.u_TxtrGramGridCollReshape( TXTR.GRD, szGrd, nTxtBis, nrm )

# --------------------   Load First Salc File   --------------------
# for comparison and verification
aFpSlc,nLin = sb.Util.LoadTextLinewise( RgstFipas.slc )
fp1st       = aFpSlc[0]                         # takes first file
SLC, Hed    = sb.DescExtr.LoadDescSalc( fp1st )
Grid1Img    = SLC.Txa.Grm.Grid                  # contains array and size
GridMx      = Grid1Img[0]                       # take array

Df1         = GridMx.flatten() - MxTxg.flatten()
assert Df1.max()==0, 'values not matching somehow'

# normalize it
GridMx[:,0] = GridMx[:,0] / nrm     # now ready for feeding to a (learned) transformer

# verify more
Df2         = GNRM[0,:]       - GridMx.flatten()
Df3         = MxNrm.flatten() - GridMx.flatten()
assert Df2.max()==0, 'values not matching somehow'
assert Df3.max()==0, 'values not matching somehow'

# --------------------   Plot   -----------------------
figNo = 4;
sbTxt.PlotCollTxtrStats( StsColl, figNo );

# --- two more figures displaying the matrices
import matplotlib.pyplot as plt

TxLb = sb.Orga.o_TxtrLabels()

# Figure 6
plt.figure(6)
plt.clf()
plt.imshow(MxNrm, aspect="auto")
plt.colorbar()
plt.xticks( range(TxLb.nLab), TxLb.aSho)
plt.title("First Image")

# Figure 7
plt.figure(7)
plt.clf()
plt.imshow(GNRM, aspect="auto")
plt.colorbar()
plt.ylabel("All Images")
plt.xlabel("Grid Units")

plt.show(block=False)

import time
time.sleep(1)




