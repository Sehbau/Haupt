"""

Mock example for setting up spatial histograms for a transformer. Assumes that
previous scripts have been executed already (see sequence in plcAll.py)

We also load texture, but cannot concatenate it with the histograms as we have
different grid sizes.

"""
import sys, subprocess, os, glob
import numpy as np
from pathlib import Path

import torch
from torch.utils.data import Dataset, DataLoader

import warnings
# Suppress the specific PyTorch nested tensor user warning
warnings.filterwarnings("ignore", message=".*enable_nested_tensor is True.*")

sys.path.insert(0, '..')

import AdminPy as sb
import AdminPy.TransFormer as sbTf

# ----------   Parameters Texture   ----------
# better use: PrmTxt      = sb.Orga.Parameters.prmTexture()
# for texture (grids)
szGrd       = [5,5]             # fixed unfortunately                           
nTxtBis     = 7
nrm         = 40                # normalization factor for numerosity bias

# ------------------------------   Load Collections   ------------------------------
dirColl     = 'Coll/';
fipsColl    = dirColl + 'COLLHST';

Fixt        = sb.Orga.o_FileExtensColl()
Fina        = sb.Orga.o_FileNameColl( dirColl, Fixt )

HSTC, Nbin  = sb.DescExtr.LoadHist.LoadCollHist( fipsColl + Fixt.hsspa )
TXTR, Hed   = sb.DescExtr.Texture.LoadCollTxtg( Fina )

sb.DescExtr.LoadHist.DispBnumSpat( Nbin )

# normalize and reshape texture:
GNRM        = sb.DescExtr.Texture.u_TxtrGramGridCollReshape( TXTR.GRD, szGrd, nTxtBis, nrm )

# ----------   Extract Folds   ----------

# training (trn) and prediction/evaluation (prd)
IxTrn       = [0,1,2]
IxPrd       = [3,4]
LbTrn       = np.array( [0,0,1] ) # fake labels training
LbPrd       = np.array( [0,1] )   # fake labels prediction (testing)

HTRN        = HSTC[IxTrn,:]
HPRD        = HSTC[IxPrd,:]
del HSTC

# we extract the texture folds, but cannot append them to the histograms as those
# are taken from 3x3 grid (texture is 5x5)
TTRN        = GNRM[IxTrn,:]
TPRD        = GNRM[IxPrd,:]
del GNRM

# ----------   Parameters Transformer   ----------
# Architecture:
nCll        = Nbin.nCells       # quasi sequence
nBin        = Nbin.nBinPerCell  
szEmb       = 512               # dimensionality model/embedding
nLay        = 2                 # num of layers
dimFF       = 8                 # dimensionality feedforward
nCtg        = 2                 # num of categories
# Learning:
nEpo        = 2                 # num of epochs
szBtc       = 2                 # size batch
lernRate    = 1e-4              # learning rate

# ------------------------------   Model   ------------------------------
# a very simple transformer model (it is just a single head):
MOD       = sbTf.MOD_Hspa_sh( nBin=nBin, szEmb=szEmb, nLay=nLay, nCll=nCll,
                              nCtg=nCtg, dimFF=dimFF )

# --------------------------------------------------------------------------------
#                             T R A I N   ( F I T )
# --------------------------------------------------------------------------------
# initialize loader
DSET        = sb.TransFormer.clsDataSetHspa( HTRN, LbTrn, nCll, nBin )
DLODer      = DataLoader( DSET, batch_size=szBtc, shuffle=True )

# ------------------------------   Guidance   ------------------------------
criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.AdamW(MOD.parameters(), lr=lernRate)

# ------------------------------   LOOP   ------------------------------
Loss      = np.zeros(nEpo)
MOD.train()
for e in range( nEpo ):

    lossVrun = 0.0
    cBtc = 0
    
    for BTC, LbB in DLODer:

        optimizer.zero_grad()
    
        LOGT    = MOD( BTC ) 
        loss    = criterion( LOGT, LbB )

        loss.backward()
        optimizer.step()

        lossVrun += loss.item()
        cBtc += 1
        
    Loss[e] = lossVrun / cBtc

print( Loss )


# --------------------------------------------------------------------------------
#                               P R E D I C T 
# --------------------------------------------------------------------------------
# initialize loader
DSET      = sb.TransFormer.clsDataSetHspa( HPRD, LbPrd, nCll, nBin )
DLODer    = DataLoader( DSET, batch_size=szBtc, shuffle=False )

MOD.eval()
cHit = 0
with torch.no_grad():

    for BTC, LbB in DLODer:

        Lgts    = MOD( BTC )
        IxPredF = torch.argmax(Lgts, dim=1)
        nHit    = (IxPredF == LbB).sum().item()
        cHit   += nHit;


# ------------------------------   Prepare for Multi-Head   ------------------------------
"""

If we were to feed the spatial histograms in raw form to a multi-head transformer,
then it makes sense to trim the dimensionality beforehand. We provide here a utility
function that omits the last components (which happen to be bins from shape
attributes).

"""
nCmp        = Nbin.nBinPerCell
nHed        = 7                                 # number of attention heads

IxS, nCmp, ntNew = sbTf.u_IxTrimToAttHed( HTRN, nCll, nCmp, nHed )
HTRN        = HTRN[:,IxS]

print( HTRN.shape )
print(np.sum(HTRN))



