"""

Mock example for setting up descriptor vector matrices for a transformer. Assumes
that previous scripts have been executed already (see sequence in plcAll.py)

"""
import sys, subprocess, os, glob
import numpy as np
from pathlib import Path

import torch
from torch.utils.data import Dataset, DataLoader

import warnings
# Suppress the specific PyTorch nested tensor user warning
warnings.filterwarnings("ignore", message=".*enable_nested_tensor is True.*")

sys.path.insert(0, '..')

import AdminPy as sb
import AdminPy.TransFormer as sbTf

dscTyp      = 'skl'

# -----  paths  -----
pthOpr      = Path.cwd()
DirNames    = sb.Orga.o_DirNames()
Pths        = sb.Orga.o_DirsPrependPath( DirNames, pthOpr )

# ------------------------------   Load   ------------------------------
from AdminPy import Collection as cl
COLLVEC, ntDsc, nDim = cl.LoadColl.LoadCollVec(    Pths.coll, dscTyp )
CollLab, ntDsc2      = cl.LoadColl.LoadCollVecLab( Pths.coll, dscTyp )

# ------------------------------   REFINE VEC   ------------------------------
# iclCollVmxLst.py
COLLVAX, COLLPOS, LbNew, IxRed = sb.Orga.o_AttCntTrfm( COLLVEC )

del COLLVEC # ensure we accidentally use it

# ------------------------------   Prep Folds   ------------------------------
# training (trn) and prediction/testing (prd)
IxTrn       = [0,1,2]
IxPrd       = [3,4]
LbTrn       = np.array( [0,0,1] ) # fake labels training
LbPrd       = np.array( [0,1] )   # fake labels prediction (testing)

# ------------------------   FOLDS & REARRANGE TO LIST   ---------------------------
u_CollVecSel      = cl.LoadColl.u_CollVecSelc
AVECTRN, ALabTrn  = u_CollVecSel( COLLVAX, CollLab, IxTrn )
AVECPRD, ALabPrd  = u_CollVecSel( COLLVAX, CollLab, IxPrd )
APOSTRN, dmy      = u_CollVecSel( COLLPOS, CollLab, IxTrn )
APOSPRD, dmy      = u_CollVecSel( COLLPOS, CollLab, IxPrd )

# ----------   Parameters Transformer   ----------
# Architecture:
szEmbFct   = 2
nLay       = 2
dimFF      = 8
nHed       = 1

# Learning:
nEpo       =  100
szBtc      =  8
lrPeak     = 0.0005
gnoisSdv   = 0.001
pDrot      = 0.3
    
stepPlotLoss   = 20
lrMin          = lrPeak * 0.1

# ------------------------------   Model   ------------------------------
import AdminPy.TransFormer as TF
nAtt      = COLLVAX.shape[1]
szEmb     = nAtt*szEmbFct
nCat      = 2  # fake number of categories
MOD       = TF.MOD_DSCclsf( nAtt, szEmb, nLay, dimFF, nCat )

# --------------------------------------------------------------------------------
#                             T R A I N   ( F I T )
# --------------------------------------------------------------------------------
# initialize loader
DSET    = TF.clsDatasetDvmx( AVECTRN, APOSTRN, LbTrn )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=True, collate_fn = TF.COLT_DSC_VAR )

# ------------------------------   Guidance   ------------------------------
criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.AdamW(MOD.parameters(), lr=lrPeak)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR( optimizer, T_max=nEpo, eta_min=lrMin)

# ------------------------------   LOOP   ------------------------------
Loss      = np.zeros(nEpo)
MOD.train()
for e in range( nEpo ):

    lossVrun = 0.0
    cBtc = 0
    
    for step, (DSC, COO, MASK, LbB) in enumerate(DLODer):

        optimizer.zero_grad()
    
        LOGT    = MOD( DSC, COO, MASK ) 
        loss    = criterion( LOGT, LbB )

        loss.backward()
        optimizer.step()

        lossVrun += loss.item()
        cBtc += 1
        
    Loss[e] = lossVrun / cBtc

# print( Loss )


# --------------------------------------------------------------------------------
#                               P R E D I C T 
# --------------------------------------------------------------------------------
# initialize loader
DSET    = TF.clsDatasetDvmx( AVECPRD, APOSPRD, LbPrd )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=False, collate_fn = TF.COLT_DSC_VAR )

MOD.eval()
cHit = 0
with torch.no_grad():

    for DSC, COO, MASK, LbB in DLODer:

        LOGT    = MOD( DSC, COO, MASK ) 

        IxPredF = torch.argmax(LOGT, dim=1)
        nHit    = (IxPredF == LbB).sum().item()
        cHit   += nHit;

acc = cHit / len(LbPrd)

print( f"# acc {acc:.4f}  szEmb {szEmb}  nHed {nHed}  nLay {nLay}  dimFF {dimFF}", end="" )
print( f"  nEpo {nEpo}  szBtc {szBtc}  lrPeak {lrPeak:.6f}  pDrot {pDrot:.1f}" )
