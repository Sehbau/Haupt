"""

Loading collected files.

---------------   DEF SUM   ---------------

def LoadCollVec( lfpStem: str | Path, dscTyp: str ) -> tuple[np.ndarray, int, int]:
def LoadCollVecLab(lfpStem: str | Path, dscTyp: str) -> tuple[np.ndarray, int]:

def u_CollVecSelc( COLLVEC, CollLab, IxImg ):
def u_CollVecSelcLev( COLLVEC, CollLab, IxImg, low, hih ):

def u_CollDscCount( Lab ):


Elsewhere:
- histogram in LoadHist.py

"""
from pathlib import Path
from dataclasses import dataclass
import numpy as np

from AdminPy.Orga import OrgFileNames


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
"""
@dataclass
class dimGrid:
# ""
#    Dimensions of grid. N of vertical times N of horizontal cells (units)
# ""
    ver: int
    hor: int
"""



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollVec   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads collected vectors (of MULTIPLE images) as saved under collVec.cpp.

sa LoadDescVect.m, LoadVecColl.m

Example in exsbCollVec.m
"""
def LoadCollVec( lfpStem: str | Path, dscTyp: str ) -> tuple[np.ndarray, int, int]:

    pthStm = Path(lfpStem)
    #lfp    = pthStm.parent / f"{pthStm.name}VEC_{dscTyp}.txt"
    lfp    = pthStm / f"VEC_{dscTyp}.txt"
    
    try:
        # read as entire block directly into a numpy array (equivalent to fscanf %f)
        # using float32 directly saves memory during the initial read
        VEC = np.fromfile(lfp, dtype=np.float32, sep=" ")
    except FileNotFoundError:
        raise FileNotFoundError(f"could not find {lfp}")

    # In Python, an empty file or failed parsing returns an empty array
    if VEC.size == 0:
        raise IOError(f"Could not read data or file is empty: {lfp}")

    # DispLoad(lfp); # Assuming this is a custom print/log function from your framework

    # -------   Last array entry contains ntDsc   -------
    # In Python, negative index -1 targets the last element safely
    ntDsc = int(VEC[-1])
    print(f"ntDsc {ntDsc}, ", end="")

    # -------    Reshape   -------
    VEC = VEC[:-1]  # exclude the last array entry (slices out the last item)

    # MATLAB reshapes column-wise, whereas NumPy defaults to row-wise (C-order).
    # To match MATLAB's column-major ordering, we use order='F' (Fortran order).
    VEC = VEC.reshape((-1, ntDsc), order="F")
    VEC = VEC.T  # Transpose the matrix

    nDim = VEC.shape[1]

    print(f"matrix is [{ntDsc} {nDim}].")

    return VEC, ntDsc, nDim



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollVecLab   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads labels as saved under collVec.cpp

Label array is [ntDsc 3] with columns corresponding to level, image and
last column is empty.

af LoadCollVec.m
"""
def LoadCollVecLab(lfpStem: str | Path, dscTyp: str) -> tuple[np.ndarray, int]:

    # Ensure lfpStem is a Path object and insert platform-specific slash
    pthStm  = Path(lfpStem)
    lfp     = pthStm / f"Lab_{dscTyp}.txt"

    try:
        # read as entire block directly into a numpy int32 array (fscanf %d)
        LAB = np.fromfile(lfp, dtype=np.int32, sep=" ")
    except FileNotFoundError:
        raise FileNotFoundError(f"could not find {lfp}")

    if LAB.size == 0:
        raise IOError(f"Could not read data or file is empty: {lfp}")

    # DispLoad(lfp);

    # -------    reshape   -------
    nLabTyp = 3

    # MATLAB reshapes column-wise, so we use order='F' (Fortran order).
    # nLabTyp is the row count during reshape, matching MATLAB's reshape(LAB, 3, [])
    LAB = LAB.reshape((nLabTyp, -1), order="F")
    LAB = LAB.T

    # -------    stats   --------
    ntDsc = LAB.shape[0]

    print(f"Label array is of size [{ntDsc} {nLabTyp}].")

    # NumPy's unique() returns sorted unique values, matching MATLAB behavior
    IxLev = np.unique(LAB[:, 0])
    IxImg = np.unique(LAB[:, 1])
    # IxCat   = np.unique( LAB[:,2] )

    print(f"Levels from {IxLev[0]} to {IxLev[-1]} (zero-indexing)")
    print(f"Images from {IxImg[0]} to {IxImg[-1]} (  \"     \"    )")
    # print(f"Categories from {IxCat[0]} to {IxCat[-1]}")

    return LAB, ntDsc



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollVecSelc   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Selects images from collection matrix COLLVEC and from label array CollLab, and
returns them as list.

"""
def u_CollVecSelc( COLLVEC, CollLab, IxImg ):

    nImg     = len(IxImg)
    
    LbImg    = CollLab[:,1]

    AVEC     = [None]*nImg
    ALab     = [None]*nImg

    for i in range(0,nImg):

        Bimg    = LbImg==IxImg[i]

        AVEC[i] = COLLVEC[Bimg,:]
        ALab[i] = CollLab[Bimg,:]

    return AVEC, ALab


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollVecSelcLev   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Same as u_CollVecSelc, but includes level selection

ti   iclCollVmxLst.py

"""
def u_CollVecSelcLev( COLLVEC, CollLab, IxImg, low, hih ):

    nSel     = len(IxImg)
    
    LbLev    = CollLab[:,0]
    LbImg    = CollLab[:,1]

    AVEC     = [None]*nSel
    ALab     = [None]*nSel

    for i in range(0,nSel):

        Bimg    = LbImg==IxImg[i]

        VECI    = COLLVEC[Bimg,:]
        LabI    = CollLab[Bimg,:]

        LevI    = LabI[:,0]

        Blev    = (LevI >= low) & (LevI <= hih)

        AVEC[i] = VECI[Blev,:]
        ALab[i] = LabI[Blev,:]

    return AVEC, ALab


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollDscCount   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Counts the num of descriptors per image and level.

ti   iclCollVmxLst.py

"""
def u_CollDscCount( Lab ):

    LevAll   = Lab[:,0]
    ImgAll   = Lab[:,1]

    nImg     = ImgAll.max()+1
    mxLev    = LevAll.max()+1

    #AVEC     = [None]*nSel
    mxnDsc = 0
    MxnDsc = np.zeros(mxLev)
    for i in range(0,nImg):

        Bimg    = ImgAll==i
        nDsc    = np.count_nonzero(Bimg)

        if nDsc > mxnDsc:
            mxnDsc = nDsc

        # ------  Per Level  ------
        LevI    = LevAll[Bimg]

        for l in range(0,mxLev):
            
            Blev    = (LevI==l)
            nD      = np.count_nonzero(Blev)
            #print( nD )
            if nD > MxnDsc[l]:
                MxnDsc[l] = nD

    return mxnDsc, MxnDsc



