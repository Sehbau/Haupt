
"""

Scripts carrying out processes (executables) for an image collection.

Take plcDscx.py, plcDtop.py (DemoPlcRec) as an example: we want to place the loop in
those scripts into a definition.

def DSCX( aImg, fipaDscx, Pths, Args )
def Dtop()
def Dbin()

"""


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   DSCX   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Descriptor extraction for a collection (a list of images).


"""
def DSCX( aImg, fipaDscx, Pths, Args ):

    for fipaImg in aImg:

        fipsOut = Pths.dirDsc / fipaImg.stem

        #            arg0      arg1     arg2      arg3            arg4
        cmnd   = [ fipaDscx, fipaImg, fipsOut, Args.prmFile ] + Args.optS

        #print( cmnd )

        Res    = subprocess.run( cmnd, shell=True, capture_output=True ) #, text=True)

        sb.Util.v_CmndExec( Res )
        
        sb.Util.printDotProg()

    return 0
