"""

A ViT-like transformer model for classification with the descriptor vector matrices
for segments, ie. contour, form, arc, straighter, etc. Uses padding to account for
variable lengths. Single attention head.

---------------   CLS/DEF SUM   ---------------
class clsDatasetDvmx(Dataset):
def COLT_DSC_VAR( BTCH ):
class ENC_Dsc(nn.Module):
class MOD_DSCclsf(nn.Module):

"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# max number of descriptors: corresponds to max length sequence
# Note: I did not check yet, whether a new image exceeds the max.
csMxnDsc = 1000                 



""" ------------------------------   clsDatasetDvmx   ------------------------------

    Dataset preparation.

       DSC: descriptors as vector matrix       {nImg}[nDsc nAtt]
       COO: coordinates, vertical & horizontal {nImg}[nDsc 2]
       Lbl: Numpy array of labels, shape       [nImg, 1]
"""
class clsDatasetDvmx(Dataset):

    def __init__(self, DSC, COO, Lbl):

        self.DSC = DSC
        self.COO = COO
        self.Lbl = Lbl
        
    def __len__(self):
        return len(self.DSC)
    
    def __getitem__(self, ix):

        Img1    = self.DSC[ix]
        Coo1    = self.COO[ix]

        ImgTns  = torch.from_numpy(Img1).float()
        CooTns  = torch.from_numpy(Coo1).float()
        
        LblI    = int(self.Lbl[ix])
        
        return ImgTns, CooTns, LblI

    
""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   COLT_DSC_VAR   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Custom collate function for DataLoader.
Pads variable-length sequences up to the longest sample *in this specific BTCH*.
BTCH is a list of tuples: [(vmx, coords, label), ...]

"""
def COLT_DSC_VAR( BTCH ):

    DSCLST = [item[0] for item in BTCH]
    COOLST = [item[1] for item in BTCH]
    Lbls   = torch.tensor([item[2] for item in BTCH], dtype=torch.long)
    
    szBtc  = len(BTCH)
    szEmb  = DSCLST[0].shape[1]
    
    # --- initalize zero-padded tensors
    DSCpad = torch.zeros(szBtc, csMxnDsc, szEmb)
    COOpad = torch.zeros(szBtc, csMxnDsc, 2)
    MSKpad = torch.zeros(szBtc, csMxnDsc, dtype=torch.bool)
    
    # --- fill in the valid contents
    for i in range(szBtc):
        n               = DSCLST[i].shape[0]
        DSCpad[i, :n]   = DSCLST[i]
        COOpad[i, :n]   = COOLST[i]
        MSKpad[i, :n]   = True
        
    return DSCpad, COOpad, MSKpad, Lbls
    


""" ------------------------------   ENC_Dsc   ------------------------------

Encoder layer.

"""
class ENC_Dsc(nn.Module):
    
    def __init__(self, szEmb, dimFF ):

        super(ENC_Dsc, self).__init__()
        
        self.szEmb = szEmb
        
        # Projects 2D coordinates [v,h] into the object feature space
        self.proj_Coord = nn.Linear(2, szEmb)
        
        # Standard Single-Head Attention Projections
        self.proj_Quy = nn.Linear(szEmb, szEmb)
        self.proj_Key = nn.Linear(szEmb, szEmb)
        self.proj_Val = nn.Linear(szEmb, szEmb)
        
        self.proj_Out = nn.Linear(szEmb, szEmb)
        self.f_Norm1  = nn.LayerNorm(szEmb)
        self.f_Norm2  = nn.LayerNorm(szEmb)
        
        self.ffn = nn.Sequential(
            nn.Linear(szEmb, szEmb * dimFF ),
            nn.GELU(),
            nn.Linear(szEmb * dimFF, szEmb)
        )

    def forward(self, DSC, COO, MSK=None):
        """
        DSC   [szBtc csMxnDsc szEmb] raw descriptors
        COO   [szBtc csMxnDsc 2    ] normalized coordinates
        MSK   [szBtc csMxnDsc      ] padding mask
        """
        szB, nDsc, szEmb = DSC.shape
        
        # 1. Project coordinates and add them to object features (Position Embedding)
        #PosEmb    = self.proj_Coord(COO)
        DSC       = DSC + COO # PosEmb  
        RESD      = DSC
        
        # 2. Standard Attention projections
        QUY = self.proj_Quy(DSC)
        KEY = self.proj_Key(DSC)
        VAL = self.proj_Val(DSC)
        
        # 3. Pure dot-product attention matrix calculation
        # [szB nDsc nDsc]
        SCORattn = torch.matmul(QUY, KEY.transpose(-2, -1)) / (self.szEmb ** 0.5)
        
        # 4. Masking Step (Block padded objects)
        if MSK is not None:
            MSK2D    = MSK.unsqueeze(1) 
            SCORattn = SCORattn.masked_fill( ~MSK2D, float('-inf'))
        
        WGTSattn     = F.softmax(SCORattn, dim=-1)
        
        if MSK is not None:
            WGTSattn = WGTSattn.masked_fill( ~MSK2D, 0.0)

        # 5. Aggregate and output
        CNTXT    = torch.matmul(WGTSattn, VAL)
        DSC      = self.f_Norm1(RESD + self.proj_Out(CNTXT))
        DSC      = self.f_Norm2(DSC  + self.ffn(DSC))
        return DSC


""" ------------------------------   MOD_DSCclsf   ------------------------------

Model for classification of descriptor vector matrices.

"""
class MOD_DSCclsf(nn.Module):

    def __init__(self, nAtt, szEmb, nLay, dimFF, nCls):

        super(MOD_DSCclsf, self).__init__()

        self.proj_DscUp  = nn.Linear( nAtt, szEmb)
        self.proj_CooUp  = nn.Linear( 2, szEmb )

        self.f_Encoder = nn.ModuleList([
            ENC_Dsc( szEmb, dimFF )
            for _ in range(nLay)
        ])
        # if one encoder layer only:
        # self.BACKB  = ENC_Dsc(szEmb)

        self.f_Clsf = nn.Sequential(
            nn.Linear(szEmb, szEmb),
            nn.GELU(),
            #nn.Dropout(0.1),
            nn.Linear(szEmb, nCls)
        )
        
    def forward(self, DSCraw, COOraw, MSK):

        DSC   = self.proj_DscUp( DSCraw )
        COO   = self.proj_CooUp( COOraw )
        
        # 1. Update features using masked attention
        for lay in self.f_Encoder:
            DSC = lay( DSC, COO, MSK )

        DSCupd   = DSC
        #DSCupd  = self.BACKB(DSC, COO, MSK)
        
        # 2. MASKED GLOBAL POOLING STEP:
        # Padded elements are zeroed out so they do not taint the average calculation.
        DSCmsk  = DSCupd * MSK.unsqueeze(-1).float()
        
        # Sum elements and divide by actual valid counts per scene sequence
        DscSum  = torch.sum(DSCmsk, dim=1)
        Knts    = torch.sum(MSK, dim=1, keepdim=True).float()
        SCENvec = DscSum / Knts
        
        # 3. Predict scene categories
        LOGT    = self.f_Clsf(SCENvec)
        return LOGT

    

