"""

Utilities for plotting

---------------   DEF SUM   ---------------
def imglabN(label, count):
def p_LossInit( ):
def p_LossUpdate( ax, Loss, line ):

def fig_MoveToLowRit( event=None ):
def p_Img( figNo, Mp, titStr ):
def p_Cross(gry, ax ):

def PlotTwoFrames( Frm1, Frm2 ):

"""
from dataclasses import dataclass

import matplotlib.pyplot as plt




# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass(frozen=True)
class colPalette:          # ''''''''''''''''''''   colPalette   ''''''''''''''''''''
    """
    Colors

    ai BonUtil.py
    """
    gray    = [0.8, 0.8, 0.8]

    drkRed  = [0.8, 0.0, 0.0]
    fllRed  = [1.0, 0.0, 0.0]

    drkBlu  = [0.0, 0.2, 0.6]
    fllBlu  = [0.0, 0.0, 1.0]

    drkGrn  = [0.0, 0.5, 0.0]
    fllGrn  = [0.0, 1.0, 0.0]




# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   imglabN   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Displays a simple text label and count.

"""
def imglabN(label, count):

    plt.title(f'{label} ({count})')





""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_LossInit   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Displays a simple text label and count.

"""
def p_LossInit( ):

    plt.ion()
    fig, ax = plt.subplots()
    line, = ax.plot([], [], 'r-')  # 'r-' creates a solid red line
    ax.set_title("Live Training Loss Profile")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss")
    ax.grid(True)

    fig.canvas.manager.window.after( 50, fig_MoveToLowRit ) # sb.Util.Plot.

    return ax, line

    
""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_LossUpdate   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Displays a simple text label and count.

"""
def p_LossUpdate( ax, Loss, line ):

    # 2. Update the dynamic plot data
    xax     = list( range(1, len(Loss) + 1) )
    line.set_xdata(xax)
    line.set_ydata(Loss)
        
    # Rescale plot limits dynamically to fit the new values
    ax.relim()
    ax.autoscale_view()
    
    # 3. Force Matplotlib to redraw the figure immediately
    plt.draw()
    plt.pause(0.1)  # Brief pause allows the GUI thread to paint
    

    
""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   fig_MoveToLowRit   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Places the figure to the lower rite.

"""
def fig_MoveToLowRit( event=None ):

    """Callback function triggered when the figure window manager establishes itself."""
    try:
        Mngr   = plt.get_current_fig_manager()
        Win    = Mngr.window
        
        # 1. Fetch dimension maps
        wScrn  = Win.winfo_screenwidth()
        hScrn  = Win.winfo_screenheight()
        wFig   = Win.winfo_width()
        hFig   = Win.winfo_height()
        
        # 2. Factor in OS scaling (if physical/logical pixels mismatch)
        # Windows/Linux taskbar padding safety buffer
        buffer_y = 80 
        buffer_x = 20
        
        x = wScrn - wFig - buffer_x
        y = hScrn - hFig - buffer_y
        #print( f"x={x}, y={y}" )
        x = 1200
        y = 400
        #print( f"x={x}, y={y}" )

        # 3. Direct geometry override
        Win.geometry(f"+{int(x)}+{int(y)}")

    except Exception as e:
        pass
    

""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_Img   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP
"""
def p_Img( figNo, Mp, titStr ):

    plt.figure(figNo)

    plt.imshow( Mp, aspect='auto')
    plt.title( titStr )

    plt.draw()
    plt.pause(0.001)  # Brief pause to let the GUI window render


    
""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_Cross   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots a cross for better orienting.

IN     gry (int or float): grayscale value between 0 and 255
"""
def p_Cross(gry, ax ):

    # Get current axes (equivalent to gca)
    #ah = plt.gca()
    
    # Get current limits
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()
    
    # Calculate midpoints (centers)
    cc = sum(xlim) / 2
    rc = sum(ylim) / 2
    
    # Convert 0-255 scale to Matplotlib's 0-1 normalized RGB scale
    col = (gry / 256, gry / 256, gry / 256)
    
    # Draw vertical and horizontal lines centered at the midpoints
    ax.axvline(x=cc, color=col)
    ax.axhline(y=rc, color=col)
    
    
    
""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotTwoFrames   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots two frames (or any two images) side-by-side. 

"""
def PlotTwoFrames( Frm1, Frm2, figNo ):

    fig, ax = plt.subplots(1, 2, num=figNo, figsize=(12, 6))

    ax[0].imshow( Frm1 )
    ax[0].axis('off')

    ax[1].imshow( Frm2 )
    ax[1].axis('off')

    plt.tight_layout()
    plt.show(block=False)
