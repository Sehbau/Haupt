"""

Manipulation of data structures.

sa u_AttIxAsFields in module OrgAtts.

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------

# ----------   Stc of Arr   ----------
def u_MtrxToStcArr( Mx, aFldNames ):
def u_StcArrToStcM
ap( R, szM ):

"""
from dataclasses import make_dataclass

import numpy as np



# --------------------------------------------------------------------------------
#                               S T C   of   A R R
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_MtrxToStcArr   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Turns a data matrix [nObs nFet] into a struct of arrays (SoA) given
fieldnames in aFldNames. If fieldnames are given as a single string then
use u_AttLabArrToList to turn them into a list.

Analogous to u_MtrxToStcArr.m

cfro u_DescMxToStcOfArr,  ReadStcMapFlt
sa   o_AttsLabels.m

IN   Mx         matrix, e.g [nDsc nAtt]
     aFldNames  attribute names, ie. 'Vrt', 'Hor', ...
OUT  S          struct with fields .Vrt, .Hor, ...each one [nDsc 1]

"""
def u_MtrxToStcArrDict( Mx, aFldNames ):

    nObs, nFet = Mx.shape
    #nFet, nObs = Mx.shape
    nFlds      = len(aFldNames)

    assert nFlds == nFet, f"nFeatures not matching: {nFlds} <> {nFet}"

    AArr = { aFldNames[i]: Mx[:,i] for i in range(nFlds) }

    return AArr



"""
Same as above but returned as a dataclass.
"""
def u_MtrxToStcArrDcls(Mx, aFldNames):

    nObs, nFet = Mx.shape
    nFlds = len(aFldNames)

    assert nFlds == nFet, ( f"nFeatures not matching: {nFlds} <> {nFet}" )

    # Create dataclass with the requested field names
    StcArr = make_dataclass(
        'StcArr',
        [(name, np.ndarray) for name in aFldNames],
        slots=True
    )

    # Initialize with the corresponding matrix columns
    return StcArr(**{
        aFldNames[i]: Mx[:, i]
        for i in range(nFlds)
    })



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_StcArrToStcMap   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

See u_StcArrToStcMap.m

"""
def u_StcArrToStcMap( R, szM ):

    nRow, nCol = szM[0], szM[1]
    for key in R:

        Mlin   = R[key]
        #Map    = Mlin.reshape((nCol,nRow)) 
        Map    = Mlin.reshape((nRow,nCol)) 
        R[key] = Map
        
    return R


