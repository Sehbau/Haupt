"""

Simples Stats

------------------------------   CLS SUM   ------------------------------
class mtrxColStat:
class arrStat:

------------------------------   DEF SUM   ------------------------------

def f_ArrStat(Arr):
def f_MtrxColStat(M):

"""

from dataclasses import dataclass
import numpy as np


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass(slots=True)
class arrStat:
    bInf: bool = False
    nInf: int = 0
    men: float = np.nan
    min: float = np.nan
    max: float = np.nan
    std: float = np.nan
    nVal: int = 0
    nnz: int = 0
    prpNnz: float = np.nan

@dataclass
class mtrxColStat:
    """ Simple Stats for a matrix
    """
    Men: np.ndarray
    Min: np.ndarray
    Max: np.ndarray
    Rng: np.ndarray


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_ArrStat   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Statistics of an array of floats, ignoring INF values.

NaN values are also ignored in the statistics.

cf exsbReadAtKpt.py
"""
def f_ArrStat(Arr):

    Binf = np.isinf(Arr)

    S = arrStat()
    S.bInf = np.any(Binf)
    S.nInf = np.count_nonzero(Binf)

    Arr = np.asarray(Arr, dtype=float).copy()
    Arr[Binf] = np.nan

    S.men = np.nanmean(Arr)
    S.min = np.nanmin(Arr)
    S.max = np.nanmax(Arr)
    S.std = np.nanstd(Arr)

    S.nVal = Arr.size
    S.nnz = np.count_nonzero(Arr)
    S.prpNnz = S.nnz / S.nVal if S.nVal > 0 else np.nan

    return S



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_MtrxColStats   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
"""
def f_MtrxColStat(M):

    S = mtrxColStat(
        Men=np.mean(M, axis=0),
        Min=np.min(M, axis=0),
        Max=np.max(M, axis=0),
        Rng=None
    )

    S.Rng = S.Max - S.Min

    return S
