"""

Read arrays, matrices and (mathematical) spaces thereof.


def ReadIxsArr( file ):
def ReadIxvArr( file ):

def ReadMtrxDat( file, conversion ):
def ReadMapGen( file, szM, conversion ):

def ReadStcMapFlt( file, aFieldNames, szM ):
def ReadStcArr( file, dtypeIN, aFieldNames ):

"""
from dataclasses import dataclass, field
from collections import namedtuple

import numpy as np
import numpy.typing as npt

from AdminPy.Util.DataStruct import *


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass(slots=True)
class ixsArr:                   # ''''''''''''''''''''   ixsArr   ''''''''''''''''''''
    """
    Indices: a simple array
    """
    Ix: npt.NDArray[np.int32] = field( default_factory=lambda: np.empty(0, dtype=np.int32) )

    @property
    def nEnt(self) -> int:
        return self.Ix.size

    

@dataclass(slots=True)
class ixvArr:                   # ''''''''''''''''''''   pixRCi   ''''''''''''''''''''
    """
    Indices and their values.
    """
    Ix: npt.NDArray[np.int32]   = field( default_factory=lambda: np.empty(0, dtype=np.int32) )
    Vl: npt.NDArray[np.float32] = field( default_factory=lambda: np.empty(0, dtype=np.float32) )

    @property
    def nEnt(self) -> int:
        return self.Ix.size
    

    
        
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadIxsArr   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads an index array from a binary file and returns an IxsArr class.
Equivalent to ReadIxsArr.m

cf ReadSalcBbxEns

"""
def ReadIxsArr( file ):

    nEnt = np.fromfile(file, dtype=np.int32, count=1)[0]

    Ix   = np.fromfile(file, dtype=np.int32, count=nEnt)
    
    return ixsArr(Ix)



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadIxvArr   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads an index array from a binary file and returns an IxvArr class.
Equivalent to ReadIxvArr.m

cf ReadAttFarbig in ReadAttGen.py

"""
def ReadIxvArr( file ):

    nEnt = np.fromfile(file, dtype=np.int32, count=1)[0]

    Ix   = np.fromfile(file, dtype=np.int32,   count=nEnt)
    Vl   = np.fromfile(file, dtype=np.float32, count=nEnt)
    
    return ixvArr(Ix, Vl)





""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadMtrxDat   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads a data matrix [nRow nCol] that was saved feature-/columnwise in C, that is
'inverse' [nCol nRow]. We therefore reshape to 'standard' format here.

EXAMPLE: descriptor attributes were saved in C by writing the attribute arrays
sequentially, ie. Len, Str, Ori. Thus when loaded, the data corresponds to [nAtt
nDsc]. We then reshape to [nDsc nAtt] format.

Use ReadStcArr() below, to read and turn into struct-of-arrays in one function.

ai ReadStrAtt(), ReadArcAtt(), LoadTxtrMaps(), ...

IN    fid         file pointer
      dtypeIN     datatype conversion, 
                   ie. np.float32, np.int32

See ReadMtrxDat.m

"""
def ReadMtrxDat( file, dtypeIN ):

    # ----------   Header   ----------
    nFet = int(np.fromfile(file, dtype=np.int32, count=1)[0])
    nObs = int(np.fromfile(file, dtype=np.int32, count=1)[0])

    # print( nFet, nObs )
    
    # ----------   Matrix   ----------
    ARR      = np.fromfile(file, dtype=dtypeIN, count=nObs * nFet)

    # ----------   Reshape   ----------
    Mtx      = ARR.reshape((nFet, nObs)).T #, order = 'F' )

    SizeDesc = namedtuple('SizeDesc', ['nObs','nFet'])
    szD      = SizeDesc( nObs=nObs, nFet=nFet )

    return Mtx, szD    



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadMapGen   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Analogous to ReadMapGen.m

cf LoadTxtrMaps

"""
def ReadMapGen( file, szM, conversion ):

    # Ensure szM is a tuple in row form
    if len(szM) != 2:
        raise ValueError("szM must have exactly two dimensions")

    nPx = szM[0] * szM[1]

    # --------------------   Read   --------------------
    Mcm = np.fromfile( file, dtype=conversion, count=nPx )

    # --------------------   Reshape   --------------------
    Map = Mcm.reshape( (szM[0], szM[1] ))

    return Map



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadStcMapFlt   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

See ReadStcMapFlt.m

"""
def ReadStcMapFlt( file, aFieldNames, szM ):

    # first load as data matrix
    Mx, szD     = ReadMtrxDat( file, np.float32 )

    # now turn into a struct-of-array
    SofArr      = u_MtrxToStcArrDict( Mx, aFieldNames )

    # now reshape arrays to maps
    SofMps      = u_StcArrToStcMap( SofArr, szM )

    return SofMps


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadStcArr   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

See ReadStcArr.m

"""
def ReadStcArr( file, dtypeIN, aFieldNames ):

    # first load as data matrix
    Mx, szD     = ReadMtrxDat( file, dtypeIN )

    #print( szD )

    # now turn into a struct-of-array
    SofArr      = u_MtrxToStcArrDict( Mx, aFieldNames )

    return SofArr


