"""

Image utilities. So far bounding box routines, mostly used for fabric.

For bounding box from description files see directory DescExtr/Bbox/


------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def i_Bbox( top, bot, lef, rit ):

def vrf_BboxInBounds( Box: np.ndarray, szV: int, szH: int ) :

def u_BboxRand( nBox, szVrt, szHor ):

def u_BboxTBLR( Box ):

def u_IptchFromBbox( Irgb, Bbx ):
def u_IptchFromBboxLst( Irgb, BBox ):

def u_BboxUnitRg( Box, szM ):

def f_BboxEnlarge1( Box, szI, xpn ):
def f_BboxShrink1( Box, szI, shk ):

def f_ImgPyr(Irgb):

Elsewhere:
- more bounding box routines in DescExtr/Bbox
- Pixels and coordinates in Orga/PixAnf.py

"""
import numpy as np

from skimage.transform import resize



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_Bbox   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII

Returns the four parameters as numpy integer array. More of a utility routine for
example scripts.

"""
def i_Bbox( top, bot, lef, rit ):
    
    return np.array([top, bot, lef, rit], dtype=np.int32)


""" VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV   vrf_BboxInBounds   VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

Verifies if focus is within map shape

ai annFabric.py

"""
def vrf_BboxInBounds( Box: np.ndarray, szV: int, szH: int ) :

    top   = Box[0]
    bot   = Box[1]
    lef   = Box[2]
    rit   = Box[3]
    
    if top<0 or bot>szV-1 or lef<0 or rit>szH-1:
        print(f"top {top}  bot {bot}  lef {lef}  rit {rit}")
        raise Error( f"Bounding box out of bounds")


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_BboxRand   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Random bounding boxes
"""
def u_BboxRand( nBox, szVrt, szHor ):

    # 1. Generate random top-left corners (y1, x1)
    # Making sure they leave room for at least a 1-pixel wide/tall box
    Top = np.random.randint(0, szVrt - 1, size=nBox)
    Lef = np.random.randint(0, szHor - 1, size=nBox)

    # 2. Generate random bottom-right corners (Bot, x2) 
    # ensuring Bot > Top and x2 > Lef
    Bot = np.random.randint(Top + 1, szVrt)
    Rit = np.random.randint(Lef + 1, szHor)

    # 3. Stack them together into an Nx4 array
    BBoxs = np.column_stack((Top, Bot, Lef, Rit)).astype(np.int32)

    #BBoxs = np.array([ [5, 120, 80, 230],
     #                  [60, 90, 120, 150] ], dtype=np.int32)
    #top=5; bot=120; lef=80; rit=230

    return BBoxs



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_BboxTBLR   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Return bounding box parameters individually

USE     top, bot, lef, rit =  bbx.u_BboxTBLR( BoxSmp ) 

"""
def u_BboxTBLR( Box ):

    return Box[0], Box[1], Box[2], Box[3]



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_IptchFromBbox   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Extracts an image patch from Irgb according to the bounding box parameters.
"""
def u_IptchFromBbox( Irgb, Box ):

    if Box is None or len(Box)==0 or Box[0]==-1: return []
    
    top, bot, lef, rit =  u_BboxTBLR( Box ) 

    return Irgb[top:bot+1, lef:rit+1, :]    # the corresponding patch in the image



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_IptchFromBboxLst   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Extracts an image patch from Irgb according to the bounding box parameters.
"""
def u_IptchFromBboxLst( Irgb, BBox ):

    if BBox is None or len(BBox)==0: return []

    nBox, nPrm   = BBox.shape
    AIptc = [None]*nBox
    for b in range(nBox):
        top, bot, lef, rit = u_BboxTBLR( BBox[b,:] )
        AIptc[b]           = Irgb[top:bot+1, lef:rit+1, :] # the corresponding patch

    return AIptc



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_BboxUnitRg   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

The dimensions of a bounding box as proportions of the given image/map size.

USE     pVrt, pHor =  u_BboxUnitRg( BoxSmp, szImg ) 

"""
def u_BboxUnitRg( Box, szM ):

    return (Box[1]-Box[0]) / szM[0], (Box[3]-Box[2]) / szM[1]



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_BboxEnlarge1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Enlarges a bounding box by a factor xpn as a proportion of the bounding box.

IN    Box   top/bot/lef/rit
      szI   image size, to ensure enlargement is within bounds
      xpn   expansion proportions, tuple of vertical and horizontal

"""
def f_BboxEnlarge1( Box, szI, xpn ):

    szV = szI[0]
    szH = szI[1]

    assert xpn[0]<1.0 and xpn[1]<1.0, "Scaling factor must be below one"
    assert np.size(xpn)==2, "expansion proportions must be tuple, vertical and horizontal"

    xpnV = (Box[1] - Box[0]) * xpn[0]
    xpnH = (Box[3] - Box[2]) * xpn[1]

    Box[0] = max(0,     Box[0] - xpnV)
    Box[1] = min(szV-1, Box[1] + xpnV)
    Box[2] = max(0,     Box[2] - xpnH)
    Box[3] = min(szH-1, Box[3] + xpnH)

    return Box


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_BboxShrink1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Shrinks a bounding box by a factor shk as a proportion of the bounding box.

"""
def f_BboxShrink1( Box, szI, shk ):

    szV = szI[0]
    szH = szI[1]

    assert shk[0]<1.0 and shk[1]<1.0, "Scaling factor must be below one"
    assert np.size(shk)==2, "expansion proportions must be tuple, vertical and horizontal"

    shkV = (Box[1] - Box[0]) * shk[0]
    shkH = (Box[3] - Box[2]) * shk[1]

    top    =    Box[0] + shkV
    bot    =    Box[1] - shkV
    if top>bot:
        cen = (Box[0]+Box[1])/2
        top = cen
        bot = cen

    lef    =    Box[2] + shkH
    rit    =    Box[3] - shkH
    if lef>rit:
        cen = (Box[2]+Box[3])/2
        lef = cen
        rit = cen
        
    
    Box[0] = top
    Box[1] = bot
    Box[2] = lef
    Box[3] = rit

    return Box



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_ImgPyr   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
    Generate a simple image pyramid, downscaling by a factor of 2.

    Stops when the next image's smallest spatial dimension would be
    smaller than 16.

    Returns
    -------
    aIMG : list[np.ndarray]
        Pyramid images, starting with the original image.
    nLev : int
        Number of pyramid levels.
"""
def f_ImgPyr(Irgb):

    aIMG = [ np.asarray(Irgb) ]
    nLev = 10

    for l in range(1, nLev):

        Ihih  = aIMG[l-1]

        minSz = min( Ihih.shape[:2] )

        if (minSz / 2) < 16:
            nLev = l
            break

        Ihih = resize(
            Ihih,
            (round(Ihih.shape[0] * 0.5), round(Ihih.shape[1] * 0.5)),
            preserve_range=True,
            anti_aliasing=True
        ).astype(Ihih.dtype)

        aIMG.append(Ihih)

    return aIMG, nLev



