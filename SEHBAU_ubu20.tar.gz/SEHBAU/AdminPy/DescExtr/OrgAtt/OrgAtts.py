"""

Organization of attributes

---------------   CLS SUM   ---------------
class dclsTxtrLabels:
class dclsAttIx:

---------------   DEF SUM   ---------------
def o_TxtrLabels():
def u_AttLabArrToList( labStr ):
def u_AttIxAsFields(aLab: list[str]) -> Any:
def o_AttIxAsFields( LB ):
def o_AttsLabels():

# ----------   VecMx Manip   ----------
def f_AngOriToSinCos( Ori: np.ndarray ) -> np.ndarray:
def u_VmxXtrOriAsSinCos( VEC, Lab ):
def u_VmxXtrPos( VEC, Lab ):
def u_VmxExpndOriToCoo( VEC: np.ndarray, IxAtt, Lab ) -> tuple[np.ndarray, list[str]]:

# ----------   Prep Transformer   ----------
def o_AttCntTrfm( V ):
def o_AttFrmTrfm( V ):

"""
from dataclasses import dataclass, make_dataclass
from typing import Any
import numpy as np
import math

lbAngCoo    = ['sin', 'cos']



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

""" ------------------------------   dclsTxtrLabels   ------------------------------
    Blob labels. Set with o_TxtrLabels() below
"""
@dataclass
class dclsTxtrLabels:

    aSho: list[str]
    aLon: list[str]
    nLab:    int

""" ------------------------------   dclsAttIx   ------------------------------
Attribute indices.
"""
@dataclass
class dclsAttIx:
    Cnt: Any
    Frm: Any
    Arc: Any
    Str: Any
    #Shp: Any i have duplicate labels

    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_TxtrLabels   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Blob labels.
 
They are also used in ReadBlobMapGlbSts.m (but NOT passed as variable).

They must match with CntTxtAnf.h, w_CntTXTbis (CntTxtIO.h)

ia 

"""
def o_TxtrLabels():

    # NB NVHAU
    aSho = ['Num', 'Blk', 'Nil', 'Vrt', 'Hor', 'Axi', 'Uni']

    aLon = [
        'Num (count)',
        'Blank (void)',
        'Nil (no ori)',
        'Vertical',
        'Horizontal',
        'Axial (vrt&hor)',
        'Uni (1 ori)',
        'Ken (contrast)',
        'Bunt'
    ]

    nLab = len( aSho );

    return dclsTxtrLabels( aSho=aSho, aLon=aLon, nLab=nLab )



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_AttLabArrToList   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Used below for converting a single array of labels (string) into a list

"""
def u_AttLabArrToList( labStr ):

    nChar = len(labStr)

    if nChar % 6 != 0:
        print("Input string:", repr(labStr))
        raise ValueError("Label array must be multiple of 6 characters.")

    aLbs = []
    for i in range(0, nChar, 6):
        lab = labStr[i:i+6].strip()             # trim spaces
        aLbs.append(lab)

    return aLbs    
    #return labStr.strip().split()


    
""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_AttLabArrToList   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Creates a struct with fieldnames from 'aLab' holding the index value to array
'aLab'.

sa u_AttIxFromLab.m
cf o_AttIxAsFields

IN    aLab    a list of attribute labels
OUT   S       dataclass instance with fieldnames from labels holding index to aLab

"""
def u_AttIxAsFields( aLab: list[str] ) -> Any:

    nLab = len(aLab)

    # Dynamically define a dataclass where all fields are typed as int
    # e.g., [('field1', int), ('field2', int)]
    aFlds   = [(lbl, int) for lbl in aLab]
    DclsDyn = make_dataclass("S_Struct", aFlds)

    # Map each label to its 0-indexed position
    FldVals = {}
    for l in range(nLab):

        FldVals[aLab[l]] = l

    # Unpack the values to instantiate the dataclass
    S = DclsDyn(**FldVals)

    return S



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttIxAsFields   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

see o_AttsLabels.m

USE   LBATT    = sb.Orga.o_AttsLabels()
      IXATT    = sb.Orga.o_AttIxAsFields( LBATT )
"""
def o_AttIxAsFields( LB ):

    S = dclsAttIx(
        Cnt = u_AttIxAsFields(LB.Cnt),
        Frm = u_AttIxAsFields(LB.Frm),
        Arc = u_AttIxAsFields(LB.Arc),
        Str = u_AttIxAsFields(LB.Str),
        #Shp = u_AttIxAsFields(LB.Shp),
    )
    return S



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttsLabels   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

see o_AttsLabels.m

"""
def o_AttsLabels():

    lbPos   = ['psv', 'psh']
    lbRgb   = ['red', 'grn', 'blu']
    lbsGen  = lbPos + lbRgb

    @dataclass
    class LB:
        pass
    
    # ----------   Contour   ----------
    LB.Cnt = ['len', 'str', 'ori'] + lbPos + lbRgb
    LB.Skl = LB.Cnt

    # ----------   Form   ----------
    radi = ['rad',  'cir',  'eloR', 'eloF', 'bulk',   'bs1', 'bs2', 'bs3', 'bs4', 'bs5',
            'star', 'dent'] + lbPos + lbRgb
    aspa = u_AttLabArrToList('AreN  HgtN  WthN  High  Wide  Higv  Widv  RtAre Axial Diamo Diag1 Diag2 EloSg EloRd Steh  Lieg  ')
    ecke = u_AttLabArrToList('EkTL  EkTT  EkTR  EkRR  EkBR  EkBB  EkBL  EkLL  ')

    LB.Frm = radi + aspa + ecke # 17 + 14 + 8
    
    # ----------   Arc   ----------
    LB.Arc = ['len', 'krv', 'dir', 'am1', 'am2', 'smo', 'spz', 'run', 'eck'] + lbPos + lbRgb

    # ----------   Str   ----------
    LB.Str = ['les', 'str', 'ifx', 'wig', 'bog', 'amp', 'smo' ] + lbPos + lbRgb

    # ----------   Bndg   ----------
    LB.Bndg = ['len', 'agx', 'tig', 'dns', 'ori' ] + lbPos + lbRgb

    # ----------   Shape   ----------
    scors = u_AttLabArrToList('Vrt   Hor   Dg1   Dg2   Axi   Adg   Vab   Hab   Dab   Tri   Nil   ')
    
    sfine = u_AttLabArrToList('Vrt   Hor   Vti   Hti   Vob   Hob   Dg2   Dg1   Axi   Uni   Dul   Cvg   Agx   Ori   Nil   Dre   Vir   Fnf   ')
    
    ras = u_AttLabArrToList('Rad   Elo   Ron   Riss  SteUgfSteEngSteDowSteUppOpnDowOpnUpwLigUgfLigEngLigDowLigUppOpnRitOpnLef')
    
    gol     = ['rib', 'ori', 'elo', 'agx']

    LB.Shp  = scors + sfine + ras + gol + lbsGen
    
    # ----------   Ttrg   ----------
    LB.Ttrg = ['Les', 'Elo', 'Wide', 'High', 'Rhom',
               'Pllo', 'Tria', 'Irrg', 'PlHor', 'PlVrt',
               'Ger', 'Wth', 'AxVrt', 'AxHor', 'Axial',
               'Lean1', 'Lean2', 'Neig1', 'Neig2',
               'ori'] + lbPos

    ## ------------   DOUBLES   ---------------
    # we use both Ttg and Ttrg. Annoying.
    #             Bnd and Bndg. Muehsam.
    # for simplicity we simply copy
    LB.Ttg  = LB.Ttrg
    LB.Bnd  = LB.Bndg

    
    return LB



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttIxPos   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

The indices for position for ONE desctype

"""
def o_AttIxPos( IxAtt ):

    Ix    = [ IxAtt.psv, IxAtt.psh ]
    return Ix



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttIxCntGeo   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

The indices for geometric attributes for contours

"""
def o_AttIxCntGeo( IxAtt ):

    Ix    = [ IxAtt.len, IxAtt.str, IxAtt.ori ]
    return Ix



# --------------------------------------------------------------------------------
#
#                                 V E C M X   M A N I P 
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_AngOriToSinCos   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Expands an orientation angle array (-pi to +pi) into sin and cos coordinates for
structural angle distance measurements.

"""
def f_AngOriToSinCos( Ori: np.ndarray ) -> np.ndarray:

    Sin = np.sin(Ori * 2) 
    Cos = np.cos(Ori * 2) 

    return np.column_stack( (Sin, Cos) )



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_VmxXtrPos   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Extracts the position columns from the vector matrix.

"""
def u_VmxXtrPos( VEC, IxAtt ):

    IxPos       = o_AttIxPos( IxAtt )

    Pos         = VEC[ :, IxPos ]

    return Pos



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_VmxOmtPos   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Omit (drop) the position columns from the vector matrix.

"""
def u_VmxOmtPos( VEC, Lab ):

    IxAttNew    = u_AttIxAsFields( Lab )
    
    IxPos       = o_AttIxPos( IxAttNew )
    ixLef       = IxPos[0] 
    ixRit       = IxPos[1] 

    VEC         = np.column_stack( ( VEC[:,:ixLef ], VEC[:, ixRit+1: ] ) )

    LabRed      = Lab[ :ixLef ] + Lab[ ixRit+1: ]

    return VEC, LabRed



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_VmxXtrOriAsSinCos   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Extracts the orientation value as coordinates in sinus and cosinus values.

"""
def u_VmxXtrOriAsSinCos( VEC, IxA ):

    Ori   = VEC[ :, IxA.ori ]
    
    return f_AngOriToSinCos( Ori )



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_VmxExpndOriToCoo   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Expands the orientation column to coordinates and insert it into VEC.
Expands the label array by labels 'sin' and 'cos'.

"""
def u_VmxExpndOriToCoo( VEC: np.ndarray, IxAtt, Lab ) -> tuple[np.ndarray, list[str]]:

    ixOri       = IxAtt.ori
    
    Ori         = VEC[ :, ixOri ]
    
    ORIcoo      = f_AngOriToSinCos( Ori )

    VEC         = np.column_stack( ( VEC[ :, :ixOri ], ORIcoo, VEC[:, ixOri+1: ] ) )

    LabNew      = Lab[ :ixOri ] + lbAngCoo + Lab[ ixOri+1: ]

    return VEC, LabNew    



# --------------------------------------------------------------------------------
#
#                     P R E P   F O R   T R A N S F O R M E R 
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttCntTrfm   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Rerranges contour vectors for transformer:
1) extract position
2) expand ori angle to coordinates
3) drop position

"""
def o_AttCntTrfm( V ):

    LBATT  = o_AttsLabels()
    LabC   = LBATT.Cnt
    
    IxC    = u_AttIxAsFields( LabC )

    #IxPos  = o_AttIxPos( IxC )

    POS    = u_VmxXtrPos( V, IxC )              # 1) extract position

    V, LbR = u_VmxExpndOriToCoo( V, IxC, LabC ) # 2) expand ori to coord

    IxR    = u_AttIxAsFields( LabC )

    V, LbR = u_VmxOmtPos( V, LbR )              # 3) omit position
    
    IxR    = u_AttIxAsFields( LbR )

    return V, POS, LbR, IxR


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttFrmTrfm   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Rerranges form vectors for transformer:
1) extract position
2) drop position

"""
def o_AttFrmTrfm( V ):

    LBATT  = o_AttsLabels()
    LabF   = LBATT.Frm
    
    IxF    = u_AttIxAsFields( LabF )

    POS    = u_VmxXtrPos( V, IxF )              # 1) extract position

    V, LbR = u_VmxOmtPos( V, LabF )              # 2) omit position
    
    IxR    = u_AttIxAsFields( LbR )

    return V, POS, LbR, IxR
