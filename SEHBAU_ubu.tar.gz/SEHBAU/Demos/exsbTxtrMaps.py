"""

Displays texture maps

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy import DescExtr as dscx

Fixt      = sb.Orga.o_FileExtensions()

# ------------------------------   DesxExtr   ------------------------------
imgNa     = 'room.png'
#imgNa     = 'street.jpg'
#imgNa     = 'forest.jpg'

imgNa     = Path( imgNa )
pthImg    = Path( 'Imgs/' ) / imgNa
pthDesc   = Path( 'Desc/' ) / imgNa.stem

cmnd      = [ Path('../DescExtr/dscx'), pthImg, pthDesc, '--saveTxm' ]

# Run descriptor extractor
Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Sts       = Res.returncode
Out       = Res.stdout + Res.stderr

fpDSC     = sb.Orga.o_FinaApndExtDscx( str(pthDesc), Fixt )


# ------------------------------   Load & Retrieve   ------------------------------
SLC, Hed  = dscx.LoadDescSalc( fpDSC.salc )
TXM       = dscx.LoadTxtrMaps( fpDSC.txtm )

BlbLab    = dscx.o_TxtrLabels()

Txa       = SLC.Txa
Blb       = SLC.Blb.Box

# see o_TxtrLabels.m
Bhor    = Blb.Typ==5;       # horizontal
BboxHor = Blb.Box[ Bhor, :];

Bvrt    = Blb.Typ==4;       # vertical
BboxVrt = Blb.Box[ Bvrt, :];

#Bnum   = Blb.Typ == 1          # numerous
#Benk   = Blb.Typ == 8          # high-contrast

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
import imageio.v3 as iio

Irgb   = iio.imread( pthImg )

fig1, axes = plt.subplots(4, 2, num=2, figsize=(10, 8))
axes   = axes.ravel()

ax1    = axes[0]
ax1.imshow(Irgb)
ax1.axis('off')

# Plot bounding boxes
dscx.PlotBboxes.p_BboxL( ax1, BboxHor )                     # default color
dscx.PlotBboxes.p_BboxL( ax1, BboxVrt, rgbOrIx=[1, 0.5, 0])  # orange

ax2  = axes[1]
ax2.imshow(TXM.KNT.Num)
ax2.axis('off')
ax2.set_title('Num')

ax3  = axes[2]
ax3.imshow(TXM.KNT.Blk)
ax3.axis('off')
ax3.set_title('Blank')

ax4  = axes[3]
ax4.imshow(TXM.OTX['Hor'])
ax4.axis('off')
ax4.set_title('Hor')

ax5  = axes[4]
ax5.imshow(TXM.OTX['Vrt'])
ax5.axis('off')
ax5.set_title('Vrt')

ax6  = axes[5]
ax6.imshow(TXM.OTX['Axi'])
ax6.axis('off')
ax6.set_title('Axi')

ax7  = axes[6]
ax7.imshow(TXM.OTX['Nil'])
ax7.axis('off')
ax7.set_title('Nil')

plt.show(block=False)
plt.pause(2)
#plt.show()
