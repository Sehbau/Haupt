%
% An example for a road scene. af exsbPlotShape.m
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'Demos'
    
strImg      = 'aachen.png';

fipaImg     = [ PthProg.descExtr 'Imgs/' strImg];         % image path
fipsOut     = [ PthProg.descExtr 'Desc/' strImg(1:end-4)]; % output filestem

% change to window backslash (in case we are on windows)
if ispc
    fipaImg  = u_PathToBackSlash( fipaImg ); 
    fipsOut  = u_PathToBackSlash( fipsOut ); 
end

%% --------   Options   --------
OptK            = o_DscxArgs();
OptK.nLev       = 3 ;
OptK.depth      = 3 ;
OptK.saveRegPix = 1 ;    
OptK.saveBonPix = 1 ;
optS            = i_DscxArgs(OptK);

%% =========   Command   ========
cmnd        = [ FipaExe.dscx ' ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd    = u_PathToBackSlash( cmnd );
end

[Sts Out]   = system(cmnd);      

v_CmndExec( Sts, Out, cmnd, 1 );

%% -------   Load Region Pixels   -------
Fixt                = o_FileExtensions();

[AREG KtReg]        = LoadRegPix(   [fipsOut Fixt.regPix] );
[DSC Kt Hed]        = LoadDescImag( [fipsOut Fixt.dsc] );    
[ABON Nbon SzM AOrg] = LoadBonPixSpc( [fipsOut Fixt.bonPix] );    

%% ---------------    Plot    -------------------
hf = figure(1); clf; imagesc( imread(fipaImg) );

hf = figure(2); clf; set(hf, 'name', 'shape'); 
for lev = 1:Kt.nLev

    % --- retrieve:
    SHP         = DSC.ASHP{lev};         % extracting one level
    SHP.LabScors = DSC.LabShpScors;
    SHP.LabSfine = DSC.LabShpSfine;
    ABonPix     = ABON{lev};
    ARegPix     = AREG(lev,:);
    Org         = AOrg{lev};

    szM         = SzM(lev,:);

    % --- plot boundaries on LEFT
    subplot(3, 2, lev*2-1); hold on;
    set(gca,'fontsize',8);
    
    IxAxiBon = p_ShpAxial( SHP, ABonPix );        % *** plot ***
    
    axis ij;
    set(gca,'xlim',[1 szM(2)]);
    set(gca,'ylim',[1 szM(1)]);
    ylabel(['Lev ' num2str(lev)] );
    
    % --- create maps on RITE
    Mp      = u_RegPixToMap( ARegPix, Org, IxAxiBon, szM );

    subplot(3, 2, lev*2);
    imagesc(  Mp' );
    set(gca,'fontsize',8);
    
end

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2Jpeg( [dirFigs 'RoadScene'], 2 );
end

