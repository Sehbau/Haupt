%
% Saving and plotting of contour endpoints.
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'Demos'
    
strImg      = 'aachen.png';

fipaImg     = [ 'Imgs/' strImg];         % image path
fipsOut     = [ 'Desc/' strImg(1:end-4)]; % output filestem

% change to window backslash (in case we are on windows)
if ispc
    fipaImg  = u_PathToBackSlash( fipaImg ); 
    fipsOut  = u_PathToBackSlash( fipsOut ); 
end

%% --------   Options   --------
OptK            = o_DscxArgs();
OptK.nLev       = 6 ;
OptK.saveCuvKpt = 1 ;               % ****  needs to be ON  ****
optS            = i_DscxArgs(OptK);

%% =========   Command   ========
cmnd        = [ FipaExe.dscx ' ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd    = u_PathToBackSlash( cmnd );
    [Sts Out] = dos(cmnd);      % excecute program for windows
elseif isunix
    [Sts Out] = unix(cmnd);     % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 );

%% -------   Load Region Pixels   -------
Fixt            = o_FileExtensions();
fpDSC           = o_FinaApndExtDscx( fipsOut, Fixt );

Irgb         	= imread( fipaImg );
[CNT Ncnt]      = LoadCntUnvKpt( fpDSC.cuvKpt );

%% ------    Plot    ---------
figNo           = 2;
typImgSpc       = 1;
PlotCntUnvKpt( CNT, Irgb, typImgSpc, figNo );


%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2File( [dirFigs 'CntUnvKpt'], 1, 1, figNo );
    %PrintFig2Jpeg( [dirFigs 'CntSpcEptRRE'], figNo );
end
