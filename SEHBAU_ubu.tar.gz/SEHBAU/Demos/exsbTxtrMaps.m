% 
% Displays texture maps.
% 
clear;
run('../AdminMb/globalsSB');        

%% =========   Execute Dscx   ========
fipaImg  = 'Imgs/street.jpg';  fipsOut  = 'Desc/street'; sidf='street';
%fipaImg  = 'Imgs/forest.jpg';  fipsOut  = 'Desc/forest'; sidf='forest';
%fipaImg  = 'Imgs/birds.jpg';  fipsOut  = 'Desc/birds'; sidf='birds';
%fipaImg  = 'Imgs/aachen.png';  fipsOut  = 'Desc/aachen'; sidf='aachen';

optS    = '--saveTxm';
%optS    = '--saveTxm --cntMinCtr 0.02'; % for aachen

cmnd    = ['../DescExtr/dscx ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd        = u_PathToBackSlash( cmnd );
    [Sts Out]   = dos(cmnd);    % excecute program for windows
elseif isunix
    [Sts Out]   = unix(cmnd);   % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 ); % verify output

%% -------------   Load    ---------------
% better use o_FileExtensions!
TXM             = LoadTxtrMaps( [fipsOut '.txm'] ); 
[SLC HedSlc]    = LoadDescSalc( [fipsOut '.slc'] ); 

Irgb            = imread( fipaImg );

%% -------------   Retrieve Texturegrams, BlobBboxes   -------------
aLbBlob         = o_BlobLabels();
aLbTxtg         = aLbBlob(1:7);

SLC.Txa.Grm     = u_TxtrGramRtrv( SLC.Txa.Grm, HedSlc.szG, aLbTxtg );

L2LSclFct       = f_LevToLaySclFct( HedSlc.szI, HedSlc.szL );
SBbxOrg         = u_BlobBbxRtrv( SLC.Txa.Blb, aLbBlob );
SBbxLay         = u_BlobBbxRtrv( SLC.Txa.Blb, aLbBlob, L2LSclFct );

%% -------------   Plot Maps   -------------
figWoutBx   = 2;
PlotTxtrMaps( TXM, figWoutBx, Irgb );

figWithBx   = 3;
PlotTxtrMaps( TXM, figWithBx, Irgb, SBbxLay );
subplot(3,3,1);
p_BboxL( SBbxOrg.Hor );
p_BboxL( SBbxOrg.Vrt );


%% -------------   Plot Texturegrams   -------------
figGrams    = 6 ;
PlotTxtrGrams( TXM, SLC.Txa.Grm, figGrams, Irgb, aLbTxtg );

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2Jpeg( [dirFigs 'TxtrMaps_' sidf], figWithBx );
    PrintFig2Jpeg( [dirFigs 'TxtrGrms_' sidf], figGrams );
end

if 0
    figNumOnly  = 4;
    PlotTxtrMap1( TXM.KNT.Num, figNumOnly, Irgb, 'Num' );
    PrintFig2Jpeg( [dirFigs 'TxtrMaps_' sidf '_Num'], figNumOnly );
end



