"""

Displays shapes. Not finished yet.

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy import DescExtr as dscx

Fixt      = sb.Orga.o_FileExtensions()

# ------------------------------   DesxExtr   ------------------------------
imgNa     = 'aachen.png'

imgNa     = Path( imgNa )
pthImg    = Path( 'Imgs/' ) / imgNa
pthDesc   = Path( 'Desc/' ) / imgNa.stem

# ------------------------------   Options   ------------------------------
OptK            = dscx.dclsDscxArgs()
OptK.nLev       = 3 
OptK.depth      = 3 
OptK.saveRegUnv = 1     
OptK.saveBonSpc = 1 
optS            = dscx.i_DscxArgs(OptK)

cmnd      = str(Path('../DescExtr/dscx ')) + str(pthImg) + ' ' + str(pthDesc) + ' ' + optS

# Run descriptor extractor
Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Sts       = Res.returncode
Out       = Res.stdout + Res.stderr

fpDSC     = sb.Orga.o_FinaApndExtDscx( str(pthDesc), Fixt() )


# ------------------------------   Load & Retrieve   ------------------------------
# not impl yet [AREG KtReg]        = LoadRegUnv(   fpDSC.ruv );
# not impl yet [ABON Nbon SzM AOrg] = LoadBonPixSpc( fpDSC.bspx );    

DSC, Hed   = dscx.LoadDescUniv( fpDSC.dsc );    
SLC, Hed   = dscx.LoadDescSalc( fpDSC.salc )

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
import imageio.v3 as iio

Irgb   = iio.imread( pthImg )

fig1, axes = plt.subplots(4, 2, num=2, figsize=(10, 8))
axes   = axes.ravel()

ax1    = axes[0]
ax1.imshow(Irgb)
ax1.axis('off')

