% 
% Displays shape-based proposals. .qbox, .qdsc
% 
clear;
run('../globalsSB');        

%% =========   Execute Dscx   ========
pthImg  = 'Imgs/room.png';  pthOut  = 'Desc/room';

optS    = '--saveProp';        % save as one file
%optS    = '--ssepProp';         % save as separate files

cmnd    = ['../DescExtr/dscx ' pthImg ' ' pthOut ' ' optS];

if ispc
    cmnd        = u_PathToBackSlash( cmnd );
    [Sts Out]   = dos(cmnd);    % excecute program for windows
elseif isunix
    [Sts Out]   = unix(cmnd);   % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 ); % verify output

%% ----------   Load    ---------
Fixt        = o_FileExtensions();

% ---- bounding boxes
if strcmp(optS, '--saveProp')
    [BBx Nr]    = LoadDescPropBbox( [pthOut Fixt.qbbx] );
else
    [BBx.ShpGen Nr.shpGen] = LoadBboxL( [pthOut Fixt.qbbx 'Shp'] );
    [BBx.TtgGen Nr.ttgGen] = LoadBboxL( [pthOut Fixt.qbbx 'Ttg'] );
    [BBx.ShpVrt Nr.shpVrt] = LoadBboxL( [pthOut Fixt.qbbx 'AxVrt'] );
    [BBx.ShpHor Nr.shpHor] = LoadBboxL( [pthOut Fixt.qbbx 'AxHor'] );
end

% ---- descriptor attributes
[QDSC] 	= LoadDescPropAtts( [pthOut Fixt.qdsc] ); 
DispLoad( [pthOut Fixt.qdsc] );

Irgb   	= imread( pthImg );

%% -------------   Plot Maps   -------------
figure(1); clf;
[nr nc] = deal(2,2);

subplot(nr,nc,1); 
imagesc( Irgb); hold on;
p_BboxL( BBx.ShpGen, 3 );
imglabN('ShpGen', Nr.shpGen );

subplot(nr,nc,2); 
imagesc( Irgb); hold on;
p_BboxL( BBx.TtgGen, 3 );
imglabN('TtgGen', Nr.ttgGen );

subplot(nr,nc,3); 
imagesc( Irgb); hold on;
p_BboxL( BBx.ShpVrt, 4 );
imglabN('ShpVrt', Nr.shpVrt );

subplot(nr,nc,4); 
imagesc( Irgb); hold on;
p_BboxL( BBx.ShpHor, 4 );
imglabN('ShpHor', Nr.shpHor );



