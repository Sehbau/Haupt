"""

  Texture matching, with a collection bank using executable mtxtc.

  Run first the script plcDscx.m to extract the descriptors.

  PREVIOUS  plcCollTxtg.m
  CURRENT   plcMtcTxtColl.m, sa plcMtcTxtIdv.m
  NEXT

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')
import numpy as np

import AdminPy as sb

# -----  paths  -----
pthOpr      = Path.cwd()
DirNames    = sb.Orga.o_DirNames()
Pths        = sb.Orga.o_DirsPrependPath( DirNames, pthOpr )

## -----  register  -----
RgstFinas   = sb.Collection.o_RegistFileNames()
RgstFipas   = sb.Orga.o_DirsPrependPath( RgstFinas, Pths.rgst )

IxImg       = [0, 1, 2, 3, 6]

sb.Collection.v_RegistValid( RgstFipas.slc )

aFpSlc, nLin  = sb.Util.LoadTextLinewise( RgstFipas.slc )
fp1st       = Path( aFpSlc[0] )

## ====================   MTCHTXT   ======================
FixtColl    = sb.Orga.o_FileExtensColl();
FinaColl    = sb.Orga.o_FileNameColl( Pths.coll, FixtColl )

# ---- for simplicity we match only 1-versus-all
#print('MTCHTXT\n');
fidfTxt     = 'Txtr';
PthM        = sb.Mtch.OrgFile.o_FileNameMtxtc( 1, fidfTxt )

#Wgt         = o_WgtTxtrMtch();

cmndBnd     = [ Path( sb.FipaExe['mtxtc'] ), fp1st, FinaColl.txgb ]
cmndGrd     = [ Path( sb.FipaExe['mtxtc'] ), fp1st, FinaColl.txgg ]

ResBnd      = subprocess.run( cmndBnd, shell=True, capture_output=True, text=True )
ResGrd      = subprocess.run( cmndGrd, shell=True, capture_output=True, text=True )

sb.Util.v_CmndExec( ResBnd )
sb.Util.v_CmndExec( ResGrd )

Mes         = sb.MtchVec.LoadMeasMtxtc( PthM )

DisTot      = Mes.Grd + Mes.Bnd;    # combine to total

# ------------------------------   Plot results   ------------------------------
import matplotlib.pyplot as plt

xLabs = ['0-1', '0-2', '0-3', '0-6', '1-6']
nComb = len( xLabs )

fig, axs = plt.subplots(2, 2, figsize=(10, 6))
xax  = range(nComb)

axs[0, 0].bar(xax, Mes.Grd )
axs[0, 0].set_xticks(xax)
axs[0, 0].set_xticklabels(xLabs)
axs[0, 0].set_title('distance grid')

axs[0, 1].bar(xax, Mes.Bnd )
axs[0, 1].set_xticks(xax)
axs[0, 1].set_xticklabels(xLabs)
axs[0, 1].set_title('distance band')

axs[1, 1].bar(xax, DisTot )
axs[1, 1].set_xticks(xax)
axs[1, 1].set_xticklabels(xLabs)
axs[1, 1].set_title('distance total')

plt.figure(1)
plt.tight_layout()
plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)

