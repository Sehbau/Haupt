%
% Matching zone-wise for both vectors and histograms using binaries for
% lists. As opposed to plcMtcZon1o1.m, we do not rely on the spatial
% arrangement, but assume that we need to find it. We therefore match the
% focii pairwise (for a pair of images) and analyse the distance matrix.
%
% Run first the script plcFocZon.m to extract the descriptors.
%
% PREVIOUS   plcFocZon.m
% CURRENT    plcMtcZonLst.m, sa plcMtcZon1o1.m
%
clear;
run('../globalsSB');

dirImg      = 'Imgs/';
dirDsc      = 'Desc/';          
dirFoc      = 'Focii/';
dirRegist   = 'Regist/';
finaMesHst  = 'Mes/HstUor.txt';
finaMesVec  = 'Mes/Vec.txt';
idfFoc      = 'Zon';

currDir     = pwd;
pthaFoc     = [ currDir '/' dirFoc ];
pthaRgst    = [ currDir '/' dirRegist ];

%% -----  Generate Register Files  -----
% For each image, we collect the focus filenames
aImg        = dir([dirImg '*.jpg']);
nImg        = length(aImg);
aImgNames   = cell(nImg,1);
for i = 1 : nImg
    aImgNames{i} = [aImg(i).name(1:end-4) idfFoc];
end
neLev       = 5;
aRgstHst    = SaveRegistFoc( pthaFoc, aImgNames, pthaRgst, 'hsf1', 0 );
aRgstVec    = SaveRegistFoc( pthaFoc, aImgNames, pthaRgst, 'vec', neLev );

%% ==========   Zone Matching   ==========
% the image comparisons
Comp(1,:) = [1 1];          % self
Comp(2,:) = [1 2];          % most similar      
Comp(3,:) = [1 3];          
Comp(4,:) = [1 4];          
Comp(5,:) = [1 5];          % least similar
Comp(6,:) = [2 5];
nComp     = size(Comp,1);   % number of comparisons

% loads parameter nZon (saved last line in plcDscxZon.m)
load('Prm');                

DisHstNN    = zeros(nComp,nZon,'single');
DisVecNN    = zeros(nComp,nZon,'single');
SimVecNN    = zeros(nComp,nZon,'single');

for c = 1:nComp

    % the image pair
    ix1     = Comp(c,1);
    ix2     = Comp(c,2);

    aFocHst = LoadTextLineWise( aRgstHst{ix1} );
    aFocVec = LoadTextLineWise( aRgstVec{ix1,5} );
    nFoc1   = length( aFocHst );
    %aFocHst{:}
    
    fpRgst2hst = aRgstHst{ix2};
    fpRgst2vec = aRgstVec{ix2,5};
    aDmy    = LoadTextLineWise( fpRgst2hst );
    nFoc2   = length(aDmy);     % we pretend NOT to know the number of focii
    % aDmy{:}
    
    % --- nFoc1 vs nFoc2 ---
    DMhst   = zeros(nFoc1, nFoc2, 'single');
    DMvec   = zeros(nFoc1, nFoc2, 'single');
    SMvec   = zeros(nFoc1, nFoc2, 'single');
    for f = 1:nFoc1
        
        % ==========   Histograms   ==========
        hsf1    = aFocHst{f};
        cmnd    = [ FipaExe.mhstL ' ' hsf1 ' ' fpRgst2hst ];
        [sts OutHst] = system(cmnd);
        v_CmndExec( sts, OutHst, cmnd );
        %OutHst
        
        DMhst(f,:) = LoadFltTxt( finaMesHst, nFoc2 );

        % ==========   Vectors   ==========
        dsc1    = aFocVec{f};
        cmnd    = [ FipaExe.mvecL ' ' dsc1 ' ' fpRgst2vec ];
        [sts OutVec] = system(cmnd);
        v_CmndExec( sts, OutVec, cmnd );
        
        MtcFoc  = LoadMtchMes( finaMesVec, nFoc2 );

        % focus-to-focus 
        DMvec(f,:) = MtcFoc(:,1);
        SMvec(f,:) = MtcFoc(:,2);
    
    end
    
    figure(10); 
    subplot(2,2,1); imagesc(DMhst); title('Hist'); colorbar;
    subplot(2,2,2); imagesc(DMvec); title('Vec Dist'); colorbar;
    subplot(2,2,3); imagesc(SMvec); title('Vec Simi'); colorbar;
    pause(.1);

    % --- focus nearest neibor measure ---
    DisHstNN(c,:) = min( DMhst, [], 2);
    DisVecNN(c,:) = min( DMvec, [], 2);
    SimVecNN(c,:) = max( SMvec, [], 2);

end

%% -----   Image Measure   -----
DisSumHst   = sum(DisHstNN,2);

DisMul      = prod(DisVecNN,2);
SmlMul      = prod(SimVecNN,2);
DisSum      = sum(DisVecNN,2);
SmlSum      = sum(SimVecNN,2);

%% -----   Plot Results   -----
figure(6); clf;
[nr nc] = deal(3,2);
xLab = {'0-0' '0-1' '0-2' '0-3' '0-6' '1-6'};

subplot(nr,nc,1);
bar(DisMul);
set(gca, 'xticklabel', xLab);
title('dist. mult.');

subplot(nr,nc,2);
bar(log(SmlMul));
set(gca, 'xticklabel', xLab);
ylabel('log simi mult');
title('simi. mult.');

subplot(nr,nc,3);
bar(DisSum);
set(gca, 'xticklabel', xLab);
title('dist. summed');

subplot(nr,nc,4);
bar(log(SmlSum));
set(gca, 'xticklabel', xLab);
ylabel('log simi sumd');
title('simi. summed');

subplot(nr,nc,5);
bar(DisSumHst);
set(gca, 'xticklabel', xLab);
title('distance hist');



