"""

The equivalent of plcAll.m. 

"""

import os

os.system('python plcDscx.py')

## -----   Whole Image   -----
os.system('python plcMtcImg.py')
os.system('python plcMtcHstKol.py')

os.system('python plcCollTxtg.py')
os.system('python plcMtcTxtColl.py')

os.system('python plcDtop.py')
os.system('python plcDtopMtch.py')

os.system('python plcCascIdf.py')

#os.system('python plcCorrSelf.py')   # does not exist yet

os.system('python plcDproc.py')       
os.system('python plcTransformerHspa.py')       

os.system('python plcCollVec.py')   # collects the vector matrices
os.system('python plcDeepSetOne.py')       
os.system('python plcDeepSetTwo.py')       
os.system('python plcTransformerDscs.py')       


## -----   Focii using Zones   -----
os.system('python plcFocZon.py')
#os.system('python plcMtcZon1o1.py') # does not exist
os.system('python plcMtcZonLst.py')


## -----   Focii using Proposals   -----
os.system('python plcFocProp.py')
os.system('python plcMtcProp.py')


## -----   ShapeExtraction using ShapeProposals   -----
os.system('python plcShpExtr.py')
os.system('python plcMtcShp.py')  


## -----   Ego Motion   -----
os.system('python plcMotEgo.py')


print('Demo Place Recognition Completed')



