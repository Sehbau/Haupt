%
% Matching focus-wise for both vectors and histograms using binaries for
% lists. 
%
% PREVIOUS   plcShpExtr.m
% CURRENT    plcMtcShp.m
%
% af plcMtcProp.m
%
clear;
run('../AdminMb/globalsSB');

dirImg      = 'Imgs/';
dirShps     = 'Shps/';

%% -----  Generate Register Files  -----
aImgNames   = u_DirWotExt( [dirImg '*.jpg'] );

%% -----  params  ----
Prm         = [];
%Prm.TolSpcng    = [0.3 0.3];
%Prm.minMtcBox   = 0.1;
%Prm.minCong     = 0.2;

%% -----  admin  -----
Admin.fpProg    = FipaExe.mshp1;
Admin.dirShps   = dirShps;

%% ==========   The Combinations   ==========
% the image comparisons
Comp(1,:) = [1 1];          % self
Comp(2,:) = [1 2];          % most similar      
Comp(3,:) = [1 3];          
Comp(4,:) = [1 4];          
Comp(5,:) = [1 5];          % least similar
Comp(6,:) = [2 5];
nComp     = size(Comp,1);   % number of comparisons

MesImg  	= zeros(nComp,1,'single');
DisMul      = MesImg;
DisMen      = MesImg;
for c = 1:nComp

    % the image pair
    ix1     = Comp(c,1);
    ix2     = Comp(c,2);
    fprintf('-------------------------  %d-%d  --------------------\n', ...
        ix1, ix2 );

    imgNa1  = aImgNames{ix1};
    imgNa2  = aImgNames{ix2};

    aShps1  = dir( [dirShps imgNa1 '*.shp'] );
    aShps2  = dir( [dirShps imgNa2 '*.shp'] );

    bDISP = 1;
    [Mes MS]  = MSHPTOSHP( aShps1, aShps2, Prm, Admin, bDISP );
    fprintf('done\n');

    %% -----  Plotting  -----
    figure(10); 
    subplot(2,2,1); imagesc(MS.DM); title('Shp'); colorbar;
    subplot(2,2,2); bar(Mes.MxVec); title('Mx Vec'); colorbar;
    subplot(2,2,3); bar(Mes.MxRts); title('Mx Rts'); colorbar;
    subplot(2,2,4); bar(Mes.MxSpk); title('Mx Spk'); colorbar;
    pause(.1);

    % =====  Image Measures  =====
    DisMul(c) = Mes.disVecMul;
    DisMen(c) = Mes.disVecMen;

end


%% -----   Plot Results   -----
hf = figure(8); clf; set(hf, 'name', 'Proposals'); 
[nr nc] = deal(3,2);
xLab = {'0-0' '0-1' '0-2' '0-3' '0-6' '1-6'};

subplot(nr,nc,1);
bar(DisMul);
set(gca, 'xticklabel', xLab);
title('dist. mult.');

subplot(nr,nc,3);
bar(DisMen);
set(gca, 'xticklabel', xLab);
title('dist. avgd');





