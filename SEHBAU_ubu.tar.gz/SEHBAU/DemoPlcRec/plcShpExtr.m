%
% Patch and shape extraction using bounding boxes from proposals (.slc,
% .qprp).
%
% Run first the script plcDscx.m to extract the descriptors.
%
% af plcFocProp.m
%
% PREVIOUS  plcDscx.m
% CURRENT   plcShpExtr.m
% NEXT      plcShpMtch.m
%
clear;
run('../AdminMb/globalsSB.m'); 

% selection bboxes
Prm.minHgt      = 16;
Prm.minWth      = 16;

dirImg      = 'Imgs/';
dirDsc      = 'Desc/';
dirPtch     = 'Ptch/';
dirShps     = 'Shps/';

delete( [dirPtch '*'] );             % remove previous patches
delete( [dirShps '*'] );             % remove previous shape files

if ispc
    %dirDsc  = u_PathToBackSlash( dirDsc ); % not necessary I think
    dirPtch  = u_PathToBackSlash( dirPtch ); 
end

Fext    	= o_FileExtensions();
fipaBbx     = 'BboxPtchs.txt';          % same name for all images 
ppthPtchx   = FipaExe.ptchxL;
ppthShpx    = FipaExe.shpx;

%% -----  List of Images  -----
[aImgNam nImg]  = u_DirWotExt( [dirDsc '*.dsc'] );

if nImg==0
    fprintf('No images found.'); return;
end

%% ----------   Shape Extraction Per Image  -----------
for i = 1:nImg
    
    imgNam  = aImgNam{i};

    % -------------------  LOAD  ----------------------
    fpSal   = [dirDsc imgNam Fext.slc ];
    fpPrp   = [dirDsc imgNam Fext.qbbx];
    fpDsc   = [dirDsc imgNam Fext.qdsc];

    % --- load saliency and proposals
    [SLC]           = LoadDescSalc( fpSal );
    [QBbx Nr]       = LoadDescPropBbox( fpPrp );
    [QDsc]          = LoadDescPropAtts( fpDsc );

    % -------------------  BBOXES  ----------------------
    % --- we choose general shapes from the proposal file
    BbxSel      = QBbx.ShpGen;
    RGBchn      = QDsc.ShpGen.RGB;
    RGBSel      = [RGBchn.Red RGBchn.Grn RGBchn.Blu];
    nBbx        = size(BbxSel,1);

    % -------------------  Selection  ----------------------
    % --- take all OR select based on size (if desired)
    if 0
        IxLrg       = 1:nBbx;                       % take all
    else
        % identify the large ones 
        BxHgt       = BbxSel(:,2) - BbxSel(:,1);    % box height
        BxWth       = BbxSel(:,4) - BbxSel(:,3);    % box width
        IxLrg       = find( BxHgt>Prm.minHgt & BxWth>Prm.minWth );  
    end
    nLrg        = length(IxLrg);
    fprintf('Selected %d props [%1.2f]\n', nLrg, nLrg/nBbx);

    % --- subselect using IxLrg
    BbxSel      = BbxSel(IxLrg,:);
    RGBSel      = RGBSel(IxLrg,:);
    
    SaveBboxL( fipaBbx, BbxSel );      % save bounding boxes
    
    % -------------------  PATCHEXTR  ----------------------
    % Patches will be overwritten from image to image.
    % ---------   create command   ----------
    fipaImg     = [dirImg imgNam '.jpg'];
    fistOut     = 'P';
    cmnd        = [ppthPtchx ' ' fipaImg ' ' fipaBbx ' ' dirPtch fistOut];
    if ispc
        cmnd  = u_PathToBackSlash( cmnd );
    end
    % ---------   execute command   ----------
    [sts, Out]  = system( cmnd );
    v_CmndExec( sts, Out, cmnd, 1 );

    % -------------------  SHAPEEXTR  ----------------------
    Nbon = zeros(nLrg,1,'int32');
    Ncrv = zeros(nLrg,1,'int32');
    for s = 1:nLrg
        
        fipaPtch1   = [dirPtch 'P' num2str(s-1) '.png'];
        
        % ---------   create rgb triplet   ----------
        % rgb triplet is in unit range, therefore upscale to 255 (uint8)
        rgbVls      = uint8( RGBSel(s,:) * 255 );
        strRgb      = sprintf('%d %d %d', rgbVls(1), rgbVls(2), rgbVls(3) );
        
        % ---------   create command   ----------
        fipsShp     = [dirShps imgNam '_S' num2str(s-1)];
        cmnd        = [ppthShpx ' ' fipaPtch1 ' ' strRgb ' ' fipsShp ];
        if ispc
            cmnd  = u_PathToBackSlash( cmnd );
        end
        % ---------   execute command   ----------
        [sts, Out]  = system( cmnd );
        v_CmndExec( sts, Out, cmnd, 1 );     
        
        % ---------   parse output   ----------
        ShpDet      = pso_Shpx( Out );
        Nbon(s)     = ShpDet.nBon;
        Ncrv(s)     = ShpDet.nCrv;

    end
    
    fprintf('Stats for img %d:\n', i);
    fprintf('\t# bons min-max    %2d-%3d\n', min(Nbon), max(Nbon) );
    fprintf('\t# crvs min-max    %2d-%3d\n', min(Ncrv), max(Ncrv) );
    fprintf('\t# zero bons/crvs  %2d/%2d\n', nnz(Nbon==0), nnz(Ncrv==0) );
    
end

fprintf('plcShpExtr fertig.\n');




