"""

Descriptor extraction for place recognition demo with zones.

More details in plcFocZon.m

"""
import sys, subprocess
import imageio.v3 as iio
from pathlib import Path
sys.path.insert(0, '..')
import AdminPy as sb

dirImg      = Path( 'Imgs/' )
dirDsc      = Path( 'Desc/' )
dirFoc      = Path( 'Focii/' )

sb.Util.del_FilesDirPat( dirFoc, '*' )
    
# --- List of image files
aImg        = list( dirImg.glob( '*.jpg' ) )

Irgb        = iio.imread( aImg[0] )

# --- Zones
szI         = Irgb.shape[0:2]
ZonesAll    = sb.FocSel.u_ZonesBboxes( szI )    # a collection of zone partitions
ZonesSel    = ZonesAll['Sep3']['Vert']          # we choose one set of partitions
nZon        = ZonesSel.nZon

fpFocDsc1   = sb.FipaExe['focdsc1']             # file path of program binary
fpFocHst1   = sb.FipaExe['fochst1']

## ----------   Zones (Focus) Extraction Per Image  -----------
for pthImg in aImg:

    imgName = pthImg.stem                       # remove .jpg extension
    
    fpDsc    = dirDsc / Path( imgName + '.dsc' )

    for f in range(nZon):
    
        Bbx    = ZonesSel.Bbox[f,:]
        top    = str(Bbx[0])
        bot    = str(Bbx[1])
        lef    = str(Bbx[2])
        rit    = str(Bbx[3])
 
        fpOut  = dirFoc / Path( imgName + f"_F{f}" )

        # -----  Vectors:
        cmnd   = [ fpFocDsc1, fpDsc, top, bot, lef, rit, fpOut ] 

        Res    = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
        sb.Util.v_CmndExec( Res )

        # -----  Histograms:
        cmnd   = [ fpFocHst1, fpDsc, top, bot, lef, rit, fpOut ] 

        Res    = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
        sb.Util.v_CmndExec( Res )

    sb.Util.printDotProg()

        
# ----------   Save Prms   ----------
from scipy.io import savemat
savemat( 'Prm.mat', {'nZon': nZon} ) 

print('plcFocZon fertig.')
