"""

Matching top descriptions, all-against-all

More details in plcDtopMtch.m

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')
import numpy as np

import AdminPy as sb

# -----  paths  -----
pthOpr      = Path.cwd()
DirNames    = sb.Orga.o_DirNames()
Pths        = sb.Orga.o_DirsPrependPath( DirNames, pthOpr )
prmMtcTyp   = ""

IxImg       = [0, 1, 2, 3, 6]
nImg        = len(IxImg)

## -----  registers  -----
Fixt        = sb.Orga.o_FileExtensions()   
RgstFinas   = sb.Collection.o_RegistFileNames();
RgstFipas   = sb.Orga.o_DirsPrependPath( RgstFinas, Pths.rgst )

RgstTop     = sb.Collection.o_RegistSetSaveDtop( RgstFipas, Pths.dtop, '', IxImg, Fixt, 7 );   

fipaMvec    = Path( sb.FipaExe['mvecL'] )  # filepath of program binary mvecL

aDtop       = list( Path(DirNames.dtop).glob( '*' + Fixt.dtop ) )

fpMesDtop   = 'Mes/Vec.txt'


# Initialize measurement arrays
DM     = np.zeros((nImg, nImg), dtype=np.float32)
SM     = np.zeros((nImg, nImg), dtype=np.float32)
c=0
for i in range(0,nImg):

    fipaDtop  = aDtop[i] 
    
    cmnd    = [ fipaMvec, fipaDtop, RgstFipas.dtop ]

    Res     = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    OutMtc  = Res.stdout + Res.stderr

    # Analyze output
    MesTot = sb.MtchVec.FileRead.LoadMtchMes( fpMesDtop, nImg )

    DM[i,:] = MesTot[:,0]
    SM[i,:] = MesTot[:,1]

# ------------------------------   Plot Results   ------------------------------
import matplotlib.pyplot as plt

#plt.imshow(DM, aspect='auto')
#plt.colorbar()
#plt.show()

fig, axs = plt.subplots(1, 2, figsize=(10, 6))

axs[0].imshow( DM )
axs[0].set_title('distances')

axs[1].imshow( SM )
axs[1].set_title('similarity')

plt.figure(1)
plt.tight_layout()
plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)
