"""

Runs only the network examples

"""

import os

bDscXtr = 1

if bDscXtr:
    os.system('python plcDscx.py')
    os.system('python plcDproc.py')       

os.system('python plcTransformerHspa.py')       

if bDscXtr:
    os.system('python plcCollVec.py')   # collects the vector matrices

os.system('python plcDeepSetOne.py')       
os.system('python plcDeepSetTwo.py')       
os.system('python plcTransformerDscs.py')       

print('Demo Nets Completed')



