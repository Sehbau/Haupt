%
% Histogram generation for zones (focii) with program fochstL taking a list
% of bounding boxes as input. 


% IN DEVELOPMENT


%
% PREVIOUS  plcDscx.m
% CURRENT   plcFocZonHst.m
% NEXT      plcMtcZonHst.m
%
clear;
run('../globalsSB');

dirImg      = 'Imgs/';
dirDsc      = 'Desc/';             
dirFoc      = 'Focii/';

% change to window backslash
if ispc
    dirDsc      = u_PathToBackSlash( dirDsc ); 
    dirFoc      = u_PathToBackSlash( dirFoc ); 
end

%% -----  List of Images  -----
aImg        = dir( [dirImg '*.jpg'] );
nImg        = length(aImg);
% obtain image size
Irgb        = imread([dirImg aImg(1).name]);
szI         = size(Irgb);

%% -----  Generate Zones Bboxes  -----
ZonesAll    = u_ZonesBboxes(szI, 0);
%Bboxes     = Zones.HorzOla;
ZonesSel    = ZonesAll.Sep3.Vert;

finaBbx     = 'BboxZones.txt';
SaveBboxL( finaBbx, ZonesSel.Bbox );

%% ----------   Focus Extraction Per Image  -----------
nZon    = ZonesSel.nZon;
optS    = '';
for i = 1:nImg
    
    imgNam  = aImg(i).name(1:end-4);
    fpDsc 	= [dirDsc imgNam '.dsc']; % description filename 
    fpHst   = [dirFoc imgNam '_FH'];
     
    cmnd   	= [ FipaExe.fochstL ' ' fpDsc ' ' finaBbx ' ' fpHst];
    [sts Out] = system(cmnd);      % excecute program
    
    v_CmndExec( sts, Out, cmnd, 1 );

    fprintf('.');
    
end

% we need to inform plcMtcZon.m how many zones were run:
save('PrmHst','nZon'); 
fprintf('fertig.');





