"""

Mock example for setting up descriptor vector matrices for a DeepSet network, for
TWO descriptor types.

"""
import sys, subprocess, os, glob
import numpy as np
from pathlib import Path

import torch
from torch.utils.data import Dataset, DataLoader

import warnings
# Suppress the specific PyTorch nested tensor user warning
warnings.filterwarnings("ignore", message=".*enable_nested_tensor is True.*")

sys.path.insert(0, '..')

import AdminPy as sb
import AdminPy.Networks.DeepSet as sbDs

# -----  paths  -----
pthOpr      = Path.cwd()
DirNames    = sb.Orga.o_DirNames()
Pths        = sb.Orga.o_DirsPrependPath( DirNames, pthOpr )

# ------------------------------   Load   ------------------------------
import AdminPy.Collection as cl
COLLCNT, ntCnt, nAttCnt = cl.LoadCollVec(    Pths.coll, 'skl' )
LabCnt,  ntCnt2         = cl.LoadCollVecLab( Pths.coll, 'skl' )
COLLFRM, ntFrm, nAttFrm = cl.LoadCollVec(    Pths.coll, 'skl' )
LabFrm,  ntFrm2         = cl.LoadCollVecLab( Pths.coll, 'skl' )


# ------------------------------   REFINE VEC   ------------------------------
# iclCollVmxLst.py
COLLCNT, Jatt = sb.DescExtr.o_AttCntOriExpand( COLLCNT )


# ------------------------------   Prep Folds   ------------------------------
# training (trn) and prediction/testing (prd)
IxTrn       = [0,1,2]          
IxPrd       = [3,4]
LbTrn       = np.array( [0,0,1] ) # fake labels training
LbPrd       = np.array( [0,1] )   # fake labels prediction (testing)

# ------------------------   FOLDS & REARRANGE TO LIST   ---------------------------
u_CollVecSel         = cl.u_CollMLtoLstSel
ACNTTRN, ALabCntTrn  = u_CollVecSel( COLLCNT, LabCnt, IxTrn )
ACNTPRD, ALabCntPrd  = u_CollVecSel( COLLCNT, LabCnt, IxPrd )
AFRMTRN, ALabFrmTrn  = u_CollVecSel( COLLFRM, LabFrm, IxTrn )
AFRMPRD, ALabFrmPrd  = u_CollVecSel( COLLFRM, LabFrm, IxPrd )

# ----------   Parameters DeepSet   ----------
# Architecture:
dimHid     =  64

# Learning:
nEpo       =  100
szBtc      =  8
lrPeak     = 0.0005
gnoisSdv   = 0.001
pDrot      = 0.3
    
stepPlotLoss   = 20
lrMin          = lrPeak * 0.1

# ------------------------------   Model   ------------------------------
nAttCnt   = COLLCNT.shape[1]
nAttFrm   = COLLFRM.shape[1]
nCat      = 2  # fake number of categories
MOD       = sbDs.MOD_DSCTwoClsf( nAttCnt, nAttFrm, dimHid, nCat )

# --------------------------------------------------------------------------------
#                             T R A I N   ( F I T )
# --------------------------------------------------------------------------------
# initialize loader
DSET    = sbDs.dsetVMX2( ACNTTRN, AFRMTRN, LbTrn )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=True, collate_fn = sbDs.colt_VMX2 )

# ------------------------------   Guidance   ------------------------------
criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.AdamW(MOD.parameters(), lr=lrPeak)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR( optimizer, T_max=nEpo, eta_min=lrMin)

# ------------------------------   LOOP   ------------------------------
Loss      = np.zeros(nEpo)
MOD.train()
for e in range( nEpo ):

    lossVrun = 0.0
    cBtc = 0
    
    for step, (CNTVEC, CNTMSK, FRMVEC, FRMMSK, LbB) in enumerate(DLODer):

        optimizer.zero_grad()
    
        LOGT    = MOD( CNTVEC, CNTMSK, FRMVEC, FRMMSK ) 
        loss    = criterion( LOGT, LbB )

        loss.backward()
        optimizer.step()

        lossVrun += loss.item()
        cBtc += 1
        
    Loss[e] = lossVrun / cBtc

# print( Loss )


# --------------------------------------------------------------------------------
#                               P R E D I C T 
# --------------------------------------------------------------------------------
# initialize loader
DSET    = sbDs.dsetVMX2( ACNTPRD, AFRMPRD, LbPrd )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=False, collate_fn = sbDs.colt_VMX2 )

MOD.eval()
cHit = 0
with torch.no_grad():

    for CNTVEC, CNTMSK, FRMVEC, FRMMSK, LbB in DLODer:

        LOGT    = MOD( CNTVEC, CNTMSK, FRMVEC, FRMMSK ) 

        IxPredF = torch.argmax(LOGT, dim=1)
        nHit    = (IxPredF == LbB).sum().item()
        cHit   += nHit;

acc = cHit / len(LbPrd)

print( f"# acc {acc:.4f}  dimHid {dimHid}", end="" )
print( f"  nEpo {nEpo}  szBtc {szBtc}  lrPeak {lrPeak:.6f}  pDrot {pDrot:.1f}" )
