"""

Matching fabrics

af plcMtcHstKol.py

"""
import sys, subprocess
from pathlib import Path

sys.path.insert(0, '..')

from AdminPy.Collection.Register import *
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn, cmndArgs
from AdminPy.Mtch.OrgFile.OrgFileNameMtch import *

import AdminPy as sb

## ----------   Prepare Input Args   --------
dirDbin     = Path( 'Dbin/' )

fipaFbrcTst  = dirDbin / Path( '0000000.fbrc' )    # testing image 

aFbrcRep     = list( dirDbin.glob( '*.fbrc' ) ) # representation/reference image

finaRgst     = Path( 'Regist/FinasFbrc.txt' )

SaveFipaLst( aFbrcRep, finaRgst )

FinaMes      = fileNameMtchFbrc()

## =========   Command Mhst/Mkol  ========
cmnd         = [ sb.FipaExe['mfbrchykL'], fipaFbrcTst,  finaRgst ]
Res          = subprocess.run( cmnd, capture_output=True, text=True )
v_CmndExec( Res )

## -------   Load Matching Results   -------
nRep         = len(aFbrcRep);

DisItg       = sb.Util.LoadArrFltHed( FinaMes.hykLstItg )
DisMtx       = sb.Util.LoadMtrxFlt( FinaMes.hykLstClw )

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
import numpy as np

xLab = ['0-0', '0-1', '0-2', '0-3', '0-6']
xPos = np.arange(len(xLab))

plt.figure(2)
plt.clf()

plt.subplot(2, 1, 1)
plt.bar(xPos, DisItg)
plt.xticks(xPos, xLab)
plt.ylabel('Distances')
plt.title('Fabric')

plt.subplot(2, 1, 2)
plt.imshow( DisMtx )
plt.ylabel('Images')
plt.xlabel('Cells')
plt.title('Per Cell Distances')

plt.tight_layout()
plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)


