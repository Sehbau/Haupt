"""

Mock example for setting up descriptor vector matrices for a DeepSet network. Assumes
that previous scripts have been executed already (see sequence in plcAll.py)

"""
import sys, subprocess, os, glob
import numpy as np
from pathlib import Path

import torch
from torch.utils.data import Dataset, DataLoader

import warnings
# Suppress the specific PyTorch nested tensor user warning
warnings.filterwarnings("ignore", message=".*enable_nested_tensor is True.*")

sys.path.insert(0, '..')

import AdminPy as sb
import AdminPy.Networks.DeepSet as sbDs

dscTyp      = 'skl'

# -----  paths  -----
pthOpr      = Path.cwd()
DirNames    = sb.Orga.o_DirNames()
Pths        = sb.Orga.o_DirsPrependPath( DirNames, pthOpr )

# ------------------------------   Load   ------------------------------
import AdminPy.Collection as cl
COLLVEC, ntDsc, nDim = cl.LoadCollVec(    Pths.coll, dscTyp )
CollLab, ntDsc2      = cl.LoadCollVecLab( Pths.coll, dscTyp )

# ------------------------------   REFINE VEC   ------------------------------
# iclCollVmxLst.py
COLLVAX, Jatt = sb.DescExtr.VmxManip.o_AttCntOriExpand( COLLVEC )

del COLLVEC # ensure we dont accidentally use it

# ------------------------------   Prep Folds   ------------------------------
# training (trn) and prediction/testing (prd)
IxTrn       = [0,1,2]          
IxPrd       = [3,4]
LbTrn       = np.array( [0,0,1] ) # fake labels training
LbPrd       = np.array( [0,1] )   # fake labels prediction (testing)

# ------------------------   FOLDS & REARRANGE TO LIST   ---------------------------
AVECTRN, ALabTrn  = cl.u_CollMLtoLstSel( COLLVAX, CollLab, IxTrn )
AVECPRD, ALabPrd  = cl.u_CollMLtoLstSel( COLLVAX, CollLab, IxPrd )

# ----------   Parameters DeepSet   ----------
# Architecture:
dimHid     =  64

# Learning:
nEpo       =  100
szBtc      =  8
lrPeak     = 0.0005
gnoisSdv   = 0.001
pDrot      = 0.3
    
stepPlotLoss   = 20
lrMin          = lrPeak * 0.1

# ------------------------------   Model   ------------------------------
nAtt      = COLLVAX.shape[1]
nCat      = 2  # fake number of categories
MOD       = sbDs.MOD_DSCOneClsf( nAtt, dimHid, nCat )

# --------------------------------------------------------------------------------
#                             T R A I N   ( F I T )
# --------------------------------------------------------------------------------
# initialize loader
DSET    = sbDs.dsetVMX1( AVECTRN, LbTrn )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=True, collate_fn = sbDs.colt_VMX1 )

# ------------------------------   Guidance   ------------------------------
criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.AdamW(MOD.parameters(), lr=lrPeak)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR( optimizer, T_max=nEpo, eta_min=lrMin)

# ------------------------------   LOOP   ------------------------------
Loss      = np.zeros(nEpo)
MOD.train()
for e in range( nEpo ):

    lossVrun = 0.0
    cBtc = 0
    
    for step, (DSC, MASK, LbB) in enumerate(DLODer):

        optimizer.zero_grad()
    
        LOGT    = MOD( DSC, MASK ) 
        loss    = criterion( LOGT, LbB )

        loss.backward()
        optimizer.step()

        lossVrun += loss.item()
        cBtc += 1
        
    Loss[e] = lossVrun / cBtc

# print( Loss )


# --------------------------------------------------------------------------------
#                               P R E D I C T 
# --------------------------------------------------------------------------------
# initialize loader
DSET    = sbDs.dsetVMX1( AVECPRD, LbPrd )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=False, collate_fn = sbDs.colt_VMX1 )

MOD.eval()
cHit = 0
with torch.no_grad():

    for DSC, MASK, LbB in DLODer:

        LOGT    = MOD( DSC, MASK ) 

        IxPredF = torch.argmax(LOGT, dim=1)
        nHit    = (IxPredF == LbB).sum().item()
        cHit   += nHit;

acc = cHit / len(LbPrd)

print( f"# acc {acc:.4f}  dimHid {dimHid}", end="" )
print( f"  nEpo {nEpo}  szBtc {szBtc}  lrPeak {lrPeak:.6f}  pDrot {pDrot:.1f}" )
