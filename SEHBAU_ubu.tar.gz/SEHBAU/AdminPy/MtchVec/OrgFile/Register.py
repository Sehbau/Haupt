"""

Generating registers. A register is a list of filenames saved as text file.


"""
import os
from dataclasses import dataclass
from AdminPy.Util.OrgFile.SaveFipaLst import *
from AdminPy.Util.FileIO.LoadData import *



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_RegistGen   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Generates a register, a list of descriptor filenames. No verification of
their existence.

ai runMvecColl.m, runMhstKnn.m
sa SaveFipaXXX, SaveFinaXXX, SaveRegistFoc.m

sa o_RegistAnf.h
cf o_RegistCatgWise.m

IN  fist      filestem or path+filestem
    IxImg     image indices
    ext       extension
    nameFrmt  name format: none, or with leading zeros
     
OUT aLin      list of file paths as string (not a field)

"""
def o_RegistGen( fist, IxImg, ext, nameFrmt=0 ):

    aLin = []
    
    for ixi in IxImg:

        if nameFrmt == 0:                       # --- plain numbers
            fname = f"{fist}{ixi}{ext}"

        elif nameFrmt == 7:                     # --- leading zeros, width=7
            fname = f"{fist}{ixi:07d}{ext}"

        else:
            raise ValueError(f"nameFrmt={nameFrmt} not implemented.")
        
        aLin.append(fname)
    
    return aLin



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_RegistSetSave   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO


Generates the registers for a set of representation formats, namely
kolumn, histogram and vector (descfile).

cf lvngRunMcsc.m
sa o_RegistAnf.h

IN  pthOpr    path of operation, ie. path of matching program
    pthRep    path of representations
    fist      filestem or path+filestem
    IxImg     image indices
    Fixt      extensions
    nameFrmt  name format: none, or with leading zeros
     
OUT R         register info

"""
def o_RegistSetSave( pthRgst, pthDsc, fist, IxImg, Fixt, nameFrmt=0 ):

    @dataclass
    class R:
        pass    
    
    R.fpaDsc = os.path.join( pthRgst, "RefDsc.txt" )
    R.fpaHst = os.path.join( pthRgst, "RefHst.txt" )
    R.fpaKol = os.path.join( pthRgst, "RefKol.txt" )

    # generate file lists
    aVec = o_RegistGen( fist, IxImg, Fixt.dsc, nameFrmt)
    SaveFipaLstPrependPath( aVec, pthDsc, R.fpaDsc )

    aHst = o_RegistGen( fist, IxImg, Fixt.hsti, nameFrmt)
    SaveFipaLstPrependPath( aHst, pthDsc, R.fpaHst )

    aKol = o_RegistGen( fist, IxImg, Fixt.kolm, nameFrmt)
    SaveFipaLstPrependPath( aKol, pthDsc, R.fpaKol )

    R.aVec =  aVec
    R.pth  =  pthDsc

    return R



""" VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV   v_RegistValid   VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

Verifies that the register contains filenames that exist.

"""
def v_RegistValid( fpRgst: str ) -> bool:

    aLst, cLin  = LoadTextLinewise(fpRgst)
    bExist      = True
    cNot        = 0

    for path in aLst:

        if not os.path.isfile(path):
            if bExist:
                print("Does not exist:")
            bExist = False
            print(path)
            cNot += 1

    if cNot > 0:
        print(f"Warning: {cNot} files do not exist")

    return bExist    

    
