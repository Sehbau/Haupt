"""


def DispSec(string: str, chr_char: str = '=', hi: int = 0) -> float:
def DispLoad( fina: str, bRet: bool = True ) -> None:

"""

import time

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   DispSec   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Display a section announced with string. Centered to 80 chars.
    
Divider is specified with character chr_char. Default is '='.

"""
def DispSec( jStr: str, chr_char: str = '=', hi: int = 0) -> float:

    t0   = time.time()  # Equivalent to MATLAB clock (returns seconds since epoch)
    nLin = hi        # Number of empty lines before and after bar
    
    ss = 'S' * 80
    
    ## Upper Vertical Spacing
    if nLin > 0:
        print(ss)
        for _ in range(nLin - 1):
            print()
            
    ## Horizontal Spacing (Centering)
    # Pads the string with 4 spaces on each side, then centers it to 80 chars using chr_char
    pad   = f"    {jStr}    "
    tot   = f"{pad:{chr_char}^80}"
    print(tot)
    
    ## Lower Vertical Spacing
    if nLin > 0:
        for _ in range(nLin - 1):
            print()
        print(ss)
        
    return t0



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   DispLoad   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Displays a formatted message when a file is loaded.

"""
def DispLoad( fina: str, bRet: bool = True ) -> None:

    # Obtain the human-readable file modification string
    dateStr = u_FileDate(fina)
    
    # Formatted print string:
    # -35s left-aligns the file name to 35 characters
    # 5s provides a minimum width placeholder for the date metadata string
    msg = f"Loaded {fina:<35} [{dateStr:5}]."
    
    # If bRet is True, end with a newline '\n' (default behavior).
    # If bRet is False, suppress the newline by ending with an empty string ''.
    if bRet:
        print(msg)
    else:
        print(msg, end='', flush=True)
