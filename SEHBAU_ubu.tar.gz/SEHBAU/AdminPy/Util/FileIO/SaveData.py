"""


---------------   DEF SUM   ---------------
def SaveTextLinewise( aLines, sfn ):

"""



""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveTextLinewise   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

Saves a list of strings (lines).
"""
def SaveTextLinewise( aLines, sfn ):

    try:
        with open(sfn, 'w') as fid:
            for line in aLines:

                fid.write( f"{line}\n" )
                
    except IOError:
        raise RuntimeError(f"SaveFipaLst: could not write to {sfn}")

