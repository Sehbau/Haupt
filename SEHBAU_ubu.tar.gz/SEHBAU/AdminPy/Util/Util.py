"""

Utility routines. Some of it is deprecated I think.

def get_FinasPatWoExt( dirFina, rex ):
def get_FieldNames( C ):
def del_FilesDirPat( path, pat ):
def del_FilesPat( pat ):
def vrf_PathsExist( P: Paths ) -> None:
def vrf_PathsExistAsk(s: dict) -> None:
def printDotProg( ):
def halted( ):

Elsewhere:
- command arguments in CmndSupp.py

"""

import os, glob, time
from pathlib import Path
import numpy as np
import msvcrt # keyboard


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   get_FinasPat   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Obtain filenames with regexp pattern. It's a wrapper for glob.glob

"""
def get_FinasPat( dirFina, rex ):

    aLst  = glob.glob( os.path.join( dirFina, rex ) )

    return aLst


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   get_FinasPatWoExt   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Obtain filenames with regexp pattern and return them without extension.

"""
def get_FinasPatWoExt( dirFina, rex ):

    # List the files
    aLst  = glob.glob( os.path.join( dirFina, rex ) )

    # Extract base filenames without extension
    aNam  = [ os.path.splitext( os.path.basename(p) )[0] for p in aLst ]

    return aNam



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   get_FieldNames   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Obtain the fieldnames from a struct

https://stackoverflow.com/questions/11637293/iterate-over-object-attributes-in-python

"""
def get_FieldNames( C ):

    aFn = [a for a in dir( C ) if not a.startswith('__')]

    return aFn



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   del_FilesDirPat   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Delete files by providing directory and regular expression pat.

"""
def del_FilesDirPat( path, pat ):

    #input( 'Deleting files in ' + str(path) + pat + '   pausing. (hit key to continue)' )
    
    for file in Path(path).glob(pat):
        file.unlink()        


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   del_FilesPatOs   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Delete files with regular expression pat using os.

Im not sure whether this is compatible with any OS

"""
def del_FilesPatOs( pat ):

    input( 'Deleting files in ' + str(pat) + '   pausing. (hit key to continue)' )
    
    for file in glob.glob( pat ):
        os.remove(file)


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   del_FilesPat   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Delete files with regular expression pat using string or path

Delete files matching a glob pattern using pathlib.
Waits for user confirmation before proceeding.

IN    pat : str | Path
      The file path pattern (can include wildcards, e.g. '*.txt' or 'data/**/*.csv')

"""
def del_FilesPat(pat: str | Path) -> None:

    pat = Path(pat)

    # Show where the deletion will occur
    print(f"Deleting files matching pattern: {pat}")
    #input("Press ENTER to continue or Ctrl+C to abort...")

    # -----  perform recursive glob if the pattern includes '**'
    if "**" in str(pat):
        aFiles = list(pat.parent.rglob(pat.name))
    else:
        aFiles = list(pat.parent.glob(pat.name)) if pat.parent.exists() else []

    if not aFiles:
        print("No files found.")
        return

    print(f"Found {len(aFiles)} file(s) to delete:")
    for f in aFiles:
        print(f"  {f}")

    # Final confirmation
    confirm = input("Type 'yes' to confirm deletion: ").strip().lower()
    if confirm != "yes":
        print("Deletion cancelled.")
        return

    # Delete files
    for f in aFiles:
        try:
            f.unlink()
            print(f"Deleted: {f}")
        except Exception as e:
            print(f"Could not delete {f}: {e}")

    print("Done.")        


""" VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV   vrf_PathsExist   VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

Verifies that filepaths exist (of a dataclass)

v_PathsExistsStruct.m

"""
def vrf_PathsExist( P ) -> None:

    for attr, path in vars(P).items():

        if isinstance( path, Path ) and not path.exists():

            path.mkdir( parents=True, exist_ok=True )


""" VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV   vrf_PathsExistAsks   VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

Verifies that filepaths exist (of a dataclass) and asks if directory is supposed to
be created.

v_PathsExistsStruct.m

"""
def vrf_PathsExistAsk(s: dict) -> None:
    
    for key, pthStr in vars(s).items():

        pth = Path(pthStr)
        
        # Check if the directory does not exist
        if not pth.is_dir():

            # Prompt the user and pause execution
            input(f"Path {pthStr} does not exist. Create? (Press Enter to continue...)")
            
            # Create the directory (parents=True also creates missing parent folders)
            pth.mkdir(parents=True, exist_ok=True)

    return


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   printDotProg   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Print a progress dot.

"""
def printDotProg( ):

    print('.', end='', flush=True)


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   halted   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Halted

"""
def halted( ):

    print("Script halted. Press any key to resume...")
    msvcrt.getch()  # halts until a single key is pressed (doesn't require Enter)
    print("Resuming...")

    #print("Script halted. Press 'space' to resume...")
    #keyboard.wait('space')  # Halts until spacebar is pressed
    #print("Resuming...")    
        




""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_FileDate   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Obtains file modification date and returns a human-readable string as output.

"""
def u_FileDate(fipa: str) -> str:
    
    # Check if the primary path exists, fall back to adding '.mat' if needed
    if not os.path.exists(fipa):
        fipa_mat = f"{fipa}.mat"
        if os.path.exists(fipa_mat):
            fipa = fipa_mat
        else:
            return 'does not exist - could not determine date'
            
    # Get the file modification timestamp (seconds since epoch)
    mtime = os.path.getmtime(fipa)
    
    # Convert timestamps to datetime objects
    dt_then = datetime.fromtimestamp(mtime)
    dt_now = datetime.now()
    
    # Generate the base timestamp string excluding seconds (Format: DD-MMM-YYYY HH:MM)
    fd = dt_then.strftime("%d-%b-%Y %H:%M")
    
    # Calculate total time difference
    delta = dt_now - dt_then
    dur_days = delta.days
    
    # Calculate raw hours and minutes relative to the actual total time difference
    total_seconds = int(delta.total_seconds())
    dur_hour = total_seconds // 3600
    dur_min = (total_seconds % 3600) // 60

    # --- Determine the human-readable suffix
    if dur_days == 0:
        if dur_hour <= 1 and dur_min < 60:
            fd = f"{fd}   {dur_min} min ago"
        elif dur_hour < 12:
            fd = f"{fd}   {dur_hour} hours ago"
        else:
            fd = f"{fd}   past 24h"
    elif dur_days == 1:
        fd = f"{fd}    yesterday"
    else:
        fd = f"{fd}   {dur_days} days old"
        
    return fd


