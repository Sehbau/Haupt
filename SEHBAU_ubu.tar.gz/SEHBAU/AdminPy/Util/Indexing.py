"""

Indexing. We assume that labels come from a collection label array without
duplicates, in particular for definition ixr_BlockInsEmp.


---------------   DEF SUM   ---------------
def ixr_Block( Lb ):
def ixr_BlockFind( Lb, Tg ):
def ixr_BlockInsEmp( aFnd, Lb, LbExp ):

"""
import numpy as np



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   ixr_Block   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Finds the blocks of same labels in array Lb. Or in other words: the connected
components for different values.

      Lb    = [1,1,0,2,2]
      aRng  = [0,1], [2], [3,4]
      nBlk  = 3
      LbU   = [1,0,2]

IN    Lb    label array whose blocks have unique ID
OUT   aRng  list of block ranges
      nBlk  num of blocks found
      LbU   the unique labels

"""
def ixr_Block( Lb ):

    Lb         = np.array(Lb)
    
    IxChng     = np.where( np.diff(Lb) != 0 )[0] + 1
    Rng        = np.arange( len(Lb) )
    aRng       = np.split(Rng, IxChng )
    nBlk       = len(IxChng)+1

    LbU        = np.append( Lb[0], Lb[IxChng] )

    return aRng, nBlk, LbU


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   ixr_BlockFind   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Finds the blocks in array Lb for the labels specified in target Tg. 

     Lb    = [1,1,0,2,2]
     Tg    = [0]
     aRng  = [2]

"""
def ixr_BlockFind( Lb, Tg ):

    aAll, nAll, LbU = ixr_Block( Lb )

    IxTrg = np.where( np.isin(LbU, Tg) )[0]

    aSel = [aAll[i] for i in IxTrg]
    nSel = len(aSel)

    return aSel, nSel, LbU


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   ixr_BlockInsEmp   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Inserts empty arrays. Works only for label array that does not contain duplicate
blocks, ie. image labels.

IN   aFnd   list of found index ranges {nFnd}
     Lb     their unique labels [nFnd]
     LbExp  expected labels [>nFnd]
OUT  aFll   full set, with empty arrays where setdiff( LbExp, Lb )

"""
def ixr_BlockInsEmp( aFnd, Lb, LbExp ):


    nLbExp   = len(LbExp)
    
    aFll     = [None]*nLbExp
    cf       = 0
    for i in range(nLbExp):

        if LbExp[i] in Lb:
            aFll[i] = aFnd[cf]
            cf      = cf+1
        else:
            aFll[i] = np.array([])
            
    cEmp = nLbExp - cf
            
    if cEmp>0:
        print(f"inserted {cEmp} empty ranges")
            
    return aFll
            
            
            
