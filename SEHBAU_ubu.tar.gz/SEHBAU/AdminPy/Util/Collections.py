"""

"""
from __future__ import annotations # 3.12
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np
from typing import List, Optional, Any


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class dclsCollPaths:
    
    ImgColl: Path = Path() # images

    ImgDat: Path = Path()  # OUTPUT files
    DescImg: Path = Path() # description files
    DescColl: Path = Path() # collected description - concatenated across files
    Hist: Path = Path()
    DescNN: Path = Path()
    Regist: Path = Path()
    MesMtch: Path = Path()


@dataclass
class dclsCollInfo:
    
    aFinas: List[str] = field(default_factory=list)
    nCat: Optional[int] = None
    name: str = ''
    nFinas: Optional[int] = None
    nImg: Optional[int] = None
    ftxFinas: Optional[Path] = None
    LabImg: Optional[np.ndarray] = None
    aCatLab: Optional[List[str]] = None
    szI: Optional[tuple] = None
    IxImgLrn: Optional[np.ndarray] = None
    IxImgTst: Optional[np.ndarray] = None
    nImgLrn: Optional[int] = None
    nImgTst: Optional[int] = None
    LbLrn: Optional[np.ndarray] = None
    LbTst: Optional[np.ndarray] = None
    Pth: Optional[Any] = None  # could be another dataclass



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

"""

Collections. For place recognition see u_CollPlcRec

"""
def u_CollPaths(dbas: int) -> tuple[ dclsCollPaths, dclsCollInfo ]:

    J    = dclsCollInfo()
    P    = dclsCollPaths()
    name = ''

    # ---------------- Database selection ----------------
    if dbas == 7:
        stem, nCat, name = 'OLTO', 8, 'UrbNat'
    elif dbas == 10:
        stem, nCat, name = 'IndOut15', 15, 'IndOut15'
    elif dbas == 31:
        stem, nCat, name = 'DOCU/Ch_lower', 24, 'LetLow'
    elif dbas == 37:
        stem, nCat, name = 'VOC', 20, 'VOC'
    elif dbas == 50:
        stem, nCat, name = 'Indoor', 67, 'Indoor67'
    elif dbas == 52:
        stem, nCat = 'PLR_NYU2', np.nan
    elif dbas == 60:
        stem, nCat, name = Path(r'CAMSDD/training'), 30, 'Cam30'
    elif dbas == 61:
        stem, nCat = Path(r'CAMSDD/validation'), 30
    elif dbas == 62:
        stem, nCat, name = Path(r'CAMSDD/test'), 30, 'Cam30Test'
    elif dbas == 17:
        stem, nCat, name = 'SINR45', 45, 'SINR45'
    elif dbas == 100:
        stem, nCat, name = 'CIFAR10', 10, 'Cif10'
    elif dbas == 200:
        stem, nCat = 'cityscapes', np.nan
    else:
        raise ValueError(f"Database {dbas} not specified")

    J.nCat = nCat
    J.name = name

    # ---------------- Paths setup ----------------
    DRV = Path("G:/")

    P.ImgColl = DRV / "IMGdown" / stem
    P.ImgDat = DRV / "IMGdat" / stem
    P.DescImg = P.ImgDat / "DSCimg"
    P.DescColl = P.ImgDat / "DSCcoll"
    P.Hist = P.ImgDat / "LHST"
    P.DescNN = P.ImgDat / "DSCnn"
    P.Regist = P.ImgDat / "Regist"
    P.MesMtch = P.ImgDat / "MesMtch"

    # --- Special cases ---
    if dbas == 10:
        P.ImgColl = P.ImgColl / "SameSize"
    elif dbas == 50:
        P.ImgColl = P.ImgColl / "Images"
    elif dbas == 200:
        P.ImgColl = DRV / "IMGdown" / "cityscapes_data" / "leftImg8bit" / "train" / "aachen"

    # ---------------- Load filenames ----------------
    ftxFinas = P.ImgDat / "ImgFinas.txt"
    if ftxFinas.is_file():
        with ftxFinas.open("r", encoding="utf-8") as f:
            J.aFinas = [line.strip() for line in f if line.strip()]
        J.nFinas = len(J.aFinas)
        J.nImg = J.nFinas
        J.ftxFinas = ftxFinas

    # ---------------- Load image labels ----------------
    ftxImgLab = P.ImgDat / "ImgCatLb.txt"
    if ftxImgLab.is_file():
        J.LabImg = np.loadtxt(ftxImgLab, dtype=int)
        if J.aFinas:
            assert len(J.LabImg) == J.nFinas
    elif dbas == 52:
        fileScenes = P.ImgColl / "Scenes.npy"
        if fileScenes.is_file():
            scenes = np.load(fileScenes, allow_pickle=True)
            J.aFinas = list(scenes)
            J.nFinas = len(J.aFinas)
            np.unique(scenes, return_index=True, return_inverse=True)
            P.ImgColl = P.ImgColl / "Images"
    elif dbas == 100:
        from LoadImgCIF10 import LoadImgCIF10  # custom function
        _, J.LabImg = LoadImgCIF10()
    else:
        print("No file ImgCatLb.txt found")

    # ---------------- Load category labels ----------------
    ftxCatLab = P.ImgDat / "CatgNames.txt"
    if ftxCatLab.is_file():
        pass  # Assume external category list loaded
    elif dbas == 7:
        J.aCatLab = ['coast', 'forest', 'highway', 'city',
                     'mountain', 'country', 'street', 'building']
    elif dbas == 100:
        J.aCatLab = ['airplane', 'automobile', 'bird', 'cat', 'deer',
                     'dog', 'frog', 'horse', 'ship', 'truck']
    else:
        print("No file CatgNames.txt found")

    # ---------------- CIFAR10 ----------------
    if dbas == 100 and J.LabImg is not None:
        J.szI = (32, 32)
        J.IxImgLrn = np.arange(1, 50001)
        J.IxImgTst = np.arange(50001, 60001)
        J.nImgLrn = 50000
        J.nImgTst = 10000
        J.LbLrn = J.LabImg[J.IxImgLrn - 1]
        J.LbTst = J.LabImg[J.IxImgTst - 1]

    # ---------------- VOC ----------------
    if dbas == 37:
        from u_Vo7Paths import u_Vo7Paths
        J.Pth = u_Vo7Paths()  # expected to return a similar dataclass
        # VOCinit() placeholder
        J.nFinas = 9963

    return P, J
