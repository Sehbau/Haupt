"""

Focus selection.

------------------------------   CLS SUM   ------------------------------
class focRng:
class prmFocScl:

------------------------------   DEF SUM   ------------------------------
def f_FocRngFromBbx( top: int, bot: int, lef: int, rit: int, sclV: float, sclH: float ) -> focRng:

def i_PrmFocSclToFbrc( szV: int, szH: int ) -> prmFocScl:

def f_FocFipaStem( pth: str | Path, ctg, ist, ext ) -> str:

"""
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import numpy.typing as npt

#from AdminPy.Orga.OrgFileNames import o_FileExtensFoc



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class focRng:                    # ''''''''''''''''''''   focRng   ''''''''''''''''''''
    """

    """
    Rw: npt.NDArray[np.int32]   # row indices
    Cl: npt.NDArray[np.int32]   # col indices
    nRow: int
    nCol: int


@dataclass
class prmFocScl:              # ''''''''''''''''''''   prmFocScl   ''''''''''''''''''''
    """
    The scaling factors for bbox to map
    """
    vrt0: float
    vrt1: float
    vrt2: float
    vrt3: float

    hor0: float
    hor1: float
    hor2: float
    hor3: float


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FocRngFromBbx   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Extracting index ranges from a bounding box

FocRng  = fs.f_FocRngFromBbx( top, lef, bot, rit, PrmScl.vrt0, PrmScl.hor0 )

"""
def f_FocRngFromBbx( top: int, bot: int, lef: int, rit: int, sclV: float, sclH: float ) -> focRng:

    rwTop   = round( float(top) * sclV )
    rwBot   = round( float(bot) * sclV )
    clLef   = round( float(lef) * sclH )
    clRit   = round( float(rit) * sclH )

    #print(rwTop, rwBot, clLef, clRit )
    
    RwRng   = np.arange( rwTop, rwBot )
    ClRng   = np.arange( clLef, clRit )

    Rng     = focRng( Rw=RwRng, Cl=ClRng, nRow=len(RwRng), nCol=len(ClRng) )

    return Rng


""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_PrmFocSclToFbrc   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII

Scaling factors for extracting focii from fabric maps.
"""
def i_PrmFocSclToFbrc( szV: int, szH: int ) -> prmFocScl:

    P       = prmFocScl
    P.vrt0  = 31 / float(szV)
    P.vrt1  = 15 / float(szV)
    P.vrt2  =  7 / float(szV)
    P.vrt3  =  3 / float(szV)

    P.hor0  = 31 / float(szH)
    P.hor1  = 15 / float(szH)
    P.hor2  =  7 / float(szH)
    P.hor3  =  3 / float(szH)

    return P

    


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_FocFipaStem   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Simple filestem:   Lab{category}_i{instance}
"""
def f_FocFipaStem( pth: str | Path, ctg, ist, ext ) -> str:

    fst = str(pth) + f"/Lab{ctg}_i{ist}" + ext

    return fst



    

