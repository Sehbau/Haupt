"""

"""
import glob, os

from AdminPy.Util.OrgFile.SaveFipaLst import *


""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveRegistFoc   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

see SaveRegistFoc.m

"""
def SaveRegistFoc( dirFoc, aImgNames, dirRegist, fext, neLev ):

    nImg = len(aImgNames);

    if nImg==0:
        print(f"SaveRegistFoc: no filenames in aImgNames for {fext} in {dirFoc}")

    ## ----  hist or vect (atts)  ----
    if fext == 'hsf1':

        aFipas  = [None] * nImg
        
        for i in range(nImg):

            imgNa   = aImgNames[i]
        
            pat     = os.path.join( dirFoc, imgNa + '_F*.' + fext )
            aFinas  = glob.glob( pat )
            
            nFocDet = len( aFinas )
            
            if nFocDet==0:
                continue
            
            sfpRgst = f'{dirRegist}/Foc{imgNa}.rgsth'
            
            SaveFipaLst( aFinas, sfpRgst )
            #SaveFipaLstPrependPath( aFinas, '', sfpRgst )
            
            aFipas[i] = sfpRgst
            
    elif fext == 'dsf':
        
        aFipas = [[None for _ in range(neLev)] for _ in range(nImg)]
        
        for i in range(nImg):

            imgNa   = aImgNames[i]
        
            for l in range(neLev):

                pat     = os.path.join( dirFoc, imgNa + '_F*_lev' + str(l+1) + '.' + fext )
                aFinas  = glob.glob( pat )
            
                nFocDet = len( aFinas )
            
                if nFocDet==0:
                    continue
            
                sfpRgst = f'{dirRegist}/Foc{imgNa}_Lev{l+1}.rgstv'
            
                SaveFipaLst( aFinas, sfpRgst )
                #SaveFipaLstPrependPath( aFinas, '', sfpRgst )
            
                aFipas[i][l] = sfpRgst

    else:
        raise NotImplemented( f'file extension {fext} not implemented' );
    

    return aFipas
