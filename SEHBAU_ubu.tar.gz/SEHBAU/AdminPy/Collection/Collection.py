"""

see IclXXX for processing lists of images
see LoadColl for loading a collection of description

---------------   DEF SUM   ---------------
def u_CollDscCount( Lab ):
def sts_CollLab( Lab, bDisp: int=0 )-> stsCollLab:


"""
from dataclasses import dataclass, field
from typing import Any

import AdminPy.Util as ut
import AdminPy.Orga as og
import numpy as np


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class stsCollLab:          # ''''''''''''''''''''   stsCollLab   ''''''''''''''''''''
    """
    Holds stats for label array
    """
    IxImg:     np.ndarray | None = None   # image indices 
    IxLev:     np.ndarray | None = None   # levels 
    MxnDscLev: np.ndarray | None = None   # max num of descriptor per level

    ntDsc:  int = -1
    mxnDsc: int = -1
    nLev:   int = -1
    nImg:   int = -1
    nAsp:   int = 3


@dataclass
class dclsColc:          # ''''''''''''''''''''   dclsColc   ''''''''''''''''''''
    """
    Holds vector matrix, position coordinates and label array
    """
    VEC: np.ndarray | None = None # vector matrix [ntDsc nAtt]
    POS: np.ndarray | None = None # position coordinates [ntDsc 2] vertical, horizontal
    Lab: np.ndarray | None = None # label array usually [ntDsc nAsp=3]

    ntDsc: int = -1
    nAtt:  int = -1
    dty:   str = '-'

    Sts: stsCollLab = field(default_factory=stsCollLab)

    LbAtt: Any = None
    IxAtt: Any = None
    Jatt:  og.dclsAttInfo = None
    


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollDscCount   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Counts the num of descriptors per image and level.

Assumes all is zero-indexing.

"""
def u_CollDscCount( Lab ):

    LevAll   = Lab[:,0]
    ImgAll   = Lab[:,1]

    nImg     = ImgAll.max()+1
    mxLev    = LevAll.max()+1

    #AVEC     = [None]*nSel
    mxnDsc = 0
    MxnDsc = np.zeros(mxLev)
    for i in range(0,nImg):

        Bimg    = ImgAll==i
        nDsc    = np.count_nonzero(Bimg)

        if nDsc > mxnDsc:
            mxnDsc = nDsc

        # ------  Per Level  ------
        LevI    = LevAll[Bimg]

        for l in range(0,mxLev):
            
            Blev    = (LevI==l)
            nD      = np.count_nonzero(Blev)
            #print( nD )
            if nD > MxnDsc[l]:
                MxnDsc[l] = nD

    return mxnDsc, MxnDsc


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   sts_CollLab   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Stats from collection array
"""
def sts_CollLab( Lab, bDisp: int=0 )-> stsCollLab:

    
    ntDsc,nAsp  = Lab.shape
    
    IxLev = np.unique( Lab[:,0] )
    IxImg = np.unique( Lab[:,1] )

    nLev  = len(IxLev)
    nImg  = len(IxImg)
    
    mxnDsc, MxnDsc  = u_CollDscCount( Lab )

    S        = stsCollLab()
    S.ntDsc  = ntDsc
    S.mxnDsc = mxnDsc
    S.nLev   = nLev
    S.nImg   = nImg

    S.IxLev     = IxLev
    S.IxImg     = IxImg
    S.MxnDscLev = MxnDsc

    if bDisp:
        print( f"ntDsc {ntDsc:7d}   nLev {nLev}   "
               f"Levs {IxLev[0]}-{IxLev[-1]}   Imgs {IxImg[0]}-{IxImg[-1]}   nImg {nImg}   "
               f"mxnDsc {mxnDsc}"
              )

    return S
