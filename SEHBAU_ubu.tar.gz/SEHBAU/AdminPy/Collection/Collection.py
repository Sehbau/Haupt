"""

Handles administrative info and processed descriptors when setting up a learning
procedure. For a specific image collection see IclAdmin.py

see IclProc.py for processing lists of images
see LoadColl.py for loading a collection of description
see CollManip.py for manipulating vector matrices (using VmxManip.py)

------------------------------   CLS SUM   ------------------------------
class collLabSts:
class dclsColc

------------------------------   DEF SUM   ------------------------------

def u_CollDscCount( Lab ):
def sts_CollLab( Lab, bDisp: int=0 )-> collLabSts:

def SaveCollHistInit( nImg: int, nBin: int, sfp: str ) -> None:
def SaveCollHistApnd(Mx: np.ndarray, sfp: str) -> None:

def ICL_COLLFBRCHYKO( fipaExe: str, IxImg: list, Fips1: object, FixtImg: object, 
                      finaFrmt: str, FinaColl: object) -> None:

Elsewhere:
- u_CollPaths, administrative info for image collections in IclAdmin.py

"""
import os, sys, subprocess

from dataclasses import dataclass, field
from typing import Any

import numpy as np

import AdminPy.Util as ut
import AdminPy.Orga as og
from AdminPy.Collection.LoadCollHist import *



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class collLabSts:          # ''''''''''''''''''''   collLabSts   ''''''''''''''''''''
    """
    Holds stats for label array
    """
    IxImg:     np.ndarray | None = None   # image indices 
    IxLev:     np.ndarray | None = None   # levels 
    MxnDscLev: np.ndarray | None = None   # max num of descriptor per level

    ntDsc:  int = -1
    mxnDsc: int = -1
    nLev:   int = -1
    nImg:   int = -1
    nAsp:   int = 3


@dataclass
class collDSCTYP:          # ''''''''''''''''''''   collDSCTYP   ''''''''''''''''''''
    """
    Holds vector matrix (aka collection matrix), position coordinates and label
    array
    """
    VEC: np.ndarray | None = None # vector matrix [ntDsc nAtt]
    POS: np.ndarray | None = None # position coordinates [ntDsc 2] vertical, horizontal
    Lab: np.ndarray | None = None # label array usually [ntDsc nAsp=3]

    ntDsc: int = -1
    nAtt:  int = -1
    dty:   str = '-'

    Sts:   collLabSts = field( default_factory=collLabSts )

    LbAtt: Any = None
    IxAtt: Any = None
    Jatt:  og.attInfo = None
    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollDscCount   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Counts the num of descriptors per image and level.

Assumes all is zero-indexing.

"""
def u_CollDscCount( Lab ):

    LevAll   = Lab[:,0]
    ImgAll   = Lab[:,1]

    nImg     = ImgAll.max()+1
    mxLev    = LevAll.max()+1

    #AVEC     = [None]*nSel
    mxnDsc = 0
    MxnDsc = np.zeros(mxLev)
    for i in range(0,nImg):

        Bimg    = ImgAll==i
        nDsc    = np.count_nonzero(Bimg)

        if nDsc > mxnDsc:
            mxnDsc = nDsc

        # ------  Per Level  ------
        LevI    = LevAll[Bimg]

        for l in range(0,mxLev):
            
            Blev    = (LevI==l)
            nD      = np.count_nonzero(Blev)
            #print( nD )
            if nD > MxnDsc[l]:
                MxnDsc[l] = nD

    return mxnDsc, MxnDsc


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   sts_CollLab   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Stats from collection array
"""
def sts_CollLab( Lab, bDisp: int=0 )-> collLabSts:

    
    ntDsc,nAsp  = Lab.shape
    
    IxLev = np.unique( Lab[:,0] )
    IxImg = np.unique( Lab[:,1] )

    nLev  = len(IxLev)
    nImg  = len(IxImg)
    
    mxnDsc, MxnDsc  = u_CollDscCount( Lab )

    S        = collLabSts()
    S.ntDsc  = ntDsc
    S.mxnDsc = mxnDsc
    S.nLev   = nLev
    S.nImg   = nImg

    S.IxLev     = IxLev
    S.IxImg     = IxImg
    S.MxnDscLev = MxnDsc

    if bDisp:
        print( f"ntDsc {ntDsc:7d}   nLev {nLev}   "
               f"Levs {IxLev[0]}-{IxLev[-1]}   Imgs {IxImg[0]}-{IxImg[-1]}   nImg {nImg}   "
               f"mxnDsc {mxnDsc}"
              )

    return S


import struct


""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveCollHistInit   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

Writes header for a collection of histograms as loaded in LoadCollHist.m

"""
def SaveCollHistInit( nImg: int, nBin: int, sfp: str ) -> None:

    try:
        with open(sfp, 'wb') as fid:
            
            # fwrite( fid, nImg, 'int32' );
            fid.write(struct.pack('i', nImg))   # number of images
            
            # fwrite( fid, nBin, 'int32' );
            fid.write(struct.pack('i', nBin))   # number of bins

    except (OSError, IOError) as e:

        raise RuntimeError(f"Could not open {sfp}\n") from e



""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveCollHistInit   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

Appends to a collection matrix, that was initialized with SaveCollHistInit() (above)

"""
def SaveCollHistApnd(Mx: np.ndarray, sfp: str) -> None:

    try:
        with open(sfp, 'ab') as fid:
            
            # fwrite( fid, Mx(:), 'int32' );   
            # 1. .flatten(order='F') mimics MATLAB's column-major Mx(:) ordering
            # 2. .astype(np.int32) guarantees it writes as 'int32' bytes
            # 3. .tofile(fid) writes the entire raw binary block directly to the open file
            Mx.flatten(order='F').astype(np.int32).tofile(fid)

    except (OSError, IOError) as e:
        raise RuntimeError(f"Could not open {sfp}\n") from e

    

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ICL_COLLFBRCHYKO   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Collecting fabric kolumns for a list of images. 

cf iclCollFbrcHyko.py

"""
def ICL_COLLFBRCHYKO( fipaExe: str, IxImg: list, Fips1: object, FixtImg: object, 
                      finaFrmt: str, FinaColl: object) -> None:

    # %% -------------   Arguments   -----------
    ut.vrf_ExecutableExists( fipaExe )

    # %% -------------   LOOP LIST   -----------
    nImg = len(IxImg)

    # Calculate step size for progress dots (avoid division by zero if nImg is tiny)
    stepDot = max(1, round(nImg / 40))

    for i, ixi in enumerate(IxImg):

        pthFbrc = og.o_FileNameFrmt( Fips1.fbrc, ixi, '', finaFrmt )
        
        # ----------   Execute   ------------
        cmnd = f"{fipaExe} {pthFbrc}{FixtImg.fbrc} .\\tmp"

        try:
            result = subprocess.run(cmnd, shell=True, capture_output=True, text=True, check=True)
            StdOut = result.stdout
        except subprocess.CalledProcessError as e:
            print(f"Command execution failed: {e.stderr}")
            StdOut = e.stderr
        
        # ----------   Load   ----------
        bFirst = i==0
        HK0, Nbin0 = LoadCollHist( f"tmp{FixtImg.fbArK0}", bFirst)
        HK1, Nbin1 = LoadCollHist( f"tmp{FixtImg.fbArK1}", bFirst)
        HK2, Nbin2 = LoadCollHist( f"tmp{FixtImg.fbArK2}", bFirst)
        HK3, Nbin3 = LoadCollHist( f"tmp{FixtImg.fbArK3}", bFirst)
        
        # --------------- Append to Collection --------------------

        # the fabric format has the same format as the spatial histograms, which is
        # simply saved as a matrix, hence we use the SaveCollHistXXXX functions.
        
        # ----- init before 1st image -----
        if i==0:
            SaveCollHistInit( nImg, HK0.size, FinaColl.fbk0)
            SaveCollHistInit( nImg, HK1.size, FinaColl.fbk1)
            SaveCollHistInit( nImg, HK2.size, FinaColl.fbk2)
            SaveCollHistInit( nImg, HK3.size, FinaColl.fbk3)
        
        # -----  append  -----
        SaveCollHistApnd( HK0, FinaColl.fbk0)
        SaveCollHistApnd( HK1, FinaColl.fbk1)
        SaveCollHistApnd( HK2, FinaColl.fbk2)
        SaveCollHistApnd( HK3, FinaColl.fbk3)
        
        # --- progress dots
        if i % stepDot == 0:
            print('.', end='', flush=True)
        
        
    print(f"\n{IxImg[0]}-{IxImg[-1]} done")


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ICL_COLLFBRCMNUM   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Collecting fabric numerosity (count) maps for a list of images. 

cf iclCollFbrcMnum.py

"""
def ICL_COLLFBRCMNUM( fipaExe: str, IxImg: list, Fips1: object, FixtImg: object, 
                      finaFrmt: str, FinaColl: object) -> None:

    # %% -------------   Arguments   -----------
    ut.vrf_ExecutableExists( fipaExe )

    # %% -------------   LOOP LIST   -----------
    nImg = len(IxImg)

    # Calculate step size for progress dots (avoid division by zero if nImg is tiny)
    stepDot = max(1, round(nImg / 40))

    for i, ixi in enumerate(IxImg):

        pthFbrc = og.o_FileNameFrmt( Fips1.fbrc, ixi, '', finaFrmt )
        
        # ----------   Execute   ------------
        cmnd = f"{fipaExe} {pthFbrc}{FixtImg.fbrc} .\\tmp"

        try:
            result = subprocess.run(cmnd, shell=True, capture_output=True, text=True, check=True)
            StdOut = result.stdout
        except subprocess.CalledProcessError as e:
            print(f"Command execution failed: {e.stderr}")
            StdOut = e.stderr
        
        # ----------   Load   ----------
        bFirst = i==0
        MN0, dmy = LoadCollHist( f"tmp{FixtImg.fbArN0}", bFirst)
        MN1, dmy = LoadCollHist( f"tmp{FixtImg.fbArN1}", bFirst)
        MN2, dmy = LoadCollHist( f"tmp{FixtImg.fbArN2}", bFirst)
        MN3, dmy = LoadCollHist( f"tmp{FixtImg.fbArN3}", bFirst)
        
        # --------------- Append to Collection --------------------

        # the fabric format has the same format as the spatial histograms, which is
        # simply saved as a matrix, hence we use the SaveCollHistXXXX functions.
        
        # ----- init before 1st image -----
        if i==0:
            SaveCollHistInit( nImg, MN0.size, FinaColl.fbn0)
            SaveCollHistInit( nImg, MN1.size, FinaColl.fbn1)
            SaveCollHistInit( nImg, MN2.size, FinaColl.fbn2)
            SaveCollHistInit( nImg, MN3.size, FinaColl.fbn3)
        
        # -----  append  -----
        SaveCollHistApnd( MN0, FinaColl.fbn0)
        SaveCollHistApnd( MN1, FinaColl.fbn1)
        SaveCollHistApnd( MN2, FinaColl.fbn2)
        SaveCollHistApnd( MN3, FinaColl.fbn3)
        
        # --- progress dots
        if i % stepDot == 0:
            print('.', end='', flush=True)
        
        
    print(f"\n{IxImg[0]}-{IxImg[-1]} done")
    

    
