"""

Manipulations of the collection matrix and label array. Serves as preparation for
training a classifier.


---------------   DEF SUM   ---------------
def u_CollSelLev( COLLVEC, CollLab, low, hih ):

def u_CollMLtoLstSel( COLLVEC, CollLab, IxImg ):

def u_CollMxToLstByLab( MX, LbAct, LbExp ):

// ----------   Adjustement   ----------
def u_CollAdjAtt( VEC, dty, adj=None, nSel: int=0 ):
def u_CollAdjAttPos( VEC, dty, adj=None, nSel: int=0 ):

"""
import numpy as np

import AdminPy.Util as ut
from AdminPy.Orga import *
from AdminPy.DescExtr.OrgAtt.OrgAtts import *
from AdminPy.DescExtr.OrgAtt.AttManip import *
from AdminPy.DescExtr.Vect.VmxManip import *



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollSelLev   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Select levels from low to hih.

"""
def u_CollSelLev( COLLVEC, CollLab, low, hih ):

    LbLev    = CollLab[:,0]

    Blev     = (LbLev >= low) & (LbLev <= hih)

    COLLVEC  = COLLVEC[Blev,:]
    CollLab  = CollLab[Blev,:]

    return COLLVEC, CollLab


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollMLtoLstSel   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Selects images from collection matrix COLLVEC and from label array CollLab, and
returns them as list.

"""
def u_CollMLtoLstSel( COLLVEC, CollLab, IxImg ):

    ntDsc,  nAtt = COLLVEC.shape
    ntDsc2, nAsp = CollLab.shape
    nImg         = len(IxImg)

    assert ntDsc==ntDsc2, f"Arrays dont have same length {ntDsc} <> {ntDsc2}"
    
    LbImg    = CollLab[:,1]

    aRng, nImF, LbFnd = ut.ixr_BlockFind( LbImg, IxImg )

    #assert nImg==nImF, f"found only {nImF} in LbImg - instead of {nImg}"
    if nImg!=nImF:
        aRng       = ut.ixr_BlockInsEmp( aRng, LbFnd, IxImg )

    AVEC     = [None]*nImg
    ALab     = [None]*nImg
    for i in range(nImg):

        if aRng[i].size > 0:
            AVEC[i] = COLLVEC[ aRng[i],:]
            ALab[i] = CollLab[ aRng[i],:]
        else:
            AVEC[i] = np.empty( (0,nAtt), dtype=COLLVEC.dtype )
            ALab[i] = np.empty( (0,nAsp), dtype=CollLab.dtype )

    return AVEC, ALab


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollMxToLstByLab   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Reshapes collection matrix to list according to label array LbAct. If not all are
found - given expected labels in LbExp - then we create empty matrices.

Assumes order in LbAct and LbExp is same.

"""
def u_CollMxToLstByLab( MX, LbAct, LbExp ):

    ntDsc,  nAtt = MX.shape
    ntDsc2       = len(LbAct)

    assert ntDsc==ntDsc2, f"Arrays dont have same length {ntDsc} <> {ntDsc2}"

    aRng, nBlk, UnqAct = ut.ixr_Block( LbAct )
    nAct       = len( UnqAct )

    UnqExp     = np.unique( LbExp )
    nExp       = len( UnqExp )

    assert nExp>=nAct, f"label mismatch: more labels present {nAct} than expected {nExp}"

    #if nExp>nLbAct:
     #   nMiss  = nExp-nLbAct
      #  print(f"{nMiss} labels missing - will be empty matrices")

    aFll     = ut.ixr_BlockInsEmp( aRng, UnqAct, UnqExp )
        
    AVEC     = [np.empty( (0,nAtt), dtype=MX.dtype) for _ in range(nExp)]
    for i in range(nExp):

        if aRng[i].size > 0:
            AVEC[i]  = MX[ aRng[i],:]

    return AVEC


# --------------------------------------------------------------------------------
#                               A D J U S T M E N T
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollAdjAtt   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Adjust collection matrix for individual desctypes, ie suitable for DeepSets.

"""
def u_CollAdjAtt( VEC, dty, adj=None, nSel: int=0 ):

    nAttIn = VEC.shape[1]
    
    LBATT  = o_AttsLabels()
    IXATT  = o_AttIxAsFields( LBATT )
    
    if dty in ("skl", "cnt"):

        VEC, Jatt = o_AttCntOriExpand( VEC )

    elif dty=="frm":

        # default:
        Jatt   = dclsAttInfo( Lb=LBATT.Frm, Ix=IXATT.Frm ) # copy

        if adj=='ess':
            Rng     = np.arange(0,nSel)
            VEC     = VEC[:,Rng]
            Jatt.Lb = [ Jatt.Lb[int(i)] for i in Rng.tolist() ]
            Jatt.Ix = u_AttIxAsFields( Jatt.Lb)
        else:
            dmy = 0
            # take vectors as they are
        

    elif dty=="str":

        VEC, Jatt = o_AttDscOriExpand( VEC, LBATT.Str )        

    elif dty=="arc":

        Jatt   = dclsAttInfo( Lb=LBATT.Arc, Ix=IXATT.Arc ) # copy
        # take vectors as they are
        
    else:
        
        raise NotImplementedError(f"dty {dty} not implemented")

    # ----------   Verify & Disp   ----------
    nAttNew = VEC.shape[1]
    print( f"Adjusted nAtt from {nAttIn} to {nAttNew}" )
    nAttJ   = len(Jatt.Lb)
    
    assert nAttNew==nAttJ, f"attribute mismatch: new {nAttNew} vs {nAttJ}"
    
    return VEC, Jatt



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollAdjAttPos   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Adjust collection matrix for individual desctypes and returns position separately,
ie suitable for position 'injection' in transformers.

"""
def u_CollAdjAttPos( VEC, dty, adj=None, nSel: int=0 ):

    nAttIn = VEC.shape[1]

    LBATT  = o_AttsLabels()
    
    if dty in ("skl", "cnt"):

        VEC, POS, Jatt = o_AttCntPosSep( VEC )

    elif dty=="frm":

        # default:
        VEC, POS, Jatt = o_AttFrmPosSep( VEC )

        if adj=='red':
            Rng     = np.arange(0,nSel)
            VEC     = VEC[:,Rng]
            Jatt.Lb = [ Jatt.Lb[int(i)] for i in Rng.tolist() ]
            Jatt.Ix = u_AttIxAsFields( Jatt.Lb )
        else:
            dmy = 0
            # take vectors as they are


    elif dty=="str":

        # verified already?
        VEC, POS, Jatt = o_AttStrPosSep( VEC )

#    elif dty=="arc":

 #       VEC, POS, Jatt = o_AttStrPosSep( VEC )
        
    else:
        
        raise NotImplementedError(f"dty {dty} not implemented")

    # ----------   Verify & Disp   ----------
    nAttNew = VEC.shape[1]
    print( f"Adjusted nAtt from {nAttIn} to {nAttNew} (excl pos)" )
    nAttJ   = len(Jatt.Lb)
    
    assert nAttNew==nAttJ, f"attribute mismatch: new {nAttNew} vs {nAttJ}"

    return VEC, POS, Jatt




