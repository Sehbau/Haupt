"""

Generating registers. A register is a list of filenames saved as text file.


def o_RegistFileNames():

def o_RegistGen( fist, IxImg, ext, nameFrmt=0 ):
def o_RegistGenAndSave( pthStem, IxImg, ext, fpRegist, nameFrmt=0, bDispSave=0 ):
def o_RegistSetSave(     RgstFp, pthDsc,  fist, IxImg, Fixt, nameFrmt=0 ):
def o_RegistSetSaveDtop( RgstFp, pthDtop, fist, IxImg, Fixt, nameFrmt=0 ):

def v_RegistValid( fpRgst: str ) -> bool:

"""
import os
from dataclasses import dataclass
from AdminPy.Orga.SaveFipaLst import *
from AdminPy.Util.FileIO.LoadData import *
from pathlib import Path



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class dclsRgstFileNames:
    """ Struct holding register filenames.
    """
    dsc:  str = 'RefDsc.txt' 
    hst:  str = 'RefHst.txt' 
    kol:  str = 'RefKol.txt' 
    slc:  str = 'RefSlc.txt' 

    dtop: str = 'RefDtop.txt'



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_RegistFileNames   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Filenames for registers.

"""
def o_RegistFileNames():

    return dclsRgstFileNames


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_RegistGen   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Generates a register, a list of descriptor filenames. No verification of
their existence.

ai runMvecColl.m, runMhstKnn.m
sa SaveFipaXXX, SaveFinaXXX, SaveRegistFoc.m

sa o_RegistAnf.h
cf o_RegistCatgWise.m

IN  fist      filestem or path+filestem
    IxImg     image indices
    ext       extension
    nameFrmt  name format: none, or with leading zeros
     
OUT aLin      list of file paths as string (not a field)

"""
def o_RegistGen( fist, IxImg, ext, nameFrmt=0 ):

    aLin = []
    
    for ixi in IxImg:

        if nameFrmt == 0:                       # --- plain numbers
            fname = f"{fist}{ixi}{ext}"

        elif nameFrmt == 7:                     # --- leading zeros, width=7
            fname = f"{fist}{ixi:07d}{ext}"

        else:
            raise ValueError(f"nameFrmt={nameFrmt} not implemented.")
        
        aLin.append(fname)
    
    return aLin


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_RegistGenAndSave   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

  Generates a register, verifies that it is valid (all files exist) and saves it.

  ai iclDscx.m, runMvecXXX.m, runMhstKnn.m
  sa SaveFipaXXX, SaveFinaXXX

  IN  pthStem   path to be preprended
      IxImg     image indices
      ext       extension
      fpRegist  file path of register
      nameFrmt  format of numbering
    
  OUT bAllFilesExist  flag if file list complete (0 not complete)
"""
def o_RegistGenAndSave( pthStem, IxImg, ext, fpRegist, nameFrmt=0, bDispSave=0 ):

    aFipaDsc = o_RegistGen( pthStem, IxImg, ext, nameFrmt )  # above

    SaveFipaLst( aFipaDsc, fpRegist )
    #SaveTextLines( aFipaDsc, fpRegist )

    bAllFilesExist = v_RegistValid( fpRegist ) # below

    if not bAllFilesExist:
        print('WWWWWWarning: not all files present')
        #breakpoint()
        
    #if bDispSave:
     #   DispSave( fpRegist )

    return bAllFilesExist
     
    
""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_RegistSetSave   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Generates the registers for a set of representation formats, namely
kolumn, histogram and vector (descfile).

cf lvngRunMcsc.m
sa o_RegistAnf.h

IN  RgstFp    register filepaths
    pthDsc    path of descriptions
    fist      filestem or path+filestem
    IxImg     image indices
    Fixt      extensions
    nameFrmt  name format: none, or with leading zeros
     
OUT R         register info for dsc files

"""
def o_RegistSetSave( RgstFp, pthDsc, fist, IxImg, Fixt, nameFrmt=0 ):

    @dataclass
    class Rdsc:
        pass    
    
    # generate file lists
    aDsc = o_RegistGen( fist, IxImg, Fixt.dsc, nameFrmt)
    SaveFipaLstPrependPath( aDsc, pthDsc, RgstFp.dsc )

    aHst = o_RegistGen( fist, IxImg, Fixt.hsti, nameFrmt)
    SaveFipaLstPrependPath( aHst, pthDsc, RgstFp.hst )

    aKol = o_RegistGen( fist, IxImg, Fixt.kolm, nameFrmt)
    SaveFipaLstPrependPath( aKol, pthDsc, RgstFp.kol )

    aKol = o_RegistGen( fist, IxImg, Fixt.kolm, nameFrmt)
    SaveFipaLstPrependPath( aKol, pthDsc, RgstFp.kol )

    Rdsc.aFipaDsc =  aDsc
    Rdsc.pth      =  pthDsc

    return Rdsc


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_RegistSetSaveDtop   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO


Generates the registers for top description (.dtop)
     
"""
def o_RegistSetSaveDtop( RgstFp, pthDtop, fist, IxImg, Fixt, nameFrmt=0 ):

    @dataclass
    class R:
        pass    
    
    # generate file lists
    aDtop = o_RegistGen( fist, IxImg, Fixt.dtop, nameFrmt)
    SaveFipaLstPrependPath( aDtop, pthDtop, RgstFp.dtop )

    R.aFipaDtop =  aDtop
    R.pth       =  pthDtop

    return R



""" VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV   v_RegistValid   VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

Verifies that the register contains filenames that exist.

"""
def v_RegistValid( fpRgst: str ) -> bool:

    aLst, cLin  = LoadTextLinewise(fpRgst)
    bExist      = True
    cNot        = 0

    for path in aLst:

        if not os.path.isfile(path):
            if bExist:
                print("Does not exist:")
            bExist = False
            print(path)
            cNot += 1

    if cNot > 0:
        print(f"Warning: {cNot} files do not exist")

    return bExist    

    
