"""

Processing on collections (or lists) of images.

"""
from .IclAdmin import *
from .IclFold import *
from .IclProc import *

from .Collection import *

from .LoadCollVec import *
from .LoadCollHist import *
from .LoadCollTxtr import *

from .CollManip import *

from .Register import *




