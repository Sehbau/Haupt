"""

---------------   DEF SUM   ---------------
def LoadCollTxtg( FinaColl ):
def f_CollTxtrStats( C ):

def u_TxtrGramGridCollReshape( MX, szG, nTxtBis, nrm=None):

def PlotCollTxtrStats(C, figNo=1):
"""
import numpy as np
from dataclasses import dataclass
import matplotlib.pyplot as plt

from AdminPy.Util.Stats.Stats import *
from AdminPy.Util.FileIO.LoadData import *
from AdminPy.DescExtr.Texture import u_TxtrGramGridArrToMtrx

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollTxtg   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the collected texturegrams. In analogy to LoadCollTxtg.m

"""
def LoadCollTxtg( FinaColl ):

    @dataclass
    class TXTR:
        pass

    @dataclass
    class Hed:
        pass    
    
    TXTR.GST, Hed.Gs = LoadBankVec( FinaColl.txgs )
    TXTR.GRD, Hed.Gg = LoadBankVec( FinaColl.txgg )
    TXTR.BND, Hed.Gb = LoadBankVec( FinaColl.txgb )

    return TXTR, Hed



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_CollTxtrStats   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

cf plcCollTxtg.py
"""
def f_CollTxtrStats( C ):

    @dataclass
    class S:
        pass

    S.Gst   = f_MtrxColStat( C.GST )
    S.Bnd   = f_MtrxColStat( C.BND )
    S.Grd   = f_MtrxColStat( C.GRD )

    return S


""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotCollTxtrStats   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

cf plcCollTxtg.py
"""
from AdminPy.Orga import o_TxtrLabels

def PlotCollTxtrStats(C, figNo=1):

    Lb = o_TxtrLabels()

    fig = plt.figure(figNo)
    plt.clf()

    nr, nc = 3, 1

    # ---- Subplot 1 ----
    ax1 = plt.subplot(nr, nc, 1)
    ax1.bar(np.arange(len(C.Gst.Men)), C.Gst.Men)
    ax1.set_title("Gst")
    ax1.grid(True, axis='y')
    ax1.set_yticks(np.arange(0, 0.9, 0.1))
    ax1.set_ylim([0, 0.85])
    ax1.set_xticks( np.arange(Lb.nLab))
    ax1.set_xticklabels(Lb.aSho)

    # ---- Subplot 2 ----
    ax2 = plt.subplot(nr, nc, 2)
    ax2.bar(np.arange(len(C.Grd.Men)), C.Grd.Men)
    ax2.set_title("Grid")

    # ---- Subplot 3 ----
    ax3 = plt.subplot(nr, nc, 3)
    ax3.bar(np.arange(len(C.Bnd.Men)), C.Bnd.Men)
    ax3.set_title("Band")

    plt.tight_layout()
    plt.show(block=False)
    plt.pause(.01)


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_TxtrGramGridCollReshape   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

cf plcCollTxtg.py
"""
def u_TxtrGramGridCollReshape( MX, szG, nTxtBis, nrm=None):

    MX  = np.asarray(MX)       # ensure Arr is a NumPy array for proper indexing

    nImg, nFet = MX.shape

    NM = np.zeros((nImg, nFet), dtype=np.float32)
    for i in range(0, nImg):

        Mx      = u_TxtrGramGridArrToMtrx( MX[i,:], szG, 7, nrm )
        NM[i,:] = Mx.flatten()

    return NM

    
