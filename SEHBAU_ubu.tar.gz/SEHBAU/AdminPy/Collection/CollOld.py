"""

Early material of CollManip.py

"""

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollMxToLstByLabV1   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Reshapes collection matrix to list according to labels in Lb.

!!!! Assumes every label is present in MX.

"""
def u_CollMxToLstByLabV1( MX, Lb ):

    ntDsc,  nDim = MX.shape
    ntDsc2       = len(Lb)

    assert ntDsc==ntDsc2, f"Arrays dont have same length {ntDsc} <> {ntDsc2}"
    
    IxChng   = np.where( np.diff(Lb) != 0 )[0] + 1     # Find where the value changes
    nBlk     = len(IxChng)+1
    Rng      = np.arange( ntDsc )
    aRng     = np.split( Rng, IxChng )
    
    AVEC     = [None]*nBlk
    for i in range(nBlk):

        AVEC[i] = MX[ aRng[i],:]

    return AVEC


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollMLtoLstSelSlow   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Too slow for large collections.

"""
def u_CollMLtoLstSelSlow( COLLVEC, CollLab, IxImg ):

    nImg     = len(IxImg)
    
    LbImg    = CollLab[:,1]

    AVEC     = [None]*nImg
    ALab     = [None]*nImg

    for i in range(0,nImg):

        Bimg    = LbImg==IxImg[i] # too expensive

        AVEC[i] = COLLVEC[Bimg,:]
        ALab[i] = CollLab[Bimg,:]

    return AVEC, ALab


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollMLtoLstSelLevV1   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Same as u_CollMLtoLstSel, but includes level selection

Deprecated. To slow

"""
def u_CollMLtoLstSelLevV1( COLLVEC, CollLab, IxImg, low, hih ):

    nSel     = len(IxImg)
    
    LbLev    = CollLab[:,0]
    LbImg    = CollLab[:,1]

    AVEC     = [None]*nSel
    ALab     = [None]*nSel

    for i in range(0,nSel):

        Bimg    = LbImg==IxImg[i] # too expensive

        VECI    = COLLVEC[Bimg,:]
        LabI    = CollLab[Bimg,:]

        LevI    = LabI[:,0]

        Blev    = (LevI >= low) & (LevI <= hih)

        AVEC[i] = VECI[Blev,:]
        ALab[i] = LabI[Blev,:]

    return AVEC, ALab




