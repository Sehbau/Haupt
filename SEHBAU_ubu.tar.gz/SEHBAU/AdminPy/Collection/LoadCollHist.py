"""

Loading collection histograms.

------------------------------   CLS SUM   ------------------------------
class DescBinNum:

------------------------------   DEF SUM   ------------------------------
def ReadDescBinNum(fileID):

def LoadCollHist(pthFile):

def LoadCollFbrcMaps( FinaColl, bDispLoad: int=1 ):
def LoadCollFbrcHyko( FinaColl, fSet: int=0, bDispLoad: int=1 ):

def u_HspaSel( H, Nbin, sel ):

"""
from pathlib import Path
from dataclasses import dataclass
import numpy as np

from AdminPy.Orga import OrgFileNames
from AdminPy.DescExtr.Hist.DescBinAnf import *
from AdminPy.DescExtr.Hist.LoadHist import *
from AdminPy.Util.FileIO.LoadData import LoadBankVec



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class bnumHistImg:
    """
    Bin numbers: used for loading the collection in LoadCollHist (ReadDescBinNum.m)
    """
    Tot: np.ndarray

    FltUni: np.ndarray
    FltBiv: np.ndarray
    SpaUni: np.ndarray
    SpaBiv: np.ndarray

    CntUni: np.ndarray
    RsgUni: np.ndarray
    ArcUni: np.ndarray
    StrUni: np.ndarray

    shpUni: int
    shpBiv: int
    ttrgUni: int
    ttrgBiv: int
    bndgUni: int
    bndgBiv: int



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

def read_int16(fileID) -> int:
    """Reads a single int16 from a binary file and returns a Python int."""
    return np.fromfile(fileID, dtype=np.int16, count=1).item()

def read_int32(fileID) -> int:
    """Reads a single int32 from a binary file and returns a Python int."""
    return np.fromfile(fileID, dtype=np.int32, count=1).item()




    
""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescBinNum   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the descriptor bin numbers as saved in C under w_DescBinNum.

"""
def ReadDescBinNum(fileID):

    def read_int(n):
        return np.fromfile(fileID, dtype=np.int32, count=n)

    def read_uint8(n):
        return np.fromfile(fileID, dtype=np.uint8, count=n).astype(np.int32)

    # ---------- Total ----------
    Tot    = read_int(4)

    # ---------- Hist Type ----------
    FltUni = read_int(7)
    FltBiv = read_int(7)
    SpaUni = read_int(7)

    SpaBiv = read_int(2)
    SpaBiv = np.concatenate([SpaBiv, [0, 0, 0]])

    # ---------- Individual DescTypes ----------
    sep = read_int(1)[0]
    assert sep == -1
    CntUni = read_int(4)

    sep = read_int(1)[0]
    assert sep == -1
    RsgUni = read_int(13)

    sep = read_int(1)[0]
    assert sep == -1
    ArcUni = read_uint8(8)

    sep = read_int(1)[0]
    assert sep == -1
    StrUni = read_int(4)

    sep = read_int(1)[0]
    assert sep == -1
    shpUni = read_int(1)[0]
    shpBiv = read_int(1)[0]

    sep = read_int(1)[0]
    assert sep == -1
    ttrgUni = read_int(1)[0]
    ttrgBiv = read_int(1)[0]

    bndgUni = read_int(1)[0]
    bndgBiv = read_int(1)[0]

    # ---------- Trailer ----------
    idfEof = read_int(1)[0]
    assert idfEof == 444

    return bnumHistImg(
        Tot, FltUni, FltBiv, SpaUni, SpaBiv,
        CntUni, RsgUni, ArcUni, StrUni,
        shpUni, shpBiv, ttrgUni, ttrgBiv,
        bndgUni, bndgBiv
    )


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollHist   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads a matrix of histograms, [nImg ntBin], as collected with program
collhimg. 

As saved in C under E_DESC/CollHist/CollHistIO.h-s_CollHist().

Flat histograms not impl. yet

"""
def LoadCollHist( pthFile, bDisp: bool=None ):

    if bDisp is None:
        bDisp = True
        
    pthP = Path( pthFile )
    pth  = str( pthP.parent )   # directory path
    nam  = pthP.stem            # filename without the LAST extension
    ext  = pthP.suffix          # the last extension ('.hst')

    Fixt = OrgFileNames.o_FileExtensColl()

    bFull = (ext == Fixt.hsall)  # full, as from dscx
    bFlat = (ext == Fixt.hsflt)  # flat, as from dbin
    bSpat = (ext == Fixt.hsspa)  # spatial, as from dbin

    bFbAk = "fbArK" in ext       # SINGLE IMAGE fabric kolumns as array
    bFbAn = "fbArN" in ext       # SINGLE IMAGE fabric num (count) maps as array
    bFbHy = "fbk" in ext         # collected fabric hyperkolumns
    bFbNm = "fbn" in ext         # collected fabric numerosity maps

    with open(pthFile, "rb") as f:

        if bDisp:
            print(f"Loading {pthFile} ", end="")

        # ------- Header (Size) -------
        nImg = np.fromfile(f, dtype=np.int32, count=1)[0]
        nBin = np.fromfile(f, dtype=np.int32, count=1)[0]

        if bDisp:
            print(f"[{nImg:4d} {nBin:5d}]...", end="")

        # ------- Data Matrix -------
        # from integer to float
        HST = np.fromfile(f, dtype=np.int32, count=nImg * nBin).astype(np.float32)

        # MATLAB: reshape(HST, nBin, nImg)'
        HST = HST.reshape((nImg, nBin))

        # ------- BinNumbers -------
        if bFull:
            Nbin = ReadDescBinNum(f)            # is above
        elif bFlat:
            printf("not impl. yet")
            breakpoint()

        elif bSpat:
            Nbin = ReadBnumSpat(f)

        elif bFbAk:
            
            Nbin = bnumSpaClw                     # DescBinAnf.py
            if ext=='.fbArK0':
                Nbin.nCells      = 9
            elif ext=='.fbArk1':
                Nbin.nCells      = 49
            elif ext=='.fbArk2':
                Nbin.nCells      = 15*15
            elif ext=='.fbArk3':
                Nbin.nCells      = 31*31

            Nbin.nBinPerCell = int( nBin / Nbin.nCells )
            
        elif bFbHy or bFbAn or bFbNm:
            Nbin = nBin
        else:
            print( 'LoadCollHist: Nbin not implemented' )
            
        if bDisp:
            print("done.")

    # -------- Verify --------
    if bFull:
        ntBin = np.sum(Nbin.Tot)
        nDim  = HST.shape[1]

        if ntBin != nDim:
            print(
                f"WARNING LoadCollHist: sum of bin numbers {ntBin} != dims of histogram {nDim}"
            )

    return HST, Nbin



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollFbrcMaps   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL


 Loads the collected fabric maps. For hyper-kolumns we use LoadCollHist.m

 af LoadCollTxtr.m
 cf iclCollFbrc.m, cfHstEss.m

 IN  FinaColl   struct with filenames as generated in o_FileNameColl.m

"""
def LoadCollFbrcMaps( FinaColl, bDispLoad: int=1 ):

    @dataclass
    class F:
        pass
    
    @dataclass
    class Hed:
        pass
    
    F.L0, Hed.L0   = LoadBankVec( FinaColl.fbm0, bDispLoad )
    F.L1, Hed.L1   = LoadBankVec( FinaColl.fbm1, bDispLoad )
    F.L2, Hed.L2   = LoadBankVec( FinaColl.fbm2, bDispLoad )
    F.L3, Hed.L3   = LoadBankVec( FinaColl.fbm3, bDispLoad )
    
    return F, Hed



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollFbrcHyko   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

 Loads the collected fabric hyperkolumns.

 By default it loads the collection of the smallest layer only (zero-index
 3). The collection size might be too large to be loaded, in particular
 for the largest layer (zero-index 0).

"""
def LoadCollFbrcHyko( FinaColl, fSet: int=3, bDispLoad: int=1 ):

    if fSet==0:
        HYK, Nbin = LoadCollHist( FinaColl.fbk0, bDispLoad ) # very large!!
    elif fSet==1:
        HYK, Nbin = LoadCollHist( FinaColl.fbk1 )
    elif fSet==2:
        HYK, Nbin = LoadCollHist( FinaColl.fbk2 )
    elif fSet==3:
        HYK, Nbin = LoadCollHist( FinaColl.fbk3 ); # the smallest one
    else:
        print( f'fSet {fSet} not possible' )
        breakpoint()
                
    return HYK, Nbin


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollFbrcMnum   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

 Loads the collected fabric numerosity maps.

 By default it loads the collection of the smallest layer only (zero-index
 3). The collection size might be too large to be loaded, in particular
 for the largest layer (zero-index 0).

"""
def LoadCollFbrcMnum( FinaColl, fSet: int=3, bDispLoad: int=1 ):

    if fSet==0:
        MNM, nDty = LoadCollHist( FinaColl.fbn0, bDispLoad )  # the 31x31 layer
    elif fSet==1:
        MNM, nDty = LoadCollHist( FinaColl.fbn1 )
    elif fSet==2:
        MNM, nDty = LoadCollHist( FinaColl.fbn2 )
    elif fSet==3:
        MNM, nDty = LoadCollHist( FinaColl.fbn3 ) 
    else:
        print( f'fSet {fSet} not possible' )
        breakpoint()
        
    return MNM, nDty



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_HspaSel   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Selects a subset of the spatial histograms, based on a specified label.

"""
def u_HspaSel( H, Nbin, sel ):

    nCll     = Nbin.nCells;
    nBpC     = Nbin.nBinPerCell;

    if sel=='cnt':
        IxB   = np.arange( Nbin.Cnt.tot )
        nRed  = len(IxB)

    SHF  = np.repeat(np.arange(nCll) * nRed, nRed).reshape(-1, nRed).T
    IXB  = np.repeat(IxB[:, np.newaxis], nCll, axis=1)
    IXS  = SHF + IXB
    IxS  = IXS.flatten(order='F')

    H    = H[:, IxS]

    Nbin.nBinPerCell = nRed
    Nbin.ntBin       = nRed*nCll
        
    return H, Nbin







    
