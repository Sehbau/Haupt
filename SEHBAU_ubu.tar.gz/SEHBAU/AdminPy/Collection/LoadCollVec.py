"""

Loading and segregating collection data.

LoadCollVecXXX: Loads collection matrices and labels, the vector matrices of
individual images as collected with executable 'collvec'.

u_CollVecSelcXXX: Selects images and returns them as lists of vector matrices (for
individual images), ie. for application to the collation functions of neural
networks.


---------------   DEF SUM   ---------------

def LoadCollVec( lfpStem: str | Path, dscTyp: str ) -> tuple[np.ndarray, int, int]:
def LoadCollVecLab(lfpStem: str | Path, dscTyp: str) -> tuple[np.ndarray, int]:

# ----------   Wrapper   ----------
def LoadColcDty( pth: Path, dty: str, bDisp: int=0 ) -> collDSCTYP:

Elsewhere:
- histogram in LoadHist.py (image & collection)

"""
from pathlib import Path
from dataclasses import dataclass
import numpy as np
from collections import defaultdict

from AdminPy.Orga import OrgFileNames
import AdminPy.Util as ut
from AdminPy.Collection import *
from AdminPy.Collection.CollManip import *


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
"""
@dataclass
class dimGrid:
# ""
#    Dimensions of grid. N of vertical times N of horizontal cells (units)
# ""
    ver: int
    hor: int
"""



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollVec   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads collected vectors (of MULTIPLE images) as saved under collVec.cpp.

sa LoadDescVect.m, LoadVecColl.m

Example in exsbCollVec.m
"""
def LoadCollVec( lfpStem: str | Path, dscTyp: str, bDisp: int=1 ) -> tuple[np.ndarray, int, int]:

    pthStm = Path(lfpStem)
    #lfp    = pthStm.parent / f"{pthStm.name}VEC_{dscTyp}.txt"
    lfp    = pthStm / f"VEC_{dscTyp}.txt"

    if bDisp:
        print( f"Loading {lfp}...", end="" )
    
    try:
        with open(lfp, "r") as fp:
            VEC = np.fromstring( fp.read(), dtype=np.float32, sep=" ")
        #VEC = np.fromfile(lfp, dtype=np.float32, sep=" ")   slow
    except FileNotFoundError:
        raise FileNotFoundError(f"could not find {lfp}")

    # In Python, an empty file or failed parsing returns an empty array
    if VEC.size == 0:
        raise IOError(f"Could not read data or file is empty: {lfp}")

    # DispLoad(lfp); # Assuming this is a custom print/log function from your framework

    # -------   Last array entry contains ntDsc   -------
    # In Python, negative index -1 targets the last element safely
    ntDsc = int(VEC[-1])

    if bDisp:
        print(f"ntDsc {ntDsc}, ", end="")

    # -------    Reshape   -------
    VEC = VEC[:-1]  # exclude the last array entry (slices out the last item)

    # MATLAB reshapes column-wise, whereas NumPy defaults to row-wise (C-order).
    # To match MATLAB's column-major ordering, we use order='F' (Fortran order).
    VEC = VEC.reshape((-1, ntDsc), order="F")
    VEC = VEC.T  # Transpose the matrix

    nDim = VEC.shape[1]

    if bDisp:
        print(f"matrix is [{ntDsc} {nDim}].")

    return VEC, ntDsc, nDim



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollVecLab   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads labels for a collection as saved under 'collvec.exe'

Label array is [ntDsc 3] with columns corresponding to level, image and
last column is empty.

af LoadCollVec.m
"""
def LoadCollVecLab(lfpStem: str | Path, dscTyp: str, bDisp: int=1 ) -> tuple[np.ndarray, int]:

    # Ensure lfpStem is a Path object and insert platform-specific slash
    pthStm  = Path(lfpStem)
    lfp     = pthStm / f"Lab_{dscTyp}.txt"

    try:
        with open(lfp, "r") as fp:
            LAB = np.fromstring( fp.read(), dtype=np.int32, sep=" ")
        #LAB = np.fromfile(lfp, dtype=np.int32, sep=" ")
    except FileNotFoundError:
        raise FileNotFoundError(f"could not find {lfp}")

    if LAB.size == 0:
        raise IOError(f"Could not read data or file is empty: {lfp}")

    # DispLoad(lfp);

    # -------    reshape   -------
    nLabTyp = 3

    # MATLAB reshapes column-wise, so we use order='F' (Fortran order).
    # nLabTyp is the row count during reshape, matching MATLAB's reshape(LAB, 3, [])
    LAB = LAB.reshape((nLabTyp, -1), order="F")
    LAB = LAB.T

    # -------    stats   --------
    ntDsc = LAB.shape[0]

    if bDisp:
        print(f"Label array is of size [{ntDsc} {nLabTyp}].")

        # NumPy's unique() returns sorted unique values, matching MATLAB behavior
        IxLev = np.unique(LAB[:, 0])
        IxImg = np.unique(LAB[:, 1])
        # IxCat   = np.unique( LAB[:,2] )
        
        print(f"Levels from {IxLev[0]} to {IxLev[-1]} (zero-indexing)")
        print(f"Images from {IxImg[0]} to {IxImg[-1]} (  \"     \"    )")
        # print(f"Categories from {IxCat[0]} to {IxCat[-1]}")

    return LAB, ntDsc



# --------------------------------------------------------------------------------
#
#                                 W R A P P E R
#
# --------------------------------------------------------------------------------

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollDty   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Calls the above functions for loading a descriptor type.
"""
def LoadCollDty( pth: Path, dty: str, bDisp: int=1 ) -> collDSCTYP:

    CL  = collDSCTYP()
    CL.VEC, ntDsc, nAtt = LoadCollVec(    pth, dty, bDisp>3 )
    CL.Lab, ntDsc2      = LoadCollVecLab( pth, dty, bDisp>3 )

    nAsp  = CL.Lab.shape[1]
    
    assert ntDsc==ntDsc2, f"Not same ntDsc: VEC {ntDsc} <> Lab {ntDsc2}"
    assert nAsp==3, f"Label array has dim= {nAsp}. Expected 3"

    CL.ntDsc  = ntDsc
    CL.nAtt   = nAtt
    CL.dty    = dty

    # -----  Statistical Info  -----
    IxLev = np.unique(CL.Lab[:,0])
    IxImg = np.unique(CL.Lab[:,1])

    nLev  = len(IxLev)
    nImg  = len(IxImg)
    
    mxnDsc, MxnDsc  = u_CollDscCount( CL.Lab )

    CL.Sts.mxnDsc   = mxnDsc
    CL.Sts.nLev     = nLev
    CL.Sts.nImg     = nImg
    CL.Sts.MxnDscLev = MxnDsc

    if bDisp:
        print( f"Loaded {dty}  ntDsc {ntDsc:7d}   nAtt {nAtt}   nLev {nLev}   "
               f"Levs {IxLev[0]}-{IxLev[-1]}   Imgs {IxImg[0]}-{IxImg[-1]}   "
               f"mxnDsc {mxnDsc}"
              )

    return CL
    
    
