"""

Scripts carrying out processes (executables) for an image collection.

def DSCX( aImg, fipaDscx, Pths, Args )
def DTOP() to be implemented, see plcDtop.py
def DBIN() to be implemented, see plcDproc.py

"""
import subprocess
import AdminPy.Util as sbUt
from AdminPy.Util import v_CmndExec 

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   DSCX   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Descriptor extraction for a collection (a list of images).

"""
def DSCX( aImg, fipaDscx, dirDsc, Args ):

    for fipaImg in aImg:

        fipsOut = dirDsc / fipaImg.stem

        #            arg0      arg1     arg2      arg3          arg4
        cmnd   = [ fipaDscx, fipaImg, fipsOut, Args.fpPrm ] + Args.opt

        #print( cmnd )

        Res    = subprocess.run( cmnd, shell=True, capture_output=True, text=True)

        sbUt.v_CmndExec( Res )
        
        sbUt.printDotProg()

    return 0


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   DBIN   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Binning for a collection (a list of images).

see plcDproc.py

"""
def DBIN( ):

    return 0
