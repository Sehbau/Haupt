"""

Organization of attributes

"""
from dataclasses import dataclass

@dataclass
class dclsTxtrLabels:
    """
    Blob labels. Set with o_TxtrLabels() below
    """
    aSho: list[str]
    aLon: list[str]
    nLab:    int

    

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_TxtrLabels   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Blob labels.
 
They are also used in ReadBlobMapGlbSts.m (but NOT passed as variable).

They must match with CntTxtAnf.h, w_CntTXTbis (CntTxtIO.h)

ia 

"""
def o_TxtrLabels():

    # NB NVHAU
    aSho = ['Num', 'Blk', 'Nil', 'Vrt', 'Hor', 'Axi', 'Uni']

    aLon = [
        'Num (count)',
        'Blank (void)',
        'Nil (no ori)',
        'Vertical',
        'Horizontal',
        'Axial (vrt&hor)',
        'Uni (1 ori)',
        'Ken (contrast)',
        'Bunt'
    ]

    nLab = len( aSho );

    return dclsTxtrLabels( aSho=aSho, aLon=aLon, nLab=nLab )



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_AttLabArrToList   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Used below for converting a single array of labels (string) into a list

"""
def u_AttLabArrToList( labStr ):

    nChar = len(labStr)

    if nChar % 6 != 0:
        print("Input string:", repr(labStr))
        raise ValueError("Label array must be multiple of 6 characters.")

    aLbs = []
    for i in range(0, nChar, 6):
        lab = labStr[i:i+6].strip()             # trim spaces
        aLbs.append(lab)

    return aLbs    
    #return labStr.strip().split()


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttsLabels   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

see o_AttsLabels.m

"""
def o_AttsLabels():

    lbsGen  = ['vpo', 'hpo', 'red', 'grn', 'blu']

    @dataclass
    class LB:
        pass
    
    # ----------   Contour   ----------
    LB.Cnt = ['len', 'str', 'ori', 'vpo', 'hpo', 'red', 'grn', 'blu']
    LB.Skl = LB.Cnt

    # ----------   Form   ----------
    radi = ['rad',  'cir',  'eloR', 'eloF', 'bulk',   'bs1', 'bs2', 'bs3', 'bs4', 'bs5',
            'star', 'dent', 'vpo',  'hpo',  'red',    'grn', 'blu' ]
    aspa = u_AttLabArrToList('AreN  HgtN  WthN  High  Wide  Higv  Widv  RtAre Axial Diamo Diag1 Diag2 EloSg EloRd Steh  Lieg  ')
    ecke = u_AttLabArrToList('EkTL  EkTT  EkTR  EkRR  EkBR  EkBB  EkBL  EkLL  ')

    LB.Rsg = radi + aspa + ecke # 17 + 14 + 8
    
    # ----------   Arc   ----------
    LB.Arc = ['len', 'krv', 'dir', 'am1', 'am2', 'smo', 'spz', 'run', 'eck',
              'vpo', 'hpo', 'red', 'grn', 'blu']

    # ----------   Str   ----------
    LB.Str = ['les', 'str', 'ifx', 'wig', 'bog', 'amp', 'smo', 'vpo', 'hpo',
              'red', 'grn', 'blu']

    # ----------   Bndg   ----------
    LB.Bndg = ['len', 'agx', 'tig', 'dns', 'ori', 'vpo', 'hpo', 'red', 'grn', 'blu']

    # ----------   Shape   ----------
    scors = u_AttLabArrToList('Vrt   Hor   Dg1   Dg2   Axi   Adg   Vab   Hab   Dab   Tri   Nil   ')
    
    sfine = u_AttLabArrToList('Vrt   Hor   Vti   Hti   Vob   Hob   Dg2   Dg1   Axi   Uni   Dul   Cvg   Agx   Ori   Nil   Dre   Vir   Fnf   ')
    
    ras = u_AttLabArrToList('Rad   Elo   Ron   Riss  SteUgfSteEngSteDowSteUppOpnDowOpnUpwLigUgfLigEngLigDowLigUppOpnRitOpnLef')
    
    gol     = ['rib', 'ori', 'elo', 'agx']

    LB.Shp  = scors + sfine + ras + gol + lbsGen
    
    # ----------   Ttrg   ----------
    LB.Ttrg = ['Les', 'Elo', 'Wide', 'High', 'Rhom',
               'Pllo', 'Tria', 'Irrg', 'PlHor', 'PlVrt',
               'Ger', 'Wth', 'AxVrt', 'AxHor', 'Axial',
               'Lean1', 'Lean2', 'Neig1', 'Neig2',
               'ori', 'vpo', 'hpo']

    ## ------------   DOUBLES   ---------------
    # we use both Ttg and Ttrg. Annoying.
    #             Bnd and Bndg. Muehsam.
    # for simplicity we simply copy
    LB.Ttg  = LB.Ttrg
    LB.Bnd  = LB.Bndg

    
    return LB
