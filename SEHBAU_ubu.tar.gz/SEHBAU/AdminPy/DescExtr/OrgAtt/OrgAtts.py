"""

Organization of attributes

Labels and indices:
LBATT    = sb.Orga.o_AttsLabels()
IXATT    = sb.Orga.o_AttIxAsFields( LBATT )

------------------------------   CLS SUM   ------------------------------
class txtrLabels:
class fbrcLabels:
class attIndxs:
class attInfo:

------------------------------   DEF SUM   ------------------------------
def o_TxtrLabels():

def u_AttLabArrToList( labStr ):

def u_AttIxAsFields(aLab: list[str]) -> Any:
def o_AttIxAsFields( LB ):

def o_AttsLabels():

def o_AttIxPos( IxAtt ):
def o_AttIxCntGeo( IxAtt ):


Elsewhere:
- manipulations in AttManip.py

"""
from dataclasses import dataclass, make_dataclass, field
from typing import Any, List, Optional
import numpy as np
import math

from AdminPy.DescExtr.OrgAtt.AttManip import *


lbAngCoo    = ['sin', 'cos']



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

""" ------------------------------   txtrLabels   ------------------------------
    Blob labels. Set with o_TxtrLabels() below
"""
@dataclass
class txtrLabels:

    aSho: list[str]
    aLon: list[str]
    nLab:    int

""" ------------------------------   fbrcLabels   ------------------------------
    Blob labels. Set with o_TxtrLabels() below
"""
@dataclass
class fbrcLabels:

    aSho: list[str]
    aLon: list[str]
    nLab:    int

""" ------------------------------   attIndxs   ------------------------------
Attribute indices.
"""
@dataclass
class attIndxs:
    Cnt: Any
    Frm: Any
    Arc: Any
    Str: Any
    #Shp: Any i have duplicate labels


""" ------------------------------   attInfo   ------------------------------
Attribute indices and labels.
ia Jatt = attInfo()
"""
@dataclass
class attInfo:

    Lb: List[str]            = field(default_factory=list)
    Ix: Any = None

    
    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_TxtrLabels   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Blob labels.
 
They are also used in ReadBlobMapGlbSts.m (but NOT passed as variable).

They must match with CntTxtAnf.h, w_CntTXTbis (CntTxtIO.h)

ia 

"""
def o_TxtrLabels():

    # NB NVHAU
    aSho = ['Num', 'Blk', 'Nil', 'Vrt', 'Hor', 'Axi', 'Uni']

    aLon = [
        'Num (count)',
        'Blank (void)',
        'Nil (no ori)',
        'Vertical',
        'Horizontal',
        'Axial (vrt&hor)',
        'Uni (1 ori)',
        'Ken (contrast)',
        'Bunt'
    ]

    nLab = len( aSho );

    return txtrLabels( aSho=aSho, aLon=aLon, nLab=nLab )


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FbrcLabels   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Fabric biases. fbrc2arr drops Dg1 & Dg2!!
"""
def o_FbrcLabels():

    # NB NVHAU
    aSho = ['Vrt', 'Hor', 'Dg1', 'Dg2', 'Axi', 'Nil', 'Uni']

    aLon = [
        'Vertical',
        'Horizontal',
        'Diagonal 1',
        'Diagonal 2',
        'Axial (vrt&hor)',
        'Nil (no ori)'
        'Uni (1 ori)'
    ]

    nLab = len( aSho );

    return fbrcLabels( aSho=aSho, aLon=aLon, nLab=nLab )



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_AttLabArrToList   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Used below for converting a single array of labels (string) into a list

"""
def u_AttLabArrToList( labStr ):

    nChar = len(labStr)

    if nChar % 6 != 0:
        print("Input string:", repr(labStr))
        raise ValueError("Label array must be multiple of 6 characters.")

    aLbs = []
    for i in range(0, nChar, 6):
        lab = labStr[i:i+6].strip()             # trim spaces
        aLbs.append(lab)

    return aLbs    
    #return labStr.strip().split()


    
""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_AttIxAsFields   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Creates a struct with fieldnames from 'aLab' holding the index value to array
'aLab'. Function is called from o_AttIxAsFields below.

sa u_AttIxFromLab.m
cf o_AttIxAsFields

IN    aLab    a list of attribute labels
OUT   S       dataclass instance with fieldnames from labels holding index to aLab

"""
def u_AttIxAsFields( aLab: list[str] ) -> Any:

    nLab = len(aLab)

    # Dynamically define a dataclass where all fields are typed as int
    # e.g., [('field1', int), ('field2', int)]
    aFlds   = [(lbl, int) for lbl in aLab]
    DclsDyn = make_dataclass("S_Struct", aFlds)

    # Map each label to its 0-indexed position
    FldVals = {}
    for l in range(nLab):

        FldVals[aLab[l]] = l

    # Unpack the values to instantiate the dataclass
    S = DclsDyn(**FldVals)

    return S



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttIxAsFields   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

see o_AttsLabels.m

USE   LBATT    = sb.Orga.o_AttsLabels()
      IXATT    = sb.Orga.o_AttIxAsFields( LBATT )
"""
def o_AttIxAsFields( LB ):

    S = attIndxs(
        Cnt = u_AttIxAsFields(LB.Cnt),
        Frm = u_AttIxAsFields(LB.Frm),
        Arc = u_AttIxAsFields(LB.Arc),
        Str = u_AttIxAsFields(LB.Str),
        #Shp = u_AttIxAsFields(LB.Shp),
    )
    return S



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttsLabels   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

see o_AttsLabels.m

"""
def o_AttsLabels():

    lbPos   = ['psv', 'psh']
    lbRgb   = ['red', 'grn', 'blu']
    lbsGen  = lbPos + lbRgb

    @dataclass
    class LB:
        pass
    
    # ----------   Contour   ----------
    LB.Cnt = ['len', 'str', 'ori'] + lbPos + lbRgb
    LB.Skl = LB.Cnt

    # ----------   Form   ----------
    radi = ['rad',  'cir',  'eloR', 'eloF', 'bulk',   'bs1', 'bs2', 'bs3', 'bs4', 'bs5',
            'star', 'dent'] + lbPos + lbRgb
    aspa = u_AttLabArrToList('AreN  HgtN  WthN  High  Wide  Higv  Widv  RtAre Axial Diamo Diag1 Diag2 EloSg EloRd Steh  Lieg  ')
    ecke = u_AttLabArrToList('EkTL  EkTT  EkTR  EkRR  EkBR  EkBB  EkBL  EkLL  ')

    LB.Frm = radi + aspa + ecke # 17 + 14 + 8
    
    # ----------   Arc   ----------
    LB.Arc = ['len', 'krv', 'dir', 'am1', 'am2', 'smo', 'spz', 'run', 'eck'] + lbPos + lbRgb

    # ----------   Str   ----------
    LB.Str = ['les', 'str', 'ifx', 'wig', 'bog', 'amp', 'ori', 'smo' ] + lbPos + lbRgb

    # ----------   Bndg   ----------
    LB.Bndg = ['len', 'agx', 'tig', 'dns', 'ori' ] + lbPos + lbRgb

    # ----------   Shape   ----------
    scors = u_AttLabArrToList('Vrt   Hor   Dg1   Dg2   Axi   Adg   Vab   Hab   Dab   Tri   Nil   ')
    
    sfine = u_AttLabArrToList('Vrt   Hor   Vti   Hti   Vob   Hob   Dg2   Dg1   Axi   Uni   Dul   Cvg   Agx   Ori   Nil   Dre   Vir   Fnf   ')
    
    ras = u_AttLabArrToList('Rad   Elo   Ron   Riss  SteUgfSteEngSteDowSteUppOpnDowOpnUpwLigUgfLigEngLigDowLigUppOpnRitOpnLef')
    
    gol     = ['rib', 'ori', 'elo', 'agx']

    LB.Shp  = scors + sfine + ras + gol + lbsGen
    
    # ----------   Ttrg   ----------
    LB.Ttrg = ['Les', 'Elo', 'Wide', 'High', 'Rhom',
               'Pllo', 'Tria', 'Irrg', 'PlHor', 'PlVrt',
               'Ger', 'Wth', 'AxVrt', 'AxHor', 'Axial',
               'Lean1', 'Lean2', 'Neig1', 'Neig2',
               'ori'] + lbPos

    ## ------------   DOUBLES   ---------------
    # we use both Ttg and Ttrg. Annoying.
    #             Bnd and Bndg. Muehsam.
    # for simplicity we simply copy
    LB.Ttg  = LB.Ttrg
    LB.Bnd  = LB.Bndg

    
    return LB



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttIxPos   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

The indices for position for ONE desctype

"""
def o_AttIxPos( IxAtt ):

    Ix    = [ IxAtt.psv, IxAtt.psh ]
    return Ix



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttIxCntGeo   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

The indices for geometric attributes for contours

"""
def o_AttIxCntGeo( IxAtt ):

    Ix    = [ IxAtt.len, IxAtt.str, IxAtt.ori ]
    return Ix




