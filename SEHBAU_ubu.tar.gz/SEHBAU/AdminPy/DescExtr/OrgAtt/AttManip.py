"""

Attribute manipulations.

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------

def f_AngOriToSinCos( Ori: np.ndarray ) -> np.ndarray:
def f_AngDirToSinCos( Dir: np.ndarray ) -> np.ndarray:

"""
import numpy as np



# --------------------------------------------------------------------------------
#
#                               R O U T I N E S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_AngOriToSinCos   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Expands an orientation angle array (-pi/2 to +pi/2) into sin and cos coordinates for
structural angle distance measurements.

"""
def f_AngOriToSinCos( Ori: np.ndarray ) -> np.ndarray:

    Sin = np.sin(Ori * 2) 
    Cos = np.cos(Ori * 2) 

    return np.column_stack( (Sin, Cos) )


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_AngDirToSinCos   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Transforms a directional angle array (0 to 2*pi) into sin and cos coordinates for
standard vector distance and directional measurements.

Not verified yet.

"""
def f_AngDirToSinCos( Dir: np.ndarray ) -> np.ndarray:

    Sin = np.sin(Dir) 
    Cos = np.cos(Dir) 

    return np.column_stack( (Sin, Cos) )

