"""

Wrapper function for program dscx

"""
import subprocess, platform
from dataclasses import dataclass, asdict


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class dclsDscxArgs:             # ''''''''''''''''''''   dclsDscxCmnd   ''''''''''''''''''''
    """
    Administrative structure for passing arguments to dscx

    USE  - as in exsbRoadScene.py
         - or:
           O = DscxArgs( saveRRE=1, saveKol=1, nLev=3, depth=2, imgSpc=1 )
           cmnd = i_DscxArgs(O)
           print( cmnd )
    
    """
    ## -----   Saving  -----
    saveRRE   = 0     # saving of RRE space (full set)
    saveCVP   = 0     # saving of full CVP space
    saveKol   = 0     # saving of kolumns
    saveTxm   = 0     # saving of texture maps

    # setting the following two has no effect!!
    saveBin   = 0     # saving of bins. default ON!!
    saveProp  = 0     # saving proposals. default ON!!

    # feature
    saveRegUnv    = 0     # region universe
    saveBonSpc    = 0     # boundary space

    # other
    saveBonBoxRaw = 0  # saves .bonBboxRaw 
    saveBonMore   = 0  # .bonBbox, .bonAsp
    saveCuvKpt    = 0  # saves .cuvKpt

    noSave        = 0     # saving of description # does this work?

    ## -----  Archit  -----
    # a value of -1 signals that no modification is desired. default remains.
    nLev      = -1 
    depth     = -1 
    imgSpc    = -1    # image space (pyramid or scale space)
    imgFlt    = -1    # image filtering
    
    ## -----  Other   -----
    optS      = ''


""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_DscxArgs   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII
"""
def i_DscxArgs( O: dclsDscxArgs ) -> str:

    # Verify field count
    #aFldn     = list(asdict(O).keys())
    #nFldFound = len(aFldn)

    #if O.nFld != 0 and O.nFld != nFldFound:
     #   print("Warning: unexpected number of fields in DscxArgs")

    S = "" 

    # ----- Extraction/Saving -----
    if O.saveRRE > 0: S += " --saveRRE"
    if O.saveCVP > 0: S += " --saveCVP"
    if O.saveKol > 0: S += " --saveKol"
    if O.saveTxm > 0: S += " --saveTxm"
    if O.saveProp > 0: S += " --saveProp"
    if O.saveCuvKpt > 0: S += " --saveCuvKpt"
    if O.saveRegUnv > 0: S += " --saveRuv"
    if O.saveBonSpc > 0: S += " --saveBsp"
    if O.saveBonBoxRaw > 0: S += " --saveBonBboxRaw"
    if O.saveBonMore > 0: S += " --saveBonMore"

    # ----- Archit -----
    if O.nLev > -1:
        assert 0 < O.nLev < 10, "nLev must be between 1 and 9"
        S += f" --nLev {O.nLev}"

    if O.depth > -1:
        assert 0 < O.depth < 5, "depth must be between 1 and 4"
        S += f" --depth {O.depth}"

    if O.imgSpc > -1:
        assert 0 < O.imgSpc < 3, "imgSpc must be 1 or 2"
        S += f" --is {O.imgSpc}"

    if O.imgFlt > -1:
        assert 0 <= O.imgFlt < 4, "imgFlt must be 0–3"
        S += f" --if {O.imgFlt}"

    # ----- Other -----
    S += f" {O.optS}".strip()

    return S.strip()    


    
""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennDscx   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for dscx. Assumes that routine is run from directory
'DescExtr' (because no path is prepended to program 'dscx').

cf exsbDscxFull.py

IN    fipaImg image filepath
      fipaOut output filepath
      Args    arguments
OUT   Res     results, incl. standard output/error

"""
def RennDscx( fipaImg, fipaOut, Args ):

    # ----------   string version   ----------
    cmnd  = 'dscx ' + str(fipaImg) + ' ' + str(fipaOut) + ' ' + Args.opt

    if platform.system()=='Windows':
        cmnd = cmnd.replace('/', '\\')
    else:
        cmnd = './' + cmnd

    # ----------   pathlib version   ----------
    #cmnd  = ['dscx', fipaImg, fipaOut ]

    #if Args.opt:
    #    cmnd.append( Args.opt )

    # --------------------   Execute   --------------------
    # https://docs.python.org/3/library/subprocess.html

    # -----  python 3.6
    #Res = subprocess.run( cmnd,
    #			  stdout = subprocess.PIPE,
    #			  stderr = subprocess.PIPE,
    #			  universal_newlines = True )

    # -----  python 3.11
    Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    
    # --------------------   Verify Proper Termination   --------------------
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        
        print('Program dscx was not executed properly. Output below:' )
        print('Commmand was: ')
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        optwDisp  = Args.opt + ' --bDISP 3' 
        cmnd2     = ['dscx', fipaImg, fipaOut, optwDisp ]

        Res2 = subprocess.run( cmnd2, shell=True, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')

    return Res.stdout



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennDscxX   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

X for explicit program specification. For evaluation.

IN   fExe filepath of executable. 

"""
def RennDscxX( fExe, fipaImg, fipaOut, Args ):

    # ----------   string version   ----------
    cmnd  = str(fExe) + ' ' + str(fipaImg) + ' ' + str(fipaOut) + ' ' + Args.opt

    if platform.system()=='Windows':
        cmnd = cmnd.replace('/', '\\')

    # ----------   pathlib version   ----------
    #cmnd  = ['dscx', fipaImg, fipaOut ]

    #if Args.opt:
    #    cmnd.append( Args.opt )

    # --------------------   Execute   --------------------
    # https://docs.python.org/3/library/subprocess.html

    # -----  python 3.6
    #Res = subprocess.run( cmnd,
    #			  stdout = subprocess.PIPE,
    #			  stderr = subprocess.PIPE,
    #			  universal_newlines = True )

    # -----  python 3.11
    Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    
    # --------------------   Verify Proper Termination   --------------------
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        
        print('Program dscx was not executed properly. Output below:' )
        print('Commmand was: ')
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        optwDisp  = Args.opt + ' --bDISP 3' 
        cmnd2     = ['dscx', fipaImg, fipaOut, optwDisp ]

        Res2 = subprocess.run( cmnd2, shell=True, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')

    return Res.stdout


