"""

Fabric manipulations.

------------------------------   CLS SUM   ------------------------------
class focIXfbrc:
class fbrcMTX:

------------------------------   DEF SUM   ------------------------------
def f_FocRngsFbrc( top: int, bot: int, lef: int, rit: int, Prm: prmFocScl ) -> focIXfbrc:
def f_FocXtrFbrc( FLL: fbrcMTX, IX: focIXfbrc ) -> fbrcMTX:

def u_FbrcCatKntMap( MP ):

def SaveFbrcMTX( FBC: fbrcMTX, pth: str):
def LoadFbrcMTX(pth: str) -> fbrcMTX:

"""
from dataclasses import dataclass
import numpy as np
import numpy.typing as npt

from AdminPy.FocSel.FocAnf import *
#import AdminPy.DescExtr.Texture.Fabric as fbrc


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class focIXfbrc:               # ''''''''''''''''''''   focIXfbrc   ''''''''''''''''''''
    """
    Linear indices for the fabric layers
    """
    L0: npt.NDArray[np.int32] = None   # layer 0 linear indices
    L1: npt.NDArray[np.int32] = None   # layer 1
    L2: npt.NDArray[np.int32] = None   # layer 2
    L3: npt.NDArray[np.int32] = None   # layer 3

    ADim: npt.NDArray[np.int32] = None # [4 2]


@dataclass
class fbrcMTX:               # ''''''''''''''''''''   fbrcMTX   ''''''''''''''''''''
    """
    Fabric as matrices as generated with 'fbrc2arr'

    Can be full fabric or focus-selected fabric
    """

    # --- hyperkolumns, ntBin is same
    HYK0: npt.NDArray[np.float32] = None # layer 0 [nCells0 ntBin]
    HYK1: npt.NDArray[np.float32] = None # layer 1 [nCells1 ntBin]
    HYK2: npt.NDArray[np.float32] = None # layer 2 [nCells2 ntBin]
    HYK3: npt.NDArray[np.float32] = None # layer 3 [nCells3 ntBin]

    # --- bias maps, nBis * (cnt + frm)
    Mps0: npt.NDArray[np.float32] = None # layer 0 [nCells0 nBis]
    Mps1: npt.NDArray[np.float32] = None # layer 1 [nCells1 nBis]
    Mps2: npt.NDArray[np.float32] = None # layer 2 [nCells2 nBis]
    Mps3: npt.NDArray[np.float32] = None # layer 3 [nCells3 nBis]

    # --- count maps, nDscTyp
    Knt0: npt.NDArray[np.float32] = None # layer 0 [nCells0 nDty]
    Knt1: npt.NDArray[np.float32] = None # layer 1 [nCells1 nDty]
    Knt2: npt.NDArray[np.float32] = None # layer 2 [nCells2 nDty]
    Knt3: npt.NDArray[np.float32] = None # layer 3 [nCells3 nDty]

    ADim: npt.NDArray[np.int32] = None # [4 2]

    Ncells: npt.NDArray[np.int32] = None # [4 1]

    nLayEnc : int=-1




# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FocRngsFbrc   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Extracting index ranges from a bounding box
"""
def f_FocRngsFbrc( top: int, bot: int, lef: int, rit: int, Prm: prmFocScl ) -> focIXfbrc:

    IX    = focIXfbrc()

    Rng0  = f_FocRngFromBbx( top, bot, lef, rit, Prm.vrt0, Prm.hor0 )
    Rng1  = f_FocRngFromBbx( top, bot, lef, rit, Prm.vrt1, Prm.hor1 )
    Rng2  = f_FocRngFromBbx( top, bot, lef, rit, Prm.vrt2, Prm.hor2 )
    Rng3  = f_FocRngFromBbx( top, bot, lef, rit, Prm.vrt3, Prm.hor3 )

    #IxLin  = Rng.Rw[:, None] * nHor + Rng.Cl
    IX.L0  = (Rng0.Rw[:, None] * 31 + Rng0.Cl).flatten()
    IX.L1  = (Rng1.Rw[:, None] * 15 + Rng1.Cl).flatten()
    IX.L2  = (Rng2.Rw[:, None] *  7 + Rng2.Cl).flatten()
    IX.L3  = (Rng3.Rw[:, None] *  3 + Rng3.Cl).flatten()

    ADim      = np.empty((4, 2), dtype=np.int32)
    ADim[0,:] = [Rng0.nRow, Rng0.nCol]
    ADim[1,:] = [Rng1.nRow, Rng1.nCol]
    ADim[2,:] = [Rng2.nRow, Rng2.nCol]
    ADim[3,:] = [Rng3.nRow, Rng3.nCol]
    IX.ADim = ADim 

    #IX.L0  = Rng0.Rw[:, None] * 31 + Rng0.Cl
    #IX.L1  = Rng1.Rw[:, None] * 15 + Rng1.Cl
    #IX.L2  = Rng2.Rw[:, None] *  7 + Rng2.Cl
    #IX.L3  = Rng3.Rw[:, None] *  3 + Rng3.Cl

    return IX


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FocXtrFbrc   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Extracting fabric for a specified bounding box given as index structure.

"""
def f_FocXtrFbrc( FLL: fbrcMTX, IX: focIXfbrc ) -> fbrcMTX:

    # hyperkolumns
    SHYK0    = FLL.HYK0[ IX.L0,: ]
    SHYK1    = FLL.HYK1[ IX.L1,: ]
    SHYK2    = FLL.HYK2[ IX.L2,: ]
    SHYK3    = FLL.HYK3[ IX.L3,: ]

    # bias maps
    SMP0     = FLL.Mps0[ IX.L0,: ] # [nSel nBis]
    SMP1     = FLL.Mps1[ IX.L1,: ]
    SMP2     = FLL.Mps2[ IX.L2,: ]
    SMP3     = FLL.Mps3[ IX.L3,: ]
    
    # count maps
    SKT0     = FLL.Knt0[ IX.L0,: ] # [nSel nDscTyp]
    SKT1     = FLL.Knt1[ IX.L1,: ]
    SKT2     = FLL.Knt2[ IX.L2,: ]
    SKT3     = FLL.Knt3[ IX.L3,: ]
    
    Ncells   = np.prod(IX.ADim, axis=1).astype(np.int32)

    nLayEnc  = np.count_nonzero(Ncells > 0)

    SL = fbrcMTX( SHYK0, SHYK1, SHYK2, SHYK3,
                  SMP0, SMP1, SMP2, SMP3,
                  SKT0, SKT1, SKT2, SKT3,
                  IX.ADim, Ncells, nLayEnc )
    
    return SL



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_FbrcCatKntMap   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Concatenates the count maps to a single block

"""
def u_FbrcCatKntMap( MP ):

    KT = np.stack( (MP.Ncnt, MP.Nfrm, MP.Narc, MP.Nstr, MP.Nshp), axis=2 )
    
    return KT



""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveFbrcMTX   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

"""
def SaveFbrcMTX( FBC: fbrcMTX, pth: str):

    with open(pth, 'wb') as f:

        # ----------   Header   ----------
        np.array([FBC.nLayEnc], dtype=np.int32).tofile(f)
        FBC.ADim.astype(np.int32).tofile(f)
        FBC.Ncells.astype(np.int32).tofile(f)

        # Constant column dimensions
        nBin = FBC.HYK0.shape[1]
        nBis = FBC.Mps0.shape[1]
        nDty = FBC.Knt0.shape[1]

        np.array([nBin, nBis, nDty], dtype=np.int32).tofile(f)

        # ----------   Data   ----------
        # --- Hypercolumns
        for A in (FBC.HYK0, FBC.HYK1, FBC.HYK2, FBC.HYK3):
            A.astype(np.float32).tofile(f)

        # --- Bias Maps
        for A in (FBC.Mps0, FBC.Mps1, FBC.Mps2, FBC.Mps3):
            A.astype(np.float32).tofile(f)

        # --- Count Maps
        for A in (FBC.Knt0, FBC.Knt1, FBC.Knt2, FBC.Knt3):
            A.astype(np.float32).tofile(f)


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadFbrcMTX   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

"""
def LoadFbrcMTX(pth: str) -> fbrcMTX:

    with open(pth, 'rb') as f:

        # ----------   Header   ----------
        nLayEnc = int(np.fromfile(f, dtype=np.int32, count=1)[0])

        ADim    = np.fromfile( f, dtype=np.int32, count=8 ).reshape(4, 2)

        Ncells  = np.fromfile( f, dtype=np.int32, count=4 )

        nBin, nBis, nDty = np.fromfile( f, dtype=np.int32, count=3 )

        # ----------   Data   ----------
        # --- Hyperkolumns
        HYK = []
        for n in Ncells:
            n = int(n)
            HYK.append( np.fromfile( f, dtype=np.float32,
                                     count=n * nBin ).reshape(n, nBin) )

        # --- Bias-Maps
        Mps = []
        for n in Ncells:
            n = int(n)
            Mps.append( np.fromfile( f, dtype=np.float32,
                                     count=n * nBis ).reshape(n, nBis) )

        # --- Count-Maps
        Knt = []
        for n in Ncells:
            n = int(n)
            Knt.append( np.fromfile( f, dtype=np.float32,
                                     count=n * nDty ).reshape(n, nDty) )

        return fbrcMTX(
            HYK0=HYK[0],
            HYK1=HYK[1],
            HYK2=HYK[2],
            HYK3=HYK[3],
            Mps0=Mps[0],
            Mps1=Mps[1],
            Mps2=Mps[2],
            Mps3=Mps[3],
            Knt0=Knt[0],
            Knt1=Knt[1],
            Knt2=Knt[2],
            Knt3=Knt[3],
            ADim=ADim,
            Ncells=Ncells,
            nLayEnc=nLayEnc
        )

