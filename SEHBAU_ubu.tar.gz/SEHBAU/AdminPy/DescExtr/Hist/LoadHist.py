"""

Loading image histogram as arrays. 

Loading as structure not implemented yet (and perhaps not necessary?).

def LoadHistImgArr(lfn):

"""
from pathlib import Path
from dataclasses import dataclass
import numpy as np

from AdminPy.Orga import OrgFileNames



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

def read_int16(fileID) -> int:
    """Reads a single int16 from a binary file and returns a Python int."""
    return np.fromfile(fileID, dtype=np.int16, count=1).item()

def read_int32(fileID) -> int:
    """Reads a single int32 from a binary file and returns a Python int."""
    return np.fromfile(fileID, dtype=np.int32, count=1).item()


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadHistImgArr   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the image histogram array from a text file.
Equivalent to LoadHistImgArr.m
    
RET  np.ndarray: 1D array of integers.

"""
def LoadHistImgArr(lfn):

    try:
        with open(lfn, 'r') as file:
            return np.loadtxt(file, dtype=np.int32)
            #H = []
            #for line in file:
             #   parts = line.strip().split()
              #  for p in parts:
               #     try:
                #        H.append(int(p))
                 #   except ValueError:
                  #      print(f"Warning: Skipping invalid token: {p}")

                    #line = line.strip()
                #if line and line.isdigit():  # skips empty and non-numeric lines
                 #   H.append(int(line))
                    
            #H = [int(line.strip()) for line in file if line.strip()]
            
    except FileNotFoundError:
        raise FileNotFoundError(f"file {lfn} not found")

    return np.array(H, dtype=np.int32)



