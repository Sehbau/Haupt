"""

Loading image histogram as arrays. 

Loading as structure not implemented yet (and perhaps not necessary?).


------------------------------   CLS SUM   ------------------------------
class fhedHist:
class hspaVal:
class hspaDUNV:

------------------------------   DEF SUM   ------------------------------
def ReadHistFileHead(fileID) -> fhedHist:

def LoadHistImgArr(lfn):

def ReadHspaDSC(fid) -> tuple[hspaVal, hspaNbin]:
def ReadHspaDUNV(fid, szGrd: tuple[int, int]) -> hspaDUNV:

def LoadDescHistClw(lfn: str | Path) -> tuple[hspaDUNV, any]:

def u_HistCatClwDty1(D) -> np.ndarray:

def i0_HistClwUniv(Nbin: hspaNbinDunv, nCells: int) -> np.ndarray:
def u_HistCatClw(HCLW: hspaDUNV) -> np.ndarray:

Elsewhere:
- loading fabric in LoadFabric.py

"""
import os
from pathlib import Path
from dataclasses import dataclass, field
from collections.abc import Sequence
import numpy as np

from AdminPy.Orga import OrgFileNames
from AdminPy.DescExtr.Hist.DescBinAnf import *


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

"""
General filehead for histograms
"""
@dataclass
class fhedHist:
    ntBin:   int
    szV:     int
    szH:     int
    ntDsc:   int
    nLev:    int
    typ:     int
    nVrtSph: int
    nHorSph: int
    vers:    float
    

"""
Histogram values one descriptor type
"""
@dataclass
class hspaVal:
    Uni: np.ndarray
    Biv: np.ndarray

"""
Spatial histogram values universe
"""
@dataclass
class hspaDUNV:
    ACNT: list[hspaVal] = field(default_factory=list)
    AFRM: list[hspaVal] = field(default_factory=list)
    AARC: list[hspaVal] = field(default_factory=list)
    ASTR: list[hspaVal] = field(default_factory=list)
    ASHP: list[hspaVal] = field(default_factory=list)
    
    # Grid summary counts (2D NumPy arrays)
    Ncnt: np.ndarray = field(default_factory=lambda: np.array([]))
    Nfrm: np.ndarray = field(default_factory=lambda: np.array([]))
    Narc: np.ndarray = field(default_factory=lambda: np.array([]))
    Nstr: np.ndarray = field(default_factory=lambda: np.array([]))
    Nshp: np.ndarray = field(default_factory=lambda: np.array([]))
    
    nCells: int = 0
    szGrd:  tuple[int, int] = (0, 0)
    Nbin:   bnumSpaClw | None = None

    
    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

def read_int16(fileID) -> int:
    """Reads a single int16 from a binary file and returns a Python int."""
    return np.fromfile(fileID, dtype=np.int16, count=1).item()

def read_int32(fileID) -> int:
    """Reads a single int32 from a binary file and returns a Python int."""
    return np.fromfile(fileID, dtype=np.int32, count=1).item()


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadHistFileHead   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads histogram file header from an open binary file.
    
IN   fid: An open file object (opened in binary read mode 'rb')
"""
def ReadHistFileHead(fileID) -> fhedHist:

    # int32
    ntBin = int(np.fromfile(fileID, dtype=np.int32, count=1)[0])
    szV   = int(np.fromfile(fileID, dtype=np.int32, count=1)[0])
    szH   = int(np.fromfile(fileID, dtype=np.int32, count=1)[0])
    ntDsc = int(np.fromfile(fileID, dtype=np.int32, count=1)[0])

    # uint8
    nLev    = int(np.fromfile(fileID, dtype=np.uint8, count=1)[0])
    typ     = int(np.fromfile(fileID, dtype=np.uint8, count=1)[0])
    nVrtSph = int(np.fromfile(fileID, dtype=np.uint8, count=1)[0])
    nHorSph = int(np.fromfile(fileID, dtype=np.uint8, count=1)[0])

    # version no
    vers = float(np.fromfile(fileID, dtype=np.float32, count=1)[0])

    # ------------   Verify   ---------------
    if nLev < 1 or nLev > 10:
        print(f"nLev not correct: {nLev}")
        print(f"szV: {szV}, szH: {szH}, ntDsc: {ntDsc}, typ: {typ}")
        
    assert 0 < szV < 5000, f"szV unreasonable: {szV}"
    assert 0 < szH < 5000, f"szH unreasonable: {szH}"
    assert abs(vers - 1.03) < 0.001, f"Version depreciated: is {vers:.12f}. new 1.03"

    # ------------   A2S   ---------------
    # In Python, we can explicitly cast nVrtSph and nHorSph to standard integers 
    # since Python automatically manages arbitrary precision sizes.
    return fhedHist(
        ntBin = ntBin,
        szV   = szV,
        szH   = szH,
        ntDsc = ntDsc,
        nLev  = nLev,
        typ   = typ,
        nVrtSph = int(nVrtSph),
        nHorSph = int(nHorSph),
        vers  = vers
    )


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadHistImgArr   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the image histogram array from a text file.
Equivalent to LoadHistImgArr.m
    
RET  np.ndarray: 1D array of integers.

"""
def LoadHistImgArr(lfn):

    try:
        with open(lfn, 'r') as file:
            return np.loadtxt(file, dtype=np.int32)
            #H = []
            #for line in file:
             #   parts = line.strip().split()
              #  for p in parts:
               #     try:
                #        H.append(int(p))
                 #   except ValueError:
                  #      print(f"Warning: Skipping invalid token: {p}")

                    #line = line.strip()
                #if line and line.isdigit():  # skips empty and non-numeric lines
                 #   H.append(int(line))
                    
            #H = [int(line.strip()) for line in file if line.strip()]
            
    except FileNotFoundError:
        raise FileNotFoundError(f"file {lfn} not found")

    return np.array(H, dtype=np.int32)

    



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadHspaDSC   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads spatial histograms from an open binary file.
    
IN   fid: An open file object (opened in binary read mode 'rb')
"""
def ReadHspaDSC(fid) -> tuple[hspaVal, bnumDsc1]:

    # -----    # of bins   -----
    nUni  = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    nBiv  = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    
    Nbins = bnumDsc1( nUni, nBiv, nUni + nBiv )
    
    # -----    Histograms  -----
    Huni  = np.fromfile(fid, dtype=np.int32, count=Nbins.uni)
    Hbiv  = np.fromfile(fid, dtype=np.int32, count=Nbins.biv)
    
    HVals = hspaVal( Uni=Huni, Biv=Hbiv )
    
    return HVals, Nbins


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadHspaDUNV   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Loads the universe of spatial histograms (organized cellwise).
    
IN    fid: An open file object (mode 'rb')
      szGrd: A tuple/list containing (nVer, nHor)

"""
def ReadHspaDUNV(fid, szGrd: Sequence[int] | np.ndarray ) -> hspaDUNV:

    nVer, nHor = szGrd[0], szGrd[1]
    nCells     = nVer * nHor
    
    # Initialize the universe container
    H = hspaDUNV(nCells=nCells, szGrd=szGrd)
    
    # Local trackers for the last read Nbin structures
    NbinCnt = NbinFrm = NbinArc = NbinStr = NbinShp = None
    
    # %% -----  Cells (data)  ------
    for _ in range(nCells):
        Hcnt, NbinCnt = ReadHspaDSC(fid)
        Hfrm, NbinFrm = ReadHspaDSC(fid)
        Harc, NbinArc = ReadHspaDSC(fid)
        Hstr, NbinStr = ReadHspaDSC(fid)
        Hshp, NbinShp = ReadHspaDSC(fid)
        
        H.ACNT.append(Hcnt)
        H.AFRM.append(Hfrm)
        H.AARC.append(Harc)
        H.ASTR.append(Hstr)
        H.ASHP.append(Hshp)
        
    # %% -----  Num (Count) Maps (trailer)   ------
    # Read raw 1D arrays from binary
    Ncnt = np.fromfile(fid, dtype=np.int32, count=nCells)
    Nfrm = np.fromfile(fid, dtype=np.int32, count=nCells)
    Narc = np.fromfile(fid, dtype=np.int32, count=nCells)
    Nstr = np.fromfile(fid, dtype=np.int32, count=nCells)
    Nshp = np.fromfile(fid, dtype=np.int32, count=nCells)
    
    # Replicate MATLAB's `reshape(..., nVer, nHor)'` using column-major order ('F')
    # and then transposing `.T` (which is what MATLAB's `'` operator does)
    H.Ncnt = Ncnt.reshape((nVer, nHor), order='F').T
    H.Nfrm = Nfrm.reshape((nVer, nHor), order='F').T
    H.Narc = Narc.reshape((nVer, nHor), order='F').T
    H.Nstr = Nstr.reshape((nVer, nHor), order='F').T
    H.Nshp = Nshp.reshape((nVer, nHor), order='F').T
    
    # %% -----   create one Nbin struct   -----
    H.Nbin = bnumSpaClw(
        nCells      = nCells,
        nBinPerCell = 0,
        ntBin       = 0,
        Dim         = [0,0],
        Cnt = NbinCnt,
        Frm = NbinFrm,
        Arc = NbinArc,
        Str = NbinStr,
        Shp = NbinShp
    )
    
    return H



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescHistClw   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the spatial hist-of-atts that were saved cellwise.
    
IN   lfn: Local file name (string or Path object)
OUT  A tuple containing (H, Head)
"""
def LoadDescHistClw(lfn: str | Path) -> tuple[hspaDUNV, any]:

    # Check if file exists to mimic MATLAB's fid < 0 error check
    if not os.path.exists(lfn):
        raise FileNotFoundError(f"file {lfn} not found")
        
    # Open file safely using a context manager ('rb' for binary reading)
    with open(lfn, 'rb') as fid:

        # -----  header   ------
        # Assuming ReadHistFileHead parses the top of the file
        Hed   = ReadHistFileHead(fid)
        
        szGrd = (Hed.nVrtSph, Hed.nHorSph)
        
        # -----  data  -----
        HST   = ReadHspaDUNV(fid, szGrd)
        
        # Assign the secondary layout grid parameter
        HST.szG = (Hed.nVrtSph, Hed.nHorSph)
        
    return HST, Hed


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_HistCatClwDty1   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Concatenates univ and biva histograms for one desctype.

"""
def u_HistCatClwDty1(D) -> np.ndarray:

    return np.concatenate((D.Uni, D.Biv), axis=0)




""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII   f_HistClwNbinTotDty1   IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII

Sets up spatial histograms for cellwise organization.
    
IN    Nbin: An instance of NbinCollection
      nCells: Number of cells in the grid (integer)

OUT   2D NumPy array of zeros with shape (nCells, nt) and single precision.
"""
def i0_HistClwUniv(Nbin: bnumSpaClw, nCells: int) -> np.ndarray:

    # In MATLAB, these were re-assigned. In Python, we just call the helper 
    # if it performs modifications, or read from them directly.
    Nbin.Cnt = f_HistClwNbinTotDty1(Nbin.Cnt)
    Nbin.Frm = f_HistClwNbinTotDty1(Nbin.Frm)
    Nbin.Arc = f_HistClwNbinTotDty1(Nbin.Arc)
    Nbin.Str = f_HistClwNbinTotDty1(Nbin.Str)
    Nbin.Shp = f_HistClwNbinTotDty1(Nbin.Shp)
    
    # Calculate the total feature length (nt)
    nt = Nbin.Cnt.nt + Nbin.Frm.nt + Nbin.Arc.nt + Nbin.Str.nt + Nbin.Shp.nt
    
    # Create the 2D matrix of zeros (rows = nCells, columns = nt)
    # 'single' in MATLAB maps directly to np.float32 in Python/NumPy
    H = np.zeros((nCells, nt), dtype=np.float32)
    
    return H


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_HistCatClw   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Concatenates histograms loaded cellwise into a single matrix.
    
IN  HCLW   An instance of hspaDUNV containing the cellwise data
OUT        A 2D NumPy array HMX with shape (nCells, ntBin)
"""
def u_HistCatClw(HCLW: hspaDUNV) -> np.ndarray:

    # 1. Allocate the output matrix of zeros
    HMX = i0_HistClwUniv(HCLW.Nbin, HCLW.nCells)
    
    # 2. Iterate through each cell (0-indexed in Python)
    for c in range(HCLW.nCells):

        # Concatenate the Univ and Biv components for each field
        Hcnt = u_HistCatClwDty1(HCLW.ACNT[c])
        Hfrm = u_HistCatClwDty1(HCLW.AFRM[c])
        Harc = u_HistCatClwDty1(HCLW.AARC[c])
        Hstr = u_HistCatClwDty1(HCLW.ASTR[c])
        Hshp = u_HistCatClwDty1(HCLW.ASHP[c])
        
        # Horizontal concatenation of all component arrays into a single row
        row_data = np.concatenate((Hcnt, Hfrm, Harc, Hstr, Hshp))
        
        # 3. Assign the combined row directly to row index `c`
        HMX[c, :] = row_data
        
    return HMX




