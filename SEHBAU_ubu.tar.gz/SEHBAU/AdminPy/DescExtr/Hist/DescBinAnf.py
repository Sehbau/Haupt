"""
Bin numbers

------------------------------   CLS SUM   ------------------------------
class dimGrid:
class bnumDsc1:
class bnumSpaClw:

------------------------------   DEF SUM   ------------------------------
def ReadBnumDsc1(fileID):
def ReadBnumSpat(fileID):
def ReadBnumATT(fid ):

def f_HistClwNbinTotDty1( N: bnumDsc1 ) -> bnumDsc1:

def DispBnumDsc1( N, jStr ):
def DispBnumSpat( N ):

"""
import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, IO
from collections.abc import Sequence
import numpy as np

from AdminPy.Orga import OrgFileNames



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
"""
Dimensions of grid. vertical x horizontal
"""
@dataclass
class dimGrid:
    ver: int
    hor: int

"""
Bin count for one descriptor type
"""
@dataclass
class bnumDsc1:
    uni: int
    biv: int
    tot: int

"""
Bin count spatial for universe
"""
@dataclass
class bnumSpaClw:

    nCells:      int
    nBinPerCell: int
    ntBin:       int

    Dim:         dimGrid
    
    Cnt:         bnumDsc1
    Frm:         bnumDsc1
    Arc:         bnumDsc1
    Str:         bnumDsc1
    Shp:         bnumDsc1


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBnumDsc1   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the bin numbers for ONE desctype as written by w_BnumDsc1 in
DescBinAnf.h

cf LoadCollHist.py, ReadBnumSpat

"""
def ReadBnumDsc1( fid ):

    uni = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    biv = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    tot = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    
    return bnumDsc1( uni, biv, tot )



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBnumSpat   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the bin numbers for spatial histograms as written by w_BnumSpaClw DescBinAnf.h

sa/af ReadDescBinNum

cf LoadFabric.m, LoadCollHist.m

cf ReadBnumSpat.m

"""
def ReadBnumSpat( fid: IO[bytes] ) -> bnumSpaClw:

    N             = bnumSpaClw
    
    N.nCells      = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    N.nBinPerCell = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    N.ntBin       = int(np.fromfile(fid, dtype=np.int32, count=1)[0])

    Dim           = dimGrid
    Dim.ver       = int(np.fromfile(fid, dtype=np.int16, count=1)[0])
    Dim.hor       = int(np.fromfile(fid, dtype=np.int16, count=1)[0])
    N.Dim         = Dim
    
    N.Cnt         = ReadBnumDsc1(fid)
    N.Frm         = ReadBnumDsc1(fid)
    N.Arc         = ReadBnumDsc1(fid)
    N.Str         = ReadBnumDsc1(fid)
    N.Shp         = ReadBnumDsc1(fid)

    N.Ndsc        = np.array([N.Cnt.tot, N.Frm.tot, N.Arc.tot, N.Str.tot, N.Shp.tot],
                             dtype=np.int32)
    return N



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBnumATT   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the descriptor bins for spatial organization.

"""
def ReadBnumATT(fid ):

    @dataclass
    class N:
        pass

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.CntUni = np.fromfile(fid, dtype=np.int32, count=4)

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.FrmUni = np.fromfile(fid, dtype=np.int32, count=13)

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.ArcUni = np.fromfile(fid, dtype=np.uint8, count=8).astype(np.int32)

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.StrUni = np.fromfile(fid, dtype=np.int32, count=4)

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.shpUni = np.fromfile(fid, dtype=np.int32, count=1)[0]

    N.shpBiv = np.fromfile(fid, dtype=np.int32, count=1)[0]

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.ttrgUni = np.fromfile(fid, dtype=np.int32, count=1)[0]

    N.ttrgBiv = np.fromfile(fid, dtype=np.int32, count=1)[0]

    N.bndgUni = np.fromfile(fid, dtype=np.int32, count=1)[0]

    N.bndgBiv = np.fromfile(fid, dtype=np.int32, count=1)[0]    
    
    return N



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_HistClwNbinTotDty1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
"""
def f_HistClwNbinTotDty1( N: bnumDsc1 ) -> bnumDsc1:

    N.nt  = N.uni + N.biv
    
    return N




# --------------------------------------------------------------------------------
#                                     D I S P 
# --------------------------------------------------------------------------------

""" DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD   DispBnumDsc1   DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD

bnumDsc1
"""
def DispBnumDsc1( N, jStr ):

    print(f"{jStr}  uni/biv/tot  {N.uni:>4} {N.biv:>4} {N.tot:>4}")

    
""" DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD   DispBnumSpat   DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD

bnumSpaClw
"""
def DispBnumSpat( N ):

    print(f"{'nCells':<15} {N.nCells:>6} {'  ('} {N.Dim.ver} {'x'} {N.Dim.hor} {')'}")
    print(f"{'nBinPerCell':<15} {N.nBinPerCell:>6}")
    print(f"{'ntBin':<15} {N.ntBin:>6}")

    DispBnumDsc1( N.Cnt, 'Cnt' )
    DispBnumDsc1( N.Frm, 'Frm' )
    DispBnumDsc1( N.Arc, 'Arc' )
    DispBnumDsc1( N.Str, 'Str' )
    DispBnumDsc1( N.Shp, 'Shp' )

