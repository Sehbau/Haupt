"""

Vector matrix manipulations

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------

# ----------   VecMx Manip   ----------
def u_VmxXtrPos( VEC, Lab ):
def u_VmxOmtPos( VEC, Lab ):
def u_VmxXtrOriAsSinCos( VEC, Lab ):
def u_VmxExpndOriToCoo( VEC: np.ndarray, IxAtt, Lab ) -> tuple[np.ndarray, list[str]]:

# ----------   Prep Vector Matrices   ----------
def o_AttCntOriExpand( V ):
def o_AttDscOriExpand( V, LbAtt ):
def o_AttCntPosSep( V ):
def o_AttFrmPosSep( V ):
def o_AttStrPosSep( V ):


"""
from AdminPy.DescExtr.OrgAtt.OrgAtts import *


# --------------------------------------------------------------------------------
#
#                                 V E C M X   M A N I P 
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_VmxXtrPos   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Extracts the position columns from the vector matrix.

"""
def u_VmxXtrPos( VEC, IxAtt ):

    IxPos       = o_AttIxPos( IxAtt )

    Pos         = VEC[ :, IxPos ]

    return Pos



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_VmxOmtPos   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Omit (drop) the position columns from the vector matrix.

"""
def u_VmxOmtPos( VEC, Lab ):

    IxAttNew    = u_AttIxAsFields( Lab )
    
    IxPos       = o_AttIxPos( IxAttNew )
    ixLef       = IxPos[0] 
    ixRit       = IxPos[1] 

    VEC         = np.column_stack( ( VEC[:,:ixLef ], VEC[:, ixRit+1: ] ) )

    LabRed      = Lab[ :ixLef ] + Lab[ ixRit+1: ]

    return VEC, LabRed



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_VmxXtrOriAsSinCos   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Extracts the orientation value as coordinates in sinus and cosinus values.

"""
def u_VmxXtrOriAsSinCos( VEC, IxA ):

    Ori   = VEC[ :, IxA.ori ]
    
    return f_AngOriToSinCos( Ori )



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_VmxExpndOriToCoo   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Expands the orientation column to coordinates and inserts them into VEC.
Expands the label array by labels 'sin' and 'cos'.

"""
def u_VmxExpndOriToCoo( VEC: np.ndarray, IxAtt, Lab ) -> tuple[np.ndarray, list[str]]:

    ixOri       = IxAtt.ori
    
    Ori         = VEC[ :, ixOri ]
    
    ORIcoo      = f_AngOriToSinCos( Ori )

    VEC         = np.column_stack( ( VEC[ :, :ixOri ], ORIcoo, VEC[:, ixOri+1: ] ) )

    LabNew      = Lab[ :ixOri ] + lbAngCoo + Lab[ ixOri+1: ]

    return VEC, LabNew    


# --------------------------------------------------------------------------------
#
#                       P R E P   V E C T O R   M A T R I C E S 
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttCntOriExpand   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Expands ori-angle to coordinates. Does not drop any dimensions.

"""
def o_AttCntOriExpand( V ):

    LBATT  = o_AttsLabels()
    LabC   = LBATT.Cnt
    
    IxC    = u_AttIxAsFields( LabC )

    V, LbR = u_VmxExpndOriToCoo( V, IxC, LabC ) # 2) expand ori to coord

    IxR    = u_AttIxAsFields( LbR )

    Jatt   = dclsAttInfo( Lb=LbR, Ix=IxR )

    return V, Jatt


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttDscOriExpand   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Expands ori-angle to coordinates. Does not drop any dimensions.

"""
def o_AttDscOriExpand( V, LbAtt ):

    assert V.shape[1] == len(LbAtt), (
        f"Dimension mismatch: V has {V.shape[1]} columns, "
        f"but LbAtt has {len(LbAtt)} elements."
    )

    IxC    = u_AttIxAsFields( LbAtt )

    V, LbR = u_VmxExpndOriToCoo( V, IxC, LbAtt ) 

    IxR    = u_AttIxAsFields( LbR )

    Jatt   = dclsAttInfo( Lb=LbR, Ix=IxR )

    return V, Jatt


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttCntPosSep   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Separates geometry from position and expands ori-angle to coordinates, for the
contour descriptor.

Three steps:
1) extract position 
2) expand ori angle to coordinates
3) drop position

"""
def o_AttCntPosSep( V ):

    LBATT  = o_AttsLabels()
    LabC   = LBATT.Cnt
    
    IxC    = u_AttIxAsFields( LabC )

    #IxPos  = o_AttIxPos( IxC )

    POS    = u_VmxXtrPos( V, IxC )              # 1) extract position

    V, LbR = u_VmxExpndOriToCoo( V, IxC, LabC ) # 2) expand ori to coord

    V, LbR = u_VmxOmtPos( V, LbR )              # 3) omit position
    
    IxR    = u_AttIxAsFields( LbR )

    Jatt   = dclsAttInfo( Lb=LbR, Ix=IxR )

    return V, POS, Jatt


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttFrmPosSep   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Separates geometry from position, for the form descriptor.

Two steps:
1) extract position
2) drop position

"""
def o_AttFrmPosSep( V ):

    LBATT  = o_AttsLabels()
    LabF   = LBATT.Frm
    
    IxF    = u_AttIxAsFields( LabF )

    POS    = u_VmxXtrPos( V, IxF )              # 1) extract position

    V, LbR = u_VmxOmtPos( V, LabF )              # 2) omit position
    
    IxR    = u_AttIxAsFields( LbR )

    Jatt   = dclsAttInfo( Lb=LbR, Ix=IxR )

    return V, POS, Jatt


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_AttStrPosSep   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Separates geometry from position and expands ori-angle to coordinates, for the
straighter descriptor.

Three steps:
1) extract position 
2) expand ori angle to coordinates
3) drop position

"""
def o_AttStrPosSep( V ):

    LBATT  = o_AttsLabels()
    LabC   = LBATT.Str
    
    IxC    = u_AttIxAsFields( LabC )

    #IxPos  = o_AttIxPos( IxC )

    POS    = u_VmxXtrPos( V, IxC )              # 1) extract position

    V, LbR = u_VmxExpndOriToCoo( V, IxC, LabC ) # 2) expand ori to coord

    V, LbR = u_VmxOmtPos( V, LbR )              # 3) omit position
    
    IxR    = u_AttIxAsFields( LbR )

    Jatt   = dclsAttInfo( Lb=LbR, Ix=IxR )

    return V, POS, Jatt
