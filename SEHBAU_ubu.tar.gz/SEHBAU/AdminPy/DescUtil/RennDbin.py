"""

Wrapper function for program dbin, fabric & fbrc2arr

"""
import subprocess, platform
from dataclasses import dataclass, asdict


    
""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennDbin   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for dbin.

cf exsbDbin.py

IN    fpDsc   filestem
      fipaOut output filepath
      Args    arguments
OUT   Res     results, incl. standard output/error

"""
def RennDbin( fpDsc, fipaOut, Args, dirExe='' ):

    fpExe = str( dirExe ) + 'dbin'
    
    # ----------   string version   ----------
    cmnd  = fpExe + ' ' + str(fpDsc) + ' ' + str(fipaOut) + ' ' + Args.fpPrm + ' ' + Args.opt

    if platform.system()=='Windows':
        cmnd = cmnd.replace('/', '\\')
    else:
        cmnd = './' + cmnd

    # -----  python 3.11
    Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    
    # --------------------   Verify Proper Termination   --------------------
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        
        print('Program dbin was not executed properly. Output below:' )
        print('Commmand was: ')
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        cmnd2     = cmnd + ' --bDISP 3' 

        Res2 = subprocess.run( cmnd2, shell=True, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')

    return Res.stdout



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennFabric   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for fbrc.

cf exsbDbin.py

IN    fpCbnt  cabinet file, spatial histograms generated with 32x32 grid
      fipaOut output filepath
      Args    arguments
OUT   Res     results, incl. standard output/error

"""
def RennFabric( fpCbnt, fipaOut, Args, dirExe='' ):

    fpExe = str( dirExe ) + 'fabric'
    
    # ----------   string version   ----------
    cmnd  = fpExe + ' ' + str(fpCbnt) + ' ' + str(fipaOut) + ' ' + Args.opt

    if platform.system()=='Windows':
        cmnd = cmnd.replace('/', '\\')
    else:
        cmnd = './' + cmnd

    # -----  python 3.11
    Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    
    # --------------------   Verify Proper Termination   --------------------
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        
        print('Program fabric was not executed properly. Output below:' )
        print('Commmand was: ')
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        cmnd2     = cmnd + ' --bDISP 3' 

        Res2 = subprocess.run( cmnd2, shell=True, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')

    return Res.stdout


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennFbrc2Ar   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for fbrc2arr.

cf exsbDbin.py

IN    fpFbrc  fabric file
      fipaOut output filepath
      Args    arguments
OUT   Res     results, incl. standard output/error

"""
def RennFbrc2Ar( fpFbrc, fipaOut, dirExe='' ):

    fpExe = str( dirExe ) + 'fbrc2arr'
    
    # ----------   string version   ----------
    cmnd  = fpExe + ' ' + str(fpFbrc) + ' ' + str(fipaOut) #+ ' ' + Args.opt

    if platform.system()=='Windows':
        cmnd = cmnd.replace('/', '\\')
    else:
        cmnd = './' + cmnd

    # -----  python 3.11
    Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    
    # --------------------   Verify Proper Termination   --------------------
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        
        print('Program fbrc2arr was not executed properly. Output below:' )
        print('Commmand was: ')
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        cmnd2     = cmnd + ' --bDISP 3' 

        Res2 = subprocess.run( cmnd2, shell=True, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')

    return Res.stdout



