"""

Classification with vector matrices using Multi-Head Attention

"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

class ENC_DscMHA(nn.Module):

    def __init__(self, szEmb, nHed, dimFF):

        super(ENC_DscMHA, self).__init__()
        
        # Ensure embedding size splits evenly across heads
        assert szEmb % nHed == 0, f"szEmb ({szEmb}) must be divisible by nHed ({nHed})"
        
        self.szEmb     = szEmb
        self.nHed       = nHed
        self.szDimHd   = szEmb // nHed  # Dimension per head
        
        # Multi-Head Projections (we project to full szEmb, then split later)
        self.proj_Quy   = nn.Linear(szEmb, szEmb)
        self.proj_Key   = nn.Linear(szEmb, szEmb)
        self.proj_Val   = nn.Linear(szEmb, szEmb)
        
        self.proj_Out   = nn.Linear(szEmb, szEmb)
        
        # Pre-LN Normalization layers
        self.f_Norm1    = nn.LayerNorm(szEmb)
        self.f_Norm2    = nn.LayerNorm(szEmb)
        
        self.ffn = nn.Sequential(
            nn.Linear(szEmb, szEmb * dimFF),
            nn.GELU(),
            nn.Linear(szEmb * dimFF, szEmb)
        )

    def forward(self, DSC, MSK=None):
        """
        Multi-Head Attention, Pre-LN
        DSC   [szBtc csMxnDsc szEmb] raw descriptors
        MSK   [szBtc csMxnDsc      ] padding mask
        """

        RESD = DSC
        X    = self.f_Norm1(DSC)
        
        szB, nDsc, _ = X.shape
        
        # Project and reshape into: [szB, nDsc, nHed, szDimHd]
        # Then permute to:          [szB, nHed, nDsc, szDimHd]
        QUY = self.proj_Quy(X).view(szB, nDsc, self.nHed, self.szDimHd).transpose(1, 2)
        KEY = self.proj_Key(X).view(szB, nDsc, self.nHed, self.szDimHd).transpose(1, 2)
        VAL = self.proj_Val(X).view(szB, nDsc, self.nHed, self.szDimHd).transpose(1, 2)
        
        # Calculate scaled dot-product attention per head
        # Resulting shape: [szB, nHed, nDsc, nDsc]
        SATN = torch.matmul(QUY, KEY.transpose(-2, -1)) / (self.szDimHd ** 0.5)
        
        # Masking padded tokens
        if MSK is not None:
            # Reshape MSK to [szB, 1, 1, nDsc] to broadcast across heads and rows
            MSK2D = MSK.unsqueeze(1).unsqueeze(2) 
            SATN  = SATN.masked_fill(~MSK2D, float('-inf'))
        
        WATN = F.softmax(SATN, dim=-1)
        
        if MSK is not None:
            WATN = WATN.masked_fill(~MSK2D, 0.0)
            
        # --------------------   Aggregate   --------------------
        # [szB, nHed, nDsc, szDimHd]
        CNTXT = torch.matmul(WATN, VAL)
        
        # Concatenate heads back together: 
        # Permute to [szB, nDsc, nHed, szDimHd] -> Reshape to [szB, nDsc, szEmb]
        CNTXT = CNTXT.transpose(1, 2).contiguous().view(szB, nDsc, self.szEmb)
        
        # Linear output projection and residual connection
        DSC = RESD + self.proj_Out(CNTXT)
        
        # --------------------   2nd Feed-Forward Block (Pre-LN)   --------------------
        RESD = DSC
        X    = self.f_Norm2(DSC)
        DSC  = RESD + self.ffn(X)
        
        return DSC


""" ------------------------------   MOD_DSCclsfMHA   ------------------------------

Model for classification of descriptor vector matrices.

"""
class MOD_DSCclsfMHA(nn.Module):

    def __init__(self, nAtt, szEmb, nHed, nLay, dimFF, nCls):

        super(MOD_DSCclsfMHA, self).__init__()

        self.proj_DscUp  = nn.Linear(nAtt, szEmb)
        self.proj_CooUp  = nn.Linear(2, szEmb)

        # Added nHed argument here to feed into encoder layers
        self.f_Encoder = nn.ModuleList([
            ENC_DscMHA(szEmb, nHed, dimFF) for _ in range(nLay)
        ])

        self.f_NormOut = nn.LayerNorm(szEmb)

        self.f_Clsf = nn.Sequential(
            nn.Linear(szEmb, szEmb),
            nn.GELU(),
            nn.Linear(szEmb, nCls)
        )
        
    def forward(self, DSCraw, COOraw, MSK):

        # --------------------   Project   --------------------
        DSC = self.proj_DscUp(DSCraw)
        COO = self.proj_CooUp(COOraw)
        
        # --------------------   Inject Position   --------------------
        DSC = DSC + COO
        
        # --------------------   Encode   --------------------
        # backbone blocks
        for lay in self.f_Encoder:
            DSC = lay(DSC, MSK)

        DSCupd = self.f_NormOut(DSC)
        
        # --------------------   Global Pooling   --------------------
        # averaging non-masked tokens
        DSCmsk  = DSCupd * MSK.unsqueeze(-1).float()
        DscSum  = torch.sum(DSCmsk, dim=1)
        Knts    = torch.sum(MSK, dim=1, keepdim=True).float()
        SCENvec = DscSum / torch.clamp(Knts, min=1.0)
        
        # --------------------   Predict   --------------------
        LOGT = self.f_Clsf(SCENvec)

        return LOGT
