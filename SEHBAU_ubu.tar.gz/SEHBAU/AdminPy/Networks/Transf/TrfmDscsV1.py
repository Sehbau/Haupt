"""

A ViT-like transformer model for classification with the descriptor vector matrices
for segments, ie. contour, form, arc, straighter, etc. Single attention head.


---------------   CLS/DEF SUM   ---------------
class dsetVMXCOO(Dataset):
def COLT_DSC_VAR( BTCH ):
class ENC_Dsc(nn.Module):
class MOD_DSCclsf(nn.Module):

"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# max number of descriptors: corresponds to max length sequence
# Note: I did not check yet, whether a new image exceeds the max.
#csMxnDsc = 1000                 



"""------------------------------   dsetVMXCOO   ------------------------------

    Dataset preparation. It is the same as dsetVMXCOO in DeepSet.py but includes
    coordinates as separate input.

       ADSC: descriptors as vector matrix       {nImg}[nDsc nAtt]
       ACOO: coordinates, vertical & horizontal {nImg}[nDsc 2]
       LbImg: numpy array of labels, shape      [nImg]
"""
class dsetVMXCOO(Dataset):

    def __init__(self, ADSC, ACOO, LbImg):

        self.ADSC  = ADSC
        self.ACOO  = ACOO
        self.LbImg = LbImg
        
    def __len__(self):
        
        return len(self.ADSC)
    
    def __getitem__(self, ix):

        DSC     = self.ADSC[ix]
        COO     = self.ACOO[ix]

        DSCtns  = torch.from_numpy(DSC).float()
        COOtns  = torch.from_numpy(COO).float()
        
        LblI    = int(self.LbImg[ix])
        
        return DSCtns, COOtns, LblI

    
""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   colt_VMXCOO   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Custom collate function for DataLoader.

Same as colt_VMXCOO in DeepSet.py, but:
1) includes coordinates
2) takes a maximum for the desc count: NOT efficient. Better organize as in DeepSet.py

BTCH is a list of tuples: [(DSC, COO, label)_0,
                           (DSC, COO, label)_1
                           ...
                           (DSC, COO, label)_n]
"""
def colt_VMXCOO( BTCH ):

    ADSC   = [item[0] for item in BTCH]
    ACOO   = [item[1] for item in BTCH]
    ALbl   = torch.tensor([item[2] for item in BTCH], dtype=torch.long)
    
    szBtc  = len(BTCH)
    nAtt   = ADSC[0].shape[1]

    mxnDsc = max(Dsc.shape[0] for Dsc in ADSC)
    
    # --- initalize zero-padded tensors
    DSCpad = torch.zeros(szBtc, mxnDsc, nAtt)
    COOpad = torch.zeros(szBtc, mxnDsc, 2)
    MSKpad = torch.zeros(szBtc, mxnDsc, dtype=torch.bool)
    
    # --- fill in the valid contents
    for i in range(szBtc):
        nDsc            = ADSC[i].shape[0]
        DSCpad[i,:nDsc] = ADSC[i]
        COOpad[i,:nDsc] = ACOO[i]
        MSKpad[i,:nDsc] = True
        
    return DSCpad, COOpad, MSKpad, ALbl
    


""" ------------------------------   ENC_Dsc   ------------------------------

Encoder layer.

"""
class ENC_Dsc(nn.Module):
    
    def __init__(self, szEmb, dimFF ):

        super(ENC_Dsc, self).__init__()
        
        self.szEmb     = szEmb
        
        # Projects 2D coordinates [v,h] into the object feature space
        self.proj_Coord = nn.Linear(2, szEmb)
        
        # Standard Single-Head Attention Projections
        self.proj_Quy   = nn.Linear(szEmb, szEmb)
        self.proj_Key   = nn.Linear(szEmb, szEmb)
        self.proj_Val   = nn.Linear(szEmb, szEmb)
        
        self.proj_Out   = nn.Linear(szEmb, szEmb)
        self.f_Norm1    = nn.LayerNorm(szEmb)
        self.f_Norm2    = nn.LayerNorm(szEmb)
        
        self.ffn = nn.Sequential(
            nn.Linear(szEmb, szEmb * dimFF ),
            nn.GELU(),
            nn.Linear(szEmb * dimFF, szEmb)
        )

    def forward(self, DSC, COO, MSK=None):
        """
        DSC   [szBtc csMxnDsc szEmb] raw descriptors
        COO   [szBtc csMxnDsc 2    ] normalized coordinates
        MSK   [szBtc csMxnDsc      ] padding mask
        """
        szB, nDsc, szEmb = DSC.shape
        
        # --------------------   Position Injection   --------------------
        DSC       = DSC + COO
        RESD      = DSC
        # if one layer only
        #PosEmb    = self.proj_Coord(COO)
        
        # --------------------   Attention Projection   --------------------
        QUY = self.proj_Quy(DSC)
        KEY = self.proj_Key(DSC)
        VAL = self.proj_Val(DSC)
        
        # Pure dot-product attention matrix calculation
        # [szB nDsc szEmb]??
        SATN = torch.matmul(QUY, KEY.transpose(-2, -1)) / (self.szEmb ** 0.5)
        
        # Masking Step (Block padded objects)
        if MSK is not None:
            MSK2D    = MSK.unsqueeze(1) # [szB, 1, nDsc] broadcast across rows
            SATN     = SATN.masked_fill( ~MSK2D, float('-inf'))
        
        WATN     = F.softmax(SATN, dim=-1) # attention weights
        
        if MSK is not None:
            WATN = WATN.masked_fill( ~MSK2D, 0.0)

        # --------------------   Aggregate   --------------------
        CNTXT    = torch.matmul(WATN, VAL)
        DSC      = self.f_Norm1(RESD + self.proj_Out(CNTXT))
        DSC      = self.f_Norm2(DSC  + self.ffn(DSC))
        
        return DSC


""" ------------------------------   MOD_DSCclsf   ------------------------------

Model for classification of descriptor vector matrices.

"""
class MOD_DSCclsf(nn.Module):

    def __init__(self, nAtt, szEmb, nLay, dimFF, nCls):

        super(MOD_DSCclsf, self).__init__()

        self.proj_DscUp  = nn.Linear( nAtt, szEmb)
        self.proj_CooUp  = nn.Linear( 2, szEmb )

        self.f_Encoder = nn.ModuleList([
            ENC_Dsc( szEmb, dimFF )
            for _ in range(nLay)
        ])
        # if one encoder layer only:
        # self.BACKB  = ENC_Dsc(szEmb)

        self.f_Clsf = nn.Sequential(
            nn.Linear(szEmb, szEmb),
            nn.GELU(),
            #nn.Dropout(0.1),
            nn.Linear(szEmb, nCls)
        )
        
    def forward(self, DSCraw, COOraw, MSK):

        # --------------------   Project   --------------------
        DSC   = self.proj_DscUp( DSCraw )
        COO   = self.proj_CooUp( COOraw )
        
        # --------------------   Update   --------------------
        for lay in self.f_Encoder:
            DSC = lay( DSC, COO, MSK )

        DSCupd   = DSC
        #DSCupd  = self.BACKB(DSC, COO, MSK)
        
        # --------------------   Global Pooling   --------------------
        # Padded elements are zeroed out so they do not taint the average calculation.
        DSCmsk  = DSCupd * MSK.unsqueeze(-1).float()
        
        # Sum elements and divide by actual valid counts per scene sequence
        DscSum  = torch.sum(DSCmsk, dim=1)
        Knts    = torch.sum(MSK, dim=1, keepdim=True).float()
        SCENvec = DscSum / Knts
        
        # --------------------   Predict   --------------------
        LOGT    = self.f_Clsf(SCENvec)

        return LOGT

    

