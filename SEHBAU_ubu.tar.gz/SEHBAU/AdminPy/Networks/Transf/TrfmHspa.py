"""

A simple ViT-like transformer model with a single attention head (SingAhed) for
classifying spatial histograms. No padding.

Number of cells correspond to sequence length. In our mock example it is fixed, that
is we provide the same number of cells for each image.

---------------   CLS SUM   ---------------
class dsetHspa(Dataset):
class MOD_Hspa_sh(nn.Module):

"""
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import numpy as np


"""------------------------------   dsetHspa   ------------------------------

Prepares the spatial histograms for the dataloader.

"""
class dsetHspa( Dataset ):
    """
    HSP (np.ndarray): [nSmp nCll * nBin] the data matrix, ie. histograms
    Lbl (np.ndarray): [nSmp] labels as integer class IDs
    """
    def __init__(self, HSP, Lbl, nCll, nBin):

        # cast features to float tensor
        self.HSP  = torch.from_numpy(HSP).float() if isinstance(HSP, np.ndarray) else HSP.float()

        # cast labels to long tensor for classification loss (e.g., CrossEntropyLoss)
        self.Lbl  = torch.from_numpy(Lbl).long() if isinstance(Lbl, np.ndarray) else Lbl.long()
            
        self.nCll = nCll
        self.nBin = nBin

    def __len__(self):
        return self.HSP.shape[0]

    def __getitem__(self, Ix):

        RSH   = self.HSP[Ix].view( self.nCll, self.nBin ) # reshape on the fly
        Lbl   = self.Lbl[Ix]
        
        return RSH, Lbl


""" ------------------------------   MOD_Hspa_sh   ------------------------------

Single attention head (sh). No dropout (because it did not really help during learning).

"""
class MOD_Hspa_sh(nn.Module):
    
    def __init__( self, nBin, szEmb, nLay, nCll, nCtg, dimFF ):

        super().__init__()
        
        self.f_InpProj = nn.Linear( nBin, szEmb )
        
        self.WgtPos    = nn.Parameter( torch.zeros(1, nCll, szEmb) )
        
        f_LayEncod     = nn.TransformerEncoderLayer(
            d_model     = szEmb,
            nhead       = 1,
            dim_feedforward = szEmb * dimFF,
            batch_first = True,
            activation  = 'gelu'
        )
        
        self.f_Encoder = nn.TransformerEncoder(
            f_LayEncod, 
            num_layers = nLay
        )

        self.f_Clsf    = nn.Linear(szEmb, nCtg)

    def forward(self, HSP):

        szBtc, nCll, _ = HSP.shape             # 3rd is nBin
        
        OUT     = self.f_InpProj(HSP) + self.WgtPos[:, :nCll, :]
        
        OUT     = self.f_Encoder(OUT)           # [szBtc nCll szEmb]
        
        # condenses the cells (sequence) into a single vector per batch item
        # Alternative: out[:, 0, :] (using the first token's representation)
        OUTmen  = OUT.mean(dim=1)               # [szBtc szEmb]
        
        LOGT    = self.f_Clsf(OUTmen)           # [szBtc nCtg]
        return LOGT


