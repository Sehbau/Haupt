"""A ViT-like set transformer model for classification with TWO descriptor vector
matrices.

More explicitly: A dual-stream Transformer for classification of two variable-length
descriptor sets, with continuous 2-D positional information.

---------------   CLS/DEF SUM   ---------------
class dsetVMXCOO2(Dataset):
def colt_VMXCOO2( BTCH ):
class ENC_Dsc(nn.Module):
class MOD_DSCclsf(nn.Module):

"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader


"""------------------------------   dsetVMXCOO2   ------------------------------

    Dataset preparation. af DeepSetTwo.py

"""
class dsetVMXCOO2(Dataset):

    def __init__(self, ACNTvec, ACNTcoo, AFRMvec, AFRMcoo, LbImg):

        self.ACNTvec  = ACNTvec
        self.ACNTcoo  = ACNTcoo
        self.AFRMvec  = AFRMvec
        self.AFRMcoo  = AFRMcoo
        self.LbImg    = LbImg
        
    def __len__(self):
        
        return len(self.ACNTvec)
    
    def __getitem__(self, ix):

        CNTvec     = self.ACNTvec[ix]
        CNTcoo     = self.ACNTcoo[ix]
        FRMvec     = self.AFRMvec[ix]
        FRMcoo     = self.AFRMcoo[ix]

        CNTvectns  = torch.from_numpy(CNTvec).float()
        CNTcootns  = torch.from_numpy(CNTcoo).float()
        FRMvectns  = torch.from_numpy(FRMvec).float()
        FRMcootns  = torch.from_numpy(FRMcoo).float()
        
        LblI    = int(self.LbImg[ix])
        
        return CNTvectns, CNTcootns, FRMvectns, FRMcootns, LblI

    
""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   colt_VMXCOO2   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Custom collate function for DataLoader.

"""
def colt_VMXCOO2( BTCH ):

    ACNTvec   = [item[0] for item in BTCH]
    ACNTcoo   = [item[1] for item in BTCH]
    AFRMvec   = [item[2] for item in BTCH]
    AFRMcoo   = [item[3] for item in BTCH]
    ALbl      = torch.tensor([item[4] for item in BTCH], dtype=torch.long)
    
    szBtc     = len(BTCH)
    nAttCnt   = next(Cnt.shape[1] for Cnt in ACNTvec if Cnt.shape[0] > 0)
    nAttFrm   = next(Frm.shape[1] for Frm in AFRMvec if Frm.shape[0] > 0)

    mxnCnt    = max(Cnt.shape[0] for Cnt in ACNTvec)
    mxnFrm    = max(Frm.shape[0] for Frm in AFRMvec)
    mxnCnt    = max(mxnCnt, 1)  
    mxnFrm    = max(mxnFrm, 1)  
    
    # --- initalize zero-padded tensors
    CNTVECpad = torch.zeros(szBtc, mxnCnt, nAttCnt)
    CNTCOOpad = torch.zeros(szBtc, mxnCnt, 2)
    CNTMSKpad = torch.zeros(szBtc, mxnCnt, dtype=torch.bool)
    FRMVECpad = torch.zeros(szBtc, mxnFrm, nAttFrm)
    FRMCOOpad = torch.zeros(szBtc, mxnFrm, 2)
    FRMMSKpad = torch.zeros(szBtc, mxnFrm, dtype=torch.bool)
    
    # --- fill in the valid contents
    for i in range(szBtc):

        nCnt            = ACNTvec[i].shape[0]
        if nCnt:
            CNTVECpad[i,:nCnt] = ACNTvec[i]
            CNTCOOpad[i,:nCnt] = ACNTcoo[i]
            CNTMSKpad[i,:nCnt] = True

        nFrm            = AFRMvec[i].shape[0]
        if nFrm:
            FRMVECpad[i,:nFrm] = AFRMvec[i]
            FRMCOOpad[i,:nFrm] = AFRMcoo[i]
            FRMMSKpad[i,:nFrm] = True
        
    return CNTVECpad, CNTCOOpad, CNTMSKpad, FRMVECpad, FRMCOOpad, FRMMSKpad, ALbl

    
""" ------------------------------   ENC_Dsc   ------------------------------

Encoder layer.

"""
class ENC_Dsc(nn.Module):

    def __init__(self, szEmb, dimFF):

        super(ENC_Dsc, self).__init__()

        self.szEmb = szEmb
        
        # Standard Single-Head Attention Projections
        self.proj_Quy   = nn.Linear(szEmb, szEmb)
        self.proj_Key   = nn.Linear(szEmb, szEmb)
        self.proj_Val   = nn.Linear(szEmb, szEmb)
        
        self.proj_Out   = nn.Linear(szEmb, szEmb)
        
        # Pre-LN setup: Apply normalization BEFORE the operations
        self.f_Norm1    = nn.LayerNorm(szEmb)
        self.f_Norm2    = nn.LayerNorm(szEmb)
        
        self.ffn = nn.Sequential(
            nn.Linear(szEmb, szEmb * dimFF),
            nn.GELU(),
            nn.Linear(szEmb * dimFF, szEmb)
        )

    def forward(self, DSC, MSK=None):
        """
        Single-Head Attention, Pre-LN
        DSC   [szBtc csMxnDsc szEmb] raw descriptors
        MSK   [szBtc csMxnDsc      ] padding mask
        """
        # --------------------   Attention (Pre-LN)   --------------------
        RESD = DSC
        X    = self.f_Norm1(DSC) # Normalize first
        
        QUY  = self.proj_Quy(X)
        KEY  = self.proj_Key(X)
        VAL  = self.proj_Val(X)
        
        # attention scores
        SATN = torch.matmul(QUY, KEY.transpose(-2, -1)) / (self.szEmb ** 0.5)
        
        if MSK is not None:
            MSK2D = MSK.unsqueeze(1) # [szB, 1, nDsc] broadcast across rows
            SATN  = SATN.masked_fill(~MSK2D, float('-inf'))
        
        # attention weights
        WATN = F.softmax(SATN, dim=-1)
        
        if MSK is not None:
            WATN = WATN.masked_fill(~MSK2D, 0.0)

        # --------------------   Aggregate   --------------------
        CNTXT = torch.matmul(WATN, VAL)
        DSC   = RESD + self.proj_Out(CNTXT) # Add residual to the un-normalized input
        
        # --------------------   2nd Feed-Forward Block (Pre-LN)   --------------------
        RESD  = DSC
        X     = self.f_Norm2(DSC)
        DSC   = RESD + self.ffn(X)
        
        return DSC

""" ------------------------------   MOD_DSCclsf   ------------------------------

Model for classification of descriptor vector matrices.

"""
class MOD_DSCclsf(nn.Module):
    
    def __init__(self, nAttCnt, nAttFrm, szEmb, nLay, dimFF, nCls):
        
        super(MOD_DSCclsf, self).__init__()

        self.proj_CntVecUp  = nn.Linear(nAttCnt, szEmb)
        self.proj_FrmVecUp  = nn.Linear(nAttFrm, szEmb)
        self.proj_CntCooUp  = nn.Linear(2, szEmb)
        self.proj_FrmCooUp  = nn.Linear(2, szEmb)

        self.f_EncodCnt = nn.ModuleList([
            ENC_Dsc(szEmb, dimFF) for _ in range(nLay)
        ])
        self.f_EncodFrm = nn.ModuleList([
            ENC_Dsc(szEmb, dimFF) for _ in range(nLay)
        ])

        # Final normalization block because Pre-LN outputs un-normalized states
        self.f_NormOutCnt = nn.LayerNorm(szEmb)
        self.f_NormOutFrm = nn.LayerNorm(szEmb)

        self.f_Clsf = nn.Sequential(
            nn.Linear(szEmb*2, szEmb),
            nn.GELU(),
            nn.Linear(szEmb, nCls)
        )
        
    def forward(self, CNTvecRaw, CNTcooRaw, CNTMSK, FRMvecRaw, FRMcooRaw, FRMMSK):

        # --------------------   Project   --------------------
        CNTvec = self.proj_CntVecUp(CNTvecRaw)
        CNTcoo = self.proj_CntCooUp(CNTcooRaw)
        FRMvec = self.proj_FrmVecUp(FRMvecRaw)
        FRMcoo = self.proj_FrmCooUp(FRMcooRaw)
        
        # --------------------   Inject Position   --------------------
        CNTvec = CNTvec + CNTcoo
        FRMvec = FRMvec + FRMcoo
        
        # --------------------   Encode   --------------------
        for lay in self.f_EncodCnt:
            CNTvec = lay(CNTvec, CNTMSK)
        for lay in self.f_EncodFrm:
            FRMvec = lay(FRMvec, FRMMSK)

        # Apply final norm layer required by Pre-LN
        CNTupd = self.f_NormOutCnt(CNTvec)
        FRMupd = self.f_NormOutFrm(FRMvec)
        
        # --------------------   Global Pooling   --------------------
        CNTmlt  = CNTupd * CNTMSK.unsqueeze(-1).float()
        FRMmlt  = FRMupd * FRMMSK.unsqueeze(-1).float()
        
        CntSum  = torch.sum(CNTmlt, dim=1)
        FrmSum  = torch.sum(FRMmlt, dim=1)
        Kcnt    = torch.sum(CNTMSK, dim=1, keepdim=True).float()
        Kfrm    = torch.sum(FRMMSK, dim=1, keepdim=True).float()
        
        # Avoid potential division by zero if an empty sequence gets passed
        SCENcnt = CntSum / torch.clamp(Kcnt, min=1.0)
        SCENfrm = FrmSum / torch.clamp(Kfrm, min=1.0)

        SCENvec = torch.cat((SCENcnt, SCENfrm), dim=1)
        
        # --------------------   Predict   --------------------
        LOGT = self.f_Clsf(SCENvec)

        return LOGT



