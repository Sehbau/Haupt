"""

Deep sets network. Classification of ONE descriptor type.

INP     DSC   [nDsc nAtt], number of descriptors x number of attributes

"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader



""" ------------------------------   dsetVMX1   ------------------------------

    Dataset preparation.

       ADSC: descriptors as vector matrix       {nImg}[nDsc nAtt]   nDsc is variable
       LbImg: numpy array of labels, shape      [nImg]
"""
class dsetVMX1(Dataset):

    def __init__(self, ADSC, LbImg):

        self.ADSC   = ADSC
        self.LbImg  = LbImg
        
    def __len__(self):

        return len(self.ADSC)
    
    def __getitem__(self, ix):

        DSC     = self.ADSC[ix]

        DSCtns  = torch.from_numpy(DSC).float()
        
        LblI    = int(self.LbImg[ix])
        
        return DSCtns, LblI



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   colt_VMX1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Custom collate function for DataLoader.

Pads variable-length sequences up to the longest sample IN THIS SPECIFIC BATCH.

BTCH is a list of tuples: [(DSC, label)_0,
                           (DSC, label)_1
                           ...
                           (DSC, label)_n]

"""
def colt_VMX1( BTCH ):

    ADSC   = [item[0] for item in BTCH]
    ALbl   = torch.tensor([item[1] for item in BTCH], dtype=torch.long)
    
    szBtc  = len(BTCH)

    # safely find nAtt even if some matrices are empty (0, nAtt)
    nAtt   = next(Dsc.shape[1] for Dsc in ADSC if Dsc.shape[0] > 0)
    #nAtt   = ADSC[0].shape[1]

    mxnDsc = max(Dsc.shape[0] for Dsc in ADSC)
    # ensure tensors can form shapes, in case no descs are present at all (RARE)
    mxnDsc = max(mxnDsc, 1)  
    
    # --- initalize zero-padded tensors
    DSCpad = torch.zeros(szBtc, mxnDsc, nAtt, dtype=torch.float32)
    MSKpad = torch.zeros(szBtc, mxnDsc, dtype=torch.bool)
    
    # --- fill in the valid contents
    for i in range(szBtc):
        nDsc             = ADSC[i].shape[0]
        if nDsc > 0:
            DSCpad[i,:nDsc]  = ADSC[i]
            MSKpad[i,:nDsc]  = True
        
    return DSCpad, MSKpad, ALbl


""" ------------------------------   PROC_DscOne   ------------------------------

Process descriptor vectors, phi and rho networks.

"""
class PROC_DscOne(nn.Module):

    def __init__(self, nAtt, dimHid):

        super().__init__()

        dimHid2 = int(dimHid*2)
        
        self.net_Phi = nn.Sequential(
            nn.Linear(nAtt, dimHid),
            nn.GELU(),
            #nn.Linear(dimHid, dimHid2),
            #nn.GELU(),
            #nn.LayerNorm(dimHid) # did not improve
        )
        
        self.net_Rho = nn.Sequential(
            nn.Linear(dimHid + 1, dimHid), 
            nn.GELU()
            #nn.Linear(dimHid)
        )

    def forward(self, DSC, MASK=None):

        # DSC shape: [szBtc nDsc nAtt]
        
        # --------------------   Phi Network   --------------------
        PHI   = self.net_Phi(DSC) # [szBtc nDsc dimHid]

        # --------------------   Aggregation   --------------------
        if MASK is not None:

            # check if descriptors are present (in MOST cases yes)
            BdscPres = MASK.sum(dim=1, keepdim=True) > 0  # [szBtc, 1]
            
            # -----  Max  -----
            PHImax  = PHI.masked_fill( ~MASK.unsqueeze(-1), float('-inf') )
            PHImax  = PHImax.masked_fill( ~BdscPres.unsqueeze(-1), 0.0) 
            POOLmax = PHImax.max(dim=1).values

            # -----  Sum  -----
            PHIsum  = PHI.masked_fill( ~MASK.unsqueeze(-1), 0 )

            POOLsum = PHIsum.sum(dim=1)

            # -----  Mean  -----
            PHImen  = PHI.masked_fill( ~MASK.unsqueeze(-1), 0 )

            nValidRaw = MASK.sum(dim=1, keepdim=True) 
            nValid    = nValidRaw.clamp(min=1) 
            #nValid    = MASK.sum(dim=1, keepdim=True).clamp(min=1) # nDsc
            
            POOLmen = PHImen.sum(dim=1) / nValid

            # -----  Std  -----
            DF2M    = (PHI - POOLmen.unsqueeze(1))
            DF2M    = DF2M.masked_fill( ~MASK.unsqueeze(-1), 0.0)

            POOLvar = (DF2M ** 2).sum(dim=1) / nValid
            POOLstd = torch.sqrt(POOLvar + 1e-6)

            # Zero out the metrics completely for samples that had 0 descriptors
            POOLsum = torch.where(BdscPres, POOLsum, 0.0)
            POOLmax = torch.where(BdscPres, POOLmax, 0.0)
            POOLmen = torch.where(BdscPres, POOLmen, 0.0)
            POOLstd = torch.where(BdscPres, POOLstd, 0.0)

            # FIX 5: Use raw count for feature representation so empty sets reflect 0
            nDesc = torch.log1p(nValidRaw.float()) 
            
            #nDesc   = torch.log1p(nValid) # nDsc as normalized feature

        else:
            
            POOLmax = PHI.max(dim=1).values
            POOLmen = PHI.mean(dim=1)
            POOLsum = PHI.sum(dim=1)

            DF2M    = (PHI - POOLmen.unsqueeze(1))
            POOLvar = (DF2M ** 2).sum(dim=1) / PHI.shape[1] 
            POOLstd = torch.sqrt(POOLvar + 1e-6)

            nDesc = torch.full(
                (PHI.shape[0], 1), # szBtc
                np.log1p(PHI.shape[1]), # nDsc
                device=PHI.device
            )
        
        # Concatenate them into a fixed size: [szBtc dim+1]
        DCAT    = torch.cat([POOLsum, nDesc], dim=-1)
        #DCAT    = torch.cat([POOLmax, POOLmen, POOLstd, nDesc], dim=-1)
        
        # --------------------   Rho Network   --------------------
        return self.net_Rho(DCAT) # [szBtc dimHid]


""" ------------------------------   MOD_DSCOneClsf   ------------------------------

Model for classification of descriptor vector matrices.

"""
class MOD_DSCOneClsf(nn.Module):

    def __init__(self, nAtt, dimHid, nCls):

        super(MOD_DSCOneClsf, self).__init__()

        self.f_Proc = PROC_DscOne( nAtt, dimHid )

        self.f_Clsf = nn.Sequential( nn.Linear(dimHid, nCls) )
        
    def forward(self, DSCraw, MSK):

        PROC     = self.f_Proc( DSCraw, MSK )

        LOGT     = self.f_Clsf( PROC )
        
        return LOGT
    
