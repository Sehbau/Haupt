"""

Same as module DeepSetDsc.py but for TWO descriptors, here labeled Cnt and Frm.

"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader


""" ------------------------------   dsetVMX2   ------------------------------

    Dataset preparation.
"""
class dsetVMX2(Dataset):

    def __init__(self, ACNT, AFRM, LbImg):

        self.ACNT  = ACNT
        self.AFRM  = AFRM
        self.LbImg = LbImg
        
    def __len__(self):

        return len(self.ACNT)
    
    def __getitem__(self, ix):

        CNT     = self.ACNT[ix]
        FRM     = self.AFRM[ix]

        CNTtns  = torch.from_numpy(CNT).float()
        FRMtns  = torch.from_numpy(FRM).float()
        
        LblI    = int(self.LbImg[ix])
        
        return CNTtns, FRMtns, LblI


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   colt_VMX2   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Custom collate function for DataLoader.

"""
def colt_VMX2( BTCH ):

    ACNT   = [item[0] for item in BTCH]
    AFRM   = [item[1] for item in BTCH]
    ALbl   = torch.tensor([item[2] for item in BTCH], dtype=torch.long)
    
    szBtc     = len(BTCH)
    # safely find nAtt even if some matrices are empty (0, nAtt)
    nAttCnt   = next(Cnt.shape[1] for Cnt in ACNT if Cnt.shape[0] > 0)
    nAttFrm   = next(Frm.shape[1] for Frm in AFRM if Frm.shape[0] > 0)
    #nAttCnt   = ACNT[0].shape[1]
    #nAttFrm   = AFRM[0].shape[1]

    mxnCnt = max(Cnt.shape[0] for Cnt in ACNT)
    mxnFrm = max(Frm.shape[0] for Frm in AFRM)
    # ensure tensors can form shapes, in case no descs are present at all (RARE)
    mxnCnt = max(mxnCnt, 1)  
    mxnFrm = max(mxnFrm, 1)  

    # --- initalize zero-padded tensors
    CNTVECpad = torch.zeros(szBtc, mxnCnt, nAttCnt)
    CNTMSKpad = torch.zeros(szBtc, mxnCnt, dtype=torch.bool)
    FRMVECpad = torch.zeros(szBtc, mxnFrm, nAttFrm)
    FRMMSKpad = torch.zeros(szBtc, mxnFrm, dtype=torch.bool)
    
    # --- fill in the valid contents
    for b in range(szBtc):

        nCnt  = ACNT[b].shape[0]
        if nCnt:
            CNTVECpad[b,:nCnt]  = ACNT[b]
            CNTMSKpad[b,:nCnt]  = True

        nFrm  = AFRM[b].shape[0]
        if nFrm:
            FRMVECpad[b,:nFrm]  = AFRM[b]
            FRMMSKpad[b,:nFrm]  = True
        
    return CNTVECpad, CNTMSKpad, FRMVECpad, FRMMSKpad, ALbl



""" ------------------------------   PROC_DscTwo   ------------------------------

Process two descriptor sets.

"""
class PROC_DscTwo(nn.Module):

    def __init__(self, nAttCnt, nAttFrm, dimHid):

        super().__init__()

        dimHid2 = int(dimHid)
        
        self.net_PhiCnt = nn.Sequential(
            nn.Linear(nAttCnt, dimHid),
            nn.GELU(),
            #nn.Linear(dimHid, dimHid2),
            #nn.GELU(),
            #nn.LayerNorm(dimHid) # did not improve
        )

        self.net_PhiFrm = nn.Sequential(
            nn.Linear(nAttFrm, dimHid),
            nn.GELU(),
            #nn.Linear(dimHid, dimHid2),
            #nn.GELU(),
            #nn.LayerNorm(dimHid) # did not improve
        )
        
        self.net_Rho = nn.Sequential(
            nn.Linear(dimHid2 * 2 + 1, dimHid), 
            nn.GELU()
            #nn.Linear(dimHid)
        )

    def forward(self, CNTVEC, FRMVEC, CNTMSK=None, FRMMSK=None):

        # DSC shape: [szBtc nDsc nAttCnt]
        
        # --------------------   Phi Network   --------------------
        PHICNT   = self.net_PhiCnt(CNTVEC) # [szBtc nDsc dimHid]
        PHIFRM   = self.net_PhiFrm(FRMVEC) # [szBtc nDsc dimHid]

        # --------------------   Aggregation   --------------------
        if CNTMSK is not None:

            # check if contours are present (in MOST cases yes)
            BcntPres   = CNTMSK.sum(dim=1, keepdim=True) > 0  # [szBtc, 1]

            PHImenCnt  = PHICNT.masked_fill( ~CNTMSK.unsqueeze(-1), 0 )

            nValidRaw  = CNTMSK.sum(dim=1, keepdim=True)
            nValid     = nValidRaw.clamp(min=1) 

            POOLmenCnt = PHImenCnt.sum(dim=1) / nValid

            POOLmenCnt = torch.where(BcntPres, POOLmenCnt, 0.0)

            nDesc   = torch.log1p(nValidRaw.float()) 

        else:
            
            POOLmenCnt = PHICNT.mean(dim=1)

            nDesc = torch.full(
                (PHI.shape[0], 1), # szBtc
                np.log1p(PHI.shape[1]), # nDsc
                device=PHI.device
            )
        
        if FRMMSK is not None:
            
            BfrmPres   = FRMMSK.sum(dim=1, keepdim=True) > 0  # [szBtc, 1]

            PHImenFrm  = PHIFRM.masked_fill( ~FRMMSK.unsqueeze(-1), 0 )

            nValid     = FRMMSK.sum(dim=1, keepdim=True).clamp(min=1) # nDsc

            POOLmenFrm = PHImenFrm.sum(dim=1) / nValid

            POOLmenFrm = torch.where(BfrmPres, POOLmenFrm, 0.0)

        else:

            POOLmenFrm = PHIFRM.mean(dim=1)

        # Concatenate them into a fixed size: [szBtc dimHid*3+1]
        DCAT    = torch.cat([POOLmenCnt, POOLmenFrm, nDesc], dim=-1)
        
        # --------------------   Rho Network   --------------------
        return self.net_Rho(DCAT) # [szBtc dimHid]


""" ------------------------------   MOD_DSCTwoClsf   ------------------------------

Model for classification of descriptor vector matrices.

"""
class MOD_DSCTwoClsf(nn.Module):

    def __init__(self, nAttCnt, nAttFrm, dimHid, nCls):

        super(MOD_DSCTwoClsf, self).__init__()

        self.f_Proc = PROC_DscTwo( nAttCnt, nAttFrm, dimHid )

        self.f_Clsf = nn.Sequential( nn.Linear(dimHid, nCls) )
        
    def forward(self, CNTVEC, CNTMSK, FRMVEC, FRMMSK ):

        #  some argument positions switched:
        PROC     = self.f_Proc( CNTVEC, FRMVEC, CNTMSK, FRMMSK )

        LOGT     = self.f_Clsf( PROC )
        
        return LOGT
    

    

