"""

"""
import numpy as np
import subprocess
import os
from dataclasses import dataclass, field
from typing import Any

from AdminPy.MtchVec.MetricMeas import *
from AdminPy.Util.CmndSupp import *
from .pso_Mshp1 import *



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class dclsMtchShpTot:
    simBox: int = 0
    disVecMul: Any = 0
    disVecMen: Any = 0
    MxVec: np.ndarray = field(default_factory=lambda: np.zeros(3))
    MxRts: np.ndarray = field(default_factory=lambda: np.zeros(3))
    MxSpk: np.ndarray = field(default_factory=lambda: np.zeros(2))


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   MSHPTOSHP   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

see MSHPTOSHP for comments.
"""
def MSHPTOSHP( aFipaQuy, aFipaRef, PrmFtF, Admin, bDISP ):

    nQuy = len( aFipaQuy )
    nRef = len( aFipaRef )

    if bDISP>0:
        print( f'MSHPTOSHP: {nQuy} x {nRef}' )
    
    # ------------------------------   LIST x LIST   ------------------------------
    @dataclass
    class dclsMtchShp:
        DM: np.ndarray  # distance matrix

    # --- create the mes matrices ---
    M = dclsMtchShp( DM=np.full((nQuy, nRef), np.nan, dtype=np.float32) )

    # tracking maxima
    MxVec = np.zeros(3)
    MxRts = np.zeros(3)
    MxSpk = np.zeros(2)

    for qq in range(nQuy):

        fipQuy = aFipaQuy[qq]
        #fipQuy = os.path.join(Admin.dirShps, aFipaQuy[qq].name)

        for rr in range(nRef):

            fipRef = aFipaRef[rr]
            #fipRef = os.path.join(Admin.dirShps, aFipaRef[rr].name)

            cmnd   = f'"{Admin.pthProg}" "{fipQuy}" "{fipRef}"'
    
            Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

            #cmnd = [Admin.pthProg, fipQuy, fipRef]

            #Res = subprocess.run(cmnd, capture_output=True, text=True, check=True)
                
            v_CmndExec( Res )
        
            # Parse output
            Msv, Rts, Spk = pso_Mshp1( Res.stdout )

            MxVec = np.maximum(MxVec, Msv)
            MxRts = np.maximum(MxRts, Rts)
            MxSpk = np.maximum(MxSpk, Spk)

            dis = np.prod(np.concatenate([Msv, MxRts, MxSpk]))
            M.DM[qq, rr] = dis


    # ------------------------------   analysis   ------------------------------
    Mes = dclsMtchShpTot( MxVec=MxVec, MxRts=MxRts, MxSpk=MxSpk )

    if nQuy > 0 and nRef > 0:

        disVecLev, ODIS = f_MtrFromMM(M.DM, 'ascend' )

        Mes.disVecMul = disVecLev.mul
        Mes.disVecMen = disVecLev.men
        
    return Mes, M
