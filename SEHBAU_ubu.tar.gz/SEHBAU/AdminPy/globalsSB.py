"""

 Creates global variables:

 PthProg:   absolute paths to program directories
 FipaExe:   absolute file path of executables

"""
import os
from pathlib import Path
#import sys

# ------------------------------   Root Path   ------------------------------
rootSehBau = Path('c:/klab/ppc/SEHBAU/')          # modify to match your path
#rootSehBau = 'fullpath/SEHBAU/'              

#print(f'globalsSB: adding paths to {rootSehBau}...', end="")

# ------------------------------   VARIABLES   ------------------------------
import platform

bOSisWin   = platform.system()=='Windows'         

pthSehqul  = Path('c:/klab/ppc/SEHQUL/')          # for evaluation

exeSuff    = '.exe' if bOSisWin else ''


# ------------------------------   DIRS    ------------------------------
# Dictionary of program directories
DirProg = {
   
    'descExtr': 'DescExtr/',
    'descProc': 'DescProc/',
    'descUtil': 'DescUtil/',
    'mtchVec':  'MtchVec/',
    'mtchHst':  'MtchHst/',
    'mtchTxt':  'MtchTxt/',
    'mtchFbrc': 'MtchFbrc/',
    'focSel':   'FocSel/',
    'shpExtr':  'ShpExtr/',
    'shpMtch':  'ShpMtch/',
    'plcRec':   'DemoPlcRec/',
    'sgrRGB':   'DemoSgrRGB/',
    'baum':     'DemoBaum/'
}

# ------------------------------   ABSOLUTE PATHS of Program DIRECTORIES   ------------------------
# prepends root path to DirProg
PthProg = {}
for key, val in DirProg.items():

   PthProg[key] = rootSehBau / val


# ------------------------------   REL & ABS FILEPATHS to EXECUTABLES   --------------------

# ----------   RELATIVE PATHS   ----------
RelPaExe = {

    # KEY          DIRECTORY   EXECUTABLE

    'dscx':      ('descExtr', 'dscx'),
    'd2vmx':     ('descExtr', 'd2vmx'),
    'dbn2vmx':   ('descExtr', 'dbn2vmx'),
    'h2arr':     ('descExtr', 'h2arr'),
    'hf2arr':    ('descExtr', 'hf2arr'),

    'topx':      ('descProc', 'topx'),
    'cntpat':    ('descProc', 'cntpat'),
    'ratkpt':    ('descProc', 'readatkpt'),
    'dbin':      ('descProc', 'dbin'),
    'fabric':    ('descProc', 'fabric'),
    'fbrc2arr':  ('descProc', 'fbrc2arr'),

    'collhimg':  ('descUtil', 'collhimg'),
    'collvec':   ('descUtil', 'collvec'),
    'collsalc':  ('descUtil', 'collsalc'),
    'collfbrc':  ('descUtil', 'collfbrc'),

    'mvec1':     ('mtchVec', 'mvec1'),
    'mvecL':     ('mtchVec', 'mvecL'),
    'motvec':    ('mtchVec', 'motvec'),

    'mhstL':     ('mtchHst', 'mhstL'),
    'mkolL':     ('mtchHst', 'mkolL'),

    'mfbrcbis':  ('mtchFbrc', 'mfbrcbis'),
    'mfbrchykL': ('mtchFbrc', 'mfbrchykL'),

    'mtxt1':     ('mtchTxt', 'mtxt1'),
    'mtxtc':     ('mtchTxt', 'mtxtc'),

    'focdsc1':   ('focSel', 'focdsc1'),
    'fochst1':   ('focSel', 'fochst1'),
    'fochstL':   ('focSel', 'fochstL'),

    'ptchxL':    ('shpExtr', 'ptchxL'),
    'shpx':      ('shpExtr', 'shpx'),
    'mshp1':     ('shpMtch', 'mshp1'),

    'sgrRGB':    ('sgrRGB', 'sgrRGB'),
   # 'baumfarb':  os.path.join( PthProg['baum'],     'baumfarb'),
   # 'baumgrau':  os.path.join( PthProg['baum'],     'baumgrau'),
}

# ----------   ABSOLUTE PATHS   ----------
# as dictionary
# FipaExe['dscx'], ['h2arr'], etc
FipaExe = {
    key: PthProg[dirKey] / (binName + exeSuff)
    for key, (dirKey, binName) in RelPaExe.items()
}

# ------------------------------ VERIFY EXISTENCE ------------------------
for fn, prna in FipaExe.items():

    if not prna.is_file():
        print(f"WARNING: program {fn} not found: {prna}")

    elif not bOSisWin and not os.access(prna, os.X_OK):
        print(f"WARNING: program {fn} is not executable: {prna}")



