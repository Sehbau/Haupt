"""

 Creates some global variables.

"""

# ------------------------------   Root Path   ------------------------------
rootSehBau = 'c:/klab/ppc/SEHBAU/'              # modify to match your path
#rootSehBau = 'fullpath/SEHBAU/'              

#print(f'globalsSB: adding paths to {rootSehBau}...', end="")

# ------------------------------   VARIABLES   ------------------------------
import platform

bOSisWin   = platform.system()=='Windows'         

pthSehqul  = 'c:/klab/ppc/SEHQUL/'              # for evaluation



# ------------------------------   DIRS    ------------------------------
# Dictionary of program directories
DirProg = {
   
    'descExtr': 'DescExtr/',
    'descUtil': 'DescUtil/',
    'mtchVec':  'MtchVec/',
    'mtchHst':  'MtchHst/',
    'mtchTxt':  'MtchTxt/',
    'focSel':   'FocSel/',
    'shpExtr':  'ShpExtr/',
    'shpMtch':  'ShpMtch/',
    'plcRec':   'DemoPlcRec/',
    'sgrRGB':   'DemoSgrRGB/',
    'baum':     'DemoBaum/'
}

# ------------------------------   PATHABS of Program DIRECTORIES   ------------------------
# prepends root path to DirProg
import sys, os

PthProg = {}
for key, val in DirProg.items():

   PthProg[key] = os.path.join( rootSehBau, val )


# ------------------------------   FILEPATHSABS to Program BINARIES   --------------------
# Dictionary of binary filepaths (absolute).
# appends binary names to PthProg
FipaExe = {

    'dscx':      os.path.join( PthProg['descExtr'], 'dscx'),
    'd2vmx':     os.path.join( PthProg['descExtr'], 'd2vmx'),
    'dbn2vmx':   os.path.join( PthProg['descExtr'], 'dbn2vmx'), # ut
    'h2arr':     os.path.join( PthProg['descExtr'], 'h2arr'), # ut
    'hf2arr':    os.path.join( PthProg['descExtr'], 'hf2arr'), # ut

    'collhimg':  os.path.join( PthProg['descUtil'], 'collhimg'),
    'collvec':   os.path.join( PthProg['descUtil'], 'collvec'),
    'collsalc':  os.path.join( PthProg['descUtil'], 'collsalc'),
    'topx':      os.path.join( PthProg['descUtil'], 'topx'),
    'cntpat':    os.path.join( PthProg['descUtil'], 'cntpat'), # ut
    'ratkpt':    os.path.join( PthProg['descUtil'], 'readatkpt'), # ut
    'dbin':      os.path.join( PthProg['descUtil'], 'dbin'),
    'fabric':    os.path.join( PthProg['descUtil'], 'fabric'), # ut
    'fbrc2arr':  os.path.join( PthProg['descUtil'], 'fbrc2arr'), # ut
    'collfbrc':  os.path.join( PthProg['descUtil'], 'collfbrc'), # ut

    'mvec1':     os.path.join( PthProg['mtchVec'],  'mvec1'),
    'mvecL':     os.path.join( PthProg['mtchVec'],  'mvecL'),
    'motvec':    os.path.join( PthProg['mtchVec'],  'motvec'),

    'mhstL':     os.path.join( PthProg['mtchHst'],  'mhstL'),
    'mkolL':     os.path.join( PthProg['mtchHst'],  'mkolL'),

    'mtxt1':     os.path.join( PthProg['mtchTxt'],  'mtxt1'), # ut
    'mtxtc':     os.path.join( PthProg['mtchTxt'],  'mtxtc'),

    'focdsc1':   os.path.join( PthProg['focSel'],   'focdsc1'),
    'fochst1':   os.path.join( PthProg['focSel'],   'fochst1'),
    'fochstL':   os.path.join( PthProg['focSel'],   'fochstL'),

    'ptchxL':    os.path.join( PthProg['shpExtr'],  'ptchxL' ),
    'shpx':      os.path.join( PthProg['shpExtr'],  'shpx'),
    'mshp1':     os.path.join( PthProg['shpMtch'],  'mshp1'),

    'sgrRGB':    os.path.join( PthProg['sgrRGB'],   'sgrRGB'),
   # 'baumfarb':  os.path.join( PthProg['baum'],     'baumfarb'),
   # 'baumgrau':  os.path.join( PthProg['baum'],     'baumgrau'),
}   


# --- Verify Existence ---
for fn, prna in FipaExe.items():
    
    # Append '.exe' if running on Windows
    if sys.platform.startswith('win'):
        prna = f"{prna}.exe"
        
    # Check if the file exists
    if not os.path.isfile(prna):
        print(f"WWWWWWWWWarning: program {FipaExe[fn]} not found")
        

