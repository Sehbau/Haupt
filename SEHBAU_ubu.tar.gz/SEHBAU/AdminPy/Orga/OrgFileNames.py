"""

Organizational routines and variables for filenames.
- file extensions (suffices)
- file names
- file name formatting
- un petit peu de directory names

------------------------------   CLS SUM   ------------------------------

class fileExtnImg:
class fileExtnFoc:
class fileExtnColl:

class fileNameRep:
class fileNameColl:

class dirNamesExmp:

------------------------------   DEF SUM   ------------------------------
def o_FileExtensions():
def o_FileExtensFoc():
def o_FileExtensColl():

def o_FinaApndExtRepFrmt( fist: str, Fixt ) -> fileNameRep:
def o_FinaApndExtDscx( fist: str, instance: fileExtnImg ) -> fileExtnImg:

def o_FileNameColl( pthColl=None, Fixt=None, fidf=None ):
def o_FileStems( Pths, idf=None, typ=None):

def o_FileNameFrmt( fist: str, ixi: int, ext: str, typ: int = 0) -> str:
def o_FileNameFrmtLst( fist: str, IxI: list, ext: str, typ: int = 0) -> list:

def o_DirsPrependPath(DirNames, pth):
def o_DirNames():

Elsewhere:
- filepaths executables in globalsSB.py

"""
from __future__ import annotations # 3.12
from dataclasses import dataclass, fields, replace
from pathlib import Path
import os
import numpy as np
from typing import List, Optional, Any
from types import SimpleNamespace

from AdminPy.Util.FileIO.LoadData import *
from AdminPy.DescExtr.OrgAtt.OrgAtts import *



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class fileExtnImg:
    """
    The file extensions for image files, descriptors and features.

    see o_FileExtension.m
    """
    # ----- image
    dsc:    str = '.dsc'
    dsbi:   str = '.dsb'
    hsti:   str = '.hst'
    hsflt:  str = '.hsflt'    # flat histograms (dbin)
    hsspa:  str = '.hsspa'    # spatial histograms (dbin)
    fbrc:   str = '.fbrc'     # fabric
    dtop:   str = '.dtop'

    kolm:   str = '.kol'      # kolumns
    txtm:   str = '.txm'      # texture maps
    salc:   str = '.slc'      # saliency
    
    qbbx:   str = '.qbbx'     # proposals bbox
    qdsc:   str = '.qdsc'     # proposals descriptors
    
    # ----- descriptors
    rre:    str = '.rre'
    cvpo:   str = '.cvpo'     # curve partitions organization (deployed yet?)
    
    # ----- features
    cuvKpt: str = '.cuvKpt'
    ruv:    str = '.ruv'
    bspx:   str = '.bspx'
    
    bonBbxRaw: str = '.bonBboxRaw'
    bonBbx: str = '.bonBbox'
    bonAsp: str = '.bonAsp'
    
    # ----- shape
    shp:    str = '.shp'
    
    # -----  conversion
    hari:   str = '.hari'       # ???

    fbArK0: str = '.fbArK0'  # fabric, kolumn 0
    fbArK1: str = '.fbArK1'  # fabric, kolumn 1
    fbArK2: str = '.fbArK2'  # fabric, kolumn 2
    fbArK3: str = '.fbArK3'  # fabric, kolumn 3

    fbArM0: str = '.fbArM0'  # fabric, bias map 0
    fbArM1: str = '.fbArM1'  # 
    fbArM2: str = '.fbArM2'  # 
    fbArM3: str = '.fbArM3'  # 

    fbArN0: str = '.fbArN0'  # fabric, num (count) map 0
    fbArN1: str = '.fbArN1'  # 
    fbArN2: str = '.fbArN2'  # 
    fbArN3: str = '.fbArN3'  # 

    #collHst: str = '.hstc'    # collHimg
    #collSlc: str = '.slcc'    # ???
    
    # ----- maps
    mapUch: str = '.mpu'

    
@dataclass
class fileExtnFoc:
    """
    The file extensions for focus files
    """
    dscf:  str  = '.dsf'        # description universe
    hstf1: str = '.hsf1'        # histogram file used by fochst1
    hstfL: str = '.hsfL'        # histogram
    fbcf: str = '.fbcf'         # fabric
    

@dataclass
class fileExtnColl:
    """ File extensions for collections (concatenated from lists of images).
    Matlab: o_FileExtensColl.m
    """

    # --- collHimg
    hsall = '.hstc'    # ALL attribute histogram 
    hsflt = '.hsFLT'   # flat attribute histogram 
    hsspa = '.hsSPA'   # spatial attribute histogram 

    # --- collSalc
    txgs  = '.txgsc'   # texture global stats
    txgg  = '.txggc'   # texture grid
    txgb  = '.txgbc'   # texture band
    
    appc  = '.appcc'   # appearance
    nfet  = '.nfetc'   # num of features
    cvrg  = '.cvrgc'   # coverage

    # --- fabric
    fbk0  = '.fbk0'    # hyperkolumns layer 0
    fbk1  = '.fbk1'    # hyperkolumns layer 1
    fbk2  = '.fbk2'    
    fbk3  = '.fbk3'
    
    fbm0  = '.fbm0'    # bias maps of layer 0 (1)
    fbm1  = '.fbm1'
    fbm2  = '.fbm2'
    fbm3  = '.fbm3'

    fbn0  = '.fbn0'    # count (num) maps of layer 0 (1)
    fbn1  = '.fbn1'
    fbn2  = '.fbn2'
    fbn3  = '.fbn3'
    
    tst   = '.tst'      # test (development)


@dataclass
class fileNameRep:
    """ Struct holding filenames for representation formats. Used together with
    the routine for appending file extensions.
    """
    dsc: str
    hsti: str
    kolm: str
    salc: str


@dataclass
class fileNameColl:
    """ Filepaths/stems/names of collected description.
    """
    hist: str
    txtr: str
    fbrc: str
    qust: str

    histFs: Optional[str] = None
    salcFs: Optional[str] = None
    fbrcFs: Optional[str] = None

    txgs: Optional[str] = None
    txgg: Optional[str] = None
    txgb: Optional[str] = None

    appc: Optional[str] = None
    nfet: Optional[str] = None
    cvrg: Optional[str] = None

    histi: Optional[str] = None
    hiflt: Optional[str] = None
    hsspa: Optional[str] = None

    fbk0: Optional[str] = None
    fbk1: Optional[str] = None
    fbk2: Optional[str] = None
    fbk3: Optional[str] = None

    fbm0: Optional[str] = None
    fbm1: Optional[str] = None
    fbm2: Optional[str] = None
    fbm3: Optional[str] = None

    tst: Optional[str] = None


@dataclass
class dirNamesExmp:
    """

    Struct holding directory names. This is for example scripts. See
    dclsCollDirNames in Collection/Admin.py for the large-scale version.

    """
    imgs:  str = 'Imgs/'
    coll:  str = 'Coll/'
    desc:  str = 'Desc/'
    dtop:  str = 'Dtop/'
    dbin:  str = 'Dbin/'
    mes:   str = 'Mes/'
    prm:   str = 'Params/'
    rgst:  str = 'Regist/'
    


    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FileExtensions   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

File extensions for image files. In analogy to o_FileExtension.m

"""
def o_FileExtensions():

    return fileExtnImg()


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FileExtensFoc   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

File extensions for focus.

"""
def o_FileExtensFoc():

    return fileExtnFoc()


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FileExtensColl   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

File extensions. In analogy to o_FileExtension.m

"""
def o_FileExtensColl():

    return fileExtnColl()



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FinaApndExtRepFrmt   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Appends the extensions for representation formats.

IN   fina   file stem, ie. 'IMGDAT/Collection/Desc/DSC_'
OUT  S      struct with .dsc, .hsti, .kolm

USE  stem     = [pthBas.DescRef 'DSC_' imna.ref];
     Fixt     = o_FileExtensions();
     Lfps     = o_FinaApndExtRepFrmt( stem, Fixt );
     Lfps.dsc, Lfps.hst, ...

"""
def o_FinaApndExtRepFrmt( fist: str, Fixt ) -> fileNameRep:

#    if Fixt is None:
#        Fixt = o_FileExtensions()

    return fileNameRep(
        dsc  = f"{fist}{Fixt.dsc}",
        hsti = f"{fist}{Fixt.hsti}",
        kolm = f"{fist}{Fixt.kolm}",
        salc = f"{fist}{Fixt.salc}"
    )


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FinaApndExtDscx   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Given a filestem fist, it prepends all file extensions, such that the filepath can
be called by field.

USE   FixtImg, FixtFoc  = sbutil.o_FileExtensions()
      fpDSC             = sbutil.o_FinaApndExtDscx( str(pthOut), FixtImg() )
      fpDSC.dsc  is filepath of description file
      fpDSC.salc is filepath of saliency file
      ...

"""
def o_FinaApndExtDscx( fist: str | Path, Fixt: fileExtnImg ) -> fileExtnImg:

    if not isinstance(fist, str):
        fist = str( fist )
    
    Sfilepaths = {
        f.name: fist + getattr(Fixt, f.name)
        for f in fields(Fixt)
    }
    return replace(Fixt, **Sfilepaths)



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FileNameColl   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Appends file extensions to a filestem. In analogy to o_FileNameColl.m

"""
def o_FileNameColl( pthColl=None, Fixt=None, fidf=None ):

    # --- filestems ---
    S = fileNameColl (
        hist = "HST_ATT",
        txtr = "TXTR",
        fbrc = 'FBRC',
        qust = "HST_QNT"
    )

    # nargin == 0
    if pthColl is None:
        return S

    pthColl = Path(pthColl)

    # nargin > 2
    if fidf is not None:
        S.hist = fidf + S.hist
        S.txtr = fidf + S.txtr
        S.qust = fidf + S.qust

    # ----- More Filestems -----
    S.histFs = str(pthColl / S.hist)
    S.salcFs = str(pthColl / S.txtr)
    S.fbrcFs = str(pthColl / S.fbrc)

    # ----- Full Filepaths -----
    S.txgs = S.salcFs + Fixt.txgs
    S.txgg = S.salcFs + Fixt.txgg
    S.txgb = S.salcFs + Fixt.txgb

    S.appc = S.salcFs + Fixt.appc
    S.nfet = S.salcFs + Fixt.nfet
    S.cvrg = S.salcFs + Fixt.cvrg

    S.tst = S.salcFs + Fixt.tst

    S.histi = S.histFs + Fixt.hsall
    S.hiflt = S.histFs + Fixt.hsflt
    S.hsspa = S.histFs + Fixt.hsspa

    S.fbk0  = S.fbrcFs + Fixt.fbk0   # fabric hyko 0
    S.fbk1  = S.fbrcFs + Fixt.fbk1   # fabric hyko 1
    S.fbk2  = S.fbrcFs + Fixt.fbk2   # 
    S.fbk3  = S.fbrcFs + Fixt.fbk3   # 
    
    S.fbm0  = S.fbrcFs + Fixt.fbm0   # fabric bias maps 0
    S.fbm1  = S.fbrcFs + Fixt.fbm1   # fabric maps 1
    S.fbm2  = S.fbrcFs + Fixt.fbm2   # 
    S.fbm3  = S.fbrcFs + Fixt.fbm3   # 

    S.fbn0  = S.fbrcFs + Fixt.fbn0   # fabric num maps 0
    S.fbn1  = S.fbrcFs + Fixt.fbn1   # fabric maps 1
    S.fbn2  = S.fbrcFs + Fixt.fbn2   # 
    S.fbn3  = S.fbrcFs + Fixt.fbn3   # 

    S.qust = str(pthColl / S.qust)

    return S



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FileStems   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

File stems. In analogy to o_FileStems.m

"""
def o_FileStems( Pths, idf=None, typ=None):

    # Equivalent of nargin == 1
    if idf is None and typ is None:
        return SimpleNamespace(
            dsci = f"{Pths.dsci}/DSC_i",
            dtop = f"{Pths.dtop}/Top_i",
            dbin = f"{Pths.dbin}/Bin_i",
            veci = f"{Pths.veci}/VMX_i",
        )

    # Equivalent of nargin  == 2
    if typ is None:
        return SimpleNamespace(
            dsci = f"{Pths.dsci}/DSC_{idf}",
            dtop = f"{Pths.dtop}/Top_{idf}",
            dbin = f"{Pths.dbin}/Bin_{idf}",
            veci = f"{Pths.veci}/VMX_{idf}",
        )

    if typ == "bin":
        return f"{Pths.dbin}/{idf}"

    elif typ == 'cab_fbrc':
        return SimpleNamespace(
            cbnt  = f"{Pths.dbin}/Cabinet",
            fbrc  = f"{Pths.dbin}/Fbrc_",
        )
    raise ValueError(f"{typ} not specified")



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FileNameFrmt   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

 Generates a formatted filename. So far only two implementations:
 - typ 0:  mere number
 - typ 7:  with 7 leading zeros

 ai ICL_TOPX.m, ICL_DBIN.m

 IN    fist    filestem
       ixi     image index
       ext     extension
       typ     format type
"""
def o_FileNameFrmt( fist: str, ixi: int, ext: str, typ: int = 0) -> str:

    if typ == 0:                                # --- plain number (no modification)
    
        return f"{fist}{ixi}{ext}"
        
    elif typ == 7:                                  # --- leading zeros
    
        # :07d formats the integer with 7 total digits, padded with leading zeros

        return f"{fist}{ixi:07d}{ext}"

    else:

        raise ValueError(f"format type={typ} not implemented.")



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FileNameFrmtLst   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

A list of filenames. Calls the above function.

"""
def o_FileNameFrmtLst( fist: str, IxI: list, ext: str, typ: int = 0) -> list:
    
    return [o_FileNameFrmt( fist, i, ext, typ) for i in IxI ]



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_DirsPrependPath   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

see o_DirsPrependPath.m

"""
def o_DirsPrependPath(DirNames, pth):

    #if not pth.endswith('/'):
     #   pth = pth + '/'

    pth    = Path(pth)

    aFldNa = fields(DirNames)
    nFldNa = len(aFldNa)

    PthsNew = {}

    for d in range(nFldNa):

        dn          = aFldNa[d].name
        PthsNew[dn] = ( pth / getattr(DirNames, dn) )
        #PthsNew[dn] = os.path.join(pth, Path( getattr(DirNames, dn) ))

    return DirNames(**PthsNew)



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_DirNames   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Directory names.m. Only for example scripts.

"""
def o_DirNames():

    return dirNamesExmp

