"""

Saving a list of filenames. 

---------------   DEF SUM   ---------------
def SaveFipaLst( aFina, sfn ):
def SaveFipaLstPrependPath( aFina, pth, sfn ):

"""
from pathlib import Path


# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveFipaLst   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

Saves a list of strings.

better place into SaveData.py

cf 

"""
def SaveFipaLst( aFina, sfn ):

    try:
        with open(sfn, 'w') as fid:
            for item in aFina:

                fid.write( f"{item}\n" )
                
    except IOError:
        raise RuntimeError(f"SaveFipaLst: could not write to {sfn}")


    
""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveFipaLstPrependPath   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

Saves a list of strings, while simultaneously prepending a path.

cf o_RegistSetSave

"""
def SaveFipaLstPrependPath( aFina, pth, sfn ):

    pth = Path( pth )
    sfn = Path( sfn )
    
    try:
        with open(sfn, 'w') as fid:
            for item in aFina:
                
                full_path = pth / item

                fid.write(f"{full_path}\n")

                #fid.write( f"{pth}{item}\n" )  # old version with strings
                
    except IOError:
        raise RuntimeError(f"SaveFipaLstPrependPath: could not write to {sfn}")
