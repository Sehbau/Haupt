function [] = chdirMb()
    chdir('c:/klab/mb/');
end

