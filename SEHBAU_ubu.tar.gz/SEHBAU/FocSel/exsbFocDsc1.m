%
% Runs program focxv1, loads vector file and plots descriptors from vector
% info (approximation).
% 
clear;
run('../AdminMb/globalsSB');

imgNa    = 'img1';
%imgNa    = 'aachen';

%% ---------   DescExtr for selected  image  --------
cd( PthProg.descExtr ); % change to directory where dscx resides
Args    = o_CmndArgs( 'dscx' );

Out = RennDscx( ['Imgs/' imgNa '.jpg'], ['../FocSel/Desc/' imgNa], Args );

cd( PthProg.focSel );

%% ---------   Boundbox   --------
%             top bot lef rit
%Bbox      = [100 400 100 300];  % mitte etwa
%Bbox      = [0 300 0 200];     % links oben
Bbox      = [300 500 200 350];  % rechts unten
%Bbox      = [0 500 200 350];  % rechts 

% turn bounding box and file number into string
bboxStr     = sprintf('%d %d %d %d', Bbox(1), Bbox(2), Bbox(3), Bbox(4));

%% =========   Command   ========
fipaDsc     = ['Desc/'  imgNa '.dsc'];
fipsOut     = ['Focii/' imgNa];        % output filestem 

if ispc
    fipsOut = u_PathToBackSlash(fipsOut); % slash to backslash for windows
end

cmnd      	= ['focdsc1 ' fipaDsc ' ' bboxStr ' ' fipsOut];
[Sts Out]   = system(cmnd);

v_CmndExec( Sts, Out, cmnd, 1);

%% ---------   Load All Output Files   -------
DispLoad( fipaDsc );
[DIMG KtI]          = LoadDescImag(fipaDsc);    % from repo DescExtr
[DFOC KtF]          = LoadFocDesc( [fipsOut '_lev4.dsf'] );    

[LbAtts, LbAttSG]   = o_AttsLabels();
DIMG                = u_DescMxToStcOfArr( DIMG, LbAttSG );
DFOC                = u_DescMxToStcOfArr( DFOC, LbAttSG );

%% --------   Prepare Plotting  -------
% the plotting function 'rectangle' expects [x y width height]
% we convert using function pBboxConvers (in UtilMb)
BxNorm      = p_BboxConvers(Bbox, KtI.szV, KtI.szH);

% we deploy the Plot[Dsc]Pyr functions of the following directory
% addpath('../DescExtr/UtilMb/Plot/');

%% ------------------------------------------------------------
% We plot every descriptor type twice (for verification):
% - once the full set, the entire image
% - once the focus set, the selected subset

%% -----   Plot Contours  -----
PlotCntSpc(DIMG.ACNT, 3, 'Full', BxNorm);
PlotCntSpc(DFOC.ACNT, 4, 'Focus');

%% -----   Plot RadSig  -----
PlotRsgSpc(DIMG.ARSG, 5, 'Full', BxNorm);
PlotRsgSpc(DFOC.ARSG, 6, 'Focus');

%% -----   Plot Arc  -----
PlotArcSpc(DIMG.AARC, 7, 'Full', BxNorm);
PlotArcSpc(DFOC.AARC, 8, 'Focus');

%% -----   Plot Str  -----
PlotStrSpc(DIMG.ASTR, 9, 'Full', BxNorm);
PlotStrSpc(DFOC.ASTR, 10, 'Focus');

%% -----   Plot Shp  -----
PlotShpSpc(DIMG.ASHP, 11, 'Full', BxNorm);
PlotShpSpc(DFOC.ASHP, 12, 'Focus');

