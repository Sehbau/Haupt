%
% Example for executable 'fabric' and 'fbrc2arr'
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'DescUtil'

%% -------   image file and parameters   --------
dirImg      = 'Imgs/';
strImg      = 'room.png';

fpPrm       = 'Params/PrmDbin_Cabinet.txt'; % coarser
%fpPrm      = 'Params/PrmDbin_Fabric.txt'; % finer

fipaImg     = [dirImg  strImg];      	% image path
fistImg     = strImg(1:end-4);
fstmOut 	= ['Desc/' fistImg];        % output file path

fstmOut     = u_PathToBackSlash( fstmOut ); % change to window backslash
Fixt        = o_FileExtensions();

%% --------   Dscx   --------
ArgsDscx        = o_CmndArgs( 'dscx' );
ArgsDscx.opt    = ' --saveRRE --saveCVP  --saveTxm';
v_CmndArgs( ArgsDscx );

[OutDscx]   = RennDscx( fipaImg, fstmOut, ArgsDscx, PthProg.descExtr );
% OutDscx

%% ---------   Dbin   ----------- 
fipaDsc         = [ fstmOut Fixt.dsc];

ArgsDbin        = o_CmndArgs( 'dbin' );
ArgsDbin.fpPrm  = fpPrm; 
ArgsDbin.opt    = '--all';

[OutDbin]   = RennDbin( fipaDsc, fstmOut, ArgsDbin ); 
% OutDbin

%% ---------   Fabric   ----------- 
fipaCbnt    = [fstmOut Fixt.hsspa];
ArgsFbrc    = o_CmndArgs( 'fabric' );
fpDSC       = o_FinaApndExtDscx( fstmOut, Fixt );

pthFbrc     = PthProg.descUtil; 

[OutFbrc]   = RennFbrc(    fipaCbnt,   fstmOut, ArgsFbrc, pthFbrc );
[OutFbAr]   = RennFbrc2Ar( fpDSC.fbrc, fstmOut, [],       pthFbrc );

%% -----------------------------------------------------------------------
%                            LOAD 
%
[FBRC HedFbrc]  = LoadFabric( fpDSC.fbrc );   DispLoad( fpDSC.fbrc );

% adjust some of the bin numbers
[NbinAtt NbinSum] = i_HistBinNumAdjAtt( HedFbrc.NbinAtt );

% now load as arrays as saved with 'fbrc2arr' (RennFbrc2Ar)
% we use LoadCollHist (because it was saved in that format)
fprintf('Loading kolumns...\n');
FK0         = LoadCollHist( fpDSC.fbArK0 );
FK1         = LoadCollHist( fpDSC.fbArK1 );
FK2         = LoadCollHist( fpDSC.fbArK2 );
FK3         = LoadCollHist( fpDSC.fbArK3 );

fprintf('Loading bias maps...\n');
[MP0 Hed0]  = LoadFabricMapAsArr( fpDSC.fbArM0 ); DispLoad( fpDSC.fbArM0 );
[MP1 Hed1]  = LoadFabricMapAsArr( fpDSC.fbArM1 ); 
[MP2 Hed2]  = LoadFabricMapAsArr( fpDSC.fbArM2 ); 
[MP3 Hed3]  = LoadFabricMapAsArr( fpDSC.fbArM3 ); 

%% -----------  verify   -------------
% We compare output of executable fabric with output of fbrc2arr and use
% vertical map of contour and form

% contour
Lin     = MP1(:);
LvrtC   = Lin(1:Hed1.nRix);
MvrtC   = FBRC.MP1.Cnt.Vrt';
DfC     = MvrtC(:) - LvrtC;

% form
LvrtF   = Lin( (1:Hed1.nRix ) + Hed1.nRix*5 );
MvrtF   = FBRC.MP1.Frm.Vrt';
DfF     = MvrtF(:) - LvrtF;

%% -----------------------------------------------------------------------
%                            PLOT 
fprintf('Plotting the different layers...\n');
figBase	= 1;
Irgb  	= imread( fipaImg ); 
hf0     = PlotFbrcMaps( FBRC.MP0, FBRC.K0, figBase,   Irgb );
hf1     = PlotFbrcMaps( FBRC.MP1, FBRC.K1, figBase+1, Irgb );
hf2     = PlotFbrcMaps( FBRC.MP2, FBRC.K2, figBase+2, Irgb );
hf3     = PlotFbrcMaps( FBRC.MP3, FBRC.K3, figBase+3, Irgb );
set(gcf,'name', 'Layer 3');

%% --- for comparison
fprintf('Plotting the texture maps for comparison...\n');
TXM             = LoadTxtrMaps( fpDSC.txm );
figTxtrMaps 	= 5;
PlotTxtrMaps( TXM, figTxtrMaps, Irgb );
set(gcf,'name', 'Texture Maps');
fprintf('done\n');





