@echo off
REM
REM 
REM

REM -----  jpegs
REM set IMG=img1
REM set IMG=build2
REM set IMG=street
REM set IMG=firework
REM set IMG=buildtall
REM set EXT=.jpg

REM -----  pngs
REM set IMG=aachen
set IMG=room
set EXT=.png

echo ------------------------------   dscx   ------------------------------
..\DescExtr\dscx Imgs\%IMG%%EXT% Desc\%IMG% --sfs || ( echo !!!!! dscx failed & exit /b )

echo ------------------------------   dbin   ------------------------------
dbin Desc\%IMG%.dsc Desc\%IMG% Params\PrmDbin_Cabinet.txt || ( call :PrintFailure dbin & exit /b )

echo ------------------------------   fabric   ------------------------------
fabric Desc\%IMG%.hsspa Desc\%IMG% || ( call :PrintFailure fabric & exit /b )

echo Fabric completed.

exit /b


REM FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   PrintFailure   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
:PrintFailure
echo !!!!! Program %~1 failed
exit /b
