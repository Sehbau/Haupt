"""
 Example for executable 'dbin'

 Assumes script is run from dir 'DescUtil'

 Two steps:
 1) run executable 'dscx' with options --saveRRE and --saveCVP
 2) run executable 'dbin' with a parameter file from directory 'Params'

"""
import sys, subprocess
import numpy as np
from pathlib import Path
sys.path.insert(0, '..')
import AdminPy as sb
from AdminPy import DescExtr as dscx

# ------------------------------   Dscx 1 Image   ------------------------------
strImg      = 'room.png'

fipaImg     = Path( 'Imgs/' + strImg )            # image path
fstmOut     = Path( 'Desc/' + strImg[:-4] )     # output file path

ArgsDscx        = sb.Util.o_CmndArgs('dscx')
ArgsDscx.opt    = ' --saveRRE --saveCVP';

StdOut      = dscx.RennDscx( fipaImg, fstmOut, ArgsDscx, sb.PthProg['descExtr'] )

# ------------------------------   Dbin 1 Image   ------------------------------
# -------   Prep  -------
#fpPrm       = '';
#fpPrm       = 'Params/PrmDbin_Example.txt';
fpPrm      = 'Params/PrmDbin_Crude.txt'; 
#fpPrm      = 'Params/PrmDbin_Refnd.txt'
#fpPrm      = 'Params/PrmDbin_Cabinet.txt'; 

Fixt        = sb.Orga.o_FileExtensions()

# ---------   Dbin   ----------- 
fipaDsc         = str(fstmOut) + Fixt.dsc 
ArgsDbin        = sb.Util.o_CmndArgs( 'dbin' )
ArgsDbin.fpPrm  = fpPrm
ArgsDbin.opt    = '--all'

#cd( PthProg.descUtil );
OutDbin         = sb.DescUtil.RennDbin( fipaDsc, fstmOut, ArgsDbin )

# ------------------------------   Load Output   ------------------------------
fpDSC           = sb.Orga.o_FinaApndExtDscx( fstmOut, Fixt )

HCLW, HedClw    = sb.DescExtr.Hist.LoadDescHistClw( fpDSC.hsspa )

"""
[DSC Kt Hed]    = LoadDescUniv( fpDSC.dsc ); DispLoad(fpDSC.dsc);
[DBN Kt]        = LoadDbinUniv( fpDSC.dsbi );   

[HSTI HedHst]   = LoadDescHist( fpDSC.hsti ); DispLoad( fpDSC.hsti );

[HCLW HedClw]   = LoadDescHistClw( fpDSC.hsspa ); DispLoad( fpDSC.hsspa );
[HFLT HedFlt]   = LoadDescHistFlt( fpDSC.hsflt ); DispLoad( fpDSC.hsflt );
"""

# --------   Concatenate Cells   -------------
Nbin            = HCLW.Nbin

HMXTOT          = sb.DescExtr.Hist.u_HistCatClw( HCLW ); 
HMXTOT.shape # [nCells ntBin]

import matplotlib.pyplot as plt
from PIL import Image

Irgb = np.array(Image.open(fipaImg))

# ------------   Plot Overview   ------------------
plt.figure(1)
plt.clf()  # Clear the current figure

# Top-Left Subplot
plt.subplot(2, 2, 1)
plt.imshow(Irgb)

# Top-Right Subplot
plt.subplot(2, 2, 2)

plt.imshow(HCLW.Ncnt, aspect='auto') 
plt.title('Contour Numerosity')

# Bottom Subplot (spans both columns)
plt.subplot(2, 1, 2)
plt.imshow(HMXTOT, aspect='auto')
plt.ylabel('Cells')
plt.xlabel('Bins')
plt.title('All Desctypes Concatenated')

plt.tight_layout() # Ensures labels/titles don't overlap between subplots
plt.show(block=False)         # Renders the window on screen

"""
# ------------   Plot Num Maps   ------------------
figNo       = 2;

# assign the numerosity maps to a separate struct
MNum.Cnt    = HCLW.Ncnt;
MNum.Frm    = HCLW.Nfrm;
MNum.Str    = HCLW.Nstr;
MNum.Arc    = HCLW.Narc;
MNum.Shp    = HCLW.Nshp;

PlotHspaUNIVMaps( MNum, figNo, 'Mnum' );

# --------   Concatenate Cells Per DescType   ----------
HMXCLW  = i0_HistClwUniv( Nbin, HCLW.nCells );

# allocate the arrays: [nCells nBinDty]
CNT     = i0_HistClwDty1( HCLW.nCells, Nbin.Cnt );
FRM     = i0_HistClwDty1( HCLW.nCells, Nbin.Frm );
ARC     = i0_HistClwDty1( HCLW.nCells, Nbin.Arc );
STR     = i0_HistClwDty1( HCLW.nCells, Nbin.Str );
SHP     = i0_HistClwDty1( HCLW.nCells, Nbin.Shp );

for c = 1:HCLW.nCells
    
    CNT.UNI(c,:) = HCLW.ACNT{c}.Uni;
    CNT.BIV(c,:) = HCLW.ACNT{c}.Biv;

    FRM.UNI(c,:) = HCLW.AFRM{c}.Uni;
    FRM.BIV(c,:) = HCLW.AFRM{c}.Biv;

    ARC.UNI(c,:) = HCLW.AARC{c}.Uni;
    ARC.BIV(c,:) = HCLW.AARC{c}.Biv;

    STR.UNI(c,:) = HCLW.ASTR{c}.Uni;
    STR.BIV(c,:) = HCLW.ASTR{c}.Biv;

    SHP.UNI(c,:) = HCLW.ASHP{c}.Uni;
    SHP.BIV(c,:) = HCLW.ASHP{c}.Biv;
    
end

# -------  Plot Individual DescTypes  -------
figure(3); clf;
[nr,nc]=deal(5,2);

subplot(nr,nc,1);
imagesc( CNT.UNI );
title('Univariate');
ylabel('Cnt','fontweight','bold');

subplot(nr,nc,2);
imagesc( CNT.BIV );
title('Bivariate');
ylabel('nCells','fontweight','bold');

subplot(nr,nc,3);
imagesc( FRM.UNI );
ylabel('Frm','fontweight','bold');

subplot(nr,nc,4);
imagesc( FRM.BIV );

subplot(nr,nc,5);
imagesc( ARC.UNI );
ylabel('Arc','fontweight','bold');

subplot(nr,nc,6);
imagesc( ARC.BIV );

subplot(nr,nc,7);
imagesc( STR.UNI );
ylabel('Str','fontweight','bold');

subplot(nr,nc,8);
imagesc( STR.BIV );

subplot(nr,nc,9);
imagesc( SHP.UNI );
ylabel('Shp','fontweight','bold');



fprintf('done\n');
"""
