"""
 Example for executable 'fabric' and 'fbrc2arr'

 Assumes script is run from dir 'DescUtil'

 Three steps:
 1) run executable 'dscx' with options --saveRRE and --saveCVP
 2) run executable 'dbin' with cabinet grid 32x32
 3) now we run fabric on the cabinet

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')
import AdminPy as sb
from AdminPy import DescExtr as dscx
from AdminPy import Collection as cl

# ------------------------------   Dscx (Step 1)   ------------------------------
strImg      = 'room.png'

fipaImg     = Path( 'Imgs/' + strImg )            # image path
fstmOut     = Path( 'Desc/' + strImg[:-4] )     # output file path

ArgsDscx        = sb.Util.o_CmndArgs('dscx')
ArgsDscx.opt    = ' --saveRRE --saveCVP';

StdOut      = dscx.RennDscx( fipaImg, fstmOut, ArgsDscx, sb.PthProg['descExtr'] )

# ------------------------------   Dbin (Step 2)   ------------------------------
fpPrm           = 'Params/PrmDbin_Cabinet.txt'; 
Fixt            = sb.Orga.o_FileExtensions()
fipaDsc         = str(fstmOut) + Fixt.dsc 
ArgsDbin        = sb.Util.o_CmndArgs( 'dbin' )
ArgsDbin.fpPrm  = fpPrm
ArgsDbin.opt    = '--all'

OutDbin         = sb.DescUtil.RennDbin( fipaDsc, fstmOut, ArgsDbin )

# ------------------------------   Fabric & fbrc2arr   ------------------------------
fpDSC           = sb.Orga.o_FinaApndExtDscx( fstmOut, Fixt )
fipaCbnt        = fpDSC.hsspa # [fstmOut Fixt.hsspa];
ArgsFbrc        = sb.Util.o_CmndArgs( 'fabric' );

pthFbrc         = sb.PthProg['descUtil']

# we run both, 'fabric' and 'fbrc2arr'
OutFbrc         = sb.DescUtil.RennFabric( fipaCbnt, fstmOut, ArgsFbrc, pthFbrc )
OutFbAr         = sb.DescUtil.RennFbrc2Ar( fpDSC.fbrc, fstmOut, pthFbrc )


# ------------------------------   Load Output Fabric   ------------------------------
# load from fabric file outputted by 'fabric'
FBRC, HedFbc    = sb.DescExtr.Hist.LoadFabric( fpDSC.fbrc )

# show how to access some fields

# --- individual count maps
print('Count Maps:')
print(FBRC.K0.Ncnt.shape) # layer 0 for contours
print(FBRC.K0.Nfrm.shape) #   "   0 for forms

# concatenate the count (numerosity) maps to a block (third axis=descriptor type)
# [vrt hor nDscTyp]
MKNT0mp = dscx.Fabric.u_FbrcCatKntMap( FBRC.K0 ) # [31 31 5]
MKNT1mp = dscx.Fabric.u_FbrcCatKntMap( FBRC.K1 )
MKNT2mp = dscx.Fabric.u_FbrcCatKntMap( FBRC.K2 )
MKNT3mp = dscx.Fabric.u_FbrcCatKntMap( FBRC.K3 )
# reshape to [nCells nDscTyp]
KNTA0   = MKNT0mp.reshape(-1, MKNT0mp.shape[2]) # [961 5]
KNTA1   = MKNT1mp.reshape(-1, MKNT1mp.shape[2]) # [225 5]
KNTA2   = MKNT2mp.reshape(-1, MKNT2mp.shape[2]) # 
KNTA3   = MKNT3mp.reshape(-1, MKNT3mp.shape[2]) # [  9 5]

# --- part of individual hyperkolumns
print('Cnt Huni' + str(FBRC.K0.ACNT[0].Uni.shape)) # layer 0, cell 0
print('Cnt Huni' + str(FBRC.K0.ACNT[4].Uni.shape)) # layer 0, cell 4

# --- bias maps
print(FBRC.MP0.Cnt['Vrt'].shape) # layer 0
print(FBRC.MP1.Cnt['Vrt'].shape) # layer 1

# number of bins in header
print('Nbin Cnt' + str(HedFbc.NbinAtt.ArcUni))
print('Nbin Arc' + str(HedFbc.NbinDty.Arc))
print('Ndsc ' + str(HedFbc.NbinDty.Ndsc))

# ------------------------------   Load Output Arrays   ------------------------------
# load the 12 files as outputted by executable 'fbrc2arr'

print('Loading kolumns...')
# Kolumn arrays were saved in collection format, therefore we use LoadCollHist
# loading from integer as float
HYKA0, Nbin0  = cl.LoadCollHist( fpDSC.fbArK0 )
HYKA1, Nbin1  = cl.LoadCollHist( fpDSC.fbArK1 )
HYKA2, Nbin2  = cl.LoadCollHist( fpDSC.fbArK2 )
HYKA3, Nbin3  = cl.LoadCollHist( fpDSC.fbArK3 )

print(HYKA0.shape)
print(Nbin0.Cnt)

# ----------   Bias Maps   ----------
# Note that dg1 and dg2 were dropped by fbrc2arr!!
hs           = sb.DescExtr.Hist
MPA0, Hed0   = hs.LoadFabricMapAsArr( fpDSC.fbArM0 )
MPA1, Hed1   = hs.LoadFabricMapAsArr( fpDSC.fbArM1 )
MPA2, Hed2   = hs.LoadFabricMapAsArr( fpDSC.fbArM2 )
MPA3, Hed3   = hs.LoadFabricMapAsArr( fpDSC.fbArM3 )

# ----------   Count Maps   ----------
# were also saved in collection format
# numerosity maps
MNA0, Hdn0   = cl.LoadCollHist( fpDSC.fbArN0 )
MNA1, Hdn1   = cl.LoadCollHist( fpDSC.fbArN1 )
MNA2, Hdn2   = cl.LoadCollHist( fpDSC.fbArN2 )
MNA3, Hdn3   = cl.LoadCollHist( fpDSC.fbArN3 )


# -----------  verify Maps  -------------
# We compare output of executable fabric with output of fbrc2arr and use
# vertical map of contour and form
DfC     = MPA1[:,0] - FBRC.MP1.Cnt['Vrt'].flatten()
DfF     = MPA1[:,5] - FBRC.MP1.Frm['Vrt'].flatten()
DfN     = MNA1[:,0] - FBRC.K1.Ncnt.flatten()
assert DfC.any()==0, 'not correct'
assert DfF.any()==0, 'not correct'
assert DfN.any()==0, 'not correct'

# --------------------------------------------------------------------------------
#                         F O C U S   E X T R A C T I O N 
# --------------------------------------------------------------------------------
# we extract the description for a bounding box
top=5; bot=120; lef=80; rit=260
top=5; bot=320; lef=80; rit=560
top=100; bot=350; lef=0; rit=640-1

fcs      = sb.FocSel                            # AdminPy.FocSel.FocAnf.py

# the scaling factors
PrmScl   = fcs.i_PrmFocSclToFbrc( HedFbc.Hed.szV, HedFbc.Hed.szH )

# the linear indices
IXlin    = dscx.Fabric.f_FocRngsFbrc( top, bot, lef, rit, PrmScl )

# -----  extract focus from arrays
# count (num) maps: these are raw (not normalized)
SKT0     = KNTA0[ IXlin.L0,: ] # [nSel nDscTyp]
SKT1     = KNTA1[ IXlin.L1,: ]
SKT2     = KNTA2[ IXlin.L2,: ]
SKT3     = KNTA3[ IXlin.L3,: ]
# hyperkolumns maps
SHYK0    = HYKA0[ IXlin.L0,: ] # [nSel nBin]
SHYK1    = HYKA1[ IXlin.L1,: ]
SHYK2    = HYKA2[ IXlin.L2,: ]
SHYK3    = HYKA3[ IXlin.L3,: ]
# bias maps
SMP0     = MPA0[ IXlin.L0,: ] # [nSel nBis]
SMP1     = MPA1[ IXlin.L1,: ]
SMP2     = MPA2[ IXlin.L2,: ]
SMP3     = MPA3[ IXlin.L3,: ]

# reshape 'linear maps' to 'spatial' maps
ntBis     = Hed0.nBis*2
SMP0map   = SMP0.reshape( IXlin.ADim[0,0], IXlin.ADim[0,1], ntBis )#, order='F' )
Mvrt      = SMP0map[:,:,0]

# ------------------------------   Plot   ------------------------------
from PIL import Image
Irgb   = np.array(Image.open(fipaImg))

import matplotlib.pyplot as plt
figNo = 1
hf = hs.PlotFbrcMaps( FBRC.MP0, FBRC.K0, figNo, Irgb )
plt.show(block=False)

hf = hs.PlotFbrcMaps( FBRC.MP0, FBRC.K1, figNo+1, Irgb )
plt.show(block=False)

hf = hs.PlotFbrcMaps( FBRC.MP0, FBRC.K2, figNo+2, Irgb )
plt.show(block=False)

hf = hs.PlotFbrcMaps( FBRC.MP0, FBRC.K3, figNo+3, Irgb )
plt.show(block=False)


# -----  plot selection
figSel = 5
hf = plt.figure(figSel)
hf.clf()

nr, nc = 3, 4

ax = hf.add_subplot(nr, nc, 1)
ax.imshow(Irgb)
ax.tick_params(labelsize=5)

ax = hf.add_subplot(nr, nc, 2)
ax.imshow( Mvrt )
ax.set_title('Sel')
plt.show(block=False)



