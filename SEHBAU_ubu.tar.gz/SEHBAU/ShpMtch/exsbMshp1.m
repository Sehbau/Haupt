%
% Example for running shape matching.
%
clear;

[sts, Out] = dos('mshp1 ../ShpExtr/Desc/p48.shp ../ShpExtr/Desc/p49.shp');

assert( sts== 0);
Out

[Mes Rts Spk]  = u_MtrMesShp( Out );

% ensemble:  arc * str * rsg 
ens     = Mes(1) * Mes(2) * Mes(3);




