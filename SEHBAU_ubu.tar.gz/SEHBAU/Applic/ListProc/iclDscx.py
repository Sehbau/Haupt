#
# Runs program 'dscx' for a collection. 
# For collecting stats see iclSalcAly.m
#
# sa exsbDscSimp.m
#
# PREVIOUS  -
# PRESENT   iclDscx.py
# NEXT      iclCollVect.py, iclCollKolm, 
#           iclDbnToVmx, iclMvec.m, iclSalcAly.m ,iclCat... runFocNyu.m
#
import sys
from pathlib import Path
sys.path.insert(0, '../../../SEHBAU')
sys.path.insert(0, '../../../../py/UTIL') # for loading CIF images
from dataclasses import is_dataclass
import AdminPy as sb
import AdminPy.Collection as cl

# --------------------   Collection   --------------------
bas = 7 # OLTO
#bas = 10; # IndOut15
#bas = 17; # SINR45
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 60;  # CAMSDD training
#bas = 61;  # CAMSDD validation
#bas = 62;  # CAMSDD testing
#bas = 50;   # indoor67
#bas = 100   # cifar10
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

## ----------------   Admin & Options   --------------
bSaveDesc       = 0    # =0 means will write to '.\ztst'
dscx            = sb.DescExtr
Args            = sb.Util.o_CmndArgs('dscx')
#Args.fpPrm      = f"Params/Colls/PrmDesc_{Coll.name}.txt"
OptK            = dscx.dclsDscxArgs
#Args            = sb.Util.dclsArgsCmnd          # CmndSupp.py
#Args.optS  = '--depth 2'
if 1:
    OptK.saveRRE    = 1 
    OptK.saveCVP    = 1 
    OptK.saveRegUnv = 1 # region universe. for readatreg
    #OptK.saveKol    = 0
    OptK.saveProp   = 1
    #OptK.imgFlt     = 2
    #OptK.depth      = 2

#OptK.nLev   = 3 ;

Args.opt        = dscx.i_DscxArgs(OptK)
#sb.Util.v_CmndArgs( Args )

# collecting afterwards?
bCollHist       = 1
bCollTxtr       = 1
bPlot           = 0

# -----------------   Paths   ---------------
Pths, Coll  = cl.u_CollPaths( bas )

FixtImg     = sb.Orga.o_FileExtensions()
Fina1       = sb.Orga.o_FileStems( Pths )
FixtColl    = sb.Orga.o_FileExtensColl()
FinaColl    = sb.Orga.o_FileNameColl( Pths.hist, FixtColl )
#nImg        = Coll.nFinas;

pthExe      = sb.PthProg['descExtr']

IxCollReg   = [ 7, 10, 17, 50, 60, 61, 62 ]

## -----------------   Delete Previous Files   -----------------
IxCollDel = [7, 10, 17, 37, 50, *range(60, 63), 100, 200]

if bas in IxCollDel:
    if bSaveDesc > 0:
        cl.u_DescDel( Pths.dsci )


# ------------------------------   LOOP IMAGES   ------------------------------
# There exists IclProc.DSCX(), but due to some of the exceptions we write here an
# explicit loop.

# Selection:
#IxImg   = 1:nImgTren;
#IxImg   = 1936:2000; # nImgTren;
Ix0Img   = Coll.Ix0Img;
nImg     = len(Ix0Img);
#nImg     = 0

if nImg:
    print(f"Running {bas}, nImg {nImg}", end="")

fipaImg  = None
for i in range(0,nImg):

    ix      = Ix0Img[i]

    # --------------------   regular case   --------------------
    if bas in IxCollReg:
        fipaImg = Pths.imgs / Coll.aFinas[ix]

    if bSaveDesc:
        fipsOut = Fina1.dsci + str(ix)
    else:
        fipsOut = '.\ztst'

    # --------------------   exceptions   --------------------
    # we may overwrite some of the previous settings
    if bas==100:
        fipaImg = Pths.imgs / Path( 'I_' + str(ix) + '.png' );

    # verify that something was specified
    if fipaImg==None:
        print("You havent specified an image")
        breakpoint()

    # --------------------   EXECUTE   --------------------
    StdOut  = dscx.RennDscx( fipaImg, fipsOut, Args, pthExe )
        
    # sb.Util.v_CmndExec( Res )

    if i%Coll.stepDisp==0:
        sb.Util.printDotProg()


cl.DispTermNext( 'iclDscx.py', 'iclCollVect.py, iclCollHist.py, iclDbin.py ...' )


# ------------------------------   COLL HIST   ------------------------------
import matplotlib.pyplot as plt
import numpy as np

if bCollHist:

    print('\n-------------------   Collecting   ---------------------\n')

    fpRgst  = 'CollHist.txt'

    bRgstOk = cl.o_RegistGenAndSave( Fina1.dsci, Coll.Ix0Img, FixtImg.hsti, fpRgst )

    if bRgstOk:

        fp      = sb.FipaExe['collhimg']
        cmnd    = f'"{fp}" "{fpRgst}" "{FinaColl.histFs}"'

        Out     = sb.Util.f_CmndExec( cmnd )
        #sb.Util.v_CmndExec( Res )
        #fprintf('done\n');
    
        HESS, NbinE  = cl.LoadCollHist( FinaColl.histi )

        # --------   Plot   ---------
        HstMen   = np.mean(HESS, axis=0)
        HstSum   = np.sum(HESS, axis=0)

        plt.figure(1)

        plt.subplot(2, 1, 1)
        plt.plot(HstSum)
        plt.title("Sum")

        plt.subplot(2, 1, 2)
        plt.plot(HstMen)
        plt.title("Mean")
        
        # 3. Adjust spacing and display the plot
        plt.tight_layout()
        plt.draw()
        plt.pause(0.001)  # Brief pause to let the GUI window render

    else:
        print('register file not complete - no collection occured\n');
