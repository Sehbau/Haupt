#
# Runs program 'fabric' for a collection. 
#
# PREVIOUS  iclDbin.py
# PRESENT   iclFabric.py
# NEXT      
#
import sys, os
from pathlib import Path
sys.path.insert(0, '../../../SEHBAU')
sys.path.insert(0, '../../../../py/UTIL') # for loading CIF images
from dataclasses import is_dataclass
import AdminPy as sb
import AdminPy.Collection as cl

# --------------------   Collection   --------------------
bas = 7 # OLTO
#bas = 10; # IndOut15
#bas = 17; # SINR45
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 60;  # CAMSDD training
#bas = 61;  # CAMSDD validation
#bas = 62;  # CAMSDD testing
#bas = 50;   # indoor67
#bas = 100   # cifar10
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 
    
# ------------------------------   Admin & Options   ------------------------------
bSaveDesc    = 0    # =0 means will write to '.\ztst'

# -----------------   Paths   ---------------
Pths, Jcoll   = cl.u_CollPaths( bas )
FixtImg      = sb.Orga.o_FileExtensions()
Fips1        = sb.Orga.o_FileStems( Pths, '', 'cab_fbrc' )

#nImg        = Jcoll.nFinas;

pthExe       = sb.FipaExe['fabric']

IxCollReg    = [ 7, 10, 17, 50, 60, 61, 62 ]

## -----------------   Delete Previous Files   -----------------
IxCollDel    = [7, 10, 17, 37, 50, *range(60, 63), 100, 200]

if 0: #bas in IxCollDel:
    if bSaveDesc > 0:
        cl.u_DescDel( Pths.dsci )


print(f"Ready to run with {Fips1.fbrc} as file identifier. ", end='')
input("Press Enter to continue...")
    
# ------------------------------   LOOP IMAGES   ------------------------------
# Selection:
#IxImg   = 1:nImgTren;
#IxImg   = 1936:2000; # nImgTren;
Ix0Img   = Jcoll.Ix0Img

os.chdir( sb.PthProg['descUtil'] )

cl.FABRIC( pthExe, Ix0Img, Fips1, FixtImg, 0 )

cl.DispTermNext( 'iclFabric.py', '' )


