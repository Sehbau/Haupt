#
# Collects vectors for different desctypes (for a list of images). 
#
# PREVIOUS  iclDscx.py
# PRESENT   iclCollVect.py
# NEXT      
#
import sys, glob
from pathlib import Path
sys.path.insert(0, '../../../SEHBAU')
sys.path.insert(0, '../../../../py/UTIL') # for loading CIF images
from dataclasses import is_dataclass
import AdminPy as sb
import AdminPy.Collection as cl

bas         = 7 
#bas         = 10 ;
#bas         = 60 ;
#bas         = 62 ;
#bas         = 100 ;

aDty, nDty  = sb.DescExtr.o_DescTypes('cfasst');  nDty=5

# -----------------   Paths   ---------------
Pths, Jcoll  = cl.u_CollPaths( bas )

dirDsc      = Pths.dsci
fpColl      = Pths.coll

# -------   The List of Files   -------
aDscNa2     = glob.glob(f"{dirDsc}/*.dsc")
aDscNa      = sb.Util.o_FileNameFrmtLst( 'DSC_i', Jcoll.Ix0Img, '.dsc', 0 )
breakpoint()

finaLst     = fpColl / "FinasDsc.txt"
sb.Orga.SaveFipaLstPrependPath( aDscNa, dirDsc, finaLst )

# -------   The Program   -------
fpProg      = sb.FipaExe['collvec']

## -----------------------    LOOP DESCTYPES   -----------------------
for d in range(nDty):
    
    dscTyp      = aDty[d]
    dty         = dscTyp.lower()
    sb.Util.DispSec( dty, '-', 0 )
    
    ## -------   Execute Command   --------
    cmnd        = f"{fpProg} {finaLst} {dty} {str(Pths.coll)}/"

    Res         = sb.Util.f_CmndExecRes( cmnd )

    sb.Util.v_CmndExec( Res )

    ## -------   Load Output   --------
    # we load for verification (to ensure the file was properly generated)
    COLLVEC, ntDsc, nAtt  = cl.LoadCollVec( fpColl, dty )
    COLLLab, ntDscL       = cl.LoadCollVecLab( fpColl, dty )

    if ntDsc!=ntDscL:
        print('WWWWARNING: ntDsc not same %d <> %d. Perhaps NaN present', ntDsc, ntDscL )
        # see exsbD2vmx how to proceed.

    # also verification
    #IxCatColl = sb.u_CollImgIxToCatIx( COLLLab[:,1], Jcoll.LabImg )
    


