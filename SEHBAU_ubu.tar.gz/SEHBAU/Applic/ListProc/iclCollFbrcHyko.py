"""

Collecting fabric hyperkolumns and num maps. For bias maps see iclCollFbrcMaps.py

PREVIOUS  iclFabric.py
PRESENT   iclCollFbrcHyko.py
NEXT      

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '../../../SEHBAU')
sys.path.insert(0, '../../../../py/UTIL') # for loading CIF images
from dataclasses import is_dataclass
import AdminPy as sb
import AdminPy.Collection as cl

# --------------------   Collection   --------------------
bas = 7 # OLTO
#bas = 10; # IndOut15
#bas = 17; # SINR45
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 60;  # CAMSDD training
#bas = 61;  # CAMSDD validation
#bas = 62;  # CAMSDD testing
#bas = 50;   # indoor67
#bas = 100   # cifar10
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

# -----------------   Paths   ---------------
Pths, Jcoll = cl.u_CollPaths( bas )
FixtImg     = sb.Orga.o_FileExtensions()
FixtColl    = sb.Orga.o_FileExtensColl()
FinaColl    = sb.Orga.o_FileNameColl( Pths.hist, FixtColl )
Fips1       = sb.Orga.o_FileStems( Pths, '', 'cab_fbrc' )

print(f"Collecting {bas},  {FinaColl.fbm1},  nImg {Jcoll.nImg}...", end="")

## -----------------------------   COLLECT   -----------------------------
if 0:
    cl.ICL_COLLFBRCHYKO( sb.FipaExe['fbrc2arr'], Jcoll.Ix0Img, Fips1,
                         FixtImg, Jcoll.finaFrmt, FinaColl )
if 0:
    cl.ICL_COLLFBRCMNUM( sb.FipaExe['fbrc2arr'], Jcoll.Ix0Img, Fips1,
                         FixtImg, Jcoll.finaFrmt, FinaColl )

# --------------   Load   -------------------
fSet        = 3 # takes the smallest to hyperkolumn hists
bDispLoad   = 1 
FBRC, Nbin  = cl.LoadCollFbrcHyko( FinaColl, fSet, bDispLoad )

FMPN0, Dim0 = cl.LoadCollFbrcMnum( FinaColl, 0, bDispLoad )
FMPN1, Dim1 = cl.LoadCollFbrcMnum( FinaColl, 1, bDispLoad )

## -----------------------------   Plot   -----------------------------
import matplotlib.pyplot as plt
if 1:
    plt.figure(1)

    plt.imshow(FBRC, aspect='auto')
    plt.title("Hyperkolumns")

    plt.draw()
    plt.pause(0.001)  # Brief pause to let the GUI window render

#DispTermNext( mfilename, 'cfHstEss.m');

