"""

see 2nd half of iclDscx.py, after loop

"""
