#
# Focus extraction for fabric description.
#
# Just a schematic so far. not operationable yet.
#
#
# PREVIOUS  iclDscx.py, iclDbin.py, iclFabric.py
# PRESENT   annFabric.py
# NEXT      category learning
#
import sys, subprocess
from pathlib import Path
from dataclasses import is_dataclass
import numpy as np

sys.path.insert(0, '../../../SEHBAU')
sys.path.insert(0, '../../../../py/UTIL') # for loading CIF images
import AdminPy as sb
import AdminPy.Collection as cl
import AdminPy.Orga as og
import AdminPy.Util as ut
dscx      = sb.DescExtr
hs        = sb.DescExtr.Hist
fbrc      = dscx.Fabric
fcs       = sb.FocSel                            # AdminPy.FocSel.FocAnf.py

# --------------------   Collection   --------------------
bas = 7 # OLTO
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

## ----------------   Admin & Options   --------------
bSaveDesc       = 0    # =0 means will write to '.\ztst'
bPlot           = 0

# -----------------   Paths   ---------------
Pths, Jcoll  = cl.u_CollPaths( bas )
Pths, Jcoll  = cl.u_CollPathAnn( Pths, Jcoll )

FixtImg     = sb.Orga.o_FileExtensions()
FixtFoc     = sb.Orga.o_FileExtensFoc()
FixtColl    = sb.Orga.o_FileExtensColl()
FinaColl    = sb.Orga.o_FileNameColl( Pths.hist, FixtColl )
Fips1       = sb.Orga.o_FileStems( Pths, '', 'cab_fbrc' )
#nImg        = Coll.nFinas;

fipaExe     = sb.FipaExe['fbrc2arr']
fpDSC       = sb.Orga.o_FinaApndExtDscx( "tmp", FixtImg )


IxCollReg   = [ 7, 10, 17, 50, 60, 61, 62 ]

## -----------------   Delete Previous Files   -----------------
IxCollDel = [7, 10, 17, 37, 50, *range(60, 63), 100, 200]

#if bas in IxCollDel:
#    if bSaveDesc > 0:
#        cl.u_DescDel( Pths.dsci )


# ------------------------------   LOOP IMAGES   ------------------------------
# Selection:
#IxImg   = 1:nImgTren;
#IxImg   = 1936:2000; # nImgTren;
Ix0Img   = Jcoll.Ix0Img;
nImg     = len(Ix0Img);
#nImg     = 0

FFLL      = fbrc.fbrcMTX()      # the full fabric, as loaded
FSEL      = fbrc.fbrcMTX()      # the focus selected fabric that will be saved

print(f"Running {bas}, nImg {nImg}", end="")
for i in range(0,nImg):

    ixi     = Ix0Img[i]

    pthFbrc = og.o_FileNameFrmt( Fips1.fbrc, ixi, '', Jcoll.finaFrmt )

    # --------------------   Init (on 1st image)   --------------------
    # scaling factors for focus selection
    if i==0:
        # obtain image size from fabric file
        fpFbrc    = pthFbrc + FixtImg.fbrc
        dmy, dmy, HedFbc    = sb.DescExtr.Hist.LoadFabric( fpFbrc )
        # the scaling factors
        PrmFocScl   = fcs.i_PrmFocSclToFbrc( HedFbc.Hed.szV, HedFbc.Hed.szH )


    # --------------------   fbrc2arr   --------------------
    cmnd = f"{fipaExe} {pthFbrc}{FixtImg.fbrc} .\\tmp"
    
    try:
        result = subprocess.run(cmnd, shell=True, capture_output=True, text=True, check=True)
        StdOut = result.stdout
    except subprocess.CalledProcessError as e:
        print(f"Command execution failed: {e.stderr}")
        StdOut = e.stderr

    # ----------   Load   ----------
    bFirst = i==0
    # loading from integer as float
    FFLL.HYK0, Nbin0 = cl.LoadCollHist( fpDSC.fbArK0, bFirst)
    FFLL.HYK1, Nbin1 = cl.LoadCollHist( fpDSC.fbArK1, bFirst)
    FFLL.HYK2, Nbin2 = cl.LoadCollHist( fpDSC.fbArK2, bFirst)
    FFLL.HYK3, Nbin3 = cl.LoadCollHist( fpDSC.fbArK3, bFirst)

    FFLL.Mps0, Hed0 = hs.LoadFabricMapAsArr( fpDSC.fbArM0 )
    FFLL.Mps1, Hed1 = hs.LoadFabricMapAsArr( fpDSC.fbArM1 )
    FFLL.Mps2, Hed2 = hs.LoadFabricMapAsArr( fpDSC.fbArM2 )
    FFLL.Mps3, Hed3 = hs.LoadFabricMapAsArr( fpDSC.fbArM3 )

    # -------------------------------------------------------------------
    #                   F O C U S   E X T R A C T I O N 
    # -------------------------------------------------------------------
    # two fake bounding boxes [nBox 4]
    BBoxs = np.array([ [5, 120, 80, 230],
                       [60, 90, 120, 150] ], dtype=np.int32)
    #top=5; bot=120; lef=80; rit=230
    ctg   = Jcoll.LabImg[i]
    
    for b in range(2):

        Box = BBoxs[b,:]        # extract one bounding box
        top = Box[0]
        bot = Box[1]
        lef = Box[2]
        rit = Box[3]

        # the linear indices
        IXlin    = dscx.f_FocRngsFbrc( top, bot, lef, rit, PrmFocScl )

        # extract focus from arrays
        FSEL     = fbrc.f_FocXtrFbrc( FFLL, IXlin )

        # --------------------   Save Focus  --------------------
        sfn      = fcs.f_FocFipaStem( Pths.DANNhst, ctg, b, FixtFoc.fbcf)

        fbrc.SaveFbrcMTX( FSEL, sfn )

        # --------------------   Verify   --------------------
        # verifies loading routine
        if 1:
            FSEL2    = fbrc.LoadFbrcMTX( sfn )
            Df       = FSEL.HYK0 - FSEL2.HYK0
            assert np.count_nonzero(Df)==0


    
    if i%Jcoll.stepDisp==0:
        sb.Util.printDotProg()


print("fertig")
cl.DispTermNext( 'annFabric.py', '' )

