"""

PREVIOUS iclDscx.py, iclCollVect.py

Testing ONE descriptor type with deep set using vector matrices.

"""
import sys
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt

import warnings
# Suppress the specific PyTorch nested tensor user warning
warnings.filterwarnings("ignore", message=".*enable_nested_tensor is True.*")

sys.path.insert(0, 'c:/klab/ppc/SEHBAU')
sys.path.insert(0, 'c:/klab/py/UTIL')
import AdminPy as sb
import AdminPy.Collection as cl
import AdminPy.Networks.DeepSet as DS

dimHid     =  512

nEpo       =   50
szBtc      =  8
lrPeak     = 0.0001
gnoisSdv   = 0.001
#pDrot      = 0.3
    
stepPlotLoss   = 20
lrMin          = lrPeak * 0.1

# ------------------------------   FileNames   ------------------------------
Pths, Jcoll = cl.u_CollPaths( 7 )
FinasFld    = cl.u_CollFoldFina( Pths.fold, 5, 1)
JFld        = cl.LoadFoldIx( FinasFld )

# ------------------------------   Load   ------------------------------
adj  = None
nSel = 0
#dtyL    = 'skl';   dtyA = 'Cnt'
#dtyL    = 'frm';   dtyA = 'Frm';   adj='ess';   nSel = 20
dtyL    = 'str';   dtyA = 'Str'
#dtyL     = 'arc';   dtyA = 'Arc'

COLC    = cl.LoadColcDty( Pths.coll, dtyL )

# ------------------------------   LEVEL SELECTION   ------------------------------
bSelLev = 0
if bSelLev:
    lvLow   = 0
    lvHih   = 1
    COLC.VEC, COLC.Lab    = cl.u_CollSelLev( COLC.VEC, COLC.Lab, lvLow,lvHih )
    COLC.Sts              = cl.sts_CollLab( COLC.Lab, 1 )
else:
    lvLow = 0
    lvHih = 5

nLevSel = lvHih-lvLow+1

# ------------------------------   REFINE VEC   ------------------------------
COLC.VEC, Jatt = cl.u_CollAdjAtt( COLC.VEC, dtyL, adj, nSel )

# ------------------------------   REARRANGE TO LIST   ------------------------------
AVECTRN, ALabTrn  = cl.u_CollMLtoLstSel( COLC.VEC, COLC.Lab, JFld.IxTrn )
AVECPRD, ALabPrd  = cl.u_CollMLtoLstSel( COLC.VEC, COLC.Lab, JFld.IxPrd )

# print(torch.cuda.is_available())
#DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#print(f"Using device: {DEVICE}")

# --------------------------------------------------------------------------------
#                               T R A I N 
# --------------------------------------------------------------------------------
# Initialize Loader
DSET    = DS.dsetVMX1( AVECTRN, JFld.LbTrn )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=True, collate_fn = DS.colt_VMX1 )

# ------------------------------   Model   ------------------------------
nAtt      = COLC.VEC.shape[1]
MOD       = DS.MOD_DSCOneClsf( nAtt, dimHid, Jcoll.nCat )
#MOD.to(DEVICE)

# ------------------------------   Guidance   ------------------------------
criterion = torch.nn.CrossEntropyLoss() # label_smoothing=0.05 )
optimizer = torch.optim.AdamW( MOD.parameters(), lr=lrPeak )
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR( optimizer, T_max=nEpo, eta_min=lrMin)

# ------------------------------   LOOP   ------------------------------
ax, line  = sb.Util.Plot.p_LossInit()

Loss      = np.zeros(nEpo)
MOD.train()
for e in range( nEpo ):

    lossVrun = 0.0
    cBtc = 0
    
    for step, (DSC, MASK, LbB) in enumerate(DLODer):

        optimizer.zero_grad()
    
        LOGT    = MOD( DSC, MASK ) 
        loss    = criterion( LOGT, LbB )

        loss.backward()

        # --- inject noise:
        for param in MOD.parameters():
            if param.grad is not None:
                NOIS = torch.randn_like(param.grad) * gnoisSdv
                param.grad.add_( NOIS )

        optimizer.step()

        lossVrun += loss.item()
        cBtc += 1
        
    Loss[e] = lossVrun / cBtc
    
    scheduler.step()
    
    # -----  Plot  -----
    mod     = np.mod(e, stepPlotLoss )
    if mod==0:
        sb.Util.Plot.p_LossUpdate( ax, Loss, line )
    

plt.ioff()   # turn off interactive mode

lrLast = scheduler.get_last_lr()[0]
print( f"lrLast {lrLast:.6f}" )


# --------------------------------------------------------------------------------
#                               P R E D I C T 
# --------------------------------------------------------------------------------
# Initialize Loader
DSET    = DS.dsetVMX1( AVECPRD, JFld.LbPrd )
DLODer  = DataLoader( DSET, batch_size=1, shuffle=False, collate_fn = DS.colt_VMX1 )

MOD.eval()
cHit = 0
with torch.no_grad():

    for DSC, MASK, LbB in DLODer:

        LOGT    = MOD( DSC, MASK ) 

        IxPredF = torch.argmax(LOGT, dim=1)
        nHit    = (IxPredF == LbB).sum().item()
        cHit   += nHit;

acc = cHit / len(JFld.LbPrd)

print( f"# acc {acc:.4f}  dimHid {dimHid}   nLevSel {nLevSel} (low {lvLow})   ", end="" )
print( f"  nEpo {nEpo}  szBtc {szBtc}  lrPeak {lrPeak:.6f}  nois {gnoisSdv:.5f}" )

# Contours:
# acc 0.3958  szEmb 14  nHed 1  nLay 1  nEpo 100  szBtc 8  lrPeak 0.000500  pDrot 0.3
