"""
Testing TWO descriptor types with deep set
"""
import sys
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

import warnings
# Suppress the specific PyTorch nested tensor user warning
warnings.filterwarnings("ignore", message=".*enable_nested_tensor is True.*")

sys.path.insert(0, 'c:/klab/ppc/SEHBAU')
sys.path.insert(0, 'c:/klab/py/UTIL')
import AdminPy as sb
import AdminPy.Collection as cl
import AdminPy.Networks.DeepSet as ds

dimHid     =  256

nEpo       =  100
szBtc      =  8
lrPeak     = 0.001
gnoisSdv   = 0.0001
#pDrot      = 0.3
    
stepPlotLoss   = 20
lrMin          = lrPeak * 0.1

# ------------------------------   FileNames   ------------------------------
Pths, Jcoll = cl.u_CollPaths( 7 )
FinasFld    = cl.u_CollFoldFina( Pths.fold, 5, 1)
JFld        = cl.LoadFoldIx( FinasFld )

# ------------------------------   Load   ------------------------------
CSKL        = cl.LoadColcDty( Pths.coll, 'skl' )
CFRM        = cl.LoadColcDty( Pths.coll, 'frm' )

# ------------------------------   LEVEL SELECTION   ------------------------------
bSelLev = 0
if bSelLev:
    lvLow   = 4
    lvHih   = 5
    CSKL.VEC, CSKL.Lab    = cl.u_CollSelLev( CSKL.VEC, CSKL.Lab, lvLow,lvHih )
    CSKL.Sts              = cl.sts_CollLab( CSKL.Lab, 1 )
    CFRM.VEC, CFRM.Lab    = cl.u_CollSelLev( CFRM.VEC, CFRM.Lab, lvLow,lvHih )
    CFRM.Sts              = cl.sts_CollLab( CFRM.Lab, 1 )
else:
    lvLow = 0
    lvHih = 5

nLevSel = lvHih-lvLow+1

# ------------------------------   REFINE VEC   ------------------------------
CSKL.VEC, JattCnt = cl.u_CollAdjAtt( CSKL.VEC, 'skl' )
CFRM.VEC, JattFrm = cl.u_CollAdjAtt( CFRM.VEC, 'frm' )

# ------------------------------   REARRANGE TO LIST   ------------------------------
ACNTTRN, ALabTrn  = cl.u_CollMLtoLstSel( CSKL.VEC, CSKL.Lab, JFld.IxTrn )
ACNTPRD, ALabPrd  = cl.u_CollMLtoLstSel( CSKL.VEC, CSKL.Lab, JFld.IxPrd )
AFRMTRN, ALabTrn  = cl.u_CollMLtoLstSel( CFRM.VEC, CFRM.Lab, JFld.IxTrn )
AFRMPRD, ALabPrd  = cl.u_CollMLtoLstSel( CFRM.VEC, CFRM.Lab, JFld.IxPrd )
    
# print(torch.cuda.is_available())
#DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#print(f"Using device: {DEVICE}")

# --------------------------------------------------------------------------------
#                               T R A I N 
# --------------------------------------------------------------------------------
# Initialize Loader
DSET    = ds.dsetVMX2( ACNTTRN, AFRMTRN, JFld.LbTrn )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=True, collate_fn = ds.colt_VMX2 )

# ------------------------------   Model   ------------------------------
nAttCnt   = CSKL.VEC.shape[1]
nAttFrm   = CFRM.VEC.shape[1]
MOD       = ds.MOD_DSCTwoClsf( nAttCnt, nAttFrm, dimHid, Jcoll.nCat )
#MOD.to(DEVICE)

# ------------------------------   Guidance   ------------------------------
criterion = torch.nn.CrossEntropyLoss() # label_smoothing=0.05 )
optimizer = torch.optim.AdamW( MOD.parameters(), lr=lrPeak )
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR( optimizer, T_max=nEpo, eta_min=lrMin)

# ------------------------------   LOOP   ------------------------------
ax, line  = sb.Util.Plot.p_LossInit()

Loss      = np.zeros(nEpo)
MOD.train()
for e in range( nEpo ):

    lossVrun = 0.0
    cBtc = 0
    
    for step, (CNTVEC, CNTMSK, FRMVEC, FRMMSK, LbB) in enumerate(DLODer):

        optimizer.zero_grad()
    
        LOGT    = MOD( CNTVEC, CNTMSK, FRMVEC, FRMMSK ) 
        loss    = criterion( LOGT, LbB )

        loss.backward()

        # --- inject noise:
        for param in MOD.parameters():
            if param.grad is not None:
                NOIS = torch.randn_like(param.grad) * gnoisSdv
                param.grad.add_( NOIS )

        optimizer.step()

        lossVrun += loss.item()
        cBtc += 1
        
    Loss[e] = lossVrun / cBtc
    
    scheduler.step()
    
    # -----  Plot  -----
    mod     = np.mod(e, stepPlotLoss )
    if mod==0:
        sb.Util.Plot.p_LossUpdate( ax, Loss, line )
    

plt.ioff()   # turn off interactive mode

lrLast = scheduler.get_last_lr()[0]
print( f"lrLast {lrLast:.6f}" )


# --------------------------------------------------------------------------------
#                               P R E D I C T 
# --------------------------------------------------------------------------------
# Initialize Loader
DSET    = ds.dsetVMX2( ACNTPRD, AFRMPRD, JFld.LbPrd )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=False, collate_fn = ds.colt_VMX2 )

MOD.eval()
cHit = 0
with torch.no_grad():

    for CNTVEC, CNTMSK, FRMVEC, FRMMSK, LbB in DLODer:

        LOGT    = MOD( CNTVEC, CNTMSK, FRMVEC, FRMMSK ) 

        IxPredF = torch.argmax(LOGT, dim=1)
        nHit    = (IxPredF == LbB).sum().item()
        cHit   += nHit;

acc = cHit / len(JFld.LbPrd)

print( f"# acc {acc:.4f}  dimHid {dimHid}   nLevSel {nLevSel} (low {lvLow})   ", end="" )
print( f"  nEpo {nEpo}  szBtc {szBtc}  lrPeak {lrPeak:.6f}  nois {gnoisSdv:.5f}" )

# Contours:
# acc 0.3958  szEmb 14  nHed 1  nLay 1  nEpo 100  szBtc 8  lrPeak 0.000500  pDrot 0.3
