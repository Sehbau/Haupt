"""
Testing transformer on vector matrices, for ONE descriptor type.
"""
import sys
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt

import warnings
# Suppress the specific PyTorch nested tensor user warning
warnings.filterwarnings("ignore", message=".*enable_nested_tensor is True.*")

sys.path.insert(0, 'Models')
#import TrfmDsc as TF
#import TrfmHistEmb as TfHst
#import Trfm2D as Tf2D

sys.path.insert(0, 'c:/klab/ppc/SEHBAU')
sys.path.insert(0, 'c:/klab/py/UTIL')
import AdminPy as sb
from AdminPy import Collection as cl
from AdminPy.Networks.Transf import TrfmDscs as tf
from AdminPy.Networks.Transf import TrfmDscsMHA as tfmha

szEmbFct   = 8
nLay       = 2
dimFF      = 4
nHed       = 2

nEpo       =  100
szBtc      =  8
lrPeak     = 0.0005
gnoisSdv   = 0.001
pDrot=0.3 # NO USED
    
stepPlotLoss   = 20
lrMin          = lrPeak * 0.1

# ------------------------------   FileNames   ------------------------------
Pths, Jcoll = cl.u_CollPaths( 7 )
FinasFld    = cl.u_CollFoldFina( Pths.fold, 5, 1)
JFld        = cl.LoadFoldIx( FinasFld )

# ------------------------------   Load   ------------------------------
#dtyL    = 'skl';   dtyA = 'Cnt'
dtyL    = 'frm';   dtyA = 'Frm';  adj='red';  nSel=17
#dtyL    = 'frm';   dtyA = 'Frm'
#dtyL    = 'str';   dtyA = 'Str'
#dtyL     = 'arc';   dtyA = 'Arc'

COLC    = cl.LoadCollDty( Pths.coll, dtyL )

# ------------------------------   LEVEL SELECTION   ------------------------------
bSelLev = 0
if bSelLev:
    lvLow   = 0
    lvHih   = 1
    COLC.VEC, COLC.Lab    = cl.u_CollSelLev( COLC.VEC, COLC.Lab, lvLow,lvHih )
    COLC.Sts              = cl.sts_CollLab( COLC.Lab, 1 )
else:
    lvLow = 0
    lvHih = 5

nLevSel = lvHih-lvLow+1

# ------------------------------   ADJUST VEC   ------------------------------
COLC.VEC, COLC.POS, Jatt = cl.u_CollAdjAttPos( COLC.VEC, dtyL, adj, nSel )

# ------------------------------   REARRANGE TO LIST   ------------------------------
u_CollVecSel      = cl.u_CollMLtoLstSel
AVECTRN, ALabTrn  = u_CollVecSel( COLC.VEC, COLC.Lab, JFld.IxTrn )
AVECPRD, ALabPrd  = u_CollVecSel( COLC.VEC, COLC.Lab, JFld.IxPrd )
APOSTRN, dmy      = u_CollVecSel( COLC.POS, COLC.Lab, JFld.IxTrn )
APOSPRD, dmy      = u_CollVecSel( COLC.POS, COLC.Lab, JFld.IxPrd )

# --------------------------------------------------------------------------------
#                               M O D E L 
# --------------------------------------------------------------------------------
nAtt      = COLC.VEC.shape[1]
szEmb     = nAtt*szEmbFct
#MOD       = tf.MOD_DSCclsf( nAtt, szEmb, nLay, dimFF, Jcoll.nCat )
MOD       = tfmha.MOD_DSCclsfMHA( nAtt, szEmb, nHed, nLay, dimFF, Jcoll.nCat )
f_Dset    = tf.dsetVMXCOO
f_Colt    = tf.colt_VMXCOO


# --------------------------------------------------------------------------------
#                               T R A I N 
# --------------------------------------------------------------------------------
DSET    = f_Dset( AVECTRN, APOSTRN, JFld.LbTrn )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=True, collate_fn = f_Colt )


# ------------------------------   Guidance   ------------------------------
criterion = torch.nn.CrossEntropyLoss() # label_smoothing=0.05 )
optimizer = torch.optim.AdamW( MOD.parameters(), lr=lrPeak )
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR( optimizer, T_max=nEpo, eta_min=lrMin)

# ------------------------------   LOOP   ------------------------------
ax, line  = sb.Util.Plot.p_LossInit()

Loss      = np.zeros(nEpo)
MOD.train()
for e in range( nEpo ):

    lossVrun = 0.0
    cBtc = 0
    
    for step, (DSC, COO, MASK, LbB) in enumerate(DLODer):

        optimizer.zero_grad()
    
        LOGT    = MOD( DSC, COO, MASK ) 
        loss    = criterion( LOGT, LbB )

        loss.backward()

        # --- inject noise:
        for param in MOD.parameters():
            if param.grad is not None:
                NOIS = torch.randn_like(param.grad) * gnoisSdv
                param.grad.add_( NOIS )

        optimizer.step()

        lossVrun += loss.item()
        cBtc += 1
        
    Loss[e] = lossVrun / cBtc
    
    scheduler.step()
    
    # -----  Plot  -----
    mod     = np.mod(e, stepPlotLoss )
    if mod==0:
        sb.Util.Plot.p_LossUpdate( ax, Loss, line )
    

plt.ioff()   # turn off interactive mode

lrLast = scheduler.get_last_lr()[0]
print( f"lrLast {lrLast:.6f}" )

# --------------------------------------------------------------------------------
#                               P R E D I C T 
# --------------------------------------------------------------------------------
DSET    = f_Dset( AVECPRD, APOSPRD, JFld.LbPrd )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=False, collate_fn = f_Colt )

MOD.eval()
cHit = 0
with torch.no_grad():

    for DSC, COO, MASK, LbB in DLODer:

        LOGT    = MOD( DSC, COO, MASK ) 

        IxPredF = torch.argmax(LOGT, dim=1)
        nHit    = (IxPredF == LbB).sum().item()
        cHit   += nHit;

acc = cHit / len(JFld.LbPrd)

print( f"# acc {acc:.4f}  szEmb {szEmb}  nHed {nHed}  nLay {nLay}  dimFF {dimFF}", end="" )
print( f"  nEpo {nEpo}  szBtc {szBtc}  lrPeak {lrPeak:.6f}  pDrot {pDrot:.1f}" )

# Contours:

