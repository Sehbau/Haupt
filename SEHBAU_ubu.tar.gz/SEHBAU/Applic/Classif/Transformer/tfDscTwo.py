"""
Testing transformer on vector matrices, for TWO descriptor types.
"""
import sys
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt

import warnings
# Suppress the specific PyTorch nested tensor user warning
warnings.filterwarnings("ignore", message=".*enable_nested_tensor is True.*")

sys.path.insert(0, 'Models')
#import TrfmDsc as TF
#import TrfmHistEmb as TfHst
#import Trfm2D as Tf2D

sys.path.insert(0, 'c:/klab/ppc/SEHBAU')
sys.path.insert(0, 'c:/klab/py/UTIL')
import AdminPy as sb
from AdminPy import Collection as cl
from AdminPy.Networks.Transf import TrfmDscsTwo as tf
#from AdminPy.Networks.Transf import TrfmDscsMHA as tfmha

szEmbFct   = 8
nLay       = 2
dimFF      = 4
nHed       = 2

nEpo       =  100
szBtc      =  8
lrPeak     = 0.0005
gnoisSdv   = 0.001
pDrot=0.3 # NO USED
    
stepPlotLoss   = 20
lrMin          = lrPeak * 0.1

# ------------------------------   FileNames   ------------------------------
Pths, Jcoll = cl.u_CollPaths( 7 )
FinasFld    = cl.u_CollFoldFina( Pths.fold, 5, 1)
JFld        = cl.LoadFoldIx( FinasFld )

# ------------------------------   Load   ------------------------------
CSKL        = cl.LoadCollDty( Pths.coll, 'skl' )
CFRM        = cl.LoadCollDty( Pths.coll, 'frm' )

# ------------------------------   LEVEL SELECTION   ------------------------------
bSelLev = 0
if bSelLev:
    lvLow   = 4
    lvHih   = 5
    CSKL.VEC, CSKL.Lab    = cl.u_CollSelLev( CSKL.VEC, CSKL.Lab, lvLow,lvHih )
    CSKL.Sts              = cl.sts_CollLab( CSKL.Lab, 1 )
    CFRM.VEC, CFRM.Lab    = cl.u_CollSelLev( CFRM.VEC, CFRM.Lab, lvLow,lvHih )
    CFRM.Sts              = cl.sts_CollLab( CFRM.Lab, 1 )
else:
    lvLow = 0
    lvHih = 5

nLevSel = lvHih-lvLow+1

# ------------------------------   REFINE VEC   ------------------------------
adj='red';  nSel=17
CSKL.VEC, CSKL.POS, JattCnt   = cl.u_CollAdjAttPos( CSKL.VEC, 'skl' )
CFRM.VEC, CFRM.POS, JattFrm   = cl.u_CollAdjAttPos( CFRM.VEC, 'frm', adj, nSel )

# ------------------------------   REARRANGE TO LIST   ------------------------------
u_CollVecSel         = cl.u_CollMLtoLstSel

ACNT                 = cl.f_COLFtoLSTpos( CSKL, JFld.IxTrn, JFld.IxPrd )
AFRM                 = cl.f_COLFtoLSTpos( CFRM, JFld.IxTrn, JFld.IxPrd )
# explicit:
#ACNTVECTRN, ALabTrn  = u_CollVecSel( CSKL.VEC, CSKL.Lab, JFld.IxTrn )
#ACNTVECPRD, ALabPrd  = u_CollVecSel( CSKL.VEC, CSKL.Lab, JFld.IxPrd )
#ACNTPOSTRN, dmy      = u_CollVecSel( CSKL.POS, CSKL.Lab, JFld.IxTrn )
#ACNTPOSPRD, dmy      = u_CollVecSel( CSKL.POS, CSKL.Lab, JFld.IxPrd )

#AFRMVECTRN, ALabTrn  = u_CollVecSel( CFRM.VEC, CFRM.Lab, JFld.IxTrn )
#AFRMVECPRD, ALabPrd  = u_CollVecSel( CFRM.VEC, CFRM.Lab, JFld.IxPrd )
#AFRMPOSTRN, dmy      = u_CollVecSel( CFRM.POS, CFRM.Lab, JFld.IxTrn )
#AFRMPOSPRD, dmy      = u_CollVecSel( CFRM.POS, CFRM.Lab, JFld.IxPrd )

# --------------------------------------------------------------------------------
#                               M O D E L 
# --------------------------------------------------------------------------------
nAttSkl   = CSKL.VEC.shape[1]
nAttFrm   = CFRM.VEC.shape[1]
szEmb     = nAttSkl*szEmbFct

MOD       = tf.MOD_DSCclsf( nAttSkl, nAttFrm, szEmb, nLay, dimFF, Jcoll.nCat )

f_Dset    = tf.dsetVMXCOO2
f_Colt    = tf.colt_VMXCOO2


# --------------------------------------------------------------------------------
#                               T R A I N 
# --------------------------------------------------------------------------------
DSET    = f_Dset( ACNT.VECTRN, ACNT.POSTRN, AFRM.VECTRN, AFRM.POSTRN, JFld.LbTrn )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=True, collate_fn = f_Colt )


# ------------------------------   Guidance   ------------------------------
criterion = torch.nn.CrossEntropyLoss() # label_smoothing=0.05 )
optimizer = torch.optim.AdamW( MOD.parameters(), lr=lrPeak )
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR( optimizer, T_max=nEpo, eta_min=lrMin)

# ------------------------------   LOOP   ------------------------------
ax, line  = sb.Util.Plot.p_LossInit()

Loss      = np.zeros(nEpo)
MOD.train()
for e in range( nEpo ):

    lossVrun = 0.0
    cBtc = 0
    
    for step, (CNTVEC, CNTPOS, CNTMSK, FRMVEC, FRMPOS, FRMMSK, LbB) in enumerate(DLODer):

        optimizer.zero_grad()
    
        LOGT    = MOD( CNTVEC, CNTPOS, CNTMSK, FRMVEC, FRMPOS, FRMMSK ) 
        loss    = criterion( LOGT, LbB )

        loss.backward()

        # --- inject noise:
        for param in MOD.parameters():
            if param.grad is not None:
                NOIS = torch.randn_like(param.grad) * gnoisSdv
                param.grad.add_( NOIS )

        optimizer.step()

        lossVrun += loss.item()
        cBtc += 1
        
    Loss[e] = lossVrun / cBtc
    
    scheduler.step()
    
    # -----  Plot  -----
    mod     = np.mod(e, stepPlotLoss )
    if mod==0:
        sb.Util.Plot.p_LossUpdate( ax, Loss, line )
    

plt.ioff()   # turn off interactive mode

lrLast = scheduler.get_last_lr()[0]
print( f"lrLast {lrLast:.6f}" )

# --------------------------------------------------------------------------------
#                               P R E D I C T 
# --------------------------------------------------------------------------------
DSET    = f_Dset( ACNT.VECPRD, ACNT.POSPRD, AFRM.VECPRD, AFRM.POSPRD, JFld.LbPrd )
DLODer  = DataLoader( DSET, batch_size=szBtc, shuffle=False, collate_fn = f_Colt )

MOD.eval()
cHit = 0
with torch.no_grad():

    for CNTVEC, CNTPOS, CNTMSK, FRMVEC, FRMPOS, FRMMSK, LbB in DLODer:

        LOGT    = MOD( CNTVEC, CNTPOS, CNTMSK, FRMVEC, FRMPOS, FRMMSK ) 

        IxPredF = torch.argmax(LOGT, dim=1)
        nHit    = (IxPredF == LbB).sum().item()
        cHit   += nHit;

acc = cHit / len(JFld.LbPrd)

print( f"# acc {acc:.4f}  szEmb {szEmb}  nHed {nHed}  nLay {nLay}  dimFF {dimFF}", end="" )
print( f"  nEpo {nEpo}  szBtc {szBtc}  lrPeak {lrPeak:.6f}  pDrot {pDrot:.1f}" )

# Contours:

