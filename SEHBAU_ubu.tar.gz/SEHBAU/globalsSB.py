"""

 Adds all necessary paths and creates some global variables.

"""
import sys, os
from dataclasses import dataclass

# ------------------------------   VARIABLES   ------------------------------
import platform

bOSisWin = platform.system()=='Windows' # used for 



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   u_AddGenPath   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Emulates the following two commands of Matlab: 'addpath( genpath( pth ) )': it adds
all subfolders to path.

USE   u_AddGenPath( 'UtilPy/' )
      u_AddGenPath( 'DescExtr/UtilPy/' )

"""
def u_AddGenPath( pth ):

   for root, dirs, files in os.walk( pth ):
      if root not in sys.path:
         sys.path.append(root)


# ------------------------------   Root Path   ------------------------------
#rootSehBau      = '' # 'c:/klab/ppc/SEHBAU/'
#sys.path.append(rootSehBau)


# ------------------------------   Dirs    ------------------------------
"""
@dataclass
class dirProg:
   descExtr = 'DescExtr/'
   mtchVec  = 'MtchVec/'
   focExtr  = 'FocExtr/'
   plcRec   = 'DemoPlcRec/'
   
DirProg = dirProg


# ------------------------------   Paths   ------------------------------
PthProg = dirProg

for a in dir( PthProg ):
    if not a.startswith('__'):
        #print(a)
        drp = getattr( DirProg, a)
        setattr( PthProg, a, rootSehBau + drp )
"""


         
"""
deprecated
# UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_AddPath   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
#
#    Analogous to addpath/genpath in Matlab. not exactly. only for a list I think
#
def u_AddPathList( dirPrinc, Subs=[] ):

    # add principal folder
    pthPrinc  = rootSehBau + dirPrinc + '/'
    sys.path.append( pthPrinc ) 

    # add sub-folders
    nSubs   = len(Subs)
    if nSubs==0: print('no subs for ', dirPrinc); return
    for i in range(nSubs):
        sys.path.append( pthPrinc + Subs[i] )

    return
"""


# ------------------------------   PATHS   ------------------------------


# deprecated
#u_AddPath( 'UtilPy',   [ 'OrgFile',  'Params' ] )
#u_AddPath( 'DescExtr/UtilPy', [ 'Vect' ] )
#u_AddPath( 'DescExtr/UtilPy/Vect' , [ 'FileRead', 'OrgAtt' ])







