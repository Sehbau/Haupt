%
% Example for extracting patches from one image
%
clear;
run('../AdminMb/globalsSB.m');

% copy an image from folder DescExtr and place it to folder Imgs for
% convenience:
copyfile( '../DescExtr/Imgs/img2.jpg', 'Imgs/img2.jpg' );

%% ---------   create command   ----------
progName    = FipaExe.ptchxL;
fipaImg     = 'Imgs/img2.jpg';

% file with bounding boxes. First entry (line) equals number of bboxes
% followed by linewise specifying top/bottom/left/right
fipaBbx     = 'PtchBbx.txt';    

dirOut      = 'Ptch/';
fistOut     = 'P';                      % creates P0, P1, etc.
mrgStr      = 0.1;                      % margin to be added

fipsOut     = [dirOut fistOut];

cmnd        = [progName ' ' fipaImg ' ' fipaBbx ' ' fipsOut ' ' num2str(mrgStr)];

if ispc
    cmnd  = u_PathToBackSlash( cmnd );
end

%% ---------   execute command   ----------
[sts, Out] = system( cmnd );

v_CmndExec( sts, Out, cmnd, 1 );






