%
% Example for shape extraction
%
% NEXT  exsbMshp1.m
%
clear;

% bright target value [200 200 200] to find letter shape
[st1, Out1] = dos('shpx Imgs/Ptch_48.png 200 200 200 Desc/p48');
[st2, Out2] = dos('shpx Imgs/Ptch_49.png 200 200 200 Desc/p49');
[st3, Out3] = dos('shpx Imgs/Ptch_49.png 200 200 200 Desc/p49 Params/PrmShpx_Example.txt');

[st4, Out4] = dos('shpx Imgs/ptch.png 200 200 200 Desc/p Params/PrmShpx_Example.txt --prms');
[st5, Out5] = dos('shpx Imgs/ptch.png 200 200 200 Desc/p Params/PrmShpx_Example.txt --prmchg');

% does not work because it requires an output file name
% dos('shpx Imgs/Ptch_49.png 200 200 200 --prms');
% dos('shpx Imgs/Ptch_49.png 200 200 200 --init 1'); not working

assert( st1==0 );
assert( st2==0 );
assert( st3==0 );
assert( st4==0 );

Out1
Out2
Out3
Out4
Out5










