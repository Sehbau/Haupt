% 
% Runs program mvec1, for two frames. Plots correspondence.
%
% For multiple files see exsbMvecLimg.m
%
clear;
run('../AdminMb/globalsSB');        % assumes script is run from dir 'MtchVec'
[LbAtts, LbAttSG]   = o_AttsLabels();

%% --------------------------------------------------------------
%                          DESC EXTR
%  --------------------------------------------------------------
% run descriptor extraction for two frames
fprintf('Descriptor extraction...');
fipaFrm1 	= 'Imgs/Frm1.png';
fipaFrm2 	= 'Imgs/Frm2.png';

fipsDsc1 	= 'Desc/Frm1';
fipsDsc2   	= 'Desc/Frm2';

if ispc
    fipsDsc1    = u_PathToBackSlash( fipsDsc1 );
    fipsDsc2    = u_PathToBackSlash( fipsDsc2 );
end

ArgsDscx        = o_CmndArgs( 'dscx' );
ArgsDscx.opt    = '--saveBsp';
v_CmndArgs( ArgsDscx );

OutDscx1    = RennDscx( fipaFrm1, fipsDsc1, ArgsDscx, PthProg.descExtr );
OutDscx2    = RennDscx( fipaFrm2, fipsDsc2, ArgsDscx, PthProg.descExtr );

fprintf('fertig\n');

%% --------------------------------------------------------------
%                          MATCH
%  --------------------------------------------------------------
fprintf('Matching...');

%% --------   Options   --------
OptK            = o_MvecArgs();
OptK.tolMtc     = 0.1;
OptK.wgtPos     = 0.5;
OptK.wgtRGB     = 0.8;
OptK.cntTolMtc  = 0.05;
OptK.rsgTolMtc  = 0.06;
OptK.arcTolMtc  = 0.07;
OptK.strTolMtc  = 0.08;
optS            = i_MvecArgs(OptK);

ArgsMvec        = o_CmndArgs( 'mvec' );
% user modification
if 0
    ArgsMvec.fpPrm  = 'Params/PrmMtch_RgbOff.txt';
else
    ArgsMvec.opt    = optS;
end
v_CmndArgs( ArgsMvec, '' );

OutMtc  = RennMvec1( [fipsDsc1 '.dsc'], [fipsDsc2 '.dsc'], ...
                    ArgsMvec, PthProg.mtchVec );
fprintf('fertig\n');

%OutMtcOwn  = RennMvec1( [fipsDsc1 '.dsc'], [fipsDsc1 '.dsc'], ...
%                        ArgsMvec, PthProg.mtchVec );

%% -------   Read Out StdOut   -------
[Sto Hed]         = pso_Mvec1Sections( OutMtc );
[AMesDty mesTot]  = pso_Mvec1Vals( Sto );

%% -------   Plot Metric Measurements   --------
figure(1); clf;
bImg        = 1;
%p_MvvDtyVx(MesI, Ndsc1I, bImg);
p_MvvDty( AMesDty );


%% --------------------------------------------------------------
%                       CORRESPONDENCE
%  --------------------------------------------------------------
fprintf('Correspondence...\n');

%% ------------   Load NNs   ----------------
finaNNcnt = 'Mes/NNspcCnt12';
[ANNCnt Ncnt nLev] = LoadNNDspace( finaNNcnt ); 
[ANNRsg Nrsg nLev] = LoadNNDspace( 'Mes/NNspcRsg12' );
[ANNArc Narc nLev] = LoadNNDspace( 'Mes/NNspcArcGst12' );
[ANNStr Nstr nLev] = LoadNNDspace( 'Mes/NNspcStrGst12' );
[ANNShp Nshp nLev] = LoadNNDspace( 'Mes/NNspcShp12' );

DispLoad( finaNNcnt );

%% ------------    Load DESCS   -------------
DUV1 = LoadDescUniv( [fipsDsc1 '.dsc'] );
DUV2 = LoadDescUniv( [fipsDsc2 '.dsc'] );

%% ------------    Load BonPix   -------------
[ABON1 Jbsp1]   = LoadBonPixSpc( [fipsDsc1 '.bspx']);
[ABON2 Jbsp2]   = LoadBonPixSpc( [fipsDsc2 '.bspx']);

%% ------   Display the 2 Frames    -------
% for illustration
figure(3); clf; 
p_SUBtig(1,2,1); imagesc( imread( fipaFrm1 ) );
p_SUBtig(1,2,2); imagesc( imread( fipaFrm2 ) );


%% ----------------   Contours (Skelet)   --------------
% All in unit coordinates.
% We invert y-axis: once for plotting descriptors and once for
% correspondence using utility routine u_PosVHinvertToIJ.
figure(5); clf; [nr nc]=deal(nLev,1);

for lv = 1:nLev

    p_SUBtig( nr,nc,lv, 'margin', 0.01); hold on;

    p_DescCorrespPair( 'cnt', DUV1.ACNT{lv}, DUV2.ACNT{lv} );

    PosA       = DUV1.ACNT{lv}.Pos;
    PosB       = DUV2.ACNT{lv}.Pos;

    PosA       = u_PosVHinvertToIJ( PosA );
    PosB       = u_PosVHinvertToIJ( PosB );
    PosB.Hor   = PosB.Hor + 1; % shift to right side

    p_DescCorrespLine( PosA, PosB, ANNCnt{lv} );

end
axis ij;

%% ----------------   Form   --------------
% In pixel coordinates; no inversion of y-axis. 
% We indicate correspondence with position info. Could also be done with
% descriptor points.
nLev = 3;
SzM  = Jbsp1.SzM;
figure(6); clf; [nr nc]=deal(nLev,1);
fprintf('Form...\n');
for lv = 1:nLev

    p_SUBtig( nr,nc,lv, 'margin', 0.01); hold on;

    DA      = DUV1.AFRM{lv};
    DB      = DUV2.AFRM{lv};
    
    DA.RdSig   = u_MtrxToStcArr( DA.RdSig, LbAttSG.Frm.RdSig );
    DB.RdSig   = u_MtrxToStcArr( DB.RdSig, LbAttSG.Frm.RdSig );

    [aBon2] = p_DescCorrespPair( 'form', DA, DB, ...
                    SzM(lv,:), ABON1{lv}, ABON2{lv} );
    
    PosA    = DA.Pos;
    PosB    = DB.Pos;
    
    PosA    = u_PosVHscaleup( PosA, SzM(lv,:), 0 );
    PosB    = u_PosVHscaleup( PosB, SzM(lv,:), 0 );

    PosB    = u_PosVHshift( PosB, 0, SzM(lv,2) );
    
    p_DescCorrespLine( PosA, PosB, ANNRsg{lv} );
    
end
axis ij;
fprintf('done\n');

%% ----------------   Arcs   --------------
% In pixel coordinates; no inversion of y-axis. 
% We indicate correspondence with position info. Could also be done with
% descriptor points.
nLev = 2;
figure(7); clf; [nr nc]=deal(nLev,1);

for lv = 1:nLev

    p_SUBtig( nr,nc,lv, 'margin', 0.01); hold on;

    DA      = DUV1.AARC{lv};
    DB      = DUV2.AARC{lv};
    
    p_DescCorrespPair( 'arc', DA, DB, SzM(lv,:) );
    
    PosA    = DA.Pos;
    PosB    = DB.Pos;
    
    PosA    = u_PosVHscaleup( PosA, SzM(lv,:), 0 );
    PosB    = u_PosVHscaleup( PosB, SzM(lv,:), 0 );

    PosB    = u_PosVHshift( PosB, 0, SzM(lv,2) );
    
    p_DescCorrespLine( PosA, PosB, ANNArc{lv} );
    
end
axis ij;

%% ----------------   Strs   --------------
% same as arcs above.
nLev = 2;
figure(8); clf; [nr nc]=deal(nLev,1);

for lv = 1:nLev

    p_SUBtig( nr,nc,lv, 'margin', 0.01); hold on;

    DA      = DUV1.ASTR{lv};
    DB      = DUV2.ASTR{lv};
    
    p_DescCorrespPair( 'str', DA, DB, SzM(lv,:) );
    
    PosA    = DA.Pos;
    PosB    = DB.Pos;
    
    PosA    = u_PosVHscaleup( PosA, SzM(lv,:), 0 );
    PosB    = u_PosVHscaleup( PosB, SzM(lv,:), 0 );

    PosB    = u_PosVHshift( PosB, 0, SzM(lv,2) );
    
    p_DescCorrespLine( PosA, PosB, ANNStr{lv} );
    
end
axis ij;

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2Jpeg( [dirFigs 'FrmsXspndSkl'], 5 );
    PrintFig2Jpeg( [dirFigs 'FrmsXspndRsg'], 6 );
end
