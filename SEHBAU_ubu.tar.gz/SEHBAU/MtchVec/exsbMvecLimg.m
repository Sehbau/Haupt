% 
% Runs program mvecL (1-versus-List) for image output (dsc files)
%
% Assumes that at least 2 frames were processed already, ie. with demo
% script plcDscx.m
%
clear;
run('../globalsSB');
cd( PthProg.mtchVec );

fipaImgTst  = 'Desc/Frm1.dsc';      % testing image 
aImgNaRep   = dir('Desc/Frm*.dsc'); % representation/reference image
fpRegist    = 'Regist/FrameVec.txt';
SaveFipaLstPrependPath( aImgNaRep, 'Desc/', fpRegist );
finaMes     = 'Mes/ImgExamp.txt';

%% --------   Options   --------
OptK            = u_OptMvecStc();
OptK.tolMtc     = 0.1;
OptK.wgtPos     = 0.5;
OptK.wgtRGB     = 0.8;
OptK.cntTolMtc  = 0.05;
OptK.rsgTolMtc  = 0.06;
OptK.arcTolMtc  = 0.07;
OptK.strTolMtc  = 0.08;
optS            = i_OptMvec(OptK);

%% =========   Command   ========
finaProg     = 'mvecL';
cmndImg      = [finaProg ' ' fipaImgTst ' ' fpRegist ' ' finaMes ' ' optS];

[Sts OutImg] = dos(cmndImg);

%% -------   Load Matching Results   -------
MesImg       = LoadMtchMes( finaMes, length(aImgNaRep) );
DisDTY       = LoadMtchMESdty( 'Mes/MesDtyDis.txt' );
SimDTY       = LoadMtchMESdty( 'Mes/MesDtySim.txt' );

%% -------   Plot Metric Measurements   --------
figure(1); clf;
[nr nc] = deal(2,1);
subplot(nr,nc,1); bar( MesImg(:,1) ); title('Distances');
subplot(nr,nc,2); bar( MesImg(:,2) ); title('Similarities');




