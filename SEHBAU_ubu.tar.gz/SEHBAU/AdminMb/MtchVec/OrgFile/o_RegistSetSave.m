%
% Generates the registers for a set of representation formats, namely
% kolumn, histogram and vector (descfile).
%
% cf lvngRunMcsc.m
% sa o_RegistAnf.h
%
% IN  pthRgst   path where registers will be saved to
%     pthDsc    path of descriptor files
%     fist      filestem or path+filestem
%     IxImg     image indices
%     Fixt      extensions
%     nameFrmt  name format: none, or with leading zeros
%     
% OUT R         register info
%
function [R] = o_RegistSetSave( pthRgst, pthDsc, fist, IxImg, Fixt, ...
                                nameFrmt )

if nargin==5
    nameFrmt = 0;
end

R.fpaDsc 	= [ pthRgst 'RefDsc.txt' ];
R.fpaHst 	= [ pthRgst 'RefHst.txt' ];
R.fpaKol 	= [ pthRgst 'RefKol.txt' ];

% vect:
aVec     	= o_RegistGen( fist, IxImg, Fixt.dsc, nameFrmt );
SaveFipaLstPrependPath( aVec, pthDsc, R.fpaDsc );

% hist:
aHst      	= o_RegistGen( fist, IxImg, Fixt.hsti, nameFrmt );
SaveFipaLstPrependPath( aHst, pthDsc, R.fpaHst );

% kolm:
aKol      	= o_RegistGen( fist, IxImg, Fixt.kolm, nameFrmt );
SaveFipaLstPrependPath( aKol, pthDsc, R.fpaKol );

% -----  A2S  -----
R.aVec      = aVec;
R.pth       = pthDsc;

end

