% 
% Metric from measurement matrix, distance or similarity, for example as
% calculated in MFOCTOFOC.m
%
% Sorts along both dimensions and takes multiplicative and average
% measure.
%
% IN  MM        matrix of arbitrary size
%     sortTyp   ascend (distance) or descend (similarity)
%
% ui MFOCTOFOC.m, lvngRunMovo.m, 
%
function [mes O] = f_MtrFromMM( MM, sortTyp, valNoMatch )

bAscend     = strcmp( sortTyp, 'ascend' );
bDescend    = strcmp( sortTyp, 'descend');
if  bAscend || bDescend
    if nargin==2
        if bAscend
            valNoMatch = 100;
        else
            valNoMatch = 0;
        end
    end
else
    error('sortTyp %s not possible: must be ascend | descend', sortTyp );
end

%% -----------   Sort   ----------
ORD12       = sort( MM, 2, sortTyp ); 	% across the rows
ORD21       = sort( MM, 1, sortTyp );  	% down the columns

% nearest neighbors:
NN12        = ORD12(:,1);           % 1st column
NN21        = ORD21(1,:);           % 1st row

%% -----------   Descend with NaN   -------------

% for descending type including NaNs we sort differently, because NaNs
% appear first in descending sorting (why?). We therefore replace NaNs by
% -99, then sort, and then replace NaNs in Nearest-Neibors by NaN again.

if bDescend  &&  any( isnan( MM(:) ) )
    
    MM( isnan(MM) ) = -99;
    
    ORD12   = sort( MM, 2, sortTyp ); 	% along rows
    ORD21   = sort( MM, 1, sortTyp );  	% along columns
    
    NN12    = ORD12(:,1);           % 1st column
    NN21    = ORD21(1,:);           % 1st row
    
    B99     = NN12==-99;    NN12(B99) = NaN;
    B99     = NN21==-99;    NN21(B99) = NaN;
    
end

%% ---------   Combine   ---------
menNN12     = nanmean( NN12 );      % 1st column
menNN21     = nanmean( NN21 );      % 1st row

mes.mul     =   menNN12 * menNN21;
mes.men     =  (menNN12 + menNN21) / 2;

% if result is NaN, then replace by no-match value
if isnan( mes.mul ) 
    mes.mul = valNoMatch;
end
if isnan( mes.men ) 
    mes.men = valNoMatch;
end

%% ---------   Explicit Case   -----------
% for descending type with NaN
if 0 % bDescend && any( isnan( MM(:) ) )
    
    [nRow nCol] = size(MM);
    
    NNrow = nan(nRow,1,'single');
    for r = 1:nRow
        
        Ord12 = ORD12(r,:);
        
        Bnot  = not( isnan( Ord12 ) );
        
        if any(Bnot)
            ix1st       = find(Bnot,1,'first');
            NNrow(r)    = Ord12(ix1st);
        end
        
    end
    
    NNcol = nan(nCol,1,'single');
    for c = 1:nCol
        
        Ord21 = ORD21(:,c);
        
        Bnot  = not( isnan( Ord21 ) );
        
        if any(Bnot)
            ix1st       = find(Bnot,1,'first');
            NNcol(c)    = Ord21(ix1st);
        end
        
    end
    
    mes.mul =   nanmean( NNrow ) * nanmean( NNcol );
    mes.men = ( nanmean( NNcol ) + nanmean( NNcol ) ) / 2;   
    
end

% for plotting:
O.O12  = ORD12;
O.O21  = ORD21;

end

