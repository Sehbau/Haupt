%
% Focus-to-focus (1-on-1) matching using wrapper RennMvec1.
%
% Two steps:
%   1) determines spatial relation
%   2) matches vectors
%
% RETURNS OutFoc only if step no. 2) has occured.
% 
% cf MFOCTOFOC.m
%
function [M] = f_FocToFoc( LocQ,  LocR, ...
                           fipaQ, fipaR, ...
                           Prm, Admin, bDISP )
                                      
M.OutFoc = 'not run yet';

%% ---------------   Spatial Relation   -------------                                      
% Consists of the combination of a congruence measure and a spacing
% measure.
%
Gbx     = f_BoxCong( LocQ.hgtN, LocQ.wthN, LocR.hgtN, LocR.wthN );

% --- Tolerance
%Tol(1)  = 0.3;          % fixed
%Tol(2)  = 0.3;
% make tolerance based on mean box size (obtained in f_BoxCong)
%Tol(1)  = Gbx.hgtMen * 2;
%Tol(2)  = Gbx.wthMen * 2;

spcng   = f_SpcngTol( LocQ.posV, LocQ.posH, ...
                      LocR.posV, LocR.posH, Prm.TolSpcng );

%spcng                  
                  
if spcng   > 1,           spcng   = 1; end    % will set sim to zero
if Gbx.gnc < Prm.minCong, Gbx.gnc = 0; end

%Gbx.gnc

M.mtcBox  = Gbx.gnc * ( 1 - spcng );    % *** combine ***

bMtcBox   = M.mtcBox > Prm.minMtcBox;   % determines whether mvec will be run

if bDISP > 3
    fprintf('spat rel: %1.3f  %1.3f = %1.3f  %d\n', spcng, Gbx.gnc, M.mtcBox, bMtcBox);
end

%% -------------   Match Vectors   ---------------
% af runMvec1.m
M.totFoc            = struct;
M.totFoc.bMtched    = 0;
if bMtcBox

    M.OutFoc      = RennMvec1( fipaQ, fipaR, Admin );

    u_StdOutOptUnrec( M.OutFoc );

    [StoF HedF]            = u_MtrMesSecs( M.OutFoc );
    [AMesDtyFoc M.totFoc]  = u_MtrMesScnf( StoF );
    
    M.totFoc.bMtched = 1;
end


end

