%
% Displays length of array Array
%
function hl = imglabKt(lstr, Array, bckGrndCol)

if nargin==2, bckGrndCol = 'w'; end

if ismatrix(Array) n = size(Array,1);
else               n = length(Array); end

imglab([lstr '  [' num2str(n) ']'], bckGrndCol);