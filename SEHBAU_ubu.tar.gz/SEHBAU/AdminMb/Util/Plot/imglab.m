%
% Will be called from imglabXXX
%
function hl = imglab( lstr, bckGrndCol )

Ha      = get(gca);
xXtd    = Ha.XLim(2);
yXtd    = Ha.YLim(2);

if xXtd > 400
    xfc  = 0.020;
    yfc  = 0.050;
elseif xXtd > 200
    xfc  = 0.005;
    yfc  = 0.020;
elseif xXtd > 50
    xfc  = 0.020;
    yfc  = 0.050;
else
    xfc  = 0.040;
    yfc  = 0.100;
end

x  = xXtd * xfc;
y  = yXtd * yfc;

hl = text(x, y, lstr, 'backgroundcolor', 'white', 'fontsize', 9);

if exist('bckGrndCol'), set(hl, 'backgroundcolor', bckGrndCol);  end
if exist('fontSize'),   set(hl, 'fontsize',   font_size);    end
% if exist('font_color'),   set(hl, 'color',      font_color);   end
