%
% Reads a struct-of-arrays that had been saved as data matrix given a list
% of fieldnames.
% 
% ai ReadShpAtt
%
function [S szD] = ReadStcArr( fid, conversion, aFieldNames )

% first load as data matrix
[S szD]     = ReadMtrxDat( fid, conversion );

% now turn into a struct-of-array
S           = u_MtrxToStcArr( S, aFieldNames );

end

