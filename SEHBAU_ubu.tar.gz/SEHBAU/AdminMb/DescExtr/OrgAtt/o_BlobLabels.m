%
% Texture biases, called blob labels here:
% 
% They are also used in ReadBlobMapGlbSts.m (but NOT passed as variable).
%
% They must match with CntTxtAnf.h, w_CntTXTbis (CntTxtIO.h)
%
% Their color code is in u_ColBlob.m
%
function [LS nTyp] = o_BlobLabels()

% NB NVHAU
LS      = {'Num' 'Blk' 'Nil' 'Vrt' 'Hor' 'Axi' 'Uni' 'Ken'};

nTyp    = length( LS );

end 

