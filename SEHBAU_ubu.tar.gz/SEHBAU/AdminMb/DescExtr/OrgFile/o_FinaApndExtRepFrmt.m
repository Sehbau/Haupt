%
% Appends the extensions for representation formats.
%
% py: DescExtr/OrgFile/FileNames.py
% 
% IN   fina   file stem, ie. 'IMGDAT/Collection/Desc/DSC_'
% OUT  S      struct with .dsc, .hsti, .kolm
%
% USE  stem     = [pthBas.DescRef 'DSC_' imna.ref];
%      Fixt     = o_FileExtensions();
%      Lfps     = o_FinaApndExtRepFrmt( stem, Fixt );
%      Lfps.dsc, Lfps.hst, ...
% 
function S = o_FinaApndExtRepFrmt( fist, Fixt )

if nargin==1
    Fixt = o_FileExtensions();
end

S   = struct;

S.( Fixt.dsc(2:end) )   = [ fist Fixt.dsc ];
S.( Fixt.hsti(2:end) )  = [ fist Fixt.hsti ];
S.( Fixt.kol(2:end) )   = [ fist Fixt.kol ];
S.( Fixt.slc(2:end) )   = [ fist Fixt.slc ];

end

