%
% Displays date for all files for ONE image.
% 
% IN   fpDSC  struct as generated with o_FinaApndExtDscx
% 
function [] = u_FipaDateExt( fpDSC )

aExt  = fieldnames( fpDSC );
nExt  = length( aExt );

for f = 1:nExt
    
    extn      = aExt{f};
    DispLoad( fpDSC.(extn) );
    
end

end

