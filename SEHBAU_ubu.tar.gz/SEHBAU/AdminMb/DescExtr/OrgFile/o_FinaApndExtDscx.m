%
% Generates filenames for descriptor extraction output (dscx) for ONE file
% stem.
% 
% IN   stm    file stem, ie. 'IMGDAT/Collection/Desc/DSC_'
%      Fixt   file extensions ( o_FileExtensions.m )
% OUT  S      struct with filepaths including the file extensions
%
% USE  stem     = [pthBas.DescRef 'DSC_' imna.ref];
%      Fixt     = o_FileExtensions();
%      Lfps     = o_FipasDscxWithStem( stem, Fixt );
%      Lfps.dsc, Lfps.hst, ...
% 
function S = o_FinaApndExtDscx( fist, Fixt )

aExt  = fieldnames( Fixt );
nExt  = length( aExt );

for f = 1:nExt
    
    extn      = aExt{f};
    S.(extn)  = [ fist Fixt.(extn) ];
    
end

end

