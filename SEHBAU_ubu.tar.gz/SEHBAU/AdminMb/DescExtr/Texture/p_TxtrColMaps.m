%
% Plots the chromatic maps
%
function [] = p_TxtrColMaps( M )

[nr,nc] = deal( 3, 3);

subplot(nr,nc,1); 
imagesc(M.Red.Men,[0 1]);
colorbar();
ylabel('Mean');
title(['Red ' sprintf('%1.3f', mean(M.Red.Men(:)))])

subplot(nr,nc,2); 
imagesc(M.Grn.Men,[0 1]);
colorbar();
title(['Grn ' sprintf('%1.3f', mean(M.Grn.Men(:)))])

subplot(nr,nc,3); 
imagesc(M.Blu.Men,[0 1]);
colorbar();
title(['Blu ' sprintf('%1.3f', mean(M.Blu.Men(:)))])


subplot(nr,nc,4); 
imagesc(M.Red.Max,[0 1]);
colorbar();
ylabel('Max');

subplot(nr,nc,5); 
imagesc(M.Grn.Max,[0 1]);
colorbar();

subplot(nr,nc,6); 
imagesc(M.Blu.Max,[0 1]);
colorbar();

sclMin = [0 0.5];

subplot(nr,nc,7); 
imagesc(M.Red.Min,sclMin);
colorbar();
ylabel('Min');

subplot(nr,nc,8); 
imagesc(M.Grn.Min,sclMin);
colorbar();

subplot(nr,nc,9); 
imagesc(M.Blu.Min,sclMin);
colorbar();
end

