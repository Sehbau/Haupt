% 
% The argument structure for descriptor extraction program dscx.
%
% Minimal version.
%
% Default is that NO options will be modified and no string will be created
% in i_OptDscx.
%
% IN    - 
% OUT   O   struct with options and parameters
%
function O = o_OptDscxStc()

warning('discontinued:  use o_DscxArgs now');

%% -----   Saving  -----
O.saveRRE   = 0;    % saving of RRE space (full set)
O.saveCVP   = 0;    % saving of full CVP space
O.saveBin   = 0;    % saving of bins
O.saveKol   = 0;    % saving of kolumns
O.saveProp  = 0;    % saving proposals

O.saveRpx   = 0;    % region pixels
O.saveBbox  = 0;    % extraction bboxes 
O.saveBon   = 0;    % extraction boundary pixels 
O.noSave    = 0;    % saving of description


%% -----  Archit  -----
% a value of -1 signals that no modification is desired. default remains.
O.nLev      = -1;
O.depth     = -1;
O.is        = -1;   % image space (pyramid or scale space)

aFldn       = fieldnames(O);
O.nFld      = length(aFldn) + 1;    % include self

end

