%
% Plots the contour universe using keypoints.
%
% Since contours are in absolute coordinates, plotting for a pyramid
% requires adjustment, which is done here by downscaling the image.
%
% IN  CUV     RRE spaces of keypoints 
%     Irgb    the image
%     typIsp  type image space
%     figNo   figure number
%
function [] = PlotCntUnvKpt( CUV, Irgb, typIsp, figNo )

nLev    = length( CUV.ARDG );

fprintf('Plotting contour universe with keypoints for %d levels...', nLev); 

figure(figNo); clf;
[nr nc]  = deal( ceil(nLev/2), 2 );     % # of rows/cols for subplots

for l = 1:nLev
    
    subplot(nr, nc, l);
    
    if typIsp==1
        % if pyramid, then downscale
        imagesc( imresize( Irgb, 1 / 2^(l-1)) ); 
    elseif typIsp==2
        imagesc( Irgb );
    else
        error('image space %d not implemented');
    end

    Rdg = CUV.ARDG{l};
    Riv = CUV.ARIV{l};
    Edg = CUV.AEDG{l};

    p_CntKeyPts( Edg, 'c', 'abs');     % edges
    p_CntKeyPts( Riv, 'b', 'abs');     % rivers
    p_CntKeyPts( Rdg, 'r', 'abs');     % ridges

    set(gca,'fontsize',5);
    
end
fprintf('done\n');


end

