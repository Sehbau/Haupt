%
% Places selected CCs (their region pixels) from different depths (of one
% tree/level) into one map (no RGB plotting).
%
% sa p_RegPixDepthOne, PlotRegPix.m
% cf exsbRoadScene.m
%
% IN   ARegPix  region pixels from one tree, ie. AREG(1,:)
%      Org      origin: depth and CC index
%      IxReg    the selected regions to place into the map
%      szM      size map
%      gry      gray-scale level
% OUT  Mp       map
%
function Mp = u_RegPixToMapSel( ARegPix, Org, IxReg, szM, gry )

Mp    = zeros( szM([2 1]), 'single');   % inverse: 
nReg  = length( IxReg );

for r = 1:nReg
    
    ixR     = IxReg(r);             % the selected region
    dth     = Org.Dth(ixR);         % depth of segmentation tree
    ixCC    = Org.CC(ixR);
    
    Rpx     = ARegPix{dth};         % all pixels for entire depth
    af      = Rpx.Anf(ixCC);        % anfang of selected CC
    ed      = Rpx.Anf(ixCC+1) - 1;  % ende
    
    Rng     = af:ed;                % range of linear indices
    Mp( Rpx.IxLin( Rng ) ) = single(gry);   % place into map with a gray shade
    
end

end

