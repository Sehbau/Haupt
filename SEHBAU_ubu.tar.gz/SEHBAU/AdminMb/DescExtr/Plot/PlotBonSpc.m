%
% Plots the boundary space
%
% IN   ABON   boundary space {nLev}
% 
function [] = PlotBonSpc( ABON, szI, bImgSpc )

nLev        = length( ABON );

%% -----   Compute Map Sizes   -------
if bImgSpc==1                       % pyramid
    % we compute the sizes of the pyramid level because we did not save
    % them.
    SzM     = zeros( nLev, 2 );
    SzM(1,:) = szI(1:2);
    for l = 2:nLev
        SzM(l,:) = SzM(l-1,:) / 2;
    end
elseif bImgSpc==2
    % same size for entire space
    warning('scale space not verified yet');
    SzM     = repmat( szI, nLev, 1 ); % correct?
else
    error('bImgSpc = %d not impl.', bImgSpc );
end

%% -----   Plot Pixels   ------
[nr nc]     = deal(nLev, 1);    % # of rows/cols for subplots
for l = 1:nLev
    
    APix        = ABON{l};
    % nBon        = length(APix);
    [szV szH]   = deal( SzM(l,1), SzM(l,2) );
    
    subplot(nr, nc, l ); hold on;

    p_BoundList( APix, 'plot', szV, 1, 1, 0 );
    
    axis tight;
    set(gca,'fontsize',5);
    ylabel(['Lev = ' num2str(l-1)], 'fontsize', 12);
    
end