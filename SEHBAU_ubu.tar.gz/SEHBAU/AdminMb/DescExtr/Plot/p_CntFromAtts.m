%
% Plots a list of contours from attribute information using the structure
% as loaded by LoadDescImag.
%
% Two plotting modes:
% - unit range plotted into Cartesian coord-system (default)
% - plotted to an image as ij and scaling up accordingly
%
% Since we have only the midpoint (of the two endpoints), we need to
% estimate the two endpoints using the orientation angle and the segment
% length.
%
% Watch the signs: we need to transform from matrix dimensions (ij) to
% Cartesian coordinates (xy)!
%
function [] = p_CntFromAtts( CNT, szM, col ) 

bUnitRange  = 1;
bColRGB     = 1;

if nargin>1
    bUnitRange = 0;
    bColRGB    = 0;
    szV   = szM(1);
    szH   = szM(2);
    col   = 'y';
end

for i = 1:CNT.nCnt

    ori     = CNT.Ori(i);           % orientation angle
    les     = CNT.Les(i);           % length
    ctr     = CNT.Ctr(i);           % contrast
        
    yrd     = sin(ori) * les/2;     % quasi radius
    xrd     = cos(ori) * les/2;

    if bUnitRange
        % from ij to Cartesian coordinates
        posV    = 1 - CNT.Pos.Vrt(i);   % vertical position (ij->Cartes.)
        posH    = CNT.Pos.Hor(i);       % horizontal position
        % watch the signs
        hl = line([posH - xrd  posH + xrd], [posV + yrd  posV - yrd]); 
    else
        yrd   = yrd * szV;
        xrd   = xrd * szH;
        posV  = CNT.Pos.Vrt(i) * szV;
        posH  = CNT.Pos.Hor(i) * szH;
        hl = line([posH - xrd  posH + xrd], [posV - yrd  posV + yrd]); 
    end
    
    
    % add color:
    if bColRGB,
        red     = CNT.RGB.Red(i);
        grn     = CNT.RGB.Grn(i);
        blu     = CNT.RGB.Blu(i);
        set(hl, 'color', [red grn blu]);
    else
        set(hl, 'color', [1 1 0]);
    end
    
    % make linewidth proportional to contrast:
    set(hl, 'linewidth', 0.2 + 2*ctr); % 0.2 is minimum width
    
end    
