%
% Places region pixels into a map, according to counter (no RGB plotting)
%
% sa PlotRegPix.m
% cf exsbRoadScene.m
%
function Mp = u_RegPixToMap( ARegPix, Org, IxReg, szM )

Mp    = zeros( szM([2 1]), 'single');   % inverse: 
nReg  = length( IxReg );

for r = 1:nReg
    
    ixR     = IxReg(r);             % the selected region
    dth     = Org.Dth(ixR);         % depth of segmentation tree
    ixCC    = Org.CC(ixR);
    
    Rpx     = ARegPix{dth};         % all pixels for entire depth
    af      = Rpx.Anf(ixCC);        % anfang of selected CC
    ed      = Rpx.Anf(ixCC+1) - 1;  % ende
    
    Rng     = af:ed;                % range of linear indices
    Mp( Rpx.IxLin( Rng ) ) = r;     % place into map
    
end

end

