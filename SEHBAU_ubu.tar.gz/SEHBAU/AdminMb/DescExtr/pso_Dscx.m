% 
% Parse standard output of program dscx for displayed parameters.
%
% IN    Out   standard out
% OUT   []
%
function [] = pso_Dscx(Out)

ixPrms = strfind(Out, 'Prms Desc');

if ~isempty( ixPrms )

    OutPrms = Out( ixPrms:end );
    
    IxCR    = regexp( OutPrms, '\n' );

    fprintf('%s', OutPrms( 1:IxCR ) );

end

end

