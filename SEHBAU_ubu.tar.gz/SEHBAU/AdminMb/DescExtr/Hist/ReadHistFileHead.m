%
% Reads histogram file header, namely struct fhedHist in
% E_DESC/UtilIO/DescFileAnf.h and saved under w_DescHistHead in
% DescIOhist.m
%
% cf LoadDescHist
%
function [H] = ReadHistFileHead( fileID )

ntBin  = fread(fileID, 1,  'int=>int');      % # of total desc
szV    = fread(fileID, 1,  'int=>int');      % vertical image size
szH    = fread(fileID, 1,  'int=>int');      % horizontal image size
ntDsc  = fread(fileID, 1,  'int=>int');      % # of total desc

nLev    = fread(fileID, 1,  'uint8=>uint8');  % # of pyramid levels
typ     = fread(fileID, 1,  'uint8=>uint8');  % file identifier
nVrtSph = fread(fileID, 1,  'uint8=>uint8');   % nVrt cells
nHorSph = fread(fileID, 1,  'uint8=>uint8');   % nHor cells

vers    = fread(fileID, 1,  'float=>single');  % version

if (nLev<1 || nLev>10)
    fprintf('nLev not correct: %d\n', nLev);
    szV, szH, ntDsc, typ
end
assert(szV>0 && szV<5000, 'szV unreasonable: %d', szV);
assert(szH>0 && szH<5000, 'szH unreasnoable: %d', szH);
assert( abs(vers-1.03)<0.001, 'Version depreciated: is %1.12f. new 1.03', vers);

H.ntBin = ntBin;
H.szV   = szV;
H.szH   = szH;
H.ntDsc = ntDsc;

H.nLev  = nLev;
H.typ   = typ;
H.nVrtSph = nVrtSph;
H.nHorSph = nHorSph;


end

