%
% Generates hash values (Id) for a matrix of binvectors.
%
% Consider renaming to f_VebToQntId | f_QntIdVmx
%
% cf plcQntHist.m, qntApply.m
% 
% IN  VBN     matrix of binvectors [nVec nAtt], the keys
%     Base    hash base [1 nAtt], ie. [1 12 144]
%     HashQnt hash of quants [1 nQnts]
% OUT Val     the value [nVec 1]
%
function Val = f_HashVbnMx( VBN, Base, HashQnt )

    HashVec     = single( VBN ) * Base';
    
    [tf, Val]   = ismember( HashVec, HashQnt );
    
    % Convert 0 (not found) to NaN
    Val(~tf) = NaN;
    
end






