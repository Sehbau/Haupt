%
% Upscaling a pyramid of boundary pixels. Useful for plotting boundaries of
% different levels into the same plot/image (original image resolution).
%
function [aOT] = u_ScaleBonPyr( aIN )

SclFct = [1 2 4 8 16 32 64 128];

nLev   = length( aIN );

aOT    = cell( nLev, 1);

aOT{1} = aIN{1};            % copy first level (no scaling necessary)

% from second level on:
for l = 2:nLev
    aOT{l}  = f_BonPixScale( aIN{l}, SclFct(l) );
end

end

