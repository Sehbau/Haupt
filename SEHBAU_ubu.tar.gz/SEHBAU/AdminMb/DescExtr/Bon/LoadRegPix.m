%
% Loads as saved under B_BON/Util/BonIO.h-s_BonPix().
%
function [APIX Kt] = LoadRegPix( lfn ) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----------   Sizes   -------------
nLev     = fread(fileID, 1, 'int=>single');
depth    = fread(fileID, 1, 'int=>single'); 

fprintf('LoadRegPix:  nLev %d  depth %d\n', nLev, depth );
    
Ncc     = zeros(nLev,depth);
Non     = zeros(nLev,depth);
for l = 1:nLev
    for d = 1:depth
        nCC    = fread(fileID, 1, 'int=>single');
        nON    = fread(fileID, 1, 'int=>single');
        
        %fprintf('lev %d, dth %d   nCC %4d  nON %6d\n', l, d, nCC, nON );
        Ncc(l,d) = nCC;
        Non(l,d) = nON;
    end
end

%% -----------   Pixels   -------------
APIX    = cell(nLev,depth);
for l = 1:nLev
    for d = 1:depth
        APIX{l,d} = ReadRegPixBlok( fileID );
    end
end

idf     = fread(fileID, 1, 'int=>single');
assert(idf==-22222);

fclose( fileID );

Kt.Ncc      = Ncc;
Kt.Non      = Non;

fprintf('\n');

