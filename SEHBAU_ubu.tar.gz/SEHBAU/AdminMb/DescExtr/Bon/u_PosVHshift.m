%
% Shift position coordinates by offsets offV and offH.
%
function P = u_PosVHshift( P, offV, offH )

P.Vrt = P.Vrt + offV;
P.Hor = P.Hor + offH;

end

