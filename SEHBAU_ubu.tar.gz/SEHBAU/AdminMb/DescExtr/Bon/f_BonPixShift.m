%
% Shift boundary pixels (in list aPix) by offsets offRw and offCl.
%
function aScl = f_BonPixShift( aPix, offRw, offCl )

nBon = length(aPix);

aScl = cell(nBon,1);

for i = 1:nBon
    
    Pix    = aPix{i};
    Pix.Rw = Pix.Rw + offRw;
    Pix.Cl = Pix.Cl + offCl;
    
    aScl{i} = Pix;
end

end

