%
% Reads space of radsig attributes as saved under RsgIO.h-w_RsgSpc
%
% af ReadCntBinSpc.m
%
function [AUNI Nrsg] = ReadRsgBinSpc(fid)

nLev  = fread(fid, 1,    'int=>int');      % # of levels

AUNI  = cell(nLev,1);
ABIV  = cell(nLev,1);
Nrsg  = zeros(nLev,1);
for l = 1:nLev
    
    [AUNI{l} nRsg1] = ReadRsgBinUni(fid);
    [ABIV{l} nRsg2] = ReadRsgBinBiv(fid);
    
    Nrsg(l)  = nRsg1;
    
    assert( nRsg1==nRsg2, 'rsg count not matching' );
    
    S.APOSA{l}    = ReadAttPos( fid, 'float=>single' );
    S.APOSQ{l}    = ReadAttPos( fid, 'uint8=>uint8' );    
    
end

end

