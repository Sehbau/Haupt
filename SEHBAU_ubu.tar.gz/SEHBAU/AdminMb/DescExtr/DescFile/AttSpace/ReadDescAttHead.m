%
% Reads attributes header ( A_ANF/Desc/DescIOanf.h )
%
% cf Read{Dsc}Att.m, ie ReadCntAtt.
%
function [H] = ReadDescAttHead( fileID )

H = [];

H.nDsc = fread( fileID, 1, 'int=>single'); % # descriptors
H.bNap = fread( fileID, 1, 'uint8=>uint8'); % not applicable
%H.bCol = fread(fileID, 1, 'uint8=>uint8'); % color info (boolean)

end

