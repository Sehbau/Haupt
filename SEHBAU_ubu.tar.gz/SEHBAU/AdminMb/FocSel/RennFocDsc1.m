%
% Wrapper routine for program focdsc1
%
% sa RennDscx.m
%
% IN    fipaDsc  descriptor file path (must include extension '.dsc')
%       Bbox     bounding box as array of numbers [top/bot/lef/rit]
%       fipsOut  output filenamestem
%       Admin    administration, u_CmndAdmin.m
%
% OUT   Sz       struct with nLev, ntDsc
%       Out      stdout
% 
function [Sz Out] = RennFocDsc1( fipaDsc, Bbox, fipsOut, Args, pthProg )

% create bounding box as string
bboxStr   = sprintf('%d %d %d %d', Bbox(1), Bbox(2), Bbox(3), Bbox(4));

if nargin==4, 
    pthProg = ''; 
end

fpProg  = [pthProg 'focdsc1'];

if exist( fpProg, 'file')==2,
    error('Program path not correct: %s', fpProg);
end

cmnd    = [ fpProg ' ' fipaDsc ' ' bboxStr ' ' fipsOut ' ' Args.opt ];

[status Out] = system(cmnd);               % excecute program

%% ------  Status  ------
if status>0
    Out
    warning('Command %s returns exit code > 0 (see Out above)', cmnd);
end

%% -----   Analyse StdOut  -----
ixLev    = strfind( Out, 'nLevFoc');
Sz.nLev  = str2num( Out(ixLev+8));
ixDsc    = strfind( Out, 'ntDsc');
Sz.ntDsc = sscanf(  Out(ixDsc+5:end), '%d', 1); %str2num(Out(ixDsc+6));

%% ------  Verify Proper Termination  -----
ixEOP = strfind(Out,'EndOfProgram');
if isempty(ixEOP)
    warning('Command %s not executed. See sz and Out below', cmnd);
    Sz
    Out
    fprintf('Paused');
    pause();
end



