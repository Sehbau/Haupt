"""

Example for generating the vector file (from the description file).

Assumes that description file has already been generated.

To be run from directory 'DescExtr'.

PREVIOUS  exsbDscx1.py
PRESENT   exsbD2vmx.py
NEXT      

"""
import sys, subprocess
import numpy as np
from pathlib import Path
sys.path.insert(0, '..')
import AdminPy as sb
from AdminPy import DescExtr as dscx


# ------------------------------   Run 1 Conversion   ------------------------------
fpDsc = Path( 'Desc/img1.dsc' )
fpVec = Path( 'Vect/img1' )

cmnd = [ 'd2vmx',  fpDsc, fpVec ]

Res  = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

if Res.returncode != 0:
    raise ValueError("h2arr did not execute properly somehow")

# ------------------------------   Load   ------------------------------
aFixtVec, nDty   = dscx.OrgDescTyp.o_DescTypes('fixtVec')
aFixtLev, dmy    = dscx.OrgDescTyp.o_DescTypes('fixtLev')
aDtyS, nDty      = dscx.OrgDescTyp.o_DescTypes('Crasstb')

# Order:       cnt rsg arc str bnd ttg shp
OrdDty      = np.array( [ 1,  2,  3,  4,  7,  6,  5 ] ) - 1

import matplotlib.pyplot as plt

# --------------------------------------------------------------------------------
#                       L O O P   D E S C T Y P E S
# --------------------------------------------------------------------------------
for i in range(0,nDty):

    ixDsc = OrdDty[i]

    # --------------------   Load   --------------------
    dtyV  = aFixtVec[ixDsc]
    dtyL  = aFixtLev[ixDsc]

    lfpV  = fpVec.with_suffix( '.' + dtyV )
    lfpL  = fpVec.with_suffix( '.' + dtyL )

    VMX, nDsc, LbsAtt, nAtt   = dscx.LoadDescVect( lfpV )

    Lev, nDsc2                = dscx.LoadDescVectLev( lfpL )

    if nDsc < 0:  # in case of NaN (problems with reading directly float from file)
        VMX, nDsc = sb.Util.UtilSscanf.f_SscanfVectMxWithNan( VMX, nAtt )

    assert nDsc == nDsc2, f"Descriptor count mismatch: {nDsc} vs {nDsc2}"

    # --------------------   Plot   --------------------
    plt.figure(i+1)
    plt.imshow(VMX, aspect='auto', cmap='viridis')  # imagesc equivalent
    plt.colorbar()

    # Set x-axis ticks and labels
    plt.xticks(ticks=np.arange(nAtt), labels=LbsAtt, rotation=45)
    
    # Add a title
    plt.title(aDtyS[ixDsc])
    
    plt.tight_layout()
    plt.show(block=False)
    plt.pause(.01)


import time
time.sleep(2)

