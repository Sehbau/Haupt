%
% Example for collecting vectors
%
% Assumes we have run script plcDscx.m already.
%
clear;
run('../globalsSB');

% we take the vector files from the place recognition demo
pthVec      = '../DemoPlcRec/Desc/';
aVecNa      = dir( [ pthVec '*.vec' ]); 
finaLst     = 'Regist/FinasVec.txt';
SaveFipaLstPrependPath( aVecNa, pthVec, finaLst );

fpColl      = 'Desc/COLL';
dscTyp      = 'skl';

%% -------   The Program   -------
fpProg      = FipaExe.collvec;  
v_ProgExists( fpProg, ispc ); 

%% -------   Execute Command   --------
cmnd         = sprintf('%s %s %s %s', fpProg, finaLst, dscTyp, fpColl );
[status Out] = dos( cmnd );
v_CmndExec( status, Out, cmnd );

%% -------   Load Output   --------
[VEC ntDsc nAtt] = LoadCollVec(    fpColl, dscTyp );
[LAB ntDscL]     = LoadCollVecLab( fpColl, dscTyp );

assert(ntDsc==ntDscL, 'ntDsc not same.', ntDsc, ntDscL );

%% -------   Plot   --------
ts      = sprintf('%s  [ %d %d ]', dscTyp, ntDsc, nAtt );

figure(1);
imagesc(VEC);
title( ts );
colorbar();

LAtts       = o_AttsLabels();
set(gca, 'xtick', 1:nAtt, 'xticklabel', LAtts.Skl );

