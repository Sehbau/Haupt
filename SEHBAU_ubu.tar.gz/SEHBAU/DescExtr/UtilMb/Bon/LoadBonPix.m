%
% Loads as saved under B_BON/Util/BonIO.h-s_BonPix().
%
function [APix nBon szM Org] = LoadBonPix( lfn, bSegwWise ) 

if nargin==1, 
    bSegwWise = 0; 
end

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

if bSegwWise
    [APix nBon szM Org] = ReadBonPixSegw( fileID );
else
    APix = ReadBonPixBlok ( fileID );
end

fclose( fileID );

fprintf('\n');

