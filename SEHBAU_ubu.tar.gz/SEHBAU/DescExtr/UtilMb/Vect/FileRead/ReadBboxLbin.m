%
% Reads as saved under wb_BboxL
%
% ai ReadBlobOut.m, cc_CntItgr
%
% af LoadCCRccBboxUnv.m
%
function [ABbox nBox] = ReadBboxLbin(fileID) 

%% -----  Head  -----
nBox        = fread(fileID, 1, 'int=>int');
% fprintf('[nBox %4d] ', nBox);

%% =====  BoundingBoxes  =====
Top         = fread(fileID, nBox, 'int=>int');
Bot         = fread(fileID, nBox, 'int=>int');
Lef         = fread(fileID, nBox, 'int=>int');
Rit         = fread(fileID, nBox, 'int=>int');

ABbox       = [Top Bot Lef Rit];
