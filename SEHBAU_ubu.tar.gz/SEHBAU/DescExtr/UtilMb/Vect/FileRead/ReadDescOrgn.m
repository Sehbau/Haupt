% 
% Reads descriptor origin information as saved in C under w_DescOrgn.
% Indices are turned into one-indexing (+1).
%
function [S] = ReadDescOrgn( fileID, nDsc )

% make it all one-indexing - where applicable
S.Anf    = fread(fileID, nDsc, 'int=>int')     + 1;     
S.Npx    = fread(fileID, nDsc, 'int=>int');     % number of pixels
S.IxBtw  = fread(fileID, nDsc, 'int=>int')     + 1;     
S.OrgCrv = fread(fileID, nDsc, 'int=>int')     + 1;   
S.OrgDth = fread(fileID, nDsc, 'uint8=>uint8') + 1; 

end

