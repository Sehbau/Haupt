%
% Loads the image histogram as saved under h2arr.cpp. It is just an
% array of integers (text).
%
function [H] = LoadHistImgArr( lfn ) 

fileID   = fopen(lfn, 'rt');
if (fileID<0), error('file %s not found', lfn); end

H = fscanf( fileID, '%d');

fclose(fileID);







