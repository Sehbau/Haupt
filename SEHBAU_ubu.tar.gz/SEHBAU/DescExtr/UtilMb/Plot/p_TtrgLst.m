%
% Plots a list of tetragon polygons from struct.
%
function [] = p_TtrgLst( Ttg, szM )

colOrng = [255 128   0] / 255;  % orange
colBlue = [0   0   255] / 255;  % blue

szV     = szM(1);
szH     = szM(2);

% the corresponding boundaries
nTtg = Ttg.nTtg;

for t = 1:nTtg
    
    [Axe Cor Tg] = u_TtrgRtrv1( Ttg, t );
        
    %% ---  polygon  ---
    hp  = plot( Cor.Cl*szH, Cor.Rw*szV, 'color', colOrng );
        
    % --- boundary pixels
    %hp  = plot( Pix.Cl, Pix.Rw, 'color', rgb);
    
    % --- boundary pole
    %plot( Tg.hor*szM(2), Tg.vrt*szM(1), '.', 'color', rgb);
    
    % --- elo-axes 
    hp  = plot( Axe.Cl*szH, Axe.Rw*szV, 'color', colBlue );
    
end
    


end

