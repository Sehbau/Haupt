%
% Plots the row and column coordinates of S as points into an image.
%
% af p_Pix.m
%
function [] = p_PixRC( S, colAndMrk, mrkSz, mrkFill )

if nargin==1, 
    colAndMrk = 'r*';
end

%% ======   Plot the Points   =======
plot( S.Cl, S.Rw, colAndMrk );

%% ======   Modify the Points   ======
if nargin>2
    set(hp, 'markersize', mrkSz);
end
if nargin>3
    if mrkFill
        set(hp, 'markerfacecolor', hp.Color);
    end
end

end

