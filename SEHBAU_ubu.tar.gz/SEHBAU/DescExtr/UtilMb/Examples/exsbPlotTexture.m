%
% Example for loading and plotting the texture info as saved in the .itgc
% file.
%
% Run from WITHIN directory DescExtr/UtilMb/Examples
%
clear;
run('../../../globalsSB.m');

pthText     = '../../Desc/img1.itgc';
%pthText     = '../../Desc/img2.itgc';       
%pthText     = '../../Desc/aachen.itgc';     

Irgb        = imread('../../Imgs/img1.jpg');

[MKT MPS YTG] 	= LoadCntYtgMaps( pthText );

%%
  figi(20, 'KOLM');
    p_SUBtig(1,2,1);
    KOL = YTG.KOLM.LEN;
    imagesc( KOL.H );

    Mlin = sum( KOL.H, 2 );
    Map  = reshape( Mlin, MKT.SzM(1,[2 1]) );
    Map  = Map';
    
    p_SUBtig(1,2,2);
    imagesc(Map);