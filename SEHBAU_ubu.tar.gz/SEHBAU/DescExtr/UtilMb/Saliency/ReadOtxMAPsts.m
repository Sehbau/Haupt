%
% Reads the statistics of the ori-bias maps as saved under w_OtxMAPsts() in
% A_CONT/Itgr/Util/CntTxtIO.h
%
% cf LoadDescSalc, LoadSalcAly.m
%
function [S] = ReadOtxMAPsts( fileID )

%% -----   Blob Labels   -----
% They must match with CntTxtAnf.h
aBlobLab  = {'Num' 'Blk' 'Nil' 'Vrt' 'Hor' 'Axi' 'Uni'};

nTyp        = length( aBlobLab );

for i = 1:nTyp
    lb          = aBlobLab{i}; 
    S.( lb )    = ReadMapBisStat( fileID );  % reads five values
end

% =====   Trailer   =====
idf    = fread(fileID, 1, 'int32=>int');

assert(idf==46593, 'idf not correct: %d', idf);

end

