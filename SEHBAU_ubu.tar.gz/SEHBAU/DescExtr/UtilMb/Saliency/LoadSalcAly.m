%
% Load as saved as with si_SalcAly in SalncyIO.h
%
function Z = LoadSalcAly( lfp, aTxtTypS )

%% -----------   Open   ------------
fileID      = fopen(lfp, 'r');
if fileID<0, error('Could not open file %s', lfp); end
DispLoad( lfp );

%% ------------   Header  -----------
szM         = fread( fileID, 2, 'int=>single' );

nRix0       = szM(1)*szM(2);
assert(nRix0>0 && nRix0<5000, 'nRix0 not reasonable: %d', nRix0);

%% ------------   Data  -----------
[Z]       	= ReadOtxMAPsts( fileID, aTxtTypS );

Z.PX.DomKntImg  = ReadPixvRCi( fileID );
Z.PX.DomCtrImg  = ReadPixvRCf( fileID );
Z.PX.DomKntLay  = ReadPixvRCi( fileID );
Z.PX.DomCtrLay  = ReadPixvRCf( fileID );

Z.BlobImg   = ReadBlobOut( fileID, 1 );
Z.BlobLay   = ReadBlobOut( fileID, 1 );

%X.Fru.ATop  = ReadMapTopoSpc( fileID ); %, nLay );
%X.Fru.Ctr   = ReadMapTopo( fileID );   % one map only
%X.Img.ATop  = ReadMapTopoSpc( fileID ); %, nLay );
%X.Img.Ctr   = ReadMapTopo( fileID );   % one map only

%S.Mdff      = fread( fileID, nRix0, 'float=>single' );
%S.Mdff      = reshape( S.Mdff, szM(2), szM(1) )';
Z.Mdff      = ReadMapGen( fileID, szM, 'float=>single' );

%PRP.ABxCntBlob = ReadBboxLbin( fileID );

%% ------------   Close   -----------
fclose( fileID );


