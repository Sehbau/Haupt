%
% Loads all contour spaces (RRE), as saved under CntIOrre.h:si_RREspc.
%
function [RRE] = LoadCntRRE(lfn) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

RRE.ARDG    = ReadCntSpc( fileID );
RRE.ARIV    = ReadCntSpc( fileID );
RRE.AEDG    = ReadCntSpc( fileID );

fclose(fileID);

DispLoad(lfn);


