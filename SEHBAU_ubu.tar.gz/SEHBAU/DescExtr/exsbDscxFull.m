%
% Runs program dscx and loads all files. Assumes the organization as given
% in the repository.
%
% In case windows does not run the executable:
% https://de.mathworks.com/matlabcentral/answers/316233-can-t-run-external-program
%
clear;
run('../globalsSB');        % assumes script is run from dir 'DescExtr'
    
strImg 	= 'img1.jpg';
%strImg 	= 'img2.jpg';
%strImg    = 'aachen.png';

pthImg	= ['Imgs/' strImg];         % image path
pthOut 	= ['Desc/' strImg(1:end-4)]; % output file path

% change to window backslash (in case we are on windows)
pthImg  = u_PathToBackSlash( pthImg, ispc ); 
pthOut  = u_PathToBackSlash( pthOut, ispc ); 

%% --------   Options   --------
if 0                        % either manually
    %optS  	= '';               % default: no parameters modified
    %optS    = 'PrmDescTest.txt';
    %opts 	= '--nLev 3';       % write here...
    optS 	= '--depth 3 --saveRRE --saveCVP';       % write here...
else                        % ...or use the following convenience wrapper
    OptK            = o_OptDscxStc();
    OptK.nLev       = 3 ;
    OptK.saveRRE    = 1 ;
    OptK.saveCVP    = 1 ;
    OptK.saveBbox   = 1 ;
    OptK.saveBon    = 1 ;    
    OptK.saveKol    = 0 ;
    %OptK.is         = 2 ; % scale space
    optS            = i_OptDscx(OptK);
end

%% =========   Command   ========
% We could use RennDscx.m, but for first demonstration we are explicit:
% Concatenate program name, arguments and options to one string
cmnd        = ['dscx ' pthImg ' ' pthOut ' ' optS];

if ispc
    [Sts Out] = dos(cmnd);      % excecute program for windows
elseif isunix
    [Sts Out] = unix(cmnd);     % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 );

%% -------   Load Vectors and Contour Endpoints   -------
% DispLoad([pthOut '.vec']);
[DSC Kt Hed]   	= LoadDescImag(  [pthOut '.dsc']);    
[CNT Ncnt]    	= LoadCntxSpcEpt([pthOut '.CntEpt']);
nLev          	= Kt.nLev;

%% -----   Plot Contours   -----
%
% Since contours are in absolute coordinates, plotting for a pyramid
% requires adjustment, which is done here by downscaling the image.
%
fprintf('Plotting contours'); fprintf('...');
Irgb    = imread(pthImg);              	% load image again for plotting
figure(2); clf;
[nr nc]  = deal( ceil(nLev/2), 2 );     % # of rows/cols for subplots

for l = 1:nLev
    
    subplot(nr, nc, l);
    
    if Hed.space==1
        % if pyramid, then downscale
        imagesc( imresize( Irgb, 1 / 2^(l-1)) ); 
    else
        imagesc( Irgb );
    end

    Rdg = CNT.ARDG{l};
    Riv = CNT.ARIV{l};
    Edg = CNT.AEDG{l};

    p_CntFromEpt( Rdg, 'r', 'abs');     % ridges
    p_CntFromEpt( Riv, 'b', 'abs');     % rivers
    p_CntFromEpt( Edg, 'c', 'abs');     % edges

    set(gca,'fontsize',5);
    
end
fprintf('done\n');

%% -----   Plot More  -------
% see examples in directory UtilMb/Examples/

%% -----   More Loading   -------
% this is done for verification. No usage here.
fprintf('Loading more output...\n');
[HFU HFB HSP Nbin HedHst] = LoadDescHist([pthOut '.hst']);

%aBlobTypS           = o_BlobLabels();
[Txm Shp Ens Dsc]   = LoadDescSalc(  [pthOut '.slc'] );
[ABbox Nbon0 IxX]   = LoadBonBboxPyr([pthOut '.BonBbox']);
[AASP  Nbon1]       = LoadBonAspPyr( [pthOut '.BonAsp']);
[APIX  Nbon2 SzM]   = LoadBonPixPyr( [pthOut '.BonPix']);
[ABbox Ncc]         = LoadBboxFunv(  [pthOut '.Bbox']);
fprintf('done\n');

[RRE]               = LoadCntRRE(  [pthOut '.dscRRE'] );
[CVP Kt]            = LoadCVPfull( [pthOut '.dscCVP'] );

