"""

Example using wrapper routine RennDscx()

Analogous to exsbDscxFull.m

"""
import sys
from pathlib import Path
sys.path.insert(0, '..')
from dataclasses import is_dataclass

from AdminPy import DescExtr as dscx
from AdminPy import Util as sbutil

strImg 	= Path('img1.jpg')
#strImg = Path('img2.jpg')

pthImg	= Path( 'Imgs/' ) / strImg         # image path
pthOut 	= Path( 'Desc/' ) / strImg.stem    # outpath 
optS    = '--depth 2'

# ------------------------------   Execute Explicitly   ------------------------------
# not much new here (coming form exsbDscxSimp.py)
if sys.platform.startswith('win'):

    cmnd  = [ 'dscx', pthImg, pthOut, optS ]

else:
    # explicitly, because my ubuntu/python3 (v 3.10.12) would not take the cmnd as
    # in Windows above
    cmnd  = './dscx ' + str(pthImg) + ' ' + str(pthOut) + ' ' + optS 

import subprocess

Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )

if Res.returncode != 0:
    raise ValueError("dscx did not execute properly somehow")

# ------------------------------   Execute With Wrapper Function   ---------------------
# this is new:
Args       = sbutil.dclsArgsCmnd            # CmndSupp.py
Args.optS  = '--depth 2'
  
StdOut     = dscx.RennDscx( pthImg, pthOut, Args )


# ------------------------------   Load   ------------------------------
if 1:
    # appending all file extensions for convenience, thus generating fpDSC.dsc,
    # fpDSC.dsb, ...
    FixtImg, FixtFoc  = sbutil.o_FileExtensions()
    fpDSC       = sbutil.o_FinaApndExtDscx( str(pthOut), FixtImg() )
    DSC, Hed    = dscx.LoadDescImag( fpDSC.dsc )
    BIN, HedB   = dscx.LoadDbinImag( fpDSC.dsbi )
else:
    # or explicitly
    fpDsc       = pthOut.with_suffix('.dsc')
    fpBin       = pthOut.with_suffix('.dsb')
    DSC, Hed    = dscx.LoadDescImag( fpDsc )
    BIN, HedB   = dscx.LoadDbinImag( fpBin )

# from dataclasses import asdict
print( f'Head  nLev {Hed.nLev}  depth {Hed.depth}' )
print( DSC.keys() )
print( DSC['Labs'].Shp.Sco )
