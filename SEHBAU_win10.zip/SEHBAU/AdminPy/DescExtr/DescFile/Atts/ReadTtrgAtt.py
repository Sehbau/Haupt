"""

Reads tetragon attributes and space.

def ReadTtrgAtt( fid ):
def ReadTtrgSpc( fid ):
def ReadTtrgBinUni( fid ):
def ReadTtrgBinSpc( fid ):

Elsewhere:
- u_TtrgRtrv1 in LoadDescription

"""
import numpy as np
from dataclasses import dataclass

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import *
from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescFile.PixPoints.ReadPixPoints import *



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadTtrgAtt   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads tetragon attributes as saved under TtrgIO.h-w_TtrgSpc

"""
def ReadTtrgAtt( fid ):

    @dataclass
    class Ax:
        pass

    @dataclass
    class S:    
        pass
    S.Ax = Ax
    
    # --------------------   Header   --------------------
    nDsc    = ReadDescAttHead( fid );
    S.nTtg  = nDsc;

    #print(nDsc)
    
    # --------------------   Data   --------------------
    aLbGeom = [ 'Les', 'Elo', 'Wide', 'High', 'Rhom',
                'Pllo', 'Tria', 'Irrg', 'PlHor', 'PlVrt',
                'Ger', 'Wth' ]
    aLbLage = [ 'AxVrt', 'AxHor', 'Axial', 'Lean1', 'Lean2',
                'Neig1', 'Neig2' ]
    
    S.GEOM  = ReadStcArr( fid, np.float32, aLbGeom )
    S.LAGE  = ReadStcArr( fid, np.float32, aLbLage )
    S.ANGS  = ReadMtrxDat( fid, np.float32 )
    S.DICV  = ReadMtrxDat( fid, np.float32 )

    # =====   Apnc & Lage   =====
    S.RGB   = ReadAttRgb( fid, nDsc )

    S.Ori   = np.fromfile( fid, dtype=np.float32, count=nDsc)
    S.Pos   = ReadAttPos( fid )
    
    # ---  points of elo-axis
    S.Ax.Ep1 = np.fromfile( fid, dtype=np.float32, count=nDsc*2 )
    S.Ax.Ep2 = np.fromfile( fid, dtype=np.float32, count=nDsc*2 )
    S.Ax.Ep1 = S.Ax.Ep1.reshape((nDsc, 2))
    S.Ax.Ep2 = S.Ax.Ep2.reshape((nDsc, 2))

    # ---  corner points as list
    S.Cop    = ReadDescCor4F( fid )

    S.IxBon = np.fromfile( fid, dtype=np.int32, count=nDsc)  

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int16, count=1)
    assert idf==4444, f"ReadTtrgAtt: trail idf not correct. is {idf}"

    return S, nDsc


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadTtrgSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of contour attributes as saved under TtrgIO.h-w_TtrgSpc

"""
def ReadTtrgSpc( fid ):

    nLev, Nttg = ReadDescSpcHead( fid )

    #print( nLev )
    #print( Nttg )

    ATTG = [None] * nLev
    for l in range( 0, nLev ):

        ATTG[l], nTtg   = ReadTtrgAtt( fid );

    return ATTG, Nttg


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadTtrgBinUni   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

see ReadTtrgBinUni.m
"""
def ReadTtrgBinUni( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    

    S.Geom, szD  = ReadMtrxDat( fid, np.uint8 );
    S.Lage, szD  = ReadMtrxDat( fid, np.uint8 );
    S.Angs, szD  = ReadMtrxDat( fid, np.int8 );
    S.Dicv, szD  = ReadMtrxDat( fid, np.uint8 );

    #print(szD)
    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadTtrgBinSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadTtrgBinSpc( fid ):

    nLev = np.fromfile( fid, dtype=np.int32, count=1 )[0]

    #print( 'TtrgSpc ' + str(nLev) )
    
    @dataclass
    class S:                                    # returning as structure
        pass    

    S.AUNI  = [None] * nLev
    S.APOSA = [None] * nLev
    S.APOSQ = [None] * nLev
    for l in range( 0, nLev ):

        S.AUNI[l]   = ReadTtrgBinUni( fid );

        S.APOSA[l]   = ReadAttPos( fid, datTyp=np.float32 )
        S.APOSQ[l]   = ReadAttPos( fid, datTyp=np.uint8 )

    return S

    
