"""

Organizational routines and variables.

def o_FileExtensions():
def o_FinaApndExtRepFrmt( fist: str, Fixt ) -> dclsFileTypRep:
def o_FinaApndExtDscx( fist: str, instance: dclsFileTypImg ) -> dclsFileTypImg:

"""

from dataclasses import dataclass, fields, replace

# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class dclsFileTypImg:
    """
    The file extensions for image files, descriptors and features.
    """
    # ----- image
    dsc:    str = '.dsc'
    dsbi:   str = '.dsb'
    hsti:   str = '.hst'
      
    kolm:   str = '.kol'      # kolumns
    txtm:   str = '.txm'      # texture maps
    salc:   str = '.slc'      # saliency
    
    qbbx:   str = '.qbbx'     # proposals bbox
    qdsc:   str = '.qdsc'     # proposals descriptors
    
    # ----- descriptors
    rre:    str = '.rre'
    cvpo:   str = '.cvpo'     # curve partitions organization (deployed yet?)
    
    # ----- features
    cuvKpt: str = '.cuvKpt'
    ruv:    str = '.ruv'
    bspx:   str = '.bspx'
    
    bonBbxRaw: str = '.bonBboxRaw'
    bonBbx: str = '.bonBbox'
    bonAsp: str = '.bonAsp'
    
    # ----- shape
    shp:    str = '.shp'
    
    # ----- collection
    collHst: str = '.hstc'    # collHimg
    collSlc: str = '.slcc'    # ???
    hari:    str = '.hari'       # ???
    
    # ----- maps
    mapUch: str = '.mpu'


    
@dataclass
class dclsFileTypFoc:
    """
    The file extensions for focus files
    """
    dscf:  str  = '.dsf'
    hstf1: str = '.hsf1'      # histogram file used by fochst1
    hstfL: str = '.hsfL'
    


@dataclass
class dclsFileTypRep:
    """ Struct holding file extensions for representation formats. Used together with
    the routine extending a name stem with these extensions.
    """
    dsc: str
    hsti: str
    kolm: str
    salc: str

    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FileExtensions   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

File extensions. In analogy to o_FileExtension.m

"""
def o_FileExtensions():

    return dclsFileTypImg, dclsFileTypFoc # both classes are above



""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FinaApndExtRepFrmt   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Appends the extensions for representation formats.

IN   fina   file stem, ie. 'IMGDAT/Collection/Desc/DSC_'
OUT  S      struct with .dsc, .hsti, .kolm

USE  stem     = [pthBas.DescRef 'DSC_' imna.ref];
     Fixt     = o_FileExtensions();
     Lfps     = o_FinaApndExtRepFrmt( stem, Fixt );
     Lfps.dsc, Lfps.hst, ...

"""
def o_FinaApndExtRepFrmt( fist: str, Fixt ) -> dclsFileTypRep:

#    if Fixt is None:
#        Fixt = o_FileExtensions()

    return dclsFileTypRep(
        dsc  = f"{fist}{Fixt.dsc}",
        hsti = f"{fist}{Fixt.hsti}",
        kolm = f"{fist}{Fixt.kolm}",
        salc = f"{fist}{Fixt.salc}"
    )


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FinaApndExtDscx   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Given a filestem fist, it prepends all file extensions, such that the filepath can
be called by field.

USE   FixtImg, FixtFoc  = sbutil.o_FileExtensions()
      fpDSC             = sbutil.o_FinaApndExtDscx( str(pthOut), FixtImg() )
      fpDSC.dsc  is filepath of description file
      fpDSC.salc is filepath of saliency file
      ...

"""
def o_FinaApndExtDscx( fist: str, Fixt: dclsFileTypImg ) -> dclsFileTypImg:

    Sfilepaths = {
        f.name: fist + getattr(Fixt, f.name)
        for f in fields(Fixt)
    }
    return replace(Fixt, **Sfilepaths)

