"""

Sscanf text for NaNs.

cf exsbD2vmx.py

"""
import numpy as np



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   SscanfForFloatWnan   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Parses a textline (character sequence) into floats, replacing non-numeric entries
with NaN.

cf f_SscanfVectMxWithNan below

    Parameters:
    line (str): Input text line
    nexVal (int): Expected number of float entries

    Returns:
    np.ndarray: Array of floats with NaNs where parsing failed

"""
def SscanfForFloatWnan( Lin, nexVal ):

    # Split Lin by whitespace
    aToken  = Lin.strip().split()
    nRead   = len(aToken)

    if nRead != nexVal:
        print("Parsing mismatch:")
        print("aToken:", aToken)
        print("nRead:", nRead)
        print("nExpected:", nexVal)

    # Convert to float with NaN fallback
    Vals = []
    for tkn in aToken:
        
        try:
            num = float(tkn)
            
        except ValueError:
            num = np.nan
            
        Vals.append( np.float32(num) )  # Convert to single precision

    return np.array(Vals, dtype=np.float32)


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_SscanfVectMxWithNan   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

cf exsbD2vmx.py
"""
def f_SscanfVectMxWithNan( aLines, nexAtt ):

    nLin = len(aLines)
    print(f'Sscanfing {nLin} lines')

    VMX  = np.zeros((nLin, nexAtt), dtype=np.float32)

    for i, line in enumerate(aLines):

        #print( line )
        Arr      = SscanfForFloatWnan( line, nexAtt )
        VMX[i,:] = Arr

    return VMX, nLin


