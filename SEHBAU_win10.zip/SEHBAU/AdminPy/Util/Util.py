"""

Utility routines

def get_FinasPatWoExt( dirFina, rex ):
def get_FieldNames( C ):
def del_FilesDirPat( path, pat ):
def del_FilesPat( pat ):
def vrf_PathsExist( P: Paths ) -> None:
def printDotProg( ):

"""

import os
import glob
from pathlib import Path



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   get_FinasPat   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Obtain filenames with regexp pattern. It's a wrapper for glob.glob

"""
def get_FinasPat( dirFina, rex ):

    aLst  = glob.glob( os.path.join( dirFina, rex ) )

    return aLst


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   get_FinasPatWoExt   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Obtain filenames with regexp pattern and return them without extension.

"""
def get_FinasPatWoExt( dirFina, rex ):

    # List the files
    aLst  = glob.glob( os.path.join( dirFina, rex ) )

    # Extract base filenames without extension
    aNam  = [ os.path.splitext( os.path.basename(p) )[0] for p in aLst ]

    return aNam



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   get_FieldNames   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Obtain the fieldnames from a struct

https://stackoverflow.com/questions/11637293/iterate-over-object-attributes-in-python

"""
def get_FieldNames( C ):

    aFn = [a for a in dir( C ) if not a.startswith('__')]

    return aFn



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   del_FilesDirPat   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Delete files by providing directory and regular expression pat.

"""
def del_FilesDirPat( path, pat ):

    #input( 'Deleting files in ' + str(path) + pat + '   pausing. (hit key to continue)' )
    
    for file in Path(path).glob(pat):
        file.unlink()        


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   del_FilesPatOs   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Delete files with regular expression pat using os.

Im not sure whether this is compatible with any OS

"""
def del_FilesPatOs( pat ):

    input( 'Deleting files in ' + str(pat) + '   pausing. (hit key to continue)' )
    
    for file in glob.glob( pat ):
        os.remove(file)


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   del_FilesPat   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Delete files with regular expression pat using string or path

Delete files matching a glob pattern using pathlib.
Waits for user confirmation before proceeding.

IN    pat : str | Path
      The file path pattern (can include wildcards, e.g. '*.txt' or 'data/**/*.csv')

"""
def del_FilesPat(pat: str | Path) -> None:

    pat = Path(pat)

    # Show where the deletion will occur
    print(f"Deleting files matching pattern: {pat}")
    #input("Press ENTER to continue or Ctrl+C to abort...")

    # -----  perform recursive glob if the pattern includes '**'
    if "**" in str(pat):
        aFiles = list(pat.parent.rglob(pat.name))
    else:
        aFiles = list(pat.parent.glob(pat.name)) if pat.parent.exists() else []

    if not aFiles:
        print("No files found.")
        return

    print(f"Found {len(aFiles)} file(s) to delete:")
    for f in aFiles:
        print(f"  {f}")

    # Final confirmation
    confirm = input("Type 'yes' to confirm deletion: ").strip().lower()
    if confirm != "yes":
        print("Deletion cancelled.")
        return

    # Delete files
    for f in aFiles:
        try:
            f.unlink()
            print(f"Deleted: {f}")
        except Exception as e:
            print(f"Could not delete {f}: {e}")

    print("Done.")        


""" VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV   vrf_PathsExist   VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

Verifies that filepaths exist (of a dataclass)

v_PathsExistsStruct.m

"""
def vrf_PathsExist( P ) -> None:

    for attr, path in vars(P).items():

        if isinstance( path, Path ) and not path.exists():

            path.mkdir( parents=True, exist_ok=True )
        

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   printDotProg   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Print a progress dot.

"""
def printDotProg( ):

    print('.', end='', flush=True)
        
        
