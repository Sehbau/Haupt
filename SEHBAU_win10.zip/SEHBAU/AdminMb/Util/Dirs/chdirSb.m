function [] = chdirSb()
    chdir('c:/klab/ppc/SEHBAU/');
end

