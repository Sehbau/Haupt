%
% Turns slashes to backslashes in a path. For windows OS.
%
% This is necessary only for program execution (of a binary) or when
% writing to a file. (not necessarily for reading file)
%
function pth = u_PathToBackSlash( pth )

IxSlash     	= strfind( pth,'/');
pth(IxSlash)    = '\';

end

