%
% Turns a data matrix [nObs nFet] into a struct of arrays (SoA) given
% fieldnames in aFldNames. If fieldnames are given as a single string then
% use u_AttLabArrToList to turn them into a list.
%
% cf u_DescMxToStcOfArr
% sa o_AttsLabels.m
%
% (( deprecated: see u_AttsArrToStruct for case when field labels are given
% as a string. ))
%
% IN   MX         matrix, e.g [nDsc nAtt]
%      aFldNames  attribute names, ie. 'Vrt', 'Hor', ...
% OUT  S          struct with fields .Vrt, .Hor, ...each one [nDsc 1]
%
function [S] = u_MtrxToStcArr( MX, aFldNames )

[nObs nFet] = size(MX);

nFlds       = length(aFldNames);
    
assert( nFlds==nFet, 'nFeatures not matching: %d <> %d', nFlds, nFet );

% capitalize 1st letter
for f = 1:nFlds
    name        = aFldNames{f};
    name(1)     = upper(name(1));
    aFldNames{f} = name;
end

%% ----------   Conversion to SoA   --------------    
S = struct;
for i = 1:nFlds
    S.( aFldNames{i} ) = MX(:,i);
end

end

