%
% Reads a struct-of-arrays that had been saved as data matrix.
% 
% ai ReadShpAtt
%
function [S szD] = ReadStcArrFlt( fid, conversion, aFieldNames )
error('deprecated');
% first load as data matrix
[S szD]     = ReadMtrxDat( fid, conversion );

% now turn into a struct-of-array
S           = u_MtrxToStcArr( S, aFieldNames );

end

