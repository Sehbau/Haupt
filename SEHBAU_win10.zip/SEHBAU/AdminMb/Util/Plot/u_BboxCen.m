%
% Calculates bounding box center
%
% sa p_BoundBoxPyr1Lv
%
function [C] = u_BboxCen( ABBox )

C.Rw   = ( ABBox(:,1) + ABBox(:,2) ) / 2;
C.Cl   = ( ABBox(:,3) + ABBox(:,4) ) / 2;

end

