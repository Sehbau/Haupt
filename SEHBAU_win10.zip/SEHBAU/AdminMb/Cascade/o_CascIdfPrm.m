%
% Parameters for cascade identifier in CASCIDF.m
%
function [P] = o_CascIdfPrm( nImg, prpPre, stgy, txtgTyp )

if nargin==1
    prpPre  = 0.5;
    stgy    = 'hist1st';        % histogram first
end
if nargin==2
    stgy    = 'hist1st';        % histogram first
end

P.stgy          = stgy;         % preselection strategy
P.prpPre        = prpPre;
P.nPre          = round ( nImg * prpPre );
P.nImg          = nImg;
P.mesFull       = 1;

% ----- texturegrams
if nargin<4
    txtgTyp = 'Grid';
end
P.txtgTyp       = txtgTyp;

Prm.WgtTxg      = o_WgtTxtrMtch();




