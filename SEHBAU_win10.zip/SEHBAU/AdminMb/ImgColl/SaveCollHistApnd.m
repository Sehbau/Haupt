%
% Appends to a collection matrix, that was initialized with
% SaveCollHistInit.m
%
% cf ICL_COLLFBRCHYKO.m
%
function [] = SaveCollHistApnd( Mx, sfp )

fid     = fopen( sfp, 'ab');

if fid==0
    error('Could not open %s\n', sfp); 
end

fwrite( fid, Mx(:), 'int32' );   

fclose(fid);

end

