%
% Collecting fabric kolumns for a list of images.
%
% cf iclCollFbrcHyko.m
% af ICL_DBIN.m
%
% IN  fipaExe    filepath of executable
%     IxImg      list of indices
%     Fina1      struct with filestems as for example in o_FileStems.
%     FixtImg    file extensions
%     finaFrmt   format of filename, see o_FileNameFrmt
%     FinaColl   filenames with o_FileNameColl
%
function [ ] = ICL_COLLFBRCHYKO( fipaExe, IxImg, Fips1, FixtImg, ...
                                 finaFrmt, FinaColl )

%% -------------   Arguments   -----------
if exist( fipaExe, 'file')==2,
    error('Program path not correct: %s', fipaExe );
end

%% -------------   LOOP LIST   -----------
nImg    = length(IxImg);

for i = 1:nImg,     

    ixi     = IxImg(i);
    
    pthFbrc = o_FileNameFrmt( Fips1.fbrc, ixi, '', finaFrmt );
    
    % ----------   Execute   ------------
    cmnd    = [ fipaExe ' ' pthFbrc FixtImg.fbrc ' .\tmp' ];

    bTryDebug = 0; % geht gar nicht mit diesem Program
    StdOut  = f_CmndExec( cmnd, bTryDebug );
    
    if ixi==IxImg(1), 
        pso_OptUnrec(StdOut); 
        StdOut
    end
    
    if mod(i,round(nImg/40))==0, fprintf('.'); end  % progress dots
    
    % ----------   Load   ----------
    K0 = LoadCollHist( ['tmp' FixtImg.fbArK0], i==1 );
    K1 = LoadCollHist( ['tmp' FixtImg.fbArK1], i==1 );
    K2 = LoadCollHist( ['tmp' FixtImg.fbArK2], i==1 );
    K3 = LoadCollHist( ['tmp' FixtImg.fbArK3], i==1 );
    
    % transpose from col-major to row-major (only Matlab) 
    K0 = K0';
    K1 = K1';
    K2 = K2';
    K3 = K3';

    % ---------------   Append to Collection   --------------------
    % -----  init before 1st image  -----
    if i==1
        % according to s_CollHistInit in CollHistIO.h
        SaveCollHistInit( nImg, numel(K0), FinaColl.fbk0 );
        SaveCollHistInit( nImg, numel(K1), FinaColl.fbk1 );
        SaveCollHistInit( nImg, numel(K2), FinaColl.fbk2 );
        SaveCollHistInit( nImg, numel(K3), FinaColl.fbk3 );
    end
    
    % -----  append  -----
    SaveCollHistApnd( K0, FinaColl.fbk0 );
    SaveCollHistApnd( K1, FinaColl.fbk1 );
    SaveCollHistApnd( K2, FinaColl.fbk2 );
    SaveCollHistApnd( K3, FinaColl.fbk3 );
    
    %pause();
    
end
fprintf('%d-%d done\n', IxImg(1), IxImg(end));

end

