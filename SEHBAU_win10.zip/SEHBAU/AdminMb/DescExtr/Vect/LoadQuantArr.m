%
% Loads an array of quant values. Values can be codes (collecting mode) or
% indices pointing to a dictionary (dictionary mode).
% 
% cf iclQntVoc.m, plcQntVoc.m
%
% USE  
%      lfn         = [ pthOut Fixt.qntDix dty ];
%      [Dix Hed]   = LoadQuantArr( lfn );

function [A H] = LoadQuantArr( lfn ) 

fid	= fopen(lfn, 'rt');
if (fid<0), error('file %s not found', lfn); end

% ------------   Head   --------------
H.nQnt      = fscanf( fid, '%d', 1 );   % number of quants
H.dimOrg    = fscanf( fid, '%d', 1 );   % original (full) dimensionality
H.dimSus    = fscanf( fid, '%d', 1 );   % subspace dimensionality
H.mxV       = fscanf( fid, '%d', 1 );   % max code value

% ------------   Data   --------------
A   = fscanf( fid, '%d', H.nQnt );      % the values (code | index)

A   = int32( A );

fclose(fid);


