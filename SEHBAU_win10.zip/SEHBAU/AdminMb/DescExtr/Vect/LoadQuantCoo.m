%
% Same as LoadQuantArr.m but loading also coordinates.
%
% cf evsbTxtra.m
%
function [S H] = LoadQuantCoo( lfn ) 

fid	= fopen(lfn, 'rt');
if (fid<0), error('file %s not found', lfn); end

% ------------   Head   --------------
H.nQnt      = fscanf( fid, '%d', 1 );   % number of quants
H.dimOrg    = fscanf( fid, '%d', 1 );   % original (full) dimensionality
H.dimSus    = fscanf( fid, '%d', 1 );   % subspace dimensionality
H.mxV       = fscanf( fid, '%d', 1 );   % max code value

% ------------   Data   --------------
Vl      = fscanf( fid, '%d', H.nQnt );  % the values (code | index)
Rw      = fscanf( fid, '%d', H.nQnt );  % row coordintes
Cl      = fscanf( fid, '%d', H.nQnt );  % col coordintes

S.Vl    = int32( Vl );
S.Rw    = int32( Rw );
S.Cl    = int32( Cl );

fclose(fid);


