%
% Loads space of boundary pixels, as saved under
% B_BON/Util/BonIO.h-s_BonPixPyr()
%
function [APIX J] = LoadBonPixSpc(lfn, bDisp ) 

if nargin==1
    bDisp = 0;
end

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----  nLev
%nLev  = fread(fileID, 1, 'int=>single');

nLev  = fread(fileID, 1, 'uint8=>single');

NbonH = fread(fileID, nLev, 'int=>single');

% fprintf('%d %d\n', nLev, NbonH );

if bDisp, fprintf('[nLev %d] \n', nLev); end

%% =====  Space
APIX    = cell(nLev,1);
J.Nbon  = zeros(nLev,1);
J.SzM   = zeros(nLev,2);
J.AOrg  = cell(nLev,1);
for l = 1:nLev

    [APix nBon szM Org] = ReadBonPixSegw( fileID, bDisp );
    
    APIX{l}     = APix;
    J.Nbon(l)   = nBon;
    J.SzM(l,:)  = szM;
    J.AOrg{l}   = Org;
    
end

id = fread(fileID, 1, 'int=>single');

fclose(fileID);

assert(id==333);

%fprintf('\n');

