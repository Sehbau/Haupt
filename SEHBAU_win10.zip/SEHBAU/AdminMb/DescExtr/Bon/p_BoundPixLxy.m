%
% Plots a list of boundaries in xy format. 
% 
% Row coordinates are inverted in loop here.
%
% IN    APix    a cell of boundaries
%       szV     vertical image size
%       col     color
%       liwiAnf linewidth Anf?
%
function [] = p_BoundPixLxy( APix, szV, col, liwiAnf )

nBon = length(APix);

bJit = 0;
ctr  = 0;
if nargin==4
    ctr = 1;
end

for b = 1:nBon

    Pix    = APix{b};

    % uninvert row axis (p_BoundPix1 plots inverted)
    Pix.Rw = szV - Pix.Rw; 

    if ctr==0
        p_BoundPix1ToPlot( Pix, szV, col, bJit, ctr );
    else
        ctr = liwiAnf-2*b;
        p_BoundPix1ToPlot( Pix, szV, col, bJit, ctr );
    end
end


end

