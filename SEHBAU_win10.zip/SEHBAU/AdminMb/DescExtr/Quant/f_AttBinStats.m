%
% Attributes statistics for its bins
%
% Bin-vectors were collected in f_CollBinDty.m
% 
% IN    BIN   matrix of bin-vectors [ntVec nBin]
% OUT   S     struct 
%
function S = f_AttBinStats( BIN, dtyS, Lb )

[ntV nAtt]  = size( BIN );

fprintf('Stats %s:\t', dtyS );
assert( nAtt==length(Lb) );

%% --------   Stats   ---------
MxvPerAtt   = max( BIN,[],1 );
mxtBin      = max( MxvPerAtt );

fprintf('mxt %2d\t', mxtBin);

BtooLrg     = MxvPerAtt>50;
if any(BtooLrg)
    MxvPerAtt
    warning('unusually high value detected');
end

%% --------   NoVals   --------
Bzero       = MxvPerAtt==0;
IxZero      = find( Bzero );
nZer        = length(IxZero);
if nZer

    fprintf('NO VALS: ');
    
    for z = 1:nZer
        fprintf('%s ', Lb{ IxZero(z) } );
    end
end    

%% --------   A2S   --------
S.IxNoVals  = IxZero;
S.mxtBin    = mxtBin;

fprintf('\n');

end






