%
% Loads the quant hash info as saved under plcCollVecBin.m.
%
% cf plcQntHist.m
%
function [QUNV Nqnt] = LoadQuantDtys( pthQnt, Fext )

nDty    = length( Fext.aVbn );

QUNV       = struct;
for d = 1 : nDty

    dty     = Fext.aVbn{d}(4:end);
    
    lfn     = sprintf('%sQNT_%s', pthQnt, dty );

    if exist( [lfn '.mat'], 'file' )==0
        fprintf('Did not find quants for %s\n', dty);
        lfn
        continue;
    end
    
    load( lfn );
    
    QUNV.(upper(dty)) = QNT;

    Nqnt.(dty) = QNT.nQnt;

    DispLoad( lfn );
    
end



end

