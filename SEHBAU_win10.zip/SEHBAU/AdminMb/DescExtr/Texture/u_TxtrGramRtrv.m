%
% Retrieves texturegrams from loaded data structure and overwrites the
% original format.
%
% cf exsbTxtrMaps.m
% 
% IN    Tgm     texturegram structure as loaded by LoadDescSalc.m
%       szG     size of the grid (is in header of saliency file)
%       aLb     array of labels
%
function [Tgm] = u_TxtrGramRtrv( Tgm, szG, aLb )

Tgm.Bvrt    = u_MtrxToStcArr( Tgm.Bvrt, aLb );
Tgm.Bhor    = u_MtrxToStcArr( Tgm.Bhor, aLb );

Tgm.Grid    = u_MtrxToStcArr(   Tgm.Grid, aLb );
Tgm.Grid    = u_StcArrToStcMap( Tgm.Grid, szG );

end

