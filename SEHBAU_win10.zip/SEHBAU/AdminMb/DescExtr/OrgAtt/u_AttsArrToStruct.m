%
% Turns an array of attributes Arr [nDsc nAtt] into a struct with fields
% as specified by aAttNames.
%
% sa o_AttsLabels.m
% ai cc_ovoT.m, f_Shp
%
% NOT WELL ORGANIZED: better use u_MtrxToStcArr
%
% IN   Arr        [nDsc nAtt]
%      aAttNames  attribute names, ie. 'Vrt', 'Hor', ...
% OUT  S          struct with fields .Vrt, .Hor, ...each one [nDsc 1]
%
function [S] = u_AttsArrToStruct( ARR, aAttNames )

error('deprecated: use u_MtrxToStcArr');

[nDsc nAtt]   =  size(ARR);
[nFld lenFld] = size(aAttNames);

%% -------   Change Labels from Char to List   --------
if lenFld==6
    % old method: better use
    aAttTxt   = aAttNames;
    aAttNames = cell(nFld,1);
    for f = 1:nFld
        lab  = aAttTxt(f,:);
        Bspc = isspace( lab );
        lab  = lab( ~Bspc );
        aAttNames{f} = lab;
    end
elseif iscell( aAttNames )
    nFld = length( aAttNames );
    % capitalize 1st letter
    for f = 1:nFld
        name    = aAttNames{f};
        name(1) = upper(name(1));
        aAttNames{f} = name;
    end
end

assert( nAtt==nFld, 'nAtts/nFlds not matching: %d <> %d', nAtt, nFld );


%% --------    Matrix to List   ----------
% better deploy u_MtrxToStcArr
S = struct;
for i = 1:nFld
    % aAttNames{i}
    S.( aAttNames{i} ) = ARR(:,i);
end
    
end

