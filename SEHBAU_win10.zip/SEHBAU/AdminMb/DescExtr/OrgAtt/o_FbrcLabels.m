%
% Fabric biases. 
% 
% They must match with CntTxtAnf.h, w_CntTXTbis (CntTxtIO.h)
%
% Their color code for plotting is in u_ColBlob.m
%
function [aLsho nBis aLlon] = o_FbrcLabels( )

% VH12ANU
%            1     2     3     4     5     6     7     8     9
aLsho   = {'Vrt' 'Hor' 'Dg1' 'Dg2' 'Axi' 'Nil' 'Uni'};

nBis    = length( aLsho );

aLlon   = { 'Vertical' ...
            'Horizontal' ...
            'Diagonal 1' ...
            'Diagonal 2' ...
            'Axial (vrt&hor)'...
            'Nil (no ori)' ...
            'Uni (1 ori)' };
        

end 

