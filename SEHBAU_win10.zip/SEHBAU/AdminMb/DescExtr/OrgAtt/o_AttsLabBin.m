%
% Attribute names (labels) for a bin-vector. See o_AttsLabels for
% float-vector and more info.
%
% cf LoadDescVect.m, LoadCollVec.m
%
% Elsewhere:
% - o_AttsLabels for analog values
% - o_QntSubSpcLab for subspace labels
% - f_AttSpcSub for subspace selection
%
function [LB Lshp] = o_AttsLabBin()

LbPos   = { 'psv' 'psh' };
LbRgb   = { 'red' 'grn' 'blu' };

%% ----------   contour   ---------  6
% wt_CntVbn, CntIObin.h
LB.Cnt  = {'len' 'str' 'ori' 'red' 'grn'   'blu' 'psv' 'psh'};
LB.Skl  = LB.Cnt;

%% ----------   radial signature   ----------  4 + 3 + 6
% wt_RsgVbn, RsgIObin.h
%  int  **Adr[nFld] = {  &Rds,  &Elo,  &Cir,  &Ori,  &Bulk, 
%                        &Bis1, &Bis2, &Bis3, &Bis4, &Bis5  };  
LbRdGeo = {'rad' 'elo' 'cir' 'ori' 'blk' ...
           'bs1' 'bs2' 'bs3' 'bs4' 'bs5' };
%LB.Rsg = {'rad' 'elo' 'cir' 'ori' 'red'   'grn' 'blu' 'ccv' };

StA ='AreN  HgtN  WthN  High  Wide  Higv  Widv  RtAre Axial Diamo Diag1 Diag2 EloSg EloRd Steh  Lieg  ';      
StEk='EkTL  EkTT  EkTR  EkRR  EkBR  EkBB  EkBL  EkLL  ';

LB.RsgSet.RospA = u_AttLabArrToList( StA );
LB.RsgSet.RoEck = u_AttLabArrToList( StEk );

LB.Rsg  = ...
    [ LbRdGeo(:); LB.RsgSet.RospA(:); LB.RsgSet.RoEck(:); ...
      LbRgb(:); LbPos(:) ];

%% ----------   arc   ---------  10
% wt_ArcVbn, ArcIObin.h
% int  **Adr[nFld] = {
%         &Les, &Krv, &Dir, &Spz, &Eck,   &Run, &Ifx, &Red, &Grn, &Blu };  
LB.Arc = {'les' 'krv' 'dir' 'spz' 'eck'   'run' 'ifx' 'red' 'grn' 'blu' ...
          'psv' 'psh'};


%% ----------   str   ---------  6
% wt_StrVbn, StrIObin.h
% int  **Adr[nFld] = {  &Les, &Str, &Ori, &Red, &Grn, &Blu };  

LB.Str = {'les' 'str' 'ori' 'red' 'grn' 'blu' 'psv' 'psh'};
        
%%  ---------    bndg   ---------  10      
LB.Bndg = {'len' 'agx' 'tig' 'dns' 'ori'   'vpo' 'hpo' 'red' 'grn' 'blu'};
      
%% ----------   shape   ---------   ShpAbstAtts.h

% ------ abnShpStrOri, ia Scors
StA = 'Vrt   Hor   Dg1   Dg2   Axi   Adg   Vab   Hab   Dab   Tri   Nil   ';
Lshp.Scors = u_AttLabArrToList( StA );

% ------ abnShpStrFin, ia Sfine
StA = 'Vrt   Hor   Vti   Hti   Vob   Hob   Dg2   Dg1   Axi   Uni   Dul   Cvg   Agx   Ori   Nil   Dre   Vir   Fnf   ';
Lshp.Sfine = u_AttLabArrToList( StA );

% ------ attsShpRadSeg, ia Ras
StA = 'Rad   Elo   Ron   Riss  SteUgfSteEngSteDowSteUppOpnDowOpnUpwLigUgfLigEngLigDowLigUppOpnRitOpnLef';
Lshp.Ras = u_AttLabArrToList( StA );
 
% ------ abnShpAuto
StA = 'SprA  SprS  Prx   Etg   Ort   Gri   Rbns  ';
Lshp.Auto = u_AttLabArrToList( StA );

%Lshp.Gol = {'rib' 'ori' 'elo' 'agx'};

%LbsGen = {'vpo' 'hpo' 'red' 'grn' 'blu'};
%LB.Shp = [ Lshp.Scors(:); LbsGen(:) ];
%LB.Shp = [ Lshp.Scors(:); Lshp.Sfine(:); Lshp.Ras(:); LbsGen(:) ];
LB.Shp = [ Lshp.Scors(:); Lshp.Sfine(:); Lshp.Ras(:); Lshp.Auto(:); LbPos(:)];
            %LbsGen(:) ];
%LB.Shp = {'vrt' 'hor' 'dg1' 'dg2' 'axi' 'vpo' 'hpo' 'red' 'grn' 'blu'};


%% ----------   tetragon   ---------   
aLbGeom = { 'Les'   'Elo'    'Wide'   'High'    'Rhom'  ...
            'Pllo'  'Tria'   'Irrg'   'PlHor'   'PlVrt' ...
            'Ger'   'Wth'
            };
aLbLage = { 'AxVrt'  'AxHor'   'Axial'   'Lean1'  'Lean2'   ...
            'Neig1'  'Neig2'
            };
        
aLbUtil = { 'ori' 'vpo' 'hpo'};

LB.Ttrg = [ aLbGeom(:); aLbLage(:); aLbUtil(:) ];

%% ------------   DOUBLES   ---------------
LB.Ttg  = LB.Ttrg;
LB.Bnd  = LB.Bndg;

%% ------------------------   Num of Labels   ----------------------
if 0
    aFldNas     =  fieldnames(LS);
    for f = 1:length(aFldNas)
        
        fl       = aFldNas{f};
        fln      = ['n' fl];
        aLabs    = LS.(fl);
        nAtt     = length( aLabs );
        
        LS.(fln) = nAtt;
    end
end



end % MAIN

