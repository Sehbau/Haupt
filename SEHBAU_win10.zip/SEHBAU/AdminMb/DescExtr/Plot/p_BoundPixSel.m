%
% Plots boundaries according to selected thresholds in Edg for attribute 
% Att with color taken from palette Pal.
%
function [] = p_BoundPixSel( Pset, Att, Edg, Pal )

% non-selected boundaries into background
colBack = [190 190 190] / 255;

Bnon    = Att < Edg(1);
p_BoundPixLij( Pset.ABonLv( Pset.IxBon(Bnon) ), colBack );  

nBin    = length(Edg) - 1;

for t = 1:nBin
    
    Bsel = (Att >= Edg(t))  &  (Att < Edg(t+1));
    
    p_BoundPixLij( Pset.ABonLv( Pset.IxBon(Bsel) ), Pal(t,:) );  
    
end

end

