%
% Plots the texturegrams into one figure.
%
% sa p_TxtrBandHist.m, PlotTxtrGrids.m
%
% IN    GM      grid as loaded with LoadDescSalc.m
%
function [] = PlotTxtrGrams( TXM, GRM, figNo, Irgb, aLb )

nLab   = length( aLb );

%% ---------   Max for each Band   -----------
MxV     = zeros(nLab);
for b = 1:nLab
    lb      = aLb{b};
    MxV(b)  = max( [GRM.Bvrt.(lb)(:); GRM.Bhor.(lb)(:) ] );
end

%% --------------------   Plot   --------------------
figure(figNo); clf;
[nr nc] = deal(nLab+1,4);

subplot(nr,nc,1);
imagesc( Irgb );
set(gca,'fontsize',5);

for b = 1:nLab

    lb      = aLb{b};
    mxN     = MxV(b)*1.05;
    
    ixL     = b*4+1;
    
    % --------   LEFT COL: Texture Map   ---------
    subplot( nr,nc, ixL );
    if b<3
        imagesc( TXM.KNT.(lb) ); 
    else
        imagesc( TXM.OTX.(lb) ); 
    end
    set( gca, 'fontsize', 5);
    ylabel( lb, 'fontsize', 12 );
    %colorbar;
    
    % --------   2ND COL: Grid Map   ---------
    subplot( nr,nc, ixL+1 );
    imagesc( GRM.Grid.(lb) ); 
    colorbar;
    set( gca, 'fontsize', 6);
    if b==1
        title( 'Grid', 'fontsize', 12 );
    end
    
    % --------   3RD COL: band vrt  ---------
    subplot( nr,nc, ixL+2 );
    bar( GRM.Bvrt.(lb) );

    set( gca, 'ylim', [0 mxN] );
    set( gca, 'xlim', [0.5 5.5] );
    set( gca, 'fontsize', 8);
    if b==1
        title( 'Vertical', 'fontsize', 12 );
    end
    if b==nLab
        set( gca, 'xticklabel', {'left' '.' 'cen' '.' 'right'} );
    end
    
    % --------   RITE COL: band hor   ---------
    subplot( nr,nc, ixL+3 );
    bar( GRM.Bhor.(lb) );

    set( gca, 'ylim', [0 mxN] );
    set( gca, 'xlim', [0.5 5.5] );
    set( gca, 'fontsize', 8);
    if b==1
        title( 'Horizontal', 'fontsize', 12 );
    end
    if b==nLab
        set( gca, 'xticklabel', {'top' '.' 'cen' '.' 'bottom'} );
    end
    
end


end

