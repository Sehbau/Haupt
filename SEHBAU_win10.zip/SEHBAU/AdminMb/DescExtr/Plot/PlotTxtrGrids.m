%
% Plots the texture grids into one figure.
%
% IN    GM      grid as loaded with LoadDescSalc.m
%
function [] = PlotTxtrGrids( GM, figNo, Irgb, aLb )

figure(figNo); clf;
[nr nc] = deal(3,3);

subplot(nr,nc,1);
imagesc( Irgb );
set(gca,'fontsize',5);

nBand   = length( aLb );

for b = 1:nBand

    lb      = aLb{b};
    
    subplot(nr,nc,1+b);
    imagesc( GM.(lb) ); title( lb );
    colorbar;
end


end

