%
% Plots the bounding boxes for the blobs.
%
function [] = p_BlobBboxes( Blb )

% LS      = {'Num' 'Blk' 'Nil' 'Vrt' 'Hor' 'Axi' 'Uni'};

%    Col(1,:) = [255 255   0]; % yellow
%    Col(2,:) = [255 128   0]; % orange
%    Col(3,:) = [191 191   0]; % beige
%    Col(4,:) = [255 0     0]; % rot
%    Col(5,:) = [170 0   255]; % magenta
%    Col(6,:) = [0   255 255]; % cyan
%    Col(7,:) = [0   0   255]; % blue
%    Col(8,:) = [255 255 255]; % white
%              red grn blu
Col(1,:)    = [1   1   1];  % numerous
Col(2,:)    = [0   0   0];  % blank
Col(3,:)    = [0   1   0];  % nil   - green
Col(4,:)    = [1   1   0];  % vertical - yellow
Col(5,:)    = [0   0   1];  % horizontal - blue
Col(6,:)    = [0   1   1];  % axial
Col(7,:)    = [0.7 0.7 0.7];  % uni
Col(8,:)    = [1   0   0];  % kenergy red


for t = 1:8

    Btyp    = Blb.Typ==t; 

    p_BboxL( Blb.Box( Btyp, :), Col(t,:) );

end

