%
% Plots boundaries of form description.
%
% fka p_RsgPix
%
% IN   FRM   form descriptor
%      aBon  ALL boundaries in segment-wise organization, ie. u_BonPixBlokToList
%
function [] = p_FormBoundPix( FRM, aBon, typ ) 

gry     = 0.8;

for i = 1:FRM.nRsg


    colBon  = ones(1,3) * gry;
    colPol  = ones(1,3);
    liwi    = 1;
    
    cir     = FRM.RdSig.Cir(i);
    elo     = FRM.RdSig.EloR(i);

    if strcmp(typ, 'nofet'), % ------------   no feature   ------------
        % do nothing
    elseif strcmp(typ, 'cir'), % ------------   circular   ------------

        if cir>0.15

            gb     = max( gry-cir, 0);
            colBon = [ gb + tanh(cir)*1.3  gb  gb ];
            colPol = [1 0 0];
        
            plot( FRM.Pol.Hor(i), FRM.Pol.Vrt(i), '.', 'color', colPol );
        end
        
    elseif strcmp(typ, 'elo'), % ------------   elo   ------------
        
        if elo>0.75

            gb     = max( gry-elo, 0);
            colBon = [ gb + tanh(elo)*1.25  gb  gb ];
            %colBon
            colPol = [1 0 0];
        
            plot( FRM.Pol.Hor(i), FRM.Pol.Vrt(i), '.', 'color', colPol );
        end
       
    else
        error('typ %s not implemented', typ);
    end
    
    ixBon   = FRM.IxBon1(i);
    bJit    = 0; % 0.5;
    p_BoundPix1ToImg( aBon{ixBon}, colBon, liwi, bJit );
    
end    
