%
% Descriptor correspondence. Plots line between points in A and nearest
% neighbors of B, given indices in NN.
%
% Assumes that descriptors of A have been plotted already in left half E
% [0,1] and those of B in right half [1,2]. And that position of B are
% already shifted by value one to right half.
%
% IN    A, B    positions of A (left) and B (right)
%       NN      NN indices with list length of A, pointing to B
%
function [] = p_DescCorresp( A, B, NN ) 


