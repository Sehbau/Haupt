%
% Connects a series of points representing a quasi visual search.
%
function [] = p_VisSearch( Loc, colLine, colStart )

if nargin==1
    colLine  =  [100 100 0]/255;        % pale yellow
    colStart = 'r';                     % red starting point
end

nLoc    = size(Loc,1);

if nLoc==0, 
    %    fprintf('p_VisSearch: no points\n'); 
    return; 
end

Rw      = Loc(:,1);
Cl      = Loc(:,2);

plot(Cl, Rw,  'marker','.',  'color', colLine);

plot(Cl(1),   Rw(1),   [colStart '*'], 'markersize', 5); % red star is starting point 
plot(Cl(end), Rw(end), 'g.', 'markersize', 5);

end

