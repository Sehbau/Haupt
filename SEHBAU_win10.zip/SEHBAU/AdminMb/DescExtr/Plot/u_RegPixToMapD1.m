%
% Places region pixels for one depth (of one level) into both a gray-map
% and an RGB map.
% 
% cf PlotRegPix.m
%
% IN   REG    region structure, as loaded with ReadRegPixBlok.m
%      szM    size map
% 
function [Mgry Irgb] = u_RegPixToMapD1( REG, szM )

[szV, szH]   = deal( szM(1), szM(2) );

nCC     = REG.nCC;
nPxMap  = szV*szH;

% --- init dimension as in C
Mgry   = zeros( szH, szV, 'uint8');
Irgb   = zeros( szH, szV, 3, 'uint8');

for c = 1:nCC
    
    anf     = REG.Anf(c);         % starting index
    trm     = REG.Anf(c+1)-1;     % terminating index
    %fprintf('%d-%d  %d\n', anf, enf, enf-anf );
    
    red     = REG.RGB(c,1);
    grn     = REG.RGB(c,2);
    blu     = REG.RGB(c,3);
    
    gry     = red*0.2989 + grn*0.5870 + blu*0.1140;
    
    % ----  Mgry:
    Mgry( REG.IxLin( anf:trm ) ) = gry;
    
    % ----  Irgb: we add color
    Irgb( REG.IxLin( anf:trm ) )            = uint8(red);
    Irgb( REG.IxLin( anf:trm ) + nPxMap )   = uint8(grn);
    Irgb( REG.IxLin( anf:trm ) + nPxMap*2 ) = uint8(blu);
    
end    
   
% flip & rotate from C to matlab
Mgry    = flipud( Mgry' );       
Irgb    = rot90( Irgb );

end