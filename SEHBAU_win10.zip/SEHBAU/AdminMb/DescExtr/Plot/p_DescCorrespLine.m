%
% Descriptor correspondence. Plots line between points in A and nearest
% neighbors of B, given indices in NN.
%
% Assumes that descriptors of A have been plotted already in left half E
% [0,1] and those of B in right half [1,2]. And that position of B are
% already shifted by appropriate value (1 if unit, szM(2) if pixel
% coordinates) to right half.
%
% IN    A, B    positions of A (left) and B (right)
%       NN      NN indices with list length of A, pointing to B
%
function [] = p_DescCorrespLine( A, B, NN, height ) 

if nargin==3
    height = 1;
end

%p_PosVH( A, 'c');
%p_PosVH( B, 'm');
bReportZeroIx = 1;
cNoNN = 0;
for i = 1:NN.nDsc
    
    if NN.Mes(i) > NN.menMes*0.8, 
        continue;               % skip loose matches
    end 
    
    v1 = A.Vrt(i);
    h1 = A.Hor(i);
    
    ix = NN.Ix(i);
    
    if ix==0, 
        cNoNN = cNoNN + 1;
        continue; 
    end
    
    v2 = B.Vrt(ix);
    h2 = B.Hor(ix);
        
    hl = line( [ h1 h2 ], [ v1  v2 ] );
    %hl = line( [ h1 h2 ], [ height-v1  height-v2 ] );
    
    set( hl, 'color', 0.7 + rand(1,3)*0.2 );
    set( hl, 'linestyle', '--' );
    
end

if bReportZeroIx > 0  &&  cNoNN > 0
    fprintf('cNoNN %3d/%3d [%1.3f] \n', ...
        cNoNN, NN.nDsc, single(cNoNN)/single(NN.nDsc) );
end