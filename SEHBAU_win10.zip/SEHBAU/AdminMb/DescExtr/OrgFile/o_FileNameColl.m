%
% Filepaths/stems/names of collected description.
%
% USE 1
%      [dmy, FistColl] = o_FileNameColl();  will return only default filestems
% USE 2 
%      [Pths Jcoll]    = u_CollPaths( dbas );
%      Fixt            = o_FileExtensColl();
%      [FinaColl FistColl] = o_FileNameColl( Pths.coll, FixtColl );
%
% IN   pthColl     to be prepended
%
function [P S] = o_FileNameColl( pthColl, Fixt, fidf, loc )

% filestems (wo path)
S.hist      = 'HST_ATT'; % binary file created in Sb
S.txtr      = 'TXTR';    % binary file created in Sb
S.fbrc      = 'FBRC';    % fabric
S.qust      = 'HST_QNT'; % quistogram? mat file

if nargin==0, 
    P = [];
    return; 
end

if nargin>2

    if nargin==3 || strcmp( loc, 'pre' ) % prefix
        S.hist      = [fidf S.hist]; 
        S.txtr      = [fidf S.txtr]; 
        S.qust      = [fidf S.qust]; 
    
    elseif strcmp( loc, 'post' ) % postfix
        S.hist      = [S.hist fidf]; 
    else
        error('location %s not implemented', loc );
    end
end

% -----  Filestems (with path)  -----
S.histFs        = [ pthColl  S.hist ];
S.salcFs        = [ pthColl  S.txtr ];
S.fbrcFs        = [ pthColl  S.fbrc ];

% -----  Full Filepaths  -----
P.txgs          = [ S.salcFs    Fixt.txgs ];
P.txgg          = [ S.salcFs    Fixt.txgg ];
P.txgb          = [ S.salcFs    Fixt.txgb ];

P.domori        = [ S.salcFs    Fixt.domori ];

P.appc          = [ S.salcFs    Fixt.appc ];
P.nfet          = [ S.salcFs    Fixt.nfet ];
P.cvrg          = [ S.salcFs    Fixt.cvrg ];

P.tst           = [ S.salcFs    Fixt.tst ];

P.histi         = [ S.histFs    Fixt.hsall ];   % from dscx
P.hsflt         = [ S.histFs    Fixt.hsflt ];   % flat from dbin
P.hsspa         = [ S.histFs    Fixt.hsspa ];   % spatial from dbin (cellwise)

P.fbk0          = [ S.fbrcFs    Fixt.fbk0 ];   % fabric hyko 0
P.fbk1          = [ S.fbrcFs    Fixt.fbk1 ];   % fabric hyko 1
P.fbk2          = [ S.fbrcFs    Fixt.fbk2 ];   % 
P.fbk3          = [ S.fbrcFs    Fixt.fbk3 ];   % 
%P.fbk4          = [ S.fbrcFs    Fixt.fbk4 ];   % 

P.fbm0          = [ S.fbrcFs    Fixt.fbm0 ];   % fabric maps 0
P.fbm1          = [ S.fbrcFs    Fixt.fbm1 ];   % fabric maps 1
P.fbm2          = [ S.fbrcFs    Fixt.fbm2 ];   % 
P.fbm3          = [ S.fbrcFs    Fixt.fbm3 ];   % 
%P.fbm4          = [ S.fbrcFs    Fixt.fbm4 ];   % 

P.qust          = [ pthColl     S.qust ];       % was saved as mat file

end




