%
% Filestems of single files. By default for descriptor extraction and it
% appends letter 'i'. Use empty string '' as second argument to omit the
% letter.
%
% sa o_FileExtensions.m
%
% IN   Pths     paths as generated in u_CollPaths.m
%      idf      [optional] appended to stem
%      typ      [optional] for bin output idf is prepended. for fabric idf
%                           is ignored
%
% OUT  struct or string. It's complex.
%
% USE
%      Fist1  = o_FileStems( Pths );
%      Fist1  = o_FileStems( Pths, '' );    % omits 'i'
%      Fist1  = o_FileStems( Pths, idf, 'bin' );
%      Fist1  = o_FileStems( Pths, idf, 'cab_fbrc' );
%
function [S] = o_FileStems( Pths, idf, typ )

if nargin==1 % with trailing letter 'i'

    S.dsci      = [ Pths.dsci 'DSC_i' ];
    S.dtop      = [ Pths.dtop 'Top_i' ];
    S.dbin      = [ Pths.dbin 'Bin_i' ];
    S.veci      = [ Pths.veci 'VMX_i' ];
    return;

elseif nargin==2 % with trailing string idf
    
    S.dsci      = [ Pths.dsci 'DSC_' idf ];
    S.dtop      = [ Pths.dtop 'Top_' idf ];
    S.dbin      = [ Pths.dbin 'Bin_' idf ];
    S.veci      = [ Pths.veci 'VMX_' idf ];

    return;
end

%% ---------   For Bins/Hist   ----------
% returns as string (not struct)
if strcmp( typ, 'bin' )
    
    S       = [ Pths.dbin idf ];
    
elseif strcmp( typ, 'cab_fbrc' )
    
    S.cbnt  = [ Pths.dbin 'Cabinet' ];
    S.fbrc  = [ Pths.dbin 'Fbrc_' ];
    
else
    error( typ, 'not specified' );
end

end




