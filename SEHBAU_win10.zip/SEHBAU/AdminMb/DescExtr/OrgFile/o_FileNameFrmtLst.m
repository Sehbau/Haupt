%
% Generates a formatted filename for a list of indices.
%
% IN    fist    filestem
%       IxI     list of indices
%       ext     extension
%       typ     format type
% 
function aFina = o_FileNameFrmtLst( fist, IxI, ext, typ )

nIx     = length(IxI);

aFina   = cell(nIx,1);
for i = 1:nIx
    aFina{i} = o_FileNameFrmt( fist, IxI(i), ext, typ );
end
    
end

