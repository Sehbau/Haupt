%
% File extensions with two output structures: one for description of image
% and one for focus. Use o_FinaApndExtDscx to generate a struct holding all
% filenames with those extensions. For filenames see o_FileNames().
%
% o_FileExtensColl.m
% 
% USE Fixt     = o_FileExtensions();
%     fpDSC    = o_FinaApndExtDscx( pthOut, Fixt ); 
%     u_FipaDateExt( fpDSC )   displays date for all files
%
% from struct stuFileExtn in FileNameDesc.h
%
function [D F] = o_FileExtensions()

%% -------------   IMAGE   ---------------

% -----  image 
D.dsc    = '.dsc';
D.dsbi   = '.dsb';
D.hsti   = '.hst';
D.hsflt  = '.hsflt';    % flat histograms (dbin)
D.hsspa  = '.hsspa';    % spatial histograms (dbin)
D.fbrc   = '.fbrc';     % fabric
D.dtop   = '.dtop';     % desc top

D.kol    = '.kol';		% kolumns
D.txm    = '.txm';		% texture maps
D.txd    = '.txd';		% texture description
D.slc    = '.slc';		% saliency 

D.qbbx   = '.qbbx';		% proposals bbox
D.qdsc   = '.qdsc';		% proposals descriptors
D.qim    = '.qim';      % quant indices for an image (by book)

% -----  descriptors
D.rre    = '.rre';      % RRE space (full set)
D.skl    = '.skl';      % skeleton (one cnt space)
D.cvpf   = '.cvpf';		% curve partitions, full set
D.cvpg   = '.cvpg';		% gerust
D.cvpo   = '.cvpo';		% curve partitions organization (deployed yet?)
D.cvps   = '.cvps';     % shape: sgrrgb
D.form   = '.form';		% form
D.shpd   = '.shpd';		% shape descriptor
D.cntpat = '.cntPat';

D.adjp   = '.adjp';
D.vtx    = '.vtx';

% -----  features
D.cntMps    = '.cntMps';
D.cuv       = '.cuv';       % contour universe
D.cuvKpt    = '.cuvKpt';
D.ruv       = '.ruv';       % region universe (LoadRegUnv.m)
D.bspx      = '.bspx';      % boundary space pixels
D.bsd       = '.bsd';       % boundary space description
D.kyp       = '.kyp';       % keypoints
D.vkyp      = '.vkyp';      % values at keypoints

D.bonBbxRaw = '.bonBboxRaw'; % s_FunvBboxAll, ai dscx.cpp
D.bonBbx    = '.bonBbox';  % s_BonBboxPyr
D.bonAsp    = '.bonAsp';
D.bonPix    = '.bonPix';   % s_BonPixSegw, ai sgrRGB.cpp

% -----  shape
D.shp       = '.shp';

% -----  vectors
% see o_FileExtensVect.m

% -----  conversion
D.hari    = '.hari';    % Hst-Of-Att as array for image
D.harflt  = '.harflt';  % Hst-Of-Att as array for flat (dbin output)
D.harspa  = '.harspa';  % Hst-Of-Att as array for spat (dbin output)

% fabric
D.fbArK0  = '.fbArK0';  % fabric, kolumn 0
D.fbArK1  = '.fbArK1';  % fabric, kolumn 1
D.fbArK2  = '.fbArK2';  % fabric, kolumn 2
D.fbArK3  = '.fbArK3';  % fabric, kolumn 3

D.fbArM0  = '.fbArM0';  % fabric, map 0
D.fbArM1  = '.fbArM1';  % 
D.fbArM2  = '.fbArM2';  % 
D.fbArM3  = '.fbArM3';  % 

D.vbnmx   = '.vbnmx';
D.qnt     = '.qnt';     % ??

% -----  maps
D.mapUch  = '.mpu';

%% -------------   FOCUS   ---------------
F.dscf   = '.dsf';
F.hstf1  = '.hsf1'; 	% fochst1.cpp
F.hstfL  = '.hsfL';

% -----   conversion
F.harf   = '.harf';    % Hst-Of-Att as array for focus





