%
% Generates a formatted filename. So far only two implementations:
% - typ 0:  mere number
% - typ 7:  with 7 leading zeros
%
% ai ICL_TOPX.m, ICL_DBIN.m
% cf o_FileNameFrmtLst.m
%
% IN    fist    filestem
%       ixi     image index
%       ext     extension
%       typ     format type
% 
%
function fn = o_FileNameFrmt( fist, ixi, ext, typ )

if nargin==3
    typ = 0;                % default: no modification
end

if typ==0                  % --- plain number (no modification)
        
    fn = [ fist num2str(ixi) ext ];
        
elseif typ==7              % --- leading zeros
        
    fn = sprintf('%s%07d%s', fist, ixi, ext);

else
    error('format type=%d not implemented.\n', typ );
end

    
end

