%
% File extensions for collections (concatenated from lists of images).
%
% for single images see o_FileExtensions.m
%
% USE Fixt     = o_FileExtensColl();
%
function [F] = o_FileExtensColl()

% --- collHimg
F.hsall = '.hstc';    % ALL attribute histogram 
F.hsflt = '.hsFLT';   % flat attribute histogram 
F.hsspa = '.hsSPA';   % spatial attribute histogram (cellwise)

% --- collSalc
F.txgs  = '.txgsc';    % texture global stats
F.txgg  = '.txggc';    % texture grid
F.txgb  = '.txgbc';    % texture band

F.domori = '.domoric'; % dominant orientation

F.appc  = '.appcc';    % appearance
F.nfet  = '.nfetc';    % num of features
F.cvrg  = '.cvrgc';    % coverage

% --- fabric
F.fbk0   = '.fbk0';   % hyperkolumns 0
F.fbk1   = '.fbk1';   % hyperkolumns 1
F.fbk2   = '.fbk2';   % 
F.fbk3   = '.fbk3';   % 
%F.fbk4   = '.fbk4';   % 

F.fbm0   = '.fbm0';   % maps of kolumn 0 (1)
F.fbm1   = '.fbm1';   % maps of kolumn 1 (2)
F.fbm2   = '.fbm2';   % 
F.fbm3   = '.fbm3';   % 

%F.fbAr  = '.fbAr';   % 

% --- text
F.tst   = '.tst';       % test (development)



