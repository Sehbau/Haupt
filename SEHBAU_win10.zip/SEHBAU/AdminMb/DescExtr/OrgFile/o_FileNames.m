%
% Filestems of single files.
%
% sa o_FileExtensions.m
%
% USE
%      Fina1  = o_FileNames( Pths );
%
function [S] = o_FileNames( Pths )

S.descFile      = [ Pths.DescImg 'DSC_i' ];
S.vectFile      = [ Pths.VectImg 'VMX_i' ];

end




