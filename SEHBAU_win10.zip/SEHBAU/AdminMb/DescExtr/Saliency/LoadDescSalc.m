%
% Loads saliency and texture statistics of one image as saved as with
% si_DescSal in DescIOsal.h
%
% cf iclSalcAly.m, exsbSmlObjDet.m, ...
%
function [S Hed] = LoadDescSalc( lfp )

bIxOne = 1;                 % we are in Matlab and use one-indexing

%% -----------   Open   ------------
fileID      = fopen(lfp, 'r');
if fileID<0, error('Could not open file %s', lfp); end

%% ------------   Header   -----------
Hed         = ReadSalcFileHead( fileID, 33 );


%% ------------   Texture  -----------
% ----  Global Stats
S.Txa.Gst       = ReadTxtrMapStats( fileID ); % map stats

% ----  Texturegrams
S.Txa.Grm.Grid  = ReadMtrxDat( fileID, 'float=>single' ); 
S.Txa.Grm.Bvrt  = ReadMtrxDat( fileID, 'int32=>single' ); 
S.Txa.Grm.Bhor  = ReadMtrxDat( fileID, 'int32=>single' ); 

% ----  Blob outlines (bboxes & asps)
S.Txa.Blb       = ReadBlobOut( fileID, bIxOne  );       


%% ------------   Shapes  -----------
% shape outlines (bboxes & asps)
S.Shp      	= ReadShpOut( fileID, bIxOne );  


%% ------------   Spots/Bunt   -----------
S.Txa.Spt	= ReadPixvRCf( fileID );
S.Txa.Bnt   = ReadPixvRCf( fileID );
S.Txa.mxBnt	= fread(fileID, 1, 'float=>single');    

idf         = fread(fileID, 1,  'int=>int');    % identifier
if idf~=-11111, error('idf incorrect'); end


%% ------------   Ensemble   -----------
S.Ens       = ReadSalcBbxEns( fileID );


%% ------------   DescStats   -------------
S.Dsc       = ReadDescStats( fileID );

%% ------------   Close   -----------
fclose( fileID );

%DispLoad( lfp );


