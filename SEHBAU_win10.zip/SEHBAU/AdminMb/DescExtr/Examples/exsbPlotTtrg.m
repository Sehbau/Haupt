%
% Demonstrates characterized tetragons.
%
% af exsbPlotShape.m
%
% Run from WITHIN directory UtilMb/Examples
%
% We assume exsbDscx1.m has been executed already.
%
clear;
run('../../../AdminMb/globalsSB.m');

pthDesc     = '../../../DescExtr/Desc/img1.dsc';       % person
%pthDesc     = '../../Desc/img2.dsc';       % train
%pthDesc     = '../../Desc/aachen.dsc';       % city

[DUV Kt]    = LoadDescUniv(pthDesc);    % in directory 'Vect'
[APIX Jbsp] = LoadBonPixSpc([pthDesc(1:end-4) '.bspx']);
DispLoad(pthDesc);
if Kt.nLev>6, Kt.nLev = 6; end      % limit to 6 levels

% LABatt = o_AttsLabels();

%% -----   Plot Shapes   -----
fprintf('Plotting...');
% we plot boundary pixels, and then colorize them according to attribute
% values
colGrayBrgt = [0.8 0.8 0.8];   
colGrayDark = [0.4 0.4 0.4];   
colBlue     = [0 0   1];
colOrng     = [1 0.5 0];

hf = figure(1); clf; set(hf, 'name', 'shape'); 
for lev = 1:Kt.nLev
    
    TTGlv = DUV.ATTRG{lev};         % extracting one level
    APix  = APIX{lev};
    szM   = Jbsp.SzM(lev,:);

    %GEObk = TTGlv.GEO;
    %GEO = u_AttsArrToStruct( GEObk, Lbs ); 
   
    subplot(3, 2, lev); hold on;
    
    % ---  plotting LONG boundaries ---
    % p_BoundPixXXX do not contain length limitation, so we write again:
    for b = 1:length(APix)
        if length(APix{b}.Cl)<20, continue; end
        plot( APix{b}.Cl, APix{b}.Rw, 'color', colGrayBrgt );
    end
    
    nTtg    = length( TTGlv.Pos.Vrt );
    fprintf('%3d\n ', nTtg);
    
    %St.Les  = f_ArrStat( TTGlv.Les );   DispArrStat( St.Les, 'Les' );
    %St.Ttrg = f_ArrStat( TTGlv.Ttrg );  DispArrStat( St.Ttrg, 'Ttrg' );
    %St.Wide = f_ArrStat( GEO.Wide );  DispArrStat( St.Wide, 'Wide' );
    %St.Wide = f_ArrStat( TTGlv.Wide );  DispArrStat( St.Wide, 'Wide' );

    for t = 1:nTtg
    
        [Axe Cor Ttg] = u_TtrgRtrv1( TTGlv, t );

        %% ---  boundary pixels  ---
        Pix   = APix{ Ttg.ixBon };    % in (pixel) map coordinates
        hpBon = plot( Pix.Cl, Pix.Rw, 'color', colGrayDark );

        %% ---  elo-axis  ---
        hp  = plot( Axe.Cl, Axe.Rw, 'color', colBlue );

        %% ---  certain attribute values  ---
        %fprintf('%1.3f  :  %1.3f %1.3f\n', TTGlv.Elo(t), wide, high);
        if 0
            % axiality
            if Ttg.axV>0.05, set(hp, 'color', [1.0  0  0]); end % red
            if Ttg.axH>0.05, set(hp, 'color', [0  1.0  0]); end % green
        else
            % orientation
            if Ttg.oriAbs<0.4, set(hp, 'color', [1.0 0  0]); end % red
            if Ttg.oriAbs>1.1, set(hp, 'color', [0   1.0  0]); end % green
        end
        
        %% ---  polygon  ---
        hp  = plot( Cor.Cl, Cor.Rw, 'color', colOrng );

        
    end
    
    axis ij;
    set(gca,'xlim',[1 szM(2)]);
    set(gca,'ylim',[1 szM(1)]);
    
end