%
% Reads ttrg bins as saved under TtrgIObin.h-w_TtrgBinUni
%
% af ReadShpBinUni.m
%
function [S nTtg] = ReadTtrgBinUni(fileID)

% labels in ReadTtrgAtt.m

[S.Geom szD]  = ReadMtrxDat( fileID, 'uint8=>single' );
S.Lage        = ReadMtrxDat( fileID, 'uint8=>single' );
S.Angs        = ReadMtrxDat( fileID, 'char=>int8' ); % we deal with invalid angles
S.Dicv        = ReadMtrxDat( fileID, 'uint8=>single' );

nTtg   = szD.nObs;

end

