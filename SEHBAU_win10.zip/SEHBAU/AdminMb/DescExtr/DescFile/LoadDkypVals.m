%
% Loads the values taken at descriptor keypoints.
%
function [D Kt Hed] = LoadDkypVals( lfn ) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----------------------   Header   ---------------------------
Hed             = ReadDescFileHead( fileID, 16 );

%% -----------------------   Spaces   ---------------------------
[D.ASKL Kt.Nskl]  = ReadDkypVlsSpcF( fileID ); % skelet

[D.AARC Kt.Narc]  = ReadDkypVlsSpcF( fileID ); % arc

[D.ASTR Kt.Nstr]  = ReadDkypVlsSpcF( fileID ); % str

[D.AFRM Kt.Nfrm]  = ReadFrmKypVlsSpc( fileID ); % form


if 0
    % to be implemented
    [D.ARSG Kt.Nrsg]  = ReadRsgSpc(fileID, vers );
    % gerust
    [nLev Narc]       = ReadDescSpcHead(fileID);
    [nLev Nstr]       = ReadDescSpcHead(fileID);
    [D.AARC Kt.Narc]  = ReadArcSpc(fileID);
    [D.ASTR Kt.Nstr]  = ReadStrSpc(fileID);
    
    [D.ASHP Kt.Nshp]  = ReadShpSpc(fileID); % shape
    
    idfSpc    = fread(fileID, 1,  'int=>int');    % identifier
    if (idfSpc~=66666)
        error('Spaces not properly read (see si_DescVect');
    end
    
    [D.ATTRG Kt.Nttrg] = ReadTtrgSpc(fileID); % tetragons
    [D.ABNDG Kt.Nbndg] = ReadBndgSpc(fileID); % bundles
end

%% -----------------------   Trailer   ---------------------------
idf    = fread(fileID, 1,  'int=>int'); % identifier

fclose(fileID);

if isempty(idf) || (idf~=99999)
    fprintf('file identifier not correct %d. Expected 99999\n', idf);
    %D.ASHP
    %Kt.Nshp
    pause('pausing in LoadDescImag');
end

%% ------   A2S   -------
%Kt.Ncnt
% cast to double: manipulation is easier in Matlab with double
Kt.nLev    = double(Hed.nLev);      
Kt.szV     = double(Hed.szV);
Kt.szH     = double(Hed.szH);
Kt.ntDsc   = double(Hed.ntDsc);

