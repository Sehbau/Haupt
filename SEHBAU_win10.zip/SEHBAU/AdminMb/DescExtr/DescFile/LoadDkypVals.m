%
% Loads the values taken at descriptor keypoints.
%
function [D Kt Hed] = LoadDkypVals( lfn ) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----------------------   Header   ---------------------------
Hed             = ReadDescFileHead( fileID, 16 );

%% -----------------------   Spaces   ---------------------------
[D.ASKL Kt.Nskl]  = ReadDkypVlsSpcF( fileID ); % skelet

[D.AARC Kt.Narc]  = ReadDkypVlsSpcF( fileID ); % arc

[D.ASTR Kt.Nstr]  = ReadDkypVlsSpcF( fileID ); % str

[D.AFRM Kt.Nfrm]  = ReadFrmKypVlsSpc( fileID ); % form

%% -----------------------   Trailer   ---------------------------
idf    = fread(fileID, 1,  'int=>int'); % identifier

fclose(fileID);

if isempty(idf) || (idf~=99999)
    fprintf('file identifier not correct %d. Expected 99999\n', idf);
    %D.ASHP
    %Kt.Nshp
    pause('pausing in LoadDescImag');
end

%% ------   A2S   -------
%Kt.Ncnt
% cast to double: manipulation is easier in Matlab with double
Kt.nLev    = double(Hed.nLev);      
Kt.szV     = double(Hed.szV);
Kt.szH     = double(Hed.szH);
Kt.ntDsc   = double(Hed.ntDsc);

