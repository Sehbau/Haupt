%
% Reads form attributes as saved under RsgIO.h-w_RsgAtt
% cf ReadRsgSpc.m
%
function [S nRsg] = ReadRsgAtt(fileID, vers)

nRsg  = fread(fileID, 1,  'int=>int');

S       = [];

% =====   Geometry   =====
% based on extrema of radial signature
[S.RdSig szD] = ReadMtrxDat( fileID, 'float=>single' );
% based on a simplified (convex) hull
[S.RospA szD] = ReadMtrxDat( fileID, 'float=>single' );
[S.RospB szD] = ReadMtrxDat( fileID, 'float=>single' );
[S.RoEck szD] = ReadMtrxDat( fileID, 'float=>single' );
% based on protrusions of radial signature
[S.BospA szD] = ReadMtrxDat( fileID, 'float=>single' );
[S.Bglid szD] = ReadMtrxDat( fileID, 'float=>single' );

if vers==2
    % inactive
end

% =====   Position   =====
S.OriRsg  = fread(fileID, nRsg, 'float=>single'); % based on radial sign.
S.OriHul  = fread(fileID, nRsg, 'float=>single'); % based on hull
S.Pos     = ReadAttPos(fileID);

S.Cod     = fread(fileID, nRsg, 'uint8=>uint8');

% =====   Appearance   =====
S.RGB     = ReadAttRgb(fileID, nRsg);
S.Ctr     = fread(fileID, nRsg, 'float=>single');

% =====   Util  =====
% index to boundary (in boundary space BSP)
S.IxBon1  = fread(fileID, nRsg, 'int32=>int32') + 1; % change to one-indexing

% =====   Trailer   =====
idf    = fread(fileID, 1, 'int16=>int');
assert(idf==2222);

S.nRsg = nRsg;

end


function [] = ff_Deprecated()

if 0
S.Rds  = fread(fileID, nRsg, 'float=>single');
S.Cir  = fread(fileID, nRsg, 'float=>single');
S.EloR = fread(fileID, nRsg, 'float=>single');
S.Bulk = fread(fileID, nRsg, 'float=>single');

S.Bis1 = fread(fileID, nRsg, 'float=>single');
S.Bis2 = fread(fileID, nRsg, 'float=>single');
S.Bis3 = fread(fileID, nRsg, 'float=>single');
S.Bis4 = fread(fileID, nRsg, 'float=>single');
S.Bis5 = fread(fileID, nRsg, 'float=>single');

S.Star = fread(fileID, nRsg, 'float=>single');
S.Dent = fread(fileID, nRsg, 'float=>single');
end
end

