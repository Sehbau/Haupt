%
% Reads space of contour attributes as saved under CntIO.h-w_CntSpc
%
function [ACNT Ncnt] = ReadCntSpc( fid, bWithPts )

if nargin==1, bWithPts=0; end

[nLev Ncnt] = ReadDescSpcHead( fid );

ACNT  = cell(nLev,1);
for l = 1:nLev
    
    [ACNT{l} nCnt] = ReadCntAtt( fid, bWithPts );
    
    assert( Ncnt(l)==nCnt, 'contour count not matching' );
    
end

end

