%
% Reads data as saved under w_PixvRCf in PixIO.h
%
function S = ReadPixvRCf( fileID )

S.Px    = ReadPixRCs( fileID );

% read the associated values (must be same length)
S.V     = fread( fileID, S.Px.nCo, 'float=>single');    

end