%
% Concatenates region histograms.
%
% cf evsbReadAtReg.m
%
function [Himg] = u_RegHstCat( HCELL )

nReg = length( HCELL );

Himg = zeros( nReg, 256, 'int32' );

cVld = 0;
for i = 1:nReg
    
    if isempty(HCELL{i}), 
        continue; 
    end
    
    cVld         = cVld+1;
    Himg(cVld,:) = HCELL{i};
end

Himg    = Himg(1:cVld,:);

fprintf('u_RegHstCat: nVld   %4d  [%1.3f]\n', cVld, cVld / nReg );

end

