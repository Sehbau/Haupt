%
% Reads the desc stats
%
% as written by w_DescStats in DescStatsAnf.h
%
function [S] = ReadDescStats( fid )

[S.MaxSizScl] = ReadDescTypSpcF( fid );
[S.MenSizScl] = ReadDescTypSpcF( fid );
[S.MaxSizAbs] = ReadDescTypSpcF( fid );

[S.Ndsc] 	= ReadDescTypSpcI( fid );
[S.IxMx]  	= ReadDescTypSpcI( fid );

% -----  coverage boundaries
nLev            = S.MaxSizScl.nLev;
S.CvgBon     	= ReadFeatCoverage( fid, nLev );
S.CvgShp     	= ReadFeatCoverage( fid, nLev );

% -----  smoothness
S.Smo.ArcMen = zeros(nLev,1,'single');
S.Smo.ArcMax = zeros(nLev,1,'single');
S.Smo.StrMen = zeros(nLev,1,'single');
S.Smo.StrMax = zeros(nLev,1,'single');
for l = 1:nLev
    arc = ReadAttDom( fid );
    str = ReadAttDom( fid );
    S.Smo.ArcMen(l) = arc.men;
    S.Smo.ArcMax(l) = arc.max;
    S.Smo.StrMen(l) = str.men;
    S.Smo.StrMax(l) = str.max;
end

idf         = fread(fid, 1,  'int=>int');    % identifier
if idf~=-11111, error('idf incorrect'); end

% -----   shape2
S.AreShp        = fread( fid, nLev, 'float=>single' );
S.ShpGrpSpc     = fread( fid, 3, 'float=>single' );

% -----  appearance
S.GryMmm      = fread( fid, 3, 'uint8=>int32' );
S.MxRngRR     = fread( fid, nLev, 'uint8=>int32' ); % ridge/river contrast
S.MxRngEg     = fread( fid, nLev, 'uint8=>int32' ); % edge contrast
S.MxRngBon    = fread( fid, nLev, 'uint8=>int32' );

S.Nbon        = fread( fid, nLev, 'int32=>int32' );
S.Nrdg        = fread( fid, nLev, 'int32=>int32' );
S.Nriv        = fread( fid, nLev, 'int32=>int32' );
S.Nedg        = fread( fid, nLev, 'int32=>int32' );

S.NpxBon      = fread( fid, nLev, 'int32=>int32' );
S.NpxRdg      = fread( fid, nLev, 'int32=>int32' );
S.NpxRiv      = fread( fid, nLev, 'int32=>int32' );
S.NpxEdg      = fread( fid, nLev, 'int32=>int32' );

%Dsc.Skl_StrLon  = fread( fileID, nLev, 'uint8=>int8' );
%Dsc.Skl_StrMen  = fread( fileID, nLev, 'uint8=>int8' );

S.Cnt       = ReadAttFarbig( fid );
S.Bon       = ReadAttFarbig( fid );

end

