%
% Turns arrays of structs (matrices) into struct of arrays given attribute
% names from o_AttsLabels.m
%
% USE
%  [LbAtts, LbAttSG]   = o_AttsLabels();
%  DSC                 = u_DescMxToStcOfArr( DSC, LbAttSG );
% 
%
function [DSC] = u_DescMxToStcOfArr( DSC, LbAttSG ) 

nLev = length( DSC.ACNT );

for l = 1:nLev

    % ----------  form   ----------
    FRM         = DSC.ARSG{l};         % extracting one level
    FRM.RdSig   = u_MtrxToStcArr( FRM.RdSig, LbAttSG.Frm.RdSig );
    FRM.RospA   = u_MtrxToStcArr( FRM.RospA, LbAttSG.Frm.RospA );
    FRM.RospB   = u_MtrxToStcArr( FRM.RospB, LbAttSG.Frm.RospB );
    FRM.RoEck   = u_MtrxToStcArr( FRM.RoEck, LbAttSG.Frm.RoEck );
    DSC.ARSG{l} = FRM;
    
    % ----------  shape   ----------
    SHP         = DSC.ASHP{l};         % extracting one level
    SHP.STR     = u_MtrxToStcArr( SHP.STR, LbAttSG.Shp.Scors ); 
    SHP.SFI     = u_MtrxToStcArr( SHP.SFI, LbAttSG.Shp.Sfine ); 
    DSC.ASHP{l} = SHP;
end

%% -----------------------   Shape Labels   ---------------------------
% reads them as one array
%D.LabShpScors = ReadAttLab( fileID, size(D.ASHP{1}.STR,2) );
%D.LabShpSfine = ReadAttLab( fileID, size(D.ASHP{1}.SFI,2) );

