%
% Loads a matrix of histograms for a collection.
% 1) a collection of full, flat or spatial hists (from a LIST of images)
% 2) or a matrix of spatial histograms for ONE image
%
% IN DETAIL:
%
% 1) [nImg ntBin], as collected with program collhimg. 
%       as saved in C under E_DESC/CollHist/CollHistUtil.h-s_CollHist().
%    For one image see LoadDescHist.m
%
% 2) [nCll nBin], as collected by fbrc2arr
%
% OUT  HST    histogram as [nImg ntBin] | [nCll nBin]
%      Nbin   number of bins, NOT adjusted for chromatics: use
%                i_HistBinNumAdj.m
%      Dim    dimensions of HST
%
function [HST Nbin Dim] = LoadCollHist( pthFile, bDisp )

if nargin==1
    bDisp = 1;
end

%% -------   Determine Hist Type   ---------
[pth,nam,ext]   = fileparts( pthFile );
Fixt            = o_FileExtensColl();

bFull = strcmp( ext, Fixt.hsall )==1; % full, as from dscx
bFlat = strcmp( ext, Fixt.hsflt )==1; % flat, as from dbin
bSpat = strcmp( ext, Fixt.hsspa )==1; % spatial, as from dbin
bFhyk = ~isempty( strfind( ext, 'fbk' ) ); % fabric hyperkolumns

% from fbrc2arr
bFbAr0 = strcmp( ext, '.fbArK0' )==1; % fabric, kolumn 0
bFbAr1 = strcmp( ext, '.fbArK1' )==1; % fabric, kolumn 1
bFbAr2 = strcmp( ext, '.fbArK2' )==1; % fabric, kolumn 2
bFbAr3 = strcmp( ext, '.fbArK3' )==1; % fabric, kolumn 3
bFbAr  = bFbAr0 || bFbAr1 || bFbAr2 || bFbAr3;

if bFull || bFlat || bSpat || bFhyk || bFbAr
    % okay, do nothing
else
    error('extension %s not recognized or implemented', ext);
end

%% -------   Open File   ---------
fileID      = fopen(pthFile, 'r');
if fileID<0, 
    error('could not open %s', pthFile); 
end

if bDisp
    fprintf('Loading %s...', pthFile );
end

%% -------   Header (Size)   --------
nImg        = fread(fileID, 1,  'int=>int');
nBin        = fread(fileID, 1,  'int=>int');

if bDisp
    fprintf('[%4d %4d]...', nImg, nBin);
end

%% -------   Data Matrix   --------
[HST k]     = fread(fileID, nImg*nBin, 'int=>single');

if k~=nImg*nBin
    fprintf('Read %d values from expected %d\n', k, nImg*nBin );
end

%% -------   BinNumbers   --------
if bFull
    Nbin    = ReadDescBinNum( fileID );
elseif bFlat
    Nbin    = ReadDescBinNum( fileID );
elseif bSpat
    Nbin    = ReadBnumSpat( fileID );
elseif bFhyk
    Nbin    = [];
elseif bFbAr
    Nbin    = [];
else
    error('not specified');
end

fclose(fileID);

if bDisp
    if isempty(Nbin)
        % dont show it is empty
    else
        Nbin
    end
end

%% --- reshape after, such that Nbin is read.
HST     	= reshape(HST, nBin, nImg)';

Dim.nImg   = nImg;
Dim.nBin   = nBin;

if bDisp
    fprintf('done.\n');
end

%% -----------   Verify   --------------
if bFull

    ntBin   = sum( Nbin.Tot );
    nDim    = size( HST,2 );
    if ntBin~=nDim
        warning( 'LoadCollHist: sum of bin numbers %d ~= dims of histogram %d', ...
            ntBin, nDim );
    end
end

end

