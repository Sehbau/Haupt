%
% Adjusts histogram bin numbers for chromatics and skeleton (contours).
%
% Carried out only for flat, univariate bin count. It also verifies total
% bin count for flat (univariate) bins.
% 
% PRECEEDS    i_HistBinRanges.m

% cf cfHstEss.m, exsbCollHist.m
%
% IN    Nbin    as loaded by LoadCollHist.m
%       nFltUni = Nbin.Tot(1);
% OUT   Nbin    with two new fields      
%
function Nbin = i_HistBinNumAdjTot( Nbin ) 

NATT        = Nbin.ATT;

NATT        = i_HistBinNumAdjAtt( NATT );

% --- total bin count
ntbCnt   = sum(NATT.CntUni) * 4;  % including skeleton!

% no more modifications: from here on verification
ntbFrm   = sum(NATT.FrmUni);
ntbArc   = sum(NATT.ArcUni);
ntbStr   = sum(NATT.StrUni);

ntbShp   = NATT.shpUni;
ntbTtrg  = Nbin.FltUni(6);
ntbBndg  = Nbin.FltUni(7);

ntbFltUni = ntbCnt + ntbFrm + ntbArc + ntbStr + ntbShp + ntbTtrg + ntbBndg;

%% ---------   place back   --------
Nbin.ATT  = NATT;

%% ---------   two new fields   ------------
Nbin.ntCntFlt = ntbCnt;     

Nbin.bAdj   = 1;

%% ---------   verify   ---------
if ntbFltUni~=Nbin.Tot(1),
    NATT.CntUni
    NATT.FrmUni
    NATT.ArcUni
    NATT.StrUni
    warning('Uni not correct: CRASS %4d %4d %4d %4d %4d = %d ~= %d', ...
        ntbCnt, ntbFrm, ntbArc, ntbStr, ntbShp, ntbF1, FltUni);
end



end

