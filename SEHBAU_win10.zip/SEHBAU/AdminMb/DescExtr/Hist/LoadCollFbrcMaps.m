%
% Loads the collected fabric maps. For hyper-kolumns we use LoadCollHist.m
%
% af LoadCollTxtr.m
% cf iclCollFbrc.m, cfHstEss.m
%
% IN  FinaColl   struct with filenames as generated in o_FileNameColl.m
%
function [F Hed] = LoadCollFbrcMaps( FinaColl, bDispLoad )

if nargin==1,
    bDispLoad = 1;
end

[F.L0 Hed.L0]   = LoadBankVec( FinaColl.fbm0, bDispLoad );
[F.L1 Hed.L1]   = LoadBankVec( FinaColl.fbm1, bDispLoad );
[F.L2 Hed.L2]   = LoadBankVec( FinaColl.fbm2, bDispLoad );
[F.L3 Hed.L3]   = LoadBankVec( FinaColl.fbm3, bDispLoad );

end

