%
% Loads the collected fabric hyperkolumns.
%
% By default it loads the collection of the smallest layer only (zero-index
% 3). The collection size might be too large to be loaded, in particular
% for the largest layer (zero-index 0).
%
function [F Nbin] = LoadCollFbrcHyko( FinaColl, set, bDispLoad )

if nargin==1,
    set       = 0;
    bDispLoad = 1;
end

[HYK Nbin] = LoadCollHist( FinaColl.fbk3, bDispLoad );   % the smallest one

if set>0
    HYK   = LoadCollHist( FinaColl.fbk2 );
end
if set>1
    HYK   = LoadCollHist( FinaColl.fbk1 );
end
if set>2
    HYK   = LoadCollHist( FinaColl.fbk0 ); % very large!!
end

end

