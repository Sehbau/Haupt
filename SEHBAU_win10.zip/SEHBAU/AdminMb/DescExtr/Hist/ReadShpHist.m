%
% Reads shape histograms as saved under ShpIO.h-w_ShpHist
%
% cf LoadDescHist.m
%
function [Hcat Nbin] = ReadShpHist( fileID )

Nbin    = struct;

HScors  = ReadMtrxDat( fileID, 'int32=>single' );
HSfine  = ReadMtrxDat( fileID, 'int32=>single' );
HRas    = ReadMtrxDat( fileID, 'int32=>single' );
HAto    = ReadMtrxDat( fileID, 'int32=>single' );

Hcat   = [ HScors(:)' HSfine(:)' HRas(:)' HAto(:)' ];

Nbin.tot = length(Hcat);

end

