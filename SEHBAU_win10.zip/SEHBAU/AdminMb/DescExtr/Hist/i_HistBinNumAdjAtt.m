%
% Adjusts histogram bin numbers for chromatics.
%
% cf exsbFabric.m, i_HistBinNumAdjTot.m
%
% IN    NATT    as read by ReadBnumATT.m
% OUT   NATT
%
function [NATT S] = i_HistBinNumAdjAtt( NATT ) 

NATT.CntUni(end)    = NATT.CntUni(end)*3;   % chromatics * 3

ixCrm    = 5;
NATT.RsgUni(ixCrm)  = NATT.RsgUni(ixCrm)*3; % chromatics * 3

ixCrm    = 8;
NATT.ArcUni(ixCrm)  = NATT.ArcUni(ixCrm)*3;

ixCrm    = 4;
NATT.StrUni(ixCrm)  = NATT.StrUni(ixCrm)*3;


% --- total bin count
S.ntbCnt    = sum(NATT.CntUni) * 4;  % including skeleton!

% no more modifications: from here on verification
S.ntbRsg    = sum(NATT.RsgUni);
S.ntbArc    = sum(NATT.ArcUni);
S.ntbStr    = sum(NATT.StrUni);

S.ntbShp    = NATT.shpUni;

end

