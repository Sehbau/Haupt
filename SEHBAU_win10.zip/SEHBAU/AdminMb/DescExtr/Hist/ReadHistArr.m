%
% Reads an array of histograms [nDty nBin] as saved under w_HistArr.
%
% cf LoadDescHist.m
%
function [Harr Dim] = ReadHistArr(fileID)

%% =====    # of bins   =====
nDty        = fread(fileID, 1,  'int=>int');
nBinPerDsc  = fread(fileID, 1,  'int=>int');  % per descriptor

%% =====   Histogram   =====
Harr        = fread(fileID, nDty*nBinPerDsc, 'int=>int');

Dim.nDty    = nDty;
Dim.nBin    = nBinPerDsc;
Dim.ntBin   = nDty * nBinPerDsc;

end

