%
% Reads the bin numbers for spatial histograms as written by w_BnumSpaClw
% DescBinAnf.h
%
% sa/af ReadDescBinNum
%
% cf LoadFabric.m, LoadCollHist.m
%
function [N] = ReadBnumSpat( fileID )

N.nCells        = fread( fileID, 1,  'int=>int');  
N.nBinPerCell   = fread( fileID, 1,  'int=>int');  
N.ntBin         = fread( fileID, 1,  'int=>int');  
N.Dim.nVer      = fread( fileID, 1,  'short=>int');  
N.Dim.nHor      = fread( fileID, 1,  'short=>int');  

% ----------   Individual DescTypes   ---------------
N.Cnt   = ReadBnumDsc1( fileID );
N.Frm   = ReadBnumDsc1( fileID );
N.Arc   = ReadBnumDsc1( fileID );
N.Str   = ReadBnumDsc1( fileID );
N.Shp   = ReadBnumDsc1( fileID );

% ----------   Total Per DescType    ---------------
N.PerTyp.Nt  	= [N.Cnt.nt   N.Frm.nt   N.Arc.nt   N.Str.nt   N.Shp.nt];
N.PerTyp.Nuni 	= [N.Cnt.nUni N.Frm.nUni N.Arc.nUni N.Str.nUni N.Shp.nUni];
N.PerTyp.Nbiv 	= [N.Cnt.nBiv N.Frm.nBiv N.Arc.nBiv N.Str.nBiv N.Shp.nBiv];

end

