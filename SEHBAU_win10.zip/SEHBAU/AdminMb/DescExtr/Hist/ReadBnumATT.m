%
% Loads the descriptor bin numbers for the individual attributes as saved
% in C under w_BnumATT (DescBinAnf.h)
%
% Note: bin count not entirely correct. It lacks trippling the chromatic
% values. Use i_HistBinNumAdj.m for that.
%
% cf ReadDescBinNum.m
%
function [N] = ReadBnumATT( fileID )

sep    	 = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.CntUni = fread(fileID, 4,  'int=>int');  % len/str/ori/crm

sep    	 = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.FrmUni = fread(fileID, 13, 'int=>int');  % rds/.../roct/lof

sep   	 = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.ArcUni = fread(fileID, 8,  'uint8=>int');  % len/...

sep    	 = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.StrUni = fread(fileID, 4,  'int=>int');  % len/...

sep    	 = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.shpUni = fread(fileID, 1,  'int=>int');  
N.shpBiv = fread(fileID, 1,  'int=>int');  

sep    	  = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.ttrgUni = fread(fileID, 1,  'int=>int');  
N.ttrgBiv = fread(fileID, 1,  'int=>int');  

N.bndgUni = fread(fileID, 1,  'int=>int');  
N.bndgBiv = fread(fileID, 1,  'int=>int');  

end

