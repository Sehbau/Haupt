%
% Loads the descriptor bin numbers as saved in C under w_DescBinNum.
%
% cf LoadCollHist.m
%
function [N] = ReadDescBinNum( fileID )

% ----------   Total   ---------------
N.Tot    = fread(fileID, 4,  'int=>int');  % flat/biv/spaFlat/spaBiv

% ----------   Hist Type   ---------------
N.F1     = fread(fileID, 7,  'int=>int');  % CRASSPB
N.F2     = fread(fileID, 7,  'int=>int');  % CRASSPB
N.S1     = fread(fileID, 7,  'int=>int');  % CRASSPB
N.S2     = fread(fileID, 2,  'int=>int');  % CR
N.S2     = [N.S2; 0; 0; 0]; % add three for ASS

% ----------   Individual DescTypes   ---------------
sep    	 = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.Cnt1D  = fread(fileID, 4,  'int=>int');  % len/str/ori/crm

sep    	 = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.Rsg1D  = fread(fileID, 13, 'int=>int');  % rds/.../roct/lof

sep   	 = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.Arc1D  = fread(fileID, 8,  'uint8=>int');  % len/...

sep    	 = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.Str1D  = fread(fileID, 4,  'int=>int');  % len/...

sep    	 = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.shpUni = fread(fileID, 1,  'int=>int');  
N.shpBiv = fread(fileID, 1,  'int=>int');  

sep    	  = fread(fileID, 1,  'int=>int');  assert(sep==-1);
N.ttrgUni = fread(fileID, 1,  'int=>int');  
N.ttrgBiv = fread(fileID, 1,  'int=>int');  

N.bndgUni = fread(fileID, 1,  'int=>int');  
N.bndgBiv = fread(fileID, 1,  'int=>int');  

% -----------   Trailer   -----------
idfEof      = fread(fileID, 1,  'int=>int');  
assert(idfEof==444);

end

