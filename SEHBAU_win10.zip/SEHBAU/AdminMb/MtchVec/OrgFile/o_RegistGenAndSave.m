%
% Generates a register, verifies that it is valid (all files exist) and
% saves it.
%
% ai iclDscx.m, runMvecXXX.m, runMhstKnn.m
% sa SaveFipaXXX, SaveFinaXXX
%
% IN  pthStem   path to be preprended
%     IxImg     image indices
%     ext       extension
%     fpRegist  file path of register
%     nameFrmt  format of numbering
%     
% OUT bAllFilesExist  flag if file list complete (0 not complete)
%
function [bAllFilesExist] = o_RegistGenAndSave( ...
                                    pthStem, IxImg, ext, fpRegist, ...
                                    nameFrmt, bDispSave )

if nargin==4
    nameFrmt = 0;
end

aFipaDsc = o_RegistGen( pthStem, IxImg, ext, nameFrmt );

SaveTextLines( aFipaDsc, fpRegist );

bAllFilesExist = v_FileLstExists( fpRegist );

if nargin < 6, return; end

if bDispSave
    DispSave( fpRegist );
end

end

