%
% Focus-to-focus vector matching for two lists with mvec1. Calls function
% f_FocToFoc for one-on-one matching.
%
% IN    aFipaQuy    list of query focus files
%       aFipaRef    list of reference focus files
% OUT   Mes         measurement struct
%       M           matrices (struct)
%
function [Mes M] = MFOCTOFOC( aFipaQuy, aFipaRef, PrmFtF, Admin, bDISP )

nFocQuy = length( aFipaQuy );
nFocRef = length( aFipaRef );

if bDISP>0
    fprintf('MFOCTOFOC: %d x %d:\n', nFocQuy, nFocRef );
end

% --- create the mes matrices
M.DMvec = nan( nFocQuy, nFocRef, 'single');
M.SMvec = nan( nFocQuy, nFocRef, 'single');
M.SMbox = M.SMvec;

for qq = 1:nFocQuy
    
    %fprintf('q/r %2d/%2d: lev %d: %2d x %2d\n', ...
    %q, r, lev, nFocQuy, nFocRef);
    
    % we load only head
    LocQuy = LoadFocDescHead( aFipaQuy{qq} );
    
    for rr = 1:nFocRef
        
        LocRef = LoadFocDescHead( aFipaRef{rr} );
        
        % ============   FOC 2 FOC  ============
        % runs mvec1 (RennMvec1.m)
        Mftf = f_FocToFoc( LocQuy, LocRef, ...
                           aFipaQuy{qq}, aFipaRef{rr}, ...
                           PrmFtF, Admin, bDISP );
        
        % -----  A2M res  -----
        M.SMbox( qq, rr )   = Mftf.mtcBox;
        if Mftf.totFoc.bMtched
            M.SMvec( qq, rr ) = Mftf.totFoc.sim;
            M.DMvec( qq, rr ) = Mftf.totFoc.dis;
        end
        
    end % rr
    
    %% --------   with RennMvecL: I needed to included location matching
    % af runMvecL.m
    % finaRefLst = aLipaRef{lev};
    %cmd     = [ 'mvecL ' pthQuy ' ' finaRefLst ' ' finaMes ];
    %OutMvecL = f_ExecCommand( cmd, Args );
    
    
end % qq

%M.SMbox

%% =====  analyze focal matches [lev]  =====
% default values
Mes.simBox      = 0;
Mes.simVecMul   = 0;
Mes.simVecMen   = 0;
Mes.disVecMul   = 0;
Mes.disVecMen   = 0;

if nFocQuy>0 && nFocRef>0
    
    [simBoxLev OBOX] = f_MtrFromMM( M.SMbox, 'descend' );
    [simVecLev OSIM] = f_MtrFromMM( M.SMvec, 'descend' );
    [disVecLev ODIS] = f_MtrFromMM( M.DMvec, 'ascend' );
    
    Mes.simBox     = simBoxLev.men;
    Mes.disVecMul  = disVecLev.mul;
    Mes.disVecMen  = disVecLev.men;
    Mes.simVecMul  = simVecLev.mul;
    Mes.simVecMen  = simVecLev.men;
    
    % -----   Plotting   -----
    if bDISP>2
        figure(1); clf; [nr nc] = deal(3,2);
        subplot(nr,nc,1); imagesc(OBOX.O12); title('box');
        subplot(nr,nc,2); imagesc(OBOX.O21); title('box');
        subplot(nr,nc,3); imagesc(OSIM.O12); title('sim');
        subplot(nr,nc,4); imagesc(OSIM.O21); title('sim');
        subplot(nr,nc,5); imagesc(ODIS.O12); title('dis'); colorbar();
        subplot(nr,nc,6); imagesc(ODIS.O21); title('dis');
        fprintf('MFOCTOFOC - halted\n');
        pause();
    end
end

end

