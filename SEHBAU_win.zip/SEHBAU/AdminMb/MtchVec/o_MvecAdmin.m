%
% Filepaths for binary mvecL
%
% sa o_CascIdfPth
%
function [P] = o_MvecAdmin( pthOpr )

if nargin==0
    pthOpr = '';
end

P.fpMesVec      = [ pthOpr 'Mes/TotVec.txt'];

P.fpMesDtyDis   = [ pthOpr 'Mes/MesDtyDis.txt']; % unchangeable
P.fpMesDtySim   = [ pthOpr 'Mes/MesDtySim.txt']; % unchangeable

%P.pthPrm        = [ pthOpr 'Params/' ];
%P.pthRgs        = [ pthOpr 'Regist/' ];

P.pthProg       = pthOpr;



