%
% Wrapper routine for program mvecL, matching a list of description files.
%
% sa RennDscx
% 
% IN   fpVecT    testing (description) file, .dsc | .dsf
%      fiRegist  list of description files, .dsc | .dsf (register)
%      finaMes   output file name for matching results, length nFinasList   
%      Admin     administration, u_CmndAdmin.m
% OUT  Out       standard output
% 
function [Out] = RennMvecL( fpVecT, fpRegist, finaMes, Admin )

if nargin==3, 
    Admin.pthProg = ''; 
    Admin.optS    = '';
end

cmnd = [Admin.pthProg ...
        'mvecL ' fpVecT ' ' fpRegist ' ' finaMes ' ' Admin.optS];

[status Out] = system(cmnd);                   % excecute program

%% ------  Status  ------
if status>0
    Out
    warning('something went wrong');
end

%% ------  Verify Proper Termination  -----
ixEOP = strfind( Out, 'EndOfProgram');

if isempty(ixEOP)
    fpVecT
    cmnd
    Out
    %[VT KtT] = LoadFocVect(pthVecT);
    % [VL KtL] = LoadFocVect(vecL); I dont have a single file but a list
    fprintf('RennMvecL: EOP not found\n'); 
    
     % sometimes it hangs completely when allocating memory:
    if isempty(Out)
        fprintf('Out empty. We try to debug: '); 
        cmnd    = [cmnd ' --bDISP 3'];
        [stu Out] = system(cmnd);           % excecute program again
        Out
    end
    pause();
end


