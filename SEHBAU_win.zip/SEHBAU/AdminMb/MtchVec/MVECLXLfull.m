%
% Matches two lists of descriptor sets using program 'mvecL' run through
% 'RennMvecL'. Creates full measurement matrices.
%
% To be run from directory MtchVec (or where binary mvecL lies)
%
% ui in auto-correlating images, ie, the images of one category.
%
% IN   fpRGAA, fpRGBB   filenames of two registers
%      Admin            paths of measurement, program
%      Args             arguments
%
function [Ens DTY] = MVECLXLfull( fpRGAA, fpRGBB, Admn, Args, ...
                                    jStr, bPlot, bDisp )

aImgAA  = LoadTextLineWise( fpRGAA );  
aImgBB  = LoadTextLineWise( fpRGBB );  % loaded only to obtain list length

nAA     = length( aImgAA );
nBB     = length( aImgBB );

fprintf('MVECLXLfull %s:  %d x %d images...', jStr, nAA, nBB);

Ens.DM  = zeros(nAA, nBB, 'single');
Ens.SM  = Ens.DM;
DTY.ADM = cell( nAA, 1);
DTY.ASM = cell( nAA, 1);

% measurements per desctype (cannot be changed)
pthDisDty = Admn.fpMesDtyDis;
pthSimDty = Admn.fpMesDtySim;

for a = 1:nAA,

    fpImgAA   = aImgAA{a};

    %% ===========   MvecL   ============
    RennMvecL( fpImgAA, fpRGBB, Args, Admn.pthProg );

    % ensemble
    MesL        = LoadMtchMes( Admn.fpMesVec, nBB );
    Ens.DM(a,:) = MesL(:,1);        % distances
    Ens.SM(a,:) = MesL(:,2);        % similarities

    % per desctype
    DisDTY      = LoadMtchMESdty( pthDisDty ); % [nBB nDty]
    SimDTY      = LoadMtchMESdty( pthSimDty ); % [nBB nDty]
    DTY.ADM{a}  = DisDTY;
    DTY.ASM{a}  = SimDTY;

    if a==1 && bDisp
        fprintf('\n');
        DispLoad( pthDisDty );
        DispLoad( pthSimDty );
    end
    
    %% -----------   Plot   -------------
    if bPlot
        if a<5  ||  mod(a,5)==0
            % figure(1); clf;
            % plot(aDis); hold on;
            % plot(aDis2);
            figure(2); clf;
            subplot(1,2,1);
            imagesc(Ens.DM);
            colorbar;
            subplot(1,2,2);
            imagesc(Ens.SM);
            colorbar;
            pause(.1);
        end
    end
    if mod(a,20)==0
        fprintf('%d,', a);
    end
    
end

fprintf('\n');

StDM    = f_ArrStat( Ens.DM(:) );
StSM    = f_ArrStat( Ens.SM(:) );
DispArrStat( StDM, '    DM: ');
DispArrStat( StSM, '    SM: ');

end

