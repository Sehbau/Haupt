%
% Texture matching with bounding boxes for a list of images,
% one-versus-many.
%
% IN    fp1st   filepath of a saliency file
%       aFpSlc  register of saliency files
%
%
function Dis = f_MtxtL( fpMtxt1, fp1st, aFpSlc, mesFil )

dfLackBox   = 10e6;

nImg    = length( aFpSlc );
Dis     = zeros( nImg, 1, 'single');
for i = 1:nImg,  
   
    fpOth  = aFpSlc{i};

    cmnd   = sprintf('%s %s %s %s %1.2f', ...
        fpMtxt1, fp1st, fpOth, mesFil, dfLackBox );
    
    if ispc, cmnd = u_PathToBackSlash( cmnd ); end
    
    f_CmndExec( cmnd );
    
    DisTyp = LoadFltTxtEof( mesFil );

    Dis(i) = mean(DisTyp);

    %fprintf('.');
    
end
