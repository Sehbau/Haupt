%
% Cascade identifier, 1 vs many. Takes a query image and matches it to a
% list of reference images, called a register. Assumes we are running in
% folder 'MtchVec'.
%
% Stage 1:  fast matching with mhst or mkol. preselection
% Stage 2:  fine matching with mvec.
%
% cf lvngRunMcsc.m
%
% IN   FpExe    filepaths of executables. 
%      FpQuy    filepaths of query image (.dsc, .hst, .kolm)
%      Rgst     register. generated with o_RegistSetSave.m
%      Admn     paths, o_CascIdfPth.m
%      Args     command arguments
%      nImg     number of images
%
% OUT  Res      matching results
%      Sto      standard output of commands
%
function [Res Sto Fll] = CASCIDF( FpExe, FpQuy, Rgst, Admn, Args, Prm )

% created in o_RegistSetSave.m
fpaRgstHst	= Rgst.fpaHst;
fpaRgstKol 	= Rgst.fpaKol;
fpaRgstVec 	= Rgst.fpaDsc;

%fpaRgstVec      = Rgst.fpaDsc;

fpMesHst  	= Admn.fpMesHst;
fpMesKol  	= Admn.fpMesKol;
fpMesVec  	= Admn.fpMesVec;

nImg      	= Prm.nImg;

%% ------------------   STAGE 1 (FAST)   -------------------
% according to a selected strategy

if strcmp( Prm.stgy,'hist1st' ),
    % -----------   Histograms   -------------
    cmndHst = [ FpExe.mhstL ' ' FpQuy.hst ' ' fpaRgstHst ' ' fpMesHst ' ' Args.Hst ];

    Sto.Mhst = f_CmndExec( cmndHst );

    % load sorting and select
    [OrdHis DisHisOrd] = LoadSortFltTxt( fpMesHst, nImg );
    OrdPre	= OrdHis( 1:Prm.nPre );

    Res.DisHisOrd = DisHisOrd;

elseif strcmp( Prm.stgy,'kolm1st' ),
    % -----------   Kolumns   -------------
    cmndKol	= [ FpExe.mkolL ' ' FpQuy.kol ' ' fpaRgstKol ' ' fpMesKol ];

    Sto.Mkol = f_CmndExec( cmndKol );

    % load sorting and select
    [OrdKol DisKolOrd] = LoadSortFltTxt( fpMesKol, nImg );
    OrdPre	= OrdKol( 1:Prm.nPre );

    Res.DisKolOrd = DisKolOrd;

elseif strcmp( Prm.stgy,'ens' ),

    % we combine histograms and kolumns

    cmndHst = [ FpExe.mhstL ' ' FpQuy.hst ' ' fpaRgstHst ' ' fpMesHst ' ' Args.Hst ];
    cmndKol	= [ FpExe.mkolL ' ' FpQuy.kol ' ' fpaRgstKol ' ' fpMesKol ];

    Sto.Mhst        = f_CmndExec( cmndHst );
    Sto.Mkol        = f_CmndExec( cmndKol );

    % load UNsorted measurements array
    DisHisUor       = LoadFltTxt( fpMesHst, nImg );
    DisKolUor       = LoadFltTxt( fpMesKol, nImg );

    DisEns          = DisHisUor .* DisKolUor;
    [Dis OrdPre]    = sort( DisEns, 'ascend' );
    OrdPre          = OrdPre( 1:Prm.nPre );
    
else
    error('strategy %s not implemented', Prm.stgy );
end

Res.OrdPre    = OrdPre;

%% ------------------   STAGE 2 (FINE)   -------------------
nPre        = length( OrdPre );
% save reduced list
SaveFipaLstPrependPath( Rgst.aVec( OrdPre ), Rgst.pth, fpaRgstVec );

cmndVec     = [ FpExe.mvecL ' ' FpQuy.dsc ' ' fpaRgstVec ];
cmndVec     = [ cmndVec ' ' Args.Vec.fpPrm ' ' fpMesVec ];
if ~isempty( Args.Vec.opt )
    cmndVec = [ cmndVec ' ' Args.Vec.opt ];
end

Sto.Mvec    = f_CmndExec( cmndVec );

%Sto.Mvec

MesTot      = LoadMtchMes( fpMesVec, nPre );
MESdis      = LoadMtchMESdty( Admn.fpMesDtyDis );
MESsim      = LoadMtchMESdty( Admn.fpMesDtySim );

% --- keep full set of measurements for benchmarking
if Prm.mesFull > 0

    Fll.MesTot  = MesTot;
    Fll.MESdis  = MESdis;
    Fll.MESsim  = MESsim;
end

%% -------------------    Sort & Reorder   -----------------
% -----  total (MesTot)
Res.OrdDis  = uu_CascSortReorder( MesTot(:,1), 'ascend', OrdPre );
Res.OrdSim  = uu_CascSortReorder( MesTot(:,2), 'descend', OrdPre );

% -----  desctype (MESdis, MESsim)
nDty        = size(MESdis,2);
Res.ORDDty.Dis = zeros(nDty,nPre,'int32');
Res.ORDDty.Sim = zeros(nDty,nPre,'int32');
for d = 1:nDty

    Res.ORDDty.Dis(d,:) = uu_CascSortReorder( MESdis(:,d), 'ascend', OrdPre);
    Res.ORDDty.Sim(d,:) = uu_CascSortReorder( MESsim(:,d), 'descend', OrdPre );
    
end

% Res.OrdDis(1) is best ensemble index (distance)
% Res.OrdSim(1) is best ensemble index (similarity)
% Res.ORDDty.Dis(1,1) is best contour index (distance)
% Res.ORDDty.Sim(1,1) is best contour index (similarity)
% Res.ORDDty.Dis(2,1) is best rsg index (distance)
% Res.ORDDty.Sim(2,1) is best rsg index (similarity)

end

%% UUUUUUUUUUUUUUUUUUUUUUUUU   uu_CascSortReorder   UUUUUUUUUUUUUUUUUUUUUU
%
% Reorders the fine-matching indices according to the preselected indices
% from fast matching.
%
% IN   Mes     array of measurements, ie. from fine matching
%      dir     ascending | descending
%      OrdPre  preselected indices from fast matching
% OUT  OrdOrg  order of original indices (full set)
%
function OrdOrg = uu_CascSortReorder( Mes, dir, OrdPre )

[MesO, OrdFin] = sort( Mes, dir );

OrdOrg     = OrdPre( OrdFin );

end

