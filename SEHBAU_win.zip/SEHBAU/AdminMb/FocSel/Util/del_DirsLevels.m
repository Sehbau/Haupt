%
% Deletes content of level directorys 'Lev1', 'Lev2', ... 'Levn' (ie. for
% focii.), as created by dirsForLevels.m for example.
%
% PREVIOUS  dirsForLevels.m
% PRESENT   del_DirsLevels
% NEXT      
%
function [] = del_DirsLevels( pth, nLev )

    for l = 1:nLev
        
        pthLev  = [pth '/Lev' num2str(l) '/'];
        
        if ispc, % applied before in order to allow inclusion of option /Q
            pthLev = u_PathToBackSlash( pthLev );
        end
        
        cmnd    = sprintf('del /Q %s*.*', pthLev );
        
        
        fprintf('cmnd %s', cmnd );
        
        [Stu, Out] = system( cmnd );

        if Stu==0
            fprintf('.\n');
        else
            cmnd
            Out
            fprintf('Error - pausing'); pause();
        end
    end

end

