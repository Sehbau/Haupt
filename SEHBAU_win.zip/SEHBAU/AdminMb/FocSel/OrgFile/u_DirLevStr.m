%
% Creates string for level directory 'LevX'.
%
function s = u_DirLevStr(nLev)

    s = ['Lev' num2str(nLev) '/'];
    
end

