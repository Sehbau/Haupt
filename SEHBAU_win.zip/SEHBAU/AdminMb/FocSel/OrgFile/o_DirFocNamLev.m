% 
% Obtains filenames for focii for ONE structure (scene,object) for
% DIFFERENT levels for description files (dsf).
%
% Focii were generated with:
%
%   [imgNa '_Lev' num2str(Sz.nLev) '_f' num2str(cLev) '.vef'];
%
% IN   fips     filepathstem
%      Levs     levels, ie. [1,2,3,4]
% OUT  AFina    lists of filepaths {nLev}
%
% cf o_FocDir1 (lvngRunMovo.m)
%
function AFina = o_DirFocNamLev( fips, Levs )

    nLev  = length(Levs);

    AFina = cell( nLev, 1 );

    for l = 1:nLev

        lev      = Levs(l);
        AFina{l} = dir( [fips '_Lev' num2str(lev) '_f*.dsf' ] );

    end

end


        
