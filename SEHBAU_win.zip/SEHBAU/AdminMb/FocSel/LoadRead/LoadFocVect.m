function [V Floc Kt] = LoadFocVect(lfn) 

error('Deprecated. Use LoadFocDesc instead');