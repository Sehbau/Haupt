% 
% Loads a list of one-sample histograms, given a register.
%
% cf nyuAnnCollHst.m
%
function S = LoadFocHistList( aRgst, NLEVARH )

nFinas  = length(aRgst);
fprintf('%4d instances', nFinas);

S.HST   = [];                       % initialized below in loop
S.Nlev  = zeros(nFinas,1,'uint8');

if nFinas==0                        % no filenames
    S.nInst = 0;
    S.KtLab = [];
    S.ntLev = 0;
    S.nBins = 0;
    return;
end
    
for i = 1:nFinas
    
    % --- load ---
    [HFU HFB Nunf Nbif Floc] = LoadFocHist( aRgst{i} );
    
    S.Nlev(i)   = Floc.nLev;
    
    % ==========   convert   ==========
    [H1 len]    = u_HistCatFlat( HFU, HFB );

    % ----------   A2MX   ----------
    if i==1
        S.HST   = zeros( nFinas, len.tot, 'single' );
        S.nBins = len.tot;
    end
    
    S.HST(i,:) = H1;

    % --- progress ---
    if mod(i,50)==0, fprintf('.'); end
end

%% -----------------   Stats   ------------------
S.KtLab = histcounts(S.Nlev, 'BinLimits', [1 8]);
S.nInst = nFinas;
S.ntLev = max(S.Nlev);

% --- display
minLev  = min(S.Nlev);
fprintf('\n\tnLevs: %d-%d: ', minLev, S.ntLev);
for l = 1:S.ntLev
    fprintf('%4d ', S.KtLab(l));
end
fprintf('\n');

assert(all(minLev>0));             % all must have at least 1 level
assert(all(S.ntLev<=NLEVARH));     % larger mxnLev should not occur

end

