%
% Load as saved as with si_SalcZUSG in SalncyIO.h
%
% used only for testing, ie. in cc_CntItgr.m
%
% see LoadDescSalc.m for production saliency.
%
function Z = LoadSalcAly( lfp )

%% -----------   Open   ------------
fileID      = fopen(lfp, 'r');
if fileID<0, error('Could not open file %s', lfp); end
DispLoad( lfp );

%% ------------   Header  -----------
DimYtg      = ReadYtgDim( fileID );

nRix        = DimYtg.nRix;
assert(nRix>0 && nRix<5000, 'nRix0 not reasonable: %d', nRix);

%% ------------   Data  -----------
[Z]       	= ReadBlobMapGlbSts( fileID );

Z.PX.DomKntImg  = ReadPixvRCi( fileID );
Z.PX.DomCtrImg  = ReadPixvRCf( fileID );
Z.PX.DomKntLay  = ReadPixvRCi( fileID );
Z.PX.DomCtrLay  = ReadPixvRCf( fileID );

Z.BlobImg   = ReadBlobOut( fileID, 1 );
Z.BlobLay   = ReadBlobOut( fileID, 1 );

%X.Fru.ATop  = ReadMapTopoSpc( fileID ); %, nLay );
%X.Fru.Ctr   = ReadMapTopo( fileID );   % one map only
%X.Img.ATop  = ReadMapTopoSpc( fileID ); %, nLay );
%X.Img.Ctr   = ReadMapTopo( fileID );   % one map only

%S.Mdff      = fread( fileID, nRix0, 'float=>single' );
%S.Mdff      = reshape( S.Mdff, szM(2), szM(1) )';
Z.Mdff      = ReadMapGen( fileID, DimYtg.szL, 'float=>single' );

%PRP.ABxCntBlob = ReadBboxLbin( fileID );

%% ------------   Close   -----------
fclose( fileID );


