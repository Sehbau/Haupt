%
% Loads saliency and statistics as saved as with si_DescSal in DescIOsal.h
%
% cf iclSalcAly.m, exsbSmlObjDet.m, ...
%
function [S Hed] = LoadDescSalc( lfp )

bIxOne = 1;                 % we are in Matlab and use one-indexing

%% -----------   Open   ------------
fileID      = fopen(lfp, 'r');
if fileID<0, error('Could not open file %s', lfp); end

%% ------------   Header   -----------
Hed         = ReadSalcFileHead( fileID, 33 );

%% ------------   Saliency  -----------

% ----  Global Statistics  ----
S.Txa.Gst   = ReadBlobMapGlbSts( fileID ); % map stats

% ----  Blobs  ----
% blob outlines (bboxes & asps)
S.Txa.Blb   = ReadBlobOut( fileID, bIxOne  );       

% ----  Shapes  ----
% shape outlines (bboxes & asps)
S.Shp      	= ReadShpOut( fileID, bIxOne );  

% ----  Spots  ----
S.Txa.Spt	= ReadPixvRCf( fileID );
S.Txa.Bnt   = ReadPixvRCf( fileID );
S.Txa.mxBnt	= fread(fileID, 1, 'float=>single');    

idf         = fread(fileID, 1,  'int=>int');    % identifier
if idf~=-11111, error('idf incorrect'); end

% ----   Ensemble  ----
S.Ens       = ReadSalcBbxEns( fileID );


%% ------------   DescStats   -------------
S.Dsc       = ReadDescStats( fileID );

%% ------------   Close   -----------
fclose( fileID );

%DispLoad( lfp );


