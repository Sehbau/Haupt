%
% File extensions with two output structures: one for description of image
% and one for focus.
%
% ia Fixt
%
% from struct stuFileExtn in FileNameDesc.h
%
function [D F] = o_FileExtensions()

%% -------------   IMAGE   ---------------
% -----  contours
D.dscRRE = '.dscRRE';   % full set
D.cntEpt = '.cntEpt';

% -----  image 
D.dsc    = '.dsc';
D.dsbi   = '.dsb';
D.hsti   = '.hst';
%D.utzi   = '.utz';		% utilities (deployed yet?)

D.kolm   = '.kol';		% kolumns
D.txtm   = '.txm';		% texture maps
D.salc   = '.slc';		% saliency 

D.qbbx   = '.qbbx';		% proposals bbox
D.qdsc   = '.qdsc';		% proposals descriptors

D.cvpo   = '.cvpo';		% curve partitions organization (deployed yet?)

% -----  features
D.regPix = '.regPix';  
D.bonDsc = '.bonDsc';
D.bonPix = '.bonPix';

D.bonBbxRaw = '.bonBboxRaw'; % s_FunvBboxAll, ai dscx.cpp
D.bonBbx    = '.bonBbox';  % s_BonBboxPyr
D.bonAsp    = '.bonAsp';

% -----  shape
D.shp    = '.shp';

% -----  collection/conversion
D.collHst = '.hstc';    % collHimg
D.collSlc = '.slcc';    % saliency collection
D.hari    = '.hari';    % Hst-Of-Att as array for image
D.vbnmx   = '.vbnmx';
D.qnt     = '.qnt';

% -----  maps
D.mapUch  = '.mpu';

%% -------------   FOCUS   ---------------
F.dscf   = '.dsf';
F.hstf1  = '.hsf1'; 	% fochst1.cpp
F.hstfL  = '.hsfL';

% -----   conversion
F.harf   = '.harf';    % Hst-Of-Att as array for focus





