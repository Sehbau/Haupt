%
% Appends file extensions to a filename.
%
% Use o_FinaApndExtXXX
%
function [N] = o_FileExtnApnd( pth, F )

warning('deprecated. use o_FinaApndExtXXX')

aFexts  = fieldnames( F );
nFexts  = length( aFexts );

for f = 1 : nFexts
    
    fxt     = aFexts{f};
    
    N.(fxt) = [ pth F.(fxt) ];
end