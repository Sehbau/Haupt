%
% Plots a list of tetragon polygons from struct of arrays. Allows upscaling
% coordinates if the are normalized.
%
% Coordinates in TTG are:
% - absolute if from description file: then dont provide szM 
% - normalized to range if from proposal file (LoadDescPropAtts): then 
%   provide map size in szM to upscale.
%
function [] = p_TtrgLst( TTG, szM )

colOrng = [255 128   0] / 255;  % orange
colBlue = [0   0   255] / 255;  % blue

if nargin==1
    szV     = 1;
    szH     = 1;
else
    szV     = single(szM(1));
    szH     = single(szM(2));
end

nTtg    = TTG.nTtg;

for t = 1:nTtg
    
    [Axe Cor Ttg] = u_TtrgRtrv1( TTG, t );
        
    %% ---  polygon  ---
    hp  = plot( Cor.Cl*szH, Cor.Rw*szV, 'color', colOrng );

    % --- elo-axes 
    hp  = plot( Axe.Cl*szH, Axe.Rw*szV, 'color', colBlue );

    % --- boundary pole
    %plot( Tg.hor*szM(2), Tg.vrt*szM(1), '.', 'color', rgb);
    
end
    


end

