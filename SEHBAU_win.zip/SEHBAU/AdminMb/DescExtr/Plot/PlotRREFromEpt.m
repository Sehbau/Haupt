%
% Plots the RRE contours for an entire space using endpoints only.
%
% Since contours are in absolute coordinates, plotting for a pyramid
% requires adjustment, which is done here by downscaling the image.
%
% IN  RRE     RRE spaces
%     Irgb    the image
%     Hed     header
%     figNo   figure number
%
function [] = PlotRREFromEpt( RRE, Irgb, Hed, figNo )

nLev    = length( RRE.ARDG );

fprintf('Plotting contours for %d levels...', nLev); 

figure(figNo); clf;
[nr nc]  = deal( ceil(nLev/2), 2 );     % # of rows/cols for subplots

for l = 1:nLev
    
    subplot(nr, nc, l);
    
    if Hed.space==1
        % if pyramid, then downscale
        imagesc( imresize( Irgb, 1 / 2^(l-1)) ); 
    else
        imagesc( Irgb );
    end

    Rdg = RRE.ARDG{l};
    Riv = RRE.ARIV{l};
    Edg = RRE.AEDG{l};

    p_CntFromEpt( Rdg, 'r', 'abs');     % ridges
    p_CntFromEpt( Riv, 'b', 'abs');     % rivers
    p_CntFromEpt( Edg, 'c', 'abs');     % edges

    set(gca,'fontsize',5);
    
end
fprintf('done\n');


end

