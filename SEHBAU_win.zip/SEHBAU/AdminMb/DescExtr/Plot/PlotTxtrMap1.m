%
% Plots one texture map into one figure, with or without bounding boxes.
%
% IN    Map        any map in principle
%       SBbxLay    the corresponding bounding boxes
%
function [] = PlotTxtrMap1( Map, figNo, Irgb, titStr, SBbxLay )

if nargin==5, bBbx = 1; else bBbx = 0; end


figure(figNo); clf;
[nr nc] = deal(2,1);

subplot(nr,nc,1);
imagesc( Irgb );
set(gca,'fontsize',5);


subplot(nr,nc,2);
imagesc( Map ); title( titStr );
if bBbx, p_BboxL( SBbxLay.Num ); end

end

