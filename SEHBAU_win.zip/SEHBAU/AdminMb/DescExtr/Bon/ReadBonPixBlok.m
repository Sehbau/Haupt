%
% Loads as saved under B_BON/Util/BonIO.h-w_BonPixBlok().
%
function [S] = ReadBonPixBlok( fileID ) 

%% ====  sizes  ====
nBon    = fread(fileID, 1, 'int=>single');
szM     = fread(fileID, 2, 'int=>single'); 

fprintf('[%4d %4d] nBon %4d', szM(1), szM(2), nBon);
    
%% ====  pixels  ====
S.Anf   = fread(fileID, nBon, 'int32=>single') +1; % turn into one-indexing
S.Npx   = fread(fileID, nBon, 'int32=>single');

S.Pix   = ReadPixRCs( fileID );

S.nBon  = nBon;
S.szM   = szM;

    
idf     = fread(fileID, 1, 'int=>single');

assert(idf==627, 'Perhaps you wanted to load ReadBonPixSegw?');

fprintf('\n');


