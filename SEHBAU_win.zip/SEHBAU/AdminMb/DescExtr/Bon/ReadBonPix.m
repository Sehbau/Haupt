
function [APix nBon szM Org] = ReadBonPix( fileID ) 

fclose(fileID);

error('use ReadBonPixSegw | ReadBonPixBlok');



