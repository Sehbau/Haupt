%
% Plots a list of boundaries in ij format using function p_BoundPix1ToImg.
%
% IN    APix    a cell of boundaries
%       col     color
%
function [] = p_BoundPixLij( APix, col )

nBon = length(APix);

bJit = 0;

for b = 1:nBon

    Pix    = APix{b};

    p_BoundPix1ToImg( Pix, col, 1, bJit );
end


end

