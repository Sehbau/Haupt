%
% Reads shape histograms as saved under ShpIO.h-w_ShpHist
%
% cf LoadDescHist.m
%
function [Hcat Nbin] = ReadShpHist( fileID )

Nbin    = struct;

HScors  = ReadMtrxDat( fileID, 'int32=>single' );
HSfine  = ReadMtrxDat( fileID, 'int32=>single' );
HRas    = ReadMtrxDat( fileID, 'int32=>single' );
HAto    = ReadMtrxDat( fileID, 'int32=>single' );

%HScors = u_FieldsCatToMxInt( Scors );
%HSfine = u_FieldsCatToMxInt( Sfine );
%HRas   = u_FieldsCatToMxInt( Ras );
%HAto   = u_FieldsCatToMxInt( Ato );

Hcat   = [ HScors(:)' HSfine(:)' HRas(:)' HAto(:)' ];

end

