%
% Reads shape histograms as saved under ShpIO.h-w_ShpHist
%
% cf LoadDescHist.m
%
function [Hcat Nbin] = ReadShpHist( fileID )

Nbin    = struct;

HScors  = ReadMtrxInt( fileID );
HSfine  = ReadMtrxInt( fileID );
HRas    = ReadMtrxInt( fileID );
HAto    = ReadMtrxInt( fileID );

%HScors = u_FieldsCatToMxInt( Scors );
%HSfine = u_FieldsCatToMxInt( Sfine );
%HRas   = u_FieldsCatToMxInt( Ras );
%HAto   = u_FieldsCatToMxInt( Ato );

Hcat   = [ HScors(:)' HSfine(:)' HRas(:)' HAto(:)' ];

end

