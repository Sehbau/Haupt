%
% Reads bundle histograms.
%
% cf LoadDescHist.m
%
function [Hcat Nbin] = ReadBndgHist( fileID )

HGeom   = ReadMtrxDat( fileID, 'int32=>single' );
%Lage   = ReadFieldsInt( fileID );
%Angs   = ReadFieldsInt( fileID );
%Dicv   = ReadFieldsInt( fileID );

%Hgeom  = u_FieldsCatToMxInt( Geom );
%Hlage  = u_FieldsCatToMxInt( Lage );
%Hangs  = u_FieldsCatToMxInt( Angs );
%HDicv  = u_FieldsCatToMxInt( Dicv );

Nbin   = struct;
Nbin.ori = fread(fileID, 1,  'int=>int');
H.Ori  = fread(fileID, Nbin.ori, 'int=>int');


Hcat   = [ HGeom(:)' H.Ori(:)'];
%Hcat   = [ Hgeom(:)' Hlage(:)' Hangs(:)' HDicv(:)' H.Ori(:)'];

end

