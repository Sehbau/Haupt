%
% Reads tetragon histograms.
%
% cf LoadDescHist.m
%
function [Hcat Nbin] = ReadTtrgHist( fileID )

HGeom   = ReadMtrxDat( fileID, 'int32=>single' );
HLage   = ReadMtrxDat( fileID, 'int32=>single' );
HAngs   = ReadMtrxDat( fileID, 'int32=>single' );
HDicv   = ReadMtrxDat( fileID, 'int32=>single' );

%Hgeom  = u_FieldsCatToMxInt( Geom );
%Hlage  = u_FieldsCatToMxInt( Lage );
%Hangs  = u_FieldsCatToMxInt( Angs );
%HDicv  = u_FieldsCatToMxInt( Dicv );

Nbin    = struct;
Nbin.ori = fread(fileID, 1,  'int=>int');
H.Ori   = fread(fileID, Nbin.ori, 'int=>int');


Hcat    = [ HGeom(:)' HLage(:)' HAngs(:)' HDicv(:)' H.Ori(:)'];
    
end

