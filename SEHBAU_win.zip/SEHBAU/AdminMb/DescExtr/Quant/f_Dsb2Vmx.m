%
% Forms vectors of binned attribute values, for ONE image and all
% desctypes. Also called bin-vectors.

% Precursor of binary dbn2vmx
%
% Currently only creating a subset of the full (potential) space.
%
% When we call this function from function f_CollBinDty, we need only one
% desctype per call. We create in here all desctypes nevertheless for
% convenience. (it would be annoying to include if statements for the
% collection process).
% 
% cf f_CollBinDty.m, plcQntHist.m
%
% If you change here then adjust.
%   1)  struct V in init section below
%   2)  Variable NexpAtt in plcCollVecBin.m
%
% IN   I    struct with binned attributes values of one image 
% OUT  V    struct with bin-vectors, concatenated across descspace
%      L    struct with label array for levels
%
function [V L] = f_Dsb2Vmx( I )

nLev    = length( I.CNT );

%% ----------------   Init   -----------------
V.Cnt   = zeros( 0, 3,'uint8');
V.Rsg   = zeros( 0, 5,'uint8');
V.Arc   = zeros( 0, 7,'uint8');
V.Str   = zeros( 0, 3,'uint8');
V.Shp   = zeros( 0, 2,'uint8');
V.Crm   = zeros( 0, 3,'uint8');

L.Cnt   = zeros(0,1,'uint8');
L.Rsg   = zeros(0,1,'uint8');
L.Arc   = zeros(0,1,'uint8');
L.Str   = zeros(0,1,'uint8');
L.Shp   = zeros(0,1,'uint8');
L.Crm   = zeros(0,1,'uint8');

%% -----------------   LOOP LEVELS   -------------------
for l = 1:nLev

    % --------------   Contours   -------------
    B     = I.CNT.AUNI{l};           
    V.Cnt = [ V.Cnt;  [ B.Les B.Str B.Ori ] ];
    
    L.Cnt = [ L.Cnt ones(1,B.nCnt)*l ];
        
    % --------------   Chromatics   -------------
    V.Crm = [ V.Crm;  [ B.Red B.Grn B.Blu ] ];
    
    L.Crm = [ L.Crm ones(1,B.nCnt)*l ];
    
    
    % --------------   RadSig   -------------
    B     = I.RSG{l};
    V.Rsg = [ V.Rsg; [ B.Rds B.Elo B.Ori B.Cir B.Cncv ] ];
    
    L.Rsg = [ L.Rsg ones(1,B.nRsg)*l ];
        
    
    % --------------   Arcs   -------------
    B     = I.ARC{l};
    V.Arc = [ V.Arc; [ B.Les B.Krv B.Dir B.Spz B.Eck B.Ifx B.Run ] ];
    
    L.Arc = [ L.Arc ones(1,B.nArc)*l ];
        
    
    % --------------   Strs   -------------
    B     = I.STR{l};
    V.Str = [ V.Str; [ B.Les B.Str B.Ori ] ];
    
    % !! nCnt !! because loading routine was cnt
    L.Str = [ L.Str ones(1,B.nCnt)*l ]; 


    % --------------   Shps   -------------
    B     = I.SHP{l};
    V.Shp = [ V.Shp; [B.Scors(:,1) B.Ras(:,1) ] ];

    nShp  = size(B.Scors,1);
    L.Shp = [ L.Shp ones(1, nShp )*l ]; 

end

end






