%
% Calculates histograms of quant ids.
%
% Consider renaming to hst_QntImg
%
% cf plcQntHist.m
% 
% IN  QID   quant ids, struct with desctypes
%     Nqnt  number of quants per desctype
% OUT H     histogram of quants, struct with desctypes
%
function H = f_HistQntImg( QID, Nqnt )

H.Cnt  = single( histcounts( QID.Cnt, Nqnt.Cnt ) );
H.Rsg  = single( histcounts( QID.Rsg, Nqnt.Rsg ) );
H.Arc  = single( histcounts( QID.Arc, Nqnt.Arc ) );
H.Str  = single( histcounts( QID.Str, Nqnt.Str ) );
H.Shp  = single( histcounts( QID.Shp, Nqnt.Shp ) );

%H.Crm  = single( histcounts( QID.Crm, Nqnt.Crm ) );

end






