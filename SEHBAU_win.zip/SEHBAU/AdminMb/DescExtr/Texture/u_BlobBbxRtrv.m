%
% Retrieves blob bboxes from struct and scales if desired.
%
% SclFct calculated in LoadDescSalc.m
%
function [S] = u_BlobBbxRtrv( BxAll, aLb, SclFct )

nTyp        = length( aLb );
mxTyp       = max( BxAll.Typ );

bScale      = 0;
if nargin==3
    bScale = 1;
end

assert( mxTyp <= 9, 'Somehow too many types' );

for i = 1:nTyp

    Bsel        = BxAll.Typ==i;
    
    Bbx         = single( BxAll.Box(Bsel,:) );

    % Scale from original resolution to layer resolution
    if bScale
        Bbx(:,1) = Bbx(:,1) * SclFct(1);
        Bbx(:,2) = Bbx(:,2) * SclFct(1);
        Bbx(:,3) = Bbx(:,3) * SclFct(2);
        Bbx(:,4) = Bbx(:,4) * SclFct(2);
    end
    
    lb          = aLb{i}; 

    S.( lb )    = Bbx;

end

end

