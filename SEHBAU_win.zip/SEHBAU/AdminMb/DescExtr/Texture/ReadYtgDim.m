% 
% Reads integration parameters as saved under w_YtgDim in YtgAnf.h
%
% af ReadFruPrms.m
%
function P = ReadYtgDim( fileID )

P.szL    = fread( fileID, 2, 'int32=>int32');   % layer (map) size
P.szFll  = fread( fileID, 2, 'int32=>int32');   % original image size
P.winSiz = fread( fileID, 1, 'uint8=>int8');    % window size

P.vrtToCvd = fread( fileID, 1, 'float=>single'); % scale factors to full
P.horToCvd = fread( fileID, 1, 'float=>single'); %   "      "     "   "

assert( P.winSiz > 4 && P.winSiz < 256, ...
    'window size unreasonable: %d', P.winSiz );

P.szL   = P.szL';               % make row vector
P.nRix  = P.szL(1) * P.szL(2);  % number of rixels    

end





