% 
% Load texture maps as saved under s_CntYtgMaps
%
% OUT   M.KNT   count maps
%       M.OTX   orientation maps
%       M.SAL   saliency maps
%       M.CRM   chromatic maps
%
function M = LoadTxtrMaps( lfp )

%% -----------   Open   ------------
fileID          = fopen(lfp, 'r');
if fileID<0, error('Could not open file %s', lfp); end

%% ============   HEADER   =============
Dim             = ReadYtgDim( fileID );
szL             = Dim.szL;

%% ============   Maps Count   =============
M.KNT.Num   	= ReadMapGen( fileID, szL, 'int16=>int16' );
M.KNT.Blk   	= ReadMapGen( fileID, szL, 'int16=>int16' );
M.KNT.DomNum    = ReadMapGen( fileID, szL, 'int16=>int16' );
M.KNT.DomEnk	= ReadMapGen( fileID, szL, 'float=>single' );

M.szM           = szL;

%% ============   Maps Txt & Sal   =============

% orientation texture (NOT blob biases, see ReadOtxMAPsts)
M.OTX           = ReadStcMapFlt( fileID, ...
                {'Vrt' 'Hor' 'Dg1' 'Dg2' 'Axi' 'Nil' 'Uni'}, szL );

% saliency maps (cntSalMaps)
M.SAL           = ReadStcMapFlt( fileID, {'Len' 'Ctr' 'Enk' 'Bgt' 'Drk'}, szL );

% chromatic maps
M.CRM.Red       = ReadStcMapFlt( fileID, {'Min' 'Max' 'Sum'}, szL );
M.CRM.Grn       = ReadStcMapFlt( fileID, {'Min' 'Max' 'Sum'}, szL );
M.CRM.Blu       = ReadStcMapFlt( fileID, {'Min' 'Max' 'Sum'}, szL );

%% ============   Trailer   =============
idf             = fread( fileID, 1, 'int=>int' ); % load identifier

%% ------------   Close   -----------
fclose( fileID );

assert( idf==826, 'idf incorrect. Is %d, but should be 826', idf );

end




