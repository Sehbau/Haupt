%
% Plots the chromatic maps
%
function [] = p_TxtrColMaps( M )

RED         = M.Red;
GRN         = M.Grn;
BLU         = M.Blu;

[nr,nc] = deal( 4, 3);

%% -------------------   MEAN   ----------------
subplot(nr,nc,1); 
imagesc(RED.Men,[0 1]);
colorbar();
ylabel('Mean');
title(['Red ' sprintf('%1.3f', mean(RED.Men(:)))])

subplot(nr,nc,2); 
imagesc(GRN.Men,[0 1]);
colorbar();
title(['Grn ' sprintf('%1.3f', mean(GRN.Men(:)))])

subplot(nr,nc,3); 
imagesc(BLU.Men,[0 1]);
colorbar();
title(['Blu ' sprintf('%1.3f', mean(BLU.Men(:)))])

%% -------------------   MAX   ----------------
subplot(nr,nc,4); 
imagesc(RED.Max,[0 1]);
colorbar();
ylabel('Max');
titleVal('', RED.Max );

subplot(nr,nc,5); 
imagesc(GRN.Max,[0 1]);
titleVal('', GRN.Max(:));
colorbar();

subplot(nr,nc,6); 
imagesc(BLU.Max,[0 1]);
titleVal('', BLU.Max(:));
colorbar();

%% -------------------   MIN   ----------------
sclMin = [0 0.5];

subplot(nr,nc,7); 
imagesc(RED.Min,sclMin);
colorbar(); p_Cross(128);
ylabel('Min');
%f_ArrStat( RED.Min(:) )
titleVal('', RED.Min );

subplot(nr,nc,8); 
imagesc(GRN.Min,sclMin);
colorbar(); p_Cross(128);
titleVal('', GRN.Min(:));

subplot(nr,nc,9); 
imagesc(BLU.Min,sclMin);
titleVal('', BLU.Min(:));
colorbar(); p_Cross(128);

%% -------------------   SDV   ----------------
subplot(nr,nc,10); 
imagesc(RED.Sdv,[0 1]);
colorbar(); p_Cross(128);
ylabel('Sdv');
%f_ArrStat( RED.Sdv(:) )
titleVal('', RED.Sdv );

subplot(nr,nc,11); 
imagesc(GRN.Sdv,[0 1]);
colorbar(); p_Cross(128);
titleVal('', GRN.Sdv(:));

subplot(nr,nc,12); 
imagesc(BLU.Sdv,[0 1]);
titleVal('', BLU.Sdv(:));
colorbar(); p_Cross(128);

end

