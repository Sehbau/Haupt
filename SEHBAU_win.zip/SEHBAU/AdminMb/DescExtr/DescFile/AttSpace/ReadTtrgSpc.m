%
% Reads a space of tetragon attributes as saved under w_PaarSpc in PaarIO.h
%
function [ATTG Nttg] = ReadTtrgSpc(fid)

[nLev Nttg] = ReadDescSpcHead( fid );

ATTG  = cell(nLev,1);
for l = 1:nLev

    [ATTG{l} nTtg] = ReadTtrgAtt(fid);

    assert( Nttg(l)==nTtg, 'ttg count not matching' );

end

end

