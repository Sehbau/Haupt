%
% Reads arc attributes as saved under ArcIO.h-w_ArcAtt
%
% cf ReadArcSpc.m
%
function [S nArc] = ReadArcAtt(fileID)

S = [];

Hed     = ReadDescAttHead(fileID);
nArc    = Hed.nDsc;

% =====   Geometry   =====
S.Geo   = ReadStcArr( fileID, 'float=>single', ...
                {'Krv' 'Les' 'Spz' 'Eck' 'Run' 'Ifx'} );

S.Smo 	= fread(fileID, nArc, 'float=>single'); % smoothness
S.Am1   = fread(fileID, nArc, 'float=>single'); 
S.Am2   = fread(fileID, nArc, 'float=>single'); 

% =====   Appearance   =====
S.RGB   = ReadAttRgb(fileID, nArc);
%S.Ctr  = fread(fileID, nCnt, 'float=>single'); % contrast

% =====   Position   =====
S.Dir   = fread(fileID, nArc, 'float=>single');
S.Pos   = ReadAttPos(fileID);

% =====   Origin   =====
S.Orgn 	= ReadDescOrgn(fileID, nArc);
S.Pts  	= ReadDescPtsS(fileID);
%S.OrgCrv = fread(fileID, nArc, 'int=>int');     % boundary index/label
%S.OrgDth = fread(fileID, nArc, 'uint8=>uint8'); % depth map

% =====   Trailer   =====
idf    = fread(fileID, 1, 'int16=>int');
assert(idf==3333);

S.nArc = nArc;
if nArc==0, return; end

%% ---- Further verification
assert(max(S.Orgn.OrgDth)<6); % more than 5 depths is unfeasible

end
