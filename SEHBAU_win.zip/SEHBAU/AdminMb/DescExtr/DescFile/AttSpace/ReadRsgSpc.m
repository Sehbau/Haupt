%
% Reads space of radsig attributes as saved under RsgIO.h-w_RsgSpc
%
function [ARSG Nrsg] = ReadRsgSpc(fid)

[nLev Nrsg] = ReadDescSpcHead( fid );

ARSG  = cell(nLev,1);
for l = 1:nLev
    
    [ARSG{l} nRsg] = ReadRsgAtt(fid);

    assert( Nrsg(l)==nRsg, 'rsg count not matching' );

end

end

