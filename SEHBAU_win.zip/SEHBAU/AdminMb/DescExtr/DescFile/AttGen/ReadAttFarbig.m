%
% Reads as written by w_CntFarbig (CntIO.h)
%
% cf ReadDescStats.m
%
function [S] = ReadAttFarbig( fid )

S.Sprd      = ReadRgbSpread( fid );
S.PixRed  	= ReadPixRCs( fid );
S.IxRed     = ReadIxvArr( fid );

end

