%
% Reads str bins as saved under StrIObin.h-w_StrBin1D
%
function [S nStr] = ReadStrBinUni(fileID)


% not operating yet. because we did not write as rack.



S       = [];

%%  ====================   Header   ====================
nStr    = fread( fileID, 1, 'int=>single'); % # descriptors
S.nStr  = nStr;

%%  ====================   Data   ====================
Lb      = {'Les' 'Str' 'Ori' 'Red' 'Grn' 'Blu'};
S       = ReadStcArrInt( fileID, Lb );

end

