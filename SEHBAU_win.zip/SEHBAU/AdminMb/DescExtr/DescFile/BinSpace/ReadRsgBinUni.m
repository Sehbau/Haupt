%
% Reads radsig bins as saved under RsgIObin.h-w_RsgBin1D
%
function [S nRsg] = ReadRsgBinUni(fileID)

S       = [];

%%  ====================   Header   ====================
nRsg    = fread( fileID, 1, 'int=>single'); % # descriptors
S.nRsg  = nRsg;

%%  ====================   Data   ====================

% =====   Geometry   =====
S.Rds   = fread(fileID, nRsg, 'int=>int32');
S.Elo   = fread(fileID, nRsg, 'int=>int32');
S.Cir   = fread(fileID, nRsg, 'int=>int32'); 
S.Ori   = fread(fileID, nRsg, 'int=>int32'); 
S.Cncv  = fread(fileID, nRsg, 'int=>int32'); 

% =====   Appearance   =====
S.Red   = fread(fileID, nRsg, 'int=>int32'); % red
S.Grn   = fread(fileID, nRsg, 'int=>int32'); % green
S.Blu   = fread(fileID, nRsg, 'int=>int32'); % blue



end

