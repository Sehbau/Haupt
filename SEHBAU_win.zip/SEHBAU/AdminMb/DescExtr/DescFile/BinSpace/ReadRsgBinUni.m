%
% Reads radsig bins as saved under RsgIObin.h-w_RsgBin1D
%
function [S nRsg] = ReadRsgBinUni( fid )

S       = [];

%%  ====================   Header   ====================
nRsg    = fread( fid, 1, 'int=>single'); % # descriptors
S.nRsg  = nRsg;

%%  ====================   Data   ====================
[S szD]     = ReadMtrxDat( fid, 'int=>int32');

if 0
% =====   Geometry   =====
S.Rds   = fread(fid, nRsg, 'int=>int32');
S.Elo   = fread(fid, nRsg, 'int=>int32');
S.Cir   = fread(fid, nRsg, 'int=>int32'); 
S.Ori   = fread(fid, nRsg, 'int=>int32'); 
S.Cncv  = fread(fid, nRsg, 'int=>int32'); 

% =====   Appearance   =====
S.Red   = fread(fid, nRsg, 'int=>int32'); % red
S.Grn   = fread(fid, nRsg, 'int=>int32'); % green
S.Blu   = fread(fid, nRsg, 'int=>int32'); % blue
end


end

