%
% Reads shape bins as saved under ShpIObin.h-w_ShpBinUni
%
% af ReadShpAtt.m
%
function [S nShp] = ReadShpBinUni(fileID)

%%  ====================   Header   ====================
%nShp    = fread( fileID, 1, 'int=>single'); % # descriptors

%%  ====================   Data   ====================
[S.HScors szD]  = ReadMtrxDat( fileID, 'uint8=>single' );
S.HSfine        = ReadMtrxDat( fileID, 'uint8=>single' );
S.HRas          = ReadMtrxDat( fileID, 'uint8=>single' );
S.HAto          = ReadMtrxDat( fileID, 'uint8=>single' );

nShp   = szD.nObs;

end

