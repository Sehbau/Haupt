
function O = o_OptDscxStc()

error('discontinued:  use o_DscxArgs now');


end

