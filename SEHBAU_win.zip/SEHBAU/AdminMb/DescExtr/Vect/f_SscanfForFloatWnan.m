%
% Scans a text line for float with NaN using the combination of sscanf and
% num2str.
%
function [A] = f_SscanfForFloatWnan( Lin, neNum ) 

%% ------   Sscanf   -------
[aStr nRead errmsg] = sscanf( Lin, '%s' );

if nRead ~= neNum
    % if that does not work, then what else?
    aStr 
    nRead

    errmsg
end

%% ------   Num2Str   -------
Bspc    = isspace(Lin);
nSpc    = nnz( Bspc );
IxSpc   = [0 find(Bspc) length(Lin)+1];

A   = zeros( nRead, 1, 'single');
for n = 1:nRead
    
    str     = Lin( IxSpc(n)+1 : IxSpc(n+1)-1 );
    %str
    %[f nScnf] = sscanf('%s', str );
    % nScnf
    num = str2double( str );
    
    if isempty(num)
        A(n) = single(nan);
    else
        A(n) = single(num);
    end
end



