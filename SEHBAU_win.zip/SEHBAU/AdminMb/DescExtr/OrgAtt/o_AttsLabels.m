%
% Attribute names (labels) for a descriptor. Some are specified as a list
% of strings, others as a single string that is turned into a list.
%
% An attribute label has at most 6 characters. 
%
% cf LoadDescVect.m, LoadCollVec.m, exsbPlotShape.m, f_ShpAlySpc.m
%
function [LB Lshp] = o_AttsLabels()


%% ----------   contour   ---------  8
LB.Cnt = {'len' 'str' 'ori' 'vpo' 'hpo'   'red' 'grn' 'blu'};
LB.Skl = LB.Cnt;

%% ----------   radial signature   ----------  10 + 7
LB.Rsg = {'rad' 'cir' 'eloR' 'eloF' 'cncv'   'bs1' 'bs2' 'bs3' 'bs4' 'bs5'...
          'star' 'dent' 'vpo' 'hpo' 'red'    'grn' 'blu'};

%% ----------   arc   ---------  9 + 5
LB.Arc = {'len' 'krv' 'dir' 'am1' 'am2'   'smo' 'spz' 'run' 'eck' ...
          'vpo' 'hpo' 'red' 'grn' 'blu' };
      
%% ----------   str   ---------  10 + 5
LB.Str = {'les' 'str' 'ifx' 'wig' 'bog'   'amp' 'smo' 'vpo' 'hpo' 'red' ...
          'grn' 'blu'};
        
%%  ---------    bndg   ---------  10      
LB.Bndg = {'len' 'agx' 'tig' 'dns' 'ori'   'vpo' 'hpo' 'red' 'grn' 'blu'};
      
%% ----------   shape   ---------   ShpAbstAtts.h

% ------ attsShpStrOri, ia Scors
Lbs = 'Vrt   Hor   Dg1   Dg2   Axi   Adg   Vab   Hab   Dab   Tri   Nil   ';
Lshp.Scors = u_AttLabArrToList( Lbs );

% ------ attsShpStrFin, ia Sfine
Lbs = 'Vrt   Hor   Vti   Hti   Vob   Hob   Dg2   Dg1   Axi   Uni   Dul   Cvg   Agx   Ori   Nil   Dre   Vir   Fnf   ';
Lshp.Sfine = u_AttLabArrToList( Lbs );

% ------ attsShpRadSeg, ia Ras
Lbs = 'Rad   Elo   Ron   Riss  SteUgfSteEngSteDowSteUppOpnDowOpnUpwLigUgfLigEngLigDowLigUppOpnRitOpnLef';
Lshp.Ras = u_AttLabArrToList( Lbs );
  
Lshp.Gol = {'rib' 'ori' 'elo' 'agx'};

LbsGen = {'vpo' 'hpo' 'red' 'grn' 'blu'};

%LB.Shp = [ Lshp.Scors(:); LbsGen(:) ];
%LB.Shp = [ Lshp.Scors(:); Lshp.Sfine(:); Lshp.Ras(:); LbsGen(:) ];
LB.Shp = [ Lshp.Scors(:); Lshp.Sfine(:); Lshp.Ras(:); Lshp.Gol(:); ...
            LbsGen(:) ];
%LB.Shp = {'vrt' 'hor' 'dg1' 'dg2' 'axi' 'vpo' 'hpo' 'red' 'grn' 'blu'};


%% ----------   tetragon   ---------   
aLbGeom = { 'Les'   'Elo'    'Wide'   'High'    'Rhom'  ...
            'Pllo'  'Tria'   'Irrg'   'PlHor'   'PlVrt' ...
            'Ger'   'Wth'
            };
aLbLage = { 'AxVrt'  'AxHor'   'Axial'   'Lean1'  'Lean2'   ...
            'Neig1'  'Neig2'
            };
        
aLbUtil = { 'ori' 'vpo' 'hpo'};

LB.Ttrg = [ aLbGeom(:); aLbLage(:); aLbUtil(:) ];

%% ------------   DOUBLES   ---------------
LB.Ttg  = LB.Ttrg;
LB.Bnd  = LB.Bndg;

%% ------------------------   Num of Labels   ----------------------
if 0
    aFldNas     =  fieldnames(LS);
    for f = 1:length(aFldNas)
        
        fl       = aFldNas{f};
        fln      = ['n' fl];
        aLabs    = LS.(fl);
        nAtt     = length( aLabs );
        
        LS.(fln) = nAtt;
    end
end



end % MAIN

