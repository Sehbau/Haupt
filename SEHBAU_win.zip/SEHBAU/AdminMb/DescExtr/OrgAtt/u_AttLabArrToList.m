%
% Turns an array of attribute labels into a list. A label is assumed to
% have at most 6 characters and the label array must therefore be multiple
% of 6. Spaces will be eliminated.
% 
% EXAMPLE:   Arr = 'Len   Str   Ori   ';
%            C   = { 'Len' 'Str' 'Ori' };
%
% cf o_AttsLabels.m
%
% IN   Arr        [nChar 1]   array 
% OUT  C          cell (list) of labels, {nAtt}[3..6]
%
function [C] = u_AttLabArrToList( Arr )

[nChar] =  length( Arr );

if mod(nChar,6)~=0
    Arr
    error('Label array must be multiple of 6');
end

Arr  = reshape( Arr, 6, [])'; % [nAtt 6]
nAtt = size(Arr,1);
C    = cell(nAtt,1);
for a = 1:nAtt
    lab     = Arr(a,:);
    Bspc    = isspace(lab);
    C{a} = lab( ~Bspc );
end
    
end

