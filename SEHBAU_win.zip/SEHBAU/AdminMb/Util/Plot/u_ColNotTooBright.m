%
% Avoid that a plotting color (rgb triplet) is too bright. We limit it to
% gray value tolBgt.
%
function [rgb] = u_ColNotTooBright( rgb, tolBgt )

if nargin==1
    tolBgt = 0.8;
end

if rgb(1)>tolBgt && rgb(2)>tolBgt && rgb(3)>tolBgt   % if very white 
    rgb = ones(1,3) * tolBgt; % then leave at gray
end                

end

