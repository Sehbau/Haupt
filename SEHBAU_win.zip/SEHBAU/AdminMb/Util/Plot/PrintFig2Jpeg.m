%
% Prints a figure as jpeg file.
%
% sa PrintFig2File
%
% IN    pfn     full path
%       figNo   figure no
%
% USE   PrintFig2Jpeg( [PATH.figs_res_pc 'example'],  1 )
%
% set(gcf, 'paperposition', [0.5 0.25 7 10.75]); % left margin, bottom margin, width/ height
%
function [] = PrintFig2Jpeg(pfn, figNo, szH )

if nargin==2,
    szH = 0;
end

if szH==0
    % do nothing
elseif szH == 0.5
     set(gcf, 'paperposition', [0.25 0.25 8 3.5]); 
elseif szH == 1
     set(gcf, 'paperposition', [0.25 0.25 8 8]); 
else
    error('not implemented');
end

figure(figNo);

print(gcf, '-djpeg', pfn);  

fprintf('Printed to file %s\n', pfn);

end