%
% Display array statistics as calculated with f_ArrStat.m
%
function [] = DispStatArr( S, jStr )

if nargin==1, jStr=''; end

DispArrStat( S, jStr );

end

