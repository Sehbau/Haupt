%
% Verifies that argument structure (created with o_CmndArgs) is still
% correct after user modifications.
%
% If you are already in the directory of the program, then set pthOpr to
% ''.
%
% IN    Args    structure as in o_CmndArgs()
%       pthOpr  path of operation, ie. where the binary lies
%
function [] = v_CmndArgs( Args, pthOpr )

aFldNa  = fieldnames(Args); 
nFldNa  = length( aFldNa );

% ---------------------   Dscx    --------------------------
if strcmp( Args.proc, 'dscx')

    if nFldNa~=Args.nFld, 
        Args
        error('fields not correct. Wrong assignment made?');
    end
    
    if ~isempty( Args.fpPrm )

        ix = strfind( Args.fpPrm, 'PrmDesc' );
        
        if isempty(ix)
            error('filename for parameters must start with PrmDesc. is %s', ...
                Args.fpPrm );
        end
        
        v_PrmFileExists( [pthOpr Args.fpPrm] ); 

    end

% ---------------------   Mvec   --------------------------
elseif strcmp( Args.proc, 'mvec')

    if nFldNa~=Args.nFld, 
        Args
        error('fields not correct. Wrong assignment made?');
    end
    
    if ~isempty( Args.fpPrm )

        ix = strfind( Args.fpPrm, 'PrmMtch' );
        
        if isempty(ix)
            error('filename for parameters must start with PrmMtch. is %s', ...
                Args.fpPrm );
        end
        
        v_PrmFileExists( [pthOpr Args.fpPrm] ); 
        
    end

% ---------------------   else   --------------------------
else
    error('process %s not implemented\n', proc );
end    



end

