% 
% Verifies that parameter file contains proper identifier and that it
% exists.
%
% sa u_PrmFileGen, paramsToFile.m
%
% sa v_ProgExists.m
%
% ai {plcrec}Run.m, ie. lvngRun.m
%
function [] = v_PrmFileExists( fipa )

%% ---------   verify identifier is present   ---------
if ~isempty( strfind( fipa, 'PrmMtch') )  || ...
   ~isempty( strfind( fipa, 'PrmDesc') )
    % okay, do nothing
else
    error('filepath %s does not contain ''PrmMtch'' or ''PrmDesc''', fipa);
end

%% ---------   verify file exists   ---------
if ~exist( fipa, 'file' )

    [ pthFile, name, ext] = fileparts( fipa );

    if ~exist( pthFile, 'dir')
        error( 'filepath %s does not exist', pthFile );
    else        
        error('parameter file %s not found. paramsToFile.m ?', fipa );
    end
    
end

end

