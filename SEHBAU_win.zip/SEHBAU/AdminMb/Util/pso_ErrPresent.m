% 
% Determines if error messages have been written to stderr.
%
% IN    Out   standard output
% OUT   []
%
function [] = pso_ErrPresent(Out)

ixErrPresent  = strfind(Out, 'errors present.');

if ~isempty( ixErrPresent )
    fprintf('errors present. check log file\n');
end

end

