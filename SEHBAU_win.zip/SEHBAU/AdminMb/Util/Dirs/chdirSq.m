function [] = chdirSq()
    chdir('c:/klab/ppc/SEHQUL/');
end

