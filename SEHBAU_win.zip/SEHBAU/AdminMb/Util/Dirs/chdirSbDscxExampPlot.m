function [] = chdirSbDscxExampPlot()
    chdir('c:/klab/ppc/SEHBAU/DescExtr/UtilMb/Examples/');
end

