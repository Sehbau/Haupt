%
% Verifies that a program exists.
%
% fka u_CheckExistProg.m
%
function [] = v_ProgExists( fipa, bOSisWin )

if bOSisWin
    pthExe = [ fipa '.exe'];
end

if ~exist( pthExe, 'file')
    
    [ pathStr, name, ext] = fileparts( fipa );
    
    if ~exist( pathStr, 'dir')
        
        error('dir %s not found.', pathStr);
        
    end
    
    error('exe file %s does not exist. (dir appears correct)', name);
    
end

end

