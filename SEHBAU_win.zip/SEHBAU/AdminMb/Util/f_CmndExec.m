%
% Execute a command (program) given in line 'cmnd' that already includes
% all arguments.
%
% sa u_CmndArgs, u_CmndArgsCat, ...
%
% cf lvngRunDscx.m, lvngRunMvec.m, ...
%
function [Out] = f_CmndExec( cmnd )

if ispc
    cmnd  = u_PathToBackSlash( cmnd ); 
end

[status Out] = system( cmnd );      

%% -------------   Verify Status   -------------
% v_CmndExec( status, Out, cmd );
if (status~=0)
    
    Out              % display out
    
    error('Command %s did not succeed (status = %d)', cmnd, status); 
end

%% -------------   Verify Output   -------------
% should be caught by status, but since I've erroneously used exit(0)
% sometimes in my code, it may happen that we missed status!=0.
%
% af RennDscx.m
%

% The EOP string does not always appear at the end of @standard output. In
% particular matching programs contain additional print statements AFTER
% 'EndOfProgram', such as measurement values.
%
ixEOP = strfind(Out, 'EndOfProgram');       

if isempty(ixEOP)
    warning('Command %s not properly terminated - lacks EOP.', cmnd);
    Out
    fprintf('paused'); 
    pause();
end

end

