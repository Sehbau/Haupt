% 
% Filepath for map occurrence.
%
function fipa = u_FipaMocc(pth)

fipa  = [pth '/MOCC'];

end

