%
% Loads a single array of floats (written as text) until end-of-file, ie.
% as saved as in st_ArrFlt.
%
function [A] = LoadFltTxtEof( lfn ) 

fid	= fopen(lfn, 'r');
if (fid<0), error('file %s not found', lfn); end

A   = fscanf( fid, '%f' );

fclose(fid);


