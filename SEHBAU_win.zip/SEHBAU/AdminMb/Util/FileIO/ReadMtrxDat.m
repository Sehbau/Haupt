%
% Reads a data matrix [nRow nCol] that was saved feature-/columnwise in C,
% that is inverse [nCol nRow]. We therefore reshape to standard format
% here.
% 
% EXAMPLE: descriptor attributes were saved in C by writing the attribute
% arrays sequentially, ie. Len, Str, Ori using w_RackFlt of RackIO.h. Thus
% when loaded, the data corresponds to [nAtt nDsc]. We then reshape to
% [nDsc nAtt] format.
%
% Use ReadStcArr.m to read and turn into struct-of-arrays in one
% function.
%
% ai ReadStrAtt.m, ReadArcAtt.m, LoadTxtrMaps.m, ...
%
% IN    fid         file pointer
%       conversion  datatype conversion, 
%                    ie. 'float=>single', 'int32=>single', 'uint8=>uint8'
%
function [ARR szD] = ReadMtrxDat( fid, conversion )

%% ----------   Header   ----------
nFet    = fread(fid, 1, 'int=>int'); % number of features (attributes, biases)
nObs    = fread(fid, 1, 'int=>int'); % number of observs  (descriptors, rixels)

%% ----------   Matrix   ----------
ARR     = fread(fid, nObs * nFet, conversion ); 

%% ----------   reshape   ----------
ARR     = reshape(ARR, [nObs nFet]);  

szD.nFet = nFet;
szD.nObs = nObs;

end

