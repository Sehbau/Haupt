%
% Reads a data matrix [nRow nCol] that was saved feature-/columnwise in C,
% that is inverse [nCol nRow]. We therefore reshape to standard format
% here.
% 
% EXAMPLE: descriptor attributes were saved in C by writing the attribute
% arrays sequentially, ie. Len, Str, Ori using w_RackFlt of RackIO.h. Thus
% when loaded the data corresponds to [nAtt nDsc]. We then reshape to [nDsc
% nAtt] format.
%
% Use ReadStcArrFlt.m to read and turn into struct-of-arrays in one
% function.
%
% ai ReadStrAtt.m, ReadArcAtt.m, LoadTxtrMaps.m, ...
%
% For integer see ReadMtrxInt.m
%
function [ARR szD] = ReadMtrxFlt( fid )
error('deprectaed');

%% ----------   Header   ----------
nFet    = fread(fid, 1, 'int=>int'); % number of features (attributes, biases)
nObs    = fread(fid, 1, 'int=>int'); % number of observs  (descriptors, rixels)

%% ----------   Matrix   ----------
ARR     = fread(fid, nObs * nFet, 'float=>single'); 

%% ----------   reshape   ----------
ARR     = reshape(ARR, [nObs nFet]);  

szD.nFet = nFet;
szD.nObs = nObs;

end

