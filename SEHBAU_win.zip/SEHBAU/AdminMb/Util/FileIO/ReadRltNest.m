%
% Reads as saved under w_RltNest
%
function [S] = ReadRltNest(fileID) 

S.nEnt   = fread( fileID,      1, 'int=>int' );

S.Count  = fread( fileID, S.nEnt, 'int=>int' );
S.Deg    = fread( fileID, S.nEnt, 'float=>single' );
