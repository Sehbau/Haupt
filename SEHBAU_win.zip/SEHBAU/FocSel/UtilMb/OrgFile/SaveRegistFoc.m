%
% Generate and save register files for focii from a list of image names:
% histograms or vectors.
%
% IN  dirFoc     folder where focii are located
%     aImgNames  image names without extension
%     fext       extension of focii: hsf1 for histograms, dsf for vectors
% OUT aFipas     filepaths of the generated register files
%
% USE
%     aRgstHst = SaveRegistFoc( [ currDir '/' dirFoc ], aImgNames, 'hsf1' );
%     aRgstVec = SaveRegistFoc( [ currDir '/' dirFoc ], aImgNames, 'dsf' );
%
%
% Assumes focus files were saved with '_Fxxx' with xxx some number/string.
%
% cf plcMtcZonLst.m
%
function [aFipas] = SaveRegistFoc( dirFoc, aImgNames, fext )

nImg        = length(aImgNames);
aFipas      = cell(nImg,1);

%% ----  hist or vect (atts)  ----
if strcmp( fext, 'hsf1' )==1
    rgstIdf = 'hst';
elseif strcmp( fext, 'dsf' )==1
    rgstIdf = 'vec';
else
    error('file extension %s not implemented', fext );
end

%% ----  filenames  ----
for i = 1 : nImg
    
    aFinas = dir( [ dirFoc aImgNames{i} '_F*.' fext ] );
    
    sfpRgst = sprintf('Regist/ifoc%d_%s.txt', i, rgstIdf );
    
    SaveFipaLstPrependPath( aFinas, dirFoc, sfpRgst );
    
    aFipas{i} = sfpRgst;

end

end

