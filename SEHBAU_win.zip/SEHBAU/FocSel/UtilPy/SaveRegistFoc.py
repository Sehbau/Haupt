"""

"""
import glob, os
from SaveFipaLst import *


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   SaveRegistFoc   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

see SaveRegistFoc.m

"""
def SaveRegistFoc( dirFoc, aImgNames, fext ):

    nImg = len(aImgNames);

    ## ----  hist or vect (atts)  ----
    if fext == 'hsf1':
        rgstIdf = 'hst'
    elif fext == 'dsf':
        rgstIdf = 'vec'
    else:
        raise NotImplemented( f'file extension {fext} not implemented' );
    
    ## ----  filenames  ----
    aFipas  = [None] * nImg
    for i in range(nImg):

        pat     = os.path.join( dirFoc, aImgNames[i] + '_F*.' + fext )
        aFinas  = glob.glob( pat );

        sfpRgst = f'Regist/ifoc{i}_{rgstIdf}.txt'
    
        SaveFipaLst( aFinas, sfpRgst )
        #SaveFipaLstPrependPath( aFinas, '', sfpRgst )
    
        aFipas[i] = sfpRgst

    return aFipas
