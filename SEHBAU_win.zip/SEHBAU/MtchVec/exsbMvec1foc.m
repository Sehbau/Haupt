% 
% Runs program mvec1 for two focii.
% For multiple files see runMvecLfoc.m
%
% PREVIOUS  runMvec1img.m
% PRESENT   runMvec1foc.m
% NEXT      runMvecLfoc.m (list)
% 
clear;
run('../globalsSB');

%% ---------------   Create Focii   -----------------------
% we do this the primitive way for reason of convenience
cd( PthProg.focSel );

copyfile('../DescExtr/Desc/img1.dsc', 'Desc/img1.dsc')
copyfile('../DescExtr/Desc/img2.dsc', 'Desc/img2.dsc')
copyfile('../DescExtr/Desc/img1.dsb', 'Desc/img1.dsb')
copyfile('../DescExtr/Desc/img2.dsb', 'Desc/img2.dsb')

% - FocExtr/run12.cmd
dos('focvec1 Desc/img1.dsc 80 160 80 150 Focii\foc1')
dos('focvec1 Desc/img2.dsc 80 160 80 150 Focii\foc2')
%dos('focvec1 Desc/aachen.dsc 80 160 80 150 Focii\aachen')

dos('fochst1 Desc/img1.dsc 80 160 80 150 Focii\foc1')
dos('fochst1 Desc/img2.dsc 80 160 80 150 Focii\foc2')

% - FocExtr/runCopy12.cmd
dos('copy Focii\foc1.dsf ..\MtchVec\Desc')
dos('copy Focii\foc2.dsf ..\MtchVec\Desc')
%dos('copy Focii\aachen.dsf ..\MtchVec\Desc')

%% ----------------   Match   ------------------
cd( PthProg.mtchVec );                     

OptK     = u_OptMvecStc();
optS     = i_OptMvec(OptK);
finaProg = 'mvec1';
dirFocii = '../FocExtr/Focii/';

cmndFoc  = [finaProg ' ' dirFocii 'foc1.dsf' ' ' dirFocii 'foc2.dsf ' optS];

[Sts OutFoc] = dos( cmndFoc );

%% -------   Read Out StdOut   -------
[StoF HedF]             = u_MtrMesSecs( OutFoc );
[AMesDtyFoc mesTotFoc]  = u_MtrMesScnf( StoF );

%[StoF HedF] = u_MtrMesHead(OutFoc);
%[MesFoc disFoc] = u_MtrMvec(StoF, HedF);
%Ndsc1F      = u_MtrMvecNdsc(StoF.Ndsc, HedF, '1');
%Ndsc2F      = u_MtrMvecNdsc(StoF.Ndsc, HedF, '2');
%MesF        = f_Mvv(MesFoc, Ndsc1F, Ndsc2F, 'foc');

%% -------   Plot Metric Measurements  --------
figure(2); clf;
bImg        = 0;
%p_MvvDty(MesF, Ndsc1F, bImg);
p_MvvDty( AMesDtyFoc );


%% --------------------------------------------------------------
%                As Function (for the Two Focii)
%  --------------------------------------------------------------
Admin       = u_CmndAdmin();
Admin.optS  = optS;

OutFnc  = RennMvec1([dirFocii 'foc1.dsf'], [dirFocii 'foc2.dsf'], Admin );
u_StdOutOptUnrec(OutFnc);

