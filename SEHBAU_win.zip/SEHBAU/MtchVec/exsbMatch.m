% 
% Runs program mvec1, for two frames. No wrappers, no plotting. To be run
% from directory '/MtchVec/'.
%
clear;
if isempty( strfind( pwd, 'MtchVec' ) ), 
    error('Must be run from dir MtchVec');
end

%% --------------------------------------------------------------
%                          DESC EXTR
%  --------------------------------------------------------------
% Firstly we run descriptor extraction for two frames.
fprintf('Descriptor extraction two frames...');
if ispc
    % excecute program for windows: backslash for program and output
    [sts1 Out1] = dos('..\DescExtr\dscx Imgs/Frm1.png Desc\Frm1'); 
    [sts2 Out2] = dos('..\DescExtr\dscx Imgs/Frm2.png Desc\Frm2'); 
elseif isunix
    [sts1 Out1] = unix('../DescExtr/dscx Imgs/Frm1.png Desc/Frm1'); 
    [sts2 Out2] = unix('../DescExtr/dscx Imgs/Frm2.png Desc/Frm2'); 
end
fprintf('fertig\n');



%% --------------------------------------------------------------
%                          MATCH
%  --------------------------------------------------------------
fprintf('Matching...');
if ispc
    [Sts OutMtc] = dos('mvec1 Desc/Frm1.dsc Desc/Frm2.dsc'); 
elseif isunix
    [Sts OutMtc] = unix('mvec1 Desc/Frm1.dsc Desc/Frm2.dsc'); 
end

% OutMtc


%% -------   Parse StdOut   -------
run('../AdminMb/globalsSB');        % assumes this script is run from dir 'MtchVec'
[Sto Hed]         = u_MtrMesSecs( OutMtc );
[AMesDty mesTot]  = u_MtrMesScnf( Sto );

