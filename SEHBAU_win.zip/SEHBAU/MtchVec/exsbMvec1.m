%
% For image see exsbFrames.m
% For focii see exsbMvec1foc.m
% 