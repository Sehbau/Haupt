% 
% Runs program motvec, for two frames and plots the vectors.
%
clear;

run('../globalsSB');        % assumes script is run from dir 'MtchVec'

%% --------------------------------------------------------------
%                          DESC EXTR
%  --------------------------------------------------------------
% run descriptor extraction for two frames
% it is the same as in exsbFrames.m but with flag saveRRE
%
fprintf('Descriptor extraction...');
pthFrm1 	= 'Imgs/Frm1.png';
pthFrm2 	= 'Imgs/Frm2.png';

pthDsc1 	= 'Desc/Frm1';
pthDsc2   	= 'Desc/Frm2';

pthDsc1     = u_PathToBackSlash( pthDsc1 );
pthDsc2     = u_PathToBackSlash( pthDsc2 );

AdminDscx 	= u_CmndAdmin( PthProg.descExtr );
    
OptK            = o_OptDscxStc();
OptK.saveRRE    = 1;
AdminDscx.optS  = i_OptDscx(OptK);
    
OutDscx1    = RennDscx( pthFrm1, pthDsc1, AdminDscx );
OutDscx2    = RennDscx( pthFrm2, pthDsc2, AdminDscx );

fprintf('fertig\n');

%% --------------------------------------------------------------
%                          MATCH
%  --------------------------------------------------------------
fprintf('Matching...');

prog    = 'motvec';

cmnd    = [prog ' ' [pthDsc1 '.dsc'] ' ' [pthDsc2 '.dsc' ]];

dos( cmnd );
%dos('motvec Desc/Frm1.dsc Desc/Frm2.dsc');

fprintf('fertig\n');


%% ----------------   Plot   -------------------
lfp         = 'Mes/A.MotVec';
Vec         = LoadMotVec( lfp );
DispLoad( lfp );

fprintf('Plotting...');

figure(5); clf; 

subplot(1,2,1); hold on;
PlotMotVec( Vec );

subplot(1,2,2); hold on;
PlotMotVec( Vec, 1 );

fprintf('fertig\n');
