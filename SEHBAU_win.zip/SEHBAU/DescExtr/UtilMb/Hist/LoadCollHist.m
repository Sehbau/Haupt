%
% Loads a matrix of histograms, [nImg ntBin], as collected with program
% collhimg. Does not verify file extension.
%
% As saved in C under E_DESC/CollHist/CollHistUtil.h-s_CollHist().
%
function [HST Nbin] = LoadCollHist( pthFile )

fileID      = fopen(pthFile, 'r');
if fileID<0, 
    error('could not open %s.', pthFile); 
end

%% -------   Header (Size)   --------
nImg        = fread(fileID, 1,  'int=>int');
nBin        = fread(fileID, 1,  'int=>int');
fprintf('[%d %d]\n', nImg, nBin);

%% -------   Data Matrix   --------
HST         = fread(fileID, nImg*nBin, 'int=>single');
HST         = reshape(HST, nBin, nImg)';

%% -------   BinNumbers   --------
Nbin        = ReadDescBinNum( fileID );

fclose(fileID);

DispLoad(pthFile);

%% -----------   Verify   --------------
ntBin   = sum( Nbin.Tot );
nDim    = size( HST,2 );
if ntBin~=nDim
    warning( 'LoadCollHist: sum of bin numbers %d ~= dims of histogram %d', ...
        ntBin, nDim );
end



end

