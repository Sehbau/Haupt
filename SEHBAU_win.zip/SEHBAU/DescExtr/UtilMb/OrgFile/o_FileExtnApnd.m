%
% Appends file extensions to a filename
%
function [N] = o_FileExtnApnd( pth, F)

aFexts  = fieldnames( F );
nFexts  = length( aFexts );

for f = 1 : nFexts
    
    fxt     = aFexts{f};
    
    N.(fxt) = [ pth F.(fxt) ];
end