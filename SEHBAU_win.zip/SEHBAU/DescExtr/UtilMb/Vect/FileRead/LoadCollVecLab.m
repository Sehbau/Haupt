%
% Loads labels as saved under collVec.cpp
%
% Label array is [ntDsc 3] with columns corresponding to level, image and
% last column is empty.
%
% af LoadCollVec.m
%
function [LAB ntDsc] = LoadCollVecLab( lfpStem, dscTyp )

lfp = [ lfpStem 'Lab_' dscTyp '.txt' ];

fileID      = fopen( lfp, 'rt');

if fileID==-1, 
    error('could not find %s', lfp); 
end

LAB = fscanf( fileID, '%d' );   % read as entire block

fclose( fileID );

DispLoad(lfp);

%% -------    reshape   -------
nLabTyp = 3;
LAB     = reshape( LAB, nLabTyp, [] );
LAB     = LAB';

%% -------    stats   --------
ntDsc   = size(LAB,1);

fprintf('Label array is of size [%d %d].\n', ntDsc, nLabTyp );

IxLev   = unique( LAB(:,1) );
IxImg   = unique( LAB(:,2) );
%IxCat   = unique( LAB(:,3) );

fprintf('Levels from %d to %d\n', IxLev(1), IxLev(end));
fprintf('Images from %d to %d\n', IxImg(1), IxImg(end));
%fprintf('Categories from %d to %d\n', IxCat(1), IxCat(end));


