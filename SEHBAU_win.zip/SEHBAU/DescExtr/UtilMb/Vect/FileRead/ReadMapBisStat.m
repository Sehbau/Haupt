%
% Reads texture biases as saved under w_MapBisStat
%
% cf ReadCntTXT.m
%
function [S] = ReadMapBisStat( fileID )

S.prpPres  	= fread( fileID, 1, 'float=>single');
S.min   	= fread( fileID, 1, 'float=>single');
S.max   	= fread( fileID, 1, 'float=>single');
S.men   	= fread( fileID, 1, 'float=>single');
S.sdv   	= fread( fileID, 1, 'float=>single');

end

