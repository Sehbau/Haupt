%
% Reads bundle attributes as saved under BndgIO.h-w_BndgAtt
%
% cf ReadBndgSpc.m
% af ReadTtrgAtt.m
%
function [S nBndg] = ReadBndgAtt(fileID)

S       = [];

aLbGeom = { 'Les'   'Tig'    'AgX'   'Dns'
          };
aLbLage = { 'AxVrt'  'AxHor'   'Axial'   'Lean1'  'Lean2'   ...
            'Neig1'  'Neig2'
          };       

%%  ====================   Header   ====================
Hed     = ReadDescAttHead(fileID);
nBndg   = Hed.nDsc;
S.nBndg = nBndg;

%%  ====================   Data   ====================

V.GEOM  = ReadRackFlt( fileID, aLbGeom );

% =====   Position   =====
S.Ori   = fread(fileID, nBndg, 'float=>single'); % orientation angle

S.Pos   = ReadAttPos(fileID);

% =====   Appearance   =====
S.RGB   = ReadAttRgb(fileID, nBndg);
%S.Ctr   = fread(fileID, nBndg, 'float=>single'); % contrast

% =====   Trailer   =====
idf    = fread(fileID, 1, 'int16=>int');
assert(idf==8888);


end

