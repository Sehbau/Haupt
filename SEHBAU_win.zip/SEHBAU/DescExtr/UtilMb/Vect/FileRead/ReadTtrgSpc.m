%
% Reads a space of tetragon attributes as saved under w_PaarSpc in PaarIO.h
%
function [ATTG Nttg] = ReadTtrgSpc(fid)

nLev  = fread(fid, 1, 'int=>int');      % # of pyramid levels

Nttg  = zeros(nLev,1);
ATTG  = cell(nLev,1);
for l = 1:nLev
    [ATTG{l} Nttg(l)] = ReadTtrgAtt(fid);
end

end

