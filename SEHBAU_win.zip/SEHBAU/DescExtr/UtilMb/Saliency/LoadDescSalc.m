%
% Loads saliency and statistics as saved as with si_DescSal in DescIOutsz.h
%
% cf evsbSalcBase.m, exsbSmlObjDet.m, ...
%
function [Txa Shp Ens Dsc] = LoadDescSalc( lfp )

bIxOne = 1;                 % we are in Matlab and use one-indexing

%% -----------   Open   ------------
fileID      = fopen(lfp, 'r');
if fileID<0, error('Could not open file %s', lfp); end
DispLoad( lfp );

%% ------------   Saliency  -----------

% ----  Global Statistics  ----
Txa.Gst   	= ReadBlobMapGlbSts( fileID ); % map stats

% ----  Blobs  ----
% blob outlines (bboxes & asps)
Txa.Blb    	= ReadBlobOut( fileID, bIxOne  );       

% ----  Shapes  ----
% shape outlines (bboxes & asps)
Shp      	= ReadShpOut( fileID, bIxOne );  

% ----  Spot  ----
Txa.Spt    	= ReadPixvRCf( fileID );

idf         = fread(fileID, 1,  'int=>int');    % identifier
if idf~=-11111, error('idf incorrect'); end

% ----   Ensemble  ----
Ens         = ReadSalcBbxEns( fileID );


%% ------------   DescStats   -------------
% as written by r_DescStats in DescIOutsz.h
[Dsc.MaxSizScl] = ReadDescTypSpcF( fileID );
[Dsc.MenSizScl] = ReadDescTypSpcF( fileID );
[Dsc.MaxSizAbs] = ReadDescTypSpcF( fileID );

[Dsc.Ndsc]   	= ReadDescTypSpcI( fileID );
[Dsc.IxMx]     	= ReadDescTypSpcI( fileID );

% -----  coverage boundaries
nLev            = Dsc.MaxSizScl.nLev;
Dsc.CvgBon     	= ReadFeatCoverage( fileID, nLev );
Dsc.CvgShp     	= ReadFeatCoverage( fileID, nLev );

% -----  smoothness
Dsc.Smo.ArcMen = zeros(nLev,1,'single');
Dsc.Smo.ArcMax = zeros(nLev,1,'single');
Dsc.Smo.StrMen = zeros(nLev,1,'single');
Dsc.Smo.StrMax = zeros(nLev,1,'single');
for l = 1:nLev
    arc = ReadAttDom( fileID );
    str = ReadAttDom( fileID );
    Dsc.Smo.ArcMen(l) = arc.men;
    Dsc.Smo.ArcMax(l) = arc.max;
    Dsc.Smo.StrMen(l) = str.men;
    Dsc.Smo.StrMax(l) = str.max;
end

idf         = fread(fileID, 1,  'int=>int');    % identifier
if idf~=-11111, error('idf incorrect'); end

% -----   shape2
Dsc.AreShp   	= fread( fileID, nLev, 'float=>single' );
Dsc.ShpGrpSpc   = fread( fileID, 3, 'float=>single' );

% -----  appearance
Dsc.GryMmm      = fread( fileID, 3, 'uint8=>int32' );
Dsc.MxRngRR     = fread( fileID, nLev, 'uint8=>int32' ); % ridge/river contrast
Dsc.MxRngEg     = fread( fileID, nLev, 'uint8=>int32' ); % edge contrast
Dsc.MxRngBon    = fread( fileID, nLev, 'uint8=>int32' );

Dsc.Nbon        = fread( fileID, nLev, 'int32=>int32' );
Dsc.Nrdg        = fread( fileID, nLev, 'int32=>int32' );
Dsc.Nriv        = fread( fileID, nLev, 'int32=>int32' );
Dsc.Nedg        = fread( fileID, nLev, 'int32=>int32' );

Dsc.NpxBon      = fread( fileID, nLev, 'int32=>int32' );
Dsc.NpxRdg      = fread( fileID, nLev, 'int32=>int32' );
Dsc.NpxRiv      = fread( fileID, nLev, 'int32=>int32' );
Dsc.NpxEdg      = fread( fileID, nLev, 'int32=>int32' );

%Dsc.Skl_StrLon  = fread( fileID, nLev, 'uint8=>int8' );
%Dsc.Skl_StrMen  = fread( fileID, nLev, 'uint8=>int8' );
 
%% ------------   Close   -----------
fclose( fileID );


