%
% Loads bounding boxes (as text) as saved under s_QnslBbox in ConslIO.h
% 
% cf cc_Axial.m
%
function [Bbx Nr] = LoadDescPropBbox( lfn )

fileID   = fopen(lfn, 'rt');
if (fileID<0), error('file %s not found', lfn); end

DispLoad( lfn );

[Bbx.ShpGen Nr.shpGen]  = ReadBboxLtxt( fileID );
[Bbx.TtgGen Nr.ttgGen]  = ReadBboxLtxt( fileID );

[Bbx.ShpVrt Nr.shpVrt]  = ReadBboxLtxt( fileID );
[Bbx.ShpHor Nr.shpHor]  = ReadBboxLtxt( fileID );

%% ------------   Close   -----------
fclose( fileID );

%% ----------  Disp  -----------
% no need because ReadBboxLtxt displays already
% fprintf('LoadConslBbox: %d %d\n', nShp, nTtg );
fprintf('\n');

end

