%
% Blob labels.
%
% They must match with CntTxtAnf.h, w_CntTXTbis (CntTxtIO.h)
%
function [LS nTyp] = o_BlobLabels()

LS = {'Num' 'Blk' 'Nil' 'Vrt' 'Hor' 'Axi' 'Uni'};

nTyp    = length( LS );

end 

