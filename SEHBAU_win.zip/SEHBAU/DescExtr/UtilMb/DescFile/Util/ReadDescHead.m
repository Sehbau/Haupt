function [] = ReadDescHead()

error('Scuzi, this is old version. Use ReadDescAttHead.m | ReadDescFileHead.m');

end

