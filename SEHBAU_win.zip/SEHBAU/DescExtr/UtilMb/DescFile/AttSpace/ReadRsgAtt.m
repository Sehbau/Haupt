%
% Reads contour attributes as saved under RsgIO.h-w_RsgAtt
% cf LoadCntxSpc.m
%
function [S nRsg] = ReadRsgAtt(fileID)

S = [];

nRsg  = fread(fileID, 1,  'int=>int');
%nRsg

% =====   Geometry   =====
S.Rds  = fread(fileID, nRsg, 'float=>single');
S.Cir  = fread(fileID, nRsg, 'float=>single');
S.EloR = fread(fileID, nRsg, 'float=>single');
S.Cncv = fread(fileID, nRsg, 'float=>single');

S.Bis1 = fread(fileID, nRsg, 'float=>single');
S.Bis2 = fread(fileID, nRsg, 'float=>single');
S.Bis3 = fread(fileID, nRsg, 'float=>single');
S.Bis4 = fread(fileID, nRsg, 'float=>single');
S.Bis5 = fread(fileID, nRsg, 'float=>single');

S.Star = fread(fileID, nRsg, 'float=>single');
S.Dent = fread(fileID, nRsg, 'float=>single');

% =====   Position   =====
S.Ori  = fread(fileID, nRsg, 'float=>single');
S.Pos  = ReadAttPos(fileID);

%S.Tif  = fread(fileID, nRsg, 'float=>single'); % depth/range (from sensor)

% =====   Appearance   =====
S.RGB   = ReadAttRgb(fileID, nRsg);
%S.RGB.Red  = fread(fileID, nRsg, 'float=>single');
%S.RGB.Grn  = fread(fileID, nRsg, 'float=>single');
%S.RGB.Blu  = fread(fileID, nRsg, 'float=>single');

% =====   Util  =====
S.IxBon1 = fread(fileID, nRsg, 'int32=>int32') + 1; % changes to one-indexing

% =====   Trailer   =====
idf    = fread(fileID, 1, 'int16=>int');
assert(idf==2222);

S.nRsg = nRsg;

end
