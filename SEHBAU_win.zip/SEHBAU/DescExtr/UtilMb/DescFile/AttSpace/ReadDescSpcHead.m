%
% Reads the space header as written by w_DescSpcHead.
%
function [nLev Ndsc] = ReadDescSpcHead( fid )

nLev  = fread(fid, 1,    'int=>int');      % # of levels
Ndsc  = fread(fid, nLev, 'int=>int');      % # of descriptors

end

