% 
% Load as saved under s_KolmUNV in KolmUtil.h
%
% OUT   .ORI  orientation hists
%       .LEN  length hists
%
function [KOLM H] = LoadKolumns( lfp )

%% -----------   Open   ------------
fileID      = fopen(lfp, 'r');
if fileID<0, error('Could not open file %s', lfp); end

%% ============   HEADER   =============
H.nSpc          = fread( fileID, 1, 'int=>int' ); 
H.nKol          = fread( fileID, 1, 'int=>int' ); 
H.nBinCntOri    = fread( fileID, 1, 'int=>int' ); 
H.nBinCntLen    = fread( fileID, 1, 'int=>int' ); 
H.ntBin         = fread( fileID, 1, 'int=>int' ); 

%% ============   KOLUMNS   =============
KOLM.ORI        = ReadKolmUni( fileID );
KOLM.LEN        = ReadKolmUni( fileID );

%% ============   Trailer   =============
idf         = fread( fileID, 1, 'int=>int' ); % load identifier

%% ------------   Close   -----------
fclose( fileID );

assert( idf==-23456, 'idf incorrect. Is %d, but should be 826', idf );

end




