%
% Plots a list of radial signature from attribute information using the
% structure as loaded by LoadDescImag.
% 
% We plot as circles and ellipses only. 
%
% Analogous to p_CntFromAtts
%
function [] = p_RsgFromAtts( RSG, Fct, bAxisIJ, col ) 

bColInp = 1;

if nargin==1
    Fct     = [1 1];
    bAxisIJ = 1;
    bColInp = 0;
end

for i = 1:RSG.nRsg

    if bAxisIJ
        posV = 1-RSG.Pos.Vrt(i);     % vertical position (ij->Cartes.)
    else
        posV = RSG.Pos.Vrt(i);     % vertical position (ij->Cartes.)
    end
    
    posH    = RSG.Pos.Hor(i);       % horizontal position
    ori     = RSG.Ori(i);           % orientation angle
    rds     = RSG.Rds(i);           % radius
    %ctr     = STR.Ctr(i);           % contrast
        
    if Fct(1)~=1 || Fct(2)~=1,
        posV = posV * Fct(1);
        posH = posH * Fct(2);
        rds  = rds  * mean(Fct);
    end
    
    wth     = rds*2;                % default for circle
    hgt     = rds*2;
    
    % If NOT circle, then squeeze circle according to orientation angle.
    % This will make diagonal shapes smaller and therefore not reflect them
    % well.
    if ~isnan(ori)
        wth     = sin(ori)*rds;       
        hgt     = cos(ori)*rds;
        if wth<0.01, wth = 0.01; end
        if hgt<0.01, hgt = 0.01; end
    end
    
    if bAxisIJ
        hl = rectangle('position', [posH-rds  posV-rds wth hgt]);
    else
        % vrt/hor switched
        hl = rectangle('position', [posV-rds  posH-rds hgt wth]);
    end
    set(hl, 'curvature', [1 1]);

    if bColInp==0
        % add color:
        red     = RSG.RGB.Red(i);
        grn     = RSG.RGB.Grn(i);
        blu     = RSG.RGB.Blu(i);
        set(hl, 'edgecolor', [red grn blu]);
    else
        set(hl, 'edgecolor', col);
    end
    
    % make linewidth proportional to contrast:
    %set(hl, 'linewidth', 0.2 + 2*ctr); % 0.2 is minimum width
    
end    
