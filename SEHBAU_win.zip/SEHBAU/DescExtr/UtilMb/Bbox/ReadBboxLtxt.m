%
% Reads bounding boxes as integer as saved under wt_BboxL
%
% cf LoadConslDesc.m, LoadSalcAlyT
%
% af LoadBboxFunv.m
%
function [ABbox nBox] = ReadBboxLtxt(fileID) 

%% -----  Head  -----
nBox  = fscanf(fileID, '%d', 1);    
fprintf('[nBox %4d] ', nBox); 

%% =====  BoundingBoxes  =====
nEnt  = 4;                   % number of bbox entries (>=4)
ABbox = zeros(nBox, nEnt, 'int16');
for l = 1:nBox
    
    Row = fscanf(fileID, '%d', nEnt);
    
    if length(Row)<nEnt, 
        warning('Row not completely read.');
        break; 
    end
    
    fscanf(fileID,'\n');
    
    ABbox(l,:) = Row;
end

%id = fscanf(fileID, '%d', 1);
%assert(id==222);


