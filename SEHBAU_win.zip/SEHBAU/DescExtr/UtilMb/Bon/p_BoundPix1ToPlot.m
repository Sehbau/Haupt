%
% Plots a single boundary to a x/y plot and therefore inverts row
% coordinates (szV-rw).
%
% sa p_BoundPix1ToImg in SgrRGB/UtilMb/
%
function hp = p_BoundPix1ToPlot( Pix, szV, col, bJit, ctr )

if nargin==2, bJit=0;  ctr=0; end % if jitter not specified, then OFF
if nargin==3, ctr=0; end   % if contrast not specified, then set to OFF

% add some jitter to avoid overlap 
if bJit>0, off = rand(1) * 0.2;
else       off = 0; end
    
hp = plot( single(Pix.Cl)+off, single(szV-Pix.Rw)+off, '-');

set(hp, 'color', col);          % default color. might be overwritten

%% --------   Contrast   ----------
if ctr>0
    liwi = ceil(ctr/50);
    set(hp, 'linewidth', liwi);
end


end

