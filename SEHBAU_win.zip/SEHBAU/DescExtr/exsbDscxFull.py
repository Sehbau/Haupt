"""

Example using wrapper routine RennDscx()

Analogous to exsbDscxFull.m

"""
import sys, os
sys.path.insert(0, '..')
import AdminPy as sb

strImg 	= 'img1.jpg'
#strImg = 'img2.jpg'

pthImg	= os.path.join( 'Imgs/', strImg )        # image path
pthOut 	= os.path.join( 'Desc/', strImg[:-4] )   # outpath 


# ------------------------------   Execute Explicitly   ------------------------------
# not much new here (coming form exsbDscxSimp.py)
cmnd  = 'dscx ' + pthImg + ' ' + pthOut + ' ' + '--depth 2'

import subprocess

Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )

if Res.returncode != 0:
    raise ValueError("dscx did not execute properly somehow")

# ------------------------------   Execute With Wrapper Function   ---------------------
# this is new:
Admin      = sb.dclsAdminCmnd            # CmndSupp.py
Admin.optS = '--depth 2'
  
StdOut     = sb.RennDscx( pthImg, pthOut, Admin )


# ------------------------------   Load   ------------------------------
filePath    = pthOut + '.dsc'

DSC, Hed    = sb.LoadDescImag( filePath )

print(DSC)
print( f'Head  nLev {Hed.nLev}  depth {Hed.depth}' )


