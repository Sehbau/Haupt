%
% Simple demo. To be run from directory '/DescExtr/'.
%
% Runs program dscx and loads essential files. Assumes the organization as
% given in the repository.
%
% In case windows does not run the executable:
% https://de.mathworks.com/matlabcentral/answers/316233-can-t-run-external-program
%
clear;

if ispc
    % excecute program for windows
    [sts Out] = dos('dscx Imgs/img2.jpg Desc\img2'); % backslash
elseif isunix
    [sts Out] = unix('dscx Imgs/img2.jpg Desc/img2');  
end

assert( sts==0, 'status not 0, but %d. dscx did not execute properly');

%% -------   Load Some Output   -------
globalsSB;
%run('../globalsSB');


% description (attributes)
[DSC Kt Hed]            = LoadDescImag( 'Desc/img2.dsc' );    

% saliency 
[Txa Shp Ens Dsc]       = LoadDescSalc(  'Desc/img2.slc' );

% histogram
[HFU HFB HSP Nbin HedHst] = LoadDescHist( 'Desc/img2.hst' );


%% ---------   h2arr  ---------
% turns a hist file into a single array
if ispc
    [sts Out] = dos('h2arr Desc/img2.hst Vect\img2'); % backslash
elseif isunix
    [sts Out] = unix('h2arr Desc/img2.hst Vect/img2');  
end

assert( sts==0, 'status not 0, but %d. h2arr did not execute properly');

Hari        = LoadHistImgArr( 'Vect/img2.hari' );


