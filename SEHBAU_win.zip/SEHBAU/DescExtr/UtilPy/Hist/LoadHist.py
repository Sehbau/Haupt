"""

Loading histograms

"""
import numpy as np

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   LoadHistImgArr   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Loads the image histogram array from a text file.
Equivalent to LoadHistImgArr.m
    
RET  np.ndarray: 1D array of integers.

"""
def LoadHistImgArr(lfn):

    try:
        with open(lfn, 'r') as file:
            return np.loadtxt(file, dtype=np.int32)
            #H = []
            #for line in file:
             #   parts = line.strip().split()
              #  for p in parts:
               #     try:
                #        H.append(int(p))
                 #   except ValueError:
                  #      print(f"Warning: Skipping invalid token: {p}")

                    #line = line.strip()
                #if line and line.isdigit():  # skips empty and non-numeric lines
                 #   H.append(int(line))
                    
            #H = [int(line.strip()) for line in file if line.strip()]
            
    except FileNotFoundError:
        raise FileNotFoundError(f"file {lfn} not found")

    return np.array(H, dtype=np.int32)


