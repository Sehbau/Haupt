
from ReadAtts import *
from ReadDescHeaders import ReadDescAttHead
from dataclasses import dataclass

## Loads attributes & info for contours as a structure. Most
## attributes are float values. Uses the 3 functions above to 
## unpack the values. 
      
## Note 1: RGB values (.Crm) were written [RGBRGB] and not
##          as [RRGGBB], hence we reshape
## Note 2: different indexing for labels and categories
    
##   S.Attributes [nDsc]  (RGB as [3 nDsc])
##   S.IxImg [nDsc 1] E [0..nImg-1] (0-indexing)
##   S.LbCat [nDsc 1] E [1..nCat]   (1-indexing)
##   S.Lev   [nDsc 1] E [0..nLev-1] (0-indexing)

##    USE    DSC = LoadDscRawGen('C:\IMG\DSC\', 'RDG')

def ReadCntAtt( fo ):

    class S:    # returning as structure
        pass    
    
    ##  ====================   Header   ====================
    Hed     = ReadDescAttHead( fo );
    nDsc    = Hed.nDsc;
    S.nCnt  = nDsc;
    #print( nDsc )

    ##  ====================   Data   ====================

    # =====   Geometry   =====
    S.Les   = np.fromfile( fo, dtype=np.float32, count=nDsc)  # length
    # S.Les   = r_Att1unpackFlt( fo, nDsc )
    S.Str   = r_Att1unpackFlt( fo, nDsc )

    # =====   Position   =====
    S.Ori   = r_Att1unpackFlt( fo, nDsc )
    S.Pos   = ReadAttPos( fo )

    #print( Hed.bTif )
    if Hed.bTif>0:
        S.Tif = ReadAttTif( fo, nDsc )

    # =====   Appearance   =====
    S.RGB    = ReadAttRgb( fo, nDsc )
    S.Ctr   = r_Att1unpackFlt( fo, nDsc )

    # print( S.Ctr )

    # =====   Trailer   =====
    idf    = int.from_bytes( fo.read(2), byteorder='little');
    #print( idf )
    #assert(idf==1111);

    
    return S 

#
# Reads space of contour attributes as saved under CntIO.h-w_CntSpc
#
def ReadCntSpc( fo ):

    nLev  = int.from_bytes( fo.read(4), 'little')

    #print( nLev )


    Ncnt  = np.zeros( (nLev ), dtype=np.uint8 )
    #ACNT  = cell(nLev,1);
    ACNT   = [ [] for _ in range(nLev) ]

    for l in range( 0, nLev ):
        Att     = ReadCntAtt( fo );
        #[ACNT{l} Ncnt(l)] = ReadCntAtt( fo );
        print( Att.nCnt )
        #print( Att.Les )
        ACNT[l] = Att	
        Ncnt[l] = Att.nCnt

    return ACNT, Ncnt
