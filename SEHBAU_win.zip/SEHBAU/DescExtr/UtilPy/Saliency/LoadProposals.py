"""

Load proposals

"""
import os
from dataclasses import dataclass

from ReadBboxes import ReadBboxLtxt



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   LoadDescPropBbox   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Loads bounding boxes saved as text, corresponding to s_QnslBbox in ConslIO.h.

RET   Bbx  struct containing bounding box arrays.
      Nr   struct containing the number of boxes for each group.

"""
def LoadDescPropBbox(lfn):

    if not os.path.isfile(lfn):
        raise FileNotFoundError(f"File {lfn} not found")

    @dataclass
    class Bbx:
        pass
    @dataclass
    class Nr:
        pass

    with open(lfn, 'r') as file:
        
        Bbx.ShpGen, Nr.shpGen = ReadBboxLtxt(file)
        Bbx.TtgGen, Nr.ttgGen = ReadBboxLtxt(file)
        Bbx.ShpVrt, Nr.shpVrt = ReadBboxLtxt(file)
        Bbx.ShpHor, Nr.shpHor = ReadBboxLtxt(file)

    #print()  # final newline for formatting

    return Bbx, Nr



