"""

Reads saliency information

"""
import numpy as np

from ReadBboxes import ReadBboxLbin
from ReadPixPoints import *
from ReadValues import *



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadMapBisStat   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads five float32 values representing texture bias statistics.

cf ReadBlobMapGlbSts below

"""
def ReadMapBisStat(fid):

    class S:
        prpPres  = np.fromfile(fid, dtype=np.float32, count=1)[0]
        min      = np.fromfile(fid, dtype=np.float32, count=1)[0]
        max      = np.fromfile(fid, dtype=np.float32, count=1)[0]
        men      = np.fromfile(fid, dtype=np.float32, count=1)[0]
        sdv      = np.fromfile(fid, dtype=np.float32, count=1)[0]

    return S



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadBlobMapGlbSts   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads global statistics of ori-bias maps as saved by xxx

"""
def ReadBlobMapGlbSts(fid):

    # --------------------   Labels   --------------------
    # Must match C/C++ counterpart
    aBlobLab = ['Num', 'Blk', 'Nil', 'Vrt', 'Hor', 'Axi', 'Uni']
    nTyp     = len(aBlobLab)

    # --------------------   Read   --------------------
    class S:
        pass

    for label in aBlobLab:
        setattr(S, label, ReadMapBisStat(fid) )  # each returns 5 values

    # --------------------   Verify   --------------------
    idf = np.fromfile(fid, dtype=np.int32, count=1)[0]
    
    assert idf == 46593, f'idf not correct: {idf}'

    return S


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadBlobOut   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads blob data as saved under wb_BlobOut (struct blobOUT).

cf LoadDescSalc
"""
def ReadBlobOut(file):

    class B:
        pass

    # Read bounding boxes
    B.Box, nBx = ReadBboxLbin(file)

    # Read associated attributes
    B.Typ   = np.fromfile(file, dtype=np.float32, count=nBx)
    B.Are   = np.fromfile(file, dtype=np.float32, count=nBx)
    B.Pon   = np.fromfile(file, dtype=np.float32, count=nBx)
    B.Cvg   = np.fromfile(file, dtype=np.float32, count=nBx)
    B.Ken   = np.fromfile(file, dtype=np.float32, count=nBx)

    B.Bord  = np.fromfile(file, dtype=np.uint8, count=nBx)
    B.IxBlb = np.fromfile(file, dtype=np.int32, count=nBx)

    B.nBox = nBx

    return B


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadShpOut   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads blob data as saved under wb_ShpOut.

cf LoadDescSalc
"""
def ReadShpOut(file):

    class B:
        pass

    # Read bounding boxes
    B.Box, nBx = ReadBboxLbin(file)

    # Read associated attributes
    B.Typ   = np.fromfile(file, dtype=np.float32, count=nBx)
    B.Are   = np.fromfile(file, dtype=np.float32, count=nBx)
    B.Cvg   = np.fromfile(file, dtype=np.float32, count=nBx)
    B.Ctr   = np.fromfile(file, dtype=np.float32, count=nBx)
    B.Cwd   = np.fromfile(file, dtype=np.float32, count=nBx)

    B.Lev   = np.fromfile(file, dtype=np.uint8, count=nBx)
    B.IxShp = np.fromfile(file, dtype=np.int32, count=nBx)
    B.IxBon = np.fromfile(file, dtype=np.int32, count=nBx)

    B.nBox = nBx

    return B


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadSalcBbxEns   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads blob data as saved under w_BbxEns.

cf LoadDescSalc
"""
def ReadSalcBbxEns(file):

    class B:
        pass

    # Read bounding boxes
    B.Box, nBx = ReadBboxLbin(file)

    # read again (for safety?)
    nBx2      = np.fromfile( file, dtype=np.int32, count=1)[0]

    # Read associated attributes
    B.Cvg     = np.fromfile(file, dtype=np.float32, count=nBx)
    B.Ctr     = np.fromfile(file, dtype=np.float32, count=nBx)
    B.Typ     = np.fromfile(file, dtype=np.uint8, count=nBx)

    B.OrdGtoL = ReadIxsArr( file )

    idf = np.fromfile( file, dtype=np.int32, count=1)
    if idf != 777:
        raise ValueError("idf incorrect")

    return B






