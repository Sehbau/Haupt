"""

Read various types of features.

"""
import numpy as np



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadFeatCoverage   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Read feature coverage, ie. of boundaries or shapes.

"""
def ReadFeatCoverage(file, nLev):

    class S:
        pass
    
    S.Deg  = np.fromfile(file, dtype=np.float32, count=nLev)
    S.mx   = np.fromfile(file, dtype=np.float32, count=1)[0]
    S.ixMx = np.fromfile(file, dtype=np.int32, count=1)[0]
    S.Kt   = np.fromfile(file, dtype=np.int32, count=nLev)

    return S


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadAttDom   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads attribute dominance as saved under w_AttDom

cf LoadDescSalc.m

"""
def ReadAttDom(file):

    class S:
        pass
    
    S.men   = np.fromfile(file, dtype=np.float32, count=1)[0]
    S.max   = np.fromfile(file, dtype=np.float32, count=1)[0]
    S.ixMax = np.fromfile(file, dtype=np.int32,  count=1)[0]

    return S
