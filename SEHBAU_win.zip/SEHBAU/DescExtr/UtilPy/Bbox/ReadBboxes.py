"""

Reads bounding boxes.

"""
import os
import numpy as np



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadBboxLtxt   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads bounding boxes saved as integers from a text file.
Equivalent to MATLAB's ReadBboxLtxt.m.

RET  ABbox (np.ndarray): Bounding boxes as int16 array of shape (nBox, 4).
     nBox (int): Number of bounding boxes read.

"""
def ReadBboxLtxt(fid):

    # --------------------   Header   --------------------
    nBox = int(fid.readline().strip())
    #print(f"[nBox {nBox:4d}] ", end='')

    # --------------------   Bboxes   --------------------
    nEnt = 4  # number of bbox entries (>=4)
    ABbox = np.zeros((nBox, nEnt), dtype=np.int16)

    for l in range(nBox):
        line = fid.readline()
        if not line:
            print("Warning: Unexpected end of fid.")
            break

        parts = list(map(int, line.strip().split()))
        if len(parts) < nEnt:
            print("Warning: Row not completely read.")
            break

        ABbox[l, :] = parts[:nEnt]

    return ABbox, nBox


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadBboxLbin   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads bounding boxes saved as integers from a binary file.
Equivalent to MATLAB's ReadBboxLbin.m.

RET  ABbox (np.ndarray): Array of shape (nBox, 4) with [top, bottom, left, right] entries.
     nBox (int): Number of bounding boxes read.

"""
def ReadBboxLbin(file):

    # --------------------   Header   --------------------
    nBox = np.fromfile(file, dtype=np.int32, count=1)[0]
    # print(f"[nBox {nBox:4d}]")

    # --------------------   Bboxes   --------------------
    Top = np.fromfile(file, dtype=np.int32, count=nBox)
    Bot = np.fromfile(file, dtype=np.int32, count=nBox)
    Lef = np.fromfile(file, dtype=np.int32, count=nBox)
    Rit = np.fromfile(file, dtype=np.int32, count=nBox)

    ABbox = np.column_stack((Top, Bot, Lef, Rit))

    return ABbox, nBox

