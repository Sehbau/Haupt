#
# Wrapper function for program dscx
#
# IN    pthImg  image file path
#       pthOut  output file path
#       Admin   administration, u_ProgExecAdmin.m
#
# OUT   Out     standard output
#
import subprocess

def RennDscx( pthImg, pthOut, Admin ):

    cmnd  = 'dscx ' + pthImg + ' ' + pthOut + ' ' + Admin.optS

    # https://docs.python.org/3/library/subprocess.html

    # -----  python 3.6
    #Res = subprocess.run( cmnd,
    #			  stdout = subprocess.PIPE,
    #			  stderr = subprocess.PIPE,
    #			  universal_newlines = True )

    # -----  python 3.11
    Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    
    # ------  Verify Proper Termination  -----
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        print('Program dscx was not executed properly. Output below:' )
        print('Commmand was: ' + Res.args )
        print( Res.stdout )
        print( Res.stderr )
        quit()

    return Res.stdout


