"""

  Reads arcs attributes and space.

"""
from ReadAttGen import *
from ReadDescHeaders import ReadDescSpcHead, ReadDescAttHead, ReadDescOrgn
from ReadValues import *
from ReadPixPoints import *


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadArcAtt   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads arc attributes as saved under ArcIO.h-w_ArcSpc

"""
def ReadArcAtt( fid ):

    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = ReadDescAttHead( fid );
    S.nArc  = nDsc;
    #print(nDsc)
    
    # --------------------   Data   --------------------

    # =====   Geometry   =====
    LbGeo   = ['Krv', 'Les', 'Spz', 'Eck', 'Run', 'Ifx']
    S.Geo   = ReadStcArrFlt( fid, LbGeo )
    
    S.Smo   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Am1   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Am2   = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # =====   Appearance   =====
    S.RGB   = ReadAttRgb( fid, nDsc )

    # =====   Position   =====
    S.DirS  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Pos   = ReadAttPos( fid )

    S.Orgn  = ReadDescOrgn( fid, nDsc )
    S.Pts   = ReadDescPtsS( fid );

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int16, count=1)

    assert idf==3333, f"ReadArcAtt: idf not correct. is {idf}"

    return S, nDsc



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadArcSpc   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads space of arc attributes as saved under ArcIO.h-w_ArcSpc

"""
def ReadArcSpc( fid ):

    nLev = np.fromfile(fid, dtype=np.int32, count=1)[0]  # # of levels
    #nLev, Narc = ReadDescSpcHead( fid )

    #print( nLev )
    #print( Narc )

    AARC = [None] * nLev
    Narc = [None] * nLev
    for l in range( 0, nLev ):

        AARC[l], nArc   = ReadArcAtt( fid );

        Narc[l] = nArc

    return AARC, Narc



    
