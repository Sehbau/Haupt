%
% Example for collecting vectors
%
% Assumes we have run script plcDscx.m already.
%
clear;
run('../globalsSB');

% we take the vector files from the place recognition demo
pthVec      = '../DemoPlcRec/Desc/';
aDscNa      = dir( [ pthVec '*.dsc' ]); 
finaLst     = 'Regist/FinasVec.txt';
SaveFipaLstPrependPath( aDscNa, pthVec, finaLst );

fpColl      = 'Vect/COLL';
dscTyp      = 'skl';

%% -------   The Program   -------
fpProg      = FipaExe.collvec;  
v_ProgExists( fpProg, ispc ); 

%% -------   Execute Command   --------
cmnd         = sprintf('%s %s %s %s', fpProg, finaLst, dscTyp, fpColl );
[status Out] = dos( cmnd );
v_CmndExec( status, Out, cmnd );

%% -------   Load Output   --------
[VEC ntDsc nAtt] = LoadCollVec(    fpColl, dscTyp );
[LAB ntDscL]     = LoadCollVecLab( fpColl, dscTyp );

if ntDsc~=ntDscL, 
    warning('ntDsc not same %d <> %d. Perhaps NaN present', ntDsc, ntDscL );
    % see exsbD2vmx how to proceed.
end

%% -------   Plot   --------
ts      = sprintf('%s  [ %d %d ]', dscTyp, ntDsc, nAtt );

figure(1); clf;
imagesc(VEC);
title( ts );
colorbar();

LAtts       = o_AttsLabels();
set( gca, 'xtick', 1:nAtt, 'xticklabel', LAtts.Skl );
set( gca, 'xticklabelrotation', 45 );


