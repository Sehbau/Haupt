%
% Example for collecting vectors
%
% Assumes we have run script plcDscx.m already.
%
clear;
run('../AdminMb/globalsSB');

% we take the vector files from the place recognition demo
dirDsc      = '../DemoPlcRec/Desc/';
aDscNa      = dir( [ dirDsc '*.dsc' ]); 
finaLst     = 'Regist/FinasVec.txt';
SaveFipaLstPrependPath( aDscNa, dirDsc, finaLst );

fpColl      = 'Vect/COLL';
dscTyp      = 'skl';

%% -------   The Program   -------
fpProg      = FipaExe.collvec;  
v_ProgExists( fpProg, ispc ); 

%% -------   Execute Command   --------
cmnd         = sprintf('%s %s %s %s', fpProg, finaLst, dscTyp, fpColl );
[status Out] = system( cmnd );
v_CmndExec( status, Out, cmnd );

%% -------   Load Output   --------
[VEC ntDsc nAtt] = LoadCollVec(    fpColl, dscTyp );
[LAB ntDscL]     = LoadCollVecLab( fpColl, dscTyp );

if ntDsc~=ntDscL, 
    warning('ntDsc not same %d <> %d. Perhaps NaN present', ntDsc, ntDscL );
    % see exsbD2vmx how to proceed.
end

%% -------   Extract Vectors Level-Wise   ---------
IxLev   = LAB(:,1) + 1;     % add one to make it one-indexing
nLev    = max( IxLev );

AVEC    = cell(nLev,1);
for l = 1:nLev
    AVEC{l} = VEC(IxLev==l, :);
end

%% -------   Plot   --------
ts      = sprintf('%s  [ %d %d ]', dscTyp, ntDsc, nAtt );

figure(1); clf;
imagesc(VEC);
title( ts );
colorbar();

LAtts       = o_AttsLabels();
set( gca, 'xtick', 1:nAtt, 'xticklabel', LAtts.Skl );
set( gca, 'xticklabelrotation', 45 );


