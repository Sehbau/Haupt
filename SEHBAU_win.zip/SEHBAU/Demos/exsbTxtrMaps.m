% 
% Displays texture maps.
% 
clear;

%% =========   Execute Dscx   ========
%pthImg  = 'Imgs/img3.jpg';    pthOut  = 'Desc/img3';
pthImg  = 'Imgs/street.jpg';  pthOut  = 'Desc/street';

optS    = '--saveKol --saveTxm';

cmnd    = ['../DescExtr/dscx ' pthImg ' ' pthOut ' ' optS];

if ispc
    cmnd        = u_PathToBackSlash( cmnd );
    [Sts Out]   = dos(cmnd);    % excecute program for windows
elseif isunix
    [Sts Out]   = unix(cmnd);   % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 ); % verify output

%% ----------   Load    ---------
TXM                 = LoadTxtrMaps( [pthOut '.txm'] ); 
[Txa Shp Ens Dsc] 	= LoadDescSalc( [pthOut '.slc'] ); 

% see o_BlobLabels.m
Bhor    = Txa.Blb.Typ==5;       % horizontal
BboxHor = Txa.Blb.Box( Bhor, :);

Bvrt    = Txa.Blb.Typ==4;       % vertical
BboxVrt = Txa.Blb.Box( Bvrt, :);


%% -------------   Plot Maps   -------------
figure(1); clf;
[nr nc] = deal(4,2);

subplot(nr,nc,1);
imagesc( imread( pthImg ) );
p_BboxL( BboxHor );
p_BboxL( BboxVrt );

subplot(nr,nc,2);
imagesc( TXM.KNT.Num ); title('Num (Count)');

subplot(nr,nc,3);
imagesc( TXM.KNT.Blk ); title('Blk (Blank)');

subplot(nr,nc,4);
imagesc( TXM.OTX.Hor ); title('Horizontal');

subplot(nr,nc,5);
imagesc( TXM.OTX.Vrt ); title('Vertical');

subplot(nr,nc,6);
imagesc( TXM.OTX.Axi ); title('Axi');

subplot(nr,nc,7);
imagesc( TXM.OTX.Nil ); title('Nil');



