"""

Displays texture maps

"""
import sys
sys.path.insert(0, '..')
import AdminPy as sb
#sys.path.insert(0, '../AdminPy')
#from globalsSB import *

import subprocess
import platform

#u_AddGenPath( '../Util/' )
#u_AddGenPath( '../DescExtr/' )

# ----------   Org & Proc   ----------
#from OrgFileNames import o_FileExtensions
#from OrgAtts import *
#from LoadDescSalc import *
#from Texture import * 

Fixt, Dmy = sb.o_FileExtensions()

# ----------   Plot   ----------

#from PlotBboxes import p_BboxL
#from PlotUtils import imglabN


# ------------------------------   DesxExtr   ------------------------------
pthImg    = 'Imgs/room.png'; pthDesc   = 'Desc/room.png'
#pthImg    = 'Imgs/street.jpg'; pthDesc   = 'Desc/street'
#pthImg    = 'Imgs/forest.jpg'; pthDesc   = 'Desc/forest'

cmnd      = f'../DescExtr/dscx {pthImg} {pthDesc} --saveTxm'

# Convert path separators for Windows if necessary
if sys.platform.startswith("win"):
    cmnd = cmnd.replace('/', '\\')

# Run descriptor extractor
Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)
#Res    = subprocess.run(cmnd, shell=True)
Sts    = Res.returncode
Out    = Res.stdout + Res.stderr

pthSalc   = pthDesc + Fixt.salc
pthTxtm   = pthDesc + Fixt.txtm


# ------------------------------   Load & Retrieve   ------------------------------
Txa, Shp, Ens, Dsc = sb.LoadDescSalc( pthSalc )
TXM                = sb.LoadTxtrMaps( pthTxtm )

# see o_BlobLabels.m
Bhor    = Txa.Blb.Typ==5;       # horizontal
BboxHor = Txa.Blb.Box[ Bhor, :];

Bvrt    = Txa.Blb.Typ==4;       # vertical
BboxVrt = Txa.Blb.Box[ Bvrt, :];

#Bnum   = Txa.Blb.Typ == 1          # numerous
#Benk   = Txa.Blb.Typ == 8          # high-contrast

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
import imageio.v3 as iio

Irgb   = iio.imread( pthImg )

fig1, axes = plt.subplots(4, 2, num=2, figsize=(10, 8))
axes   = axes.ravel()

ax1    = axes[0]
ax1.imshow(Irgb)
ax1.axis('off')

# Plot bounding boxes
sb.p_BboxL( ax1, BboxHor )                     # default color
sb.p_BboxL( ax1, BboxVrt, rgbOrIx=[1, 0.5, 0])  # orange

ax2  = axes[1]
ax2.imshow(TXM.KNT.Num)
ax2.axis('off')
ax2.set_title('Num')

ax3  = axes[2]
ax3.imshow(TXM.KNT.Blk)
ax3.axis('off')
ax3.set_title('Blank')

ax4  = axes[3]
ax4.imshow(TXM.OTX['Hor'])
ax4.axis('off')
ax4.set_title('Hor')

ax5  = axes[4]
ax5.imshow(TXM.OTX['Vrt'])
ax5.axis('off')
ax5.set_title('Vrt')

ax6  = axes[5]
ax6.imshow(TXM.OTX['Axi'])
ax6.axis('off')
ax6.set_title('Axi')

ax7  = axes[6]
ax7.imshow(TXM.OTX['Nil'])
ax7.axis('off')
ax7.set_title('Nil')

plt.show(block=False)
plt.pause(2)
#plt.show()
