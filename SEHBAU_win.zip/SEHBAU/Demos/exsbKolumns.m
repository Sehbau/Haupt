% 
% Display kolumns. For understanding. 
% 
clear;

%% =========   Command   ========
% We could use RennDscx.m, but for first demonstration we are explicit:
% Concatenate program name, arguments and options to one string
pthImg  = 'Imgs/room.png';
pthOut  = 'Desc/room';
%pthImg  = 'Imgs/birds.jpg';
%pthOut  = 'Desc/birds';

optS    = '--saveKol --saveTxm';
optS    = '--saveKol --saveTxm --txws 36';

cmnd    = ['../DescExtr/dscx ' pthImg ' ' pthOut ' ' optS];

if ispc
    cmnd        = u_PathToBackSlash( cmnd );
    [Sts Out]   = dos(cmnd);    % excecute program for windows
elseif isunix
    [Sts Out]   = unix(cmnd);   % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 ); % verify output

%% ----------   Load    ---------
[KOLM Hed] 	= LoadKolumns(  [pthOut '.kol'] );
TXM         = LoadTxtrMaps( [pthOut '.txm'] ); % required for image size

KORI    = KOLM.ORI;
KLEN    = KOLM.LEN;

%% -----------   Rearrange to Map   -----------
Mlin    = sum( KORI.H, 2 );
Mnum    = reshape( Mlin, TXM.szM([2 1]) );
Mnum  	= Mnum';
Mnum    = int16(Mnum);

Mdff    = TXM.KNT.Num - Mnum;
%any(Mdff(:))

%% -------------   Plot Kolumns   -------------
figure(2); clf;
subplot(2,3,1);
imagesc( imread( pthImg ) );

subplot(2,3,2);
imagesc( Mnum );

subplot(2,3,3);
imagesc( TXM.KNT.Num );

subplot(2,3,4);
imagesc( KORI.H );
colorbar();
title('Ori Kolumns (flat)');

subplot(2,3,5);
imagesc( KLEN.H );
colorbar();
title('Len Kolumns (flat)');



