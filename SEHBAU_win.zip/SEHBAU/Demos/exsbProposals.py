"""

Displays shape-based proposals. .qbox, .qdsc

"""
import sys
sys.path.insert(0, '..')
import subprocess
import platform
from globalsSB import *

# ------------------------------   Image & Options   ------------------------------
pthImg    = 'Imgs/room.png'
pthOut    = 'Desc/room'

optS      = '--saveProp'  # one file for bboxes
#optS      = '--ssepProp'  # individual files for bboxes

# ------------------------------   Run Dscx   ------------------------------
# Construct command & run
pthDscx   = os.path.join( '../DescExtr/', 'dscx' )
cmnd      = f"{pthDscx} {pthImg} {pthOut} {optS}"
if bOSisWin:
    cmnd = cmnd.replace('/', '\\')

Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

from CmndSupp import v_CmndExec
v_CmndExec( Res )

# ------------------------------   Load Props   ------------------------------
from OrgFileNames import o_FileExtensions
from LoadProposals import LoadDescPropBbox
from LoadDescription import * #LoadDescPropAtts
from PlotDescriptors import *

Fixt, dmy = o_FileExtensions()

pthBbox   = pthOut + Fixt.qbbx
pthQdsc   = pthOut + Fixt.qdsc

BBx, Nr   = LoadDescPropBbox( pthBbox )
DSC       = LoadDescPropAtts( pthQdsc )

if 0:
    print(DSC.Ttg.Cop.Ep1)
    print(DSC.Ttg.Ax.Ep1)

# ------------------------------   Plot Bbox   ------------------------------
import matplotlib.pyplot as plt
import imageio.v3 as iio

from PlotBboxes import p_BboxL
from PlotUtils import imglabN

Irgb     = iio.imread(pthImg)

fig, Axs = plt.subplots(2, 2, figsize=(10, 8))
Axes     = Axs.ravel()

aTits = ['ShpGen', 'TtgGen', 'ShpVrt', 'ShpHor']
aBBxs = [BBx.ShpGen, BBx.TtgGen, BBx.ShpVrt, BBx.ShpHor]
NrFet = [Nr.shpGen, Nr.ttgGen, Nr.shpVrt, Nr.shpHor]
aCols = [3, 3, 4, 4]

for i in range(4):

    Axes[i].imshow(Irgb)
    Axes[i].axis('off')

    p_BboxL( Axes[i], aBBxs[i], aCols[i])

    Axes[i].set_title(f"{aTits[i]} ({NrFet[i]})")

plt.tight_layout()

plt.show(block=False), plt.pause(1)

# ------------------------------   Plot Dsc   ------------------------------
fig = plt.figure(2)
fig.clf()
nr, nc = 2, 2

# Subplot 1: shapes as circles
ax1 = fig.add_subplot(nr, nc, 1)
ax1.imshow(Irgb)
p_ShpPoleFromPos( DSC.Shp, Irgb.shape, ax=ax1)
ax1.set_title('Shapes indicated as circles')

# Subplot 2: tetragons
ax2 = fig.add_subplot(nr, nc, 2)
ax2.imshow(Irgb)
p_TtrgLst( DSC.Ttg, Irgb.shape )
ax2.set_title('Tetragons')

plt.tight_layout()
plt.show( block=False )


