% 
% Compares the output of filtering (save with --saveIsp).
%
% This concerns the original resolution only, but we plot the entire space
% nevertheless, including the contour skeleton.
%
% Uses long options:
%   --if      to set the type of filtering (pyramid or scale space).
%   --saveIsp to save the space to file with extension .isp
%
% Assumes script is run from directory 'Demos'
%
clear;
run('../AdminMb/globalsSB');        

%% ---------    Run the 2 Spaces    ----------
cmndUnf = '../DescExtr/dscx Imgs/room.png Desc/roomunf --is 2 --saveIsp'; 
cmndFlt = '../DescExtr/dscx Imgs/room.png Desc/roomflt --is 2 --if 2 --saveIsp';
cmndFlt = [cmndFlt ' --cntMinCtr 0.05']; 

if ispc
    cmndUnf = u_PathToBackSlash( cmndUnf ); 
    cmndFlt = u_PathToBackSlash( cmndFlt ); 
end

[OutUnf]    = system( cmndUnf );
[OutFlt]    = system( cmndFlt );

[GryUnf RGBunf DimUnf] = LoadImgSpace( 'Desc/roomunf.isp' );
[GryFlt RGBflt DimFlt] = LoadImgSpace( 'Desc/roomflt.isp' );

[DSCorg KtO HedO] = LoadDescImag( 'Desc/roomunf.dsc' );
[DSCgs3 KtG HedG] = LoadDescImag( 'Desc/roomflt.dsc' );

%% ---------    Plot Skeleton Contours  ----------
% This is reduced set (not full set)
Irgb    = imread('Imgs/room.png');

figure(3); clf;
nLev    = KtO.nLev;
[nr nc] = deal( nLev, 2 );
szI     = size(Irgb);

for l = 1:nLev

    % to plot contours properly, we need to specify the map size
    if HedO.space==1
        szM = round( szI / 2^(l-1) );   % pyramid
    else
        szM = szI;                      % scale-space (no modification)
    end
    
    % --------   Unfiltered   ---------
    subplot(nr, nc, l*2-1);
    imagesc( GryUnf{l} ); colormap(gray);
    
    p_CntFromAtts( DSCorg.ACNT{l}, szM );

    set(gca,'fontsize',5);
    if l==1, title('Unfiltered'); end

    % --------   Filtered   ---------
    subplot(nr, nc, l*2);
    imagesc( GryFlt{l} ); colorbar();

    p_CntFromAtts( DSCgs3.ACNT{l}, szM );     

    set(gca,'fontsize',5);
    if l==1, title('Filtered'); end
    
end


