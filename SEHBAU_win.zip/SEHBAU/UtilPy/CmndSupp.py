"""
Utility structure for arguments that are passed to programs, such as dscx, mvec, focx. 

Called from:
- RennDscx.m
- RennMvec1.m
- RennMvecL.m
- RennFocxv1.m
- etc
"""
from dataclasses import dataclass

@dataclass
class adminCmnd:

    pthProg   = ''       # path to program
    optS      = ''       # options as string. set manually or with u_OptXXX, i_OptXXX
    bOSisWin  = 1




