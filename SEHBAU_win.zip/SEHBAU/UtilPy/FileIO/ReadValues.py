"""

Read arrays, matrices and (mathematical) spaces thereof.

def ReadIxsArr( file ):
def ReadMtrxFlt( file ):
def ReadMapGen( file, szM, conversion ):
# ----------   Stc of Arr   ----------
def u_MtrxToStcArr( Mx, aFldNames ):
def ReadStcMapFlt( file, aFieldNames, szM ):
def ReadStcArrFlt( file, aFieldNames ):

"""
import numpy as np
from collections import namedtuple




""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadIxsArr   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads an index array from a binary file and returns an IxsArr object.
Equivalent to ReadIxsArr.m

"""
class IxsArr:
    
    def __init__(self, nEnt, Ix):
        self.nEnt = nEnt      # number of entries
        self.Ix   = Ix        # index array
        

def ReadIxsArr( file ):

    nEnt = np.fromfile(file, dtype=np.int32, count=1)[0]

    Ix   = np.fromfile(file, dtype=np.int32, count=nEnt)
    
    return IxsArr(nEnt, Ix)



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadMtrxFlt   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

See ReadMtrxFlt.m

"""
def ReadMtrxFlt( file ):

    # ----------   Header   ----------
    nFet = int(np.fromfile(file, dtype=np.int32, count=1)[0])
    nObs = int(np.fromfile(file, dtype=np.int32, count=1)[0])

    # print( nFet, nObs )
    
    # ----------   Matrix   ----------
    ARR  = np.fromfile(file, dtype=np.float32, count=nObs * nFet)

    # ----------   Reshape   ----------
    Mtx      = ARR.reshape((nFet, nObs)).T #, order = 'F' )

    SizeDesc = namedtuple('SizeDesc', ['nObs','nFet'])
    szD      = SizeDesc( nObs=nObs, nFet=nFet )

    #Mtx      = ARR.reshape((nFet, nObs))

    #SizeDesc = namedtuple('SizeDesc', ['nFet', 'nObs'])
    #szD      = SizeDesc(nFet=nFet, nObs=nObs)

    return Mtx, szD    



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadMapGen   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Analogous to ReadMapGen.m

cf LoadTxtrMaps

"""
def ReadMapGen( file, szM, conversion ):

    # Ensure szM is a tuple in row form
    if len(szM) != 2:
        raise ValueError("szM must have exactly two dimensions")

    nPx = szM[0] * szM[1]

    # --------------------   Read   --------------------
    Mcm = np.fromfile( file, dtype=conversion, count=nPx )

    # --------------------   Reshape   --------------------
    Map = Mcm.reshape( (szM[0], szM[1] ))

    return Map


# --------------------------------------------------------------------------------
#                               S T C   of   A R R
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   u_MtrxToStcArr   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Analogous to u_MtrxToStcArr.m

cf ReadStcMapFlt

"""
def u_MtrxToStcArr( Mx, aFldNames ):

    nObs, nFet = Mx.shape
    #nFet, nObs = Mx.shape
    nFlds      = len(aFldNames)

    assert nFlds == nFet, f"nFeatures not matching: {nFlds} <> {nFet}"

    AArr = { aFldNames[i]: Mx[:,i] for i in range(nFlds) }

    return AArr



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   u_StcArrToStcMap   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

See u_StcArrToStcMap.m

"""
def u_StcArrToStcMap( R, szM ):

    nRow, nCol = szM[0], szM[1]
    for key in R:

        Mlin   = R[key]
        #Map    = Mlin.reshape((nCol,nRow)) 
        Map    = Mlin.reshape((nRow,nCol)) 
        R[key] = Map
        
    return R



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadStcMapFlt   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

See ReadStcMapFlt.m

"""
def ReadStcMapFlt( file, aFieldNames, szM ):

    # first load as data matrix
    Mx, szD     = ReadMtrxFlt( file )

    # now turn into a struct-of-array
    SofArr      = u_MtrxToStcArr( Mx, aFieldNames )

    # now reshape arrays to maps
    SofMps      = u_StcArrToStcMap( SofArr, szM )

    return SofMps


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadStcArrFlt   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

See ReadStcArrFlt.m

"""
def ReadStcArrFlt( file, aFieldNames ):

    # first load as data matrix
    Mx, szD     = ReadMtrxFlt( file )

    #print( szD )

    # now turn into a struct-of-array
    SofArr      = u_MtrxToStcArr( Mx, aFieldNames )

    return SofArr


