
#
# https://stackoverflow.com/questions/11637293/iterate-over-object-attributes-in-python
#
def u_FieldNames( C ):

    aFn = [a for a in dir( C ) if not a.startswith('__')]

    return aFn

 
