% 
% Determines the measurement sections from mshp1
%
% sa u_MtrMesScnf.m
%
% IN    Sto   standard out (full, unselected)
%
% OUT   Mes   measurements
%
function [Mes Rts Spk] = u_MtrMesShp( Sto )

%% -----   Descriptor Distances  -----
ixMes   = strfind( Sto, 'mes' );
if isempty(ixMes), 
    Sto
    error('cannot find descriptor measurements'); 
end
Sto     = Sto( ixMes+3:end);     % eliminate section header
%Sto
% -----   Read measurements   ------
Mes     = sscanf( Sto, '%f', 3 ); % arc, str, rsg


%% -----   Size Ratios   -----
ixRsz   = strfind( Sto, 'rts' );
if isempty(ixRsz), 
    Sto
    error('cannot find size ratios'); 
end
Sto     = Sto( ixRsz+3:end);     % eliminate section header
% -----   Read measurements   ------
Rts     = sscanf( Sto, '%f', 3 ); % peri, height width

%% -----   Spektrum  -----
ixSpk   = strfind( Sto, 'spk' );
if isempty(ixSpk), 
    Sto
    error('cannot find spektrum measurement'); 
end
Sto     = Sto( ixSpk+3:end);     % eliminate section header
% -----   Read measurements   ------
Spk     = sscanf( Sto, '%f', 2 ); 

end

