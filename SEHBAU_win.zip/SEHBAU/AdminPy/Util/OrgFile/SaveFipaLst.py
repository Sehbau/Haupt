"""

"""

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   SaveFipaLst   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
"""
def SaveFipaLst( aFina, sfn ):

    try:
        with open(sfn, 'w') as fid:
            for item in aFina:
                fid.write( f"{item}\n" )
    except IOError:
        raise RuntimeError(f"SaveFipaLst: could not write to {sfn}")


    
""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   SaveFipaLstPrependPath   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Limitedly useful: assumes fixed-size extension
"""
def SaveFipaLstPrependPath( aFina, pth, sfn ):

    try:
        with open(sfn, 'w') as fid:
            for item in aFina:
                fname = item[:-4]
                fid.write( f"{pth}{fname}\n" )
    except IOError:
        raise RuntimeError(f"SaveFipaLstPrependPath: could not write to {sfn}")
