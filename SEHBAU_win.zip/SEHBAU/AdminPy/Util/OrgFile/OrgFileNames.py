"""

Organizational routines and variables.

"""

from dataclasses import dataclass

# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class dclsFinaApndExt:
    """ Struct holding file extensions for representation formats. Used together with
    the routine extending a name stem with these extensions.
    """
    dsc: str
    hsti: str
    kolm: str
    salc: str


# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FileExtensions   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

File extensions

"""
def o_FileExtensions():

    @dataclass
    class D:
        
        # ----- contours
        dscRRE = '.dscRRE'
        cntEpt = '.cntEpt'

        # ----- image
        dsc    = '.dsc'
        dsbi   = '.dsb'
        hsti   = '.hst'
        # hstc = '.hstc'     # collection (collHimg)
        # utzi = '.utz'      # utilities (deployed yet?)

        kolm   = '.kol'      # kolumns
        txtm   = '.txm'      # texture maps
        salc   = '.slc'      # saliency

        qbbx   = '.qbbx'     # proposals bbox
        qdsc   = '.qdsc'     # proposals descriptors

        cvpo   = '.cvpo'     # curve partitions organization (deployed yet?)

        # -----  features
        bonPix    = '.bonPix'
        regPix    = '.regPix'

        bonBbxRaw = '.bonBboxRaw' 
        bonBbx    = '.bonBbox'
        bonAsp    = '.bonAsp'

        # -----  shape
        shp     = '.shp'

        # -----  collection
        collHst = '.hstc'    # collHimg
        collSlc = '.slcc'    # ???
        hari    = '.hari'    # ???

        # -----  maps
        mapUch = '.mpu'

    @dataclass
    class F:
        # ----- focus
        dscf = '.dsf'
        hstf1 = '.hsf1'      # PROD/FocExtr/focxh1.cpp
        hstfL = '.hsfL'

    return D, F


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FinaApndExtRepFrmt   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Appends the extensions for representation formats.

IN   fina   file stem, ie. 'IMGDAT/Collection/Desc/DSC_'
OUT  S      struct with .dsc, .hsti, .kolm

USE  stem     = [pthBas.DescRef 'DSC_' imna.ref];
     Fixt     = o_FileExtensions();
     Lfps     = o_FinaApndExtRepFrmt( stem, Fixt );
     Lfps.dsc, Lfps.hst, ...

"""
def o_FinaApndExtRepFrmt( fist: str, Fixt ) -> dclsFinaApndExt:

#    if Fixt is None:
#        Fixt = o_FileExtensions()

    return dclsFinaApndExt(
        dsc  = f"{fist}{Fixt.dsc}",
        hsti = f"{fist}{Fixt.hsti}",
        kolm = f"{fist}{Fixt.kolm}",
        salc = f"{fist}{Fixt.salc}"
    )
