"""

Metric measurements.

pso_Mvec1Sections, example in MtchVec/exsbMatch.py
pso_Mvec1Vals,   "     in         "
def f_MtrFromMM( MM, sortTyp ):



"""
import re
from typing import Dict
import numpy as np
from dataclasses import dataclass
from collections import namedtuple



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class dclsMtrMesVec:
    """
    Metric measurements for vector matching of lists

    ai pso_Mvec1Vals below
    """
    dis = 0.0
    sim = 0.0
    txt = 0.0


@dataclass
class dclsMtrMesFromMx:
    """
    Metrics from a matrix of measurements

    ai f_MtrFromMM below
    """
    mul: float
    men: float


# how about using?    
nmdtMtrMesFromMx = namedtuple('MtrMesFromMx', ['mul','men'])

    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   pso_Mvec1Sections   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Parses standard output by program mvec1. More comments in pso_Mvec1Sections.m

"""
def pso_Mvec1Sections( Sto ):

    H = {}
    Sec: Dict[str, str] = {}

    # ----- Detect Results Section -----
    mrkMtchRes = '-----  MatchResults  -----'
    ixRes = Sto.find(mrkMtchRes)
    if ixRes == -1:
        print(Sto)
        raise ValueError("cannot find result section")
    
    Sto = Sto[ixRes:]                           # eliminate section header

    # ----- nLev -----
    ixLev = Sto.find('nLevRes') + 8
    H['ixLev'] = ixLev

    # Read 3 integers from the substring starting at ixLev
    # Using regex to extract integers
    nums = list(map(int, re.findall(r'\d+', Sto[ixLev:])))
    if len(nums) < 3:
        raise ValueError("Not enough values after 'nLevRes'")
    nLev = nums[0]
    assert 0 < nLev <= 7, f"nLev {nLev}"

    H['nLev'] = nLev
    H['bImg'] = nums[1]
    H['bFoc'] = nums[2]

    # ----- desctypes -----
    ixDty   = Sto.find('-----  desctypes  -----')
    ixEodty = Sto.find('eodty')
    if ixDty == -1 or ixEodty == -1:
        print(Sto)
        raise ValueError("cannot find desctypes or end of it")
    Sec['Dty'] = Sto[ixDty:ixEodty]

    # ----- image -----
    ixImg  = Sto.find('-----  img  -----')
    ixEoim = Sto.find('eoimg')
    if ixImg == -1 or ixEoim == -1:
        print(Sto)
        raise ValueError("cannot find image total or end of it")
    Sec['Img'] = Sto[ixImg:ixEoim]

    # ----- texture -----
    ixTxt  = Sto.find('-----  txt  -----')
    ixEotx = Sto.find('eotxt')
    if ixTxt != -1 and ixEotx != -1:
        Sec['Txt'] = Sto[ix_txt:ixEotx]

    # ----- Detect End -----
    ixEnd = Sto.find('EndOfProgram')
    if ixEnd == -1:
        raise ValueError("cannot find EndOfProgram")
    H['ixEnd'] = ixEnd

    return Sec, H




""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   pso_Mvec1Vals   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Comments in pso_Mvec1Vals.m

"""
def pso_Mvec1Vals( StoSec ):

    # --------------------   DescTypes   --------------------

    # dty  dis       sim
    # skl  1.701431  0.027669
    # rsg  6.547936  0.034358
    # arc  2.031621  0.000000
    # str  1.811071  0.009634
    # shp  7.919334  0.014331
    # eodty.

    aDty = ['skl', 'rsg', 'arc', 'str', 'shp']
    nDty = len(aDty)

    AMes   = np.zeros((nDty, 2), dtype=np.float32)
    SecDty = StoSec['Dty']
    for d, dty in enumerate(aDty):

        ixDty = SecDty.find(dty)
        if ixDty == -1:
            raise ValueError(f"Descriptor type '{dty}' not found in Dty section.")

        # Extract float values after the descriptor keyword (starting at ixDty + 5)
        MesVals = re.findall(r"[-+]?\d*\.\d+|\d+", SecDty[ixDty + 5:])
        if len(MesVals) < 2:
            raise ValueError(f"Not enough values found after descriptor '{dty}'")

        # Store the first two values: dis and sim
        AMes[d, :] = list(map(float, MesVals[:2]))


    # --------------------   Image Total   --------------------

    # dis 324.627686
    # sim 0.000000
    # eoimg.
    SecImg   = StoSec['Img']
    ixDis    = SecImg.find('dis')
    ixSim    = SecImg.find('sim')

    if ixDis == -1 or ixSim == -1:
        raise ValueError("Could not find 'dis' or 'sim' in Img section.")

    # Extract dis and sim values
    disStr = SecImg[ixDis + 3 : ixSim].strip()
    simStr = SecImg[ixSim + 3 : -1].strip()

    mesImg = dclsMtrMesVec()

    mesImg.dis = float(disStr)
    mesImg.sim = float(simStr)

    # --- Txt Section ---
    SecTxt   = StoSec.get('Txt', '')
    ixTxt    = SecTxt.find('dis')

    if ixTxt != -1:
        txtStr        = SecTxt[ixTxt + 3 : -1].strip()
        mesImg.txt    = float(txtStr)
    else:
        mesImg.txt    = None  # or handle differently if 'dis' not found


    return AMes, mesImg



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_MtrFromMM   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Comments in f_MtrFromMM.m

"""
def f_MtrFromMM( MM, sortTyp ):

    # ---------- Validate sortTyp ----------
    if sortTyp not in ("ascend", "descend"):
        raise ValueError(f"sortTyp {sortTyp} not possible: must be 'ascend' | 'descend'")

    bAscend  = (sortTyp == "ascend")
    bDescend = (sortTyp == "descend")

    # ---------- Sort ----------
    if bAscend:
        ORD12 = np.sort(MM, axis=1) 
        ORD21 = np.sort(MM, axis=0)
    else:
        ORD12 = np.sort(MM, axis=1)[:, ::-1]
        ORD21 = np.sort(MM, axis=0)[::-1, :]

    # nearest neighbors
    NN12 = ORD12[:, 0]                          # first column
    NN21 = ORD21[0, :]                          # first row

    # ---------- Descend with NaN handling ----------
    if bDescend and np.isnan(MM).any():

        MMtmp = MM.copy()
        MMtmp[ np.isnan(MMtmp) ] = -99

        ORD12 = np.sort(MMtmp, axis=1)[:, ::-1]
        ORD21 = np.sort(MMtmp, axis=0)[::-1, :]

        NN12  = ORD12[:, 0]
        NN21  = ORD21[0, :]

        # Restore NaNs
        NN12[NN12 == -99] = np.nan
        NN21[NN21 == -99] = np.nan

    # ------------------------------   Combine   ------------------------------
    if np.all(np.isnan(NN12)): menNN12 = np.nan
    else:                      menNN12 = np.nanmean(NN12)
        
    if np.all(np.isnan(NN21)): menNN21 = np.nan
    else:                      menNN21 = np.nanmean(NN21)

    mes = dclsMtrMesFromMx(
        mul =  menNN12 * menNN21,
        men = (menNN12 + menNN21) / 2
    )

    if np.isnan( mes.mul ):
        if bAscend:  mes.mul = 100
        else:        mes.mul = 0

    if np.isnan( mes.men ):
        if bAscend:  mes.men = 100
        else:        mes.men = 0

    # ------------------------------   For Plotting   ------------------------------    
    @dataclass
    class O:
        pass
    # for plotting:
    O.O12  = ORD12
    O.O21  = ORD21

    return mes, O
