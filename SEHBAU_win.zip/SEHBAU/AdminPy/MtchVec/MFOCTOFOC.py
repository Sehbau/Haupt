"""

See MFOCTOFOC.m

def f_BoxCong( h1, w1, h2, w2 ):
def f_SpcngTol( v1, h1, v2, h2, Tol ):
def f_FocToFoc( LocQ, LocR, fipaQ, fipaR, Admin, bDISP ):
def MFOCTOFOC( aFipaQuy, aFipaRef, Admin, bDISP ):

"""
import numpy as np
import subprocess

from AdminPy.FocSel.LoadReadFoc import *
from .MetricMeas import *
from AdminPy.Util.CmndSupp import *



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_BoxCong   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

see f_BoxCong.m

"""
def f_BoxCong( h1, w1, h2, w2 ):

    @dataclass
    class G:
        pass

    # --- mean dimensions
    G.hgtMen = ( h1 + h2 ) / 2 
    G.wthMen = ( w1 + w2 ) / 2 

    ## -----  side ratios  -----
    if h1 < h2:
        rtHgt   = h1 / h2
    else:
        rtHgt   = h2 / h1


    if w1 < w2:
        rtWth   = w1 / w2
    else:
        rtWth   = w2 / w1

    G.gnc   = rtHgt * rtWth          	# congruence measure


    # --- determine smaller/larger box
    sz1     = h1 * w1                	# size of first box
    sz2     = h2 * w2               	# size of second box

    if sz1 > sz2:
        G.szLrg = sz1
        G.szSml = sz2
    else:
        G.szLrg = sz2
        G.szSml = sz1


    G.rtoArea  = G.szSml / G.szLrg  	# ratio area

    return G



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_SpcngTol   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

see f_SpcngTol.m

"""
def f_SpcngTol( v1, h1, v2, h2, Tol ):

    dV  = abs( v1 - v2 )
    dH  = abs( h1 - h2 )

    if ( dV > Tol[0] ) or ( dH > Tol[1] ):
        s  = np.inf
    else:
        s  = np.sqrt( dV**2 + dH**2 )
        #s = np.hypot( dV, dH )

    return s



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FocToFoc   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

see f_FocToFoc.m

"""
def f_FocToFoc( LocQ, LocR, fipaQ, fipaR, Admin, bDISP ):

    @dataclass
    class M:
        pass

    M.OutFoc = 'not run yet';                   # dont think I use it

    ## ---------------   Spatial Relation   -------------                                      
    Gbx     = f_BoxCong( LocQ.hgtN, LocQ.wthN, LocR.hgtN, LocR.wthN )

    Tol     = [0.3, 0.3]
    
    spcng   = f_SpcngTol( LocQ.posV, LocQ.posH, LocR.posV, LocR.posH, Tol )

    #print( spcng )

    if spcng   > 1:     spcng   = 1             # will set sim to zero
    if Gbx.gnc < 0.125: Gbx.gnc = 0

    #print( Gbx.gnc )
    
    M.mtcBox  = Gbx.gnc * ( 1 - spcng )         # *** combine ***

    bMtcBox   = M.mtcBox > 0.1                  # determines whether mvec will be run

    #print(M.mtcBox)
    #breakpoint()
    
    ## -------------   Match Vectors   ---------------
    # see exsbMatch.py
    M.bMtched    = 0;
    if bMtcBox>0:

        cmnd    = Admin.pthProg + ' ' + fipaQ + ' ' + fipaR
        Res     = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
        v_CmndExec( Res )
        #M.OutFoc      = RennMvec1( fipaQ, finaR, Admin );

        #u_StdOutOptUnrec( M.OutFoc );

        Sto, Hed           = pso_Mvec1Sections( Res.stdout )
        AMesDty, M.totFoc  = pso_Mvec1Vals( Sto );

        #print( M.totFoc.dis )
        
        M.bMtched = 1

    return M
    


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   MFOCTOFOC   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

see MFOCTOFOC.m

"""
def MFOCTOFOC( aFipaQuy, aFipaRef, Admin, bDISP ):

    nFocQuy = len( aFipaQuy )
    nFocRef = len( aFipaRef )

    if bDISP>0:
        print( f'MFOCTOFOC: {nFocQuy} x {nFocRef}' )

    # ------------------------------   LIST x LIST   ------------------------------
    @dataclass
    class M:
        pass
    M.DMvec = np.full((nFocQuy, nFocRef), np.nan, dtype=np.float32)
    M.SMvec = np.full((nFocQuy, nFocRef), np.nan, dtype=np.float32)
    M.SMbox = M.SMvec.copy()

    for qq in range( nFocQuy ):
    
        #fprintf('q/r %2d/%2d: lev %d: %2d x %2d\n', ...
        #q, r, lev, nFocQuy, nFocRef);
    
        LocQuy = LoadFocDescHead( aFipaQuy[qq] )

        for rr in range( nFocRef ):
        
            LocRef = LoadFocDescHead( aFipaRef[rr] );

            # ============   FOC 2 FOC  ============
            # runs mvec1 (RennMvec1.m)
            Mftf = f_FocToFoc( LocQuy, LocRef, aFipaQuy[qq], aFipaRef[rr], Admin, bDISP )

            # -----  A2M res  -----
            M.SMbox[ qq, rr ] = Mftf.mtcBox
            if Mftf.bMtched:
                M.SMvec[ qq, rr ] = Mftf.totFoc.sim
                M.DMvec[ qq, rr ] = Mftf.totFoc.dis
            
    #print( M.SMbox )

    # ------------------------------   analysis   ------------------------------
    @dataclass
    class Mes:
        pass
    # default:
    Mes.simBox      = 0;
    Mes.simVecMul   = 0;
    Mes.simVecMen   = 0;
    Mes.disVecMul   = 0;
    Mes.disVecMen   = 0;

    if nFocQuy>0 and nFocRef>0:

        simBoxLev, OBOX = f_MtrFromMM( M.SMbox, 'descend' )
        simVecLev, OSIM = f_MtrFromMM( M.SMvec, 'descend' )
        disVecLev, ODIS = f_MtrFromMM( M.DMvec, 'ascend' )

        # overwriting default:
        Mes.simBox     = simBoxLev.men
        Mes.disVecMul  = disVecLev.mul
        Mes.disVecMen  = disVecLev.men
        Mes.simVecMul  = simVecLev.mul
        Mes.simVecMen  = simVecLev.men

    return Mes, M


