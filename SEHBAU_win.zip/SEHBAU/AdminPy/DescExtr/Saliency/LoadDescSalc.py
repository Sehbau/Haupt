"""

Loads saliency file

"""
from dataclasses import dataclass

from AdminPy.DescExtr.Saliency.ReadSaliency import *
from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescType.ReadDescTyp import *
from AdminPy.DescExtr.Bbox.ReadFeatures import *
from AdminPy.DescExtr.DescFile.Atts import *
from AdminPy.DescExtr.DescFile.LoadDescription import ReadDescStats



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   LoadDescSalc   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Loads saliency file.

RET Txa, Shp, Ens, Dsc: 

"""
def LoadDescSalc( lfp ):

    # --------------------   Open File   --------------------
    try:
        file = open(lfp, 'rb')
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not open file {lfp}")
    
    #disp_load(lfp)  # mimic DispLoad(lfp)

    # --------------------   Header   --------------------
    Hed      = ReadSalcFileHead( file, 33 )

    @dataclass
    class SLC:
        pass
    
    # --------------------   Saliency   --------------------
    # ------------   Txa Gst/Blob   -----------
    @dataclass
    class Txa:
        pass

    Txa.Gst  = ReadBlobMapGlbSts( file )

    Txa.Blb  = ReadBlobOut( file )
    
    # ------------   Shapes   -----------
    Shp      = ReadShpOut( file )
    
    # ------------   Txa Spt/Bnt   -----------
    #print('bef TxaSp/Bnt')
    Txa.Spt   = ReadPixvRCf( file )
    Txa.Bnt   = ReadPixvRCf( file )
    Txa.mxBnt = np.fromfile( file, dtype=np.float32, count=1 )[0]

    idf      = np.fromfile( file, dtype=np.int32, count=1)[0]
    if idf != -11111:
        raise ValueError("idf incorrect")

    # ------------   Ensemble   -----------
    Ens      = ReadSalcBbxEns( file )


    # --------------------   DescStats   --------------------
    #print('bef DescStats')
    Dsc      = ReadDescStats( file )
    
    file.close

    SLC.Txa = Txa
    SLC.Shp = Shp
    SLC.Ens = Ens
    SLC.Dsc = Dsc
    
    return SLC, Hed


