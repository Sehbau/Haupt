"""

Reads saliency information

"""
import numpy as np
from dataclasses import dataclass, field

from AdminPy.DescExtr.Bbox.ReadBboxes import ReadBboxLbin
from AdminPy.DescExtr.DescFile.PixPoints.ReadPixPoints import *
from AdminPy.Util.FileIO.ReadValues import *



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class salcFileHead:
    """
    Header of saliency file
    """
    nLev   = 0
    szL: np.ndarray = field(default_factory=lambda: np.array([0, 0], dtype=int))
    szM: np.ndarray = field(default_factory=lambda: np.array([0, 0], dtype=int))
    typ    = 0
    
    versLod = 0.0

@dataclass
class dclsTxtMapBis:
    """
    Corresponds to statMapBis

    ai ReadMapBisStat below
    """
    prpPres : float             # proportion present
    minv : float                # minimum value
    maxv : float                # maximum value
    men : float                 # mean value
    sdv : float                 # std dev


@dataclass
class dclsShpOut:
    """
    Bounding boxes of shapes and their associated values.
    
    ai ReadShpOut below
    """
    Box: np.ndarray
    Typ: np.ndarray
    Are: np.ndarray
    Cvg: np.ndarray
    Ctr: np.ndarray
    Cwd: np.ndarray
    Lev: np.ndarray
    IxShp: np.ndarray
    IxBon: np.ndarray
    nBox: int

    
    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------
    

""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadSalcFileHead   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the header of a saliency file (.slc)

"""
def ReadSalcFileHead( fid, typExp ):

    versExp = 1.03

    S       = salcFileHead()

    S.nRix  = np.fromfile( fid, dtype=np.int32, count=1)[0]     # # of pyramid levels
    S.szL   = np.fromfile( fid, dtype=np.int32, count=2)
    S.szM   = np.fromfile( fid, dtype=np.int32, count=2)
    S.typ   = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # file typ (imag|fidcus)

    S.versLod = np.fromfile( fid, dtype=np.float32, count=1)[0]  # version loaded

    assert S.typ == typExp, f'file idf not correct: {S.typ}, expected {typExp}'
    assert abs(S.versLod - versExp) < 0.001, f'Version depreciated: is {S.versLod:.3f}. new {versExp:.3f}'

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadMapBisStat   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads five float32 values representing texture bias statistics. Dataclass is above.

cf ReadBlobMapGlbSts below

"""
def ReadMapBisStat(fid):

    S = dclsTxtMapBis(
        np.fromfile(fid, dtype=np.float32, count=1)[0],
        np.fromfile(fid, dtype=np.float32, count=1)[0],
        np.fromfile(fid, dtype=np.float32, count=1)[0],
        np.fromfile(fid, dtype=np.float32, count=1)[0],
        np.fromfile(fid, dtype=np.float32, count=1)[0]
    )
    return S



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBlobMapGlbSts   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads global statistics of ori-bias maps as saved by xxx

"""
def ReadBlobMapGlbSts(fid):

    # --------------------   Labels   --------------------
    # Must match C/C++ counterpart
    aBlobLab = ['Num', 'Blk', 'Nil', 'Vrt', 'Hor', 'Axi', 'Uni']
    nTyp     = len(aBlobLab)

    # --------------------   Read   --------------------
    #@dataclass     does not work 
    class S:
        pass

    for label in aBlobLab:
        setattr( S, label, ReadMapBisStat(fid) )  # each returns 5 values

    # --------------------   Verify   --------------------
    idf = np.fromfile(fid, dtype=np.int32, count=1)[0]
    
    assert idf == 46593, f'idf not correct: {idf}'

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBlobOut   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads blob data as saved under wb_BlobOut (struct blobOUT).

cf LoadDescSalc
"""
def ReadBlobOut(fid):

    #@dataclass
    class B:
        pass

    # Read bounding boxes
    B.Box, nBx = ReadBboxLbin(fid)

    # Read associated attributes
    B.Typ   = np.fromfile(fid, dtype=np.float32, count=nBx)
    B.Are   = np.fromfile(fid, dtype=np.float32, count=nBx)
    B.Pon   = np.fromfile(fid, dtype=np.float32, count=nBx)
    B.Cvg   = np.fromfile(fid, dtype=np.float32, count=nBx)
    B.Ken   = np.fromfile(fid, dtype=np.float32, count=nBx)

    B.Bord  = np.fromfile(fid, dtype=np.uint8, count=nBx)
    B.IxBlb = np.fromfile(fid, dtype=np.int32, count=nBx)

    # BLOBNtyp = 8 (CntTxtAnf.h)
    B.Nblob   = np.fromfile(fid, dtype=np.int32, count=8)
    
    B.nBox = nBx

    return B


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadShpOut   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads shape data as saved under wb_ShpOut.

cf LoadDescSalc
"""
def ReadShpOut(fid):

    # read bounding boxes
    Box, nBx = ReadBboxLbin(fid)

    # read associated attributes
    Typ   = np.fromfile(fid, dtype=np.float32, count=nBx)
    Are   = np.fromfile(fid, dtype=np.float32, count=nBx)
    Cvg   = np.fromfile(fid, dtype=np.float32, count=nBx)
    Ctr   = np.fromfile(fid, dtype=np.float32, count=nBx)
    Cwd   = np.fromfile(fid, dtype=np.float32, count=nBx)

    Lev   = np.fromfile(fid, dtype=np.uint8,  count=nBx)
    IxShp = np.fromfile(fid, dtype=np.int32,  count=nBx)
    IxBon = np.fromfile(fid, dtype=np.int32,  count=nBx)

    return dclsShpOut(Box, Typ, Are, Cvg, Ctr, Cwd, Lev, IxShp, IxBon, nBx)



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadSalcBbxEns   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads blob data as saved under w_BbxEns.

cf LoadDescSalc
"""
def ReadSalcBbxEns(fid):

    @dataclass
    class B:
        pass

    # Read bounding boxes
    B.Box, nBx = ReadBboxLbin(fid)

    # read again (for safety?)
    nBx2      = np.fromfile(fid, dtype=np.int32, count=1)[0]

    # Read associated attributes
    B.Cvg     = np.fromfile(fid, dtype=np.float32, count=nBx)
    B.Ctr     = np.fromfile(fid, dtype=np.float32, count=nBx)
    B.Typ     = np.fromfile(fid, dtype=np.uint8, count=nBx)

    B.OrdGtoL = ReadIxsArr( fid )

    idf = np.fromfile( fid, dtype=np.int32, count=1)
    if idf != 777:
        raise ValueError("idf incorrect")

    return B






