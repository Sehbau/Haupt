"""

  Reads shape attributes and space.

"""
import numpy as np
from dataclasses import dataclass

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import *
from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescFile.PixPoints.ReadPixPoints import *


    
""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadShpSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads contour attributes as saved under ShpIO.h-w_ShpSpc

"""
def ReadShpAtt( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = ReadDescAttHead( fid );
    S.nShp  = nDsc;

    # --------------------   Data   --------------------

    S.Are   = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # =====   Str   =====
    S.STR, szL = ReadMtrxDat( fid, np.float32 );
    S.SFI, dmy = ReadMtrxDat( fid, np.float32 );
    #print( szL )
    
    # =====   Geometry   =====
    S.RAS, dmy = ReadMtrxDat( fid, np.float32 );
    S.ATO, dmy = ReadMtrxDat( fid, np.float32 );

    LbGeo   = ['Rib', 'Ori', 'Elo', 'AgX']
    S.GOL   = ReadStcArr( fid, np.float32, LbGeo )

    # =====   Apnc & Util   =====
    S.RGB   = ReadAttRgb( fid, nDsc )

    S.Pos   = ReadAttPos( fid )
    
    S.IxBon = np.fromfile( fid, dtype=np.int32, count=nDsc)  

    idf     = np.fromfile( fid, dtype=np.int32, count=1)
    assert idf==55555, f"ReadShpAtt: in-btw idf not correct. is {idf}"

    S.BAS, dmy = ReadMtrxDat( fid, np.float32 );
    
    # =====   Indices & Spektra   =====
    S.LGIx4str = np.fromfile( fid, dtype=np.int16, count=4 * nDsc).astype(np.int32)
    S.SpkKrv   = np.fromfile( fid, dtype=np.float32, count=5 * nDsc)

    #S.LGIx4str = S.LGIx4str.reshape((nDsc, 4))  # MATLAB-style transpose: (4, n)'
    #S.SpkKrv = S.SpkKrv.reshape((nDsc, 5))

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int32, count=1)
    assert idf==55555, f"ReadShpAtt: trail idf not correct. is {idf}"

    return S, nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadShpSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of contour attributes as saved under ShpIO.h-w_ShpSpc

"""
def ReadShpSpc( fid ):

    nLev, Nshp = ReadDescSpcHead( fid )
    #print( nLev )
    #print( Nshp )

    ASHP = [None] * nLev
    for l in range( 0, nLev ):

        ASHP[l], nShp   = ReadShpAtt( fid );

    return ASHP, Nshp


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadShpBinUni   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

see ReadShpBinUni.m
"""
def ReadShpBinUni( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    

    S.HScors, szD  = ReadMtrxDat( fid, np.uint8 );
    S.HSfine, szD  = ReadMtrxDat( fid, np.uint8 );
    S.HRas, szD    = ReadMtrxDat( fid, np.uint8 );
    S.HAto, szD    = ReadMtrxDat( fid, np.uint8 );

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadShpBinSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadShpBinSpc( fid ):

    nLev = np.fromfile( fid, dtype=np.int32, count=1 )[0]

    #print( 'ShpSpc ' + str(nLev) )
    
    @dataclass
    class S:                                    # returning as structure
        pass    

    S.AUNI = [None] * nLev
    for l in range( 0, nLev ):

        S.AUNI[l]   = ReadShpBinUni( fid );

    return S





    
