"""

  Reads bundle attributes and space.

"""
import numpy as np

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import *
from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescFile.PixPoints.ReadPixPoints import *



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBndgAtt   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads bundle attributes as saved under BndgIO.h-w_BndgSpc

"""
def ReadBndgAtt( fid ):

    @dataclass
    class S:    
        pass
    
    # --------------------   Header   --------------------
    nDsc    = ReadDescAttHead( fid );
    S.nBnd  = nDsc;

    #print(nDsc)
    
    # --------------------   Data   --------------------
    aLbGeom = [ 'Les', 'Tig', 'AgX', 'Dns' ]
    
    S.GEOM  = ReadStcArr( fid, np.float32, aLbGeom )

    # =====   Lage   =====
    S.Ori   = np.fromfile( fid, dtype=np.float32, count=nDsc)
    S.Pos   = ReadAttPos( fid )
    
    # =====   Apnc   =====
    S.RGB   = ReadAttRgb( fid, nDsc )

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int16, count=1 )
    assert idf==8888, f"ReadBndgAtt: trail idf not correct. is {idf}"

    return S, nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBndgSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of bundle attributes as saved under BndgIO.h-w_BndgSpc

"""
def ReadBndgSpc( fid ):

    nLev, Nbnd = ReadDescSpcHead( fid )

    #print( nLev )
    #print( Nbnd )

    ABND = [None] * nLev
    for l in range( 0, nLev ):

        ABND[l], nBnd   = ReadBndgAtt( fid );

    return ABND, Nbnd



    
