"""

  Reads contour attributes and space. And bins as well.

def ReadCntAtt( fid ):
def ReadCntSpc( fid ):

def ReadCntBinUni( fid ):
def ReadCntBinSpc( fid ):
def ReadCntBinBiv( fid ):


"""
import numpy as np
from dataclasses import dataclass

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import ReadDescSpcHead, ReadDescAttHead
#from .Util.ReadDescHeaders import ReadDescSpcHead, ReadDescAttHead


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntAtt   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads contour attributes as saved under CntIO.h-w_CntSpc

"""
def ReadCntAtt( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = ReadDescAttHead( fid );
    S.nCnt  = nDsc;

    # --------------------   Data   --------------------

    # =====   Geometry   =====
    S.Les   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Str   = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # =====   Position   =====
    S.Ori   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Pos   = ReadAttPos( fid )

    # =====   Appearance   =====
    S.RGB   = ReadAttRgb( fid, nDsc )
    S.Ctr   = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int16, count=1)

    assert idf==1111, f"ReadCntAtt: idf not correct. is {idf}"

    return S, nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of contour attributes as saved under CntIO.h-w_CntSpc

"""
def ReadCntSpc( fid ):

    nLev, Ncnt = ReadDescSpcHead( fid )

    #print( nLev )
    #print( Ncnt )

    ACNT = [None] * nLev
    for l in range( 0, nLev ):

        ACNT[l], nCnt   = ReadCntAtt( fid );

        assert Ncnt[l] == nCnt, 'contour count not matching'

    return ACNT, Ncnt



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntBinUni   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

see ReadCntBinUni.m
"""
def ReadCntBinUni( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    S.nCnt  = nDsc;

    # --------------------   Data   --------------------

    # =====   Geometry   =====
    S.Les   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Str   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Ori   = np.fromfile( fid, dtype=np.int32, count=nDsc )  

    # =====   Appearance   =====
    S.Red   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Grn   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Blu   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    
    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntBinBiv   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadCntBinBiv( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    

    # --------------------   Header   --------------------
    nDsc    = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    S.nCnt  = nDsc;

    # --------------------   Data   --------------------
    S.LS   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.LO   = np.fromfile( fid, dtype=np.int32, count=nDsc )  

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntBinSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadCntBinSpc( fid ):

    nLev = np.fromfile( fid, dtype=np.int32, count=1 )[0]

    #print( nLev )
    
    @dataclass
    class S:                                    # returning as structure
        pass    

    S.AUNI  = [None] * nLev
    S.ABIV  = [None] * nLev
    S.APOSA = [None] * nLev
    S.APOSQ = [None] * nLev
    for l in range( 0, nLev ):

        S.AUNI[l]   = ReadCntBinUni( fid );
        S.ABIV[l]   = ReadCntBinBiv( fid );

        S.APOSA[l]   = ReadAttPos( fid, datTyp=np.float32 )
        S.APOSQ[l]   = ReadAttPos( fid, datTyp=np.uint8 )

    return S





    
