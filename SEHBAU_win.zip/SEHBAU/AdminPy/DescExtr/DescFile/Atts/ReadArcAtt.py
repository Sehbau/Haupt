"""

  Reads arcs attributes and space.

"""
import numpy as np
from dataclasses import dataclass

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import *
from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescFile.PixPoints.ReadPixPoints import *



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadArcAtt   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads arc attributes as saved under ArcIO.h-w_ArcSpc

"""
def ReadArcAtt( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = ReadDescAttHead( fid );
    S.nArc  = nDsc;
    #print(nDsc)
    
    # --------------------   Data   --------------------

    # =====   Geometry   =====
    LbGeo   = ['Krv', 'Les', 'Spz', 'Eck', 'Run', 'Ifx']
    S.Geo   = ReadStcArr( fid, np.float32, LbGeo )
    
    S.Smo   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Am1   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Am2   = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # =====   Appearance   =====
    S.RGB   = ReadAttRgb( fid, nDsc )

    # =====   Position   =====
    S.DirS  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Pos   = ReadAttPos( fid )

    S.Orgn  = ReadDescOrgn( fid, nDsc )
    S.Pts   = ReadDescPtsS( fid );

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int16, count=1)

    assert idf==3333, f"ReadArcAtt: idf not correct. is {idf}"

    return S, nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadArcSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of arc attributes as saved under ArcIO.h-w_ArcSpc

"""
def ReadArcSpc( fid ):

    nLev = np.fromfile(fid, dtype=np.int32, count=1)[0]  # # of levels
    #nLev, Narc = ReadDescSpcHead( fid )

    #print( nLev )
    #print( Narc )

    AARC = [None] * nLev
    Narc = [None] * nLev
    for l in range( 0, nLev ):

        AARC[l], nArc   = ReadArcAtt( fid );

        Narc[l] = nArc

    return AARC, Narc


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadArcBinUni   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

see ReadArcBinUni.m
"""
def ReadArcBinUni( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    S.nArc  = nDsc;

    # --------------------   Data   --------------------
    LbGeo   = ['Les', 'Krv', 'Dir', 'Spz', 'Eck', 'Run', 'Ifx', 'Red', 'Grn', 'Blu']
    S.Geo   = ReadStcArr( fid, np.int32, LbGeo )
    
    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadArcBinBiv   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadArcBinBiv( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    

    # --------------------   Header   --------------------
    nDsc    = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    S.nArc  = nDsc;

    # --------------------   Data   --------------------
    S.LK   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.LD   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.LKD  = np.fromfile( fid, dtype=np.int32, count=nDsc )  

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadArcBinSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadArcBinSpc( fid ):

    nLev = np.fromfile( fid, dtype=np.int32, count=1 )[0]

    #print( 'at arc: ' + str(nLev) )
    
    @dataclass
    class S:                                    # returning as structure
        pass    

    S.AUNI = [None] * nLev
    S.ABIV = [None] * nLev
    for l in range( 0, nLev ):

        S.AUNI[l]   = ReadArcBinUni( fid );
        S.ABIV[l]   = ReadArcBinBiv( fid );

    return S




    
