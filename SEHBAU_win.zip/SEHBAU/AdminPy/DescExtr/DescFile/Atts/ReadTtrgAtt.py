"""

Reads tetragon attributes and space.

Elsewhere:
- u_TtrgRtrv1 in LoadDescription

"""
import numpy as np
from dataclasses import dataclass

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import *
from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescFile.PixPoints.ReadPixPoints import *


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadTtrgAtt   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads tetragon attributes as saved under TtrgIO.h-w_TtrgSpc

"""
def ReadTtrgAtt( fid ):

    @dataclass
    class Ax:
        pass

    @dataclass
    class S:    
        pass
    S.Ax = Ax
    
    # --------------------   Header   --------------------
    nDsc    = ReadDescAttHead( fid );
    S.nTtg  = nDsc;

    #print(nDsc)
    
    # --------------------   Data   --------------------
    aLbGeom = [ 'Les', 'Elo', 'Wide', 'High', 'Rhom',
                'Pllo', 'Tria', 'Irrg', 'PlHor', 'PlVrt',
                'Ger', 'Wth' ]
    aLbLage = [ 'AxVrt', 'AxHor', 'Axial', 'Lean1', 'Lean2',
                'Neig1', 'Neig2' ]
    
    S.GEOM  = ReadStcArrFlt( fid, aLbGeom )
    S.LAGE  = ReadStcArrFlt( fid, aLbLage )
    S.ANGS  = ReadMtrxFlt( fid )
    S.DICV  = ReadMtrxFlt( fid )

    # =====   Apnc & Lage   =====
    S.RGB   = ReadAttRgb( fid, nDsc )

    S.Ori   = np.fromfile( fid, dtype=np.float32, count=nDsc)
    S.Pos   = ReadAttPos( fid )
    
    # ---  points of elo-axis
    S.Ax.Ep1 = np.fromfile( fid, dtype=np.float32, count=nDsc*2 )
    S.Ax.Ep2 = np.fromfile( fid, dtype=np.float32, count=nDsc*2 )
    S.Ax.Ep1 = S.Ax.Ep1.reshape((nDsc, 2))
    S.Ax.Ep2 = S.Ax.Ep2.reshape((nDsc, 2))

    # ---  corner points as list
    S.Cop    = ReadDescCor4F( fid )

    S.IxBon = np.fromfile( fid, dtype=np.int32, count=nDsc)  

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int16, count=1)
    assert idf==4444, f"ReadTtrgAtt: trail idf not correct. is {idf}"

    return S, nDsc



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadTtrgSpc   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads space of contour attributes as saved under TtrgIO.h-w_TtrgSpc

"""
def ReadTtrgSpc( fid ):

    nLev, Nttg = ReadDescSpcHead( fid )

    #print( nLev )
    #print( Nttg )

    ATTG = [None] * nLev
    for l in range( 0, nLev ):

        ATTG[l], nTtg   = ReadTtrgAtt( fid );

    return ATTG, Nttg



    
