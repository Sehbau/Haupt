"""

Wrapper function for program dscx

"""
import subprocess, platform



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennDscx   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for dscx. Assumes that routine is run from directory
'DescExtr' (because no path is prepended to program 'dscx').

cf exsbDscxFull.py

IN    fipaImg image filepath
      fipaOut output filepath
      Args    arguments
OUT   Res     results, incl. standard output/error

"""
def RennDscx( fipaImg, fipaOut, Args ):

    # ----------   string version   ----------
    cmnd  = 'dscx ' + str(fipaImg) + ' ' + str(fipaOut) + ' ' + Args.opt

    if platform.system()=='Windows':
        cmnd = cmnd.replace('/', '\\')

    # ----------   pathlib version   ----------
    #cmnd  = ['dscx', fipaImg, fipaOut ]

    #if Args.opt:
    #    cmnd.append( Args.opt )

    # --------------------   Execute   --------------------
    # https://docs.python.org/3/library/subprocess.html

    # -----  python 3.6
    #Res = subprocess.run( cmnd,
    #			  stdout = subprocess.PIPE,
    #			  stderr = subprocess.PIPE,
    #			  universal_newlines = True )

    # -----  python 3.11
    Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    
    # --------------------   Verify Proper Termination   --------------------
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        
        print('Program dscx was not executed properly. Output below:' )
        print('Commmand was: ')
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        optwDisp  = Args.opt + ' --bDISP 3' 
        cmnd2     = ['dscx', fipaImg, fipaOut, optwDisp ]

        Res2 = subprocess.run( cmnd2, shell=True, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')

    return Res.stdout



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennDscxX   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

X for explicit program specification. For evaluation.

IN   fExe filepath of executable. 

"""
def RennDscxX( fExe, fipaImg, fipaOut, Args ):

    # ----------   string version   ----------
    cmnd  = str(fExe) + ' ' + str(fipaImg) + ' ' + str(fipaOut) + ' ' + Args.opt

    if platform.system()=='Windows':
        cmnd = cmnd.replace('/', '\\')

    # ----------   pathlib version   ----------
    #cmnd  = ['dscx', fipaImg, fipaOut ]

    #if Args.opt:
    #    cmnd.append( Args.opt )

    # --------------------   Execute   --------------------
    # https://docs.python.org/3/library/subprocess.html

    # -----  python 3.6
    #Res = subprocess.run( cmnd,
    #			  stdout = subprocess.PIPE,
    #			  stderr = subprocess.PIPE,
    #			  universal_newlines = True )

    # -----  python 3.11
    Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    
    # --------------------   Verify Proper Termination   --------------------
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        
        print('Program dscx was not executed properly. Output below:' )
        print('Commmand was: ')
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        optwDisp  = Args.opt + ' --bDISP 3' 
        cmnd2     = ['dscx', fipaImg, fipaOut, optwDisp ]

        Res2 = subprocess.run( cmnd2, shell=True, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')

    return Res.stdout


