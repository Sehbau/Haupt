"""

Wrapper function for program dscx

"""
import subprocess, platform





""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennDscx   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for dscx. Assumes that routine is run from directory
'DescExtr' (because no path is prepended to program 'dscx').

cf 

IN    fipaImg image filepath
      fipaOut output filepath
      Args    arguments
OUT   Out     standard output

"""
def RennDscx( fipaImg, fipaOut, Args ):

    cmnd  = 'dscx ' + fipaImg + ' ' + fipaOut + ' ' + Args.opt

    if platform.system()=='Windows':
        cmnd = cmnd.replace('/', '\\')

    # https://docs.python.org/3/library/subprocess.html

    # -----  python 3.6
    #Res = subprocess.run( cmnd,
    #			  stdout = subprocess.PIPE,
    #			  stderr = subprocess.PIPE,
    #			  universal_newlines = True )

    # -----  python 3.11
    Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    
    # ------  Verify Proper Termination  -----
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        print('Program dscx was not executed properly. Output below:' )
        print('Commmand was: ' + Res.args )
        print( Res.stdout )
        print( Res.stderr )
        quit()

    return Res.stdout


