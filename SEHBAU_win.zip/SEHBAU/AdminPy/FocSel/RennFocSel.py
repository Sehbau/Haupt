"""

Wrapper functions for programs fochst1, focdsc1, ...

"""
import subprocess, re, platform
from dataclasses import dataclass


@dataclass                      
class focselSiz:                # ''''''''''''''''''''   focselSiz   ''''''''''''''''''''
    """
    The two variables obtain from the (standard) output of fochst1 or focdsc1
    """
    nLev      = 0
    ntDsc     = 0

    

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennFocHst1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for fochst1.

IN    fipaDsc image filepath
      Bbx     one bounding box (TBLR)
      fipaOut output filepath
      Args    arguments
      pthProg path of program
OUT   Out     standard output

"""
def RennFocHst1( fipaDsc, Bbx, fipaOut, Args, pthProg ):

    bboxStr   = f"{Bbx[0]} {Bbx[1]} {Bbx[2]} {Bbx[3]}"

    fipaBin   = pthProg + 'fochst1'

    cmnd  = fipaBin +' '+ fipaDsc +' '+ bboxStr +' '+ fipaOut +' '+ Args.opt

    #print( cmnd )
    
    if platform.system()=='Windows':
        cmnd = cmnd.replace('/', '\\')

    # -----  python 3.11
    Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    
    # ------  Verify Proper Termination  -----
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        print('Program dscx was not executed properly. Output below:' )
        print('Commmand was: ' + Res.args )
        print( Res.stdout )
        print( Res.stderr )
        quit()

    # -----   Analyse StdOut  -----
    Sz = focselSiz

    # find 'nLevFoc' and get the number right after it
    lev = re.search(r"nLevFoc(\d+)", Res.stdout )
    if lev:
        Sz.nLev = int(lev.group(1))

    # find 'ntDsc' and get the number right after it
    ntDsc = re.search(r"ntDsc(\d+)", Res.stdout )
    if ntDsc:
        Sz.ntDsc = int( ntDsc.group(1) )
    
    return Sz, Res.stdout


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennFocDsc1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for focdsc1. Same as above but different binary name.

"""
def RennFocDsc1( fipaDsc, Bbx, fipaOut, Args, pthProg ):

    bboxStr   = f"{Bbx[0]} {Bbx[1]} {Bbx[2]} {Bbx[3]}"

    fipaBin   = pthProg + 'focdsc1'

    cmnd  = fipaBin +' '+ fipaDsc +' '+ bboxStr +' '+ fipaOut +' '+ Args.opt

    #print( cmnd )
    
    if platform.system()=='Windows':
        cmnd = cmnd.replace('/', '\\')

    # -----  python 3.11
    Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    
    # ------  Verify Proper Termination  -----
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        print('Program dscx was not executed properly. Output below:' )
        print('Commmand was: ' + Res.args )
        print( Res.stdout )
        print( Res.stderr )
        quit()

    # -----   Analyse StdOut  -----
    Sz = focselSiz

    # find 'nLevFoc' and get the number right after it
    lev = re.search(r"nLevFoc(\d+)", Res.stdout )
    if lev:
        Sz.nLev = int(lev.group(1))

    # find 'ntDsc' and get the number right after it
    ntDsc = re.search(r"ntDsc(\d+)", Res.stdout )
    if ntDsc:
        Sz.ntDsc = int( ntDsc.group(1) )
    
    return Sz, Res.stdout

