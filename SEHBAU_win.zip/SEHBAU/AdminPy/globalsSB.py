"""

 Creates some global variables.

"""

# ------------------------------   Root Path   ------------------------------
rootSehBau = 'c:/klab/ppc/SEHBAU/'              # modify to match your path
#rootSehBau = 'fullpath/SEHBAU/'              

print(f'globalsSB: adding paths to {rootSehBau}...')


# ------------------------------   VARIABLES   ------------------------------
import platform

bOSisWin = platform.system()=='Windows'         



# ------------------------------   DIRS    ------------------------------
# Dictionary of program directories
DirProg = {
   
    'descExtr': 'DescExtr/',
    'mtchVec':  'MtchVec/',
    'mtchHst':  'MtchHst/',
    'focSel':   'FocSel/',
    'shpExtr':  'ShpExtr/',
    'shpMtch':  'ShpMtch/',
    'plcRec':   'DemoPlcRec/',
    'sgrRGB':   'DemoSgrRGB/',
    'baum':     'DemoBaum/'
}


# ------------------------------   PATHABS of ProgramDirectories   ------------------------
# prepends root path to DirProg
import sys, os

PthProg = {}
for key, val in DirProg.items():

   PthProg[key] = os.path.join( rootSehBau, val )


# ------------------------------   FILEPATHSABS to ProgramBinaries   --------------------
# Dictionary of binary filepaths (absolute).
# appends binary names to PthProg
FipaExe = {
    'dscx':      os.path.join( PthProg['descExtr'], 'dscx'),
    'collhimg':  os.path.join( PthProg['descExtr'], 'collhimg'),
    'd2vmx':     os.path.join( PthProg['descExtr'], 'd2vmx'),
    'collvec':   os.path.join( PthProg['descExtr'], 'collvec'),

    'mvec1':     os.path.join( PthProg['mtchVec'],  'mvec1'),
    'mvecL':     os.path.join( PthProg['mtchVec'],  'mvecL'),
    'motvec':    os.path.join( PthProg['mtchVec'],  'motvec'),

    'mhstL':     os.path.join( PthProg['mtchHst'],  'mhstL'),
    'mkolL':     os.path.join( PthProg['mtchHst'],  'mkolL'),

    'focdsc1':   os.path.join( PthProg['focSel'],   'focdsc1'),
    'fochst1':   os.path.join( PthProg['focSel'],   'fochst1'),
    'fochstL':   os.path.join( PthProg['focSel'],   'fochstL'),

    'ptchxL':    os.path.join( PthProg['shpExtr'],  'ptchxL' ),
    'shpx':      os.path.join( PthProg['shpExtr'],  'shpx'),
    'mshp1':     os.path.join( PthProg['shpMtch'],  'mshp1'),

    'sgrRGB':    os.path.join( PthProg['sgrRGB'],   'sgrRGB'),
    'baumfarb':  os.path.join( PthProg['baum'],     'baumfarb'),
    'baumgrau':  os.path.join( PthProg['baum'],     'baumgrau'),
}   




# ------------------------------   For Evaluation   ------------------------------
pthSehqul = 'c:/klab/ppc/SEHQUL/'              



# ------------------------------   Depracated   ------------------------------


# --------------------------------------------------------------------------------
#                               P A T H   V A R I A B L E S
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_AddGenPath   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Emulates the following two commands of Matlab: 'addpath( genpath( pth ) )': it adds
all subfolders to path.

USE   u_AddGenPath( 'UtilPy/' )
      u_AddGenPath( 'DescExtr/UtilPy/' )


def u_AddGenPath( pth ):

   for root, dirs, files in os.walk( pth ):
      if root not in sys.path:
         sys.path.append(root)
"""

# ------------------------------   Add SubDirs   ------------------------------
#u_AddGenPath( '../AdminPy/' )

"""
u_AddGenPath( '../UtilPy/' )
u_AddGenPath( os.path.join( PthProg['descExtr'], 'UtilPy/' ) )

sys.path.append( PthProg['descExtr'] )
u_AddGenPath( os.path.join( PthProg['descExtr'], 'UtilPy/' ) )
u_AddGenPath( os.path.join( PthProg['sgrRGB'], 'UtilPy/' ) )

sys.path.append( PthProg['mtchVec'] ) 
u_AddGenPath( os.path.join( PthProg['mtchVec'], 'UtilPy/' ) )

sys.path.append( PthProg['mtchHst'] )
u_AddGenPath( os.path.join( PthProg['mtchHst'], 'UtilPy/' ) )

sys.path.append( PthProg['focSel'] )
u_AddGenPath( os.path.join( PthProg['focSel'], 'UtilPy/' ) )

sys.path.append( PthProg['shpExtr'] ) 
"""
