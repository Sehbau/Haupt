function [] = chdirSbDscx()
    chdir('c:/klab/ppc/SEHBAU/DescExtr');
end

