%
% Turns a data matrix [nObs nFet] into a struct of arrays given fieldnames
% in aFldNames.
%
% see u_AttsArrToStruct for case when field labels are given as a string.
%
% IN   MX         matrix [nDsc nAtt]
%      aFldNames  for example attribute names, ie. 'Vrt', 'Hor', ...
%
function [S] = u_MtrxToStcArr( MX, aFldNames )

[nObs nFet] = size(MX);

nFlds = length(aFldNames);
    
assert( nFlds==nFet, 'nFeatures not matching: %d <> %d', nFlds, nFet );

S = struct;
for i = 1:nFlds
    S.( aFldNames{i} ) = MX(:,i);
end

end

