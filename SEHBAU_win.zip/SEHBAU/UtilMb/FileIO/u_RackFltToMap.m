%
% Turns field arrays of a rack into maps of size szM.
%
% cf LoadCntYtgMaps.m
%
function [R] = u_RackFltToMap( R, szM )

aFldNa  = fieldnames( R );
nFld    = length(aFldNa);

for f = 1:nFld
    fn      = aFldNa{f};
    R.(fn)  = permute( reshape( R.(fn), szM([2 1])), [2 1] );
end

end

