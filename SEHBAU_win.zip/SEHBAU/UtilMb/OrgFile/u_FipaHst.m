% 
% Filepaths for histograms.
%
function fipa = u_FipaHst(pth)

fipa.cat  = [pth '/CatAll'];

end

