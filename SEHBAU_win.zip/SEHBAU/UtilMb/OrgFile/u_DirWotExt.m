%
% Command dir, but returns filenames without extension shed, and as list of
% strings in a cell, not as list of structs.
%
function [aFina nFil] = u_DirWotExt( rex )

aFil    = dir( rex );
nFil    = length( aFil );

aFina   = cell( nFil, 1 );
for f = 1 : nFil

    fp      = aFil(f).name;
    
    [pth,name,ext] = fileparts( fp );
    
    aFina{f} = name;
    
end

