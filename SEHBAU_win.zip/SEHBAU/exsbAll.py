"""

Runs the python example scripts. See also exsbAll.m for comments.

For full demo see Matlab scripts (exsbAll.m)

"""
import os

# Get current working directory
crrDir = os.getcwd()

# Check if we are in the SEHBAU directory
if len(crrDir) < 6 or not crrDir[-6:] == 'SEHBAU':
    os.chdir('c:/klab/ppc/SEHBAU/')  # Change to SEHBAU directory


# ------------------------------   Simple Examples   ------------------------------
os.chdir('DescExtr')

os.system('python exsbDscxSimp.py')

os.chdir('../MtchVec')

os.system('python exsbMatch.py')

os.chdir('..')

# ------------------------------   DescExtr   ------------------------------
os.chdir('DescExtr')

os.system('python exsbDscxFull.py')

os.chdir('..')


# ------------------------------   Demos   ------------------------------
os.chdir('Demos')

print('General Demos');

os.system('python exsbSmlObjDet.py')

os.system('python exsbSalBlobs.py')

os.system('python exsbProposals.py')

os.system('python exsbTxtrMaps.py')

os.chdir('..')


# ------------------------------   Hist & Vectors   ------------------------------
os.chdir('DescExtr')

print('Demo Hists & Vectors');

os.system('python exsbH2arr.py')
os.system('python exsbD2vmx.py')

os.chdir('..')

