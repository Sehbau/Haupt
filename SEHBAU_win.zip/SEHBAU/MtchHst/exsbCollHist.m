% 
% Runs program collhimg, to collect and concatenate histograms to a single
% matrix [nImg nBin].
%
% script to be run from directory 'MtchHst'
%
clear;
run('../globalsSB');

cd( PthProg.descExtr );
RennDscx( 'Imgs/img1.jpg', '../MtchHst/Desc/img1' );
RennDscx( 'Imgs/img2.jpg', '../MtchHst/Desc/img2' );

cd( PthProg.mtchHst );

aImgNaRep   = dir('Desc/*.hst');    % representation/reference image
finaLst     = 'Regist/FinasHst.txt';
SaveFipaLstPrependPath( aImgNaRep, 'Desc/', finaLst );

fipsColl    = 'Desc/COLLHST';

%% -------   The Program   -------
fpProg      = FipaExe.collhimg;  
v_ProgExists( fpProg, ispc ); 

%% -------   Execute Command   --------
cmnd         = sprintf('%s %s %s', fpProg, finaLst, fipsColl );
[status Out] = dos( cmnd );
v_CmndExec( status, Out, cmnd );

%% -------   Load Histogram   -------
Fixt        = o_FileExtensions();
[HST Nbin]  = LoadCollHist( [fipsColl Fixt.collHst] );

figure(1);
imagesc(HST);

figure(2);
bar(Nbin.Tot);
set(gca,'xticklabel', {'FltUni' 'FltBiv' 'SpaUni' 'SpaBiv'} );

