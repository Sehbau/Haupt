%
% Wrapper routine for program mhstL, matching a list of histogram files.
%
% af RennMvecL
% 
% IN   fpHstT    histogram file
%      fiRegist  list of histogram files
%      finaMes   output file name for matching results, length nFinasList   
%      Admin     administration, u_CmndAdmin.m
% OUT  Out       standard output
% 
function [Out] = RennMhstL( fpHstT, fpRegist, finaMes, Admin )

if nargin==3, 
    Admin.pthProg = ''; 
    Admin.optS    = '';
end

cmnd = [Admin.pthProg ...
        'mhstL ' fpHstT ' ' fpRegist ' ' finaMes ' ' Admin.optS];

[status Out] = dos(cmnd);                   % excecute program

%% ------  Status  ------
if status>0
    Out
    warning('something went wrong');
end

%% ------  Verify Proper Termination  -----
ixEOP = strfind( Out, 'EndOfProgram');

if isempty(ixEOP)
    fpHstT
    cmnd
    Out

    fprintf('RennMhstL: EOP not found\n'); 

    pause();
end


