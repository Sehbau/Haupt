%
% Overview of Matlab scripts that run a process or demo. This script is to
% be launched from the root directory 'SEHBAU'.
%
% Demos scripts are assumed to be run from their respective directories,
% that is, we enter the directory, then run the example script which
% loads the global variables (run through globalsSB.m), and then we return
% to the root directory again.
%

% ensure we are in the root directory (SEHBAU)
crrDir      = pwd;                  % current directory
if length(crrDir)<6  ||  strcmp(crrDir(end-5:end),'SEHBAU')==0
    cd('c:/klab/ppc/SEHBAU/');      % where SEHBAU is located
end
% this appends the directories to path variable. It is not required here,
% but we run it to assert that all is in place.
globalsSB;          

%% ------  Descriptor Extraction  (dscx)  ------
cd('DescExtr');                 % change to corresponding directory
exsbDscx1

pause(2); close all;            % we pause to ensure that figures were seen
cd('..');

%% ------  Plotting Descriptor Output  --------
cd('DescExtr/UtilMb/Examples');

exsbPlotBbox;
exsbPlotBon;
exsbPlotBonPix;
exsbPlotHist;
exsbPlotVect;
exsbPlotShape;
exsbPlotTtrg;
exsbPlotSalc;

pause(2); close all;   % we pause to ensure that figures were seen
cd('../../..');

%% ------  2 Frames  (dscx & mvec1)  ------
% establishes correspondence between two frames
cd('MtchVec');

exsbFrames           % uses mvec1

pause(2); close all;
cd('..');

%% ------  Demo Place Recognition  ------
% 5 frames being processed
cd('DemoPlcRec');

plcDscx
plcMtcImg

fprintf('Demo Place Recognition completed\n');

pause(2); close all;
cd('..');

%% ------  Matching Vectors  ------
cd('MtchVec');

exsbMvecLimg         

exsbMotVec

fprintf('Demo Matching Vectors completed\n');

pause(2); close all; 
cd('..');

%% ------  Matching Histograms  ------
cd('MtchHst');

exsbMhstLimg
exsbCollHist

fprintf('Demo Matching Histograms completed\n');

pause(2); close all; 
cd('..');

%% ------  Collecting Vectors  ------
cd('DescExtr');                 % change to corresponding directory

exsbCollVec

pause(2); close all; 
cd('..');

%% ------  Demo Segregation Patch  ------
cd('DemoSgrRGB');

exsbSgrPtch1

pause(2); close all; 
cd('..');

%% ------  Demo Tree  ------
cd('DemoBaum');

exsbBaum1grau
exsbBaum1rgb

pause(2); close all; 
cd('..');

%% ------  Shape Extraction  (shpx)  ------
cd('ShpExtr');   

exsbShpx

cd('..');

%% ------  Shape Matching (mshp)  ------
cd('ShpMtch');

exsbMshp1;

cd('..');

%% -------------------------------------------------------------
%                            FOCII
%  -------------------------------------------------------------
cd('FocSel');
exsbFocVec1
exsbFocHst1
exsbFocHstL
exsbFocVecFew
exsbFocHstFew
cd('..');

cd('DemoPlcRec');
plcDscxZon          % uses focxv1 and focxh1

% from here on, not working properly
plcMtcZon           % uses mvec1
cd('..');

cd('MtchVec');
exsbMvec1foc
exsbMhstLfoc
cd('..');

