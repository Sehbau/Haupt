"""

see plcMtcShp.m for comments.

af plcMtcProp.py

"""
import sys, subprocess, os
import numpy as np

sys.path.insert(0, '..')
import AdminPy as sb

dirImg      = 'Imgs/'
dirShps     = 'Shps/'
finaMesHst  = 'Mes/HstUor.txt'
finaMesVec  = 'Mes/Vec.txt'

aImgNa      = sb.get_FinasPatWoExt( dirImg, '*.jpg' )

# combinations of image indices
aComb = [ [0,0], [0,1], [0,2], [0,3], [0,4], [1,4], ]
nComb = len(aComb)

# command administration
Admin         = sb.dclsAdminCmnd
Admin.pthProg = sb.FipaExe['mshp1']

# nearest neighbor measurement matrices
MesImg     = np.zeros((nComb), dtype=np.float32)
DisMul     = MesImg.copy()
DisMen     = MesImg.copy()

for c in range(nComb):

    per   = aComb[c]
    ix1   = per[0]
    ix2   = per[1]

    print( f'--------------------  {ix1} {ix2}  -----------------------' )

    imgNa1  = aImgNa[ix1]
    imgNa2  = aImgNa[ix2]

    aShps1  = sb.get_FinasPat( dirShps, imgNa1 + '*.shp' )
    aShps2  = sb.get_FinasPat( dirShps, imgNa2 + '*.shp' )

    Mes, M      = sb.ShpMtch.MSHPTOSHP( aShps1, aShps2, None, Admin, 1 )

    DisMul[c]   = Mes.disVecMul
    DisMen[c]   = Mes.disVecMen

    
# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt

xLab = ['0-0', '0-1', '0-2', '0-3', '0-6', '1-6']
xPos = np.arange(len(xLab))

fig, axs = plt.subplots(3, 2, figsize=(10, 10))
axs = axs.flatten()

axs[0].bar(xPos, DisMul)
axs[0].set_xticks(xPos)
axs[0].set_xticklabels(xLab)
axs[0].set_title('dist. mult.')

axs[2].bar(xPos, DisMen)
axs[2].set_xticks(xPos)
axs[2].set_xticklabels(xLab)
axs[2].set_title('dist. summed')

plt.figure
plt.tight_layout()
plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)

print("plcMtcShp completed.")
