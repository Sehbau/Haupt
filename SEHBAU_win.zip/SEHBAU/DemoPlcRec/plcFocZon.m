%
% Descriptor selection for regionwise matching, called zones here. Zones
% are generic image partitions as in spatial histogramming. They are
% extracted from the description file with the program 'focdsc1' and
% 'fochst1'.
%
% Run first the script plcDscx.m to extract the descriptors.
%
% PREVIOUS  plcDscx.m
% CURRENT   plcFocZon.m
% NEXT      plcMtcZon1o1.m
%
clear;
run('../AdminMb/globalsSB');

dirImg      = 'Imgs/';
dirDsc      = 'Desc/';
dirFoc      = 'Focii/';
idfFoc      = 'Zon';
% change to window backslash
if ispc
    %dirDsc  = u_PathToBackSlash( dirDsc ); % not necessary I think
    dirFoc  = u_PathToBackSlash( dirFoc ); 
end

%% -----  List of Images  -----
aImg        = dir( [dirImg '*.jpg'] );
nImg        = length(aImg);
% obtain image size:
Irgb        = imread( [dirImg aImg(1).name] );
szI         = size(Irgb);

%% -----  Generate Zones Bboxes  -----
ZonesAll    = u_ZonesBboxes(szI, 0);
ZonesSel    = ZonesAll.Sep3.Vert;

%% ----------   Zones (Focus) Extraction Per Image  -----------
nZon    = ZonesSel.nZon;
idfZon  = 'Zon';
for i = 1:nImg
    
    imgNam  = aImg(i).name(1:end-4);
    fpDsc 	= [dirDsc imgNam '.dsc']; % vector file name 
    
    for f = 1:nZon
        
        Bbx     = ZonesSel.Bbox(f,:);
        strBbx  = sprintf('%d %d %d %d', Bbx(1), Bbx(2), Bbx(3), Bbx(4));
        fpOut   = [dirFoc imgNam idfZon '_F' num2str(f-1)];
        
        % -----  Vectors:
        cmnd   	= [FipaExe.focdsc1 ' ' fpDsc ' ' strBbx ' ' fpOut];
        [Sts OutFocv] = system(cmnd);     % excecute program
        if Sts>0
            OutFocv
            error('failure'); 
        end

        % -----  Histograms:
        cmnd   	= [FipaExe.fochst1 ' ' fpDsc ' ' strBbx ' ' fpOut];
        [Sts OutFoch] = system(cmnd);     % excecute program
        if Sts>0
            OutFoch
            error('failure'); 
        end
        
        fprintf('.');
    end
end

% we need to inform plcMtcZon.m how many zones were run:
save('Prm','nZon'); 
fprintf('plcFocZon fertig.');




