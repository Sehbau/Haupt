%
% Matching focus-wise for both vectors and histograms using binaries for
% lists. 
%
% IN DEVELOPMENT
%
% Run first the script plcFocZon.m to extract the descriptors.
%
% PREVIOUS   plcFocProp.m
% CURRENT    plcMtcProp.m
%
clear;
run('../globalsSB');

dirImg      = 'Imgs/';
dirDsc      = 'Desc/';          
dirFoc      = 'Focii/';
dirRegist   = 'Regist/';
finaMesHst  = 'Mes/HstUor.txt';
finaMesVec  = 'Mes/Vec.txt';
idfFoc      = '';

currDir     = pwd;
pthaFoc     = [ currDir '/' dirFoc ];
pthaRgst    = [ currDir '/' dirRegist ];

%% -----  Generate Register Files  -----
% For each image, we collect the focus filenames
aImg        = dir([dirImg '*.jpg']);
nImg        = length(aImg);
aImgNames   = cell(nImg,1);
for i = 1 : nImg
    aImgNames{i} = [aImg(i).name(1:end-4) idfFoc];
end
neLev       = 5;
aRgstHst    = SaveRegistFoc( pthaFoc, aImgNames, pthaRgst, 'hsf1', 0 );
aRgstVec    = SaveRegistFoc( pthaFoc, aImgNames, pthaRgst, 'vec', neLev );

%% ----- params & args ----
Admin           = u_CmndAdmin();
Admin.pthProg   = PthProg.mtchVec;

%% ==========   The Combinations   ==========
% the image comparisons
Comp(1,:) = [1 1];          % self
Comp(2,:) = [1 2];          % most similar      
Comp(3,:) = [1 3];          
Comp(4,:) = [1 4];          
Comp(5,:) = [1 5];          % least similar
Comp(6,:) = [2 5];
nComp     = size(Comp,1);   % number of comparisons

% loads parameter nZon (saved last line in plcDscxZon.m)
%load('Prm');                

MesImg      = zeros(nComp,1,'single');
DisSumHst   = MesImg;
DisMul      = MesImg;
SmlMul      = MesImg;
DisSum      = MesImg;
SmlSum      = MesImg;
for c = 1:nComp

    % the image pair
    ix1     = Comp(c,1);
    ix2     = Comp(c,2);

    aFocHst = LoadTextLineWise( aRgstHst{ix1} );
    nFoc1   = length( aFocHst );
    %aFocHst{:}
    
    fpRgst2hst = aRgstHst{ix2};
    % obtain value nFoc2 by loading a file
    aDmy    = LoadTextLineWise( fpRgst2hst );
    nFoc2   = length(aDmy);     
    
    % --- nFoc1 vs nFoc2 ---
    DMhst   = zeros(nFoc1, nFoc2, 'single');
    for f = 1:nFoc1
        
        % ==========   Histograms   ==========
        % this does not include spatial position
        hsf1    = aFocHst{f};
        cmnd    = [ FipaExe.mhstL ' ' hsf1 ' ' fpRgst2hst ];
        [sts OutHst] = system(cmnd);
        v_CmndExec( sts, OutHst, cmnd );
        %OutHst
        
        DMhst(f,:) = LoadFltTxt( finaMesHst, nFoc2 );
    
    end
    
    % ==========   Vectors   ==========
    % matching the corresponding levels:
    DisV   = zeros( nLev, 1, 'single');
    SimV   = ones(  nLev, 1, 'single') * 99;
    for l = 1:neLev

        aFocVec1 = LoadTextLineWise( aRgstVec{ix1, l} );
        aFocVec2 = LoadTextLineWise( aRgstVec{ix2, l} );
        % list-to-list measure:
        [MX Mes] = MFOCTOFOC( aFocVec1, aFocVec2, Admin, 0 );
        
        
    end
    
    figure(10); 
    subplot(2,2,1); imagesc(DMhst); title('Hist'); colorbar;
    subplot(2,2,2); imagesc(DVec); title('Vec Dist'); colorbar;
    subplot(2,2,3); imagesc(SimV); title('Vec Simi'); colorbar;
    pause(.1);

    % --- focus nearest neibor measure ---
    DisHstNN = min( DMhst, [], 2);
    DisVecNN = min( DVec, [], 2);
    SimVecNN = max( SimV, [], 2);

    DisSumHst(c) = sum(DisHstNN);

    DisMul(c)   = prod( DisVecNN );
    SmlMul(c)   = prod( SimVecNN );
    DisSum(c)   = sum( DisVecNN );
    SmlSum(c)   = sum( SimVecNN );

end

%% -----   Image Measure   -----



%% -----   Plot Results   -----
figure(6); clf;
[nr nc] = deal(3,2);
xLab = {'0-0' '0-1' '0-2' '0-3' '0-6' '1-6'};

subplot(nr,nc,1);
bar(DisMul);
set(gca, 'xticklabel', xLab);
title('dist. mult.');

subplot(nr,nc,2);
bar(log(SmlMul));
set(gca, 'xticklabel', xLab);
ylabel('log simi mult');
title('simi. mult.');

subplot(nr,nc,3);
bar(DisSum);
set(gca, 'xticklabel', xLab);
title('dist. summed');

subplot(nr,nc,4);
bar(log(SmlSum));
set(gca, 'xticklabel', xLab);
ylabel('log simi sumd');
title('simi. summed');

subplot(nr,nc,5);
bar(DisSumHst);
set(gca, 'xticklabel', xLab);
title('distance hist');



