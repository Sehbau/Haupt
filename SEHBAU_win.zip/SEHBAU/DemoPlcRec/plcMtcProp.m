%
% Matching focus-wise for both vectors and histograms using binaries for
% lists. 
%
% PREVIOUS   plcFocProp.m
% CURRENT    plcMtcProp.m
%
clear;
run('../AdminMb/globalsSB');

dirImg      = 'Imgs/';
dirFoc      = 'Focii/';
dirRegist   = 'Regist/';

finaMesHst  = 'Mes/HstUor.txt';

%% -----  Generate Register Files  -----
currDir     = pwd;
pthaFoc     = [ currDir '/' dirFoc ];
pthaRgst    = [ currDir '/' dirRegist ];

aImgNames   = u_DirWotExt( [dirImg '*.jpg'] );

nmxLev      = 5;
aRgstHst    = SaveRegistFoc( pthaFoc, aImgNames, pthaRgst, 'hsf1' );
aRgstDsc    = SaveRegistFoc( pthaFoc, aImgNames, pthaRgst, 'dsf', nmxLev );

%% -----  params  ----
Prm.TolSpcng    = [0.3 0.3];
Prm.minMtcBox   = 0.1;
Prm.minCong     = 0.2;
%% -----  admin  ----
remDir          = pwd;
Args            = o_CmndArgs( 'mvec' );
%Args.pthProg   = PthProg.mtchVec;
cd( PthProg.mtchVec );

%% ==========   The Combinations   ==========
% the image comparisons
Comp(1,:) = [1 1];          % self
Comp(2,:) = [1 2];          % most similar      
Comp(3,:) = [1 3];          
Comp(4,:) = [1 4];          
Comp(5,:) = [1 5];          % least similar
Comp(6,:) = [2 5];
nComp     = size(Comp,1);   % number of comparisons

MesImg      = zeros(nComp,1,'single');
DisSumHst   = MesImg;
DisMul      = MesImg;
SmlMul      = MesImg;
DisMen      = MesImg;
SmlMen      = MesImg;
BoxImg      = MesImg;
for c = 1:nComp

    % the image pair
    ix1     = Comp(c,1);
    ix2     = Comp(c,2);

    fprintf('-------------------------  %d %d  --------------------\n', ix1, ix2);

    aFocHst = LoadTextLineWise( aRgstHst{ix1} );
    nFoc1   = length( aFocHst );
    %aFocHst{:}
    
    fpRgst2hst      = aRgstHst{ix2};
    % obtain value nFoc2 by loading a register
    [aDmy nFoc2]    = LoadTextLineWise( fpRgst2hst );
    
    % ==========   Histograms   ==========
    fprintf('Hists %d x %d...', nFoc1, nFoc2 );
    DMhst   = zeros(nFoc1, nFoc2, 'single');
    for f = 1:nFoc1
        
        % this does not include spatial position
        hsf1    = aFocHst{f};
        cmnd    = [ FipaExe.mhstL ' ' hsf1 ' ' fpRgst2hst ];
        [sts OutHst] = system(cmnd);
        v_CmndExec( sts, OutHst, cmnd );
        %OutHst
        
        DMhst(f,:) = LoadFltTxt( finaMesHst, nFoc2 );
    
    end
    fprintf('done\n');
    
    % ==========   Vectors   ==========
    % matching the corresponding levels:
    BoxLev  = zeros( nmxLev, 1, 'single');
    DisLev  = ones(  nmxLev, 1, 'single') * 5;
    SimLev  = zeros( nmxLev, 1, 'single') ;
    BlevPrz = false( nmxLev, 1 );
    fprintf('Vects on max %d levs...', nmxLev);
    for l = 1:nmxLev

        if isempty( aRgstDsc{ix1, l} ), continue; end
        if isempty( aRgstDsc{ix2, l} ), continue; end

        BlevPrz(l)  = true;
        
        aFocVec1    = LoadTextLineWise( aRgstDsc{ix1, l} );
        aFocVec2    = LoadTextLineWise( aRgstDsc{ix2, l} );

        % --- list-to-list measure ---
        bDISP = 1 ; %fprintf('\n');
        [Mes MMX]   = MFOCTOFOC( aFocVec1, aFocVec2, Prm, Args, bDISP );
        
        BoxLev(l)   = Mes.simBox;
        DisLev(l)   = Mes.disVecMul;
        SimLev(l)   = Mes.simVecMen;
        
    end
    nLevFound  = find( BlevPrz,1,'last');
    fprintf('done (nLevFound %d)\n', nLevFound );

    % -----  Plotting  -----
    figure(10); 
    subplot(2,2,1); imagesc(DMhst); title('Hist'); colorbar;
    subplot(2,2,2); bar(DisLev); title('Vec Dist'); 
    subplot(2,2,3); bar(SimLev); title('Vec Simi'); 
    subplot(2,2,4); bar(BoxLev); title('Box Mtc'); 
    pause(.1);

    % =====  Image Measures  =====
    
    % --- histogram ---
    % focus nearest neibor measure 
    DisHstNN    	= min( DMhst, [], 2);
    DisSumHst(c)    = sum( DisHstNN );

    % --- vectors ---
    % NN already calculated in MFOCTOFOC. 
    % Here we integrate levels 
    Blev        = logical(1:nLevFound);
    BoxLev      = BoxLev(Blev);
    DisLev      = DisLev(Blev);
    SimLev      = SimLev(Blev);
    
    %BoxLev
    %DisLev
    
    BoxImg(c)   = mean( BoxLev );
    DisMen(c)   = mean( DisLev );
    SmlMen(c)   = mean( SimLev );

    DisMul(c)   = prod( DisLev );

    SimLev(SimLev==0) = 1; % set to one to avoid zeroing by non-matches
    SmlMul(c)   = prod( SimLev );

end

cd( remDir );

%% -----   Plot Results   -----
hf = figure(8); clf; set(hf, 'name', 'Proposals'); 
[nr nc] = deal(3,2);
xLab = {'0-0' '0-1' '0-2' '0-3' '0-6' '1-6'};

subplot(nr,nc,1);
bar(DisMul);
set(gca, 'xticklabel', xLab);
title('dist. mult.');

subplot(nr,nc,2);
bar(log(SmlMul));
set(gca, 'xticklabel', xLab);
ylabel('log simi mult');
title('simi. mult.');

subplot(nr,nc,3);
bar(DisMen);
set(gca, 'xticklabel', xLab);
title('dist. avgd');

subplot(nr,nc,4);
bar(log(SmlMen));
set(gca, 'xticklabel', xLab);
ylabel('log simi sumd');
title('simi. avgd');

subplot(nr,nc,5);
bar(DisSumHst);
set(gca, 'xticklabel', xLab);
title('distance hist');

subplot(nr,nc,6);
bar(BoxImg);
set(gca, 'xticklabel', xLab);
title('box mes');



