clear;

aFinas = dir('Desc/*.vec');

SaveFinasFull('FinasVec.txt', aFinas, 'Desc/');
