"""

"""
import sys, glob, os
sys.path.insert(0, '..')
import AdminPy as sb


# -----  paths  -----
dirImg    = "Imgs/"
pthOpr    = os.getcwd() + "/"
pthRgst   = os.path.join( pthOpr, "Regist/" )
pthDsc    = os.path.join( pthOpr, "Desc/" )
prmMtcTyp = ""

# -----  the images  -----
aImg      = glob.glob(os.path.join(dirImg, "*.jpg"))
nImg      = len(aImg)
IxImg     = [0, 1, 2, 3, 6]

# -----  parameters  -----
stgy      = "hist1st"           # histogram first
#stgy      = "kolm1st"          # kolumn first
#stgy      = "ens"              # ensemble

Prms      = sb.Cascade.o_CascIdfPrm( nImg, 0.5, stgy )
Admn      = sb.Cascade.o_CascIdfPth( )

## -----  arguments command  -----
ArgsMvec  = sb.o_CmndArgs( 'mvec' );

ArgsCasc     = sb.Cascade.dclsCascArgs
ArgsCasc.Vec = ArgsMvec


Fixt, Dmy = sb.o_FileExtensions()   

Rgst      = sb.MtchVec.o_RegistSetSave( pthRgst, pthDsc, "", IxImg, Fixt, 7) 

sb.MtchVec.v_RegistValid( Rgst.fpaDsc )


# ------------------------------   LOOP IMAGES   ------------------------------
print(f"MTCHCSC  {Prms.stgy}  prpPre {Prms.prpPre:.1f}  nPre {Prms.nPre}")

import numpy as np
# Preallocate
AMesTot    = [None] * nImg   # like cell(nImg,1)
AOrdPre    = [None] * nImg
AMESdis    = [None] * nImg
AMESsim    = [None] * nImg

ORDdis     = np.zeros((nImg, Prms.nPre), dtype=np.float32)
ORDsim     = np.zeros((nImg, Prms.nPre), dtype=np.float32)

AORDDtyDis = [None] * nImg
AORDDtySim = [None] * nImg
DM         = np.zeros((nImg, nImg), dtype=np.float32)
SM         = np.zeros((nImg, nImg), dtype=np.float32)
NNdis      = np.zeros((nImg, Prms.nPre), dtype=np.int32)
NNsim      = np.zeros((nImg, Prms.nPre), dtype=np.int32)

for i, ixi in enumerate(IxImg):

    fnQuy = os.path.join(pthDsc, Rgst.aVec[i][:-4] )
    FpQuy = sb.o_FinaApndExtRepFrmt( fnQuy, Fixt )

    Res, Sto, Fll = sb.Cascade.CASCIDF( sb.FipaExe, FpQuy, Rgst, Admn, ArgsCasc, Prms )
    
    # print( Res.OrdPre )
    
    # --- reduced (only indices)
    AOrdPre[i] = Res.OrdPre
    
    ORDdis[i,:] = Res.OrdDis
    ORDsim[i,:] = Res.OrdSim
    
    AORDDtyDis[i] = Res.ORDDtyDis
    AORDDtySim[i] = Res.ORDDtySim

    NNdis[i,:]   = Res.OrdDis          # nearest neighbors distance
    NNsim[i,:]   = Res.OrdSim          # nearest neighbors similarity

    DM[ i, Res.OrdDis ]  = Fll.MesTot[:,0]
    SM[ i, Res.OrdSim ]  = Fll.MesTot[:,1]


# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))
im1 = ax1.imshow(DM, aspect="auto")
plt.colorbar(im1, ax=ax1)
ax1.set_title("distance")

im2 = ax2.imshow(SM, aspect="auto")
plt.colorbar(im2, ax=ax2)
ax2.set_title("similarity")

plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)
