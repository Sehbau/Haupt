%
% Applying the quant hash function to the collection.
% sa clustQntBins.m
%
% PREVIOUS  plcCollVecBin.m
% CURRENT   plcQntHist.m
% NEXT      classification
%
clear;  
run('../AdminMb/globalsSB');

pthOpr      = [pwd '/'];            % path of operation
%pthDsc      = [pthOpr 'Desc/000000'];              
pthColl     = [pthOpr 'Coll/'];   
fipsVect    = [pthOpr 'Vect/000000']; 

IxImg       = [0 1 2 3 6];
nImg        = length(IxImg);

[Fext nDty] = o_FileExtensVect( );

%% --------------------   Load Quants   ------------------------
[QUNV Nqnt] = LoadQuantDtys( pthColl, Fext );
nDty        = 5; % we have only five desctypes for now
%% --------------------   LOOP IMAGES   -----------------------
for d = 1:nDty
    dty        = upper( Fext.aVbn{d}(4:end) );
    HSTC.(dty) = zeros( nImg, QUNV.(dty).nQnt, 'single');
end

for i = 1:nImg

    ixStr	= num2str( IxImg(i) );
    fipa    = [ fipsVect ixStr ];

    % -------  Collect Bin-Vects for one image  -------
    VEB     = struct;
    for d = 1:nDty
        
        fext    = Fext.aVbn{d};
        dty     = fext(4:end);
        [VBdty Dim] = LoadDescVebn( [fipa '.' fext ], i==1 );
        VEB.(dty) = VBdty;
    end

    % -----  HashVals/Hist  -----
    QID     = f_HashBinImg( VEB, QUNV );
    
    QST     = f_HistQntImg( QID, Nqnt );
    
    % -----  A2S  -----
    HSTC.CNT(i,:) = QST.Cnt;
    HSTC.RSG(i,:) = QST.Rsg;
    HSTC.ARC(i,:) = QST.Arc;
    HSTC.STR(i,:) = QST.Str;
    HSTC.SHP(i,:) = QST.Shp;
    %    HSTC.CRM(i,:) = QST.Crm;
end

%% -------------------   Stats Hist   --------------------------
fprintf('-----  Hist frequencies  -----\n');
for d = 1:nDty
    
    dty     = upper( Fext.aVbn{d}(4:end) );
    HDty    = HSTC.(dty);
    men     = mean( HDty(:) );
    maxV    = max( HDty(:) );
    
    fprintf('\t%s   mean  %1.4f    max %3d\n', dty, men, maxV );
end

%% -------------------   Plot   --------------------------
figure(3);
subplot(1,5,1); imagesc( HSTC.CNT ); title('Cnt'); ylabel('images');
subplot(1,5,2); imagesc( HSTC.RSG ); title('Rsg');
subplot(1,5,3); imagesc( HSTC.ARC ); title('Arc');
subplot(1,5,4); imagesc( HSTC.STR ); title('Str');
subplot(1,5,5); imagesc( HSTC.SHP ); title('Shp');

%figi(2);
%subplot(2,2,2); 

%% -------------------   SAVE   --------------------
if 0
    sfp = [ PthColl.Hist 'QNTS' ];
    save( sfp, 'HSTC');
    DispSave( sfp );
end







