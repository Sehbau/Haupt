"""

Descriptor extraction for place recognition demo.

More details in plcDscx.m

"""
import sys, glob, subprocess
sys.path.insert(0, '..')
from globalsSB import *
from CmndSupp import *

dirImg   = 'Imgs/'
dirDsc   = 'Desc/'

#if bOSisWin:
#    dirDsc.replace('/', '\\')

# List of image files
aImg    = glob.glob( os.path.join( dirImg, '*.jpg' ) )
nImg    = len(aImg)

# extraction options
optS        = '../DescExtr/Params/PrmDesc_Gerust.txt --saveKol --saveProp'

fipaBinDscx = FipaExe['dscx']        # file path of program binary

# Loop over images
for fipaImg in aImg:

    imgName = os.path.basename( fipaImg )
    outName = imgName[:-4]                        # remove .jpg extension
    
    fipsOut = os.path.join( dirDsc, outName )
    
    cmnd   = f'"{fipaBinDscx}" "{fipaImg}" "{fipsOut}" {optS}'
    
    Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)
    
    v_CmndExec( Res )

