"""

Descriptor extraction for place recognition demo.

More details in plcDscx.m

"""
import sys, glob, subprocess
sys.path.insert(0, '..')
from globalsSB import *
from CmndSupp import *

dirImg   = 'Imgs/'
dirDsc   = 'Desc/'

#if bOSisWin:
#    dirDsc.replace('/', '\\')

# List of image files
aImg    = glob.glob( os.path.join( dirImg, '*.jpg' ) )
nImg    = len(aImg)

# extraction options
optS        = '../DescExtr/Params/PrmDesc_Gerust.txt --saveKol'

fipaBinDscx = FipaExe['dscx']        # file path of program binary

# Loop over images
for pthImg in aImg:

    imgName = os.path.basename( pthImg )
    outName = imgName[:-4]                        # remove .jpg extension
    
    pthOut = os.path.join( dirDsc, outName )
    
    cmnd   = f'"{fipaBinDscx}" "{pthImg}" "{pthOut}" {optS}'
    
    Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)
    
    v_CmndExec( Res )

