%
% Ego motion using the 5 frames.
%
% af exsbMotVec
%
clear;
run('../AdminMb/globalsSB.m');

progName = FipaExe.motvec;

dirDsc  = 'Desc/';

aFina   = dir( [dirDsc '*.dsc'] );

nFrm    = length(aFina);

AVec    = cell(nFrm-1, 1);
for i = 1:nFrm-1

    fina1   = [dirDsc aFina(i).name];
    fina2   = [dirDsc aFina(i+1).name];
    
    cmnd    = [progName ' ' fina1 ' ' fina2 ];

    [sts Out] = system( cmnd );

    v_CmndExec( sts, Out, cmnd, 1 );
    
    lfp         = 'Mes/A.MotVec';
    AVec{i}     = LoadMotVec( lfp );        % load output to cell
    % DispLoad( lfp );    
    
end


%% ----------------   Plotting    ----------------
figure(1); clf;

for i = 1:nFrm-1
    
    p_SUBtig(4,i); hold on;
    
    Vec     = AVec{i};
    
    fprintf('Mean NNdis %1.3f', mean(Vec.Dis) );
    
    % -----  Reliable Vectors  -------- 
    
    % we attempt to find reliable vectors by discarding very dissimilar
    % matches
    
    Brlb        = Vec.Dis < 0.25;       % reliable if smaller 
    fprintf('  reliable %1.2f\n', single(nnz(Brlb)) / single(Vec.nMot) );
    
    % extract reliable
    Vec.Ep1     = Vec.Ep1(Brlb,:);
    Vec.Ep2     = Vec.Ep2(Brlb,:);
    Vec.nMot    = size(Vec.Ep1,1);

    % compute average radial motion vector
    RadRw  = Vec.Ep2(:,1) - Vec.Ep1(:,1);
    RadCl  = Vec.Ep2(:,2) - Vec.Ep1(:,2);
    menRw  = mean(RadRw);
    menCl  = mean(RadCl);
    
    % -----   Plot   --------
    PlotMotVec( Vec, 1 );
    plot( [0 menCl], [0 menRw], 'k' );
    
    %fprintf('.');
end
