"""

see plcMtcZonLst.m

"""
import sys, subprocess, os
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')
import AdminPy as sb

dirImg      = Path( 'Imgs/' )
dirFoc      = Path( 'Focii/')
dirRegist   = Path( 'Regist/' )
finaMesHst  = 'Mes/HstUor.txt'
finaMesVec  = 'Mes/Vec.txt'

aImgNa      = list( dirImg.glob( '*.jpg' ) ) 
crrDir      = Path.cwd()
pthFoc      = crrDir / dirFoc

neLev       = 4            # there is only level 4 in this example
aRgstHst    = sb.FocSel.SaveRegistFoc( pthFoc, aImgNa, dirRegist, 'hsf1', 0 )
aRgstVec    = sb.FocSel.SaveRegistFoc( pthFoc, aImgNa, dirRegist, 'dsf', neLev )

#for f in aRgstHst:
#    print( f )

# Combinations of image indices
aComb = [ [0,0], [0,1], [0,2], [0,3], [0,4], [1,4], ]
nComb = len(aComb)


from scipy.io import loadmat                    # load number of zones from previous script
Prm  = loadmat( 'Prm.mat' )

nZon = int( Prm['nZon'].squeeze() )

# nearest neighbor measurement matrices
DisHstNN = np.zeros((nComb, nZon), dtype=np.float32)
DisVecNN = np.zeros((nComb, nZon), dtype=np.float32)
SimVecNN = np.zeros((nComb, nZon), dtype=np.float32)

for c in range(nComb):

    per   = aComb[c]
    ix1   = per[0]
    ix2   = per[1]

    aFocHst, nFocHst1 = sb.Util.LoadTextLinewise( aRgstHst[ix1] )
    aFocVec, nFocVec1 = sb.Util.LoadTextLinewise( aRgstVec[ix1][neLev-1] )

    fpRgst2hst = aRgstHst[ix2]
    fpRgst2vec = aRgstVec[ix2][neLev-1]

    nFoc1 = nFocHst1                    # we pretend not knowing the number of focii
    nFoc2 = nZon                        # ...and make an exception for simplicity

    # focus-to-focus measurement matrices
    DMhst = np.zeros((nFoc1, nFoc2), dtype=np.float32)
    DMvec = np.zeros((nFoc1, nFoc2), dtype=np.float32)
    SMvec = np.zeros((nFoc1, nFoc2), dtype=np.float32)

    for i in range(nZon):

        # ==========   Histograms   ==========
        fpHst   = aFocHst[i]
        cmnd    = [ sb.FipaExe['mhstL'], fpHst, fpRgst2hst ]
        Res     = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
        sb.Util.v_CmndExec( Res )
        
        DMhst[i,:] = sb.Util.LoadFltTxt( finaMesHst, nFoc2 )

        # ==========   Vectors   ==========
        fpDsc   = aFocVec[i]
        cmnd    = [ sb.FipaExe['mvecL'], fpDsc, fpRgst2vec ]
        Res     = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
        sb.Util.v_CmndExec( Res )

        MtcFoc  = sb.MtchVec.LoadMtchMes( finaMesVec, nFoc2 )

        # ----------  MesMtx focus-to-focus  ----------
        DMvec[i,:] = MtcFoc[:,0];
        SMvec[i,:] = MtcFoc[:,1];        

    # --- Mes NN focus ---
    DisHstNN[c,:] = np.min(DMhst, axis=1)
    DisVecNN[c,:] = np.min(DMvec, axis=1)
    SimVecNN[c,:] = np.max(SMvec, axis=1)        


## -----   Measure Image   -----
DisSumHst = np.sum( DisHstNN, axis=1 )
DisMul    = np.prod( DisVecNN, axis=1 )
SmlMul    = np.prod( SimVecNN, axis=1 )
DisSum    = np.sum( DisVecNN, axis=1 )
SmlSum    = np.sum( SimVecNN, axis=1 )


# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt

xLab = ['0-0', '0-1', '0-2', '0-3', '0-6', '1-6']
xPos = np.arange(len(xLab))

fig, axs = plt.subplots(3, 2, figsize=(10, 10))
axs = axs.flatten()

axs[0].bar(xPos, DisMul)
axs[0].set_xticks(xPos)
axs[0].set_xticklabels(xLab)
axs[0].set_title('dist. mult.')

axs[1].bar(xPos, np.log(SmlMul))
axs[1].set_xticks(xPos)
axs[1].set_xticklabels(xLab)
axs[1].set_ylabel('log simi mult')
axs[1].set_title('simi. mult.')

axs[2].bar(xPos, DisSum)
axs[2].set_xticks(xPos)
axs[2].set_xticklabels(xLab)
axs[2].set_title('dist. summed')

axs[3].bar(xPos, np.log(SmlSum))
axs[3].set_xticks(xPos)
axs[3].set_xticklabels(xLab)
axs[3].set_ylabel('log simi sumd')
axs[3].set_title('simi. summed')

axs[4].bar(xPos, DisSumHst)
axs[4].set_xticks(xPos)
axs[4].set_xticklabels(xLab)
axs[4].set_title('distance hist')

# Leave the 6th subplot empty
axs[5].axis('off')

#plt.figure(6)
plt.tight_layout()
plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)
