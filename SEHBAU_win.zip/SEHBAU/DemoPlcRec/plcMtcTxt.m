%
% Texture matching with bounding boxes.
%
% Run first the script plcDscx.m to extract the descriptors.
%
% PREVIOUS  plcDscx.m
% CURRENT   plcMtcTxt.m
% NEXT      
%
clear;
run('../AdminMb/globalsSB');

dirImg      = 'Imgs/';
pthOpr      = [pwd '/'];            % path of operation
pthRgst     = [pthOpr 'Regist/'];              
pthDsc      = [pthOpr 'Desc/'];     
mesFil      = 'Mes/TxtBbox.txt';
prmMtcTyp   = '';

%% -----  the images  -----
aImg        = dir( [dirImg '*.jpg'] );
nImg        = length(aImg);
IxImg       = [0 1 2 3 6];

%% -----  register  -----
Fixt        = o_FileExtensions();
Rgst        = o_RegistSetSave( pthRgst, pthDsc, '', IxImg, Fixt, 7 );

v_RegistValid( Rgst.fpaSlc );

aFpSlc      = LoadTextLineWise( Rgst.fpaSlc );
fp1st       = aFpSlc{1};

%% ====================   MTCHTXT   ======================
fprintf('MTCHTXT\n');

Dis  = f_MtxtL( FipaExe.mtxt1, fp1st, aFpSlc, mesFil );

dnct    =  max(Dis) / Dis(1);
%fprintf('dnct: %1.3f\n', dnct );

%% ---------------   Plot   --------------
xLab    = {'0-0' '0-1' '0-2' '0-3' '0-6'};

figure(1); clf;
bar(Dis); 
set(gca, 'xticklabel', xLab);
ylabel('Distances');
title( sprintf('Distinctness %1.1f', dnct) );

