%
% Descriptor extraction for place recognition demo. 
% 
% Run from directory DemoPlcRec/
%
% PREVIOUS  -
% CURRENT   plcDscx.m
% NEXT      plcMtcImg.m
%
clear;
run('../AdminMb/globalsSB');
% cd( PthProg.plcRec );     

dirImg      = 'Imgs/';
dirDsc      = 'Desc/';              

dirDsc      = u_PathToBackSlash( dirDsc ); % change to window backslash

delete( [dirDsc '*'] );             % remove previous description files

%% -----  List of Images  -----
aImg    = dir( [dirImg '*.jpg'] );
nImg    = length(aImg);

%% ----------   Descriptor Extraction   ----------
% We modify default parameters for place rec by specifying a prm file.
% And we run with flag saveKol to save also the kolumns.
%
optS    = ['Params/PrmDesc_Gerust.txt --saveKol --saveProp']; 

for i = 1:nImg
    
    imgName = aImg(i).name;
    outNast = aImg(i).name(1:end-4);
    
    fipaImg = [dirImg imgName];      % filepath image 
    fipsOut	= [dirDsc outNast];      % output filestem
    
    cmnd   	= [FipaExe.dscx ' ' fipaImg ' ' fipsOut ' ' optS];
    
    [sts OutDscx] = system(cmnd);       % excecute program
    
    v_CmndExec( sts, OutDscx, cmnd );

    fprintf('.');
    
end

fprintf('\n');

