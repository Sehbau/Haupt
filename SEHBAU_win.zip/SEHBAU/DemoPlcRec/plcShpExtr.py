"""

Shape descriptor extraction for place recognition demo.

More details in plcShpExtr.m

"""
import sys, glob, subprocess, os
sys.path.insert(0, '..')
import AdminPy as sb
from collections import namedtuple
import numpy as np

# selection bboxes
ntupPrmBboxes = namedtuple('PrmBboxes', ['minHgt', 'minWth'])
Prm     = ntupPrmBboxes( 16, 16 )

dirImg      = 'Imgs/'
dirDsc      = 'Desc/'
dirPtch     = 'Ptch/'
dirShps     = 'Shps/'

sb.del_FilesDirPat( dirPtch, '*' )
sb.del_FilesDirPat( dirShps, '*' )

if sb.bOSisWin:
    dirPtch = dirPtch.replace('/', '\\')
    dirShps = dirShps.replace('/', '\\')


FextDsc, FextFoc  = sb.o_FileExtensions();
fipaBbx     = 'BboxPtchs.txt'          # same name for all images 
ppthPtchx   = sb.FipaExe['ptchxL']
ppthShpx    = sb.FipaExe['shpx']

## -----  List of Images  -----
aImgNam     = sb.get_FinasPatWoExt( dirDsc, '*.dsc' )
nImg        = len(aImgNam)
if nImg==0:
    print('No images found.')
    raise NoImages

# ------------------------------   LOOP IMAGES   ------------------------------
for i in range(nImg):

    imgNam  = aImgNam[i]
    print(imgNam)

    # -------------------  LOAD  ----------------------
    fpSal   = os.path.join( dirDsc, imgNam + FextDsc.salc )
    fpPrp   = os.path.join( dirDsc, imgNam + FextDsc.qbbx )
    fpDsc   = os.path.join( dirDsc, imgNam + FextDsc.qdsc )

    QBbx, Nr           = sb.LoadDescPropBbox( fpPrp )
    Txa, Shp, Ens, Dsc = sb.LoadDescSalc( fpSal )
    QDsc               = sb.LoadDescPropAtts( fpDsc )


    # -------------------  BBOXES  ----------------------
    # --- we choose general shapes from the proposal file
    BbxSel      = QBbx.ShpGen
    RGBchn      = QDsc.Shp.RGB
    RGBSel      = np.column_stack((RGBchn.Red, RGBchn.Grn, RGBchn.Blu))
    nBbx, nPrm  = BbxSel.shape
    
    # --------------------   Selection   --------------------
    if False:  # same as MATLAB's "if 0"
        IxLrg = np.arange(nBbx)   # take all (0-based indices)
    else:
        # box height and width
        BxHgt = BbxSel[:, 1] - BbxSel[:, 0]
        BxWth = BbxSel[:, 3] - BbxSel[:, 2]

        # Find indices of "large" boxes
        IxLrg = np.where((BxHgt > Prm.minHgt) & (BxWth > Prm.minWth))[0]

    nLrg = len(IxLrg)
    print(f"Selected {nLrg} props [{nLrg/nBbx:.2f}]")

    # --- subselect using IxLrg
    BbxSel      = BbxSel[IxLrg,:]
    RGBSel      = RGBSel[IxLrg,:]
    
    sb.SaveBboxL( fipaBbx, BbxSel )      # save bounding boxes

    # -------------------  PATCHEXTR  ----------------------
    fipaImg = os.path.join(dirImg, imgNam + '.jpg')
    fistOut = os.path.join(dirPtch, 'P')

    cmndX   = [ppthPtchx, fipaImg, fipaBbx, fistOut]

    Res     = subprocess.run(cmndX, capture_output=True, text=True)

    sb.v_CmndExec( Res ) 

    # -------------------  SHAPEEXTR  ----------------------
    Nbon = np.zeros(nLrg, dtype=np.int32)
    Ncrv = np.zeros(nLrg, dtype=np.int32)

    for s in range(nLrg):   

        # ---------   create patch path   ----------
        fipaPtch1 = os.path.join(dirPtch, f"P{s}.png")

        # ---------   create rgb triplet   ----------
        rgbVls = (RGBSel[s, :] * 255).astype(np.uint8)
        strRgb = f"{rgbVls[0]} {rgbVls[1]} {rgbVls[2]}"

        # ---------   create shape output path   ----------
        fipsShp = os.path.join(dirShps, imgNam + '_S' + str(s) )

        # ---------   create command   ----------
        cmndS = ppthShpx + ' ' + fipaPtch1 + ' ' + strRgb + ' ' + fipsShp
        if sys.platform.startswith("win"):
            cmndS = cmndS.replace('/', '\\')
        #cmndS = [ppthShpx, fipaPtch1, strRgb, fipsShp]

        # ---------   execute command   ----------
        Res = subprocess.run(cmndS, shell=True, capture_output=True, text=True)

        sb.v_CmndExec( Res )

        # ---------   parse output   ----------
        nBon, nCrv, umf  = sb.pso_Shpx( Res.stdout )   
        Nbon[s] = nBon
        Ncrv[s] = nCrv

    # ---------   stats printing   ----------
    print(f"Stats for img {i}:")
    print(f"\t# bons min-max    {Nbon.min():2d}-{Nbon.max():3d}")
    print(f"\t# crvs min-max    {Ncrv.min():2d}-{Ncrv.max():3d}")
    print(f"\t# zero bons/crvs  {np.sum(Nbon == 0):2d}/{np.sum(Ncrv == 0):2d}")


print('plcShpExtr completed')    
