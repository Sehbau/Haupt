"""

Descriptor matching

More details in plcMtcImg.m

"""
import sys, glob, subprocess, os
sys.path.insert(0, '..')
import AdminPy as sb

dirImg   = 'Imgs/'
dirDsc   = 'Desc/'

fipaBinMvec = sb.FipaExe['mvec1']        # file path of program binary mvec1

# List of description files
aDsc    = glob.glob( os.path.join( dirDsc, '*.dsc' ) )

# Combinations of image indices
aComb = [ [0, 1],  
          [0, 2],
          [0, 3],
          [0, 4],
          [1, 4], ]
nComb = len(aComb)

# Initialize measurement arrays
Dis    = [0.0] * nComb
Sim    = [0.0] * nComb

for c in range(nComb):

    per     = aComb[c]
    
    fipaDsc1 = aDsc[per[0]] 
    fipaDsc2 = aDsc[per[1]] 
    
    cmnd    = f'"{fipaBinMvec}" "{fipaDsc1}" "{fipaDsc2}"'

    Res     = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
    OutMtc  = Res.stdout + Res.stderr

    # Analyze output
    StoI, HedI      = sb.MtchVec.pso_Mvec1Sections(OutMtc)
    aMesDty, MesTot = sb.MtchVec.pso_Mvec1Vals(StoI)
    
    Dis[c] = MesTot.dis
    Sim[c] = MesTot.sim


# ------------------------------   Plot results   ------------------------------
import matplotlib.pyplot as plt

xLabs = ['0-1', '0-2', '0-3', '0-6', '1-6']

fig, axs = plt.subplots(2, 2, figsize=(10, 6))
xax  = range(nComb)

axs[0, 0].bar(xax, Dis)
axs[0, 0].set_xticks(xax)
axs[0, 0].set_xticklabels(xLabs)
axs[0, 0].set_title('distance vect')

axs[0, 1].bar(xax, Sim)
axs[0, 1].set_xticks(xax)
axs[0, 1].set_xticklabels(xLabs)
axs[0, 1].set_title('similarity vect')

plt.figure(1)
plt.tight_layout()
plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)
