"""

Matching hists and kolumns

more in plcMtcHstKol.m

"""
import sys, glob, subprocess, os
sys.path.insert(0, '..')
import AdminPy as sb
#from globalsSB import *
#from CmndSupp import *
#from SaveFipaLst import *
#from LoadData import *

## ----------   Prepare Input Args   --------
progMhst    = '../MtchHst/mhstL'
progMkol    = '../MtchHst/mkolL'

dirDesc     = 'Desc/'

fipaHstTst  = os.path.join( dirDesc, '0000000.hst' )    # testing image 
fipaKolTst  = os.path.join( dirDesc, '0000000.kol' )    # testing image 

aHstRep     = glob.glob( os.path.join( dirDesc, '*.hst' ) ) # representation/reference image
aKolRep     = glob.glob( os.path.join( dirDesc, '*.kol' ) ) # representation/reference image

finaRgstHst = 'Regist/FinasHst.txt'
finaRgstKol = 'Regist/FinasKol.txt'

sb.SaveFipaLst( aHstRep, finaRgstHst )
sb.SaveFipaLst( aKolRep, finaRgstKol )

finaMesHst  = 'Mes/HstLst.txt'
finaMesHuor = 'Mes/HstUor.txt'             # cannot be changed
finaMesKol  = 'Mes/KolLst.txt'
finaMesKuor = 'Mes/KolUor.txt'             # cannot be changed


## =========   Command Mhst/Mkol  ========
cmndHst      = sb.FipaExe['mhstL']+' '+fipaHstTst+' '+finaRgstHst+' '+finaMesHst
Res          = subprocess.run( cmndHst, shell=True, capture_output=True, text=True )
sb.v_CmndExec( Res )

cmndKol      = sb.FipaExe['mkolL']+' '+fipaKolTst+' '+finaRgstKol+' '+finaMesKol
Res          = subprocess.run( cmndKol, shell=True, capture_output=True, text=True )
sb.v_CmndExec( Res )


## -------   Load Matching Results   -------
nRep         = len(aHstRep);

DisHisUor    = sb.LoadFltTxt( finaMesHuor, nRep );
DisKolUor    = sb.LoadFltTxt( finaMesKuor, nRep );

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
import numpy as np

xLab = ['0-0', '0-1', '0-2', '0-3', '0-6']
xPos = np.arange(len(xLab))

plt.figure(2)
plt.clf()

plt.subplot(2, 1, 1)
plt.bar(xPos, DisHisUor)
plt.xticks(xPos, xLab)
plt.ylabel('Distances')
plt.title('Histogram Differences')

plt.subplot(2, 1, 2)
plt.bar(xPos, DisKolUor)
plt.xticks(xPos, xLab)
plt.ylabel('Distances')
plt.title('Kolumn Differences')

plt.tight_layout()
plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)


