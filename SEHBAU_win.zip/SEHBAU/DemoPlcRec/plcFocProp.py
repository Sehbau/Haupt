"""

Descriptor extraction for place recognition demo with zones.

More details in plcFocZon.m

"""
import sys, glob, subprocess, os
sys.path.insert(0, '..')
import AdminPy as sb

FextDsc, FextFoc  = sb.o_FileExtensions();

dirDsc      = 'Desc/'
dirFoc      = 'Focii/'

sb.del_FilesDirPat( dirFoc, '*' )

# --- List of descriptor files
aDsc        = glob.glob( os.path.join( dirDsc, '*.dsc' ) )
nImg        = len(aDsc)
if nImg==0:
    raise 

Admin          = sb.dclsAdminCmnd
Admin.pthProg  = sb.PthProg['focSel']


# ------------------------------   LOOP IMAGES   ------------------------------
for i in range(nImg):

    fpDsc   = aDsc[i]
    imgName = os.path.basename( fpDsc )[:-4]    # remove .jpg extension

    fpSal   = os.path.join( dirDsc, imgName + FextDsc.salc )
    fpPrp   = os.path.join( dirDsc, imgName + FextDsc.qbbx )

    QBbx, Nr           = sb.LoadDescPropBbox( fpPrp )
    Txa, Shp, Ens, Dsc = sb.LoadDescSalc( fpSal )
    
    # --- we choose general shapes from the proposal file
    BbxSel      = QBbx.ShpGen;
    nBbx, nPrm  = BbxSel.shape

    # --------------------   Focii   --------------------
    for f in range(nBbx):
    
        Bbx     = BbxSel[f,:]
        fpFoc   = dirFoc + imgName + '_F' + str(f)

        SzHst, OutHst = sb.FocSel.RennFocHst1( fpDsc, Bbx, fpFoc, Admin )
        SzDsc, OutDsc = sb.FocSel.RennFocDsc1( fpDsc, Bbx, fpFoc, Admin )

        #print(Bbx)

        assert SzDsc.nLev==SzHst.nLev, 'nLev not same'

        print('.', end='', flush=True)

        
    print('')
