"""

Focus selection with proposals.

More details in plcFocProp.m

"""
import sys, subprocess
import numpy as np
from pathlib import Path
sys.path.insert(0, '..')
import AdminPy as sb
from AdminPy.FocSel import RennFocHst1, RennFocDsc1

FextDsc, FextFoc  = sb.Util.o_FileExtensions();

dirDsc      = Path( 'Desc/' )
dirFoc      = Path( 'Focii/' )

sb.Util.del_FilesDirPat( dirFoc, '*' )

aDsc        = list( dirDsc.glob( '*.dsc' ) ) # list of descriptor files
nImg        = len(aDsc)
if nImg==0:
    raise NoImages

Args     = sb.Util.dclsArgsCmnd
pthProg  = sb.PthProg['focSel']


# ------------------------------   LOOP IMAGES   ------------------------------
for i in range(nImg):

    fpDsc   = aDsc[i]
    imgNam  = Path( fpDsc.stem )                 # remove .jpg extension

    fpSal   = dirDsc / imgNam.with_suffix( FextDsc.salc )
    fpPrp   = dirDsc / imgNam.with_suffix( FextDsc.qbbx )

    QBbx, Nr    = sb.DescExtr.LoadDescPropBbox( fpPrp )
    SLC         = sb.DescExtr.LoadDescSalc( fpSal )
    
    # --- we choose general shapes from the proposal file
    BbxSel      = QBbx.ShpGen;
    nBbx, nPrm  = BbxSel.shape

    # --------------------   Selection   --------------------
    if False:  # same as MATLAB's "if 0"
        IxLrg = np.arange(nBbx)   # take all (0-based indices)
    else:
        minHgt = 16
        minWth = 16

        # box height and width
        BxHgt = BbxSel[:, 1] - BbxSel[:, 0]
        BxWth = BbxSel[:, 3] - BbxSel[:, 2]

        # Find indices of "large" boxes
        IxLrg = np.where((BxHgt > minHgt) & (BxWth > minWth))[0]

    nLrg = len(IxLrg)
    print(f"Selected {nLrg} props [{nLrg/nBbx:.2f}]")

    # --------------------   Focii   --------------------
    for f in range(nBbx):
    
        Bbx     = BbxSel[f,:]
        fpFoc   = dirFoc / Path( str(imgNam) + '_F' + str(f) ) 

        SzHst, OutHst = RennFocHst1( str(fpDsc), Bbx, str(fpFoc), Args, pthProg )
        SzDsc, OutDsc = RennFocDsc1( str(fpDsc), Bbx, str(fpFoc), Args, pthProg )

        #print(Bbx)

        assert SzDsc.nLev==SzHst.nLev, 'nLev not same'

        print('.', end='', flush=True)

        
    print('')
