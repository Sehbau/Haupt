"""

Focus selection with proposals.

More details in plcFocProp.m

"""
import sys, glob, subprocess, os
sys.path.insert(0, '..')
import AdminPy as sb
import numpy as np


FextDsc, FextFoc  = sb.o_FileExtensions();

dirDsc      = 'Desc/'
dirFoc      = 'Focii/'

sb.del_FilesDirPat( dirFoc, '*' )

# --- List of descriptor files
aDsc        = glob.glob( os.path.join( dirDsc, '*.dsc' ) )
nImg        = len(aDsc)
if nImg==0:
    raise NoImages

Args     = sb.dclsArgsCmnd
pthProg  = sb.PthProg['focSel']


# ------------------------------   LOOP IMAGES   ------------------------------
for i in range(nImg):

    fpDsc   = aDsc[i]
    imgNam  = os.path.basename( fpDsc )[:-4]    # remove .jpg extension

    fpSal   = os.path.join( dirDsc, imgNam + FextDsc.salc )
    fpPrp   = os.path.join( dirDsc, imgNam + FextDsc.qbbx )

    QBbx, Nr           = sb.LoadDescPropBbox( fpPrp )
    Txa, Shp, Ens, Dsc = sb.LoadDescSalc( fpSal )
    
    # --- we choose general shapes from the proposal file
    BbxSel      = QBbx.ShpGen;
    nBbx, nPrm  = BbxSel.shape

    # --------------------   Selection   --------------------
    if False:  # same as MATLAB's "if 0"
        IxLrg = np.arange(nBbx)   # take all (0-based indices)
    else:
        minHgt = 16
        minWth = 16

        # box height and width
        BxHgt = BbxSel[:, 1] - BbxSel[:, 0]
        BxWth = BbxSel[:, 3] - BbxSel[:, 2]

        # Find indices of "large" boxes
        IxLrg = np.where((BxHgt > minHgt) & (BxWth > minWth))[0]

    nLrg = len(IxLrg)
    print(f"Selected {nLrg} props [{nLrg/nBbx:.2f}]")

    # --------------------   Focii   --------------------
    for f in range(nBbx):
    
        Bbx     = BbxSel[f,:]
        fpFoc   = dirFoc + imgNam + '_F' + str(f)

        SzHst, OutHst = sb.FocSel.RennFocHst1( fpDsc, Bbx, fpFoc, Args, pthProg )
        SzDsc, OutDsc = sb.FocSel.RennFocDsc1( fpDsc, Bbx, fpFoc, Args, pthProg )

        #print(Bbx)

        assert SzDsc.nLev==SzHst.nLev, 'nLev not same'

        print('.', end='', flush=True)

        
    print('')
