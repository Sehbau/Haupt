%
% Descriptor selection from proposals (.slc, .qprp). 
%
% Run first the script plcDscx.m to extract the descriptors.
%
% PREVIOUS  plcDscx.m
% CURRENT   plcFocProp.m
% NEXT      plcMtcProp.m
%
clear;
run('../AdminMb/globalsSB.m'); 

dirDsc      = 'Desc/';
dirFoc      = 'Focii/';
delete( [dirFoc '*'] );             % remove previous focus files

if ispc
    %dirDsc  = u_PathToBackSlash( dirDsc ); % not necessary I think
    dirFoc  = u_PathToBackSlash( dirFoc ); 
end
Fext    	= o_FileExtensions();

Args        = o_CmndArgs('focsel');

%% -----  List of Images  -----
[aImgNam nImg]  = u_DirWotExt( [dirDsc '*.dsc'] );

if nImg==0
    fprintf('No images found.'); return;
end

%% ----------   Focus Extraction Per Image  -----------
optS    = '';
for i = 1:nImg
    
    imgNam  = aImgNam{i}; %aDsc(i).name(1:end-4);

    fpDsc 	= [dirDsc imgNam Fext.dsc ];    
    fpSal   = [dirDsc imgNam Fext.salc];
    fpPrp   = [dirDsc imgNam Fext.qbbx];

    % --- load saliency and proposals
    [Txa Shp Ens Dsc]   = LoadDescSalc( fpSal );
    [QBbx Nr]           = LoadDescPropBbox( fpPrp );

    % --- we choose general shapes from the proposal file
    BbxSel      = QBbx.ShpGen;
    nBbx        = size(BbxSel,1);
    
    % --- take all OR select based on size (if desired)
    if 0
        IxLrg       = 1:nBbx;                       % take all
    else
        minHgt      = 16;
        minWth      = 16;
        % identify the large ones 
        BxHgt       = BbxSel(:,2) - BbxSel(:,1);    % box height
        BxWth       = BbxSel(:,4) - BbxSel(:,3);    % box width
        IxLrg       = find( BxHgt>minHgt & BxWth>minWth );  
    end
    nLrg        = length(IxLrg);
    fprintf('Selected %d props [%1.2f]\n', nLrg, nLrg/nBbx);
    
    % ---------  LOOP FOCII  ------------
    for l = 1:nLrg
        
        f       = IxLrg(l);
        Bbx     = BbxSel(f,:);

        fpOut   = [dirFoc imgNam '_F' num2str(f-1)];
        
        [SzDsc OutDsc] = RennFocDsc1( fpDsc, Bbx, fpOut, Args, PthProg.focSel );
        [SzHst OutHst] = RennFocHst1( fpDsc, Bbx, fpOut, Args, PthProg.focSel );
        
        assert( SzDsc.nLev==SzHst.nLev, 'nLev not same');
        % not same, because we use full set for histogramming
        %assert( SzDsc.ntDsc==SzHst.ntDsc, 'nLev not same');
        
        fprintf('.');
    end
end

fprintf('\n');




