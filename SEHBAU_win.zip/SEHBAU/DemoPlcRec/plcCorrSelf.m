%
% Self-correlating all 5 frames.
%
% This demonstrates the use of program MVECLXLfull (without any specific
% recognition goal in mind).
%
% Run first the script plcDscx.m to extract the descriptors.
%
% PREVIOUS  plcDscx.m
% CURRENT   plcCorrSelf.m, af plcCascIdf.m
% NEXT      
%
clear;
run('../AdminMb/globalsSB');

dirImg      = 'Imgs/';
pthOpr      = [pwd '/'];            % path of operation
pthRgst     = [pthOpr 'Regist/'];              
pthDsc      = [pthOpr 'Desc/'];              
prmMtcTyp   = '';                   % no parameters
%prmMtcTyp   = 'RgbOff';            % set chromatic weights to zero

%% -----  the images  -----
aImg        = dir( [dirImg '*.jpg'] );
nImg        = length(aImg);
IxImg       = [0 1 2 3 6];

%% -----  arguments command  -----
Admn        = o_MvecAdmin( PthProg.mtchVec );
Args        = o_CmndArgs( 'mvec' );
pthPrmFile  = [ PthProg.mtchVec 'Params/' ];
Args.fpPrm  = u_PrmFileGen( prmMtcTyp, pthPrmFile, 'Mtch', 1 );
Args.fpMes  = Admn.fpMesVec;
v_CmndArgs( Args, '' );

%% -----  register  -----
Fixt        = o_FileExtensions();
Rgst        = o_RegistSetSave( pthRgst, pthDsc, '', IxImg, Fixt, 7 );

v_RegistValid( Rgst.fpaDsc );

%% ---------------   RUN    -------------------
bPlot   = 1;
bDisp   = 1;
[Ens DTY] = MVECLXLfull( Rgst.fpaDsc, Rgst.fpaDsc, Admn, Args,...
                     	'', bPlot, bDisp );

%% ---------------   Plot   --------------
figure(1); clf;
subplot(1,2,1);
imagesc( Ens.DM ); colorbar; title('distance');
subplot(1,2,2);
imagesc( Ens.SM ); colorbar; title('similarity');

