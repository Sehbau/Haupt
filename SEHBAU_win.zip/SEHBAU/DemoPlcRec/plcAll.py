"""

The equivalent of plcAll.m

"""

import os

os.system('python plcDscx.py')

## -----   Whole Image   -----
os.system('python plcMtcImg.py')
os.system('python plcMtcHstKol.py')

## -----   Focii using Zones   -----
os.system('python plcFocZon.py')

#os.system('python plcMtcZon1o1.py') # does not exist
os.system('python plcMtcZonLst.py')




