%
% Overview of Matlab scripts that run a process or demo. This script is to
% be launched from the root directory 'SEHBAU'.
%
% Demos scripts are assumed to be run from their respective directories:
% 1) we enter the directory, 2) run the example script which
% loads the global variables (run through globalsSB.m), 3) we return
% to the root directory.
%

% ensure we are in the root directory (SEHBAU)
crrDir      = pwd;                  % current directory
if length(crrDir)<6  ||  strcmp(crrDir(end-5:end),'SEHBAU')==0
    cd('c:/klab/ppc/SEHBAU/');      % where SEHBAU is located
end
% this appends the directories to path variable. It is not required here,
% but we run it to assert that all is in place.
globalsSB;          

%% ------  Simple Demos  ------
cd('DescExtr');                 % change to corresponding directory
exsbDscxSimp                    % simple demo

cd('../MtchVec');
exsbMatch

cd('..');

%% ------  Descriptor Extraction  (dscx)  ------
cd('DescExtr');                 % change to corresponding directory
exsbDscxFull                    % demo with wrapper routines and plotting

pause(2); close all;            % we pause to ensure that figures were seen
cd('..');

%% ------  Plotting Descriptor Output  --------
cd('DescExtr/UtilMb/Examples');

exsbPlotBbox;
exsbPlotBon;
exsbPlotBonPix;

exsbPlotHist;
exsbPlotDesc;
exsbPlotShape;
exsbPlotTtrg;
exsbPlotSalc;

pause(2); close all;   % we pause to ensure that figures were seen
cd('../../..');

%% ------  2 Frames  (dscx & mvec1)  ------
% establishes correspondence between two frames
cd('MtchVec');

exsbFrames           % uses mvec1

pause(2); close all;
cd('..');

%% ------  Demo Place Recognition  ------
% 5 frames being processed
cd('DemoPlcRec');

plcDscx
plcMtcImg

fprintf('Demo Place Recognition completed\n');

pause(2); close all;
cd('..');

%% ------  Matching Vectors  ------
cd('MtchVec');

exsbMvecLimg         

exsbMotVec

fprintf('Demo Matching Vectors completed\n');

pause(2); close all; 
cd('..');

%% ------  Matching Histograms/Kolumns  ------
cd('MtchHst');

exsbMhstLimg
exsbCollHist
exsbMhstPlcRec

fprintf('Demo Matching Histograms/Kolumns completed\n');

pause(2); close all; 
cd('..');

%% ------  Vector Files  ------
cd('DescExtr');                 % change to corresponding directory

exsbD2vmx
exsbCollVec

exsbH2arr

pause(2); close all; 
cd('..');

%% ------  Demo Segregation Patch  ------
cd('DemoSgrRGB');

exsbSgrPtch1

pause(2); close all; 
cd('..');

%% ------  Demo Tree  ------
cd('DemoBaum');

exsbBaum1grau
exsbBaum1rgb

pause(2); close all; 
cd('..');

%% ------  Shape Extraction  (shpx)  ------
cd('ShpExtr');   

exsbShpx

cd('..');

%% ------  Shape Matching (mshp)  ------
cd('ShpMtch');

exsbMshp1;

cd('..');

%% ------  Demos  ------
cd('Demos');

exsbImgSpaces;
exsbSmlObjDet;
exsbSpaHist;

% texture:
exsbKolumns;
exsbTxtrMaps;
exsbSalBlobs;

exsbProposals;

pause(2); close all; 
cd('..');

%% -------------------------------------------------------------
%                            FOCII
%  -------------------------------------------------------------
cd('FocSel');
exsbFocDsc1
exsbFocHst1
exsbFocHstL
exsbFocDscFew
exsbFocHstFew
cd('..');

cd('DemoPlcRec');
plcDscxZon          % uses focdsc1 and fochst1

plcMtcZon           % uses mvec1
cd('..');

% from here on depracated
%cd('MtchVec');
% exsbMvec1foc
% exsbMhstLfoc
%cd('..');

fprintf('Demos completed. Back in %s\n', pwd );

