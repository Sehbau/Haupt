%
% Loads the description as saved under si_Desc
%
function [D Kt Hed] = LoadDescImag(lfn) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----------------------   Header   ---------------------------
Hed             = ReadDescFileHead( fileID, 10 );

%% -----------------------   Spaces   ---------------------------
[D.ACNT Kt.Ncnt]  = ReadCntSpc(fileID); % skelet
[D.ARSG Kt.Nrsg]  = ReadRsgSpc(fileID);
% gerust
[nLev Narc]       = ReadDescSpcHead(fileID);
[nLev Nstr]       = ReadDescSpcHead(fileID);
[D.AARC Kt.Narc]  = ReadArcSpc(fileID);
[D.ASTR Kt.Nstr]  = ReadStrSpc(fileID); 

[D.ASHP Kt.Nshp]  = ReadShpSpc(fileID); % shape

idfSpc    = fread(fileID, 1,  'int=>int');    % identifier
if (idfSpc~=66666) 
    error('Spaces not properly read (see si_DescVect');
end

[D.ATTRG Kt.Nttrg] = ReadTtrgSpc(fileID); % tetragons
[D.ABNDG Kt.Nbndg] = ReadBndgSpc(fileID); % bundles

%% -----------------------   Shape Labels   ---------------------------
% reads them as one array
D.LabShpScors = ReadAttLab( fileID, size(D.ASHP{1}.STR,2) );
D.LabShpSfine = ReadAttLab( fileID, size(D.ASHP{1}.SFI,2) );


%% -----------------------   Trailer   ---------------------------
idf    = fread(fileID, 1,  'int=>int'); % identifier

fclose(fileID);

if (idf~=99999)
    fprintf('file identifier not correct %d. Expected 99999\n', idf);
    D.ASHP
    Kt.Nshp
    pause('pausing in LoadDescVect');
end

%% ------   A2S   -------
%Kt.Ncnt
% cast to double: manipulation is easier in Matlab with double
Kt.nLev    = double(Hed.nLev);      
Kt.szV     = double(Hed.szV);
Kt.szH     = double(Hed.szH);
Kt.ntDsc   = double(Hed.ntDsc);

