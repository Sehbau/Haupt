% 
% Plots a list of bounding boxes representing the various oriented
% textures. 5th column holds type.
%
% IN   ABbox   list of bboxes
%      rgbOrIx rgb triplet or index
%
function [] = p_BboxLotx( S, aBlobTypS )

aBbx   = S.Box;

OriTyp = S.Typ;           % 1st column holds texture type

for t = 1 : length(aBlobTypS)
    st = aBlobTypS{t};
    Bbx.(st) = aBbx( OriTyp==t, :);
end

% colors from p_CntOriTxt.m
p_BboxL( Bbx.Knt, [128 128 128] / 256 ); % gray
p_BboxL( Bbx.Blk, [255 255 255] / 256 ); % white

p_BboxL( Bbx.Nil, [0   255 0  ] / 256 ); % green
p_BboxL( Bbx.Vrt, [255 255 0  ] / 256 ); % yellow
p_BboxL( Bbx.Hor, [0   0   255] / 256 ); % blue
p_BboxL( Bbx.Axi, [0   255 255] / 256 ); % cyan
p_BboxL( Bbx.Uni, [255 128   0] / 256 ); % orange

end

%     Col(1,:) = [255 255   0]; % yellow
%     Col(2,:) = [255 128   0]; % orange
%     Col(3,:) = [191 191   0]; % beige
%     Col(4,:) = [255 0     0]; % rot
%     Col(5,:) = [170 0   255]; % magenta
%     Col(6,:) = [0   255 255]; % cyan
%     Col(7,:) = [0   0   255]; % blue
%     Col(8,:) = [255 255 255]; % white
%     Col(9,:) = [0   255   0]; % green