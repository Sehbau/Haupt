%
% Example for loading the vectors. 
%
% Run from WITHIN directory UtilMb/Examples
%
% Function scripts in directory 'Vect/'
%
clear;
run('../../../globalsSB.m');

pthVect     = '../../Desc/img1.vec';       % vectors for one image
%pthVect     = '../../Desc/img2.vec';       % vectors for one image
%pthVect     = '../../Desc/aachen.vec';       % vectors for one image

[DVEC Kt]   = LoadDescVect(pthVect);    % in directory 'Vect'

if Kt.nLev>6, Kt.nLev = 6; end      % limit to 6 levels

%% -----   Geometrie  -----
% example for creating geometry descriptors for the 1st level:
C1  = DVEC.ACNT{1};
GMX = [C1.Les C1.Str C1.Ori];           % geometry only [nCnt 3]

fprintf('Some ranges:\n');
fprintf('Ori angles %1.3f to %1.3f\n', min(C1.Ori), max(C1.Ori));
fprintf('Lengths    %1.3f to %1.3f\n', min(C1.Les), max(C1.Les));

%% -----   Plot Contours  -----
% unit resolution
hf = figure(1); clf; set(hf, 'name', 'Contours');
for lev = 1:Kt.nLev
    
    CNTlv = DVEC.ACNT{lev};         % extracting one level
    
    subplot(3, 2, lev); hold on;
    
    p_CntFromVect(CNTlv);           % in directory 'Vect'

    set(gca,'xlim',[-0.02 1.02]);
    set(gca,'ylim',[-0.02 1.02]);
end

%% -----   Plot Rsg  -----
% unit resolution
hf = figure(2); clf; set(hf, 'name', 'radsig'); 
for lev = 1:Kt.nLev
    
    RSGlv = DVEC.ARSG{lev};         % extracting one level
    
    subplot(3, 2, lev); hold on;
    
    p_RsgFromVect( RSGlv );         % in directory 'Vect'

    set(gca,'xlim',[-0.02 1.02]);
    set(gca,'ylim',[-0.02 1.02]);
    
end

%% -----   Plot Arcs  -----
% pixel resolution
hf = figure(3); clf; set(hf, 'name', 'arcs'); 
for lev = 1:Kt.nLev

    ARClv = DVEC.AARC{lev};
    
    subplot(3, 2, lev); hold on;
    
    p_ArcPts( ARClv );
    %p_ArcFromVect( ARClv );           

    axis ij
    set(gca,'xlim',[1 Kt.szH/(2^(lev-1))]);
    set(gca,'ylim',[1 Kt.szV/(2^(lev-1))]);
    %set(gca,'xlim',[-0.02 1.02]);
    %set(gca,'ylim',[-0.02 1.02]);
    
end

%% -----   Plot Straighters  -----
% pixel resolution
hf = figure(4); clf; set(hf, 'name', 'strs'); 
% -----   Plot Straighters  -----
for lev = 1:Kt.nLev
    
    %STRlv = AVEC.ASTRfll{lev};     % extracting one level (full)
    STRlv = DVEC.ASTR{lev};      % extracting one level (gerust)
    
    subplot(3, 2, lev); hold on;
    
    p_StrPts(STRlv);                
    % p_StrFromVect(STRlv);         

    axis ij
    set(gca,'xlim',[1 Kt.szH/(2^(lev-1))]);
    set(gca,'ylim',[1 Kt.szV/(2^(lev-1))]);
    %set(gca,'xlim',[-0.02 1.02]);
    %set(gca,'ylim',[-0.02 1.02]);
    
end

%% -----   Plot Shapes   -----
% unit resolution
% we plot boundary pixels in addition - for verification. For that we need
% to load the boundaries and scale them.

[APIX  Nbon2 SzM]   = LoadBonPixPyr([pthVect(1:end-4) '.BonPix']);

colGray     = [0.7 0.7 0.7];    % default for bounding boxes

hf = figure(5); clf; set(hf, 'name', 'shape'); 
for lev = 1:Kt.nLev
    
    SHPlv = DVEC.ASHP{lev};         % extracting one level
    APix  = APIX{lev};
    szM   = SzM(lev,:);
    
    subplot(3, 2, lev); hold on;
    
    p_ShpFromVect(SHPlv);           % in directory 'Vect'

    % now the corresponding boundaries
    nShp = length(SHPlv.IxBon1);
    for b = 1:nShp
        
        ixBon   = SHPlv.IxBon1(b);  % already made one-indexing
        Pix     = APix{ ixBon };    % in original map coordinates...
        % ...therefore normalize
        Pix.Rw  = 1 - Pix.Rw / szM(1); % -1 due to inverted axis
        Pix.Cl  =     Pix.Cl / szM(2);
        
        hp  = plot( Pix.Cl, Pix.Rw, 'color', colGray );      

    end
    
    set(gca,'xlim',[-0.02 1.02]);
    set(gca,'ylim',[-0.02 1.02]);
    
end