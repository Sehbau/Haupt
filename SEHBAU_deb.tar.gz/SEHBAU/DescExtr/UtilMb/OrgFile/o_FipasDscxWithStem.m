%
% Generates filenames for descriptor extraction output (dscx) for ONE file
% stem.
% 
% IN   stm    file stem, ie. 'IMGDAT/Collection/Desc/DSC_'
%      Fixt   file extensions ( o_FileExtensions.m )
% OUT  S      struct with filepaths including the file extensions
%
% USE  stem     = [pthBas.DescRef 'DSC_' imna.ref];
%      Fixt     = o_FileExtensions();
%      Lfps     = o_FipasDscxWithStem( stem, Fixt, bOSISWIN );
%      Lfps.vec, Lfps.hst, ...
% 
function S = o_FipasDscxWithStem( stm, Fixt, bOSisWin )

if nargin==2                % argument bOSisWin missing...
    bOSisWin = 0;           % ...then we assume linux
end

aExt  = fieldnames( Fixt );
nFld  = length( aExt );

for f = 1:nFld
    
    extn      = aExt{f};
    S.(extn)  = [ stm Fixt.(extn) ];
    
    % slash to backslash for windows
    S.(extn)  = u_PathToBackSlash( S.(extn), bOSisWin ); 
end

end

