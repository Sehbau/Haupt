%
% File extensions.
%
% ia Fixt
%
% from struct stuFileExtn in A_ANF/Util/FileNameDesc.h
%
function [D F] = o_FileExtensions()

% -----  contours
D.vecRRE = '.vecRRE';
D.cntEpt = '.CntEpt';

% -----  image 
D.vec    = '.vec';
%D.vegi   = '.vecGrp';
D.vebi   = '.veb';
D.hsti   = '.hst';
D.hstc   = '.hstc';     % collection (collHimg)
D.utzi   = '.utz';		% utilities (deployed yet?)
D.objp   = '.obp';		% object proposals?			
D.salc   = '.slc';		% saliency 
D.itgc   = '.itgc';		% integration contours
D.cvpo   = '.cvpo';		% curve partitions organization (deployed yet?)

D.bbox   = '.Bbox';		% s_FunvBboxAll, ai dscx.cpp

D.bonBbx = '.BonBbox';  % s_BonBboxPyr
D.bonAsp = '.BonAsp';
D.bonPix = '.BonPix';

% -----  shape
D.shp    = '.shp';

% -----  focus
F.vecf   = '.vef';
F.hstf1  = '.hsf1'; 	% PROD/FocExtr/focxh1.cpp
F.hstfL  = '.hsfL';

% -----  collection
D.collHst = '.hstc';
D.collVec = '.vecc';

% -----  maps
D.mapUch  = '.mpu';

