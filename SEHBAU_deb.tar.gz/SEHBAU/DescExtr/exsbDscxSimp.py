"""

Ensure that the main folder is called 'SEHBAU' and not 'SEHBAU_win/ubu...'

Runs two programs:

1) descriptor extraction in simplest form, without utility/wrapper routines, for reason
   of clarity.
2) Turns the histogram file into a single array with program h2arr.

Analogous to exsbDscxSimp.m

It also includes some plotting, taken from exsbPlotDesc.m

"""
import os
import subprocess
import sys

## ------------------------------   Run 1 Image   ------------------------------
# we could use os.path.join but we are explicit for the beginning.
# note that in windows we need backslash for output directory
if sys.platform.startswith('win'):

    cmnd = r'dscx Imgs/img2.jpg Desc\img2'  # raw string to handle backslash
    
elif sys.platform.startswith('linux') or sys.platform.startswith('darwin'):

    cmnd = 'dscx Imgs/img2.jpg Desc/img2'

Res  = subprocess.run( cmnd, shell=True, capture_output=True, text=True )

# Access status and output
if Res.returncode != 0:
    raise ValueError("dscx did not execute properly somehow")

print( Res.stdout )


## ------------------------------   Load Output   ------------------------------
# to load the fileoutput now we need the administration code
sys.path.insert(0, '..')        # insert path where folder SEHBAU/AdminPy lies
import AdminPy as sb            


# ----------   Saliency   ----------
Txa, Shp, Ens, Dsc = sb.LoadDescSalc( 'Desc/img2.slc' )


# ----------   Description   ----------
DSC, Hed    = sb.LoadDescImag( 'Desc/img2.dsc' )

print( Hed )
print( DSC.keys() )
print( DSC['Labs'].Shp.Sco )

# print some attributes of 1st level 
if 0:
    print( DSC['ACNT'][0].Les )
    print( DSC['ACNT'][0].Pos.Vrt )
    print( DSC['ACNT'][0].RGB.Red )
    print( DSC['AARC'][0].Pts.Ep1 )
    print( DSC['ASTR'][0].Pts.Ep1 )
    print( DSC['ASHP'][0].Pos.Vrt )
    print( DSC['ABNDG'][0].Pos.Vrt )


# ----------   Histograms   ----------
# does not exist yet
# [HFU HFB HSP Nbin HedHst] = LoadDescHist( 'Desc/img2.hst' )


## ------------------------------   h2arr   ------------------------------
# turns a hist file into a single array
if sys.platform.startswith('win'):

    cmnd = r'h2arr Desc/img2.hst Vect\img2'  # raw string to handle backslash
    
elif sys.platform.startswith('linux') or sys.platform.startswith('darwin'):

    cmnd = 'h2arr Desc/img2.hst Vect/img2'

Res  = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

if Res.returncode != 0:
    raise ValueError("h2arr did not execute properly somehow")

# --------------------   Load Hist Array   --------------------
Hari  = sb.LoadHistImgArr( 'Vect/img2.hari' )

print( f'HistArr: {Hari}' )



# ------------------------------   Plot Contours  ------------------------------

# we plot contours of first level only. Once with RGB image, once without.

#from PlotDescriptors import p_CntFromAtts

import matplotlib.pyplot as plt
import imageio.v3 as iio

Irgb     = iio.imread( 'Imgs/img2.jpg')

fig = plt.figure(1)
fig.clf()
nr, nc   = 1, 2

# Subplot 1: with RGB image
ax1 = fig.add_subplot(nr, nc, 1)
ax1.imshow(Irgb)

sb.p_CntFromAtts( DSC['ACNT'][0], Irgb.shape )

plt.show(block=False)

# Subplot 2: without image - in unit coordinates
ax2 = fig.add_subplot(nr, nc, 2)

sb.p_CntFromAtts( DSC['ACNT'][0] )

plt.show(block=False)


# ------------------------------   Plot Arcs  ------------------------------

# we plot acrc enpoints of first level only. Only to RGB.

#from PlotDescriptors import p_ArcPts

import matplotlib.pyplot as plt
import imageio.v3 as iio

Irgb     = iio.imread( 'Imgs/img2.jpg')

fig = plt.figure(2)
fig.clf()
nr, nc   = 1, 2

# Subplot 1: with RGB image
ax1 = fig.add_subplot(nr, nc, 1)
ax1.imshow(Irgb)

sb.p_ArcPts( DSC['AARC'][0] )#, Irgb.shape )

plt.show(block=False)

