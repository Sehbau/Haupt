%
% The more elaborate example for running program dscx. It passes some
% parameters and loads all files.
%
clear;
run('../AdminMb/globalsSB');        % assumes script is run from dir 'DescExtr'
    
strImg 	= 'img1.jpg';
%strImg 	= 'img2.jpg';

fipaImg	= ['Imgs/' strImg];         % image path
fipsOut = ['Desc/' strImg(1:end-4)]; % output filestem

% change to window backslash (in case we are on windows)
if ispc
    fipaImg  = u_PathToBackSlash( fipaImg ); 
    fipsOut  = u_PathToBackSlash( fipsOut ); 
end

%% --------------   Options   ---------------
if 0                        
    % either manually
    %optS  	= '';               % default: no parameters modified
    %optS    = 'PrmDescTest.txt';
    %opts 	= '--nLev 3';       % write here...
    optS 	= '--depth 3 --saveRRE --saveCVP';       % write here...
else
    % ...or use the following convenience struct
    OptK            = o_DscxArgs();
    OptK.nLev       = 3 ;
    %OptK.imgSpc    = 2 ; % scale space
    %OptK.imgFlt    = 1 ; % image filtering

    OptK.saveRRE    = 1 ;
    OptK.saveCVP    = 1 ;
    OptK.saveRegUnv = 1 ;    % region universe
    OptK.saveBonSpc = 1 ;    
    OptK.saveKol    = 0 ;
    
    % other:
    OptK.saveBonBoxRaw  = 1 ;
    OptK.saveBonMore    = 1;
    OptK.saveCuvKpt     = 1;
    optS                = i_DscxArgs(OptK);
end

%% =============   Command   ================
% We could use RennDscx.m, but for first demonstration we are explicit:
% Concatenate program name, arguments and options to one string
if ispc
    cmnd      = ['dscx ' fipaImg ' ' fipsOut ' ' optS];
    [Sts Out] = dos(cmnd);      % excecute program for windows
elseif isunix
    cmnd      = ['./dscx ' fipaImg ' ' fipsOut ' ' optS];
    [Sts Out] = unix(cmnd);     % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 );
pso_ErrPresent( Out )

%% --------------   Load Description   ---------------
Fixt                = o_FileExtensions(); 
fpDSC               = o_FinaApndExtDscx( fipsOut, Fixt );

[DSC KtDsc Hed]     = LoadDescImag(  fpDSC.dsc );    
[BIN KtDbn Hed]     = LoadDbinImag(  fpDSC.dsbi );    

[HST HedHst]        = LoadDescHist( fpDSC.hsti );

[SLC HedSlc]        = LoadDescSalc(  fpDSC.slc );

assert( all(KtDbn.Nshp==KtDsc.Nshp)==1 )

%% --------------   Load Full Sets   ---------------
[RRE]               = LoadCntRRE(  fpDSC.rre );
[CVP Kt]            = LoadCVPfull( fpDSC.cvpf );

%% --------------   Load Features   ---------------
[AREG KtReg]        = LoadRegUnv(    fpDSC.ruv );
[APIX  Nbon2 SzM]   = LoadBonPixSpc( fpDSC.bspx );
% Other (more info):
[ABbox Nbon0 IxX]   = LoadBonBboxPyr([fipsOut Fixt.bonBbx]);
[AASP  Nbon1]       = LoadBonAspPyr( [fipsOut Fixt.bonAsp]);
[ABbox Ncc]         = LoadBboxFunv(  [fipsOut Fixt.bonBbxRaw]);
[CNT Ncnt]          = LoadCntUnvKpt( fpDSC.cuvKpt );

%% --------------   Plot Contours   ---------------
Irgb    = imread(fipaImg);      	% load image again for plotting

PlotCntUnvKpt( CNT, Irgb, 1, 2 );

% see more examples in directory AdminMb/DescExtr/Plot/Examples/
