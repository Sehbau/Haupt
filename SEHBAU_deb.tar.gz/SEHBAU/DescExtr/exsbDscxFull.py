"""

Example using wrapper routine RennDscx()

Analogous to exsbDscxFull.m

"""
import sys, os
sys.path.insert(0, '..')
from globalsSB import *

strImg 	= 'img1.jpg'
#strImg = 'img2.jpg'

pthImg	= os.path.join( 'Imgs/', strImg )        # image path
pthOut 	= os.path.join( 'Desc/', strImg[:-4] )   # outpath 


# ------------------------------   Execute Explicitly   ------------------------------
# not much new here, as opposed to exsbDscxSimp.py
cmnd  = 'dscx ' + pthImg + ' ' + pthOut + ' ' + '--depth 2'

import subprocess

Res = subprocess.run( cmnd, shell=True, capture_output=True, text=True )

if Res.returncode != 0:
    raise ValueError("dscx did not execute properly somehow")

# ------------------------------   Execute With Wrapper Function   ---------------------
from CmndSupp import *
from RennDscx import *

Admin      = adminCmnd                          # CmndSupp.py
Admin.optS = '--depth 2'
  
StdOut     = RennDscx( pthImg, pthOut, Admin )


# ------------------------------   Load   ------------------------------
from LoadDescription import LoadDescImag

filePath    = pthOut + '.dsc'

DSC, Hed    = LoadDescImag( filePath )

print(DSC)
print(Hed)


