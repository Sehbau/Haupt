#
# Analogous to exsbDscx1.m
#
import sys
import subprocess
sys.path.insert(0, '..')
sys.path.insert(0, '../UtilPy/')
from globalsSB import *
from u_PathToBackSlash import u_PathToBackSlash

strImg 	= 'img1.jpg'

pthImg	= 'Imgs/' + strImg;          # image path
pthOut 	= 'c:/ztmp/Python/' + strImg[:-4] 
#pthOut 	= 'c:\ztmp\Python\Out' # works
#pthOut 	= 'c:\ztmp\Python\\' + strImg[:-4] # works

pthOut  = u_PathToBackSlash( pthOut, bOSisWin )


# ------------------------------   Execute Explicitly   ------------------------------
# https://docs.python.org/3/library/subprocess.html
# python 3.6
cmd  = 'dscx ' + pthImg + ' ' + pthOut + ' ' + '--depth 1'
#Args = subprocess.run( [ 'dscx', pthImg, pthOut, '--depth 1' ],
Args = subprocess.run( cmd,
		       stdout = subprocess.PIPE,
		       stderr = subprocess.PIPE,
		       universal_newlines = True )

print( Args.stdout )
print( Args.stderr )
#print( Out )

# ------------------------------   Execute As Function   ------------------------------
from CmndSupp import *
from RennDscx import *
Admin      = adminCmnd
Admin.optS = '--depth 2'
  
RennDscx( pthImg, pthOut, Admin )


# ------------------------------   Plot   ------------------------------
print( 'Loading Vec file' )
from LoadDescVect import LoadDescVect

filePath    = pthOut + '.vec'

AVEC, Hed = LoadDescVect( filePath )

#print("nLev={0}, szV={1}, szH={2}".format(nLev, szV, szH ))
#print("ntDsc={0}, idfLod={1}, vers{2}".format(ntDsc, idfLod, vers ))

print(Hed)

for l in range( 0, 5 ):
    print(AVEC[l].Les)    
#print(AVEC[3].Les)    

