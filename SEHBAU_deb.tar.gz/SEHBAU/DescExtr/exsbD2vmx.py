"""

Example for generating the vector file (from the description file).

Assumes that description file has already been generated.

To be run from directory 'DescExtr'.

PREVIOUS  exsbDscx1.py
PRESENT   exsbD2vmx.py
NEXT      

"""
import sys
sys.path.insert(0, '..')
from globalsSB import *

u_AddGenPath( '../UtilPy/' )
u_AddGenPath( '../DescExtr/UtilPy/' )

import subprocess

# ------------------------------   Run 1 Conversion   ------------------------------
inpf = 'Desc/img1.dsc'
outf = 'Vect/img1'

cmnd = f"d2vmx {inpf} {outf}"

# Convert path separators for Windows if necessary
if os.name == 'nt':
    cmnd = cmnd.replace('/', '\\')

Res  = subprocess.run(cmnd, shell=True, capture_output=True, text=True)
if Res.returncode != 0:
    raise ValueError("h2arr did not execute properly somehow")

# ------------------------------   Load   ------------------------------
from LoadDescription import *
from OrgDescTyp import *

aFixtVec, nDty   = o_DescTypes('fixtVec');
aFixtLev, dmy    = o_DescTypes('fixtLev');
aDtyS, nDty      = o_DescTypes('Crasstb');

# Order:       cnt rsg arc str bnd ttg shp
OrdDty      = np.array( [ 1,  2,  3,  4,  7,  6,  5 ] ) - 1

import matplotlib.pyplot as plt

# --------------------------------------------------------------------------------
#                       L O O P   D E S C T Y P E S
# --------------------------------------------------------------------------------
for i in range(0,nDty):

    ixDsc = OrdDty[i]

    # --------------------   Load   --------------------
    dtyV  = aFixtVec[ixDsc]
    dtyL  = aFixtLev[ixDsc]

    lfpV  = f"{outf}.{dtyV}"
    lfpL  = f"{outf}.{dtyL}"

    VMX, nDsc, LbsAtt, nAtt   = LoadDescVect( lfpV );

    Lev, nDsc2                = LoadDescVectLev( lfpL );

    if nDsc < 0:
        VMX, nDsc = f_SscanfVectMxWithNan( VMX, nAtt )

    assert nDsc == nDsc2, f"Descriptor count mismatch: {nDsc} vs {nDsc2}"

    # --------------------   Plot   --------------------
    plt.figure(i+1)
    plt.imshow(VMX, aspect='auto', cmap='viridis')  # imagesc equivalent
    plt.colorbar()

    # Set x-axis ticks and labels
    plt.xticks(ticks=np.arange(nAtt), labels=LbsAtt, rotation=45)
    
    # Add a title
    plt.title(aDtyS[ixDsc])
    
    plt.tight_layout()
    plt.show(block=False)
    plt.pause(.01)


import time
time.sleep(2)

