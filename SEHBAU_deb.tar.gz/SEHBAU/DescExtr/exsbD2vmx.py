"""

Example for generating the vector file (from the description file).

Assumes that description file has already been generated.

To be run from directory 'DescExtr'.

PREVIOUS  exsbDscxFull/Simp.py
PRESENT   exsbD2vmx.py
NEXT      

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.DescExtr.DescType.OrgDescTyp import o_DescTypes
from AdminPy.DescExtr.DescFile.LoadDescription import LoadDescVect, LoadDescVectLev
from AdminPy.DescExtr.OrgAtt.OrgAtts import u_AttIxAsFields
from AdminPy.DescExtr.Vect.VmxManip import *
from AdminPy.DescExtr.DescAnf import *

# ------------------------------   Run 1 Conversion   ------------------------------
fpDsc   = Path( 'Desc/img1.dsc' )
fpVec   = Path( 'Vect/img1' )

cmnd    = [ 'd2vmx',  fpDsc, fpVec ]

Res     = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

if Res.returncode != 0:
    raise ValueError("d2vmx did not execute properly somehow")

# ------------------------------   Load   ------------------------------
aFixtVec, nDty   = o_DescTypes('fixtVec')
aFixtLev, dmy    = o_DescTypes('fixtLev')
aDtyS, nDty      = o_DescTypes('Crasstb')

# Order:       cnt frm arc str bnd ttg shp
OrdDty      = np.array( [ 1,  2,  3,  4,  7,  6,  5 ] ) - 1

import matplotlib.pyplot as plt

# --------------------------------------------------------------------------------
#                       L O O P   D E S C T Y P E S
# --------------------------------------------------------------------------------
for i in range(0,nDty):

    ixDsc = OrdDty[i]

    # --------------------   Load   --------------------
    dtyV  = aFixtVec[ixDsc]
    dtyL  = aFixtLev[ixDsc]

    lfpV  = fpVec.with_suffix( '.' + dtyV )
    lfpL  = fpVec.with_suffix( '.' + dtyL )

    VMX, Hed, LbsAtt     = LoadDescVect( lfpV )

    # ----------   Level Info   ----------
    # load from file
    Lev, nDsc2           = LoadDescVectLev( lfpL )
    # or take it from the head
    print(Hed.Ndsc)
    Blev0                = Lev==0

    if Hed.nAtt < 0:    # was set to -1 in case reading had failed
        # in case of NaN (problems with reading directly float from file)
        VMX, nDsc = sb.Util.UtilSscanf.f_SscanfVectMxWithNan( VMX, Hed.nAtt )

        #assert Hed.nDsc == nDsc2, f"Descriptor count mismatch: {Hed.nDsc} vs {nDsc2}"

    # --------------------   Extract Per Cell   --------------------

    # we extract position and quantize it into a raster (overlapping grid/windows),
    # and then cycle through the individual cells and extract the corresponding
    # window vector matrix. It is essentially focus descriptor extraction, but
    # applied systematically; the vectorial equivalent of fabric generation.
    
    IxAtt    = u_AttIxAsFields( LbsAtt )   # turn labels into indices

    # ----------   Init Raster   ----------
    Dim      = dimRast()                   # fabric layer 3 style
    #Dim      = i_DimRast( 31, 31 )        # fabric layer 0 style
    IXWin    = f_RastWin( Dim )

    szGvrt   = float( Dim.vrtBase )        # vertical number of units
    szGhor   = float( Dim.horBase )        # horizontal number of units
    
    # ----------   Position: real to quant   ----------

    # from VmxManip.py: we extract the two position columns from the vector matrix
    Pos      = u_VmxXtrPos( VMX, IxAtt )   # [nDsc 2]   vertical/horizontal

    VrtQ     = np.floor(Pos[:,0] * szGvrt) # vertical coordinate quants
    HorQ     = np.floor(Pos[:,1] * szGhor) # horizontal coordinate quants

    IxCll    = VrtQ * szGhor + HorQ        # linear cell indices

    # boolean mask [nDsc nCll]
    BCLLS    = np.any(IxCll[:, None, None] == IXWin[None, :, :], axis=2)

    # ----------   Loop Cells   ----------
    for c in range( Dim.nCll ):

        Bcll   = BCLLS[:,c]                # one cell
        VmxCll = VMX[Bcll,:]               # corresponding focus vector matrix

        # further subselect using level
        # computationally a bit expensive
        BcllLev0    = Bcll & Blev0
        VmxCllLv0   = VMX[BcllLev0,:]

        # the only check I have made so far:
        #print( VmxCll.shape, VmxCllLv0.shape )
        
    
    # --------------------   Angles   --------------------
    # Some angle values are invalid (value = -9999).
    # Set to zero for plotting.
    if any(VMX.flatten()==ANGINVLD):
        VMX[VMX==ANGINVLD] = 0
        print( 'Achtung: desctype ' + dtyV +
               ' contains invalid angles: set to 0 for plotting' )
    
    # --------------------   Plot   --------------------
    plt.figure(i+1)
    plt.imshow(VMX, aspect='auto', cmap='viridis')  # imagesc equivalent
    plt.colorbar()

    # Set x-axis ticks and labels
    plt.xticks(ticks=np.arange(Hed.nAtt), labels=LbsAtt, rotation=45)
    
    # Add a title
    plt.title(aDtyS[ixDsc])
    
    plt.tight_layout()
    plt.show(block=False)
    plt.pause(.01)


import time
time.sleep(2)

