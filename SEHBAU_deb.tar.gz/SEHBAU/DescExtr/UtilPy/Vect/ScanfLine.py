"""

Sscanf text for NaNs

"""
import numpy as np



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   SscanfForFloatWnan   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Parses a line of text into floats, replacing non-numeric entries with NaN.

    Parameters:
    line (str): Input text line
    nexNum (int): Expected number of float entries

    Returns:
    np.ndarray: Array of floats with NaNs where parsing failed

"""
def SscanfForFloatWnan( Lin, nexNum ):

    # Split Lin by whitespace
    aToken = Lin.strip().split()
    n_read = len(aToken)

    if n_read != nexNum:
        print("Parsing mismatch:")
        print("AToken:", aToken)
        print("Read:", n_read)
        print("Expected:", nexNum)

    # Convert to float with NaN fallback
    Vals = []
    for tkn in aToken:
        
        try:
            num = float(tkn)
            
        except ValueError:
            num = np.nan
            
        Vals.append( np.float32(num) )  # Convert to single precision

    return np.array(Vals, dtype=np.float32)


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_SscanfVectMxWithNan   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF


"""
def f_SscanfVectMxWithNan( aLines, nexAtt):

    nLin = len(aLines)
    print(f'Sscanfing {nLin} lines')

    VMX  = np.zeros((nLin, nexAtt), dtype=np.float32)

    for i, line in enumerate(aLines):

        #print( line )
        Arr      = SscanfForFloatWnan( line, nexAtt )
        VMX[i,:] = Arr

    return VMX, nLin


