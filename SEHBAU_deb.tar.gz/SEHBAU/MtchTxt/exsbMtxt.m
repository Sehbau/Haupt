% 
% Runs program mtxt1, for three frames and takes distances 1-2 and 1-3
%
% Plots correspondence for 1-2.
%
% af exsbFrame.m (in MtchVec)
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'MtchHst'

%% --------------------------------------------------------------
%                          DESC EXTR
%  --------------------------------------------------------------
% run descriptor extraction for three frames in directory MtchVec
fprintf('Descriptor extraction...');
cd( PthProg.mtchVec );
fipaFrm1 	= 'Imgs/Frm1.png';
fipaFrm2 	= 'Imgs/Frm2.png';
fipaFrm3 	= 'Imgs/Frm3.png';

fipsDsc1 	= 'Desc/Frm1';
fipsDsc2   	= 'Desc/Frm2';
fipsDsc3   	= 'Desc/Frm3';

if ispc
    fipsDsc1    = u_PathToBackSlash( fipsDsc1 );
    fipsDsc2    = u_PathToBackSlash( fipsDsc2 );
    fipsDsc3    = u_PathToBackSlash( fipsDsc3 );
end

ArgsDscx        = o_CmndArgs( 'dscx' );
ArgsDscx.opt    = '--saveBon';
v_CmndArgs( ArgsDscx );

OutDscx1    = RennDscx( fipaFrm1, fipsDsc1, ArgsDscx, PthProg.descExtr );
OutDscx2    = RennDscx( fipaFrm2, fipsDsc2, ArgsDscx, PthProg.descExtr );
OutDscx3    = RennDscx( fipaFrm3, fipsDsc3, ArgsDscx, PthProg.descExtr );

fprintf('Dscx fertig\n');

%% --------------------------------------------------------------
%                          MATCH
%  --------------------------------------------------------------
fprintf('Matching...');
cd( PthProg.mtchTxt );

dfLackBox   = 200;              % distance value when no match was possible

dirFrm      = '../MtchVec/Desc/';
fpSlc1      = [dirFrm 'Frm1.slc'];
fpSlc2      = [dirFrm 'Frm2.slc'];
fpSlc3      = [dirFrm 'Frm3.slc'];

mesFil12    = 'Mes/Txt12.txt';
mesFil13    = 'Mes/Txt13.txt';

cmnd12 = sprintf('mtxt1 %s %s %s %1.2f', fpSlc1, fpSlc2, mesFil12, dfLackBox );
cmnd13 = sprintf('mtxt1 %s %s %s %1.2f', fpSlc1, fpSlc3, mesFil13, dfLackBox );

if ispc 
    cmnd12 = u_PathToBackSlash( cmnd12 ); 
    cmnd13 = u_PathToBackSlash( cmnd13 ); 
end

% --------   Execute & Load 1 vs 2   -----------
[Sts1 Out1] = system( cmnd12 );
v_CmndExec( Sts1, Out1, cmnd12, 1 );

DfBias12    = LoadFltTxtEof( mesFil12 );
NNMs12      = LoadFltTxtEof( 'Mes/Txt1NNMsRow.txt' );
NNIx12      = LoadIntTxtEof( 'Mes/Txt1NNIxRow.txt' ) + 1;
% geht nur, wenn auch Txa1/2 vertauscht sind
% NNMs12      = LoadFltTxtEof( 'Mes/Txt1NNMsCol.txt' );
% NNIx12      = LoadIntTxtEof( 'Mes/Txt1NNIxCol.txt' ) + 1;

%NNvl        = [NNMs12 single(NNIx12)];

% --------   Execute & Load 1 vs 3   -----------
[Sts2 Out2] = system( cmnd13 );
v_CmndExec( Sts2, Out2, cmnd13, 1 );

DfBias13    = LoadFltTxtEof( mesFil13 );

% --------    Analyze   ---------
df12        = mean(DfBias12);
df13        = mean(DfBias13);

fprintf('Mes 12: %1.3f  13: %1.3f\n', df12, df13);

%% -------   Plot Metric Measurements   --------
LbBlob      = o_BlobLabels();

figure(1); clf;
subplot(1,2,1);
bar([DfBias12 DfBias13]);
set(gca,'xticklabel',LbBlob);
ylabel('Difference');
legend({'1vs2' '1vs3'});
title('Bias');

subplot(1,2,2);
bar([df12 df13]);
set(gca,'xticklabel',{'12' '13'});
set(gca,'xlim',[0.4 2.6]);
title('Total');


%% --------------------------------------------------------------
%                       CORRESPONDENCE
%  --------------------------------------------------------------
% We compare 1 versus 2.
fprintf('Correspondence for 12...\n');

% -------------   Create one image   --------------
Ifrm1   = imread( [PthProg.mtchVec fipaFrm1] );
Ifrm2   = imread( [PthProg.mtchVec fipaFrm2] );
Iboth   = cat(2, Ifrm1, Ifrm2 );
[ihgt iwth nCh] = size( Ifrm1 );

% ------------    Load Saliency Files   -------------
Fixt    = o_FileExtensions();
SLC1    = LoadDescSalc( fpSlc1 );
SLC2    = LoadDescSalc( fpSlc2 );
Txa1    = SLC1.Txa;
Txa2    = SLC2.Txa;

% shift bboxes of 2nd frame to the right
Txa2.Blb.Box(:,3) = Txa2.Blb.Box(:,3) + iwth;
Txa2.Blb.Box(:,4) = Txa2.Blb.Box(:,4) + iwth;

Cen1    = u_BboxCen( Txa1.Blb.Box );
Cen2    = u_BboxCen( Txa2.Blb.Box );

% ---------------   Plot   -------------
figure(2); clf;
imagesc( Iboth ); hold on;

if 0
    p_BlobBboxes( Txa1.Blb );   % plot all
    p_BlobBboxes( Txa2.Blb );
end

ColBias = u_ColBlob();

for b = 1:Txa1.Blb.nBox
    
    dis     = NNMs12(b);
    
    % a value of 99 means no match found (invalid)
    if dis==99, continue; end    % no match
    
    ix      = NNIx12(b);
    
    typ     = Txa1.Blb.Typ(b);
    col     = ColBias(typ,:);
    
    p_BboxL( Txa1.Blb.Box( b, :), col );    % left side
    
    p_BboxL( Txa2.Blb.Box( ix, :), col );   % rite side
    
    % bounding box centers (verification)
    %plot( Cen1.Cl(b),  Cen1.Rw(b), '*' );
    %plot( Cen2.Cl(ix), Cen2.Rw(ix), '*' );
    
    % correspondence line:
    hl = line( [Cen1.Cl(b) Cen2.Cl(ix)], [Cen1.Rw(b) Cen2.Rw(ix)] );
    set( hl, 'linewidth', 4-dis*2 );
    
    
end






