#
#
#  Adds all necessary paths and creates some global variables.
#  
#
import sys

# ------------------------------   Root Path   ------------------------------
rootSehBau      = 'c:/klab/ppc/SEHBAU/'

sys.path.append(rootSehBau)



from dataclasses import dataclass

# ------   Dirs to Programs (and Demos)   ------
@dataclass
class dirProg:
   descExtr = 'DescExtr/'
   mtchVec  = 'MtchVec/'
   focExtr  = 'FocExtr/'
   plcRec   = 'DemoPlcRec/'
   
DirProg = dirProg


# ------   Paths to Programs (and Demos)   ------
PthProg = dirProg

for a in dir( PthProg ):
    if not a.startswith('__'):
        print(a)
        drp = getattr( DirProg, a)
        setattr( PthProg, a, rootSehBau + drp )


# UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_AddPath   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
#
#    Analogous to addpath/genpath in Matlab
#
def u_AddPath( dirPrinc, Subs=[]):

    # add principal folder
    pthPrinc  = rootSehBau + dirPrinc + '/'
    sys.path.append( pthPrinc ) 

    # add sub-folders
    nSubs   = len(Subs)
    if nSubs==0: print('no subs for ', dirPrinc); return
    for i in range(nSubs):
        sys.path.append( pthPrinc + Subs[i] )

    return



# ------------------------------   PATHS   ------------------------------
u_AddPath( 'UtilPy',   [ 'OrgFile',  'Params' ] )
u_AddPath( 'DescExtr/UtilPy', [ 'Vect' ] )
u_AddPath( 'DescExtr/UtilPy/Vect' , [ 'FileRead', 'OrgAtt' ])



# ------------------------------   VARIABLES   ------------------------------
import platform

bOSisWin = platform.system()=='Windows'




