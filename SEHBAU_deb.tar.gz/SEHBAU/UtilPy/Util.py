"""

Utility routines

"""



import os
import glob



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   get_FinasPatWoExt   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Obtain filenames with pattern and return them without extension.

"""
def get_FinasPatWoExt( dirFina, rex ):

    # List the files
    aLst  = glob.glob( os.path.join( dirFina, rex ) )

    # Extract base filenames without extension
    aNam  = [ os.path.splitext( os.path.basename(p) )[0] for p in aLst ]

    return aNam







""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   get_FieldNames   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Obtain the fieldnames from a struct

https://stackoverflow.com/questions/11637293/iterate-over-object-attributes-in-python

"""
def get_FieldNames( C ):

    aFn = [a for a in dir( C ) if not a.startswith('__')]

    return aFn

 
