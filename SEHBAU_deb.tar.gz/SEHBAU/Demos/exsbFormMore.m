%
% Plotting forms. af exsbShape.m
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'Demos'

%typs         = {'Ori' 'Elo'};  figForm = 4;
typs        = {'RtArea' 'Bulk'};  figForm = 5;
%typs         = {'Dent' 'Star'};  figForm = 6;
%typs         = {'Haar' 'Diamond'};  figForm = 7;

typLeft     = typs{1};
typRite     = typs{2};

%strImg      = 'aachen.png';
strImg      = 'room.png';
%strImg      = 'highway.jpg';
%strImg      = 'SnowCovMount.jpg';

fipaImg     = [ 'Imgs/' strImg];         % image path
fipsOut     = [ 'Desc/' strImg(1:end-4)]; % output filestem

% change to window backslash (in case we are on windows)
if ispc
    fipaImg  = u_PathToBackSlash( fipaImg ); 
    fipsOut  = u_PathToBackSlash( fipsOut ); 
end

%% --------   Options   --------
OptK            = o_DscxArgs();
OptK.nLev       = 3 ;
OptK.depth      = 3 ;
OptK.saveBonSpc = 1 ;
optS            = i_DscxArgs(OptK);

%% =========   Command   ========
cmnd        = [ FipaExe.dscx ' ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd    = u_PathToBackSlash( cmnd );
end

[Sts, Out]  = system(cmnd);      

v_CmndExec( Sts, Out, cmnd, 1 );

%% -------   Load Region Pixels   -------
Fixt                = o_FileExtensions();
fpDSC               = o_FinaApndExtDscx( fipsOut, Fixt ); 

[DSC Kt Hed]        = LoadDescImag( fpDSC.dsc );    
[ABON Nbon SzM AOrg] = LoadBonPixSpc( fpDSC.bspx );    

[LbAtts, LbAttSG]   = o_AttsLabels();
DSC                 = u_DescMxToStcOfArr( DSC, LbAttSG );

Pal                 = u_ColPalets();
Ang                 = o_Angles();

%% -----------------   Plot Forms   ------------------------
hf = figure(figForm); clf; set(hf, 'name', 'form'); 
for lev = 1:Kt.nLev

    % --- retrieve:
    FRM         = DSC.ARSG{lev};         % extracting one level

    % --- avoid large ones
    Bsmlr       = FRM.RospA.AreN < 0.20;  % smaller (omit very large)
    
    % --- prep plotting struct
    Pset.ABonLv = ABON{lev};
    Pset.IxBon  = FRM.IxBon1;
    Pset.IxBon  = Pset.IxBon(Bsmlr);

    szM         = SzM(lev,:);

    % ----------   Plot LEFT   ----------
    subplot(3, 2, lev*2-1); hold on;
    set(gca,'fontsize',8);
    
    if strcmp( typLeft, 'Ori' ) 
        
        p_BoundPixSel( Pset, FRM.OriHul(Bsmlr), Ang.EdgOri8, Pal.Ori ); 
        
        if lev==1, title('Orientation'); end
        
    elseif strcmp( typLeft, 'RtArea' ) 
        
        Edg4 = [0.25  0.5  0.75  1.01];
        p_BoundPixSel( Pset, FRM.RospA.RtAre(Bsmlr), Edg4, Pal.Deg3 );
        
        if lev==1, title('Ratio Area (Bound/Hull)'); end
        
    elseif strcmp( typLeft, 'Dent' ) 
        
        Edg4 = [0.05  0.35  0.65  1.21];
        p_BoundPixSel( Pset, FRM.RdSig.Dent(Bsmlr), Edg4, Pal.Deg3 );

        if lev==1, title('Dent (RdSig)'); end
        
    elseif strcmp( typLeft, 'Haar' ) 
        
        Edg4 = [0.01  0.33  0.66  1.01];
        p_BoundPixSel( Pset, FRM.RospB.Haar(Bsmlr), Edg4, Pal.Deg3 );
        
        if lev==1, title('Haar'); end        
    else
        error('not implemented %s', typLeft );
    end
    
    p_AxesToImgDim( szM );
    ylabel(['Lev ' num2str(lev)] );
    
    % ----------   Plot RITE   ---------
    subplot(3, 2, lev*2); hold on;
    set(gca,'fontsize',8);

    if strcmp( typRite, 'Elo' ) 
        
        Edg4 = [0.15  0.35  0.55  1.01];
        p_BoundPixSel( Pset, FRM.RospA.EloRd(Bsmlr), Edg4, Pal.Deg3 );
        
        if lev==1, title('Elongation'); end
        
    elseif strcmp( typRite, 'Bulk' ) 
        
        Edg4 = [0.5  0.66 0.75  1.01];
        p_BoundPixSel( Pset, FRM.RdSig.Bulk(Bsmlr), Edg4, Pal.Deg3 );

        if lev==1, title('Bulk (RdSig)'); end

    elseif strcmp( typRite, 'Star' ) 
        
        Edg4 = [0.05  0.35  0.6  1.25];
        p_BoundPixSel( Pset, FRM.RdSig.Star(Bsmlr), Edg4, Pal.Deg3 );

        if lev==1, title('Star (RdSig)'); end        
        
    elseif strcmp( typRite, 'Diamond' ) 
        
        Edg4 = [0.25  0.5  0.75  1.01];
        p_BoundPixSel( Pset, FRM.RospA.Diamo(Bsmlr), Edg4, Pal.Deg3 );
        
        if lev==1, title('Diamond'); end
    else
        error('not implemented %s', typRite );
    end
    % -----  Corners (Ecken=Ek)  -----
    %Edg4 = [0.25  0.5  0.75  1.01];
    %p_BoundPixSel( Pset, FRM.RoEck.EkTT(Bsmlr), Edg4, Pal.Deg3 );   
    %p_BoundPixSel( Pset, FRM.RoEck.EkBB(Bsmlr), Edg4, Pal.Deg3 );   
    %p_BoundPixSel( Pset, FRM.RoEck.EkLL(Bsmlr), Edg4, Pal.Deg3 );   
    %p_BoundPixSel( Pset, FRM.RoEck.EkRR(Bsmlr), Edg4, Pal.Deg3 );   
    
    p_AxesToImgDim( szM );
    ylabel(['Lev ' num2str(lev)] );
    
end
set(gcf, 'paperposition', [0.5 0.25 7 10.75]);

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2File( [dirFigs 'RoadSceneForm' typ], 1, 1, figForm );
end

