"""

Displays some saliency info for two different textures.

"""
import sys
sys.path.insert(0, '..')
from globalsSB import *

import subprocess
import platform

u_AddGenPath( '../UtilPy/' )
u_AddGenPath( '../DescExtr/UtilPy/' )

# ----------   Org & Proc   ----------
from OrgFileNames import o_FileExtensions
from OrgAtts import *
from LoadDescSalc import *
from Texture import * 

Fixt, Dmy = o_FileExtensions()

# ----------   Plot   ----------
import matplotlib.pyplot as plt
import imageio.v3 as iio

from PlotBboxes import p_BboxL
from PlotUtils import imglabN


# ------------------------------   FieldMound   ------------------------------
pthImg    = 'Imgs/FieldMound.jpg'
pthDesc   = 'Desc/FieldMound'
cmnd      = f'../DescExtr/dscx {pthImg} {pthDesc}'

# Convert path separators for Windows if necessary
if os.name == 'nt':
    cmnd = cmnd.replace('/', '\\')

# Run descriptor extractor
Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

if Res.returncode != 0:
    raise ValueError("dscx did not execute properly somehow")

Out    = Res.stdout + Res.stderr

pthSalc   = pthDesc + Fixt.salc

TxaFld, ShpFld, EnsFld, DscFld = LoadDescSalc( pthSalc )

#print( DscFld.Ndsc.Skl )

# ------------------------------   PlotFieldMound   ------------------------------
Ifield = iio.imread( pthImg )

Bnum   = TxaFld.Blb.Typ == 1          # numerous
Benk   = TxaFld.Blb.Typ == 8          # high-contrast

fig1, ax1 = plt.subplots(figsize=(10, 8))
ax1.imshow(Ifield)
ax1.axis('off')

# Plot bounding boxes
p_BboxL(ax1, TxaFld.Blb.Box[Bnum, :])                     # default color
p_BboxL(ax1, TxaFld.Blb.Box[Benk, :], rgbOrIx=[1, 0.5, 0])  # orange

#                       plt.show()


# ------------------------------   SnowCovMount   ------------------------------
pthImg    = 'Imgs/SnowCovMount.jpg'
pthDesc   = 'Desc/SnowCovMount'
cmnd      = f'../DescExtr/dscx {pthImg} {pthDesc}'

# Convert path separators for Windows if necessary
if os.name == 'nt':
    cmnd = cmnd.replace('/', '\\')

# Run descriptor extractor
Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

if Res.returncode != 0:
    raise ValueError("dscx did not execute properly somehow")

Out    = Res.stdout + Res.stderr

pthSalc   = pthDesc + Fixt.salc

TxaSnw, ShpSnw, EnsSnw, DscSnw = LoadDescSalc( pthSalc )

# ------------------------------   PlotSnowCovMount   ------------------------------
Isnow = iio.imread( pthImg )

Bnum   = TxaSnw.Blb.Typ == 1          # numerous
Benk   = TxaSnw.Blb.Typ == 8          # high-contrast

fig2, ax2 = plt.subplots(figsize=(10, 8))
ax2.imshow(Isnow)
ax2.axis('off')

# Plot bounding boxes
p_BboxL(ax2, TxaSnw.Blb.Box[Bnum, :])                     # default color
p_BboxL(ax2, TxaSnw.Blb.Box[Benk, :], rgbOrIx=[1, 0.5, 0])  # orange

#plt.show()
plt.show(block=False) #, plt.pause(2)


## ------------------------------   Extract Some Vars   ------------------------------
GstField    = u_TxtrGstToArrs( TxaFld.Gst )
GstSnow     = u_TxtrGstToArrs( TxaSnw.Gst )

PrpPres     = np.concatenate((GstField.PrpPres.reshape(1,-1),
                              GstSnow.PrpPres.reshape(1,-1)), axis=0)

# Horizontal concatenation of arrays (1D or 2D)
MxSizShp    = np.concatenate((DscFld.MaxSizScl.Shp.reshape(1,-1),
                              DscSnw.MaxSizScl.Shp.reshape(1,-1)), axis=0)
CvgShp      = np.concatenate((DscFld.CvgShp.Deg.reshape(1,-1),
                              DscSnw.CvgShp.Deg.reshape(1,-1)),axis=0)
CtrRngRR    = np.concatenate((DscFld.MxRngRR.reshape(1,-1),
                              DscSnw.MxRngRR.reshape(1,-1)), axis=0)
CtrRngBon   = np.concatenate((DscFld.MxRngBon.reshape(1,-1),
                              DscSnw.MxRngBon.reshape(1,-1)), axis=0)

# 
MeanMaxGry  = np.array([
    DscFld.GryMmm[1],
    DscFld.GryMmm[2],
    DscSnw.GryMmm[1],
    DscSnw.GryMmm[2]
]).reshape(-1, 1)



## ------------------------------   Plot Some Vars   ------------------------------
nLev          = DscFld.MaxSizScl.nLev
aLbBlob, nTyp = o_BlobLabels()

fig, axes = plt.subplots(4, 2, num=3, figsize=(10, 12))  # figure(3); clf;
axes = axes.ravel()

# ----------  Subplot 1
ax0   = axes[0]
width = 0.25
xax   = np.arange( nTyp )                       # x-axis (label positions)

ax0.bar(xax - width/2, PrpPres[0,:], width, label='Field')
ax0.bar(xax + width/2, PrpPres[1,:], width, label='Snow')

ax0.set_xticks(xax)
ax0.set_xticklabels(aLbBlob)
ax0.set_ylabel('Prop Present')
ax0.legend()
ax0.set_title('Blob Presence per Type')

# ----------  Subplot 2
ax1   = axes[1]
xax   = np.arange( nLev ) + 1                    # x-axis (levels)

ax1.bar( xax-width/2, MxSizShp[0,:], width )
ax1.bar( xax+width/2, MxSizShp[1,:], width )

ax1.set_xticks(xax)
ax1.set_xlabel('Level')
ax1.set_ylabel('Prop of Img')
ax1.set_title('Max Size by Shape')


# ----------  Subplot 3
ax2   = axes[2]

ax2.bar( xax-width/2, CvgShp[0,:], width )
ax2.bar( xax+width/2, CvgShp[1,:], width )

ax2.set_xticks(xax)
ax2.set_xlabel('Level')
ax2.set_ylabel('Prop of Img')
ax2.set_title('Coverage Shape')


plt.show(block=False)
plt.pause(2)




