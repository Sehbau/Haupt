%
% Plotting salient red spots. af exsbPlotShape.m
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'Demos'
    
strImg      = 'aachen.png';
%strImg      = 'highway.jpg';

fipaImg     = [ 'Imgs/' strImg];         % image path
fipsOut     = [ 'Desc/' strImg(1:end-4)]; % output filestem

% change to window backslash (in case we are on windows)
if ispc
    fipaImg  = u_PathToBackSlash( fipaImg ); 
    fipsOut  = u_PathToBackSlash( fipsOut ); 
end

%% =========   Command   ========
cmnd        = [ FipaExe.dscx ' ' fipaImg ' ' fipsOut ];

if ispc
    cmnd    = u_PathToBackSlash( cmnd );
end

[Sts Out]   = system(cmnd);      

v_CmndExec( Sts, Out, cmnd, 1 );

%% -------   Load Region Pixels   -------
Fixt                = o_FileExtensions();
fpDSC               = o_FinaApndExtDscx( fipsOut, Fixt ); 
SLC                 = LoadDescSalc( fpDSC.slc );

%% ---------------    Plot   -------------------
figRed  = 1;
hf      = figure(figRed); clf; 
imagesc( imread(fipaImg) ); hold on;
p_VisSearch( SLC.Dsc.Cnt.PixRed.Pt );
%p_VisSearch( SLC.Dsc.Bon.PixRed.Pt );


%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2File( [dirFigs 'RoadSceneRed'], 1, 1, figRed );
end

