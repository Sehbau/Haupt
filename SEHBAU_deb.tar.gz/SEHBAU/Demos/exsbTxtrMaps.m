% 
% Displays texture maps.
% 
clear;
run('../AdminMb/globalsSB');        

%% =========   Execute Dscx   ========
fipaImg  = 'Imgs/street.jpg';  fipsOut  = 'Desc/street'; sidf='street';
%fipaImg  = 'Imgs/forest.jpg';  fipsOut  = 'Desc/forest'; sidf='forest';
%fipaImg  = 'Imgs/birds.jpg';  fipsOut  = 'Desc/birds'; sidf='birds';
%fipaImg  = 'Imgs/aachen.png';  fipsOut  = 'Desc/aachen'; sidf='aachen';

optS    = '--saveTxm';
%optS    = '--saveTxm --cntMinCtr 0.02'; % for aachen

cmnd    = ['../DescExtr/dscx ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd        = u_PathToBackSlash( cmnd );
    [Sts Out]   = dos(cmnd);    % excecute program for windows
elseif isunix
    [Sts Out]   = unix(cmnd);   % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 ); % verify output

%% -------------   Load    ---------------
TXM             = LoadTxtrMaps( [fipsOut '.txm'] ); 
[SLC HedSlc]    = LoadDescSalc( [fipsOut '.slc'] ); 

Irgb            = imread( fipaImg );

%% -------------   Retrieve Bboxes   -------------
aLbBlob         = o_BlobLabels();
L2LSclFct       = f_LevToLaySclFct( HedSlc.szI, HedSlc.szL );
SBbxOrg         = u_BlobBbxRtrv( SLC.Txa.Blb, aLbBlob );
SBbxLay         = u_BlobBbxRtrv( SLC.Txa.Blb, aLbBlob, L2LSclFct );

%% -------------   Plot Maps   -------------
figWoutBx   = 2;
PlotTxtrMaps( TXM, figWoutBx, Irgb );

figWithBx   = 3;
PlotTxtrMaps( TXM, figWithBx, Irgb, SBbxLay );
subplot(3,3,1);
p_BboxL( SBbxOrg.Hor );
p_BboxL( SBbxOrg.Vrt );

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2Jpeg( [dirFigs 'TxtrMaps_' sidf], figWithBx );
end

if 0
    figNumOnly  = 4;
    PlotTxtrMap1( TXM.KNT.Num, figNumOnly, Irgb, 'Num' );
    PrintFig2Jpeg( [dirFigs 'TxtrMaps_' sidf '_Num'], figNumOnly );
end



