"""

Plots small regions.

afro exsbFormAxial.py

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescExtr.DescFile import LoadDescUniv, LoadDbinUniv
from AdminPy.DescExtr.Saliency import LoadDescSalc

Fixt      = o_FileExtensions()

# ------------------------------   DesxExtr   ------------------------------
#imgNa     = 'aachen.png'
imgNa     = 'highway.jpg'

imgNa     = Path( imgNa )
pthImg    = Path( 'Imgs/' ) / imgNa
pthDesc   = Path( 'Desc/' ) / imgNa.stem

# ------------------------------   Options   ------------------------------
OptK            = argsDscx()
OptK.nLev       = 3 
OptK.depth      = 3 
OptK.saveRegUnv = 1     
OptK.saveBonSpc = 1
OptK.optS       = '--frmMinPix 0 --frmMinCtr 0 --saveBonMore --saveBonBboxRaw'
optS            = i_DscxArgs(OptK)

cmnd      = str(Path('../DescExtr/dscx ')) + str(pthImg) + ' ' + str(pthDesc) + ' ' + optS

# Run descriptor extractor
Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Sts       = Res.returncode
Out       = Res.stdout + Res.stderr

fpDSC     = o_FinaApndExtDscx( str(pthDesc), Fixt )


# ------------------------------   Load & Retrieve   ------------------------------
DUV, Hed      = LoadDescUniv( fpDSC.dsc )
#SLC, Hed      = LoadDescSalc( fpDSC.salc )
print( DUV.AFRM[0].nRsg )

# ----------   Feature Segments   ----------
import AdminPy.DescExtr.Features.LoadFeatures as lodf

AREG, KtReg   = lodf.LoadRegUnv(   fpDSC.ruv ) # not tested yet
ABON, Jbsp    = lodf.LoadBonPixSpc( fpDSC.bspx );    

# ----------   BoundingBoxes   ----------
import AdminPy.DescExtr.Features.LoadBonBbox as lodb
BONBOX1       = lodb.LoadBboxFunv( fpDSC.bonBbxRaw )
l=0; d=0

    
BOX           = BONBOX1.ABbox[l][d]
nCC           = BONBOX1.Nflk[l,d]

BONBOX2       = lodb.LoadBonBboxPyr( fpDSC.bonBbx )
ABbox         = BONBOX2.ABbox # [nLev][depth]
NbonPerLev    = BONBOX2.Nbon
IxX           = BONBOX2.IxX

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
import numpy as np

from AdminPy.DescExtr.Features.Segments.RegUtil import *
from AdminPy.DescExtr.Plot.PlotDescBound import *
from AdminPy.Util.Plot.PlotUtils import *

import imageio.v3 as iio

if 1:
    Irgb   = iio.imread( pthImg )

    fig1, axes = plt.subplots(1, 2, num=2, figsize=(10, 8))
    axes   = axes.ravel()
    
    ax1    = axes[0]
    ax1.imshow(Irgb)
    ax1.axis('off')
    p_Cross( 128, ax1 )

# ------- boundaries & regions:     
fig, axes = plt.subplots(3, 2, figsize=(7, 10.75))
fig.suptitle("form", fontsize=10)

for lv in range(KtReg.nLev):

    lvx1 = lv + 1 # 1-based index used for titles/labels
    
    # --- retrieve:
    FRM          = DUV.AFRM[lv]
    ABonPix      = ABON[lv]
    ARegPix      = AREG[lv,:]
    Org          = Jbsp.AOrg[lv]
    szM          = Jbsp.SzM[lv,:] # map size

    BOXLev       = np.concatenate(BONBOX1.ABbox[lv], axis=0)
    
    # ------   LEFT COLUMN: boundaries
    AxLef        = axes[lv,0]
    
    IxSel, Typ   = p_FrmSmall( FRM, ABonPix, BOXLev, AxLef ) # BonUtil.py
    
    AxLef.tick_params(labelsize=8)
    AxLef.invert_yaxis()                # equivalent to 'axis ij'
    AxLef.set_xlim([1, szM[1]])
    AxLef.set_ylim([szM[0],1])          # inverted coordinates check boundary constraints
    AxLef.set_ylabel(f"Lev {lvx1}")
    p_Cross( 128, AxLef )
    
    # ------  RITE COLUMN: regions
    MpTot = u_RegPixToMapSel( ARegPix, Org, IxSel, szM, 20 )
        
    AxRit = axes[lv, 1]
    
    im    = AxRit.imshow( MpTot, cmap='gray', aspect='auto', origin='upper')
    AxRit.tick_params(labelsize=8)
    p_Cross( 128, AxRit )

# Adjust spacing so labels don't clip over neighboring axes
plt.tight_layout()
plt.show(block=False)
