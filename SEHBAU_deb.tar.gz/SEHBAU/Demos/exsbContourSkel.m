% 
% Compares the output of two different settings for contour selection.
%
% Uses the parameter file PrmDesc_CntSkel.txt in directory Params.
%
% Assumes script is run from directory 'Demos'
%
clear;
run('../AdminMb/globalsSB');        

%% ---------    Run the 2 Spaces    ----------
cmndDef = '../DescExtr/dscx Imgs/room.png Desc/roomd'; % default is pyramid
cmndSps = '../DescExtr/dscx Imgs/room.png Desc/room2 Params/PrmDesc_CntSkel.txt'; 

if ispc
    cmndDef = u_PathToBackSlash( cmndDef ); 
    cmndSps = u_PathToBackSlash( cmndSps ); 
end

[OutDef]    = system( cmndDef );
[OutScs]    = system( cmndSps );

[DSCdef HedP] = LoadDescImag( 'Desc/roomd.dsc' );
[DSCsps HedS] = LoadDescImag( 'Desc/room2.dsc' );

%% ---------    Plot Skeleton Contours  ----------
% This is reduced set (not RRE full set)
Irgb = imread('Imgs/room.png');

figure(1); clf;
nLev    = HedP.nLev;
[nr nc] = deal( nLev, 2 );
szI     = size(Irgb);

for l = 1:nLev

    szM = round( szI / 2^(l-1) );
    
    % --------   Default   ---------
    subplot(nr, nc, l*2-1);
    imagesc( imresize( Irgb, 1 / 2^(l-1)) ); 

    p_CntFromAtts( DSCdef.ACNT{l}, szM );     

    set(gca,'fontsize',5);
    title( num2str(DSCdef.ACNT{l}.nCnt), 'fontsize', 10);

    % --------   Sparse   ---------
    subplot(nr, nc, l*2);
    imagesc( imresize( Irgb, 1 / 2^(l-1)) ); 

    p_CntFromAtts( DSCsps.ACNT{l}, szM );     

    set(gca,'fontsize',5);
    title( num2str(DSCsps.ACNT{l}.nCnt), 'fontsize', 10);
    
end

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2Jpeg( [dirFigs 'ContourSkel'], 1 );
end

