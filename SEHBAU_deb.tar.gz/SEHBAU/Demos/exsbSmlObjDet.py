"""

Runs demo for small object detection. Uses two images, birds in the sky
and fireworks.

Uses long option --txws to adjust the size of the texture window.

Assumes script is run from directory 'Demos'

"""
import sys
sys.path.insert(0, '..')
import AdminPy as sb

import subprocess
import platform

#Fixt, Dmy = sb.o_FileExtensions()   # it would be better to use those

## ---------    Bird Image    ----------
# we run with a window size of 8 pixels.
cmnd = '../DescExtr/dscx Imgs/birds.jpg Desc/birds --txws 8'

if sys.platform.startswith("win"):
    cmnd = cmnd.replace('/', '\\')

Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Txa, Shp, Ens, Dsc = sb.LoadDescSalc( 'Desc/birds.slc' )


## ---------    Plot Bird    ----------
import matplotlib.pyplot as plt
import imageio.v3 as iio

fig1, ax1 = plt.subplots(figsize=(10, 8))

Ibirds = iio.imread('Imgs/birds.jpg')

ax1.imshow(Ibirds)
ax1.axis('off')

Bnum    = Txa.Blb.Typ==1        # numerous
Benk    = Txa.Blb.Typ==8        # high-contrast

# Plot bounding boxes
sb.p_BboxL(ax1, Txa.Blb.Box[Bnum, :])                     # default color
sb.p_BboxL(ax1, Txa.Blb.Box[Benk, :], rgbOrIx=[1, 0.5, 0])  # orange

plt.show(block=False)


## ---------    Fireworks Image    ----------
# we run with a window size of 6 pixels.
cmnd = '../DescExtr/dscx Imgs/fireworks.jpg Desc/fireworks --txws 6'

if sys.platform.startswith("win"):
    cmnd = cmnd.replace('/', '\\')

Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Txa, Shp, Ens, Dsc = sb.LoadDescSalc( 'Desc/fireworks.slc' );


## ---------    Plot Fireworks    ----------
fig2, ax2 = plt.subplots(figsize=(10, 8))

Ifirew  = iio.imread('Imgs/fireworks.jpg'); 

ax2.imshow(Ifirew)
ax2.axis('off')

Bnum    = Txa.Blb.Typ==1;        # numerous
Benk    = Txa.Blb.Typ==8;        # high-contrast

# Plot bounding boxes
sb.p_BboxL(ax2, Txa.Blb.Box[Bnum, :])                     # default color
sb.p_BboxL(ax2, Txa.Blb.Box[Benk, :], rgbOrIx=[1, 0.5, 0])  # orange

plt.show(block=False)
plt.pause(.01)

import time
time.sleep(2)


