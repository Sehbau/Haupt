"""

Runs demo for small object detection. Uses two images, birds in the sky
and fireworks.

Uses long option --txws to adjust the size of the texture window.

Assumes script is run from directory 'Demos'

"""
import sys
sys.path.insert(0, '..')

from AdminPy.DescExtr.Saliency import LoadDescSalc

import AdminPy.DescExtr.Plot as PltDsc
import AdminPy.DescExtr.Bbox.PlotBboxes as PltBbx

import subprocess
import platform

#Fixt, Dmy = sb.o_FileExtensions()   # it would be better to use those

## ---------    Bird Image    ----------
# we run with a window size of 8 pixels.
cmnd = '../DescExtr/dscx Imgs/birds.jpg Desc/birds --txws 8'

if sys.platform.startswith("win"):
    cmnd = cmnd.replace('/', '\\')

Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

SLC, Hed = LoadDescSalc( 'Desc/birds.slc' )

BlbBird  = SLC.Blb.Box;

## ---------    Plot Bird    ----------
import matplotlib.pyplot as plt
import imageio.v3 as iio

fig1, ax1 = plt.subplots(figsize=(10, 8))

Ibirds = iio.imread('Imgs/birds.jpg')

ax1.imshow(Ibirds)
ax1.axis('off')

Bnum    = BlbBird.Typ==1        # numerous
Benk    = BlbBird.Typ==8        # high-contrast

# Plot bounding boxes
PltBbx.p_BboxL(ax1, BlbBird.Box[Bnum, :])                     # default color
PltBbx.p_BboxL(ax1, BlbBird.Box[Benk, :], rgbOrIx=[1, 0.5, 0])  # orange

plt.show(block=False)


## ---------    Fireworks Image    ----------
# we run with a window size of 6 pixels.
cmnd = '../DescExtr/dscx Imgs/fireworks.jpg Desc/fireworks --txws 6'

if sys.platform.startswith("win"):
    cmnd = cmnd.replace('/', '\\')

Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

SLC, Hed = LoadDescSalc( 'Desc/fireworks.slc' );

BlbFire = SLC.Blb.Box;


## ---------    Plot Fireworks    ----------
fig2, ax2 = plt.subplots(figsize=(10, 8))

Ifirew  = iio.imread('Imgs/fireworks.jpg'); 

ax2.imshow(Ifirew)
ax2.axis('off')

Bnum    = BlbFire.Typ==1;        # numerous
Benk    = BlbFire.Typ==8;        # high-contrast

# Plot bounding boxes
PltBbx.p_BboxL(ax2, BlbFire.Box[Bnum, :])                     # default color
PltBbx.p_BboxL(ax2, BlbFire.Box[Benk, :], rgbOrIx=[1, 0.5, 0])  # orange

plt.show(block=False)
plt.pause(.01)

import time
time.sleep(2)


