"""

Loading, accessing and plotting regions and boundaries.

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescExtr.DescFile import LoadDescUniv, LoadDbinUniv
from AdminPy.DescExtr.Saliency import LoadDescSalc

Fixt      = o_FileExtensions()

# ------------------------------   DesxExtr   ------------------------------
#imgNa     = 'aachen.png'
imgNa     = 'highway.jpg'

imgNa     = Path( imgNa )
pthImg    = Path( 'Imgs/' ) / imgNa
pthDesc   = Path( 'Desc/' ) / imgNa.stem

# ------------------------------   Options   ------------------------------
OptK            = argsDscx()
OptK.nLev       = 3 
OptK.depth      = 3 
OptK.saveRegUnv = 1     
OptK.saveBonSpc = 1 
optS            = i_DscxArgs(OptK)

cmnd      = str(Path('../DescExtr/dscx ')) + str(pthImg) + ' ' + str(pthDesc) + ' ' + optS

# Run descriptor extractor
Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Sts       = Res.returncode
Out       = Res.stdout + Res.stderr

fpDSC     = o_FinaApndExtDscx( str(pthDesc), Fixt )


# ------------------------------   Load   ------------------------------
import AdminPy.DescExtr.Features.LoadFeatures as lodf

AREG, KtReg   = lodf.LoadRegUnv(    fpDSC.ruv ) 
ABON, Jbsp    = lodf.LoadBonPixSpc( fpDSC.bspx )

import imageio.v3 as iio
Irgb          = iio.imread( pthImg )
IrgbOrg       = Irgb.copy() # make a copy for the 2nd level

# ------------------------------   Retrieve   ------------------------------
# For this demo, we plot one region and one boundary into the RGB image.
from AdminPy.DescExtr.Features.Segments.RegUtil import *
from AdminPy.DescExtr.Features.Segments.BonUtil import *
import numpy as np

# determines the number of pixels for each region and boundary 
NPixReg       = u_RegUnivNpx( AREG ) # returns [nLev][depth]
NPixBon       = u_BonNpixSpc( ABON ) # return  [nLev]

# Plotting works only for level 0 if pyramid was specified (default). For higher
# levels we need to subsample Irgb to the corresponding level

# --- select a region
lev       = 0    
dth       = 0
ixR       = NPixReg[lev][dth].argmax()  # select largest one
#ixR       = 2
Row, Col  = u_RegCoord1( AREG, lev, dth, ixR, Irgb.shape[:2] )

# blank out the region across all 3 color channels
Irgb[Row,Col,:] = 255

# --- select a boundary
ixB       = NPixBon[lev].argmax()       # select longest one
Row, Col  = u_BonCoord1( ABON, lev, ixB )

colRed    = [255, 0, 0]
Irgb[Row,Col,:] = colRed

# ----------   Level 1   ----------
# we need to downsample the image
import skimage.transform as skimage_transform
IrgbQut   = skimage_transform.rescale(IrgbOrg, scale=(0.5, 0.5, 1), anti_aliasing=True)
IrgbQut   = (IrgbQut*255).astype(np.uint8)

# --- select a region
lev       = 1
dth       = 0
ixR       = NPixReg[lev][dth].argmax()
#ixR       = 3
Row, Col  = u_RegCoord1( AREG, lev, dth, ixR, IrgbQut.shape[:2] )

IrgbQut[Row,Col,:] = 255

# --- select a boundary
Row, Col  = u_BonCoord1( ABON, lev, ixR )

IrgbQut[Row,Col,:] = colRed

# ------------------------------   Plot Selected Ones   ------------------------------
import matplotlib.pyplot as plt

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))

ax1.imshow(Irgb)
ax1.set_title("Original Image")
ax1.axis('off') 

ax2.imshow(IrgbQut)
ax2.set_title("Quarter Resolution")
ax2.axis('off') 

plt.tight_layout()
plt.show(block=False)


# ------------------------------   Plot All   ------------------------------
from AdminPy.DescExtr.Plot.PlotFeatures import *
# For this demo, we plot ALL regions and ALL boundaries into separate plots

# already imported above:
#    from AdminPy.DescExtr.DescFile.Features.RegUtil import *

PlotRegUnv( AREG, Irgb.shape )
PlotRegUnv( AREG, Irgb.shape, 'gray' )

PlotBonSpc( ABON, Irgb.shape, 1 )



