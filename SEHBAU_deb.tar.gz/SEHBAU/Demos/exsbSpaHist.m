% 
% Compares output of spatial histograms for four types of grid sizes.
%
% Assumes script is run from directory 'Demos'
%
clear;
run('../AdminMb/globalsSB');        

%% ---------    Histograms   ----------
% Default is 3x3. For the other cases we provide a parameter file.
cmnd3x3 = '../DescExtr/dscx Imgs/img3.jpg Desc/img3_33';  % default 3x3
cmnd5x5 = '../DescExtr/dscx Imgs/img3.jpg Desc/img3_55 Params/PrmDesc_SpaHist5x5.txt'; 
cmnd3x1 = '../DescExtr/dscx Imgs/img3.jpg Desc/img3_31 Params/PrmDesc_SpaHist3x1.txt'; 
cmnd1x3 = '../DescExtr/dscx Imgs/img3.jpg Desc/img3_13 Params/PrmDesc_SpaHist1x3.txt'; 

if ispc
    cmnd3x3 = u_PathToBackSlash( cmnd3x3 ); 
    cmnd5x5 = u_PathToBackSlash( cmnd5x5 ); 
    cmnd3x1 = u_PathToBackSlash( cmnd3x1 ); 
    cmnd1x3 = u_PathToBackSlash( cmnd1x3 ); 
end

[St Out3x3] = system( cmnd3x3 );
[St Out5x5] = system( cmnd5x5 );
[St Out3x1] = system( cmnd3x1 );
[St Out1x3] = system( cmnd1x3 );

%% ---------    Hists To Arr   ----------
cmnd3x3 = '../DescExtr/h2arr Desc/img3_33.hst Vect/img3_33'; 
cmnd5x5 = '../DescExtr/h2arr Desc/img3_55.hst Vect/img3_55'; 
cmnd3x1 = '../DescExtr/h2arr Desc/img3_31.hst Vect/img3_31'; 
cmnd1x3 = '../DescExtr/h2arr Desc/img3_13.hst Vect/img3_13'; 

if ispc
    cmnd3x3 = u_PathToBackSlash( cmnd3x3 ); 
    cmnd5x5 = u_PathToBackSlash( cmnd5x5 ); 
    cmnd3x1 = u_PathToBackSlash( cmnd3x1 ); 
    cmnd1x3 = u_PathToBackSlash( cmnd1x3 ); 
end

[St Out3x3] = system( cmnd3x3 );
[St Out5x5] = system( cmnd5x5 );
[St Out3x1] = system( cmnd3x1 );
[St Out1x3] = system( cmnd1x3 );

%% ---------   LOAD   ---------
[DSC33 HedP] = LoadDescImag( 'Desc/img3_33.dsc' );
[DSC55 HedS] = LoadDescImag( 'Desc/img3_55.dsc' );
[DSC31 HedS] = LoadDescImag( 'Desc/img3_31.dsc' );
[DSC13 HedS] = LoadDescImag( 'Desc/img3_13.dsc' );

[HST33 Head33] = LoadDescHist( 'Desc/img3_33.hst' );
[HST55 Head55] = LoadDescHist( 'Desc/img3_55.hst' );
[HST31 Head31] = LoadDescHist( 'Desc/img3_31.hst' );
[HST13 Head13] = LoadDescHist( 'Desc/img3_13.hst' );

Hari33      = LoadHistImgArr( 'Vect/img3_33.hari' );
Hari55      = LoadHistImgArr( 'Vect/img3_55.hari' );
Hari31      = LoadHistImgArr( 'Vect/img3_31.hari' );
Hari13      = LoadHistImgArr( 'Vect/img3_13.hari' );

%% ---------    Plot   ----------
figure(1); clf;
subplot(4,1,1); bar(Hari33);
subplot(4,1,2); bar(Hari55);
subplot(4,1,3); bar(Hari31);
subplot(4,1,4); bar(Hari13);
