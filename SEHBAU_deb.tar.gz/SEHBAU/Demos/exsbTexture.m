% 
% For examples on texture analysis see:
%
% exsbKolumns.m
% exsbTxtrMaps.m
% exsbSalBlobs.m
%
