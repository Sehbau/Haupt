% 
% Displays shape-based proposals. .qbox, .qdsc
% 
clear;
run('../AdminMb/globalsSB');        

%% =========   Execute Dscx   ========
fipaImg  = 'Imgs/room.png';  fipsOut  = 'Desc/room';

optS    = '--saveProp';        % save as one file
%optS    = '--ssepProp';         % save as separate files

cmnd    = ['../DescExtr/dscx ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd        = u_PathToBackSlash( cmnd );
    [Sts Out]   = dos(cmnd);    % excecute program for windows
elseif isunix
    [Sts Out]   = unix(cmnd);   % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 ); % verify output

%% ----------   Load    ---------
Fixt        = o_FileExtensions();

% ---- bounding boxes
if strcmp(optS, '--saveProp')
    [BBx Nr]    = LoadDescPropBbox( [fipsOut Fixt.qbbx] );
else
    [BBx.ShpGen Nr.shpGen] = LoadBboxL( [fipsOut Fixt.qbbx 'Shp'] );
    [BBx.TtgGen Nr.ttgGen] = LoadBboxL( [fipsOut Fixt.qbbx 'Ttg'] );
    [BBx.ShpVrt Nr.shpVrt] = LoadBboxL( [fipsOut Fixt.qbbx 'AxVrt'] );
    [BBx.ShpHor Nr.shpHor] = LoadBboxL( [fipsOut Fixt.qbbx 'AxHor'] );
end

% ---- descriptor attributes
[QDSC] 	= LoadDescPropAtts( [fipsOut Fixt.qdsc] ); 
DispLoad( [fipsOut Fixt.qdsc] );

Irgb   	= imread( fipaImg );
szI     = size( Irgb );

%% -------------   Plot Maps   -------------
figure(1); clf;
[nr nc] = deal(2,2);

subplot(nr,nc,1); 
imagesc( Irgb); hold on;
p_BboxL( BBx.ShpGen, 3 );
imglabN('ShpGen', Nr.shpGen );

subplot(nr,nc,2); 
imagesc( Irgb); hold on;
p_BboxL( BBx.TtgGen, 3 );
imglabN('TtgGen', Nr.ttgGen );

subplot(nr,nc,3); 
imagesc( Irgb); hold on;
p_BboxL( BBx.ShpVrt, 4 );
imglabN('ShpVrt', Nr.shpVrt );

subplot(nr,nc,4); 
imagesc( Irgb); hold on;
p_BboxL( BBx.ShpHor, 4 );
imglabN('ShpHor', Nr.shpHor );

%% -------------   Plot Desc   -------------
figure(2); clf;
[nr nc] = deal(2,2);

subplot(nr,nc,1); 
imagesc( Irgb); hold on;
p_ShpPoleFromPos( QDSC.ShpGen, szI );
title('Shapes indicated as circles');

subplot(nr,nc,2); 
imagesc( Irgb); hold on;
p_TtrgLst( QDSC.TtgGen, szI );
title('Tetragons');



