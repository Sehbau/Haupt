% 
% Compares the two image spaces by plotting the contour skeleton, since the
% image scale space was not saved.
%
% Uses long option --is to set the space
%
% Assumes script is run from directory 'Demos'
%
clear;
run('../AdminMb/globalsSB');        

%% ---------    Run the 2 Spaces    ----------
cmndPyr = '../DescExtr/dscx Imgs/room.png Desc/roompyr'; % default is pyramid
cmndScs = '../DescExtr/dscx Imgs/room.png Desc/roomscs --is 2 --cntMinCtr 0.05'; % scale space

if ispc
    cmndPyr = u_PathToBackSlash( cmndPyr ); 
    cmndScs = u_PathToBackSlash( cmndScs ); 
end

[OutPyr]    = system( cmndPyr );
[OutScs]    = system( cmndScs );

[DSCpyr HedP] = LoadDescImag( 'Desc/roompyr.dsc' );
[DSCscs HedS] = LoadDescImag( 'Desc/roomscs.dsc' );

[YPyr ShpPyr EnsPyr DscPyr] = LoadDescSalc( 'Desc/roompyr.slc' );
[YSsp ShpSsp EndSsp DscSsp] = LoadDescSalc( 'Desc/roomscs.slc' );

%% ---------    Plot Skeleton Contours  ----------
% This is reduced set (not full set)
Irgb = imread('Imgs/room.png');

figure(1); clf;
nLev    = HedP.nLev;
[nr nc] = deal( nLev, 2 );
szI     = size(Irgb);

for l = 1:nLev
    
    % --------   Pyramid   ---------
    subplot(nr, nc, l*2-1);
    imagesc( imresize( Irgb, 1 / 2^(l-1)) ); 

    szM = round( szI / 2^(l-1) );
    p_CntFromAtts( DSCpyr.ACNT{l}, szM );     

    set(gca,'fontsize',5);

    % --------   Scale Space   ---------
    subplot(nr, nc, l*2);
    imagesc( Irgb ); % we plot the original image (no scale space)

    p_CntFromAtts( DSCscs.ACNT{l}, szI );     

    set(gca,'fontsize',5);
    
end


%% ---------   Some Stats   ----------
figure(2); clf; 

xax = 1:nLev;

subplot(2,2,1); hold on;

plot( xax, DscPyr.MxRngRR, 'b-');
plot( xax, DscPyr.MxRngEg, 'b:');

plot( xax, DscSsp.MxRngRR, 'r-' );
plot( xax, DscSsp.MxRngEg, 'r:' );

set( gca, 'xtick', 1:nLev );
ylabel('Max Contrast');
xlabel('Level');
legend({'Pyr RR' 'PyrEdg' 'Ssp RR' 'Ssp Edg'}, 'location', 'southwest');

subplot(2,2,2); hold on;

plot( xax, DscPyr.Nrdg, 'b-');
plot( xax, DscPyr.Nriv, 'b--');
plot( xax, DscPyr.Nedg, 'b.-');
plot( xax, DscPyr.Ndsc.Skl, 'b:');

plot( xax, DscSsp.Nrdg, 'r-');
plot( xax, DscSsp.Nriv, 'r--');
plot( xax, DscSsp.Nedg, 'r.-');
plot( xax, DscSsp.Ndsc.Skl, 'r:');

set( gca, 'xtick', 1:nLev );
ylabel('N ridges/rivers');
xlabel('Level');
legend({'PyrRdg' 'PyrRiv' 'PyrEdg' 'PyrSkl'...
        'SspRdg' 'SspRiv' 'SspEdg' 'SspSkl'}, ...
    'location', 'northeast');
