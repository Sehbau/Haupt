% 
% Runs demo for salient texture blobs. Loads saliency file (.slc) and plots
% blob bounding boxes for numerous and high-contrast regions.
%
% Assumes script is run from directory 'Demos'
%
clear;
run('../globalsSB');        

%% ---------    FieldMound Image    ----------
cmnd = '../DescExtr/dscx Imgs/FieldMound.jpg Desc/FieldMound';

cmnd = u_PathToBackSlash( cmnd );

dos( cmnd );

[TxaFld ShpFld EnsFld DscFld] = LoadDescSalc( 'Desc/FieldMound.slc' );

%% ---------    Plot FieldMound    ----------
figure(1); clf;

Bnum    = TxaFld.Blb.Typ==1;        % numerous
Benk    = TxaFld.Blb.Typ==8;        % high-contrast

Ifield  = imread('Imgs/FieldMound.jpg'); 

imagesc( Ifield );

p_BboxL( TxaFld.Blb.Box( Bnum, :) );
p_BboxL( TxaFld.Blb.Box( Benk, :), [1 0.5 0] ); % orange


%% ---------    SnowCovMount Image    ----------
cmnd = '../DescExtr/dscx Imgs/SnowCovMount.jpg Desc/SnowCovMount';

cmnd = u_PathToBackSlash( cmnd );

dos( cmnd );

[TxaSnw ShpSnw EnsSnw DscSnw] = LoadDescSalc( 'Desc/SnowCovMount.slc' );


%% ---------    Plot SnowCovMount    ----------
figure(2); clf;

Bnum    = TxaSnw.Blb.Typ==1;        % numerous
Benk    = TxaSnw.Blb.Typ==8;        % high-contrast

Isnow = imread('Imgs/SnowCovMount.jpg'); 

imagesc( Isnow );

p_BboxL( TxaSnw.Blb.Box( Bnum, :) );
p_BboxL( TxaSnw.Blb.Box( Benk, :), [1 0.5 0] ); % orange


%% ---------    Plot Some Variables   ---------
GstField    = u_TxtrGstToArrs( TxaFld.Gst );
GstSnow     = u_TxtrGstToArrs( TxaSnw.Gst );
PrpPres     = [ GstField.PrpPres GstSnow.PrpPres ];
%Density     = [ MstField.Men     MstSnow.Men ]; % not so interesting
%Variability = [ MstField.Sdv     MstSnow.Sdv ]; % not so interesting

MxSizShp    = [ DscFld.MaxSizScl.Shp DscSnw.MaxSizScl.Shp ];
CvgShp      = [ DscFld.CvgShp.Deg    DscSnw.CvgShp.Deg ];
CtrRngRR    = [ DscFld.MxRngRR       DscSnw.MxRngRR ];
CtrRngBon   = [ DscFld.MxRngBon      DscSnw.MxRngBon ];
MeanMaxGry  = [ DscFld.GryMmm(2:3)   DscSnw.GryMmm(2:3)]';
nLev        = DscFld.MaxSizScl.nLev;

[aLbBlob nTyp] = o_BlobLabels();

figure(3); clf; [nr nc] = deal( 4, 2 );

subplot(nr,nc,1);
bar( PrpPres );
set( gca, 'xtick', 1:nTyp );
set( gca, 'xticklabel', aLbBlob );
ylabel(' Prop Present');
legend( {'Field' 'Snow'} );

subplot(nr,nc,2);
bar( MxSizShp );
set( gca, 'xtick', 1:nLev );
xlabel('Level');
ylabel('Max Size Shp');
%legend( {'Field' 'Snow'} );

subplot(nr,nc,4);
bar( CvgShp );
set( gca, 'xtick', 1:nLev );
xlabel('Level');
ylabel('Coverage Shape');
%legend( {'Field' 'Snow'} );

subplot(nr,nc,3);
bar( CtrRngBon );
set( gca, 'xtick', 1:nLev );
xlabel('Level');
ylabel('Max Contrast Boundaries');
legend( {'Field' 'Snow'} );

subplot(nr,nc,5);
bar( CtrRngRR );
set( gca, 'xtick', 1:nLev );
xlabel('Level');
ylabel('Max Contrast Ridge/River');
legend( {'Field' 'Snow'} );

subplot(nr,nc,7);
bar( MeanMaxGry );
set( gca, 'xtick', 1:2 );
set( gca, 'xticklabel', {'Mean' 'Max'} );
ylabel('Mean & Max Gray');
%legend( {'Field' 'Snow'} );



%%
if 0
subplot(nr,nc,2);
bar( Density );
set( gca, 'xtick', 1:nTyp );
set( gca, 'xticklabel', aLbBlob );
ylabel(' Mean Value');
legend( {'Field' 'Snow'} );

subplot(nr,nc,3);
bar( Variability );
set( gca, 'xtick', 1:nTyp );
set( gca, 'xticklabel', aLbBlob );
ylabel('Variability');
legend( {'Field' 'Snow'} );
end
