"""

Focus extraction of fabric description for annotations. Mock example with fake
bounding boxes.

PREVIOUS  iclDscx.py, iclDbin.py, iclFabric.py
PRESENT   focFabricAnn.py
NEXT      smlFbrc.py

"""
import sys, subprocess
from pathlib import Path
from dataclasses import is_dataclass
import numpy as np

sys.path.insert(0, '../../../SEHBAU')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Texture.FabricIO import *
from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.LoadCollHist import LoadCollHist
from AdminPy.DescUtil.BoundBox import *

# ------------------------------   Collection   ------------------------------
bas = 7 # OLTO
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

## ----------------   Admin & Options   --------------
bSaveFocFll     = 1    # =0 means will write to '.\ztst'
bSaveFocSts     = 1    # =0 means will write to '.\ztst'
bPlot           = 0

# ------------------------------   Paths   ------------------------------
Pths, Jcoll  = u_CollPaths( bas )
Pths, Jcoll  = u_CollPathAnn( Pths, Jcoll )

FixtImg     = o_FileExtensions()
FixtFoc     = o_FileExtensFoc()
FixtColl    = o_FileExtensColl()
FinaColl    = o_FileNameColl( Pths.hist, FixtColl )
Fips1       = o_FileStems( Pths, '', 'cab_fbrc' )

fipaExe     = sb.FipaExe['fbrc2arr']
pthOut      = Path("tmp/fbar")
fpDSC       = o_FinaApndExtDscx( pthOut, FixtImg )

## -----------------   Delete Previous Files   -----------------
IxCollDel = [7, 10, 17, 37, 50, *range(60, 63), 100, 200]
#if bas in IxCollDel:
#    if bSaveDesc > 0:
#        cl.u_DescDel( Pths.dsci )

# --------------------------------------------------------------------------------
#                               L O O P   I M A G E S
# --------------------------------------------------------------------------------
# Selection:
#IxImg   = 1:nImgTren;
#IxImg   = 1936:2000; # nImgTren;
Ix0Img   = Jcoll.Ix0Img;
nImg     = len(Ix0Img);
#nImg     = 0
RndNo    = np.random.default_rng()

print(f"Running {bas}, nImg {nImg}", end="")
for i in range(0,nImg):

    ixi     = Ix0Img[i]

    pthFbrc = o_FileNameFrmt( Fips1.fbrc, ixi, '', Jcoll.finaFrmt )

    # ------------------------------   Init (on 1st image)   ------------------------------
    # scaling factors for focus selection
    if i==0:
        # obtain image size from fabric file
        fpFbrc      = pthFbrc + FixtImg.fbrc
        dmy, HedFbc = LoadFabric( fpFbrc )
        # the scaling factors
        PrmFocScl   = i_PrmFbrcFocScl( HedFbc.Hed.szV, HedFbc.Hed.szH )

    # ------------------------------   fbrc2arr   ------------------------------
    cmnd = f"{fipaExe} {pthFbrc}{FixtImg.fbrc} {pthOut}"
    
    try:
        Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True, check=True)
        StdOut = Res.stdout
    except subprocess.CalledProcessError as e:
        print(f"Command execution failed: {e.stderr}")
        StdOut = e.stderr

    # ------------------------------   Load   ------------------------------
    bDispLoad = i==0
    # loading from integer as float
    FFLL  = LoadFbrcArrays( fpDSC, bDispLoad )
                 
    # -------------------------------------------------------------------
    #                     L O O P   B B O X E S 
    # -------------------------------------------------------------------
    # fake bounding boxes [nBox 4]
    nBox  = RndNo.integers(1, 4)
    szVar = RndNo.integers(1,3)
    Bboxs = u_BboxRand( nBox, HedFbc.Hed.szV / szVar, HedFbc.Hed.szH / szVar )
    
    ctg   = Jcoll.LabImg[i]
    
    for b in range(nBox):

        Box      = Bboxs[b,:]        # extract one bounding box

        # --- verify it is within bounds
        vrf_BboxInBounds( Box, HedFbc.Hed.szV, HedFbc.Hed.szH )

        # --- the linear indices
        IXlin    = f_FbrcFocRngs( Box, PrmFocScl )

        if IXlin.nLayEnc==0: # should not occur
            print( str(IXlin.nLayEnc) + ' Box ' + str(Box), flush=True )

        # --- extract focus from arrays (FabricFoc.py)
        FSEL     = f_FbrcFocXtr( FFLL, IXlin )

        # --- simple stats
        FKrnl     = f_FbrcKernel( FSEL )        
        
        # --------------------   Save Focus  --------------------
        if bSaveFocFll:
            sfn  = u_FocFileNameLily( Pths.DANNhst, ctg, b,
                                      FSEL.Dim.nLay, FixtFoc.fbcf )
            #sfn  = fcs.u_FocFileNameLi( Pths.DANNhst, ctg, b, FixtFoc.fbcf)

            SaveFbrcMTX( FSEL, sfn )

            # --------------------   Verify   --------------------
            # verifies loading routine for first 3 images
            if i<3:
                FSEL2    = LoadFbrcMTX( sfn )
                Df       = FSEL.AHYK[0] - FSEL2.AHYK[0]
                assert np.count_nonzero(Df)==0

        if bSaveFocSts:
            # different extension
            sfn = u_FocFileNameLily( Pths.DANNhst, ctg, b,
                                     FSEL.Dim.nLay, FixtFoc.fbfst)

            SaveFbrcKernel( FKrnl, sfn )

            # --------------------   Verify   --------------------
            if i<3:
                FKrnlL   = LoadFbrcKernel( sfn )
                Df       = FKrnl.MHyk[0] - FKrnlL.MHyk[0]
                assert np.count_nonzero(Df)==0
            

    
    if i%Jcoll.stepDisp==0:
        sb.Util.printDotProg()


print("fertig")
DispTermNext( 'focFabricAnn.py', 'smlFbrc.py' )
