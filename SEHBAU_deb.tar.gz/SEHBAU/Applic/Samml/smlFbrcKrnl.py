"""

Collecting fabric kernels (from annotations) for a LIST of categories for ONE
layer. Mock example.

PREVIOUS  focFabricAnn.py
PRESENT   smlFbrcKrnl.py
NEXT      training classifiers

"""
import sys, subprocess, glob
from pathlib import Path
from dataclasses import is_dataclass
import numpy as np

sys.path.insert(0, '../../../SEHBAU')
import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.LoadCollHist import LoadCollHist
from AdminPy.Sammlung.Samml import *
from AdminPy.DescUtil.BoundBox import *

# ------------------------------   Collection   ------------------------------
bas = 7 # OLTO
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

# ------------------------------   Selection   ------------------------------
nLaySus     = 4   # 1: smallest subspace height, 4: largest height
ixL         = nLaySus-1
bSave       = 0
bDisp       = 0

# ------------------------------   Paths   ------------------------------
Pths, Jcoll = u_CollPaths( bas )
Pths, Jcoll = u_CollPathAnn( Pths, Jcoll )

FixtFoc     = o_FileExtensFoc()
FixtSmlg    = o_FileExtensSmlg()

aLab        = ('Lab1', 'Lab2', 'Lab3')#, 'Lab4', 'Lab5', 'Lab6', 'Lab7')
nCtg        = len(aLab)

# ------------------------------   Declare   ------------------------------
# [ctg][lay][None]
AKHYK       = [[None for _ in range(nLaySus)] for _ in range(nCtg)]
AKBIS       = [[None for _ in range(nLaySus)] for _ in range(nCtg)]
AKKNT       = [[None for _ in range(nLaySus)] for _ in range(nCtg)]
ALbl        = [None for _ in range(nCtg)]

# --------------------------------------------------------------------------------
#                          L O O P   C A T E G O R I E S 
# --------------------------------------------------------------------------------
for c in range(nCtg):

    lab   = aLab[c]

    sb.Util.DispSec5( lab )
    
    # ------------------------------   Register   ------------------------------
    Rgst  = list( Pths.DANNhst.glob( lab + '*' + FixtFoc.fbfst ) )
    nIst  = len(Rgst)

    # ------------------------------   Stats   ------------------------------
    StFb  = u_SmlgFbrcStatsScout( Rgst )

    # ------------------------------   Sammeln   ------------------------------
    # collects all layers...
    SML, Kt = SML_FBRCkern( Rgst, StFb ) # Samml.py
    
    # ...therefore select the desired one
    AKHYK[c] = SML.AAMHyk[ixL]
    AKBIS[c] = SML.AAMBis[ixL]
    AKKNT[c] = SML.AAMKnt[ixL]
    ALbl[c]  = np.ones( Kt[ixL] )*c

    # display
    if bDisp:
        print()
        print('-----  Sammlungen  -----\nnIst ntBin nLaySus')
        for l in range(4):
            print(str(SML.AAMHyk[l].shape) + str("  -  ") +
                  str(SML.AAMBis[l].shape) + str("  -  ") +
                  str(SML.AAMKnt[l].shape) )
    else:
        print()
        
    # ------------------------------   Save   ------------------------------
    if bSave:
        sfn    = Pths.Smlg / lab
        sfn    = sfn.with_suffix( FixtSmlg.fbSts )

        SaveSmlgFBRCKRN( SML, StFb, StFb.Dim, sfn )
    
        #        SML2, DimFb = dscx.LoadSmlgFBRCKRN( sfn )

# ------------------------------   3D ARRAYS   ------------------------------
sb.Util.DispSec5( 'As 3D Arrays' )
MTXHYK      = np.concatenate( AKHYK, axis=0 )
MTXBIS      = np.concatenate( AKBIS, axis=0 )
MTXKNT      = np.concatenate( AKKNT, axis=0 )
LbCtg       = np.concatenate( ALbl, axis=0 )

print( 'nIst nFet nLaySus:' )
print( MTXHYK.shape )
print( MTXBIS.shape )
print( MTXKNT.shape )

# ------------------------------   MATRICES   ------------------------------
sb.Util.DispSec5( 'As Matrices' )
if nLaySus==1:
    nIst, ntBin    = MTXHYK.shape
    nIst, ntvBis   = MTXBIS.shape
    nIst, ntvKnt   = MTXKNT.shape
    # > directly suitable as training matrix
else:
    nIst, ntBin,  _ = MTXHYK.shape
    nIst, ntvBis, _ = MTXBIS.shape
    nIst, ntvKnt, _ = MTXKNT.shape
    
    # --- layers separately ---
    # preferred for matching
    lrg   = nLaySus-2
    une   = lrg
    print('--- layer-wise')
    for l in range(nLaySus):
        print(f"lay {l}: ", end="")
        print(MTXHYK[:,:,l].shape, end="  -  ")
        print(MTXBIS[:,:,l].shape, end="  -  ")
        print(MTXKNT[:,:,l].shape, end="  ")
        if lrg>0 and l<lrg:
            print('little expressive')
        else:
            print()
        
    # --- layers concatenated ---
    # for visualization
    # not appealing, as bottom layer for large fabrics (3|4) are not very distinct
    if 1:
        #print('--- as one block')
        MHYKblk = MTXHYK.reshape( nIst, ntBin *nLaySus )
        MBISblk = MTXBIS.reshape( nIst, ntvBis*nLaySus )
        MKNTblk = MTXKNT.reshape( nIst, ntvKnt*nLaySus )
        #print( MHYKblk.shape )
        #print( MBISblk.shape )
        #print( MKNTblk.shape )
    
# verify:    
nIst2       = len(LbCtg)
assert nIst==nIst2, 'nIst not same somehow'

# ------------------------------   Train   ------------------------------
# as pointed out, we will train only the top two layers (for nLaySus=3,4), the
# bottom two are little expressive
if nLaySus==1:
    # MTXHYK
elif nLaySus==2:
    # MTXHYK[:,:,0]
    # MTXHYK[:,:,1]
elif nLaySus==3:
    # MTXHYK[:,:,1]
    # MTXHYK[:,:,2]
elif nLaySus==4:
    # MTXHYK[:,:,2]
    # MTXHYK[:,:,3]

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
figNo = 1
hf = plt.figure(figNo)
hf.clf()
plt.subplot(4, 1, 1)
if nLaySus==1:
    plt.imshow(MTXHYK, aspect='auto')
else:
    plt.imshow(MHYKblk, aspect='auto')

plt.colorbar()
plt.show(block=False)

plt.subplot(4, 1, 2)
if nLaySus==1:
    plt.imshow(MTXBIS, aspect='auto')
else:
    plt.imshow(MBISblk, aspect='auto')
plt.colorbar()
plt.show(block=False)

plt.subplot(4, 1, 3)
if nLaySus==1:
    plt.imshow(MTXKNT, aspect='auto')
else:
    plt.imshow(MKNTblk, aspect='auto')
plt.colorbar()
plt.show(block=False)
