"""Collecting fabric kernels (from annotations) for a LIST of categories for a
ONE-LAYER subset. Mock example.

PREVIOUS  focFabricAnn.py
PRESENT   smlFbrcKrnl.py
NEXT      training classifiers

"""
import sys, subprocess, glob
from pathlib import Path
from dataclasses import is_dataclass
import numpy as np

sys.path.insert(0, '../../../SEHBAU')
import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.LoadCollHist import LoadCollHist
from AdminPy.Sammlung.Samml import *
from AdminPy.Util.UtilImg import *

# ------------------------------   Collection   ------------------------------
bas = 7 # OLTO
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

# ------------------------------   Selection   ------------------------------
nLaySus     = 4   # 1: smallest subspace height, 4: largest height
ixL         = nLaySus-1
bSave       = 0
bDisp       = 0

# ------------------------------   Paths   ------------------------------
Pths, Jcoll = u_CollPaths( bas )
Pths, Jcoll = u_CollPathAnn( Pths, Jcoll )

FixtFoc     = o_FileExtensFoc()
FixtRep     = o_FileExtensRep()

aLab        = ('Lab1', 'Lab2', 'Lab3')#, 'Lab4', 'Lab5', 'Lab6', 'Lab7')
nCtg        = len(aLab)

# ------------------------------   Declare   ------------------------------
#              [ctg][lay][None]
AKHYK       = [[None for _ in range(nLaySus)] for _ in range(nCtg)]
AKBIS       = [[None for _ in range(nLaySus)] for _ in range(nCtg)]
AKKNT       = [[None for _ in range(nLaySus)] for _ in range(nCtg)]
ALbl        = [None for _ in range(nCtg)]

# --------------------------------------------------------------------------------
#                          L O O P   C A T E G O R I E S 
# --------------------------------------------------------------------------------
for c in range(nCtg):

    lab   = aLab[c]

    sb.Util.DispSec5( lab )
    
    # ------------------------------   Register   ------------------------------
    # collect filenames for this category
    Rgst  = list( Pths.DANNhst.glob( lab + '*' + FixtFoc.fbfst ) )
    nIst  = len(Rgst)

    # ------------------------------   Stats   ------------------------------
    StFb  = u_SmlgFbrcStatsScout( Rgst )

    # ------------------------------   Sammeln   ------------------------------
    # collects all 4 layers...
    SML, Kt = SML_FBRCkern( Rgst, StFb ) # Samml.py
    
    # ...therefore select the desired one
    AKHYK[c] = SML.AAMHyk[ixL]
    AKBIS[c] = SML.AAMBis[ixL]
    AKKNT[c] = SML.AAMKnt[ixL]
    ALbl[c]  = np.ones( Kt[ixL] )*c

    # display
    if bDisp:
        print()
        print('-----  Sammlungen  -----\nnIst ntBin nLaySus')
        for l in range(4):
            print(str(SML.AAMHyk[l].shape) + str("  -  ") +
                  str(SML.AAMBis[l].shape) + str("  -  ") +
                  str(SML.AAMKnt[l].shape) )
    else:
        print()
        
    # ------------------------------   Save   ------------------------------
    if bSave:
        sfn    = Pths.Smlg / lab
        sfn    = sfn.with_suffix( FixtSmlg.fbKRN )

        SaveSmlgFBRCKRN( SML, StFb, StFb.Dim, sfn )
    
        #        SML2, DimFb = dscx.LoadSmlgFBRCKRN( sfn )

# ------------------------------   3D ARRAYS   ------------------------------
sb.Util.DispSec5( 'As 3D Arrays' )
MTXHYK      = np.concatenate( AKHYK, axis=0 )
MTXBIS      = np.concatenate( AKBIS, axis=0 )
MTXKNT      = np.concatenate( AKKNT, axis=0 )
LbCtg       = np.concatenate( ALbl, axis=0 )

nIst, ntBin, nLay = MTXHYK.shape
print( f'nIst for subspace height {nLaySus} is {nIst}' )

print( 'nIst nFet nLaySus:' )
print( MTXHYK.shape )
print( MTXBIS.shape )
print( MTXKNT.shape )
print( LbCtg.shape )

# ------------------------------   MATRICES   ------------------------------
sb.Util.DispSec5( 'As Matrices' )
if nLaySus==1:
    nIst, ntBin   = MTXHYK.shape
    nIst, ntBsv   = MTXBIS.shape
    nIst, nDscT   = MTXKNT.shape
    # > directly suitable as training matrix
else:
    nIst, ntBin, nLay = MTXHYK.shape
    nIst, ntBsv, nLay = MTXBIS.shape
    nIst, nDscT, nLay = MTXKNT.shape
    
    # --- layers separately ---
    # preferred for matching
    print('--- layer-wise')
    for l in range(nLaySus):
        print(f"lay {l}: ", end="")
        print(MTXHYK[:,:,l].shape, end="  -  ")
        print(MTXBIS[:,:,l].shape, end="  -  ")
        print(MTXKNT[:,:,l].shape)
        
    # --- layers concatenated ---
    # for visualization
    if 1:
        #print('--- as one block')
        MHYKblk = MTXHYK.reshape( nIst, ntBin*nLaySus )
        MBISblk = MTXBIS.reshape( nIst, ntBsv*nLaySus )
        MKNTblk = MTXKNT.reshape( nIst, nDscT*nLaySus )
        #print( MHYKblk.shape )
        #print( MBISblk.shape )
        #print( MKNTblk.shape )
    
# --- verify:    
nIst2       = len(LbCtg)
assert nIst==nIst2, 'nIst not same somehow'

# ------------------------------   Train   ------------------------------
# The 'granularity' of the individual training matrices
if nLaySus==1:
    MTXHYK                      # from bottom layer              
elif nLaySus==2:
    MTXHYK[:,:,0] # coarse        from bottom layer        
    MTXHYK[:,:,1] # coarsest
elif nLaySus==3:
    MTXHYK[:,:,0] # fine          from bottom layer
    MTXHYK[:,:,1] # coarse
    MTXHYK[:,:,2] # coarsest
elif nLaySus==4:
    MTXHYK[:,:,0] # finest        from bottom layer, probably not very expressive
    MTXHYK[:,:,1] # fine
    MTXHYK[:,:,2] # coarse
    MTXHYK[:,:,3] # coarsest      from top layer

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
figNo = 1
hf = plt.figure(figNo)
hf.clf()
plt.subplot(4, 1, 1)
if nLaySus==1:
    plt.imshow(MTXHYK, aspect='auto')
else:
    plt.imshow(MHYKblk, aspect='auto')

plt.colorbar()
plt.show(block=False)

plt.subplot(4, 1, 2)
if nLaySus==1:
    plt.imshow(MTXBIS, aspect='auto')
else:
    plt.imshow(MBISblk, aspect='auto')
plt.colorbar()
plt.show(block=False)

plt.subplot(4, 1, 3)
if nLaySus==1:
    plt.imshow(MTXKNT, aspect='auto')
else:
    plt.imshow(MKNTblk, aspect='auto')
plt.colorbar()
plt.show(block=False)

DispTermNext( 'smlFbrcKrnl.py', 'trnXXX.py ...' )
