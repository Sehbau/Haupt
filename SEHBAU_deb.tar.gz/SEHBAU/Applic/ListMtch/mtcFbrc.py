"""

Matching fabrics, 1 vs many. Testing script.

PREVIOUS  iclCollFbrcMaps.py, iclCollFbrcHyko.py
PRESENT   mtcFbrc.py
NEXT      

"""
import sys, subprocess
from pathlib import Path
from dataclasses import is_dataclass

sys.path.insert(0, '../../../SEHBAU')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.Collecting import *
from AdminPy.Collection.LoadCollHist import *
from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.Mtch.MtchFbrcImg import *


# ------------------------------   Collections   ------------------------------
bas = 7 # OLTO
#bas = 10; # IndOut15
#bas = 17; # SINR45
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 60;  # CAMSDD training
#bas = 61;  # CAMSDD validation
#bas = 62;  # CAMSDD testing
#bas = 50;   # indoor67
#bas = 100   # cifar10
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

PrmMtch     = prmMtchFbrcImg()
# modify if desired:
#                            contours                  forms
#                       vrt hor axi  nil  uni   vrt hor axi  nil  uni
PrmMtch.Wgt = np.array([ 1,  1, 0.5, 0.5, 0.5,   1,  1, 0.5, 0.5, 0.5])

# ------------------------------   Paths, Folds   ------------------------------
Pths, Jcoll = u_CollPaths( bas )
FixtImg     = o_FileExtensions()
FixtColl    = o_FileExtensColl()
FinaColl    = o_FileNameColl( Pths.hist, FixtColl )
Fips1       = o_FileStems( Pths, '', 'cab_fbrc' )

fipaExe     = sb.FipaExe['fbrc2arr']
pthOut      = Path("tmp/fbar")
fpDSC       = o_FinaApndExtDscx( pthOut, FixtImg )

# -----------------------------   Load   -----------------------------
#fSet        = 3 # finest layer
fSet        = 2 #  fine layer
bDispLoad   = 1 
FHYK, Nbin  = LoadCollFbrcHyko( FinaColl, fSet, bDispLoad )
FMBS, Heds  = LoadCollFbrcMaps( FinaColl )



# --------------------------------------------------------------------------------
#                               L O O P   I M A G E S
# --------------------------------------------------------------------------------
Ix0Img   = Jcoll.Ix0Img
nImg     = len(Ix0Img)

print(f"Running {bas}, nImg {nImg}", end="")
for i in range(0,nImg):

    ixi     = Ix0Img[i]

    pthFbrc = o_FileNameFrmt( Fips1.fbrc, ixi, '', Jcoll.finaFrmt )

    # ------------------------------   Init (on 1st image)   ------------------------------
    # scaling factors for focus selection
    if i==0:
        # obtain image size from fabric file
        fpFbrc      = pthFbrc + FixtImg.fbrc
        dmy, HedFbc = LoadFabric( fpFbrc )

        BinEdg      = i_BinEdgFromLoad( HedFbc.NbinAtt, HedFbc.NbinDty )
        szImg       = [HedFbc.Hed.szV, HedFbc.Hed.szH]

    # ------------------------------   fbrc2arr   ------------------------------
    cmnd = f"{fipaExe} {pthFbrc}{FixtImg.fbrc} {pthOut}"
    
    try:
        Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True, check=True)
        StdOut = Res.stdout
    except subprocess.CalledProcessError as e:
        print(f"Command execution failed: {e.stderr}")
        StdOut = e.stderr


    # ------------------------------   Load   ------------------------------
    bDispLoad  = i==0
    IFb        = LoadFbrcArrays( fpDSC, bDispLoad )
    

    # --------------------------------------------------------------------------------
    #                                 MATCH
    #
    # top-down
    PrmMtch.ixT = i    # for testing purposes
    Ord     = MTCHFBRCBIS( IFb, FMBS, PrmMtch )
    #Ord     = f_MtchFbrcHykLay( IFb.AHYK[fSet], FHYK, PrmMtch, BinEdg )


    # ------------------------------   Evaluate   ------------------------------
    LbCtg   = Jcoll.LabImg[Ord]
    Knt, Edg = np.histogram( LbCtg, bins=Jcoll.nCat )
    ixMx    = Knt.argmax()
    print( f"cat {LbCtg[ixMx]}" )
    
    
    if i%Jcoll.stepDisp==0:
        sb.Util.printDotProg()
        

print("fertig")
DispTermNext( 'mtcFbrc.py', 'evaluation' )

# -----------------------------   Plot   -----------------------------
if 1:
    sb.Util.p_Img( 1, FHYK, "Hyperkolumns" )

    sb.Util.p_Img( 4, FMBS.L3, "Bias Maps Layer 3" )



