"""

Clustering (word finding) per category. It loads the entire collection matrix and
cycles through the categories. For large databases probably not doable.

PREVIOUS  iclDscx.py, iclCollVect.py
CURRENT   clstVect.py
NEXT      training

"""
import sys
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

from sklearn.cluster import KMeans

sys.path.insert(0, 'c:/klab/ppc/SEHBAU')
sys.path.insert(0, 'c:/klab/py/UTIL')
import AdminPy as sb
from AdminPy import Collection as cl

# ------------------------------   Parameters   ------------------------------
nCls    = 30

# -----  Model  -----
# "auto" uses optimized K-Means++ initialization
f_Kmeans = KMeans(n_clusters=nCls, n_init="auto", random_state=42)

# ------------------------------   Paths, Folds   ------------------------------
Pths, Jcoll = cl.u_CollPaths( 7 )
FinasFld    = cl.u_CollFoldFina( Pths.fold, 5, 1)
JFld        = cl.LoadFoldIx( FinasFld )

# ------------------------------   Load   ------------------------------
adj=None; nSel=None
dtyL    = 'skl';   dtyA = 'Cnt'
#dtyL    = 'frm';   dtyA = 'Frm';  adj='red';  nSel=17
#dtyL    = 'frm';   dtyA = 'Frm'
#dtyL    = 'str';   dtyA = 'Str'
#dtyL     = 'arc';   dtyA = 'Arc'

COLC    = cl.LoadCollDty( Pths.coll, dtyL )

# ------------------------------   LEVEL SELECTION   ------------------------------
bSelLev = 0
if bSelLev:
    lvLow   = 0
    lvHih   = 1
    COLC.VEC, COLC.Lab    = cl.u_CollSelLev( COLC.VEC, COLC.Lab, lvLow,lvHih )
    COLC.Sts              = cl.sts_CollLab( COLC.Lab, 1 )
else:
    lvLow = 0
    lvHih = 5

nLevSel = lvHih-lvLow+1

# ------------------------------   ADJUST VEC   ------------------------------
COLC.VEC, COLC.POS, Jatt = cl.u_CollAdjAttPos( COLC.VEC, dtyL, adj, nSel )

# ------------------------------   REARRANGE TO LIST   ------------------------------
u_CollVecSel      = cl.u_CollMLtoLstSel
AVECTRN, ALabTrn  = u_CollVecSel( COLC.VEC, COLC.Lab, JFld.IxTrn )
APOSTRN, dmy      = u_CollVecSel( COLC.POS, COLC.Lab, JFld.IxTrn )

ntDscTrn          = np.sum( [ VEC.shape[0] for VEC in AVECTRN] )

# ------------------------------   Cycle Categories   ------------------------------

ct = 0
for c in range( Jcoll.nCat ):

    # --------------------   extract the category   --------------------

    IxCtg        = ( JFld.LbTrn==c ).nonzero()[0] # indices to AVECTRN

    VMX, Lab     = cl.u_CollCatLstToMx( AVECTRN, ALabTrn, IxCtg )

    nDsc         = VMX.shape[0]
    ct           = ct+nDsc

    print(f"---------   Cat {c:2d}  nDsc {nDsc:5d}   ---------")
    
    # --------------------   cluster   --------------------

    Lbs       = f_Kmeans.fit_predict(VMX)

    Cens      = f_Kmeans.cluster_centers_  # [nCls nAtt] centroids
    inertia   = f_Kmeans.inertia_          # sum of squared distances to closest centroid

    print(inertia)
    
    
assert ct==ntDscTrn, 'categories not properly extracted' 

