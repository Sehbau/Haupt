"""

Clustering (syllable/word finding) per category. It loads the entire collection matrix and
cycles through the categories. For large databases probably not doable.

Level selection occurs before cycling

PREVIOUS  iclDscx.py, iclCollVect.py
CURRENT   sylbFind.py
NEXT      sylbApply.py

"""
import sys
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, 'c:/klab/ppc/SEHBAU')
sys.path.insert(0, 'c:/klab/py/UTIL')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.IclFold import *
from AdminPy.Collection.LoadCollVec import *
from AdminPy.MtchVec.Syllables import *
from AdminPy.MtchVec.SyllabIO import *

# ------------------------------   Parameters   ------------------------------
Prm         = prmSylbFind
bSave       = 1

# ------------------------------   Paths, Folds   ------------------------------
bas         = 7
ixFold      = [1,5]
Pths, Jcoll = u_CollPaths( bas )
FinasFld    = u_CollFoldFina( Pths.fold, ixFold[1], ixFold[0])
JFld        = LoadFoldIx( FinasFld )
FixtRep     = o_FileExtensRep()

# ------------------------------   Load   ------------------------------
adj=None; nSel=None
dtyL    = 'skl';   dtyA = 'Cnt';   fctCls = 2.0;  bPosIncl=0;
#dtyL    = 'frm';   dtyA = 'Frm';  adj='red';  nSel=24;   fctCls=1.0
#---dtyL    = 'frm';   dtyA = 'Frm'
#dtyL    = 'str';   dtyA = 'Str';  fctCls = 2.0
#dtyL     = 'arc';   dtyA = 'Arc'

COLC    = LoadCollDty( Pths.coll, dtyL ) # LoadCollVec.py

# ------------------------------   LEVEL SELECTION   ------------------------------
bSelLev = 1
if bSelLev:
    lvLow = 1;  lvHih = 5;  levIdf  = '15'
    #lvLow = 2;  lvHih = 5;  levIdf  = '25'
    #lvLow = 3;  lvHih = 5;  levIdf  = '35'
    COLC.VEC, COLC.Lab    = u_CollSelLev( COLC.VEC, COLC.Lab, lvLow,lvHih )
    COLC.Sts              = sts_CollLab( COLC.Lab, 1 )
    
else:
    lvLow = 0
    lvHih = 5
    levIdf  = 'a'

nLevSel = lvHih-lvLow+1

# ------------------------------   ADJUST VEC   ------------------------------
# with or without position:
if bPosIncl==1:                
    COLC.VEC, Jatt           = u_CollAdjAtt(    COLC.VEC, dtyL, adj, nSel )
elif bPosIncl==0:        
    COLC.VEC, COLC.POS, Jatt = u_CollAdjAttPos( COLC.VEC, dtyL, adj, nSel )
else:
    raise Error('position aspect not specified')

# ------------------------------   REARRANGE TO LIST   ------------------------------
u_CollVecSel      = u_CollMLtoLstSel
AVECTRN, ALabTrn  = u_CollVecSel( COLC.VEC, COLC.Lab, JFld.IxTrn )
if bPosIncl==1:                
    APOSTRN, dmy  = u_CollVecSel( COLC.POS, COLC.Lab, JFld.IxTrn )

ntDscTrn          = np.sum( [ VEC.shape[0] for VEC in AVECTRN] )

# --------------------------------------------------------------------------------
#                               L O O P   C A T G S 
# --------------------------------------------------------------------------------
ctDsc = 0
ctCls = 0
for c in range( Jcoll.nCat ):

    # --------------------   extract the category   --------------------

    IxCtg        = ( JFld.LbTrn==c ).nonzero()[0] # indices to AVECTRN

    # concatenates AVECTRN[IxCtg[0]], AVECTRN[IxCtg[1]], ...
    VMX, Lab     = u_CollCatLstToMx( AVECTRN, ALabTrn, IxCtg )

    #breakpoint()
    nImg         = len(IxCtg)
    
    nDsc, nAtt   = VMX.shape
    avgnDsc      = round(nDsc / nImg)   # average number of descriptors for this catg
    
    ctDsc        = ctDsc+nDsc              # for verification

    # --------------------   cluster   --------------------
    print(f"---------   Cat {c:2d}  [{nDsc:5d} {nAtt:2d}]  (nImg {nImg})  ---------")
    Prm.nCls     = round( avgnDsc * fctCls )
    Prm.nImg     = nImg

    bDisp        = 2
    Sylb         = f_SylbFindVmx1( VMX, Prm, bDisp ) # MtchVec/Syllables.py

    ctCls       += Sylb.nClsDt

    print( f"nCls {Prm.nCls}:  inertia {Sylb.inertia:8.3f}" )

    if bSave:
        sfn = u_SylbCtg1Fina( Pths.sylb, c, levIdf, dtyL, FixtRep )

        SaveSylbCtg1( sfn, Sylb )
        Sylb2 = LoadSylbCtg1( sfn )


# --- verify        
assert ctDsc==ntDscTrn, 'categories not properly extracted somehow'

# ------------------------------   Zusf   ------------------------------
sb.Util.DispSec5('Zusf')
print( f'bas {bas}   pos {bPosIncl:d}   nAtt {nAtt}   levs {levIdf}   ', end='')
print( f'fold {ixFold[0]}/{ixFold[1]}' )

# ------------------------------   StatsColl   ------------------------------
sb.Util.DispSec5('Stats Coll')
avgnClsPerCatg = ctCls/Jcoll.nCat
print( f"ntCls {ctCls}   avgnClsPerCatg {avgnClsPerCatg:5.1f}" )

# ------------------------------   Trailer   ------------------------------
DispTermNext( 'sylbFind.py', 'sylbApply.py ...' )
