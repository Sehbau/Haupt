"""

Applying syllables. Data preparation must of course match that of sylbFind.py

PREVIOUS  sylbFind.py
CURRENT   sylbApply.py
NEXT      analysis

"""
import sys
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

from sklearn.neighbors import NearestNeighbors

sys.path.insert(0, 'c:/klab/ppc/SEHBAU')
sys.path.insert(0, 'c:/klab/py/UTIL')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.IclFold import *
from AdminPy.Collection.LoadCollVec import *
from AdminPy.MtchVec.Syllables import *
from AdminPy.MtchVec.SyllabIO import *

# ------------------------------   Parameters   ------------------------------
#Prm     = prmSylb
bSave       = 1

# ------------------------------   Paths, Folds   ------------------------------
bas         = 7
ixFold      = [1,5]
Pths, Jcoll = u_CollPaths( bas )
FinasFld    = u_CollFoldFina( Pths.fold, ixFold[1], ixFold[0])
JFld        = LoadFoldIx( FinasFld )
FixtRep     = o_FileExtensRep()

# ------------------------------   Load   ------------------------------
adj=None; nSel=None
dtyL    = 'skl';   dtyA = 'Cnt'; bPosIncl=0;
#dtyL    = 'frm';   dtyA = 'Frm';  adj='red';  nSel=24
#---dtyL    = 'frm';   dtyA = 'Frm'
#dtyL    = 'str';   dtyA = 'Str'
#dtyL     = 'arc';   dtyA = 'Arc'

COLC    = LoadCollDty( Pths.coll, dtyL )

# ------------------------------   LEVEL SELECTION   ------------------------------
bSelLev = 1
if bSelLev:
    lvLow = 1;  lvHih = 5;  levIdf  = '15'
    #lvLow = 2;  lvHih = 5;  levIdf  = '25'
    #lvLow = 3;  lvHih = 5;  levIdf  = '35'
    COLC.VEC, COLC.Lab    = u_CollSelLev( COLC.VEC, COLC.Lab, lvLow,lvHih )
    COLC.Sts              = sts_CollLab( COLC.Lab, 1 )
    levIdf  = '15'
else:
    lvLow = 0
    lvHih = 5
    levIdf  = 'a'

nLevSel = lvHih-lvLow+1

# ------------------------------   ADJUST VEC   ------------------------------
# with or without position:
if bPosIncl==1:                
    COLC.VEC, Jatt           = u_CollAdjAtt(    COLC.VEC, dtyL, adj, nSel )
elif bPosIncl==0:        
    COLC.VEC, COLC.POS, Jatt = u_CollAdjAttPos( COLC.VEC, dtyL, adj, nSel )
else:
    raise Error('position aspect not specified')

# ------------------------------   REARRANGE TO LIST   ------------------------------
u_CollVecSel      = u_CollMLtoLstSel
AVECPRD, ALabPrd  = u_CollVecSel( COLC.VEC, COLC.Lab, JFld.IxPrd )
if bPosIncl==1:                
    APOSPRD, dmy  = u_CollVecSel( COLC.POS, COLC.Lab, JFld.IxPrd )

# ------------------------------   Load Syllables   ------------------------------
print('LoadFit Syllables...', end='')
ASYLB             = CollSyllables( Pths.sylb, Jcoll.nCat, levIdf, dtyL )
print('done')

# ------------------------------   Fit Syllables   ------------------------------
ANEBS=[]
for c in range( Jcoll.nCat ):

    NEBS = NearestNeighbors( n_neighbors=1, algorithm='brute').fit(ASYLB[c].CEN)
    
    ANEBS.append(NEBS)


# --------------------------------------------------------------------------------
#                               L O O P   I M A G E S
# --------------------------------------------------------------------------------
nImg = JFld.nPrd
print( f"Looping {nImg} images...", end='')

DisNN1 = np.empty( (nImg, Jcoll.nCat), np.float32 )
DisFrq = np.empty( (nImg, Jcoll.nCat), np.float32 )
for i in range( nImg ):

    for c in range( Jcoll.nCat ):

        nCls        = ASYLB[c].nClsDt
        nDsc, nAtt  = AVECPRD[i].shape

        Dis, IxS    = ANEBS[c].kneighbors( AVECPRD[i] )

        DisNN1[i,c] = Dis.mean()

        #print(ASYLB[c].Frq)
        Frq         = np.bincount(IxS.ravel(), minlength=nCls) # frequency of cluster hits
        DfFrq       = ASYLB[c].Frq - Frq
        DisFrq[i,c] = np.sqrt( np.sum( np.square(DfFrq) ) )
        
    # --- progress dot
    if (i / Jcoll.stepDisp)==0: sb.Util.printDotProg()

print()
DispTermNext( 'sylbApply.py', 'analysis' )

# ------------------------------   Zusf   ------------------------------
sb.Util.DispSec5('Zusf')
print( f'bas {bas}   pos {bPosIncl:d}   nAtt {nAtt}   levs {levIdf}   ', end='')
print( f'fold {ixFold[0]}/{ixFold[1]}' )

# ------------------------------   Evaluation   ------------------------------
from AdminPy.Util.Eval import *

DisEns   = DisFrq * DisNN1

accNN    = u_AccFromPrdAct( DisNN1.argmin( axis=1 ), JFld.LbPrd )
accFq    = u_AccFromPrdAct( DisFrq.argmin( axis=1 ), JFld.LbPrd )
accEns   = u_AccFromPrdAct( DisEns.argmin( axis=1 ), JFld.LbPrd )

print( f"acc NN {accNN:1.4f}   Fq {accFq:1.4f}   Ens {accEns:1.4f}" )

# ------------------------------   Plot   ------------------------------
figNo = 1
import matplotlib.pyplot as plt

plt.figure(figNo)
plt.clf()
plt.imshow( DisNN1, aspect="auto")
plt.colorbar()
#plt.xticks( range(TxLb.nLab), TxLb.aSho)
#plt.title("First Image")

plt.show(block=False)

import time
time.sleep(1)
