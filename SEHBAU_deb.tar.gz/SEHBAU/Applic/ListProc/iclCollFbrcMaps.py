"""

Collecting fabric bias maps. For hykos and num maps see iclCollFbrcHyko.py

PREVIOUS  iclFabric.py
PRESENT   iclCollFbrcMaps.py, af iclCollHist.m
NEXT      

"""
import sys, subprocess
from pathlib import Path
from dataclasses import is_dataclass

sys.path.insert(0, '../../../SEHBAU')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.Collecting import *
from AdminPy.Collection.LoadCollHist import *
from AdminPy.Collection.Register import *


# ------------------------------   Collections   ------------------------------
bas = 7 # OLTO
#bas = 10; # IndOut15
#bas = 17; # SINR45
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 60;  # CAMSDD training
#bas = 61;  # CAMSDD validation
#bas = 62;  # CAMSDD testing
#bas = 50;   # indoor67
#bas = 100   # cifar10
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

# ------------------------------   Paths, Folds   ------------------------------
Pths, Jcoll = u_CollPaths( bas )
FixtImg     = o_FileExtensions()
FixtColl    = o_FileExtensColl()
FinaColl    = o_FileNameColl( Pths.hist, FixtColl )
Fips1       = o_FileStems( Pths, '', 'cab_fbrc' )

print(f"Collecting {bas},  {FinaColl.fbm1},  nImg {Jcoll.nImg}...", end="")

fpRgst      = Pths.dsci / 'RgstCollFbrc.txt'

bRgstOk     = o_RegistGenAndSave( Fips1.fbrc, Jcoll.Ix0Img, FixtImg.fbrc, fpRgst )

if bRgstOk==0:
    raise RegisterError('register file not complete - no collection occured')

# ------------------------------   Cmnd & Exec   ------------------------------
cmnd        = [ sb.FipaExe['collfbrc'], fpRgst, FinaColl.fbrcFs ]

Res         = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
OutColl     = Res.stdout + Res.stderr

print('done')

OutColl

# ------------------------------   Load   ------------------------------
FMBS, Heds  = LoadCollFbrcMaps( FinaColl )

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
import numpy as np

BNK1     = FMBS.L0
BnkMen   = np.mean(BNK1, axis=0)
BnkSum   = np.sum(BNK1, axis=0)

nImg, ntFet = BNK1.shape

htyp = '1'

plt.figure(1)
plt.suptitle(f"{Jcoll.name} {htyp}")

plt.subplot(2, 1, 1)
plt.plot(BnkSum)
plt.title('Sum')

plt.subplot(2, 1, 2)
plt.plot(BnkMen)
plt.title('Mean')

bSpat = False

# ----   Add Dividers   ----
if bSpat:
    y = np.max(BnkMen)
    
    # --- per cell
    # MATLAB: 1:NbinE.nCells -> Python range(1, nCells + 1)
    for c in range(1, NbinE.nCells + 1):
        x = NbinE.nBinPerCell * c
        # MATLAB: line([x x], [-2 y], 'color', [1 0 0]) -> Vertical line in Matplotlib
        plt.axvline(x=x, ymin=-2, ymax=y, color='red')
        
    # --- per desctype
    x = 0
    # MATLAB: 1:length(NbinE.NtPerTyp) -> Python loop directly over the elements
    for val in NbinE.NtPerTyp:
        x += val
        plt.axvline(x=x, ymin=-2, ymax=y, color='green')

# Display the plot window
plt.tight_layout() # Ensures subplots don't overlap labels
plt.show(block=False)


plt.figure(4)

plt.subplot(4, 1, 1)
plt.imshow(FMBS.L0, aspect='auto')
plt.colorbar()
plt.title(f"{Jcoll.name} 0 ")

plt.subplot(4, 1, 2)
plt.imshow(FMBS.L1, aspect='auto')
plt.colorbar()
plt.ylabel(' 1 ')

# MATLAB: subplot(4,1,3); imagesc( FMBS.L2 ); colorbar(); ylabel( ' 2 ');
plt.subplot(4, 1, 3)
plt.imshow(FMBS.L2, aspect='auto')
plt.colorbar()
plt.ylabel(' 2 ')

# MATLAB: subplot(4,1,4); imagesc( FMBS.L3 ); colorbar(); ylabel( ' 3 ');
plt.subplot(4, 1, 4)
plt.imshow(FMBS.L3, aspect='auto')
plt.colorbar()
plt.ylabel(' 3 ')

# Optimizes subplot spacing so labels and colorbars don't overlap
plt.tight_layout()
plt.show(block=False)

DispTermNext( 'iclCollFbrcMaps.py', 'match/classify' )

