"""
 Runs program 'dscx' for a collection. 
 For collecting stats see iclSalcAly.m

 sa exsbDscSimp.m

 PREVIOUS  -
 PRESENT   iclDscx.py
 NEXT      iclCollVect.py, iclCollKolm, 
           iclDbnToVmx, iclMvec.m, iclSalcAly.m ,iclCat... runFocNyu.m
"""
import sys
from pathlib import Path
from dataclasses import is_dataclass

sys.path.insert(0, '../../../SEHBAU')
sys.path.insert(0, '../../../../py/UTIL') # for loading CIF images

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn, cmndArgs
from AdminPy.Collection.IclAdmin import *


# ------------------------------   Collection   ------------------------------
bas = 7 # OLTO
#bas = 10; # IndOut15
#bas = 17; # SINR45
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 60;  # CAMSDD training
#bas = 61;  # CAMSDD validation
#bas = 62;  # CAMSDD testing
#bas = 50;   # indoor67
#bas = 100   # cifar10
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

# ------------------------------   Admin & Options   ------------------------------
bSaveDesc       = 0    # =0 means will write to '.\ztst'
Args            = o_CmndArgs('dscx')
#Args.fpPrm      = f"Params/Colls/PrmDesc_{Coll.name}.txt"
OptK            = argsDscx
#Args            = sb.Util.argsCmndRenn          # CmndSupp.py
#Args.optS  = '--depth 2'
if 1:
    OptK.saveRRE    = 1 
    OptK.saveCVP    = 1 
    OptK.saveRegUnv = 1 # region universe. for readatreg
    #OptK.saveKol    = 0
    OptK.saveProp   = 1
    #OptK.imgFlt     = 2
    #OptK.depth      = 2

#OptK.nLev   = 3 ;

Args.opt        = i_DscxArgs(OptK)
#sb.Util.v_CmndArgs( Args )

# ------------------------------   Paths   ------------------------------
Pths, Jcoll  = u_CollPaths( bas )

FixtImg     = o_FileExtensions()
Fina1       = o_FileStems( Pths )
FixtColl    = o_FileExtensColl()
FinaColl    = o_FileNameColl( Pths.hist, FixtColl )

pthExe      = sb.PthProg['descExtr']

IxCollReg   = [ 7, 10, 17, 50, 60, 61, 62 ]

## -----------------   Delete Previous Files   -----------------
IxCollDel = [7, 10, 17, 37, 50, *range(60, 63), 100, 200]

if bas in IxCollDel:
    if bSaveDesc > 0:
        cl.u_DescDel( Pths.dsci )


# --------------------------------------------------------------------------------
#                               L O O P   I M A G E S
# --------------------------------------------------------------------------------
# There exists IclProc.DSCX(), but due to some of the exceptions we write here an
# explicit loop.

# Selection:
#IxImg   = 1:nImgTren;
#IxImg   = 1936:2000; # nImgTren;
Ix0Img   = Jcoll.Ix0Img;
nImg     = len(Ix0Img);
#nImg     = 0

if nImg:
    print(f"Running {bas}, nImg {nImg}", end="")

fipaImg  = None
for i in range(0,nImg):

    ix      = Ix0Img[i]

    # --------------------   regular case   --------------------
    if bas in IxCollReg:
        fipaImg = Pths.imgs / Jcoll.aFinas[ix]

    if bSaveDesc:
        fipsOut = Fina1.dsci + str(ix)
    else:
        fipsOut = 'tmp\ztst'

    # --------------------   exceptions   --------------------
    # we may overwrite some of the previous settings
    if bas==100:
        fipaImg = Pths.imgs / Path( 'I_' + str(ix) + '.png' );

    # verify that something was specified
    if fipaImg==None:
        print("You havent specified an image")
        breakpoint()

    # --------------------   EXECUTE   --------------------
    StdOut  = RennDscx( fipaImg, fipsOut, Args, pthExe )
        
    # sb.Util.v_CmndExec( Res )

    if i%Jcoll.stepDisp==0:
        sb.Util.printDotProg()

print()
DispTermNext( 'iclDscx.py', 'iclCollVect.py, iclCollHist.py, iclDbin.py ...' )


