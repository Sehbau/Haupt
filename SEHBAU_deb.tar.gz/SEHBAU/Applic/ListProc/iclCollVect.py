#
# Collects vectors for different desctypes (for a list of images). 
#
# PREVIOUS  iclDscx.py
# PRESENT   iclCollVect.py
# NEXT      classification, clustering, etc.
#
import sys, glob
from pathlib import Path
from dataclasses import is_dataclass

sys.path.insert(0, '../../../SEHBAU')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.LoadCollVec import *
from AdminPy.Collection.Register import *
from AdminPy.DescExtr.DescType.OrgDescTyp import o_DescTypes

# ------------------------------   Collection   ------------------------------
bas         = 7 
#bas         = 10 ;
#bas         = 60 ;
#bas         = 62 ;
#bas         = 100 ;

aDty, nDty  = o_DescTypes('cfasst');  nDty=5

# ------------------------------   Paths   ------------------------------
Pths, Jcoll  = u_CollPaths( bas )

dirDsc      = Pths.dsci
fpColl      = Pths.coll

# -------   The List of Files   -------
aDscNa2     = glob.glob(f"{dirDsc}/*.dsc")
aDscNa      = o_FileNameFrmtLst( 'DSC_i', Jcoll.Ix0Img, '.dsc', 0 )
#breakpoint()

finaLst     = fpColl / "FinasDsc.txt"
SaveFipaLstPrependPath( aDscNa, dirDsc, finaLst )

# -------   The Program   -------
fpProg      = sb.FipaExe['collvec']

## -----------------------    LOOP DESCTYPES   -----------------------
for d in range(nDty):
    
    dscTyp      = aDty[d]
    dty         = dscTyp.lower()
    sb.Util.DispSec( dty, '-', 0 )
    
    ## -------   Execute Command   --------
    cmnd        = f"{fpProg} {finaLst} {dty} {str(Pths.coll)}/"

    Res         = sb.Util.f_CmndExecRes( cmnd )

    sb.Util.v_CmndExec( Res )

    ## -------   Load Output   --------
    # we load for verification (to ensure the file was properly generated)
    COLLVEC, ntDsc, nAtt  = LoadCollVec( fpColl, dty )
    COLLLab, ntDscL       = LoadCollVecLab( fpColl, dty )

    if ntDsc!=ntDscL:
        print('WWWWARNING: ntDsc not same %d <> %d. Perhaps NaN present', ntDsc, ntDscL )
        # see exsbD2vmx how to proceed.

    # also verification
    #IxCatColl = sb.u_CollImgIxToCatIx( COLLLab[:,1], Jcoll.LabImg )
    

DispTermNext( 'iclCollVect.py', 'classification, clustering, ...' )


