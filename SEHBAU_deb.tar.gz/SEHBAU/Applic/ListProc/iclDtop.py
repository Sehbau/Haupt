#
# Runs program 'topx' for a collection. 
#
# PREVIOUS  iclDscx.py
# PRESENT   iclDtop.py
# NEXT      matching
#
import sys, os
from pathlib import Path
from dataclasses import is_dataclass

sys.path.insert(0, '../../../SEHBAU')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.IclProc import TOPX


# ------------------------------   Collection   ------------------------------
bas = 7 # OLTO
#bas = 10; # IndOut15
#bas = 17; # SINR45
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 60;  # CAMSDD training
#bas = 61;  # CAMSDD validation
#bas = 62;  # CAMSDD testing
#bas = 50;   # indoor67
#bas = 100   # cifar10
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

# ------------------------------   Admin & Options   ------------------------------
bSaveDesc    = 0    # =0 means will write to '.\ztst'
#Args         = sb.Util.o_CmndArgs('topx')
#Args.fpPrm   = fpPrm
#Args.opt     = '--nobin'          # voll, flat, spatial
#sb.Util.v_CmndArgs( Args ) does not exist
#argStr       = fpPrm + " " + Args.opt

# ------------------------------   Paths   ------------------------------
Pths, Jcoll  = u_CollPaths( bas )

FixtImg      = o_FileExtensions()
Fips1        = o_FileStems( Pths )
FixtColl     = o_FileExtensColl()
FinaColl     = o_FileNameColl( Pths.hist, FixtColl )
pthExe       = sb.FipaExe['topx']

## -----------------   Delete Previous Files   -----------------
IxCollDel    = [7, 10, 17, 37, 50, *range(60, 63), 100, 200]
if 0: #bas in IxCollDel:
    if bSaveDesc > 0:
        u_DescDel( Pths.dsci )


print(f"Ready to run with {Fips1.dtop} as file identifier. ", end='')
input("Press Enter to continue...")


# ------------------------------   LOOP IMAGES   ------------------------------
# Selection:
#IxImg   = 1:nImgTren;
#IxImg   = 1936:2000; # nImgTren;
Ix0Img   = Jcoll.Ix0Img;

os.chdir( sb.PthProg['descUtil'] )

TOPX( pthExe, Ix0Img, Fips1, FixtImg, 0 )

DispTermNext( 'iclDtop.py', 'matching' )


