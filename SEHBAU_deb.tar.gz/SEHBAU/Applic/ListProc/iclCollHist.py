"""

Collecting histograms.

"""
import sys
from pathlib import Path
from dataclasses import is_dataclass

sys.path.insert(0, '../../../SEHBAU')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.LoadCollHist import LoadCollHist
from AdminPy.Collection.Register import *

# ------------------------------   Collection   ------------------------------
bas = 7 # OLTO
#bas = 10; # IndOut15
#bas = 17; # SINR45
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 60;  # CAMSDD training
#bas = 61;  # CAMSDD validation
#bas = 62;  # CAMSDD testing
#bas = 50;   # indoor67
#bas = 100   # cifar10
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

# ------------------------------   Paths   ------------------------------
Pths, Jcoll = u_CollPaths( bas )

FixtImg     = o_FileExtensions()
Fina1       = o_FileStems( Pths )
FixtColl    = o_FileExtensColl()
FinaColl    = o_FileNameColl( Pths.hist, FixtColl )

# ------------------------------   Prep Register   ------------------------------
fpRgst  = 'CollHist.txt'

bRgstOk = o_RegistGenAndSave( Fina1.dsci, Jcoll.Ix0Img, FixtImg.hsti, fpRgst )

if not bRgstOk:
    raise "register file not properly setup"

# ------------------------------   COLL HIST   ------------------------------
print('\n-------------------   Collecting   ---------------------\n')

fpExe   = sb.FipaExe['collhimg']

cmnd    = f'"{fpExe}" "{fpRgst}" "{FinaColl.histFs}"'

Out     = sb.Util.f_CmndExec( cmnd )
#sb.Util.v_CmndExec( Res )
#fprintf('done\n');


# ------------------------------   Load   ------------------------------
# for verification
HESS, Nbin   = LoadCollHist( FinaColl.histi )

ntBin   = sum(Nbin.Tot)

print(f'ntBin {ntBin}')


# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
import numpy as np

HstMen   = np.mean(HESS, axis=0)
HstSum   = np.sum(HESS, axis=0)

plt.figure(1)

plt.subplot(2, 1, 1)
plt.plot(HstSum)
plt.title("Sum")

plt.subplot(2, 1, 2)
plt.plot(HstMen)
plt.title("Mean")

# 3. Adjust spacing and display the plot
plt.tight_layout()
plt.draw()
plt.pause(0.001)  # Brief pause to let the GUI window render


DispTermNext( 'iclCollHist.py', 'classification...' )
