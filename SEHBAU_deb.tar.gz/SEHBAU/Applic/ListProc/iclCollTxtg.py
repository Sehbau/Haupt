"""

Collecting texturegrams with executable 'collsalc'.

For collecting texture (blob) bounding boxes use iclCollTxtBbx.py

Afro plcCollTxtg.py
"""

import sys, subprocess
from pathlib import Path
import numpy as np

sys.path.insert(0, '../../../SEHBAU')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.Collecting import *
import AdminPy.DescExtr.Texture.Texture as tx
from AdminPy.DescExtr.Saliency import LoadDescSalc
from AdminPy.Collection.Register import *
from AdminPy.Collection.LoadCollTxtr import *


# ------------------------------   Collection   ------------------------------
bas = 7 # OLTO

# ------------------------------   Paths   ------------------------------
Pths, Jcoll = u_CollPaths( bas )

FixtImg     = o_FileExtensions()   
RgstFinas   = o_RegistFileNames();
RgstFipas   = o_DirsPrependPath( RgstFinas, Pths.regist )

# create register
o_RegistSetSave( RgstFipas, Pths.dsci, "DSC_i", Jcoll.Ix0Img, FixtImg, Jcoll.finaFrmt)
# ensure all files are present
v_RegistValid( RgstFipas.slc )

FixtColl    = o_FileExtensColl();
FinaColl    = o_FileNameColl( Pths.coll, FixtColl )

# ------------------------------   Collect   ------------------------------
cmnd        = [ sb.FipaExe['collsalc'], RgstFipas.slc, FinaColl.salcFs ]

Res         = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
OutColl     = Res.stdout + Res.stderr

# ------------------------------   Load   ------------------------------
TXTR, Hed   = LoadCollTxtg( FinaColl )

# stats
StsColl     = f_CollTxtrStats( TXTR )

# ------------------------------   Reshape Output   ------------------------------
# reshaping is necessary for learning with a transformer that requires sequence x
# dimensions, in our case grid units x texture biases.

# --- for one image
Txgg        = TXTR.GRD[0,:]                     # take first image
szGrd       = [5,5]
nTxtBis     = 7
MxTxg       = tx.u_TxtrGramGridArrToMtrx( Txgg, szGrd, nTxtBis )
# now we normalize
nrm         = 40
MxNrm       = tx.u_TxtrGramGridArrToMtrx( Txgg, szGrd, nTxtBis, nrm )

# --- for the collection
GNRM        = u_TxtrGramGridCollReshape( TXTR.GRD, szGrd, nTxtBis, nrm )

# ------------------------------   Load 1st SalcFile   ------------------------------
# for comparison and verification
aFpSlc,nLin = sb.Util.LoadTextLinewise( RgstFipas.slc )
fp1st       = aFpSlc[0]                         # takes first file
SLC, Hed    = LoadDescSalc( fp1st )
Grid1Img    = SLC.Txa.Grm.Grid                  # contains array and size
GridMx      = Grid1Img[0]                       # take array

Df1         = GridMx.flatten() - MxTxg.flatten()
assert Df1.max()==0, 'values not matching somehow'

# normalize it
GridMx[:,0] = GridMx[:,0] / nrm     # now ready for feeding to a (learned) transformer

# verify more
Df2         = GNRM[0,:]       - GridMx.flatten()
Df3         = MxNrm.flatten() - GridMx.flatten()
assert Df2.max()==0, 'values not matching somehow'
assert Df3.max()==0, 'values not matching somehow'


# ------------------------------   Plot   ------------------------------
figNo = 4;
PlotCollTxtrStats( StsColl, figNo )

# --- two more figures displaying the matrices
import matplotlib.pyplot as plt

TxLb = o_TxtrLabels()

# Figure 6
plt.figure(6)
plt.clf()
plt.imshow(MxNrm, aspect="auto")
plt.colorbar()
plt.xticks( range(TxLb.nLab), TxLb.aSho)
plt.title("First Image")

# Figure 7
plt.figure(7)
plt.clf()
plt.imshow(GNRM, aspect="auto")
plt.colorbar()
plt.ylabel("All Images")
plt.xlabel("Grid Units")

plt.show(block=False)

import time
time.sleep(1)





