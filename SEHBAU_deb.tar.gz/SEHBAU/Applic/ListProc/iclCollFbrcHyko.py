"""

Collecting fabric hyperkolumns and num maps. For bias maps see iclCollFbrcMaps.py

Requires a directory called 'tmp' for the temporary array files.

PREVIOUS  iclFabric.py
PRESENT   iclCollFbrcHyko.py
NEXT      classification, objsearch      

"""
import sys, subprocess
from pathlib import Path
from dataclasses import is_dataclass

sys.path.insert(0, '../../../SEHBAU')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.Collecting import *
from AdminPy.Collection.LoadCollHist import *

# --------------------   Collection   --------------------
bas = 7 # OLTO
#bas = 10; # IndOut15
#bas = 17; # SINR45
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 60;  # CAMSDD training
#bas = 61;  # CAMSDD validation
#bas = 62;  # CAMSDD testing
#bas = 50;   # indoor67
#bas = 100   # cifar10
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

# -----------------   Paths   ---------------
Pths, Jcoll = u_CollPaths( bas )
FixtImg     = o_FileExtensions()
FixtColl    = o_FileExtensColl()
FinaColl    = o_FileNameColl( Pths.hist, FixtColl )
Fips1       = o_FileStems( Pths, '', 'cab_fbrc' )

print(f"Collecting {bas},  {FinaColl.fbm1},  nImg {Jcoll.nImg}...", end="")

## -----------------------------   COLLECT   -----------------------------
if 0:
    ICL_COLLFBRCHYKO( sb.FipaExe['fbrc2arr'], Jcoll.Ix0Img, Fips1,
                         FixtImg, Jcoll.finaFrmt, FinaColl )
if 1:
    ICL_COLLFBRCMNUM( sb.FipaExe['fbrc2arr'], Jcoll.Ix0Img, Fips1,
                         FixtImg, Jcoll.finaFrmt, FinaColl )

# --------------   Load   -------------------
fSet        = 3 # takes the smallest layer
bDispLoad   = 1 
FBRC, Nbin  = LoadCollFbrcHyko( FinaColl, fSet, bDispLoad )

FMPN0, Dim0 = LoadCollFbrcMnum( FinaColl, 0, bDispLoad )
FMPN1, Dim1 = LoadCollFbrcMnum( FinaColl, 1, bDispLoad )

## -----------------------------   Plot   -----------------------------
import matplotlib.pyplot as plt
if 1:
    plt.figure(1)

    plt.imshow(FBRC, aspect='auto')
    plt.title("Hyperkolumns")

    plt.draw()
    plt.pause(0.001)  # Brief pause to let the GUI window render


    plt.figure(2)

    plt.imshow(FMPN0, aspect='auto')
    plt.title("Num Maps Layer 0")

    plt.draw()
    plt.pause(0.001)  # Brief pause to let the GUI window render

    plt.figure(3)

    plt.imshow(FMPN1, aspect='auto')
    plt.title("Num Maps Layer 1")

    plt.draw()
    plt.pause(0.001)  # Brief pause to let the GUI window render

#DispTermNext( mfilename, 'cfHstEss.m');

