"""
Runs program 'fabric' for a collection. 

PREVIOUS  iclDbin.py
PRESENT   iclFabric.py
NEXT      focFbrcAnn.py
"""
import sys, os
from pathlib import Path
from dataclasses import is_dataclass

sys.path.insert(0, '../../../SEHBAU')

import AdminPy as sb
from   AdminPy.Orga.OrgFileNames import *
from   AdminPy.Collection.IclAdmin import *
from   AdminPy.Collection.IclProc import FABRIC


# ------------------------------   Collection   ------------------------------
bas = 7 # OLTO
#bas = 10; # IndOut15
#bas = 17; # SINR45
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 60;  # CAMSDD training
#bas = 61;  # CAMSDD validation
#bas = 62;  # CAMSDD testing
#bas = 50;   # indoor67
#bas = 100   # cifar10
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 
    
# ------------------------------   Admin & Options   ------------------------------
bSaveDesc    = 0    # =0 means will write to '.\ztst'


# ------------------------------   Paths   ------------------------------
Pths, Jcoll  = u_CollPaths( bas )
FixtImg      = o_FileExtensions()
Fips1        = o_FileStems( Pths, '', 'cab_fbrc' )

pthExe       = sb.FipaExe['fabric']


## -----------------   Delete Previous Files   -----------------
IxCollDel    = [7, 10, 17, 37, 50, *range(60, 63), 100, 200]

if 0: #bas in IxCollDel:
    if bSaveDesc > 0:
        u_DescDel( Pths.dsci )


print(f"Ready to run with {Fips1.fbrc} as file identifier. ", end='')
input("Press Enter to continue...")
    
# ------------------------------   LOOP IMAGES   ------------------------------
# Selection:
#IxImg   = 1:nImgTren;
#IxImg   = 1936:2000; # nImgTren;
Ix0Img   = Jcoll.Ix0Img

os.chdir( sb.PthProg['descUtil'] )

FABRIC( pthExe, Ix0Img, Fips1, FixtImg, 0 )

DispTermNext( 'iclFabric.py', 'ie. focFbrcAnn.py' )


