"""

Collecting texture bounding boxes. Output not tested yet.

For texturegrams see iclCollTxtg.py

sa exsbSalBlobs.py

"""

import sys, subprocess
from pathlib import Path
import numpy as np

sys.path.insert(0, '../../../SEHBAU')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.Collecting import *
import AdminPy.DescExtr.Texture as tx
from AdminPy.DescExtr.Saliency import LoadDescSalc


# ------------------------------   Collection   ------------------------------
bas = 7 # OLTO

# ------------------------------   Paths   ------------------------------
Pths, Jcoll = u_CollPaths( bas )

FixtImg     = o_FileExtensions()
Fips1       = o_FileStems( Pths )
FixtColl    = o_FileExtensColl()
FinaColl    = o_FileNameColl( Pths.hist, FixtColl )


# --------------------------------------------------------------------------------
#                               L O O P   I M A G E S
# --------------------------------------------------------------------------------
Ix0Img   = Jcoll.Ix0Img;
nImg     = len(Ix0Img);

if nImg:
    print(f"Running {bas}, nImg {nImg}", end="")

ABBBX=[]
ABtyp=[]
for i in range(0,nImg):

    ixi     = Ix0Img[i]

    pthSlc  = o_FileNameFrmt( Fips1.dsci, ixi, FixtImg.salc, Jcoll.finaFrmt )

    SLC, Hed = LoadDescSalc( pthSlc )    

    # ---------------   Retrieve   ---------------
    Bbxs    = SLC.Blb.Box         # blobs
    Bbx     = Bbxs.Box
    Typ     = Bbxs.Typ
    nBox    = Bbx.shape[0]
    
    print( f"i {i:2d}: {nBox:3d} boxes" )

    # ---------------   Normalize   ---------------
    Topf    = Bbx[:,0] / Hed.szM[0]
    Botf    = Bbx[:,1] / Hed.szM[0]
    Leff    = Bbx[:,2] / Hed.szM[1]
    Ritf    = Bbx[:,3] / Hed.szM[1]

    BbxN    = np.column_stack( (Topf, Botf, Leff, Ritf) )
    
    # ---------------   Append   ---------------
    if nBox > 0:
        ABBBX.append(BbxN)
        ABtyp.append(Typ)
    else:
        ABBBX.append(None) 
        ABtyp.append(None) 

    # -----  progress dots
    if (i + 1) % Jcoll.stepDisp == 0:
        print('.', end='', flush=True)


# ------------------------------   Save   ------------------------------
sfp = FinaColl.txbx

if 0:
    with open( sfp, "wb") as f:
        
        # ----------   Header   ----------
        f.write(struct.pack("i", len(ABBBX)))

        # ----------   Data   ----------
        for i in range(len(ABBBX)):

            BBx = ABBBX[i]
            Typ = ABtyp[i]
            
            if BBx is None or BBx.shape[0] == 0:
                # Write 0 BBx for this image
                f.write(struct.pack("i", 0))
            else:
                nBox = BBx.shape[0]
                f.write(struct.pack("i", nBox)) # How many items to read next
            
                # Ensure data types match expected C/C++ equivalents (e.g., float and int)
                f.write(BBx.astype(np.float32).tobytes())
                f.write(Typ.astype(np.int32).tobytes())


# ------------------------------   Load   ------------------------------
# see LoadCollTxtrBbxs in LoadCollTxtr.py                
