"""

Collecting histograms.

"""
import sys, subprocess, os, glob
from pathlib import Path
sys.path.insert(0, '..')
import numpy as np

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.Orga.SaveFipaLst import SaveFipaLstPrependPath
from AdminPy.Collection.LoadCollHist import LoadCollHist


# ------------------------------   DescExtr   ------------------------------
os.chdir( sb.PthProg['descExtr'] )

Args       = argsCmndRenn()            # CmndSupp.py
  
#Args       = sb.o_CmndArgs( 'dscx' )

StdOut1    = RennDscx( 'Imgs/img1.jpg', '../MtchHst/Desc/img1', Args )
StdOut2    = RennDscx( 'Imgs/img2.jpg', '../MtchHst/Desc/img2', Args )

# ------------------------------   Collecting   ------------------------------
os.chdir( sb.PthProg['mtchHst'] )


aImgNaRep  = glob.glob("Desc/*.hst")    # representation/reference image
finaLst    = 'Regist/FinasHst.txt';
SaveFipaLstPrependPath( aImgNaRep, '', finaLst )

fipsColl   = 'Desc/COLLHST';

# -----  build, execute, verify command  -----
cmnd       = f"{sb.FipaExe['collhimg']} {finaLst} {fipsColl}"

Res        = subprocess.run( cmnd, shell=True, capture_output=True, text=True)

v_CmndExec( Res )

# ----------   Load Collection   ----------
Fixt       = o_FileExtensColl()

HSTC, NbinC = LoadCollHist( fipsColl + Fixt.hsall )


# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt

print(f"ntBin       {np.sum(NbinC.Tot):5d}")
print(f"nBinFltUni  {NbinC.Tot[0]:5d}")
print(f"nBinFltBiv  {NbinC.Tot[1]:5d}")
print(f"nBinSpaUni  {NbinC.Tot[2]:5d}")
print(f"nBinSpaBiv  {NbinC.Tot[3]:5d}")


# ----- Figure 1 -----
plt.figure(1)
plt.imshow(HSTC, aspect="auto")
plt.colorbar()


# ----- Figure 2 -----
plt.figure(2)
x = np.arange(len(NbinC.Tot))
plt.bar(x, NbinC.Tot)

plt.xticks(x, ["FltUni", "FltBiv", "SpaUni", "SpaBiv"])
plt.title("Num Bins")

plt.show( block=False )

import time
time.sleep(0.2)
