% 
% Runs program binaries mhstL and mkolL (1-versus-List) for the images of
% the place recognition set. Thus, ensure that there are descriptor by
% running first demo script plcDscx.m.
%
% This script is to be run from directory 'MtchHst'
%
clear;
run('../globalsSB');

%% ----------   Prepare Input Args   --------
progMhst    = 'mhstL';
progMkol    = 'mkolL';

dirPlcRec   = '../DemoPlcRec/Desc/';

pthHstTst   = [dirPlcRec '0000000.hst'];    % testing image 
pthKolTst   = [dirPlcRec '0000000.kol'];    % testing image 

aHstRep     = dir([ dirPlcRec '*.hst']);    % representation/reference image
aKolRep     = dir([ dirPlcRec '*.kol']);    % representation/reference image

finaRgstHst = 'Regist/FinasHst.txt';
finaRgstKol = 'Regist/FinasKol.txt';

SaveFipaLstPrependPath( aHstRep, dirPlcRec, finaRgstHst );
SaveFipaLstPrependPath( aKolRep, dirPlcRec, finaRgstKol );

finaMesHst  = 'Mes/HstLst.txt';
finaMesHuor = 'Mes/HstUor.txt';             % cannot be changed
finaMesKol  = 'Mes/KolLst.txt';
finaMesKuor = 'Mes/KolUor.txt';             % cannot be changed

%% =========   Command Mhst  ========
cmndHst      = [progMhst ' ' pthHstTst ' ' finaRgstHst ' ' finaMesHst];
[Sts OutHst] = dos( cmndHst );

cmndKol      = [progMkol ' ' pthKolTst ' ' finaRgstKol ' ' finaMesKol];
[Sts OutKol] = dos( cmndKol );

%% -------   Load Matching Results   -------
nRep         = length(aHstRep);

[OrdHis DisHisOrd] = LoadSortFltTxt( finaMesHst, nRep );
[OrdKol DisKolOrd] = LoadSortFltTxt( finaMesKol, nRep );

DisHisUor    = LoadFltTxt( finaMesHuor, nRep );
DisKolUor    = LoadFltTxt( finaMesKuor, nRep );

%% -------   Plot   -------
figure(1); clf;

subplot(2,1,1);
bar( DisHisUor );
ylabel('Distances');
title('Histogram Differences');

subplot(2,1,2);
bar( DisKolUor );
ylabel('Distances');
title('Kolumn Differences');






