% 
% Runs program collhimg, to collect and concatenate histograms to a single
% matrix [nImg nBin].
%
% script to be run from directory 'MtchHst'
%
clear;
run('../AdminMb/globalsSB');

cd( PthProg.descExtr );
Args    = o_CmndArgs( 'dscx' );

RennDscx( 'Imgs/img1.jpg', '../MtchHst/Desc/img1', Args );
RennDscx( 'Imgs/img2.jpg', '../MtchHst/Desc/img2', Args );

cd( PthProg.mtchHst );

aImgNaRep   = dir('Desc/*.hst');    % representation/reference image
finaLst     = 'Regist/FinasHst.txt';
SaveFipaLstPrependPath( aImgNaRep, 'Desc/', finaLst );

fipsColl    = 'Desc/COLLHST';

%% -------   The Program   -------
fpProg      = FipaExe.collhimg;  
v_ProgExists( fpProg ); 

%% -------   Execute Command   --------
cmnd         = sprintf('%s %s %s', fpProg, finaLst, fipsColl );
[status Out] = system( cmnd );
v_CmndExec( status, Out, cmnd );

%% -------   Load Collected Histogram   -------
Fixt            = o_FileExtensions();
[HSTC NbinC]    = LoadCollHist( [fipsColl Fixt.collHst] );

fprintf('ntBin       %5d\n', sum(NbinC.Tot) );
fprintf('nBinFltUni  %5d\n', NbinC.Tot(1) );
fprintf('nBinFltBiv  %5d\n', NbinC.Tot(2) );
fprintf('nBinSpaUni  %5d\n', NbinC.Tot(3) );
fprintf('nBinSpaBiv  %5d\n', NbinC.Tot(4) );

figure(1);
imagesc(HSTC);

figure(2);
bar(NbinC.Tot);
set(gca,'xticklabel', {'FltUni' 'FltBiv' 'SpaUni' 'SpaBiv'} );
title('Num Bins');

%% -------   Load an Individual Histogram   -------
Hst1        = LoadDescHist( 'Desc/img1.hst' );
Nbin1       = Hst1.Nbin;

% for verification:
% sum bin count of Nbin1, too see if it matches NbinC.
nBinUni     = f_SumFromFields( Nbin1.Uni );
nBinBiv     = f_SumFromFields( Nbin1.Biv );
nBinSpa     = f_SumFromFields( Nbin1.Spa );

% ori for ttrg and bndg not collected, therefore add now as +16:
nBinUniC    = NbinC.Tot(1) + 16;    

nBinSpaC    = sum( NbinC.Tot(3:4) );

assert( nBinBiv==sum(NbinC.Tot(2)) );
assert( nBinSpa==nBinSpaC, 'spa %d <> %d', nBinSpa, nBinSpaC );
assert( nBinUni==nBinUniC, 'uni %d <> %d', nBinUni, nBinUniC );
