% 
% Runs program mhstL (1-versus-List) for two images.
%
% af exsbMvecLimg.m
%
% script to be run from directory 'MtchHst'
%
clear;
run('../globalsSB');

cd( PthProg.descExtr );
RennDscx( 'Imgs/img1.jpg', '../MtchHst/Desc/img1' );
RennDscx( 'Imgs/img2.jpg', '../MtchHst/Desc/img2' );

cd( PthProg.mtchHst );

finaProg    = 'mhstL';

pthImgTst   = 'Desc/img1.hst';      % testing image 
aImgNaRep   = dir('Desc/*.hst');    % representation/reference image
finaLst     = 'Regist/FinasHst.txt';
SaveFipaLstPrependPath( aImgNaRep, 'Desc/', finaLst );
finaMesHlst = 'Mes/HstLst.txt';
finaMesHuor = 'Mes/HstUor.txt';     % cannot be changed

%% --------   Options   --------
% OptK            = u_OptMvecStc();
% OptK.tolMtc     = 0.1;
% optS            = i_OptMvec(OptK);
optS = ''; % no options so far

%% =========   Command   ========
cmndImg      = [finaProg ' ' pthImgTst ' ' finaLst ' ' finaMesHlst ' ' optS];

[Sts OutImg] = dos( cmndImg );

%% -------   Load Matching Results   -------
nRep         = length(aImgNaRep);

[OrdHis DisHisOrd] = LoadSortFltTxt( finaMesHlst, nRep );

DisHisUor    = LoadFltTxt( finaMesHuor, nRep );






