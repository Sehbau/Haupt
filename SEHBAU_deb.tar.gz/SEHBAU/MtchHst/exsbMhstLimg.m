% 
% Runs program mhstL (1-versus-List) for two images.
%
% af exsbMvecLimg.m
%
% script to be run from directory 'MtchHst'
%
clear;
run('../AdminMb/globalsSB');

%% ---------   Run Two Images   -----------
% we run dscx for two images
cd( PthProg.descExtr );
Args    = o_CmndArgs( 'dscx' );
RennDscx( 'Imgs/img1.jpg', '../MtchHst/Desc/img1', Args );
RennDscx( 'Imgs/img2.jpg', '../MtchHst/Desc/img2', Args );

cd( PthProg.mtchHst );

%% ----------   Prepare Input Args   --------
finaProg    = 'mhstL';

pthImgTst   = 'Desc/img1.hst';      % testing image 
aImgNaRep   = dir('Desc/*.hst');    % representation/reference image
finaLst     = 'Regist/FinasHst.txt';
SaveFipaLstPrependPath( aImgNaRep, 'Desc/', finaLst );

finaMesHlst = 'Mes/HstLst.txt';
finaMesHuor = 'Mes/HstUor.txt';     % cannot be changed

%% =========   Command   ========
cmndImg      = [finaProg ' ' pthImgTst ' ' finaLst ' ' finaMesHlst];

[Sts OutImg] = system( cmndImg );

%% -------   Load Matching Results   -------
nRep         = length(aImgNaRep);

% the sorted array
[OrdHis DisHisOrd] = LoadSortFltTxt( finaMesHlst, nRep );

% the UNsorted array
DisHisUor    = LoadFltTxt( finaMesHuor, nRep );

fprintf('mmm  %1.2f - %1.2f - %1.2f \n', ...
    DisHisOrd(1), mean(DisHisUor), DisHisOrd(end));






