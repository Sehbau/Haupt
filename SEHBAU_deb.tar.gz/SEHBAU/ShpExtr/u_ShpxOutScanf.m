% 
% Determines the measurement sections from mshp1
%
% sa u_MtrMesScnf.m
%
% IN    Sto   standard out (full, unselected)
%
% OUT   Mes   measurements
%
function [V] = u_ShpxOutScanf( Sto )

%% -----   Umfang  -----
ixUmf   = strfind( Sto, 'umf' );
if isempty(ixUmf), 
    Sto
    error('cannot find umf value'); 
end
Sto     = Sto( ixUmf+3:end);     % eliminate section header
%Sto
% -----   Read measurements   ------
V.umf   = sscanf( Sto, '%f', 1 ); % umfang


%% -----   Shape Success   -----
ixSha   = strfind( Sto, 'sha' );
if isempty(ixSha), 
    Sto
    error('cannot find sha value'); 
end
Sto     = Sto( ixSha+3:end);     % eliminate section header
% -----   Read measurements   ------
V.sha   = sscanf( Sto, '%f', 1 ); % shape success


end

