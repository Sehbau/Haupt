"""
 Example for executable 'fabric' and 'fbrc2arr'

 Assumes script is run from dir 'DescUtil'

 Three steps:
 1) run executable 'dscx' with options --saveRRE and --saveCVP
 2) run executable 'dbin' with cabinet grid 32x32
 3) now we run fabric on the cabinet

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescUtil.RennDbin import RennDbin, RennFabric, RennFbrc2Ar
from AdminPy.DescExtr.Texture.Fabric import u_FbrcCatKntMap
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.DescExtr.Hist.DescBinAnf import *
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn
from AdminPy.Collection.LoadCollHist import LoadCollHist


# ------------------------------   Dscx (Step 1)   ------------------------------
strImg      = 'room.png'

fipaImg     = Path( 'Imgs/' + strImg )            # image path
fstmOut     = Path( 'Desc/' + strImg[:-4] )     # output file path

ArgsDscx        = o_CmndArgs('dscx')
ArgsDscx.opt    = ' --saveRRE --saveCVP';

StdOut      = RennDscx( fipaImg, fstmOut, ArgsDscx, sb.PthProg['descExtr'] )

# ------------------------------   Dbin (Step 2)   ------------------------------
fpPrm           = 'Params/PrmDbin_Cabinet.txt'; 
Fixt            = o_FileExtensions()
fipaDsc         = str(fstmOut) + Fixt.dsc 
ArgsDbin        = o_CmndArgs( 'dbin' )
ArgsDbin.fpPrm  = fpPrm
ArgsDbin.opt    = '--all'

OutDbin         = RennDbin( fipaDsc, fstmOut, ArgsDbin )

# ------------------------------   Fabric & fbrc2arr   ------------------------------
fpDSC           = o_FinaApndExtDscx( fstmOut, Fixt )
fipaCbnt        = fpDSC.hsspa # [fstmOut Fixt.hsspa];
ArgsFbrc        = o_CmndArgs( 'fabric' );

pthFbrc         = sb.PthProg['descUtil']

# we run both, 'fabric' and 'fbrc2arr'
OutFbrc         = RennFabric( fipaCbnt, fstmOut, ArgsFbrc, pthFbrc )
OutFbAr         = RennFbrc2Ar( fpDSC.fbrc, fstmOut, pthFbrc )


# ------------------------------   Load Output Fabric   ------------------------------
# load from fabric file outputted by 'fabric'
FBRC, HedFbc    = LoadFabric( fpDSC.fbrc )

# show how to access some fields

# --- individual count maps
print('Count Maps:')
print(FBRC.K0.Ncnt.shape) # layer 0 for contours
print(FBRC.K0.Nfrm.shape) #   "   0 for forms

# concatenate the count (numerosity) maps to a block (third axis=descriptor type)
# [vrt hor nDscTyp]
MKNT0mp = u_FbrcCatKntMap( FBRC.K0 ) # [31 31 5]
MKNT1mp = u_FbrcCatKntMap( FBRC.K1 )
MKNT2mp = u_FbrcCatKntMap( FBRC.K2 )
MKNT3mp = u_FbrcCatKntMap( FBRC.K3 )
# reshape to [nCells nDscTyp]
KNTA0   = MKNT0mp.reshape(-1, MKNT0mp.shape[2]) # [961 5]
KNTA1   = MKNT1mp.reshape(-1, MKNT1mp.shape[2]) # [225 5]
KNTA2   = MKNT2mp.reshape(-1, MKNT2mp.shape[2]) # 
KNTA3   = MKNT3mp.reshape(-1, MKNT3mp.shape[2]) # [  9 5]

# --- part of individual hyperkolumns
print('Cnt Huni' + str(FBRC.K0.ACNT[0].Uni.shape)) # layer 0, cell 0
print('Cnt Huni' + str(FBRC.K0.ACNT[4].Uni.shape)) # layer 0, cell 4

# --- bias maps
print(FBRC.MP0.Cnt['Vrt'].shape) # layer 0
print(FBRC.MP1.Cnt['Vrt'].shape) # layer 1

# number of bins in header
print('Nbin Cnt' + str(HedFbc.NbinAtt.ArcUni))
print('Nbin Arc' + str(HedFbc.NbinDty.Arc))
print('Ndsc ' + str(HedFbc.NbinDty.Ndsc))

# ------------------------------   Load Output Arrays   ------------------------------
# load the 12 files as outputted by executable 'fbrc2arr' and assign to FFLL
FFLL      = fbrcMTXL()      # the full fabric, as loaded

print('Loading kolumns...')
# Kolumn arrays were saved in collection format, therefore we use LoadCollHist
# loading from integer as float
FFLL.AHYK[0], Nbin0 = LoadCollHist( fpDSC.fbArK0 )
FFLL.AHYK[1], Nbin1 = LoadCollHist( fpDSC.fbArK1 )
FFLL.AHYK[2], Nbin2 = LoadCollHist( fpDSC.fbArK2 )
FFLL.AHYK[3], Nbin3 = LoadCollHist( fpDSC.fbArK3 )

nCells, ntBin   = FFLL.AHYK[0].shape
FFLL.Dim        = dimFabric()
FFLL.Dim.ntBin  = ntBin

print( f"HYK 0 [nCells ntBin] = [ {nCells} {ntBin} ]" )
# print(Nbin0.Cnt) # is none

# ----------   Bias Maps   ----------
# Note that dg1 and dg2 were dropped by fbrc2arr!!
FFLL.ABIS[0], Hed0 = LoadFbrcMapBisFromArrToMap( fpDSC.fbArM0 )
FFLL.ABIS[1], Hed1 = LoadFbrcMapBisFromArrToMap( fpDSC.fbArM1 )
FFLL.ABIS[2], Hed2 = LoadFbrcMapBisFromArrToMap( fpDSC.fbArM2 )
FFLL.ABIS[3], Hed3 = LoadFbrcMapBisFromArrToMap( fpDSC.fbArM3 )

# ----------   Count Maps   ----------
# were also saved in collection format
# numerosity/count maps
FFLL.AKNT[0], Hdn0 = LoadCollHist( fpDSC.fbArN0 )
FFLL.AKNT[1], Hdn1 = LoadCollHist( fpDSC.fbArN1 )
FFLL.AKNT[2], Hdn2 = LoadCollHist( fpDSC.fbArN2 )
FFLL.AKNT[3], Hdn3 = LoadCollHist( fpDSC.fbArN3 )

nCells, ntBsv = FFLL.ABIS[0].shape
nCells, nDscT = FFLL.AKNT[0].shape

FFLL.Dim.ntBsv = ntBsv
FFLL.Dim.nDscT = nDscT

# -----------  verify Maps  -------------
# We compare output of executable fabric with output of fbrc2arr and use
# vertical map of contour and form
DfC     = FFLL.ABIS[1][:,0] - FBRC.MP1.Cnt['Vrt'].flatten()
DfF     = FFLL.ABIS[1][:,5] - FBRC.MP1.Frm['Vrt'].flatten()
DfN     = FFLL.AKNT[1][:,0] - FBRC.K1.Ncnt.flatten()
assert DfC.any()==0, 'not correct'
assert DfF.any()==0, 'not correct'
assert DfN.any()==0, 'not correct'

# ------------------------------   NumBins   ------------------------------
# adjust some of the bin numbers
# NbinCms  = i_BnumFromLoad( HedFbc.NbinAtt, HedFbc.NbinDty )

# --------------------------------------------------------------------------------
#                         F O C U S   E X T R A C T I O N 
# --------------------------------------------------------------------------------
# we extract the description for a bounding box
#top=5; bot=120; lef=80; rit=260
#top=5; bot=320; lef=80; rit=560
top=100; bot=350; lef=0; rit=640-1 # partial height, full width
Box = np.array([top, bot, lef, rit], dtype=np.int32)

# the scaling factors
PrmScl   = i_PrmFbrcFocScl( HedFbc.Hed.szV, HedFbc.Hed.szH )

# the linear indices
IXlin    = f_FbrcFocRngs( Box, PrmScl )

# -----  extract focus from arrays
FFOC     = f_FbrcFocXtr( FFLL, IXlin )

# reshape 'linear maps' to 'spatial' maps
ntBis     = Hed0.nBis*2
SMP0map   = FFOC.ABIS[0].reshape( IXlin.ASiz[0,0], IXlin.ASiz[0,1], ntBis )#, order='F' )
Mvrt      = SMP0map[:,:,0]

# ------------------------------   Plot   ------------------------------
from PIL import Image
Irgb   = np.array(Image.open(fipaImg))

import matplotlib.pyplot as plt
figNo = 1
hf = PlotFbrcMaps( FBRC.MP0, FBRC.K0, figNo, Irgb )
plt.show(block=False)

hf = PlotFbrcMaps( FBRC.MP0, FBRC.K1, figNo+1, Irgb )
plt.show(block=False)

hf = PlotFbrcMaps( FBRC.MP0, FBRC.K2, figNo+2, Irgb )
plt.show(block=False)

hf = PlotFbrcMaps( FBRC.MP0, FBRC.K3, figNo+3, Irgb )
plt.show(block=False)


# -----  plot selection
figSel = 5
hf = plt.figure(figSel)
hf.clf()

nr, nc = 3, 4

ax = hf.add_subplot(nr, nc, 1)
ax.imshow(Irgb)
ax.tick_params(labelsize=5)

ax = hf.add_subplot(nr, nc, 2)
ax.imshow( Mvrt )
ax.set_title('Sel')
plt.show(block=False)



