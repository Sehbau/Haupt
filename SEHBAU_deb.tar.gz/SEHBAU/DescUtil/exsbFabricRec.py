"""

Example for top-down recognition strategy with fabric description.

Assumes script exsbFabric.py has been run already, as we rely on the fabric
description.

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescUtil.RennDbin import RennDbin, RennFabric, RennFbrc2Ar
from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Texture.FabricIO import *
from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.DescExtr.Hist.DescBinAnf import *
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn


# ------------------------------   Paths   ------------------------------
strImg      = 'room.png'
fipaImg     = Path( 'Imgs/' + strImg )            # image path
fstmOut     = Path( 'Desc/' + strImg[:-4] )     # output file path
Fixt        = o_FileExtensions()
fpDSC       = o_FinaApndExtDscx( fstmOut, Fixt )

# ------------------------------   Load Output   ------------------------------
# we assume that script exsbFabric.py has alread been executed
dmy, HedFbc = LoadFabric( fpDSC.fbrc )  # we need the image size for scaling factors
FFLL        = LoadFbrcArrays( fpDSC )   # FabricIO.py


# --------------------------------------------------------------------------------
#                         F O C U S   E X T R A C T I O N 
# --------------------------------------------------------------------------------
# we extract a subset of the fabric description
top=160; bot=245; lef=450; rit=540 # black microwave/cabinet
#top=240; bot=320; lef=50; rit=95 # fire exstinguisher
#top=280; bot=315; lef=480; rit=520 # stove
#top=280; bot=320; lef=520; rit=580 # faucet
#top=180; bot=260; lef=330; rit=390 # ventilator/towel dispenser
Box      = np.array([top, bot, lef, rit], dtype=np.int32)

# --- the scaling factors
PrmScl   = i_PrmFbrcFocScl( HedFbc.Hed.szV, HedFbc.Hed.szH )
# --- extract and create kernel
IXlin    = f_FbrcFocRngs( Box, PrmScl ) # the linear indices
FFOC     = f_FbrcFocXtr( FFLL, IXlin )  # extract focus (subspace)
FKrnl    = f_FbrcKernel( FFOC )         # kernel: take mean of hyperkolumns/biases


# -------------------------------------------------------------------
#                        T O P - D O W N
# -------------------------------------------------------------------
# we look for the above focus description 'FKrnl' in the fabric description
# 'FFLL'. That should be easy, since it is a loose auto-correlation, but this
# ensures that we apply everthing correctly
import AdminPy.Recognize.FbrcAly as faly

# exhaustive, no acceleration / optimization
SCORexhst   = faly.Krnl1Exhst( FFLL, FKrnl ) 

# accelerated using quick-reject conditions
PrmIdf      = faly.i_FbrcIdfPrm()
SCORaccel   = faly.Krnl1Accel( FFLL, FKrnl, PrmIdf )

# ----------   Find Minima   ----------
import AdminPy.Recognize.RecUtil as rcut
nLayKrnl    = FKrnl.Dim.nLay
MinTopExhst = rcut.f_MapLocMinima( SCORexhst.AHyk[nLayKrnl-1], 3, 2 )
MinTopAccel = rcut.f_MapLocMinima( SCORexhst.AHyk[nLayKrnl-1], 3, 2 )

szHor       = ADimLay[0][1]
IxMinTopEx  = rcut.u_PixRCtoIx( MinTopExhst, szHor )
IxMinTopAc  = rcut.u_PixRCtoIx( MinTopAccel, szHor )
# is it same?
assert IxMinTopEx[0]==IxMinTopAc[0] 


# ------------------------------   Plot   ------------------------------
from PIL import Image
Irgb     = np.array(Image.open(fipaImg))
Iptch    = Irgb[top:bot+1, lef:rit+1, :]    # the corresponding patch in the image

nLaySus  = FKrnl.Dim.nLay
figExhst = 1
figAccel = 2
faly.p_MapsScor( figExhst, Irgb, Iptch, SCORexhst, FKrnl.Dim.nLay )
faly.p_MapsScor( figAccel, Irgb, Iptch, SCORaccel, FKrnl.Dim.nLay )

