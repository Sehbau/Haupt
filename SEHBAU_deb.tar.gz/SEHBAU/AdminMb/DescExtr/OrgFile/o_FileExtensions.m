%
% File extensions with two output structures: one for description of image
% and one for focus.
%
% ia Fixt
%
% from struct stuFileExtn in FileNameDesc.h
%
function [D F] = o_FileExtensions()

%% -------------   IMAGE   ---------------
% -----  contours
D.dscRRE = '.dscRRE';   % full set
D.cntEpt = '.CntEpt';

% -----  image 
D.dsc    = '.dsc';
D.dsbi   = '.dsb';
D.hsti   = '.hst';
%D.hstc   = '.hstc';     % collection (collHimg)
%D.utzi   = '.utz';		% utilities (deployed yet?)

D.kolm   = '.kol';		% kolumns
D.txtm   = '.txm';		% texture maps
D.salc   = '.slc';		% saliency 

D.qbbx   = '.qbbx';		% proposals bbox
D.qdsc   = '.qdsc';		% proposals descriptors

D.cvpo   = '.cvpo';		% curve partitions organization (deployed yet?)

D.bbox   = '.Bbox';		% s_FunvBboxAll, ai dscx.cpp

D.bonBbx = '.BonBbox';  % s_BonBboxPyr
D.bonAsp = '.BonAsp';
D.bonPix = '.BonPix';

% -----  shape
D.shp    = '.shp';

% -----  collection/conversion
D.collHst = '.hstc';    % collHimg
D.collSlc = '.slcc';    % ???
D.hari    = '.hari';    % Hst-Of-Att as array for image

% -----  maps
D.mapUch  = '.mpu';


%% -------------   FOCUS   ---------------
F.dscf   = '.dsf';
F.hstf1  = '.hsf1'; 	% fochst1.cpp
F.hstfL  = '.hsfL';

% -----   conversion
F.harf   = '.harf';    % Hst-Of-Att as array for focus




