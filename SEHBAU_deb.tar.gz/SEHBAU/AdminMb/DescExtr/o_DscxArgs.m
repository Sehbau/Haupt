% 
% The argument structure for descriptor extraction program dscx.
%
% Minimal version.
%
% Default is that NO options will be modified and no string will be created
% in i_DscxArgs.
%
% IN    - 
% OUT   O   struct with options and parameters
%
function O = o_DscxArgs()


%% -----   Saving  -----
O.saveRRE   = 0;    % saving of RRE space (full set)
O.saveCVP   = 0;    % saving of full CVP space
O.saveKol   = 0;    % saving of kolumns
O.saveTxm   = 0;    % saving of texture maps

% setting the following two has no effect!!
O.saveBin   = 0;    % saving of bins. default ON!!
O.saveProp  = 0;    % saving proposals. default ON!!

% feature
O.saveRegUnv    = 0;    % region universe
O.saveBonSpc    = 0;    % boundary space

% other
O.saveBonBoxRaw = 0; % saves .bonBboxRaw 
O.saveBonMore   = 0; % .bonBbox, .bonAsp
O.saveCuvKpt    = 0; % saves .cuvKpt

O.noSave        = 0;    % saving of description % does this work?

%% -----  Archit  -----
% a value of -1 signals that no modification is desired. default remains.
O.nLev      = -1;
O.depth     = -1;
O.imgSpc    = -1;   % image space (pyramid or scale space)
O.imgFlt    = -1;   % image filtering

%% -----  Other   -----
O.optS      = '';

%% -----  For Verification   -----
aFldn       = fieldnames(O);
O.nFld      = length(aFldn) + 1;    % include self

end

