%
% Wrapper function for program dscx
%
% sa RennMvecL.m
% 
% IN   fpImg    image file path,  including extension
%      fpOut    output file path, excluding extension
%      Args     arguments (o_CmndArgs) 
%      Args      .fpPrm   parameter filename (3rd argument)
%
% OUT   Out     standard output
% 
function [Out] = RennDscx( fpImg, fpOut, Args, pthProg )

if nargin==3, 
    pthProg = ''; 
end

fpProg  = [pthProg 'dscx'];

if exist( fpProg, 'file')==2,
    error('Program path not correct: %s', fpProg);
end

cmnd    = [ fpProg ' ' fpImg ' ' fpOut ' ' Args.fpPrm, ' ' Args.opt ];

if ispc
    cmnd         = u_PathToBackSlash( cmnd );
    [status Out] = dos(cmnd);            % excecute as windows program
elseif isunix
    [status Out] = unix(cmnd);           % excecute as unix program
else
    error('OS not implemented');
end

%% ------  Status  ------
if status>0
    Out
    warning('status > 0: something went wrong');
end

%% ------  Verify Proper Termination  -----
ixEOP = strfind( Out, 'EndOfProgram');

if isempty(ixEOP)
    warning('Program dscx %s did not finish.', cmnd);
    Out    
    if isempty(Out)
        fprintf('Out empty. We try to debug: '); 
        cmnd      = [cmnd ' --bDISP 3'];
        [stu Out] = dos(cmnd);           % excecute program again
        Out    
    end
    fprintf('Paused');
    pause();
end


