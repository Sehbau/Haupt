%
% Reads desctype values as saved under w_DescTypSpcF
%
% cf LoadDescSalc.m
%
function [S] = ReadDescTypSpcF( fileID )

nLev = fread( fileID, 1, 'uint8=>single');

assert( nLev>0 && nLev<10, 'nLev =%d: unreasonable.', nLev);

S.Rdg = fread( fileID, nLev, 'float=>single');
S.Riv = fread( fileID, nLev, 'float=>single');
S.Edg = fread( fileID, nLev, 'float=>single');
S.Skl = fread( fileID, nLev, 'float=>single');

S.Rsg    = fread( fileID, nLev, 'float=>single');
S.Arc    = fread( fileID, nLev, 'float=>single');
S.Str    = fread( fileID, nLev, 'float=>single');
S.ArcGst = fread( fileID, nLev, 'float=>single');
S.StrGst = fread( fileID, nLev, 'float=>single');

S.Shp    = fread( fileID, nLev, 'float=>single');
S.Ttrg   = fread( fileID, nLev, 'float=>single');
S.Bndg   = fread( fileID, nLev, 'float=>single');

S.nLev   = nLev;



end

