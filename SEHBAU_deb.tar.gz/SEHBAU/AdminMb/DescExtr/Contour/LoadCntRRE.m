%
% Loads all contour spaces (RRE), also known as the full set of contours.
%
% Loads as saved under CntIOrre.h:si_RREspc.
%
function [RRE] = LoadCntRRE(lfn) 

fid   = fopen(lfn, 'r');
if (fid<0), error('file %s not found', lfn); end

[nLev Nrdg] = ReadDescSpcHead( fid );
[nLev Nriv] = ReadDescSpcHead( fid );
[nLev Nedg] = ReadDescSpcHead( fid );

RRE.ARDG    = ReadCntSpc( fid );
RRE.ARIV    = ReadCntSpc( fid );
RRE.AEDG    = ReadCntSpc( fid );

fclose(fid);

DispLoad(lfn);


