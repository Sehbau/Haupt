%
% Plots a pair of descriptor sets in preparation for a correspondence plot.
%
function [Out] = p_DescCorrespPair( dty, A, B, szM, aBon1, aBon2 ) 


if strcmp( dty, 'cnt' )
    
    % we remain in unit coordinates
    B.Pos.Hor   = B.Pos.Hor + 1; % shift to right side
    Out         = B.Pos;

    p_CntFromAtts( A );        % left side
    p_CntFromAtts( B );        % right side
    
    set(gca,'xlim', [ 0 2 ]);
    set(gca,'ylim', [ 0 1 ]);

elseif strcmp( dty, 'rsg' )

    % here we are in absolute (pixel) coordinates (NOT unit coordinates)
    aBon2 = f_BonPixShift( aBon2, 0, szM(2) );
    Out   = aBon2;
    
    p_RsgPix( A, aBon1, 'nofet' ); 
    p_RsgPix( B, aBon2, 'nofet' ); 
    %p_RsgFromAtts( A ); 
    %p_RsgFromAtts( B ); 

    % the poles as dots with no pixel correction 
    A.Pos  = u_PosVHscaleup( A.Pos, szM, 0 );
    B.Pos  = u_PosVHscaleup( B.Pos, szM, 0 );
    B.Pos  = u_PosVHshift( B.Pos, 0, szM(2) );
    
    p_PosVH( A.Pos, 'k' );
    p_PosVH( B.Pos, 'r' );

    set(gca,'xlim', [ 0 szM(2)*2 ]);
    set(gca,'ylim', [ 0 szM(1)   ]);

elseif strcmp( dty, 'arc' )
    
    B.Pts = u_DescPtsShift( B.Pts, 0, szM(2) );
    
    p_ArcPts( A );
    p_ArcPts( B );

    set(gca,'xlim', [ 0 szM(2)*2 ]);
    set(gca,'ylim', [ 0 szM(1)   ]);
    
elseif strcmp( dty, 'str' )

    B.Pts = u_DescPtsShift( B.Pts, 0, szM(2) );
    
    p_StrPts( A );
    p_StrPts( B );

    set(gca,'xlim', [ 0 szM(2)*2 ]);
    set(gca,'ylim', [ 0 szM(1)   ]);
    
else
    
    error('descriptor %s not implemented', dty);

end

set(gca,'fontsize',6, 'xcolor', ones(1,3)*0.5 );
