%
% Plots the texture maps into one figure, with or without bounding boxes.
%
% IN    TXM     as loaded with LoadTxtrMaps.m
%       SBbxLay    the corresponding bounding boxes
%
function [] = PlotTxtrMaps( TXM, figNo, Irgb, SBbxLay )

if nargin==4, bBbx = 1; else bBbx = 0; end


figure(figNo); clf;
[nr nc] = deal(3,3);


subplot(nr,nc,1);
imagesc( Irgb );
set(gca,'fontsize',5);
%p_BboxL( SBbxOrg.Hor );
%p_BboxL( SBbxOrg.Vrt );

subplot(nr,nc,2);
imagesc( TXM.KNT.Num ); title('Num (Count)');
if bBbx, p_BboxL( SBbxLay.Num ); end

subplot(nr,nc,3);
imagesc( TXM.KNT.Blk ); title('Blank (Void)');
if bBbx, p_BboxL( SBbxLay.Blk ); end

subplot(nr,nc,4);
imagesc( TXM.OTX.Hor ); title('Horizontal');
if bBbx, p_BboxL( SBbxLay.Hor ); end

subplot(nr,nc,5);
imagesc( TXM.OTX.Vrt ); title('Vertical');
if bBbx, p_BboxL( SBbxLay.Vrt ); end

subplot(nr,nc,6);
imagesc( TXM.OTX.Axi ); title('Axial');
if bBbx, p_BboxL( SBbxLay.Axi ); end

subplot(nr,nc,7);
imagesc( TXM.OTX.Nil ); title('Nil-Ori');
if bBbx, p_BboxL( SBbxLay.Nil ); end

subplot(nr,nc,8);
imagesc( TXM.SAL.Enk ); title('Contrast');
if bBbx, p_BboxL( SBbxLay.Ken ); end

subplot(nr,nc,9);
imagesc( TXM.SAL.Bunt ); title('Bunt');
if bBbx, p_BboxL( SBbxLay.Bnt ); end

end

