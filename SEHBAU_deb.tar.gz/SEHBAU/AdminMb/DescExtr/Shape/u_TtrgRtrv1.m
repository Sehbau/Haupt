%
% Retrieve attributes of one tetragon with index ix from struct-of-arrays
% as read by ReadTtrgAtt.
%
% ui p_TtrgLst.m
%
function [Axe Cor O] = u_TtrgRtrv1( S, ix )

% elo-axis
Axe.Rw  = [ S.Ax.Ep1(ix,1) S.Ax.Ep2(ix,1) ];
Axe.Cl  = [ S.Ax.Ep1(ix,2) S.Ax.Ep2(ix,2) ];

% corner points
Cor.Rw  = [ S.Cop.Ep1(ix,1) S.Cop.Ep2(ix,1) S.Cop.Ep3(ix,1) S.Cop.Ep4(ix,1) ];
Cor.Cl  = [ S.Cop.Ep1(ix,2) S.Cop.Ep2(ix,2) S.Cop.Ep3(ix,2) S.Cop.Ep4(ix,2) ];

% attributes
O.vrt       = S.Pos.Vrt(ix);
O.hor       = S.Pos.Hor(ix);
O.ori       = S.Ori(ix);
O.oriAbs    = abs( O.ori );

O.axV       = S.LAGE.AxVrt(ix); % vertical
O.axH       = S.LAGE.AxHor(ix); % horizontal

O.Rgb       = [ S.RGB.Red(ix) S.RGB.Grn(ix) S.RGB.Blu(ix) ];

% util
O.ixBon     = S.IxBon1( ix );  % already one-indexing (see loading rout)

        
end

