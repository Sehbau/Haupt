%
% Appends binarized vectors for ONE image and ONE desctype to a collection.
% 
% Consider deploying f_VecBinForm
% 
% cf collDbins.m
%
function COLL = u_CollBinApndImg( COLL, I, nLev, dty )

error('deprecated');

ctV     = COLL.ctV;

for l = 1:nLev

    if strcmp( dty, 'cnt' );
        Bn      = I.CNT{l};
        nVec    = Bn.nCnt;    
        VLev    = [Bn.Les Bn.Str Bn.Ori];
        
    elseif strcmp( dty, 'rsg' );
        Bn      = I.RSG{l};
        nVec    = Bn.nRsg;   
        VLev    = [Bn.Rds Bn.Elo Bn.Ori Bn.Cir];
        
    elseif strcmp( dty, 'arc' );
        Bn      = I.ARC{l};
        nVec    = Bn.nArc;    
        VLev    = [Bn.Les Bn.Krv Bn.Dir];
        
    elseif strcmp( dty, 'str' );
        Bn      = I.STR{l};
        nVec    = Bn.nCnt;    
        VLev    = [Bn.Les Bn.Str Bn.Ori];
        
    else
        error('dty %d not defined');
    end

    % --- append
    COLL.BIN(   ctV+(1:nVec), : ) =  VLev;
    COLL.LbLev( ctV+(1:nVec) )    =  ones(1,nVec,'uint8')*l;

    ctV     = ctV + nVec;    
end

COLL.ctV = ctV;


end






