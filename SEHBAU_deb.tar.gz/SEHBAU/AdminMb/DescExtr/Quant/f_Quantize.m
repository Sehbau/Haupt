%
% Finds the unique binned vectors, called quants hereafter. It also
% determines a hash-base and determines the hash for each quant.
%
% Bin-vectors were collected in f_CollBinDty.m
% 
% IN    BIN   matrix of bin-vectors [ntVec nBin]
% OUT   S     struct 
%              .QNT        quants: unique bin-vectors 
%              .HashBase   hash base
%              .QntHsh     hash for quants
%
function S = f_Quantize( BIN, dtyS )

[ntV nAtt]  = size( BIN );

fprintf('%-7s [%d %d]\n', dtyS, ntV, nAtt);

S           = struct;
if ntV==0
    S.nQnt = 0; 
    return;
end

%% --------   Find   ---------
[S.QNT IxC IxQ]  = unique( BIN, 'rows');
nQnt        = size(S.QNT,1);
fprintf('\t\tnQnt       %6d / %4.3f mio [%1.5f]\t', nQnt, ntV/1e6, nQnt/ntV );

%% --------   Hist Qnt  ---------
S.Kt        = histcounts( IxQ, nQnt );
S.KtO       = sort(S.Kt);
fprintf('\tfreq mmm   %d - %8.2f - %8d\n', ...
                S.KtO(1), mean(S.Kt), S.KtO(end) );
            
%% --------   Hist Kount  ---------
%Edg         = linspace( 0.5, max(S.Kt)+0.5, 11 );
%S.Hkt       = histcounts( S.Kt, Edg );

%% --------   Density   ---------
MxQperAtt   = max( S.QNT,[],1 );

nmxQntU     = prod( MxQperAtt + 1 );
dnsty       = nQnt / nmxQntU;
fprintf('\t\tdensity    %6d / %6d    [%1.5f]\n', nQnt, nmxQntU, dnsty );

%% --------   HashBase   --------
maxBin      = single( max( MxQperAtt ) ); 	% bound of bins values

S.HashBase  = (maxBin+1).^(0:nAtt-1);    	% base multipliers

S.QntHsh    = single(S.QNT) * S.HashBase';	% [nQnt 1]


%% ---------   A2S    ---------
S.dnsty     = dnsty;
S.nAtt      = nAtt;
S.nQnt      = nQnt;

end






