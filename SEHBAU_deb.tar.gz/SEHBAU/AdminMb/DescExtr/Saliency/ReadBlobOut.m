%
% Reads blobs as saved under wb_BlobOut in BlobIO.h (struct blobOUT)
%
% cf LoadDescSalc.m, LoadSalcAly.m
%
function [B] = ReadBlobOut( fileID, bIxOne )

% the bounding boxes
[B.Box nBx] = ReadBboxLbin( fileID );

% the aspects
B.Typ     = fread( fileID, nBx, 'float=>single' ); % 1-8, 7 + kke
B.Are     = fread( fileID, nBx, 'float=>single' ); % area
B.Pon     = fread( fileID, nBx, 'float=>single' ); % proportion ON
B.Cvg     = fread( fileID, nBx, 'float=>single' ); % coverage
B.Ken     = fread( fileID, nBx, 'float=>single' ); % kontrast energy

B.Bord    = fread( fileID, nBx, 'uint8=>uint8' ) ; % border type
B.IxBlb   = fread( fileID, nBx, 'int32=>int32' ) + bIxOne ; 

B.nBox    = nBx;

end

