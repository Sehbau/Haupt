% 
% Creates long-option string arguments for program dscx. Template in 
% o_DscxArgs.m
%
% IN    O   argument structure with fields modified by user
% OUT   S   arguments as string 
%
function S = i_DscxArgs( O )

%% -----  Verify Fieldnames  ------
aFldn       = fieldnames(O);
nFldFound   = length(aFldn);

if O.nFld~=nFldFound, 
    fprintf('too many fields present somehow\n');
    O
    fprintf('pausing'); pause();
end


%% -----  Extraction/Saving  -----
% DscxArg.h
S = '';

if O.saveRRE>0,   S = [S ' --saveRRE'];  end
if O.saveCVP>0,   S = [S ' --saveCVP'];  end
if O.saveKol>0,   S = [S ' --saveKol'];  end

% default is ON for this anyway!
if O.saveProp>0,  S = [S ' --saveProp'];  end

% features
if O.saveRegPix>0,   S = [S ' --saveRpx'];  end
if O.saveBonPix>0,   S = [S ' --saveBon'];   end

% other
if O.saveBonBoxRaw>0,  S = [S ' --saveBonBboxRaw'];  end
if O.saveBonMore>0,    S = [S ' --saveBonMore'];   end
if O.saveCntEpt>0,     S = [S ' --saveCntEpt'];  end


%% -----  Archit  -----
if O.nLev>-1,
    assert(O.nLev>0 && O.nLev<10);
    S = [S ' --nLev ' num2str(O.nLev)];
end
if O.depth>-1,
    assert(O.depth>0 && O.depth<5);
    S = [S ' --depth ' num2str(O.depth)];
end
if O.imgSpc>-1,
    assert(O.imgSpc>0 && O.imgSpc<3);
    S = [S ' --is ' num2str(O.imgSpc)];
end
if O.imgFlt>-1,
    assert(O.imgFlt>=0 && O.imgFlt<4);
    S = [S ' --if ' num2str(O.imgFlt)];
end

%% -----  Other   -----
S   = [S ' ' O.optS];           % append other options

