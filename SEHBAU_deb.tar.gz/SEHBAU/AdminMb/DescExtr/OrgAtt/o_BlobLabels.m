%
% Texture biases, called blob labels here:
% 
% They are also used in ReadBlobMapGlbSts.m (but NOT passed as variable).
%
% They must match with CntTxtAnf.h, w_CntTXTbis (CntTxtIO.h)
%
% Their color code for plotting is in u_ColBlob.m
%
function [aLsho nTyp aLlon] = o_BlobLabels()

% NB NVHAU
aLsho   = {'Num' 'Blk' 'Nil' 'Vrt' 'Hor' 'Axi' 'Uni' 'Ken'};

nTyp    = length( aLsho );

aLlon   = { 'Num (count)' ...
            'Blank (void)' ...
            'Nil (no ori)' ...
            'Vertical' ...
            'Horizontal' ...
            'Axial (vrt&hor)'...
            'Uni (1 ori)' ...
            'Ken (contrast)'};

end 

