%
% Shift descriptor keypoints by offsets orw and ocl.
%
function P = u_DescPtsShift( P, orw, ocl )

P.Ep1(:,1)  = P.Ep1(:,1) + orw;
P.Ep1(:,2)  = P.Ep1(:,2) + ocl;

P.Ep2(:,1)  = P.Ep2(:,1) + orw;
P.Ep2(:,2)  = P.Ep2(:,2) + ocl;

P.Btw(:,1)  = P.Btw(:,1) + orw;
P.Btw(:,2)  = P.Btw(:,2) + ocl;

end

