%
% Loads as saved under B_BON/Util/BonIO.h-w_BonPix().
%
% For reading as block see ReadBonPixBlok.m
%
function [APix nBon szM Org] = ReadBonPixSegw( fileID ) 

%% ====  sizes  ====
nBon     = fread(fileID, 1, 'int=>single');
szM      = fread(fileID, 2, 'int=>single'); 

fprintf('[%4d %4d] nBon %4d ', szM(1), szM(2), nBon);
    
%% ====  arrays  ====
APix = cell(nBon,1);
Org  = zeros(nBon,1);
for b = 1:nBon
    
    nPx     = fread(fileID, 1, 'int=>single');
    Org(b)  = fread(fileID, 1, 'uint8=>single');
    
    % turn into one-indexing
    Pix.Rw  = fread(fileID, nPx, 'int16=>single') + 1; 
    Pix.Cl  = fread(fileID, nPx, 'int16=>single') + 1;
    
    APix{b} = Pix;
end

idf     = fread(fileID, 1, 'int=>single');
assert(idf==626);

fprintf('\n');


