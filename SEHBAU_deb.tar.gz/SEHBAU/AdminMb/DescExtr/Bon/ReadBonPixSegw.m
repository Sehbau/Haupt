%
% Loads the boundary pixels segment-wise, as saved under
% B_BON/Util/BonIO.h-w_BonPix().
%
% For reading as block see ReadBonPixBlok.m
%
% cf LoadBonPixSpc.m
%
function [APix nBon szM Org] = ReadBonPixSegw( fileID, bDisp ) 

if nargin==1
    bDisp = 0;
end

%% ====  sizes  ====
nBon     = fread(fileID, 1, 'int=>single');
szM      = fread(fileID, 2, 'int=>single'); 

if bDisp
    fprintf('\t[%4d %4d] nBon %4d ', szM(1), szM(2), nBon);
end
    
%% ====  arrays  ====
APix     = cell(nBon,1);
Org.Dth  = zeros(nBon,1,'single');
Org.CC   = zeros(nBon,1,'single');
for b = 1:nBon
    
    nPx         = fread(fileID, 1, 'int=>single');
    Org.Dth(b)  = fread(fileID, 1, 'uint8=>single') + 1;  % depth of tree
    Org.CC(b)   = fread(fileID, 1, 'int32=>single') + 1;  % index of conncomp
    
    % turn into one-indexing
    Pix.Rw  = fread(fileID, nPx, 'int16=>single') + 1; 
    Pix.Cl  = fread(fileID, nPx, 'int16=>single') + 1;
    
    APix{b} = Pix;
end

idf     = fread(fileID, 1, 'int=>single');
assert(idf==626);

if bDisp
    fprintf('\n');
end


