%
% Loads the region pixels as block (not as segments)
%
% Loads as saved under w_BWcoco() in CoCoIO.h.
%
% Plotted with PlotRegPix.m
%
function [S] = ReadRegPixBlok( fileID ) 

%% ====  sizes  ====
nON     = fread(fileID, 1, 'int=>single');
nCC     = fread(fileID, 1, 'int=>single'); 

%% ====  pixels  ====
S.IxLin = fread(fileID, nON,   'int32=>single') + 1; % turn into one-indexing
S.LbCC  = fread(fileID, nON,   'int32=>single') + 1; % 
S.Anf   = fread(fileID, nCC+1, 'int32=>single') + 1;
S.RGB   = fread(fileID, nCC*3, 'uint8=>uint8');

% --- verify
idf     = fread(fileID, 1, 'int=>single');
assert(idf==-1);

S.nON   = nON;
S.nCC   = nCC;
S.RGB   = reshape( S.RGB, 3, nCC )';    % rearrange from C to Matlab

