%
% Reads position coordinates (vertical/horizontal).
%
% cf ReadCntAtt.m
%
function [P] = ReadAttPos( fileID, conversion )

if nargin==1
    cnvs = 'float=>single';
else
    cnvs = conversion;
end

P       = [];

P.nPos  = fread(fileID, 1, 'int=>single'); % # descriptors
nPos    = P.nPos;

P.Vrt   = fread(fileID, nPos, cnvs ); % vertical position
P.Hor   = fread(fileID, nPos, cnvs ); % horizontal position 

end

