%
% Loads the image space (pyramid or scale-space). Gray and RGB.
%
% Is available as file only if long option --saveIsp was set.
%
function [AGry ARGB Dim] = LoadImgSpace(lfn) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----------------------   Header   ---------------------------
nLev   = fread(fileID, 1, 'int=>int');      % # of pyramid levels

SzM    = zeros(nLev,3);
for l = 1:nLev
    SzM(l,:) = fread( fileID, 3, 'int=>int');  
end
%SzM

%% -----------------------   Gray Space   ---------------------------
AGry = cell(nLev,1);
for l = 1:nLev

    szV     = SzM(l,1);
    szH     = SzM(l,2);

    nPx     = szV * szH;
    AGry{l} = fread( fileID, nPx, 'uint8=>uint8');
    AGry{l} = reshape( AGry{l}, szH, szV );
    AGry{l} = flipud( rot90( AGry{l} ) );
end

%% -----------------------   RGB Space   ---------------------------
%
% NOTE: for scale space the image was NOT filtered. It's the same image for
% all maps.
%
ARGB = cell(nLev,1);
for l = 1:nLev
    
    szV     = SzM(l,1);
    szH     = SzM(l,2);
    
    nPx     = szV * szH;
    ARGB{l} = fread( fileID, nPx*3, 'uint8=>uint8');
    
    ARGB{l} = reshape( ARGB{l}, 3, szH, szV );
    ARGB{l} = flipud( rot90( permute( ARGB{l}, [2 3 1] ) ) );
end


fclose(fileID);

%% ------   A2S   -------
Dim.SzM     = SzM;


