%
% Reads space of shape attributes as saved under ShpIObin.h-w_SHPbinSpc
%
function [AUNI Nshp] = ReadShpBinSpc(fid)

nLev  = fread(fid, 1,    'int=>int');      % # of levels

AUNI  = cell(nLev,1);
Nshp  = zeros(nLev,1);
for l = 1:nLev
    
    [AUNI{l} nShp1] = ReadShpBinUni(fid);

    Nshp(l)     = nShp1;
end

end

