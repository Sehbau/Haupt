%
% Reads space of contour attributes as saved under CntIO.h-w_CntSpc
%
function [AUNI Ncnt] = ReadCntBinSpc(fid)

nLev  = fread(fid, 1,    'int=>int');      % # of levels
%[nLev Ncnt] = ReadDescSpcHead( fid );

AUNI  = cell(nLev,1);
ABIV  = cell(nLev,1);
for l = 1:nLev
    
    [AUNI{l} nCnt1] = ReadCntBinUni(fid);
    [ABIV{l} nCnt2] = ReadCntBinBiv(fid);
    
    assert( nCnt1==nCnt2, 'contour count not matching' );
    %nCnt1
    
end

end

