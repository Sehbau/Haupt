%
% Reads space of contour attributes as saved under CntIO.h-w_CntSpc
%
function [S] = ReadCntBinSpc(fid)

nLev  = fread(fid, 1,    'int=>int');      % # of levels
%[nLev Ncnt] = ReadDescSpcHead( fid );

S.AUNI  = cell(nLev,1);
S.ABIV  = cell(nLev,1);
S.APOSA = cell(nLev,1);
S.APOSQ = cell(nLev,1);
for l = 1:nLev
    
    [S.AUNI{l} nCnt1] = ReadCntBinUni(fid);
    [S.ABIV{l} nCnt2] = ReadCntBinBiv(fid);
    
    assert( nCnt1==nCnt2, 'contour count not matching' );
    %nCnt1
    
    S.APOSA{l}    = ReadAttPos( fid, 'float=>single' );
    S.APOSQ{l}    = ReadAttPos( fid, 'uint8=>uint8' );
    %S.APOS{l}.Vrt
    
end

end

