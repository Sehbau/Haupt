%
% Loads the bin values as saved under si_DescBin (DescIObin.h)
%
function [D Kt Hed] = LoadDbinImag(lfn) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----------------------   Header   ---------------------------
Hed         = ReadDescFileHead( fileID, 55 );

%% -----------------------   Spaces   ---------------------------
D.CNT   	= ReadCntBinSpc( fileID );
D.RSG    	= ReadRsgBinSpc( fileID );
D.ARC     	= ReadArcBinSpc( fileID );
D.STR     	= ReadStrBinSpc( fileID );

[D.SHP Kt.Nshp] = ReadShpBinSpc( fileID );

%% 
%D.Zug     	= ReadImgZug( fileID );
%D.Zug

%% -----------------------   Trailer   ---------------------------
idf         = fread(fileID, 1,  'int=>int'); % identifier

fclose(fileID);

if isempty(idf) || (idf~=888)
    fprintf('LoadDbinImag: file identifier not correct %d. Expected 888\n', idf);
    D.SHP
    Kt.Nshp
    pause('pausing in LoadDescImag');
end

%% ------   A2S   -------
%Kt.Ncnt
% cast to double: manipulation is easier in Matlab with double
Kt.nLev    = double(Hed.nLev);      
Kt.szV     = double(Hed.szV);
Kt.szH     = double(Hed.szH);
Kt.ntDsc   = double(Hed.ntDsc);

