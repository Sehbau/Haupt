%
% Loads the headers of the focus description file (as saved under
% si_FocDesc). 
%
% Full loading in LoadFocDesc.m
%
function [Floc Kt] = LoadFocDescHead(lfn) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----  header
HedV    = ReadDescFileHead( fileID, 11 ); % 11 for focus file
Floc    = ReadFocHead( fileID );

fclose(fileID);

%% ------   A2S   -------
%Kt.Ncnt
Kt.nLev    = double( HedV.nLev);      % its easier in Matlab with double
Kt.szV     = double( HedV.szV);
Kt.szH     = double( HedV.szH);
Kt.ntDsc   = double( HedV.ntDsc);
Kt.Floc    = Floc;
