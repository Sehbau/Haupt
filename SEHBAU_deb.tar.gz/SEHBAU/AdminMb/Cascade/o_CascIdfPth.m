%
% Filepaths for cascade identifier in CASCIDF.m
%
function [P] = o_CascIdfPth( pthMes )

if nargin==0
    pthMes = '';
end

P.fpMesHst      = [ pthMes 'Mes/CscHst.txt'];
P.fpMesKol      = [ pthMes 'Mes/CscKol.txt'];
P.fpMesVec      = [ pthMes 'Mes/CscVec.txt'];

P.fpMesDtyDis   = [ pthMes 'Mes/MesDtyDis.txt']; % unchangeable
P.fpMesDtySim   = [ pthMes 'Mes/MesDtySim.txt']; % unchangeable

%P.pthPrm        = [ pthOpr 'Params/' ];
%P.pthRgs        = [ pthOpr 'Regist/' ];



