%
% Wrapper routine for program mvecL, matching a list of description files.
%
% sa RennDscx
% cf MVECLXLfull.m
% 
% IN   fpVecT   testing (description) file, .dsc | .dsf
%      fiRegist list of description files, .dsc | .dsf (register)
%      Args     arguments (o_CmndArgs, o_MvecArgs) 
%               .fpPrm   parameter filename (3rd argument)
%               .fpMes   measurement file (3rd|4th argument)
%      pthProg  filepath of executable, ie. PthProg.mvecL
% OUT  Out       standard output
% 
function [Out] = RennMvecL( fpVecT, fpRegist, Args, pthProg )

if nargin==3, 
    pthProg = ''; 
end

fpProg  = [pthProg 'mvecL'];

if exist( fpProg, 'file')==2,
    error('Program path not correct: %s', fpProg);
end

% ensure order of parameter file and measurement file
if ~isempty( Args.fpPrm )

    cmnd = [ fpProg ' ' fpVecT ' ' fpRegist ' ' Args.fpPrm ...
             ' ' Args.fpMes ' ' Args.opt ];
else
    
    cmnd = [ fpProg ' ' fpVecT ' ' fpRegist ' ' Args.fpMes ...
             ' ' Args.opt ];
end

[status Out] = system( cmnd );                   % excecute program

%% ------  Status  ------
if status>0
    Out
    warning('something went wrong');
end

%% ------  Verify Proper Termination  -----
ixEOP = strfind( Out, 'EndOfProgram');

if isempty(ixEOP)
    fpVecT
    cmnd
    Out
    %[VT KtT] = LoadFocVect(pthVecT);
    % [VL KtL] = LoadFocVect(vecL); I dont have a single file but a list
    fprintf('RennMvecL: EOP not found\n'); 
    
     % sometimes it hangs completely when allocating memory:
    if isempty(Out)
        fprintf('Out empty. We try to debug: '); 
        cmnd    = [cmnd ' --bDISP 3'];
        [stu Out] = system( cmnd );           % excecute program again
        Out
    end
    pause();
end


