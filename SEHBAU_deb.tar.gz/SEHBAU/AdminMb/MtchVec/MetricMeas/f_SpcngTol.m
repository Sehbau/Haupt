% 
% Spacing for two points with tolerance. 
%
% We take Euclidean distance unless either coordinate difference is
% exceeding the tolerance.
%
%
%    -------------
%    | ------    |
%    |       --- |
%    -------------
%
%
% IN   v1, h1    vertical and horizontal position of box 1
%      v2, h2       "             "          "    of box 2
%      Tol       [2] vertical and horizontal tolerance
%
function s = f_SpcngTol( v1, h1, v2, h2, Tol )

dV  = abs( v1 - v2 );
dH  = abs( h1 - h2 );

if ( dV > Tol(1) ) || ( dH > Tol(2) )
    s   = inf;
else
    s   = sqrt( dV^2 + dH^2 );
end


end

