% 
% Box congruency using height and width. No position involved.
%
% cf f_FocToFoc.m
% 
% IN    h1, w1    height, width of box 1
%       h2, w2       "      "    "  "  2
%
function G = f_BoxCong( h1, w1, h2, w2 )

% --- mean dimensions
G.hgtMen = ( h1 + h2 ) / 2; 
G.wthMen = ( w1 + w2 ) / 2; 

%% -----  side ratios  -----
if h1 < h2
    rtHgt   = h1 / h2;
    %G.hgtSml  = h1;
else
    rtHgt   = h2 / h1;
    %G.hgtSml  = h2;
end

if w1 < w2
    rtWth   = w1 / w2;
    %G.wthSml  = w1;
else
    rtWth   = w2 / w1;
    %G.wthSml  = w2;
end

G.gnc   = rtHgt * rtWth;          	% congruence measure


% --- determine smaller/larger box
sz1     = h1 * w1;                	% size of first box
sz2     = h2 * w2;               	% size of second box

if sz1 > sz2,           
    G.szLrg = sz1;
    G.szSml = sz2;
else
    G.szLrg = sz2;
    G.szSml = sz1;
end

G.rtoArea  = G.szSml / G.szLrg;  	% ratio area

end

