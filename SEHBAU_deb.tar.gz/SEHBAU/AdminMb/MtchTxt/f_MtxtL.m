%
% Texture matching with texturegrams and bounding boxes for a list of
% images, one-versus-many. It uses executable mtxt1, loads the individual
% matchings and weights by values given in Wgt (wgt_TxtrMtch.m).
%
% IN    fpMtxt1  filepath of executable
%       fp1st    filepath of a saliency file
%       aFpSlc   register of saliency files
%       PthM     paths as generated with o_FileNameMeas.m
%       Wgt      wgt_TxtrMtch.m
% OUT   R        struct with fields for grid, bands and blobs
%
function R = f_MtxtL( fpMtxt1, fp1st, aFpSlc, PthM, Wgt )

dfLackBox   = 10e6;

nImg        = length( aFpSlc );
R.Grid      = zeros( nImg, 1, 'single');
R.Band      = zeros( nImg, 1, 'single');
R.Blob      = zeros( nImg, 1, 'single');
for i = 1:nImg,  
   
    fpOth  = aFpSlc{i};

    cmnd   = sprintf('%s %s %s %s %1.2f', ...
        fpMtxt1, fp1st, fpOth, PthM.User.txtStm, dfLackBox );
    
    if ispc, cmnd = u_PathToBackSlash( cmnd ); end
    
    f_CmndExec( cmnd );

    % --- Load Hists
    Mes.histTot         = LoadFltTxtEof( PthM.User.txtBand ); 
    [Mes.Blob nRedBlob] = LoadFltTxtEof( PthM.User.txtBlob );

    if nRedBlob<9
        Mes.Blob
    end
    
    Mes.GridBis = LoadFltTxtEof( PthM.Fixd.txtGridBis ); 
    Mes.BandSnk = LoadFltTxtEof( PthM.Fixd.txtBandSnk );
    Mes.BandWag = LoadFltTxtEof( PthM.Fixd.txtBandWag );

    % === Combine ===
    R.Grid(i)   = Mes.GridBis' * Wgt.Grid;
    %R.Grid(i)   = sum( Mes.grid );
    
    %BndSum      = Mes.BandWag;
    %BndSum      = Mes.BandSnk;
    BndSum      = Mes.BandSnk + Mes.BandWag;
    R.Band(i)   = BndSum' * Wgt.Band;

    % --- Blobs
    R.Blob(i)   = Mes.Blob' * Wgt.Blob;
    %R.Blob(i)   = mean( Mes.Blob );

    %fprintf('.');
    
end
