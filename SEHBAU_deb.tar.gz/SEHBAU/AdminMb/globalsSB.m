%
% Paths, directories and global variables for Sehbau
% 
% dirXXX    one directory/folder, or relative path
% pthXXX    absolute (full) path
% fipaXXX   file path: fullpath | relpath + filename 
%
% sa cc_Globals.m
%
%% ------   Root   ------
rootSehBau      = 'c:/klab/ppc/SEHBAU/';    % modify to match your path...
%rootSehBau      = 'fullpath/SEHBAU/';      % ...like this

%% ------   Dirs Util   ------
fprintf('globalsSB: adding paths to %s...', rootSehBau);

addpath( genpath( [rootSehBau 'AdminMb'] ) );

%% ------   Dirs to Programs (and Demos)   ------
DirProg.descExtr = 'DescExtr/';
DirProg.mtchVec  = 'MtchVec/';
DirProg.mtchHst  = 'MtchHst/';
DirProg.focSel   = 'FocSel/';
DirProg.shpExtr  = 'ShpExtr/';
DirProg.shpMtch  = 'ShpMtch/';
DirProg.plcRec   = 'DemoPlcRec/';
DirProg.sgrRGB   = 'DemoSgrRGB/';
DirProg.baum     = 'DemoBaum/';

%% ------   Paths to Programs (prepends root)   ------
% used to set field pthProg of administrative structure, ie.:
%     Admin         = u_CmndAdmin();
%     Admin.pthProg = PthProg.focSel;
%
aFnDirs     = fieldnames( DirProg );
for f = 1 : length(aFnDirs)
    fn      = aFnDirs{f};
    PthProg.(fn) = [ rootSehBau DirProg.(fn) ];
    
    if ispc
        PthProg.(fn)   = u_PathToBackSlash( PthProg.(fn) ); 
    end
end

%% ------   Full Filepaths of Binaries/Executables   ------
FipaExe.dscx    = [ PthProg.descExtr 'dscx' ];
FipaExe.collhimg= [ PthProg.descExtr 'collhimg' ];
FipaExe.d2vmx   = [ PthProg.descExtr 'd2vmx' ];
FipaExe.collvec = [ PthProg.descExtr 'collvec' ];
FipaExe.h2arr   = [ PthProg.descExtr 'h2arr' ];
%FipaExe.collsalc= [ PthProg.descExtr 'collsalc' ];

FipaExe.mvec1   = [ PthProg.mtchVec  'mvec1' ];
FipaExe.mvecL   = [ PthProg.mtchVec  'mvecL' ];
FipaExe.motvec  = [ PthProg.mtchVec  'motvec' ];

FipaExe.mhstL   = [ PthProg.mtchHst  'mhstL' ];
FipaExe.mkolL   = [ PthProg.mtchHst  'mkolL' ];

FipaExe.focdsc1 = [ PthProg.focSel   'focdsc1' ];
FipaExe.fochst1 = [ PthProg.focSel   'fochst1' ];
FipaExe.fochstL = [ PthProg.focSel   'fochstL' ];

FipaExe.ptchxL  = [ PthProg.shpExtr  'ptchxL' ];
FipaExe.shpx    = [ PthProg.shpExtr  'shpx' ];
FipaExe.mshp1   = [ PthProg.shpMtch  'mshp1' ];

FipaExe.sgrRGB   = [ PthProg.sgrRGB  'sgrRGB' ];
FipaExe.baumfarb = [ PthProg.baum    'baumfarb' ];
FipaExe.baumgrau = [ PthProg.baum    'baumgrau' ];

% -------  Verify Existence  --------
aFldNa    = fieldnames( FipaExe );
for p = 1:length(aFldNa)
    
    fn      = aFldNa{p};
    prna    = FipaExe.(fn);
    
    if ispc, prna = [prna '.exe'];  end % append '.exe' for windows
    
    if ~exist( prna, 'file' ),
        warning('program %s not found\n', FipaExe.(fn) ); 
    end
end

fprintf('done\n');


