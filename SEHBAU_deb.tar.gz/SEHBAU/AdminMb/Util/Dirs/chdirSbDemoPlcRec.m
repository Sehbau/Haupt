function [] = chdirSbDemoPlcRec()
    chdir('c:/klab/ppc/SEHBAU/DemoPlcRec');
end

