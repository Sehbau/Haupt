% 
% Color palettes.
%
% sa u_ColPalette
% 
function P = u_ColPalets( )

Col(1,:) = [255 255   0]; % yellow
Col(2,:) = [255 128   0]; % orange
Col(3,:) = [191 191   0]; % beige
Col(4,:) = [255 0     0]; % rot
Col(5,:) = [170 0   255]; % magenta
Col(6,:) = [0   255 255]; % cyan
Col(7,:) = [0   0   255]; % blue
Col(8,:) = [255 255 255]; % white
Col(9,:) = [0   255   0]; % green

Col(10,:) = [100 100   0]; % dark yellow
Col(11,:) = [220 220   0]; % somber yellow

P.Col      = Col ./ 255;
P.nEnt     = size(Col,2);

%% ----------   Fields   -------------
P.ylw       = Col(1,:) / 255;
P.ylwdrk    = Col(10,:) / 255;
P.ylwpale   = Col(11,:) / 255;
P.org       = Col(2,:) / 255;
% beige
P.red       = Col(4,:) / 255;
P.mag       = Col(5,:) / 255;
P.cyn       = Col(6,:) / 255;
P.blu       = Col(7,:) / 255;
% white
P.grn       = Col(9,:) / 255;
P.wth       = [255 255 255] / 255;
P.gry       = [128 128 128] / 255;

%% -----------   8 Oris   -----------
P.Ori       = zeros(8,3,'single');
P.Ori(1,:)  = P.red;
P.Ori(2,:)  = P.org;
P.Ori(3,:)  = P.mag;
P.Ori(4,:)  = P.cyn;
P.Ori(5,:)  = P.blu;
P.Ori(6,:)  = P.cyn;
P.Ori(7,:)  = P.mag;
P.Ori(8,:)  = P.org;
P.Ori(9,:)  = P.red;

%% -----------   3 Degrees   -----------
P.Deg3(1,:) = P.org;
P.Deg3(2,:) = P.mag;
P.Deg3(3,:) = P.red;
