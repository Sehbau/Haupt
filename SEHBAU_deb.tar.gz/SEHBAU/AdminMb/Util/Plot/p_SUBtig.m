%
% Subplots with tight spacing.
% 
% p_SUBtig( nPlots, ixPlt )
% p_SUBtig( nr, nc, ixPlt )
%
function H = p_SUBtig( varargin )

mrgLft = 0 ;
mrgRit = 0 ;
mrgTop = 0 ;
mrgBot = 0 ;

use_outer=0 ;

%% ---------   Margins   ------------
nPlts   = single( varargin{1} );
ixPlt   = varargin{2} ;

nn      = ceil(sqrt( nPlts )) ;
mm      = ceil( nPlts/nn ) ;

a=3 ;
nArgs = length(varargin) ;
if nArgs > 2
    
  if isa(varargin{3},'char')
    % called with nPlots and ixPlt
  else
    % called with nr, nc, ixPlt
    a       = 4 ;
    mm      = nPlts ;
    nn      = ixPlt ;
    ixPlt   = varargin{3} ;
  end
end

for a = a:2:nArgs
  opt=lower(varargin{a}) ;
  arg=varargin{a+1} ;
  switch opt
    case 'margin'
      mrgTop = arg ;
      mrgBot = arg ;
      mrgLft = arg ;
      mrgRit = arg ;
    case 'marginleft'
      mrgLft = arg ;      
    case 'marginright'
      mrgRit = arg ;      
    case 'margintop'
      mrgTop = arg ;      
    case 'marginbottom'
      mrgBot = arg ;            
    case 'spacing'
      mrgTop = arg/2 ;
      mrgBot = arg/2 ;
      mrgLft = arg/2 ;
      mrgRit = arg/2 ;
    case 'box'      
      switch lower(arg)
        case 'inner'
          use_outer = 0 ;
        case 'outer'
          use_outer = 1 ;
        otherwise
          error(['Box is either ''inner'' or ''outer''']) ;
      end
    otherwise
      error(['Uknown parameter ''', varargin{a}, '''.']) ;
  end      
end

% --------------------------------------------------------------------
%% ---------   Axes Positions   ---------
[Js, Is]   = ind2sub( [nn mm], ixPlt) ;
Is  = Is-1 ;
Js  = Js-1 ;

AxPos = [    Js * 1/nn       + mrgLft,...
            1 - Is * 1/mm - 1/mm + mrgBot,...
            1/nn - mrgLft - mrgRit, ...
            1/mm - mrgTop - mrgBot] ;

switch use_outer
    
  case 0
    H = findobj(gcf, 'Type', 'axes', 'Position', AxPos) ;
    if isempty(H) 
      H = axes('Position', AxPos) ;
    else
      axes(H) ;
    end
    
  case 1
    H = findobj(gcf, 'Type', 'axes', 'OuterPosition', AxPos) ;
    if isempty(H) 
      H = axes('ActivePositionProperty', 'outerposition',...
               'OuterPosition', AxPos) ;
    else
      axes(H) ;
    end
end    
