%
% Sets axes dimensions to those of the image/map in szM. This is for plots
% where the image itself (Irgb) has NOT been plotted. We therefore set the
% axis to matrix format.
%
% sa axgray
%
function [] = p_AxesToImgDim( szM )

axis ij;
    
set( gca, 'xlim', [ 1 szM(2) ] );
set( gca, 'ylim', [ 1 szM(1) ] );

end

