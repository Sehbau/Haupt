function [] = SaveFinaLstFromDir( aFina, pth, sfn )

error('use SaveFinaLstPrependPath (with *p*)');
    
end

