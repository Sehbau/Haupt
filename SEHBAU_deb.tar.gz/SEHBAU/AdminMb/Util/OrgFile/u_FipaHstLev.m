% 
% Filepaths for histograms of ONE leve.
%
function fipa = u_FipaHstLev(pth, lev)

fipa.all  = [pth '/HALLlev' num2str(lev)];

end

