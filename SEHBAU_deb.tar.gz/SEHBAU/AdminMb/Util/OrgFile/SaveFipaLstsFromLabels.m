%
% Generates and saves a list of filepaths for a set of labels, ie. zones.
%
% cf lvngRunMvecZon.m
%
function ALipas = SaveFipaLstsFromLabels( AFinas, pthFinas, aLab, fistLina )

nLab   = length( aLab );

ALipas = cell( nLab, 1);
for i = 1:nLab
    
    lipa = [ fistLina '_' aLab{i} '.txt' ];
    
    SaveFipaLstPrependPath( AFinas{i}, pthFinas, lipa );

    ALipas{i} = lipa;
    
end

    
end

