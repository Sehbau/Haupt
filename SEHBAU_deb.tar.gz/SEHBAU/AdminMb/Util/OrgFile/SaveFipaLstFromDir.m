function [] = SaveFipaLstFromDir( aFina, pth, sfn )

error('use SaveFipaLstPrependPath')
    
end

