%
% Loads as saved under BoundBoxIO.h-s_BboxL
%
% af LoadCCRccBboxUnv.m
%
function [ABbox nBox] = LoadBboxL(lfn) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----  Head  -----
nBox  = fscanf(fileID, '%d', 1);    
fprintf('[nBox %4d] ', nBox); DispLoad(lfn);

%% =====  BoundingBoxes  =====
nEnt  = 4;                   % number of bbox entries (>=4)
ABbox = zeros(nBox, nEnt, 'int16');
for l = 1:nBox
    
    Row = fscanf(fileID, '%d', nEnt);
    if length(Row)<nEnt, 
        warning('Row not completely read.');
        break; 
    end
    fscanf(fileID,'\n');
    ABbox(l,:) = Row;
end

%id = fscanf(fileID, '%d', 1); assert(id==222);

fclose(fileID);

