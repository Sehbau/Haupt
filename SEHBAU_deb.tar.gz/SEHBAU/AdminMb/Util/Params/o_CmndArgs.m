%
% Structure for passing command line arguments (parameters) responsible for
% descriptor extraction and matching. Verified with v_CmndArgs.m
%
% Elsewhere:
% - u_PrmFileGen for creating parameter files.
% - u_CmndArgsCat to concatenate args.
% - v_PrmFileExists for verifying parameter filenames exist.
%
% IN    process     'dscx' | 'mvec' | 'focsel'
% OUT   Args        structure
%
function Args = o_CmndArgs( proc )

Args.proc       = proc;
Args.fpPrm      = '';       % parameter file
Args.opt        = '';       % parameters/options given as arguments
%Args.bVerif = 0;

if strcmp( proc, 'dscx')

    Args.archit     = '';   % architecture
    Args.nFld       = 5;    % include this field

elseif strcmp( proc, 'mvec')

    Args.fpMes      = '';
    Args.nFld       = 5;

elseif strcmp( proc, 'focsel')
    
    Args.nFld   = 4;

else
    error('process %s not implemented\n', proc );
end    



end

