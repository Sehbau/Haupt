"""

Runs the python example scripts. See also exsbAll.m for comments.

Ensure that the main folder is called 'SEHBAU' (without suffix '_win|ubu...')

The example script for Matlab, exsbAll.m, has some more demos.

"""
import os, sys

finaPyExe = sys.executable

# Get current working directory
crrDir = os.getcwd()

# Check if we are in the SEHBAU directory
if len(crrDir) < 6 or not crrDir[-6:] == 'SEHBAU':
    print('Start from within folder SEHBAU') 
    os.chdir('c:/klab/ppc/SEHBAU/')  # Change to SEHBAU directory


# ------------------------------   Simple Examples   ------------------------------
os.chdir('DescExtr')

os.system(finaPyExe + ' exsbDscxSimp.py')

os.chdir('../MtchVec')

os.system(finaPyExe + ' exsbMatch.py')

os.chdir('..')


## -------------------------------------------------------------------------
#                       Descriptor Extraction  (dscx)
#  -------------------------------------------------------------------------
os.chdir('DescExtr')

os.system(finaPyExe + ' exsbDscxFull.py')

os.chdir('..')

## ----------------------------    Essentials   ---------------------------
os.chdir('Demos')

print('------------------   DEMOS   ----------------')

os.system(finaPyExe + ' exsbProposals.py')

os.system(finaPyExe + ' exsbSmlObjDet.py')

os.system(finaPyExe + ' exsbTxtrMaps.py')

os.system(finaPyExe + ' exsbSalBlobs.py')

os.system(finaPyExe + ' exsbCntPat.py') 

os.system(finaPyExe + ' exsbRegBon.py')
os.system(finaPyExe + ' exsbFormAxial.py') 
os.system(finaPyExe + ' exsbShape.py') 
os.system(finaPyExe + ' exsbSmlObjReg.py') 

os.chdir('..')


## ----------------------------    Histograms   ---------------------------
os.chdir('MtchHst')

os.system(finaPyExe + ' exsbCollHist.py')

os.chdir('..')


## ---------------------------------------------------------------------
#                            CONVERSIONS
#  ---------------------------------------------------------------------
os.chdir('DescExtr')

print('------------------   CONVERSIONS   ----------------')

os.system(finaPyExe + ' exsbH2arr.py')
os.system(finaPyExe + ' exsbD2vmx.py')

os.chdir('..')

## ---------------------------------------------------------------------
#                            FABRIC
#  ---------------------------------------------------------------------
os.chdir('DescProc')

print('------------------   FABRIC   ----------------')
os.system(finaPyExe + ' exsbDbin.py')
os.system(finaPyExe + ' exsbFabric.py')
os.system(finaPyExe + ' exsbFabricRec.py')
os.system(finaPyExe + ' exsbFabricRecKrnl.py')

os.chdir('..')

## ---------------------------------------------------------------------
#                            OBJ IDF
#  ---------------------------------------------------------------------
os.chdir('Demos')

print('------------------   OBJ IDF   ----------------')
os.system(finaPyExe + ' exsbObjIdf.py')
os.system(finaPyExe + ' exsbObjIdfLst.py')

os.chdir('..')

# ------------------------------   PlaceRecognition   ------------------------------

# The following is only useful if we continue with MATCHING demo scripts as in
# exsbAll.m (Matlab), otherwise one might move on to plcAll.py in directory
# DemoPlcRec.
if 0:
    os.chdir('DemoPlcRec')

    print('Demo Place Recognition (Essentials)');

    os.system(finaPyExe + ' plcDscx.py')
    os.system(finaPyExe + ' plcMtcImg.py')
    
    os.chdir('..')


print('exsbAll.py completed. Bereit fuer mehr.');
