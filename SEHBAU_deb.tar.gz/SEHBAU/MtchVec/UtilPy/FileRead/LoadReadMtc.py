"""

"""

import numpy as np


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   LoadMtchMes   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

see LoadMtchMes.m
"""
def LoadMtchMes( lfn, nImg ):
    try:
        with open(lfn, 'r') as fileID:

            Mes = np.zeros((nImg, 4), dtype=np.float32)

            for i in range(nImg):
                
                line   = fileID.readline()
                values = list(map(float, line.strip().split()))
                if len(values) != 4:
                    raise ValueError(f"Line {i+1} does not contain 4 values")
                Mes[i, :] = values
                
            return Mes
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not open file {lfn}")
