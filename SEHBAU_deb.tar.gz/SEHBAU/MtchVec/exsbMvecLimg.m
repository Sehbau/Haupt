% 
% Runs program mvecL (1-versus-List) for image output (dsc files). Two
% frames only.
%
% Assumes that exsbFrames.m was run (and better no other dsc files present)
%
clear;
run('../AdminMb/globalsSB');
cd( PthProg.mtchVec );

fipaImgTst  = 'Desc/Frm1.dsc';      % testing image 
aImgNaRep   = dir('Desc/Frm*.dsc'); % representation/reference image
fpRegist    = 'Regist/FrameVec.txt';
SaveFipaLstPrependPath( aImgNaRep, 'Desc/', fpRegist );
finaMes     = 'Mes/ImgExamp.txt';
finaPrm     = 'Params/PrmMtch_PosTolSlm.txt';

%% --------   Options   --------
OptK            = o_MvecArgs();
OptK.tolMtc     = 0.1;
OptK.wgtPos     = 0.5;
OptK.wgtRGB     = 0.8;
OptK.cntTolMtc  = 0.05;
OptK.rsgTolMtc  = 0.06;
OptK.arcTolMtc  = 0.07;
OptK.strTolMtc  = 0.08;
optS            = i_MvecArgs(OptK);

%% =========   Command   ========
finaProg    = 'mvecL';
cmndImg     = [finaProg ' ' fipaImgTst ' ' fpRegist ' ' finaPrm ' ' finaMes];
%cmndImg     = [cmndImg ' ' optS];

[Sts OutImg] = system(cmndImg);

%% -------   Load Matching Results   -------
MesImg       = LoadMtchMes( finaMes, length(aImgNaRep) );
DisDTY       = LoadMtchMESdty( 'Mes/MesDtyDis.txt' );
SimDTY       = LoadMtchMESdty( 'Mes/MesDtySim.txt' );

%% -------   Plot Metric Measurements   --------
figure(1); clf;
[nr nc] = deal(2,1);
subplot(nr,nc,1); bar( MesImg(:,1) ); title('Distances');
subplot(nr,nc,2); bar( MesImg(:,2) ); title('Similarities');




