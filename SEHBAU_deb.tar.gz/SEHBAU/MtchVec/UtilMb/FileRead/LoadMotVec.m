%
% Loads the motion vectors as saved under s_MotVecs in MotUtil.h
%
function [V] = LoadMotVec( lfn )

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----------------------   Header   ---------------------------
nMot    = fread(fileID, 1,  'int32=>int32'); % number of motion vectors

%% -----------------------   Vectors   ---------------------------
V.Ep1 	= fread(fileID, nMot*2,  'float=>single'); % endpoint 1
V.Ep2	= fread(fileID, nMot*2,  'float=>single'); % endpoint 2
V.Cen 	= fread(fileID, nMot*2,  'float=>single'); % center point

V.Mag 	= fread(fileID, nMot,    'float=>single'); % magnitude
V.Dir 	= fread(fileID, nMot,    'float=>single'); % direction

V.Mes 	= fread(fileID, nMot,    'float=>single'); % measurement

V.nMot 	= nMot;

%% -----------------------   Trailer   ---------------------------
idf    = fread(fileID, 1,  'int=>int'); % identifier

V.nRdg = fread(fileID, 1,  'int=>int'); % number of ridges
V.nRiv = fread(fileID, 1,  'int=>int'); 
V.nEdg = fread(fileID, 1,  'int=>int'); 
V.nSkl = fread(fileID, 1,  'int=>int'); 

V.nRsg = fread(fileID, 1,  'int=>int'); 
V.nArc = fread(fileID, 1,  'int=>int'); 
V.nStr = fread(fileID, 1,  'int=>int'); 

fclose(fileID);

if (idf~=7771)
    fprintf('file identifier not correct %d. Expected 7771\n', idf);

    pause('pausing in LoadDescVect');
end

V.Ep1 = reshape(V.Ep1, [2 nMot])';
V.Ep2 = reshape(V.Ep2, [2 nMot])';
V.Cen = reshape(V.Cen, [2 nMot])';

fprintf('Loaded %d vectors\n', nMot );

end
