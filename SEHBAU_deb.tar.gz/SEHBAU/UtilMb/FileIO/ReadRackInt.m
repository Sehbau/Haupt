%
% Same as ReadRackFlt but for integer.
%
% Used for reading histograms.
%
% cf ReadShpHist.m
%
function [ARR] = ReadRackInt( fid )

%% ----------   Header   ----------
nFld = fread(fid, 1, 'uint8=>int'); % number of fields (uchr!)
nElm = fread(fid, 1, 'int=>int');   % number of elements

%% ----------   Matrix   ----------
ARR = fread(fid, nElm * nFld, 'int32=>single'); % [nElm*nFld 1]

ARR = reshape(ARR, [nElm nFld]);            % [nFld nElm] quasi matrix


end

