%
% deprecated. Use u_StcArrToStcMap.m
%