%
% Same as ReadMtrxFlt but for integer.
%
% Used for reading histograms.
%
% cf ReadShpHist.m
%
function [ARR] = ReadMtrxInt( fid )

%% ----------   Header   ----------
nFet    = fread(fid, 1, 'uint8=>int'); % number of features
nObs    = fread(fid, 1, 'int=>int');   % number of observations

%% ----------   Matrix   ----------
ARR     = fread(fid, nObs * nFet, 'int32=>single'); 

%% ----------   reshape   ----------
ARR     = reshape(ARR, [nObs nFet]);


end

