REM runs a focus for image 1 and 2

.\focdsc1 Desc/img1.dsc 120 160 20 150 Focii\Tst --sVMX

REM focdsc1 Desc/img1.dsc 80 160 80 150 Focii\foc1

REM focdsc1 Desc/img2.dsc 80 160 80 150 Focii\foc2
REM focdsc1 Desc/aachen.dsc 80 160 80 150 Focii\aachen

REM fochst1 Desc/img1.hst 80 160 80 150 Focii\foc1
REM fochst1 Desc/img2.hst 80 160 80 150 Focii\foc2
