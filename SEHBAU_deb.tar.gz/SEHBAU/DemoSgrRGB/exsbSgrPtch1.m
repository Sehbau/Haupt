%
% Example for running segregation and loading its output.
%
clear;

% copy an image from folder DescExtr and place it to folder Imgs for
% convenience:
copyfile( '../DescExtr/Imgs/img2.jpg', 'Imgs/img2.jpg' );

% bright target value [200 200 200] to find bright regions (train
% silhouette)
[sts, Out] = system('sgrRGB Imgs/img2.jpg 200 200 200 --init 0');


%% ---------    Load Output   ---------
Fixt                = o_FileExtensions();

BW                  = LoadMapUch('Desc/Mlab.mpu');

bLoadSegWise        = 1;
[ABonFore nBonFore] = LoadBonPix(['Desc/BonFore' Fixt.bonPix], bLoadSegWise );
[ABonBack nBonBack] = LoadBonPix(['Desc/BonBack' Fixt.bonPix], bLoadSegWise );

[Arc Str]           = LoadCrvPrt(['Desc/CrvPrt' Fixt.cvps] );

szI                 = size(BW);

%% --------     Plot Boundaries   ------------
figure(1); clf;
imagesc(BW); hold on;
colTrg  = [1.0 0.0 0.0];
colOff  = [0.9 0.9 0.9];
for b = 1:nBonFore
    hb  = p_BoundPix1ToImg( ABonFore{b}, colTrg, 1);
end
for b = 1:nBonBack
    hb  = p_BoundPix1ToImg( ABonBack{b}, colOff, 1);
end

%% ---------    Plot Shape    --------
figure(4); clf; hold on;
p_ArcFromVect(Arc);
p_StrFromVect(Str);

%% ---------    Plot Shape on Irgb    --------
Ifore       = imread('Desc/Ifore.png');
figure(5); clf;
imagesc(Ifore); hold on;

p_StrFromVectScl(Str, szI);
p_ArcFromVectScl(Arc, szI);

