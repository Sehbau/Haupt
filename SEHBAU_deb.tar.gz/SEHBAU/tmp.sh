#!/bin/bash

# --- Conversion from windows to unix ---
# we eliminate carriage return and change permission
# tr -d "\r" < runEss.sh > tmp.sh
# chmod u+x runEss.sh
# bash ./runEss.sh

# --------------------------------------------------------------------------------
# 
# Essential functionality
# 

# -----  Descriptor Extraction for images 1 and 2  -----
cd DescExtr

./dscx Imgs/img1.jpg Desc/img1
./dscx Imgs/img2.jpg Desc/img2


# -----  Matching the two images  -----

# we change to matching directory, because we require directory 'Mes'
cd ../MtchVec || { echo "Failed to cd to ../MtchVec"; exit 1; }

./mvec1 ../DescExtr/Desc/img1.dsc ../DescExtr/Desc/img2.dsc

# return to directory for descriptor extraction
cd ../DescExtr || { echo "Failed to cd back to ../DescExtr"; exit 1; }


# -----  Converting output  -----

# we turn the histogram file into a single array 
./h2arr Desc/img1.hst Desc/img1

# we generate vector matrices
./d2vmx Desc/img1.dsc Desc/img1

# we generate bin-vector matrices from dsb file
./dbn2vmx Desc/img1.dsb Desc/img1

