"""Example for matching subspace (focus) fabric. Exhaustive only. No optimizations.

Assumes script exsbFabric.py has been run already, as we rely on the fabric
description.

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescProc.RennDbin import RennDbin, RennFabric, RennFbrc2Ar

from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Texture.FabricIO import *
from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.DescExtr.Hist.DescBinAnf import *
from AdminPy.Util.UtilImg import *


# ------------------------------   Paths   ------------------------------
strImg      = 'room.png'
fipaImg     = Path( 'Imgs/' + strImg )            # image path
fstmOut     = Path( 'Desc/' + strImg[:-4] )     # output file path
Fixt        = o_FileExtensions()
fpDSC       = o_FinaApndExtDscx( fstmOut, Fixt )

# ------------------------------   Load Output   ------------------------------
# we assume that script exsbFabric.py has alread been executed
dmy, HedFbc = LoadFabric( fpDSC.fbrc )  # we need the image size for scaling factors
FImg        = LoadFbrcArrays( fpDSC )   # FabricIO.py

BinEdg      = i_BinEdgFromLoad( HedFbc.NbinAtt, HedFbc.NbinDty )


# --------------------------------------------------------------------------------
#                         F O C U S   E X T R A C T I O N 
# --------------------------------------------------------------------------------
# we extract a subset of the fabric description
#top=160; bot=245; lef=450; rit=540 # black microwave/cabinet
#top=240; bot=320; lef=50; rit=95 # fire exstinguisher
#top=280; bot=315; lef=480; rit=520 # stove
#top=280; bot=320; lef=520; rit=580 # faucet
top=180; bot=260; lef=330; rit=390 # ventilator/towel dispenser
#top=0; bot=479; lef=0; rit=50
#top=0; bot=50; lef=0; rit=639
#top=0; bot=240; lef=0; rit=320
BoxRep   = i_Bbox( top, bot, lef, rit )

# --- the scaling factors
szImg    = [HedFbc.Hed.szV, HedFbc.Hed.szH]
PrmScl   = i_PrmFbrcFocScl( szImg[0], szImg[1] )

# --- extract focus fabric (subspace)
IXlin    = f_FbrcFocRngs( BoxRep, PrmScl ) # the linear indices
FFoc     = f_FbrcFocXtr( FImg, IXlin )     # extract

BoxRepUrg = u_BboxUnitRg( BoxRep, szImg ) # dimensions in unit range (UtilImg.py)


# -------------------------------------------------------------------
#                        M A T C H I N G
# -------------------------------------------------------------------
# we look for the above subspace 'FFoc' in the image fabric 'FImg'
import AdminPy.Mtch.MtchFbrcFlsh as mfbf
import AdminPy.Mtch.MtchFbrcUtil as mfbu

PrmIdf      = mfbf.i_FbrcIdfPrm()

# --- exhaustive, no acceleration / optimization
SCORexhst   = mfbf.Flsh1Exhst( FImg, FFoc, PrmIdf, BinEdg )

# ------------------------------   Locate   ------------------------------
import AdminPy.Recognize.RecUtil as rcut
import AdminPy.DescExtr.Features.PixAnf as px

# by default we take scores from hyperkolumn matching, but we also take from bias
# maps for comparison:
bTakeBis         = 0
ABoxPrdExHyk, _  = mfbu.u_OutlFromScorFbrc( SCORexhst, BoxRepUrg, szImg, FFoc.Dim.nLay )
ABoxPrdExBis, _  = mfbu.u_OutlFromScorFbrc( SCORexhst, BoxRepUrg, szImg, FFoc.Dim.nLay,
                                            bTakeBis )


# ------------------------------   Plot   ------------------------------
from PIL import Image
Irgb         = np.array(Image.open(fipaImg))

IptcRep      = u_IptchFromBbox( Irgb, BoxRep )  # the corresponding patch in the image

AIptchHyk    = rcut.u_IptchFromBoxLst( Irgb, ABoxPrdExHyk )
AIptchBis    = rcut.u_IptchFromBoxLst( Irgb, ABoxPrdExBis )

nLaySus      = FFoc.Dim.nLay

figHyk = 1
figBis = 2
mfbu.p_MapsScor( figHyk, Irgb, IptcRep, SCORexhst, nLaySus, AIptchHyk )
mfbu.p_MapsScor( figBis, Irgb, IptcRep, SCORexhst, nLaySus, AIptchBis )

# conclusion: looks better with hyperkolumns, but we still have an aliasing
# issue. From here on we continue with:
# - smoothening the maps and or combine them
# - higher resolution using fochst1
# - vectorial comparison using focvec1
