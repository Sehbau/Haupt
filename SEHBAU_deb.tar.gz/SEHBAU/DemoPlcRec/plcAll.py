"""

The equivalent of plcAll.m

"""

import os

os.system('python plcDscx.py')

## -----   Whole Image   -----
os.system('python plcMtcImg.py')
os.system('python plcMtcHstKol.py')
os.system('python plcCascIdf.py')

#os.system('python plcCorrSelf.py')   # does not exist yet


## -----   Focii using Zones   -----
os.system('python plcFocZon.py')

#os.system('python plcMtcZon1o1.py') # does not exist
os.system('python plcMtcZonLst.py')


## -----   Focii using Proposals   -----
os.system('python plcFocProp.py')
os.system('python plcMtcProp.py')


## -----   ShapeExtraction using ShapeProposals   -----
os.system('python plcShpExtr.py')
os.system('python plcMtcShp.py')  


## -----   Ego Motion   -----
os.system('python plcMotEgo.py')


print('Demo Place Recognition Completed')



