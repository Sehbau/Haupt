%
% Matching zone-wise for both vectors and histograms using one-on-one
% matching with binaries mvec1 and improvised histogram matching.
%
% Run first the script plcDscxZon.m to extract the descriptors.
%
% PREVIOUS   plcDscxZon.m
% CURRENT    plcMtcZon1o1.m
%
clear;
run('../globalsSB');

dirImg      = 'Imgs/';
dirDsc      = 'Desc/';          
dirFoc      = 'Focii/';

% change to window backslash
%dirDsc      = u_PathToBackSlash( dirDsc ); 
%dirFoc      = u_PathToBackSlash( dirFoc );

%% -----  List of Images  -----
aImg        = dir([dirImg '*.jpg']);

%% ==========   Zone Matching   ==========
% the image comparisons (one-indexing in Matlab)
Comp(1,:) = [1 2];          % most similar      
Comp(2,:) = [1 3];          
Comp(3,:) = [1 4];          
Comp(4,:) = [1 5];          % least similar
Comp(5,:) = [2 5];
nComp     = size(Comp,1);   % number of comparisons

% loads parameter nZon (saved last line in plcDscxZon.m)
load('Prm');                

[DisMes SmlMes] = deal(zeros(nComp, nZon));
DisHst      = zeros(nComp,nZon);

for c = 1:nComp

    % the image pair
    per     = Comp(c,:);
    imna1   = [aImg(per(1)).name(1:end-4) '_F'];
    imna2   = [aImg(per(2)).name(1:end-4) '_F'];
    
    for f = 1:nZon

        ixF = f-1;

        % ==========   Vectors   ==========
        dsc1    = [dirFoc imna1 num2str(ixF) '.dsf'];
        dsc2    = [dirFoc imna2 num2str(ixF) '.dsf'];
        cmnd    = [ FipaExe.mvec1 ' ' dsc1 ' ' dsc2];
        [sts OutMtc] = dos(cmnd);
        % OutMtc
        fprintf('.');
        
        % -----  Analyze Output  -----
        [StoI HedI]      = u_MtrMesSecs( OutMtc );
        [AMesDty mesTot] = u_MtrMesScnf( StoI );  
        
        DisMes(c,f) = mesTot.dis;
        SmlMes(c,f) = mesTot.sim;

        % ==========   Histograms   ==========
        hsf1        = [dirFoc imna1 num2str(ixF) '.hsf1'];
        hsf2        = [dirFoc imna2 num2str(ixF) '.hsf1'];
        Hst1        = LoadFocHist(hsf1);
        Hst2        = LoadFocHist(hsf2);
        % since we lack a matching program for hists one-on-one, I take a
        % simple distance in Matlab:
        DisHst(c,f) = f_HistMtc(Hst1, Hst2);
        
    end
    
end
%% -----   Combine Measures   -----
DisMul  = prod(DisMes,2);
SmlMul  = prod(SmlMes,2);
DisSum  = sum(DisMes,2);
SmlSum  = sum(SmlMes,2);

DisSumHst = sum(DisHst,2);

%% -----   Plot Results   -----
figure(4); [nr nc] = deal(3,2);
xLab = {'0-1' '0-2' '0-3' '0-6' '1-6'};

subplot(nr,nc,1);
bar(DisMul);
set(gca, 'xticklabel', xLab);
title('distance mult');

subplot(nr,nc,2);
bar(SmlMul);
set(gca, 'xticklabel', xLab);
title('similarity mult');

subplot(nr,nc,3);
bar(DisSum);
set(gca, 'xticklabel', xLab);
title('distance summed');

subplot(nr,nc,4);
bar(SmlSum);
set(gca, 'xticklabel', xLab);
title('similarity summed');

subplot(nr,nc,5);
bar(DisSumHst);
set(gca, 'xticklabel', xLab);
title('distance hist (improv)');



