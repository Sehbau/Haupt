"""

Collecting vector matrices. Assumes the description files are already present,
ie. see plcAll.py for sequence.

"""
import sys, subprocess
from pathlib import Path
import numpy as np

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.Register import *
from AdminPy.Collection.LoadCollVec import *
from AdminPy.Collection.CollManip import *

dscTyp      = 'skl'

# -----  paths  -----
pthOpr      = Path.cwd()
DirNames    = o_DirNames()
Pths        = o_DirsPrependPath( DirNames, pthOpr )

IxImg       = [0, 1, 2, 3, 6] # only for generating register file

# -----  register  -----
Fixt        = o_FileExtensions()   
RgstFinas   = o_RegistFileNames();
RgstFipas   = o_DirsPrependPath( RgstFinas, Pths.rgst )

dmy         = o_RegistSetSave( RgstFipas, Pths.desc, "", IxImg, Fixt, 7) 

v_RegistValid( RgstFipas.dsc )

FixtColl    = o_FileExtensColl();
FinaColl    = o_FileNameColl( Pths.coll, FixtColl )

# ------------------------------   Collect   ------------------------------
cmnd        = [ sb.FipaExe['collvec'], RgstFipas.dsc, dscTyp, str(Pths.coll)+'/' ]

Res         = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
OutColl     = Res.stdout + Res.stderr

# ------------------------------   Load   ------------------------------
COLLVEC, ntDsc, nDim = LoadCollVec(    Pths.coll, dscTyp )
CollLab, ntDsc2      = LoadCollVecLab( Pths.coll, dscTyp )

# NOTE: the image labels (numbers) in CollLab[:,1] correspond to the loop counter of
# program 'collvec' (starting with 0) and NOT to the indices as provided above with
# array 'IxImg'

# ------------------------------   Stats   ------------------------------
mxnDsc, MxnDsc  = u_CollDscCount( CollLab )
print( f"mxnDsc  {mxnDsc}" )
print( MxnDsc ) 

# ------------------------------   Plotting   ------------------------------
import matplotlib.pyplot as plt

plt.imshow(COLLVEC, aspect="auto", cmap="viridis")

plt.colorbar()

plt.xlabel("Attributes")
plt.ylabel("Desc")
plt.title( dscTyp )

plt.show(block=False)

