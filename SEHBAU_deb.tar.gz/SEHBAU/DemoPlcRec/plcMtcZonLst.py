"""

see plcMtcZonLst.m

"""
import sys, subprocess
sys.path.insert(0, '..')
from globalsSB import *
from CmndSupp import *
from Util import get_FinasPatWoExt
from SaveRegistFoc import SaveRegistFoc
from LoadData import *
from LoadReadMtc import *
import numpy as np


dirImg      = 'Imgs/'
dirFoc      = 'Focii/'
finaMesHst  = 'Mes/HstUor.txt'
finaMesVec  = 'Mes/Vec.txt'

aImgNa      = get_FinasPatWoExt( dirImg, '*.jpg' )
crrDir      = os.getcwd()

pthFoc      = os.path.join( crrDir, dirFoc )
    
aRgstHst    = SaveRegistFoc( pthFoc, aImgNa, 'hsf1' )
aRgstVec    = SaveRegistFoc( pthFoc, aImgNa, 'dsf' )

#for f in aRgstHst:
#    print( f )

# Combinations of image indices
aComb = [ [0,0], [0,1], [0,2], [0,3], [0,4], [1,4], ]
nComb = len(aComb)


from scipy.io import loadmat                    # load number of zones from previous script
Prm  = loadmat( 'Prm.mat' )

nZon = int( Prm['nZon'].squeeze() )

# nearest neighbor measurement matrices
DisHstNN = np.zeros((nComb, nZon), dtype=np.float32)
DisVecNN = np.zeros((nComb, nZon), dtype=np.float32)
SimVecNN = np.zeros((nComb, nZon), dtype=np.float32)

for c in range(nComb):

    per   = aComb[c]
    ix1   = per[0]
    ix2   = per[1]

    aFocHst = LoadTextLinewise( aRgstHst[ix1] )
    aFocVec = LoadTextLinewise( aRgstVec[ix1] )

    fpRgst2hst = aRgstHst[ix2]
    fpRgst2vec = aRgstVec[ix2]

    nFoc1 = len(aFocHst)+1         # we pretend not knowing the number of focii
    nFoc2 = nZon                   # ...and make an exception for simplicity

    # focus-to-focus measurement matrices
    DMhst = np.zeros((nFoc1, nFoc2), dtype=np.float32)
    DMvec = np.zeros((nFoc1, nFoc2), dtype=np.float32)
    SMvec = np.zeros((nFoc1, nFoc2), dtype=np.float32)

    for i in range(nZon):

        # ==========   Histograms   ==========
        hsf1    = aFocHst[0][i]
        cmnd    = FipaExe['mhstL'] + ' ' + hsf1 + ' ' + fpRgst2hst
        Res     = subprocess.run( cmnd, shell=True, capture_output=True, text=True )

        #print(Res.stdout)
        #[sts OutHst] = system(cmnd);
        #v_CmndExec( sts, OutHst, cmnd );
        #OutHst
        
        DMhst[i,:] = LoadFltTxt( finaMesHst, nFoc2 );
        #print(i)

        # ==========   Vectors   ==========
        dsc1    = aFocVec[0][i]
        cmnd    = FipaExe['mvecL'] + ' ' + dsc1 + ' ' + fpRgst2vec
        Res     = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
        
        #print(Res.stdout)
        MtcFoc  = LoadMtchMes( finaMesVec, nFoc2 );

        # focus-to-focus 
        DMvec[i,:] = MtcFoc[:,0];
        SMvec[i,:] = MtcFoc[:,1];        

    # --- focus nearest neibor measure ---
    DisHstNN[c,:] = np.min(DMhst, axis=1)
    DisVecNN[c,:] = np.min(DMvec, axis=1)
    SimVecNN[c,:] = np.max(SMvec, axis=1)        


## -----   Image Measure   -----
DisSumHst = np.sum(DisHstNN, axis=1)

DisMul = np.prod(DisVecNN, axis=1)
SmlMul = np.prod(SimVecNN, axis=1)
DisSum = np.sum(DisVecNN, axis=1)
SmlSum = np.sum(SimVecNN, axis=1)


# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt

xLab = ['0-0', '0-1', '0-2', '0-3', '0-6', '1-6']
xPos = np.arange(len(xLab))

fig, axs = plt.subplots(3, 2, figsize=(10, 10))
axs = axs.flatten()

axs[0].bar(xPos, DisMul)
axs[0].set_xticks(xPos)
axs[0].set_xticklabels(xLab)
axs[0].set_title('dist. mult.')

axs[1].bar(xPos, np.log(SmlMul))
axs[1].set_xticks(xPos)
axs[1].set_xticklabels(xLab)
axs[1].set_ylabel('log simi mult')
axs[1].set_title('simi. mult.')

axs[2].bar(xPos, DisSum)
axs[2].set_xticks(xPos)
axs[2].set_xticklabels(xLab)
axs[2].set_title('dist. summed')

axs[3].bar(xPos, np.log(SmlSum))
axs[3].set_xticks(xPos)
axs[3].set_xticklabels(xLab)
axs[3].set_ylabel('log simi sumd')
axs[3].set_title('simi. summed')

axs[4].bar(xPos, DisSumHst)
axs[4].set_xticks(xPos)
axs[4].set_xticklabels(xLab)
axs[4].set_title('distance hist')

# Leave the 6th subplot empty
axs[5].axis('off')

plt.figure(6)
plt.tight_layout()
plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)
