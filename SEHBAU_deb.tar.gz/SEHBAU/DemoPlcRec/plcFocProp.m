%
% Descriptor selection from proposals (.slc, .qprp). 
%
% Run first the script plcDscx.m to extract the descriptors.
%
% PREVIOUS  plcDscx.m
% CURRENT   plcFocProp.m
% NEXT      plcMtcZon1o1.m
%
clear;
run('../globalsSB');

dirImg      = 'Imgs/';
dirDsc      = 'Desc/';
dirFoc      = 'Focii/';

% change to window backslash
if ispc
    %dirDsc  = u_PathToBackSlash( dirDsc ); % not necessary I think
    dirFoc  = u_PathToBackSlash( dirFoc ); 
end
Fext        = o_FileExtensions();

%% -----  List of Images  -----
aDsc        = dir( [dirDsc '*.dsc'] );
nImg        = length(aDsc);

%% ----------   Focus Extraction Per Image  -----------
optS    = '';
for i = 1:nImg
    
    imgNam  = aDsc(i).name(1:end-4);
    fpDsc 	= [dirDsc imgNam Fext.dsc ]; % vector file name 

    fpSal   = [dirDsc imgNam Fext.salc];
    fpPrp   = [dirDsc imgNam Fext.qbbx];

    % load saliency and proposals
    [Txa Shp Ens Dsc]   = LoadDescSalc( fpSal );
    [QBbx Nr]           = LoadDescPropBbox( fpPrp );

    % we choose general shapes from the proposal file
    BbxSel      = QBbx.ShpGen;
    nBbx        = size(BbxSel,1);
    
    % identify the large ones (at least 17*17 pixels)
    BxHgt       = BbxSel(:,2) - BbxSel(:,1);    % box height
    BxWth       = BbxSel(:,4) - BbxSel(:,3);    % box width
    IxLrg       = find( BxHgt>16 & BxWth>16 );
    nLrg        = length(IxLrg);
    
    for l = 1:nLrg
        
        f       = IxLrg(l);
        
        Bbx     = BbxSel(f,:);
        strBbx  = sprintf('%d %d %d %d', Bbx(1), Bbx(2), Bbx(3), Bbx(4));
        fpOut   = [dirFoc imgNam '_F' num2str(f-1)];
        
        % -----  Vectors:
        cmnd   	= [FipaExe.focdsc1 ' ' fpDsc ' ' strBbx ' ' fpOut];
        [Sts OutFocv] = system(cmnd);     % excecute program
        if Sts>0
            OutFocv
            error('failure'); 
        end

        % -----  Histograms:
        cmnd   	= [FipaExe.fochst1 ' ' fpDsc ' ' strBbx ' ' fpOut];
        [Sts OutFoch] = system(cmnd);     % excecute program
        if Sts>0
            OutFoch
            error('failure'); 
        end
        
        fprintf('.');
    end
end





