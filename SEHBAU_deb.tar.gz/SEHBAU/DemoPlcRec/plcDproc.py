"""

More descriptor processing: binning

More details in plcDproc.m

"""
import sys, subprocess, os, glob
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Orga.SaveFipaLst import SaveFipaLstPrependPath
from AdminPy.DescExtr.Hist.DescBinAnf import DispBnumSpat
from AdminPy.Collection.LoadCollHist import LoadCollHist

# --- directories
DirNames    = o_DirNames()
Fixt        = o_FileExtensions()   

fipaDbin    = Path( sb.FipaExe['dbin'] )      # file path of program binary
fipaDemo    = Path( '../DemoPlcRec' )

# --- list of image files
aDsc        = list( Path(DirNames.desc).glob( '*' + Fixt.dsc ) )
nImg        = len( aDsc )

# I need to change dir, because dbin requires parameter files
os.chdir( sb.PthProg['descProc'] )  

# ------------------------------   LOOP IMAGES   ------------------------------
for fipaDsc in aDsc:

    outNast = fipaDsc.stem;
    
    fipsBin = Path(DirNames.dbin) / outNast                  # output filestem
    
    cmnd    = [ fipaDbin, fipaDemo / fipaDsc, fipaDemo / fipsBin ]
    
    Res     = subprocess.run(cmnd, shell=True, capture_output=True, text=True)
    
    sb.Util.v_CmndExec( Res )

    sb.Util.printDotProg()


# ------------------------------   Collecting   ------------------------------
os.chdir( fipaDemo )

aHstNa     = glob.glob("Dbin/*.hsspa")    # representation/reference image
finaLst    = 'Regist/FinasHst.txt';
SaveFipaLstPrependPath( aHstNa, '', finaLst )

fipsColl   = 'Coll/COLLHST';

# -----  build, execute, verify command  -----
cmnd       = f"{sb.FipaExe['collhimg']} {finaLst} {fipsColl}"

Res        = subprocess.run( cmnd, shell=True, capture_output=True, text=True)

sb.Util.v_CmndExec( Res )

# ----------   Load Collection   ----------
Fixt       = o_FileExtensColl()

HSTC, Nbin = LoadCollHist( fipsColl + Fixt.hsspa )

DispBnumSpat( Nbin )

print(np.sum(HSTC))



