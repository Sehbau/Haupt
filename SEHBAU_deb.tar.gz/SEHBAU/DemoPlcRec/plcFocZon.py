"""

Descriptor extraction for place recognition demo with zones.

More details in plcFocZon.m

"""
import sys, glob, subprocess
sys.path.insert(0, '..')
from globalsSB import *
from CmndSupp import *
import imageio.v3 as iio
from BboxesZones import u_ZonesBboxes

dirImg      = 'Imgs/'
dirDsc      = 'Desc/'
dirFoc      = 'Focii/'

if bOSisWin:
    dirFoc.replace('/', '\\')

# --- List of image files
aImg        = glob.glob( os.path.join( dirImg, '*.jpg' ) )

Irgb        = iio.imread( aImg[0] )

# --- Zones
szI         = Irgb.shape[0:2]
ZonesAll    = u_ZonesBboxes( szI )              # a collection of zone partitions
ZonesSel    = ZonesAll['Sep3']['Vert']          # we choose one set of partitions
nZon        = ZonesSel.nZon

binFocDsc1  = FipaExe['focdsc1']                # file path of program binary
binFocHst1  = FipaExe['fochst1']

## ----------   Zones (Focus) Extraction Per Image  -----------
for pthImg in aImg:

    imgName = os.path.basename( pthImg )[:-4]    # remove .jpg extension
    
    dscf    = os.path.join( dirDsc, imgName + '.dsc' )

    for f in range(nZon):
    
        Bbx    = ZonesSel.Bbox[f,:]
        BbxStr = f"{Bbx[0]} {Bbx[1]} {Bbx[2]} {Bbx[3]}"

        outf   = f"{dirFoc}{imgName}_F{f}"
        #outf   = os.path.join( dirFoc, f"{imgName}_F{f}" )

        # -----  Vectors:
        cmnd   = binFocDsc1 + ' ' + dscf + ' ' + BbxStr + ' ' + outf
        #cmnd   = f'"{fipaBinDscx}" "{pthImg}" "{pthOut}" {optS}' # works as well

        Res    = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
        v_CmndExec( Res )

        # -----  Histograms:
        cmnd   = binFocHst1 + ' ' + dscf + ' ' + BbxStr + ' ' + outf
        Res    = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
        v_CmndExec( Res )

        
# ----------   Save Prms   ----------
from scipy.io import savemat
savemat( 'Prm.mat', {'nZon': nZon} ) 

print('plcFocZon fertig.')
