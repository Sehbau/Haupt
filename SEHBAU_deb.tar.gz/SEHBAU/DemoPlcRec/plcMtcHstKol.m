% 
% Runs program binaries mhstL and mkolL (1-versus-List) for the images of
% the place recognition set. Assumes that demo plcDscx.m has already been
% executed.
%
% This script is to be run from directory 'DemoPlcRec'
%
clear;
run('../globalsSB');

%% ----------   Prepare Input Args   --------
progMhst    = '../MtchHst/mhstL';
progMkol    = '../MtchHst/mkolL';

if ispc
    progMhst = u_PathToBackSlash(progMhst);
    progMkol = u_PathToBackSlash(progMkol);
end

dirDesc     = 'Desc/';

pthHstTst   = [dirDesc '0000000.hst'];    % testing image 
pthKolTst   = [dirDesc '0000000.kol'];    % testing image 

aHstRep     = dir([ dirDesc '*.hst']);    % representation/reference image
aKolRep     = dir([ dirDesc '*.kol']);    % representation/reference image

finaRgstHst = 'Regist/FinasHst.txt';
finaRgstKol = 'Regist/FinasKol.txt';

SaveFipaLstPrependPath( aHstRep, dirDesc, finaRgstHst );
SaveFipaLstPrependPath( aKolRep, dirDesc, finaRgstKol );

finaMesHst  = 'Mes/HstLst.txt';
finaMesHuor = 'Mes/HstUor.txt';             % cannot be changed
finaMesKol  = 'Mes/KolLst.txt';
finaMesKuor = 'Mes/KolUor.txt';             % cannot be changed

%% =========   Command Mhst/Mkol  ========
cmndHst      = [progMhst ' ' pthHstTst ' ' finaRgstHst ' ' finaMesHst];
[Sts OutHst] = system( cmndHst );

cmndKol      = [progMkol ' ' pthKolTst ' ' finaRgstKol ' ' finaMesKol];
[Sts OutKol] = system( cmndKol );

%% -------   Load Matching Results   -------
nRep         = length(aHstRep);

[OrdHis DisHisOrd] = LoadSortFltTxt( finaMesHst, nRep );
[OrdKol DisKolOrd] = LoadSortFltTxt( finaMesKol, nRep );

DisHisUor    = LoadFltTxt( finaMesHuor, nRep );
DisKolUor    = LoadFltTxt( finaMesKuor, nRep );

%% -------   Plot   -------
figure(2); clf;
xLab = {'0-0' '0-1' '0-2' '0-3' '0-6'};

subplot(2,1,1);
bar( DisHisUor );
set(gca, 'xticklabel', xLab);
ylabel('Distances');
title('Histogram Differences');

subplot(2,1,2);
bar( DisKolUor );
set(gca, 'xticklabel', xLab);
ylabel('Distances');
title('Kolumn Differences');






