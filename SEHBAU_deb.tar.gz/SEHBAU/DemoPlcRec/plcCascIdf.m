%
% Cascade identifier. Runs all-vs-all building a distance matrix.
%
% Run first the script plcDscx.m to extract the descriptors.
%
% PREVIOUS  plcDscx.m
% CURRENT   plcCascIdf.m
% NEXT      
%
clear;
run('../AdminMb/globalsSB');

dirImg      = 'Imgs/';
pthOpr      = [pwd '/'];            % path of operation
pthRgst     = [pthOpr 'Regist/'];              
pthDsc      = [pthOpr 'Desc/'];              
prmMtcTyp   = '';

%% -----  the images  -----
aImg        = dir( [dirImg '*.jpg'] );
nImg        = length(aImg);
IxImg       = [0 1 2 3 6];

%% -----  parameters  -----
%preStgy     = 'txtg1st';        % texture first
preStgy     = 'hist1st';        % histogram first
%preStgy     = 'kolm1st';        % kolumn first
%preStgy     = 'ens';        % ensemble

Prms        = o_CascIdfPrm( nImg, 0.5, preStgy );
Admn        = o_CascIdfPth( );

%% -----  arguments command  -----
ArgsMvec        = o_CmndArgs( 'mvec' );
pthPrmFile      = [ PthProg.mtchVec 'Params/' ];
ArgsMvec.fpPrm  = u_PrmFileGen( prmMtcTyp, pthPrmFile, 'Mtch', 1 );
%ArgsMvec.opt    = '--dty cnt';
%ArgsMvec.opt    = '--dty rsg';
v_CmndArgs( ArgsMvec, '' );

ArgsCasc.Vec	= ArgsMvec; % u_CmndArgsCat( Args );
ArgsCasc.Hst    = '';

%% -----  register  -----
Fixt        = o_FileExtensions();
Rgst        = o_RegistSetSave( pthRgst, pthDsc, '', IxImg, Fixt, 7 );

v_RegistValid( Rgst.fpaDsc );

%% ====================   MTCHCSC   ======================
fprintf('MTCHCSC  %s  prpPre %0.1f  nPre %d\n', Prms.stgy,...
    Prms.prpPre, Prms.nPre );

% --- ARRAYS for total and desctypes
AMesTot = cell(nImg,1);
AOrdPre = cell(nImg,1);
AMESdis = cell(nImg,1);
AMESsim = cell(nImg,1);
[ORDdis ORDsim] = deal( zeros(nImg, Prms.nPre, 'single') );
[AORDDtyDis AORDDtySim] = deal(cell(nImg,1));
% --- MATRICES for total 
DM      = zeros(nImg, nImg, 'single');
SM      = DM;
NNdis   = zeros(nImg,Prms.nPre,'single');
NNsim   = zeros(nImg,Prms.nPre,'single');
for i = 1:nImg,  
   
    ixi     = IxImg(i);

    fnQuy   = [pthDsc Rgst.aVec{i}(1:end-4)]; % I could also load the register

    FpQuy   = o_FinaApndExtRepFrmt( fnQuy );
    
    [Res Sto Fll] = CASCIDF( FipaExe, FpQuy, Rgst, Admn, ArgsCasc, Prms );
    
    if i==1,
        pso_OptUnrec( Sto.Mvec );
    end
    
    % --- reduced (only indices)
    AOrdPre{i}  = Res.OrdPre;
    
    ORDdis(i,:) = Res.OrdDis;
    ORDsim(i,:) = Res.OrdSim;
    
    AORDDtyDis{i} = Res.ORDDty.Dis;
    AORDDtySim{i} = Res.ORDDty.Sim;

    % --- full
    AMesTot{i} = Fll.MesTot;
    AMESdis{i} = Fll.MESdis;
    AMESsim{i} = Fll.MESsim;
    
    DM(i, Res.OrdDis )  = Fll.MesTot(:,1);
    SM(i, Res.OrdSim )  = Fll.MesTot(:,2);

    NNdis(i,:)   = Fll.MesTot(:,1); % nearest neighbors distance
    NNsim(i,:)   = Fll.MesTot(:,2); % nearest neighbors similarity

    fprintf('.');
    
end
fprintf('done\n');

%% ---------------   NN other   ---------------
% exclude measurement to itself
NNdisOth    = NNdis(:,2:end);
NNsimOth    = NNsim(:,2:end);

%% ---------------   Plot   --------------
figure(1); clf;
subplot(1,2,1);
imagesc(DM); colorbar; title('distance');
subplot(1,2,2);
imagesc(SM); colorbar; title('similarity');

