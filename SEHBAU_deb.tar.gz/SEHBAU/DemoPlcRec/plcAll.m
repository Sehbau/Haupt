%
% Runs all scripts for place recognition
%
% Runs 5 downsized frames from the living room collection.
%

plcDscx             % descriptor extraction

%% -----   (Whole) Image   -----
plcMtcImg           % vector matching
plcMtcHstKol     	% histogram and kolumn matching

%% -----   Focii using Zones   -----
plcFocZon           % uses focdsc1 and fochst1
plcMtcZon1o1        % uses mvec1 and improvised hist-distances
plcMtcZonLst        % uses mvecL, mhstL

% improvement (not deployed yet)
% plcFocZonHst.m
% plcMtcZonHst.m

%% -----   Focii using Proposals   -----
plcFocProp
% plcMtcProp % in development
