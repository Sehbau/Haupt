"""

Descriptor extraction for place recognition demo.

More details in plcDscx.m

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')
import AdminPy as sb

# --- directories
dirImg      = Path('Imgs/')
dirDsc      = Path('Desc/')
fipaDscx    = Path(sb.FipaExe['dscx'])        # file path of program binary

# --- list of image files
aImg        = list( dirImg.glob("*.jpg") )
nImg        = len(aImg)

# --- extraction options
prmFile     = Path('../DescExtr/Params/PrmDesc_Gerust.txt')
optS        = [ '--saveKol', '--saveProp' ]

# ------------------------------   LOOP IMAGES   ------------------------------
for fipaImg in aImg:

    fipsOut = dirDsc / fipaImg.stem
    
    cmnd   = [ fipaDscx, fipaImg, fipsOut, prmFile ] + optS
    
    Res    = subprocess.run(cmnd, shell=True, capture_output=True, text=True)
    
    sb.Util.v_CmndExec( Res )

    sb.Util.printDotProg()

