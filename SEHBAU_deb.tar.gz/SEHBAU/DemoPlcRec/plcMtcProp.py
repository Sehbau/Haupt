"""

see plcMtcZonLst.m

"""
import sys, subprocess, os
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')
import AdminPy as sb

dirImg      = Path( 'Imgs/' )
dirFoc      = Path( 'Focii/')
dirRegist   = Path( 'Regist/' )
finaMesHst  = 'Mes/HstUor.txt'
finaMesVec  = 'Mes/Vec.txt'

aImgNa      = list( dirImg.glob( '*.jpg' ) ) # sb.Util.get_FinasPatWoExt( dirImg, '*.jpg' )
crrDir      = Path.cwd()

pthaFoc     = crrDir / dirFoc
pthaRgst    = crrDir / dirRegist

neLev       = 5
aRgstHst    = sb.FocSel.SaveRegistFoc( pthaFoc, aImgNa, pthaRgst, 'hsf1', 0 )
aRgstDsc    = sb.FocSel.SaveRegistFoc( pthaFoc, aImgNa, pthaRgst, 'dsf', neLev )

#for f in aRgstHst:
#    print( f )

os.chdir( sb.PthProg['mtchVec'] )

# Combinations of image indices
aComb = [ [0,0], [0,1], [0,2], [0,3], [0,4], [1,4], ]
nComb = len(aComb)


# nearest neighbor measurement matrices
MesImg     = np.zeros((nComb), dtype=np.float32)
DisSumHst  = MesImg.copy()
DisMul     = MesImg.copy()
SmlMul     = MesImg.copy()
DisSum     = MesImg.copy()
SmlSum     = MesImg.copy()
BoxImg     = MesImg.copy()

for c in range(nComb):

    per   = aComb[c]
    ix1   = per[0]
    ix2   = per[1]

    print( f'--------------------  {ix1} {ix2}  -----------------------' )

    aFocHst, nFoc1 = sb.Util.LoadTextLinewise( aRgstHst[ix1] )

    fpRgst2hst     = aRgstHst[ix2]
    aDmy, nFoc2    = sb.Util.LoadTextLinewise( fpRgst2hst )

    # ==========   Histograms   ==========
    print( f'Hists {nFoc1} x {nFoc2}...' )
    DMhst = np.zeros((nFoc1, nFoc2), dtype=np.float32)
    for f in range(nFoc1):

        fpHst   = aFocHst[f]
        cmnd    = [ sb.FipaExe['mhstL'], fpHst, fpRgst2hst ]
        #cmnd    = sb.FipaExe['mhstL'] + ' ' + fpHst + ' ' + fpRgst2hst
        
        Res     = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
        sb.Util.v_CmndExec( Res )
        
        DMhst[f,:] = sb.Util.LoadFltTxt( finaMesHst, nFoc2 )

    print('done')
    #print( DMhst )

    # ==========   Vectors   ==========
    Args         = sb.Util.dclsArgsCmnd()
#    pthProg      = sb.FipaExe['mvec1']
    
    BoxLev  = np.zeros((neLev, 1), dtype=np.float32)
    DisLev  = np.full( (neLev, 1), 5,      dtype=np.float32)
    SimLev  = np.full( (neLev, 1), np.nan, dtype=np.float32)
    BlevPrz = np.zeros((neLev, 1), dtype=bool)      
    print( f'Vects on max {neLev} levs...' )
    for l in range(neLev):

        if not aRgstDsc[ix1][l]:
            continue
        if not aRgstDsc[ix2][l]:
            continue

        BlevPrz[l] = True
        
        aFocVec1, n1 = sb.Util.LoadTextLinewise( aRgstDsc[ix1][l] )
        aFocVec2, n2 = sb.Util.LoadTextLinewise( aRgstDsc[ix2][l] )

        bDISP       = 1;
        Mes, M      = sb.MtchVec.MFOCTOFOC( aFocVec1, aFocVec2, bDISP )

        BoxLev[l]   = Mes.simBox;
        DisLev[l]   = Mes.disVecMul
        SimLev[l]   = Mes.simVecMen
        
    IxLev     = np.where( BlevPrz )[0]
    if IxLev.size > 0:  nLevFound = IxLev[-1]+1 
    else:               nLevFound = None

    ## -----   Image Measures   -----
    DisHstNN     = np.min( DMhst, axis=1 )   
    DisSumHst[c] = np.sum( DisHstNN )        

    RgLev       = np.arange(0, nLevFound )
    BoxLev      = BoxLev[RgLev]
    DisLev      = DisLev[RgLev]
    SimLev      = SimLev[RgLev]
    #print(BoxLev)
    #print(DisLev)

    BoxImg[c]   = np.mean( BoxLev )
    DisSum[c]   = np.mean( DisLev )
    SmlSum[c]   = np.mean( SimLev )

    DisMul[c]   = np.prod( DisLev )

    SimLev[SimLev==0] = 1                       # set to one to avoid zeroing by non-matches
    SmlMul[c]   = np.prod( SimLev )

    print( f'____ done (nLevFound {nLevFound})' )
    
# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt

xLab = ['0-0', '0-1', '0-2', '0-3', '0-6', '1-6']
xPos = np.arange(len(xLab))

fig, axs = plt.subplots(3, 2, figsize=(10, 10))
axs = axs.flatten()

axs[0].bar(xPos, DisMul)
axs[0].set_xticks(xPos)
axs[0].set_xticklabels(xLab)
axs[0].set_title('dist. mult.')

axs[1].bar(xPos, np.log(SmlMul))
axs[1].set_xticks(xPos)
axs[1].set_xticklabels(xLab)
axs[1].set_ylabel('log simi mult')
axs[1].set_title('simi. mult.')

axs[2].bar(xPos, DisSum)
axs[2].set_xticks(xPos)
axs[2].set_xticklabels(xLab)
axs[2].set_title('dist. summed')

axs[3].bar(xPos, np.log(SmlSum))
axs[3].set_xticks(xPos)
axs[3].set_xticklabels(xLab)
axs[3].set_ylabel('log simi sumd')
axs[3].set_title('simi. summed')

axs[4].bar(xPos, DisSumHst)
axs[4].set_xticks(xPos)
axs[4].set_xticklabels(xLab)
axs[4].set_title('distance hist')

axs[5].bar(xPos, BoxImg)
axs[5].set_xticks(xPos)
axs[5].set_xticklabels(xLab)
axs[5].set_title('box mes')

plt.figure
plt.tight_layout()
plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)

print("plcMtcProp completed.")
