"""

Plots descriptors from attribute values.

Only 4 descriptors so far.

def p_CntFromAtts( CNT, szM=None, col='y', ax=None ):
def p_ArcPts( ARC ): 
def p_TtrgLst( TL, szM ):
def p_ShpPoleFromPos( SHP, szI=None, ax=None ):


"""
import numpy as np

import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse

from AdminPy.DescExtr.DescFile.LoadDescription import u_TtrgRtrv1



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_CntFromAtts   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

see p_CntAtt.m

"""
def p_CntFromAtts( CNT, szM=None, col='y', ax=None ):

    if ax is None:
        ax = plt.gca()

    bUnitRng = szM is None
    bColRGB  = szM is None

    if not bUnitRng:
        szV, szH = szM[0], szM[1]

    for i in range(CNT.nCnt):

        ori = CNT.Ori[i]
        les = CNT.Les[i]
        ctr = CNT.Ctr[i]

        yrd = np.sin(ori) * les / 2
        xrd = np.cos(ori) * les / 2

        if bUnitRng:
            posV   = 1 - CNT.Pos.Vrt[i]
            posH   = CNT.Pos.Hor[i]
            xVals  = [posH - xrd, posH + xrd]
            yVals  = [posV + yrd, posV - yrd]
        else:
            xrd   *= szH
            yrd   *= szV
            posV   = CNT.Pos.Vrt[i] * szV
            posH   = CNT.Pos.Hor[i] * szH
            xVals  = [posH - xrd, posH + xrd]
            yVals  = [posV - yrd, posV + yrd]

        if bColRGB:
            rgb = [ CNT.RGB.Red[i], CNT.RGB.Grn[i], CNT.RGB.Blu[i] ]
        else:
            rgb = col if isinstance(col, (list, tuple)) else {'y': [1,1,0]}.get(col, [1,1,0])

        ax.plot( xVals, yVals, color=rgb, linewidth=0.2 + 2 * ctr)    


        
""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_ArcPts   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

see p_ArcAtt.m

"""
def p_ArcPts( ARC ): #, szM=None, col='y', ax=None ):

    for i in range(ARC.nArc):
        
        # endpoint - peakpoint - endpoint
        Y = [ ARC.Pts.Ep1[i][0], ARC.Pts.Btw[i][0], ARC.Pts.Ep2[i][0] ]
        X = [ ARC.Pts.Ep1[i][1], ARC.Pts.Btw[i][1], ARC.Pts.Ep2[i][1] ]

        # Add color
        red   = ARC.RGB.Red[i]
        grn   = ARC.RGB.Grn[i]
        blu   = ARC.RGB.Blu[i]
        color = (red, grn, blu)
        color = [ 1, 1, 0 ]

        # Plot the arc
        hl, = plt.plot( X, Y, color=color )

        # Emphasize peakpoint by placing a dot
        plt.plot( X[1], Y[1], '.', color=color )


    

    
""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_TtrgLst   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

see p_TtrgLst.m

"""
def p_TtrgLst( TL, szM ):

    szV = szM[0]
    szH = szM[1]

    colOrng = [255/255, 128/255, 0/255]   # orange
    colBlue = [0/255, 0/255, 255/255]     # blue

    for i in range( TL.nTtg ):
    
        Axe, Cor, Tg   = u_TtrgRtrv1( TL, i )

        plt.plot( [cl * szH for cl in Cor.Cl], 
                  [rw * szV for rw in Cor.Rw], color=colOrng )

        plt.plot( [cl * szH for cl in Axe.Cl], 
                  [rw * szV for rw in Axe.Rw], color=colBlue )
    


""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_ShpPoleFromPos   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

see p_ShpPoleFromPos.m

"""
def p_ShpPoleFromPos( SHP, szI=None, ax=None ):


    if ax is None:
        ax = plt.gca()

    bUnitRng = szI is None  # unit-range if size is given

    for i in range(SHP.nShp):
        
        posV = SHP.Pos.Vrt[i]
        posH = SHP.Pos.Hor[i]
        rds  = SHP.RAS[i,0]
        #print(rds)

        if rds == 0:
            rds = 0.01

        if bUnitRng:
            posV = 1 - posV  # convert from image to Cartesian
        else:
            posV = posV * szI[0]
            posH = posH * szI[1]
            rds = rds * szI[0] / 2  # scale for better visual appearance

        wth = hgt = rds * 2

        ellipse = Ellipse(
            (posH, posV), width=wth, height=hgt,
            edgecolor=[SHP.RGB.Red[i], SHP.RGB.Grn[i], SHP.RGB.Blu[i]],
            facecolor='none'
        )
        ax.add_patch(ellipse)    
        
