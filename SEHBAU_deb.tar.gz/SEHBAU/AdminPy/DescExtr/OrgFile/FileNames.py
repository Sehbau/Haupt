"""

"""
from dataclasses import dataclass
from AdminPy.Util.OrgFile.OrgFileNames import *



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class dclsFinaApndExt:
    dsc: str
    hsti: str
    kolm: str


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------
    
""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FinaApndExtRepFrmt   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
"""
def o_FinaApndExtRepFrmt( fist: str, Fixt ) -> dclsFinaApndExt:

#    if Fixt is None:
#        Fixt = o_FileExtensions()

    return dclsFinaApndExt(
        dsc  = f"{fist}{Fixt.dsc}",
        hsti = f"{fist}{Fixt.hsti}",
        kolm = f"{fist}{Fixt.kolm}"
    )
    

    
