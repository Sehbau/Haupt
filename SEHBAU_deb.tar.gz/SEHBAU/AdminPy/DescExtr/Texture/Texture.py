"""

Texture 

"""
import numpy as np
from dataclasses import dataclass

from AdminPy.Util.FileIO.ReadValues import *



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadYtgDim   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Analogous to ReadYtgDim.m

"""
def ReadYtgDim( file ):

    @dataclass
    class S:
        pass
    
    S.szL      = np.fromfile(file, dtype=np.int32, count=2)
    S.szFll    = np.fromfile(file, dtype=np.int32, count=2)

    winSzRaw   = np.fromfile(file, dtype=np.uint8, count=1)[0]
    S.winSiz   = np.int8(winSzRaw)

    S.vrtToCvd = np.fromfile(file, dtype=np.float32, count=1)[0]
    S.horToCvd = np.fromfile(file, dtype=np.float32, count=1)[0]

    if not (4 < S.winSiz < 256):
        raise ValueError(f"window size unreasonable: {S.winSiz}")

    S.szL   = S.szL
    S.nRix  = int(S.szL[0] * S.szL[1])

    return S


    
""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_TxtrGstToArrs   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Texture global stats to array, for the 7 biases.

cf exsbSalBlobs.py

"""
def u_TxtrGstToArrs( T ):

    aBlobLab = list(T.__dict__.keys())
    aBlobLab = aBlobLab[4:11]                   # get rid of __xxx__
    nTyp     = len(aBlobLab)
    
    @dataclass
    class S:
        PrpPres = np.zeros(nTyp, dtype=np.float32)
        Men     = np.zeros(nTyp, dtype=np.float32)
        Sdv     = np.zeros(nTyp, dtype=np.float32)

    for i, lb in enumerate(aBlobLab):

        fld = getattr( T, lb )

        #print( fld )
        #print(dir(fld.__dataclass_params__))
        #print( dir(fld) )
        
        
        S.Men[i]     = fld.men
        S.Sdv[i]     = fld.sdv
        S.PrpPres[i] = fld.prpPres

    return S



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadTxtrMaps   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads texture maps

RET TXM

"""
def LoadTxtrMaps( lfp ):

    # --------------------   Open File   --------------------
    try:
        file = open(lfp, 'rb')
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not open file {lfp}")
    
    @dataclass
    class KNT:
        pass

    @dataclass
    class CRM:
        pass

    ## ============   Header   =============
    Dim      = ReadYtgDim( file )
    szL      = Dim.szL

    print( szL )
    
    ## ============   Maps Count   =============
    KNT.Num   	= ReadMapGen( file, szL, np.int16 )
    KNT.Blk   	= ReadMapGen( file, szL, np.int16 );
    KNT.DomNum  = ReadMapGen( file, szL, np.int16 );
    KNT.DomEnk	= ReadMapGen( file, szL, np.float32 );
    
    ## ============   Maps Txt & Sal   =============
    # orientation texture (NOT blob biases, see ReadOtxMAPsts)
    aFldOtx     = [ 'Vrt', 'Hor', 'Dg1', 'Dg2', 'Axi', 'Nil', 'Uni' ]
    OTX         = ReadStcMapFlt( file, aFldOtx, szL );

    # saliency maps
    aFldSmp     = [ 'Len', 'Ctr', 'Enk', 'Bgt', 'Drk', 'Cvr' ] 
    SAL         = ReadStcMapFlt( file, aFldSmp, szL );

    # chromatic maps
    aFldSts     = ['Min', 'Max', 'Sum', 'Sdv']
    CRM.Red     = ReadStcMapFlt( file, aFldSts, szL );
    CRM.Grn     = ReadStcMapFlt( file, aFldSts, szL );
    CRM.Blu     = ReadStcMapFlt( file, aFldSts, szL );

    # ----------   Trailer (Idf)   ----------
    idf = np.fromfile( file, dtype=np.int32, count=1)

    # --------------------   Close File   --------------------
    file.close

    if idf != 826:
        raise ValueError("idf incorrect")


    @dataclass
    class TXM:
        pass
    TXM.KNT = KNT
    TXM.OTX = OTX
    TXM.SAL = SAL
    TXM.CRM = CRM
    
    return TXM
