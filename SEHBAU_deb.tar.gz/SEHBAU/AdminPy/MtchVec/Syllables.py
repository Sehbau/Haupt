"""Syllables are the 'Words' of vectors obtained for a category.

------------------------------   CLS SUM   ------------------------------
class prmSylbFind:
class sylbCtg1:

------------------------------   DEF SUM   ------------------------------
def f_SylbFindVmx1( VMX, Prm: prmSylbFind ) -> sylbCtg1:

"""
import numpy as np
from dataclasses import dataclass
from pathlib import Path
from sklearn.cluster import KMeans

from AdminPy.Orga.OrgFileNames import fileExtnRep

@dataclass
class prmSylbFind:              # ''''''''''''''''''''   prmSylbFind   ''''''''''''''''''''
    """
    
    """
    nCls:   int = 30
    nImg:   int = 0

    
@dataclass
class sylbCtg1:                 # ''''''''''''''''''''   sylbCtg1   ''''''''''''''''''''
    """
    The syllables for ONE category. 
    """
    nAtt:      int = -1
    nClsIn:    int = -1          # applied num of clusters

    CEN:       np.array = None   # [nClsDt nAtt]
    Nmem:      np.array = None   # [nClsDt 1]
    Frq:       np.array = None   # [nClsDt 1] frequency: Nmem / nImgTrn

    nClsDt:    int = -1          # detected num of clusters (nClsIn - nEmpty)
    nSingt:    int = -1          # num of singleton clusters
    inertia:   float = -1


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_SylbFindVmx1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Finding syllables by Kmeans-clustering. 

IN    VMX   vector matrix [nDsc nAtt]

"""
def f_SylbFindVmx1( VMX, Prm: prmSylbFind, bDisp: int=1 ) -> sylbCtg1:

    nDsc, nAtt   = VMX.shape
    nClsIn       = Prm.nCls
    
    # --------------------   MODEL & FIT   --------------------
    # "auto" uses optimized K-Means++ initialization
    MOD       = KMeans( n_clusters=nClsIn, n_init="auto", random_state=42 )

    # -----  Fit  -----
    Lbs       = MOD.fit_predict(VMX)
    nClsDt    = MOD.n_clusters

    # -----  Analyse Nmem  -----
    CEN       = MOD.cluster_centers_  # [nCls nAtt] centroids
    inertia   = MOD.inertia_          # sum of squared distances to closest centroid

    Nmem      = np.bincount(Lbs, minlength=MOD.n_clusters) # number of descriptors in each cluster
    nSingt    = np.sum(Nmem == 1)        # singleton clusters
    nEmpty    = np.sum(Nmem == 0)        # empty clusters

    Frq       = Nmem / Prm.nImg
    
    if bDisp:
        #print("Cluster sizes:", Nmem)
        print("nSingt:", nSingt)
        print("nEmpty:", nEmpty)
        print("nMem smallest - largest:", Nmem.min(), " - ", Nmem.max() )    
    
    # --------------------   ClustStats   --------------------
    # distances from descriptors to their assigned centroids
    Dst   = np.linalg.norm( VMX - CEN[Lbs], axis=1) # [nDsc,1]

    for k in range( nClsDt ):
            
        Dk  = Dst[Lbs == k]

        if len(Dk) == 0:
            print(f"Cluster {k}: empty")
            continue

        if bDisp>1:
            if k<8:
                print(
                    f"k {k:3d}:  "
                    f"nMem={len(Dk):3d},  "
                    f"mean={Dk.mean():.4f},  "
                    f"max={Dk.max():.4f},  "
                    f"SSE={np.sum(Dk**2):.4f}"
                )
            elif k<9: print('...')

    # Cluster indices with exactly one member
    IxSngCls = np.flatnonzero(Nmem == 1)

    # Corresponding descriptor indices
    IxSngDsc = np.array([
        np.flatnonzero(Lbs == k)[0]
        for k in IxSngCls
    ], dtype=int)

    if bDisp:
        print("Singleton cluster    Ixs:", IxSngCls)
        print("Singleton descriptor Ixs:", IxSngDsc)            

    # --------------------   ClustSpread   --------------------
    # Distances from EVERY sample to EVERY centroid
    DST   = np.linalg.norm( VMX[:, None, :] - CEN[None, :, :], axis=2 )

    # Nearest and second-nearest centroid distances
    DSTO  = np.sort(DST, axis=1)

    Dnear = DSTO[:,0]
    Dnext = DSTO[:,1]

    # Difference between the two distances
    Margin = Dnext - Dnear

    # Small margins indicate ambiguous assignments
    IxAmb = np.argsort(Margin)

    if bDisp:
        print("Most ambiguous samples:", IxAmb[:10])
    
    # --------------------   Selection   --------------------
    if 0:
        Bkeep  = (Nmem > 1)# & (Nmem < 30)
        #Bkeep  = Nmem != 1
        CEN    = CEN[Bkeep, :]
        Nmem   = Nmem[Bkeep]
        nClsDt = CEN.shape[0]

        
    return sylbCtg1( nAtt, nClsIn, CEN, Nmem, Frq, nClsDt, nSingt, inertia )



