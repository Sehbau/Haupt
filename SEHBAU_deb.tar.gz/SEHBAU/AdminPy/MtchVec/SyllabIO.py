"""

IO for syllables.

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------

def u_SylbCtg1Fina( pth, ctg, levIdf, Fixt: fileExtnRep ):

# --------------------   One Catg   --------------------
def SaveSylbCtg1( sfn, S: sylbCtg1 ):
def LoadSylbCtg1( sfn ) -> sylbCtg1:

# --------------------   Collection   --------------------
def CollSyllables( pths, nCat, levIdf ):


"""
import numpy as np
from dataclasses import dataclass
from pathlib import Path

from sklearn.cluster import KMeans
from sklearn.neighbors import NearestNeighbors

from AdminPy.Orga.OrgFileNames import o_FileExtensRep

from .Syllables import *


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_SylbCtg1Fina   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
"""
def u_SylbCtg1Fina( pth, ctg, levIdf, dty, Fixt: fileExtnRep ):

    pth  = str( pth )
    
    fina = f"{pth}/Ctg{ctg}_Lv{levIdf}_{dty}" + Fixt.syl

    return fina
    

# --------------------------------------------------------------------------------
#
#                                  O N E   C A T G 
#
# --------------------------------------------------------------------------------

""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveSylbCtg1   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

Saves the syllables in text format, row-wise
"""
def SaveSylbCtg1( sfn, S: sylbCtg1 ):

    try:
        with open(sfn, 'w') as fid:

            nCls = S.nClsDt
            
            # --------------------   Header   --------------------
            fid.write(f"{S.nAtt} {nCls}\n")
            fid.write(f"{S.inertia}\n")

            # --------------------   Data   --------------------
            # Write CEN explicitly, row by row
            for i in range(nCls):
                
                fid.write(" ".join(f"{S.CEN[i, j]:.10g}"
                                   for j in range(S.nAtt)) + "\n")

            fid.write(" ".join(f"{S.Nmem[i]:d}" for i in range(nCls)) + "\n")
            fid.write(" ".join(f"{S.Frq[i]:.10g}" for i in range(nCls)) + "\n")
            # alternatively: fid.write(" ".join(map(str, S.Nmem[:nCls])) + "\n")

    except IOError:
        raise SaveError(f"SaveSylbCtgs: could not write to {sfn}")



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadSylbCtg1   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the syllables in text format as written by SaveSylbCtg1
"""
def LoadSylbCtg1( sfn ) -> sylbCtg1:

    S = sylbCtg1()
    
    try:
        with open(sfn, 'r') as fid:

            # --------------------   Header   --------------------
            S.nAtt, S.nClsDt = map(int, fid.readline().split())
            S.inertia        = float(fid.readline())

            # --------------------   Data   --------------------
            S.CEN  = np.empty((S.nClsDt, S.nAtt), dtype=np.float32)
            S.Nmem = np.empty((S.nClsDt, 1),      dtype=np.int32)

            # Read row-wise
            for i in range(S.nClsDt):
                S.CEN[i] = np.array(
                    fid.readline().split(), dtype=np.float32
                )

            S.Nmem = np.array( list(map(int,   fid.readline().split())), dtype=np.int32 )
            S.Frq  = np.array( list(map(float, fid.readline().split())), dtype=np.float32 )

            assert len(S.Nmem) == S.nClsDt                

            return S

    except IOError:
        raise LoadError(f"LoadSylbCtgs: could not read frmo {sfn}")
    

    
# --------------------------------------------------------------------------------
#
#                                  C O L L E C T I O N 
#
# --------------------------------------------------------------------------------

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   CollSyllables   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

cf sylbApply.py
"""
def CollSyllables( pths, nCat, levIdf, dty ):

    FixtRep     = o_FileExtensRep()
    
    ASYLB=[]
    for c in range( nCat ):

        lfn  = u_SylbCtg1Fina( pths, c, levIdf, dty, FixtRep )
        
        Sylb = LoadSylbCtg1( lfn )
        
        ASYLB.append(Sylb)

    return ASYLB
