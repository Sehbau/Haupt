"""

The term sammlung refers to a collection of focus descriptions obtained from
annotations, ie. object annotations.

Allocation and I/O of sammlung can occur in module DescExtr, ie. m_SmlgFBRCKRN


------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def u_SmlgFbrcStatsScout( Rgst, bDisp: int=1 ):

def SML_INSTFABRIC( bas, Rgst, StFb ) -> dscx.smglFBRCKRN:



"""
from dataclasses import dataclass
import numpy as np

from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Texture.FabricIO import *




# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------


# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_SmlgFbrcStatsScout   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Fabric stats for a list, a sammlung

"""
def u_SmlgFbrcStatsScout( Rgst, bDisp: int=1 ):

    nIst        = len(Rgst)

    # --------------------   Collect   --------------------
    Nlay = [None]*nIst
    for i in range(0,nIst):

        FMen    = LoadFbrcKernel( Rgst[i] )
        Nlay[i] = FMen.Dim.nLay

    # --------------------   Stats   --------------------
    Lay, Frq = np.unique( Nlay, return_counts=True)

    # --------------------   Disp   --------------------
    if bDisp:
        print( '-----  Stats  -----' )
        print( 'Range layers ' + str(Lay) )
        print( 'Frequency    ' + str(Frq) )

    # --------------------   A2S   --------------------
    @dataclass
    class ST:
        pass

    ST.Nlay    = Nlay     # [nIst 1]
    ST.Lay     = Lay      # [nLayMx 1]
    ST.Frq     = Frq      # [4 1]

    ST.Dim     = FMen.Dim

    ST.nLayMx  = len(Lay)

    return ST




""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   SML_FBRCkern   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Creating a sammlung for fabric kernels for ALL layers. Thus, script smlFbrcKrnl.py
will extract one of the layers.

cf smlFbrc.py

"""
def SML_FBRCkern( Rgst, StFb ) -> tuple[smglFBRCKRN, int]:

    nIst    = len(Rgst)
    stpDisp = int( nIst / 40 )

    # ------------------------------   Allocate   ------------------------------
    SML     = m_SmlgFBRCKRN( StFb, StFb.Dim )

    # ------------------------------   LOOP   ------------------------------
    print(f"nIst {nIst}", end="")
    Kt  = [0,0,0,0]                    # count per layer
    for i in range(0,nIst):

        FKrnl    = LoadFbrcKernel( Rgst[i] )

        #print( FKrnl.Dim )

        nLay    = FKrnl.Dim.nLay
        ixL     = nLay-1
        c       = Kt[ixL]

        if nLay==1:
            SML.AAMHyk[0][c,:] = FKrnl.MHyk[0]
            SML.AAMBis[0][c,:] = FKrnl.MBis[0]
            SML.AAMKnt[0][c,:] = FKrnl.MKnt[0]
        else:
            for l in range(1,nLay):
                SML.AAMHyk[ixL][c,:,l] = FKrnl.MHyk[l]
                SML.AAMBis[ixL][c,:,l] = FKrnl.MBis[l]
                SML.AAMKnt[ixL][c,:,l] = FKrnl.MKnt[l]
                
        Kt[ixL] += 1
                
        if stpDisp>0 and i%stpDisp==0:
            sb.Util.printDotProg()

    return SML, Kt
                    
                    
                    





