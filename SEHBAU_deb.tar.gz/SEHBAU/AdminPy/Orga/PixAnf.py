"""

------------------------------   CLS SUM   ------------------------------
class pixRCv:

------------------------------   DEF SUM   ------------------------------
def i_PixRCv( nEnt )->pixRCv:

"""
from dataclasses import dataclass, field
import numpy as np
import numpy.typing as npt


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass(slots=True)
class pixRCv:                # ''''''''''''''''''''   pixRCv   ''''''''''''''''''''
    """
    Pixel coordinates and their values
    """
    Rw: npt.NDArray[np.int32]   = None
    Cl: npt.NDArray[np.int32]   = None
    Vl: npt.NDArray[np.float32] = None


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_PixRCv   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII
"""
def i_PixRCv( nEnt: int ) -> pixRCv:

    return pixRCv(
        Rw = np.zeros( nEnt,  dtype=np.int32 ),
        Cl = np.zeros( nEnt,  dtype=np.int32 ),
        Vl = np.zeros( nEnt,  dtype=np.float32 )   )
    

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_PixRCtoIx   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
"""
def u_PixRCtoIx( Px: pixRCv, szH: int ):

    return np.array( Px.Rw*szH + Px.Cl )
