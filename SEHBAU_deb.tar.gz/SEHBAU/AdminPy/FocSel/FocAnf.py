"""

Focus selection.

------------------------------   CLS SUM   ------------------------------
class focRng:
class prmFocScl:

------------------------------   DEF SUM   ------------------------------
def f_FocRngFromBbx( top: int, bot: int, lef: int, rit: int, sclV: float, sclH: float ) -> focRng:

def u_FocFileNameLi( pth: str | Path, ctg, ist, ext ) -> str:
def u_FocFileNameLily( pth: str | Path, ctg, ist, nLay, ext ) -> str:

"""
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import numpy.typing as npt

#from AdminPy.Orga.OrgFileNames import o_FileExtensFoc



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class focRng:                    # ''''''''''''''''''''   focRng   ''''''''''''''''''''
    """
    Row and column index ranges for a focus.
    """
    Rw: npt.NDArray[np.int32]   # row indices
    Cl: npt.NDArray[np.int32]   # col indices
    
    nRow: int
    nCol: int


@dataclass
class prmFocScl:              # ''''''''''''''''''''   prmFocScl   ''''''''''''''''''''
    """

    The scaling factors for bbox to map. Not deployed yet. See also prmFbrcFocSel in Fabric.py

    """
    vrt: float
    hor: float


    
    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FocRngFromBbx   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Extracting index ranges from a bounding box

FocRng  = fs.f_FocRngFromBbx( top, lef, bot, rit, PrmScl.vrt0, PrmScl.hor0 )

cf f_FocRngsFbrc in Fabric.py

"""
def f_FocRngFromBbx( top: int, bot: int, lef: int, rit: int, sclV: float, sclH: float ) -> focRng:

    rwTop   = np.floor( float(top) * sclV ).astype(np.int32)
    rwBot   = np.floor( float(bot) * sclV ).astype(np.int32)
    clLef   = np.floor( float(lef) * sclH ).astype(np.int32)
    clRit   = np.floor( float(rit) * sclH ).astype(np.int32)

    #print(rwTop, rwBot, clLef, clRit )
    
    RwRng   = np.arange( rwTop, rwBot )
    ClRng   = np.arange( clLef, clRit )

    Rng     = focRng( Rw=RwRng, Cl=ClRng, nRow=len(RwRng), nCol=len(ClRng) )

    return Rng






""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_FocFileNameLi   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Simple filename consisting of label and instance:   Lab{category}_i{instance}

ai annFabric.py

"""
def u_FocFileNameLi( pth: str | Path, ctg, ist, ext ) -> str:

    fn = str(pth) + f"/Lab{ctg}_i{ist}" + ext

    return fn


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_FocFileNameLily   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Filename consisting of label, instance and number of layers/levels:

                   Lab{category}_i{instance}_ly{nLay/Lev}

ai annFabric.py

"""
def u_FocFileNameLily( pth: str | Path, ctg, ist, nLay, ext ) -> str:

    fn = str(pth) + f"/Lab{ctg}_i{ist}_ly{nLay}" + ext

    return fn



    

