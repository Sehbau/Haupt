"""

Collecting fabric.

The first two definitions are general. 


------------------------------   DEF SUM   ------------------------------
def SaveCollHistInit( nImg: int, nBin: int, sfp: str ) -> None:
def SaveCollHistApnd(Mx: np.ndarray, sfp: str) -> None:

def ICL_COLLFBRCHYKO( fipaExe: str, IxImg: list, Fips1: object, FixtImg: object, 
                      finaFrmt: str, FinaColl: object) -> None:

def ICL_COLLFBRCMNUM( fipaExe: str, IxImg: list, Fips1: object, FixtImg: object, 
                      finaFrmt: str, FinaColl: object) -> None:

"""
import sys, subprocess
import struct
import numpy as np

from AdminPy.Orga.OrgFileNames import *
from AdminPy.Util.Util import *
from AdminPy.Collection.LoadCollHist import LoadCollHist


# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveCollHistInit   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

Writes header for a collection of histograms as loaded in LoadCollHist.m

"""
def SaveCollHistInit( nImg: int, nBin: int, sfp: str ) -> None:

    try:
        with open(sfp, 'wb') as fid:
            
            # fwrite( fid, nImg, 'int32' );
            fid.write(struct.pack('i', nImg))   # number of images
            
            # fwrite( fid, nBin, 'int32' );
            fid.write(struct.pack('i', nBin))   # number of bins

    except (OSError, IOError) as e:

        raise RuntimeError(f"Could not open {sfp}\n") from e



""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveCollHistInit   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

Appends to a collection matrix, that was initialized with SaveCollHistInit() (above)

"""
def SaveCollHistApnd(Mx: np.ndarray, sfp: str) -> None:

    try:
        with open(sfp, 'ab') as fid:
            
            # fwrite( fid, Mx(:), 'int32' );   
            # 1. .flatten(order='F') mimics MATLAB's column-major Mx(:) ordering
            # 2. .astype(np.int32) guarantees it writes as 'int32' bytes
            # 3. .tofile(fid) writes the entire raw binary block directly to the open file
            Mx.flatten(order='F').astype(np.int32).tofile(fid)

    except (OSError, IOError) as e:
        raise RuntimeError(f"Could not open {sfp}\n") from e

    

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ICL_COLLFBRCHYKO   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Collecting fabric kolumns for a list of images. 

cf iclCollFbrcHyko.py

"""
def ICL_COLLFBRCHYKO( fipaExe: str, IxImg: list, Fips1: object, FixtImg: object, 
                      finaFrmt: str, FinaColl: object) -> None:

    # %% -------------   Arguments   -----------
    vrf_ExecutableExists( fipaExe )

    # %% -------------   LOOP LIST   -----------
    nImg = len(IxImg)

    # Calculate step size for progress dots (avoid division by zero if nImg is tiny)
    stepDot = max(1, round(nImg / 40))

    for i, ixi in enumerate(IxImg):

        pthFbrc = o_FileNameFrmt( Fips1.fbrc, ixi, '', finaFrmt )
        pthOut  = Path("tmp/fbar")
        
        # ----------   Execute   ------------
        cmnd = f"{fipaExe} {pthFbrc}{FixtImg.fbrc} {pthOut}"

        try:
            result = subprocess.run(cmnd, shell=True, capture_output=True, text=True, check=True)
            StdOut = result.stdout
        except subprocess.CalledProcessError as e:
            print(f"Command execution failed: {e.stderr}")
            StdOut = e.stderr
        
        # ----------   Load   ----------
        bFirst = i==0
        HK0, Nbin0 = LoadCollHist( f"{pthOut}{FixtImg.fbArK0}", bFirst)
        HK1, Nbin1 = LoadCollHist( f"{pthOut}{FixtImg.fbArK1}", bFirst)
        HK2, Nbin2 = LoadCollHist( f"{pthOut}{FixtImg.fbArK2}", bFirst)
        HK3, Nbin3 = LoadCollHist( f"{pthOut}{FixtImg.fbArK3}", bFirst)
        
        # --------------- Append to Collection --------------------

        # the fabric format has the same format as the spatial histograms, which is
        # simply saved as a matrix, hence we use the SaveCollHistXXXX functions.
        
        # ----- init before 1st image -----
        if i==0:
            SaveCollHistInit( nImg, HK0.size, FinaColl.fbk0)
            SaveCollHistInit( nImg, HK1.size, FinaColl.fbk1)
            SaveCollHistInit( nImg, HK2.size, FinaColl.fbk2)
            SaveCollHistInit( nImg, HK3.size, FinaColl.fbk3)
        
        # -----  append  -----
        SaveCollHistApnd( HK0, FinaColl.fbk0)
        SaveCollHistApnd( HK1, FinaColl.fbk1)
        SaveCollHistApnd( HK2, FinaColl.fbk2)
        SaveCollHistApnd( HK3, FinaColl.fbk3)
        
        # --- progress dots
        if i % stepDot == 0:
            print('.', end='', flush=True)
        
        
    print(f"\n{IxImg[0]}-{IxImg[-1]} done")



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ICL_COLLFBRCMNUM   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Collecting fabric numerosity (count) maps for a list of images. 

cf iclCollFbrcMnum.py

"""
def ICL_COLLFBRCMNUM( fipaExe: str, IxImg: list, Fips1: object, FixtImg: object, 
                      finaFrmt: str, FinaColl: object) -> None:

    # %% -------------   Arguments   -----------
    vrf_ExecutableExists( fipaExe )

    # %% -------------   LOOP LIST   -----------
    nImg = len(IxImg)

    # Calculate step size for progress dots (avoid division by zero if nImg is tiny)
    stepDot = max(1, round(nImg / 40))

    for i, ixi in enumerate(IxImg):

        pthFbrc = o_FileNameFrmt( Fips1.fbrc, ixi, '', finaFrmt )
        pthOut  = Path("tmp/fbar")
        
        # ----------   Execute   ------------
        cmnd = f"{fipaExe} {pthFbrc}{FixtImg.fbrc} {pthOut}"

        try:
            result = subprocess.run(cmnd, shell=True, capture_output=True, text=True, check=True)
            StdOut = result.stdout
        except subprocess.CalledProcessError as e:
            print(f"Command execution failed: {e.stderr}")
            StdOut = e.stderr
        
        # ----------   Load   ----------
        bFirst = i==0
        MN0, dmy = LoadCollHist( f"{pthOut}{FixtImg.fbArN0}", bFirst)
        MN1, dmy = LoadCollHist( f"{pthOut}{FixtImg.fbArN1}", bFirst)
        MN2, dmy = LoadCollHist( f"{pthOut}{FixtImg.fbArN2}", bFirst)
        MN3, dmy = LoadCollHist( f"{pthOut}{FixtImg.fbArN3}", bFirst)
        
        # --------------- Append to Collection --------------------

        # the fabric format has the same format as the spatial histograms, which is
        # simply saved as a matrix, hence we use the SaveCollHistXXXX functions.
        
        # ----- init before 1st image -----
        if i==0:
            SaveCollHistInit( nImg, MN0.size, FinaColl.fbn0)
            SaveCollHistInit( nImg, MN1.size, FinaColl.fbn1)
            SaveCollHistInit( nImg, MN2.size, FinaColl.fbn2)
            SaveCollHistInit( nImg, MN3.size, FinaColl.fbn3)
        
        # -----  append  -----
        SaveCollHistApnd( MN0, FinaColl.fbn0)
        SaveCollHistApnd( MN1, FinaColl.fbn1)
        SaveCollHistApnd( MN2, FinaColl.fbn2)
        SaveCollHistApnd( MN3, FinaColl.fbn3)
        
        # --- progress dots
        if i % stepDot == 0:
            print('.', end='', flush=True)
        
        
    print(f"\n{IxImg[0]}-{IxImg[-1]} done")
    

    
