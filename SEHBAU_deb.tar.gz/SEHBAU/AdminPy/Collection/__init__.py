"""

The term collection refers to two types:

1) the collected descriptors for a list of images, such as the collection matrix for
vectors

2) a specific image database

We have several groups of modules in this directory:

- IclXXX.py          deals with image databases
     IclAdmin.py     administrative info for specific image databases, ie. collPaths, collInfo
     IclFold.py      folding into training/testing
     IclProc.py      list processing

- LoadCollXXX.py     loads collected descriptors

- Register.py        handles list of filenames for processing a collection


"""
"""
from .IclAdmin import *
from .IclFold import *
from .IclProc import *

from .CollMtrx import *
from .Collecting import *

from .LoadCollVec import *
from .LoadCollHist import *
from .LoadCollTxtr import *

from .CollManip import *

from .Register import *
"""



