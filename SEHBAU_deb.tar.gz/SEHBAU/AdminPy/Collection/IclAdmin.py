"""

Administrative info of image collections (image databases).

------------------------------   CLS SUM   ------------------------------
class collDirNames:
class collPaths:
class collInfo:

------------------------------   DEF SUM   ------------------------------
def u_CollPaths(dbas: int) -> tuple[ collPaths, collInfo ]:
def u_CollPathAnn( P, J ):

def u_DescDel( pthIn, idf="DSC"):
def DispTermNext(str1, str2):

"""
from __future__ import annotations # 3.12
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np
import sys, time
from typing import List, Optional, Any

from AdminPy.Util.FileIO.LoadData import *
from AdminPy.Util import *


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class collDirNames:
    """ Struct holding directory names for an image collection.
    in Mb: o_DirNamesImgColl.m

    For demos we use dclsDirNames in OrgFileNames.py
    """
    imgs    : str = 'IMGdown/'  # location of images. to be set by user.
    
    dsci    : str = 'DSCimg/'
    dtop    : str = 'DSCtop/'
    vect    : str = 'VECimg/'
    coll    : str = 'DSCcoll/'  # collected hists/txtr/vects
    descNN  : str = 'DSCnn/'
    fold    : str = 'Fold/'
    
    regist  : str = 'Regist/'
    params  : str = 'Params/'
    mesMtch : str = 'MesMtch/'


@dataclass
class collPaths:
    """ Struct holding paths for an image collection.
    in Mb: u_CollPaths.m
    """
    imgs:     Path = Path()  # images
    MAIN:     Path = Path()  # description OUTPUT

    dsci:     Path = Path()
    dtop:     Path = Path()
    dbin:     Path = Path()
    veci:     Path = Path()

    coll:     Path = Path()  # collected description - concatenated across files
    fold:     Path = Path()  
    hist:     Path = Path()
    descNN:   Path = Path()
    regist:   Path = Path()
    mesMtch:  Path = Path()


@dataclass
class collInfo:
    
    aFinas: List[str] = field(default_factory=list)
    nCat:     Optional[int] = None
    name:     str = ''
    finaFrmt: int = 0        # used in o_FileNameFrmt or OrgFileNames.py
    nFinas:   Optional[int] = None
    nImg:     Optional[int] = None
    ftxFinas: Optional[Path] = None
    LabImg:   Optional[np.ndarray] = None
    aCatLab:  Optional[List[str]] = None
    szI:      Optional[tuple] = None
    IxImgLrn: Optional[np.ndarray] = None
    IxImgTst: Optional[np.ndarray] = None
    nImgLrn:  Optional[int] = None
    nImgTst:  Optional[int] = None
    LbLrn:    Optional[np.ndarray] = None
    LbTst:    Optional[np.ndarray] = None
    Pth:      Optional[Any] = None  # could be another dataclass



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollPaths   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Collections. For place recognition see u_CollPlcRec

"""
def u_CollPaths(dbas: int) -> tuple[ collPaths, collInfo ]:

    J    = collInfo()
    P    = collPaths()
    name = ''

    # ---------------- Database selection ----------------
    if dbas == 7:
        stem, nCat, name = 'OLTO', 8, 'UrbNat'
    elif dbas == 10:
        stem, nCat, name = 'IndOut15', 15, 'IndOut15'
    elif dbas == 31:
        stem, nCat, name = 'DOCU/Ch_lower', 24, 'LetLow'
    elif dbas == 37:
        stem, nCat, name = 'VOC', 20, 'VOC'
    elif dbas == 50:
        stem, nCat, name = 'Indoor', 67, 'Indoor67'
    elif dbas == 52:
        stem, nCat = 'PLR_NYU2', np.nan
    elif dbas == 60:
        stem, nCat, name = Path(r'CAMSDD/training'), 30, 'Cam30'
    elif dbas == 61:
        stem, nCat = Path(r'CAMSDD/validation'), 30
    elif dbas == 62:
        stem, nCat, name = Path(r'CAMSDD/test'), 30, 'Cam30Test'
    elif dbas == 17:
        stem, nCat, name = 'SINR45', 45, 'SINR45'
    elif dbas == 100:
        stem, nCat, name = 'CIFAR10', 10, 'Cif10'
    elif dbas == 200:
        stem, nCat = 'cityscapes', np.nan
    else:
        raise ValueError(f"Database {dbas} not specified")

    J.nCat = nCat
    J.name = name
    J.ix   = dbas

    # ---------------- Paths setup ----------------
    DRV = Path("G:/")
    P.DRV     = DRV
    # use dataclass with directorynames above for creating full path:
    P.imgs    = DRV / "IMGdown" / stem / ""
    P.MAIN    = DRV / "IMGdat" / stem / ""

    # consider using structure above:
    P.dsci    = P.MAIN / "DSCimg/" / ""
    P.dtop    = P.MAIN / 'DSCtop/'       # top files
    P.dbin    = P.MAIN / 'DSCbin/'       # bin files
    P.veci    = P.MAIN / 'VECimg/'      # vector files

    P.coll    = P.MAIN / "DSCcoll/"
    P.fold    = P.MAIN / "Folds/"
    P.hist    = P.MAIN / "LHST/"
    P.descNN  = P.MAIN / "DSCnn/"
    P.regist  = P.MAIN / "Regist/"
    P.sylb    = P.MAIN / "Syllables/"
    P.mesMtch = P.MAIN / "MesMtch/"

    # --- Special cases ---
    if dbas == 10:
        P.imgs = P.imgs / "SameSize"
    elif dbas == 50:
        P.imgs = P.imgs / "Images"
    elif dbas == 200:
        P.imgs = DRV / "IMGdown" / "cityscapes_data" / "leftImg8bit" / "train" / "aachen"

    vrf_PathsExistAsk( P )

    # ---------------- Load filenames ----------------
    ftxFinas = P.MAIN / "ImgFinas.txt"
    if ftxFinas.is_file():
        with ftxFinas.open("r", encoding="utf-8") as f:
            J.aFinas = [line.strip() for line in f if line.strip()]
        J.nFinas     = len(J.aFinas)
        J.nImg       = J.nFinas
        J.ftxFinas   = ftxFinas

    # ---------------- Load image labels ----------------
    ftxImgLab = P.MAIN / "ImgCatLb.txt"
    if ftxImgLab.is_file():

        J.LabImg = np.loadtxt(ftxImgLab, dtype=int)
        if J.aFinas:
            assert len(J.LabImg) == J.nFinas
            
    elif dbas == 52:

        fileScenes = P.imgs / "Scenes.npy"
        if fileScenes.is_file():
            scenes = np.load(fileScenes, allow_pickle=True)
            J.aFinas = list(scenes)
            J.nFinas = len(J.aFinas)
            np.unique(scenes, return_index=True, return_inverse=True)
            P.imgs = P.imgs / "Images"
            
    elif dbas == 100:
        
        from LoadImages import LoadImgCIF10  # custom function
        _, J.LabImg = LoadImgCIF10()
        
    else:
        print("No file ImgCatLb.txt found")

    # ---------------- Load category labels ----------------
    ftxCatLab = P.MAIN / "CatgNames.txt"
    if ftxCatLab.is_file():
        pass  # Assume external category list loaded
    elif dbas == 7:
        J.aCatLab = ['coast', 'forest', 'highway', 'city',
                     'mountain', 'country', 'street', 'building']
    elif dbas == 100:
        J.aCatLab = ['airplane', 'automobile', 'bird', 'cat', 'deer',
                     'dog', 'frog', 'horse', 'ship', 'truck']
    else:
        print("No file CatgNames.txt found")

    # ---------------- CIFAR10 ----------------
    if dbas == 100 and J.LabImg is not None:
        J.szI = (32, 32)
        J.IxImgLrn = np.arange(1, 50001)
        J.IxImgTst = np.arange(50001, 60001)
        J.nImgLrn = 50000
        J.nImgTst = 10000
        J.nImg    = 60000
        J.LbLrn = J.LabImg[J.IxImgLrn - 1]
        J.LbTst = J.LabImg[J.IxImgTst - 1]

    # ---------------- VOC ----------------
    if dbas == 37:
        from u_Vo7Paths import u_Vo7Paths
        J.Pth = u_Vo7Paths()  # expected to return a similar dataclass
        # VOCinit() placeholder
        J.nFinas = 9963

    J.Ix0Img     = np.arange(0,J.nImg)
    J.stepDisp   = int(J.nImg / 40)
        
    return P, J


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollPathAnn   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Paths for annotations. Follows u_CollPaths.m

USE
   [Pths Coll] = u_CollPaths( bas );
   Pths        = u_CollPathsAnnt( Pths, Coll );

cf annFocx.m
"""
def u_CollPathAnn( P, J ):

    P.DANNhst = P.MAIN / 'DANNhst/'
    P.DANNvec = P.MAIN / 'DANNvec/' 
    P.AnnImg  = P.MAIN / 'AnnImg/' 
    P.Smlg    = P.MAIN / 'Smlg/' 

    bPause = 1
    f_MkDir( P.DANNhst, bPause )
    f_MkDir( P.Smlg, bPause )
    
    if J.ix==7:
        # do nothing
        dmy = 0
    elif J.ix==52:

        J.nLABEL          = 895;
        J.nINST           = 37;
        J.NLEVARH         = 5;      # nLev
        J.nLay            = 3;      # ???
        J.aLabCat         = cell( J.nLABEL, 1);

        bPause      = 1
        u_MkDirLevels( P.DANNvec, J.NLEVARH, bPause )
        
    elif J.ix==37:
        #u_Vo7Paths.m
        raise('unfinished ')
        
    else: 
        raise('collection %s (ix=%d) not implemented yet', J.name, J.ix )
    

    return P, J


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_DescDel   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

    Deletes descriptor files of a collection. 
    
    Parameters:
    pth (str or Path): The directory path where files should be deleted.
    idf (str, optional): The prefix of the files to delete. Defaults to 'DSC'.

"""
def u_DescDel( pthIn, idf="DSC"):

    # 1. Ensure pth is treated as a robust Path object
    pthF = Path(pthIn)
    
    aFiles = [fp for fp in pthF.glob(f"{idf}*") if fp.is_file()]

    if not aFiles:
        print(f"No files matching '{idf}*' found in {pthF}.")
        return

    # -----  Inform & Ask User  -----
    nFound = len(aFiles)
    print(f"Found {nFound} files matching '{idf}*' in {pthF}:")
    ansQ   = input(f"Deleting those {nFound} files? (y/N): ").strip().lower()
    
    # -----  Eval Answer  -----
    # Abort if the user doesn't explicitly type 'y' or 'yes'
    if ansQ not in ['y', 'yes']:
        print("deletion aborted.")
        return

    if ansQ == 'a':
        print("Exiting Python application...")
        sys.exit() 
    
    # -----  Now kill  -----
    print(f"Deleting files...", end="", flush=True)
    for fp in aFiles:
        fp.unlink()  # unlinks/removes the file
    
    print("done")


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   DispTermNext   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

IN    str     string to be displayed
USE   DispTermNext(mfilname, 'gs_DFLK')

"""
def DispTermNext(str1, str2):

    print(f">>>>>>>>>>>>>> Terminated script: {str1} ")
    print(f">>>>>>>>>>>>>> Next script:       {str2} ")



    
