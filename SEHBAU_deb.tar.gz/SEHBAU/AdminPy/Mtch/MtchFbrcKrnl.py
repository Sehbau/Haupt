"""

Fabric analysis with kernel.

Elsewhere:
- matching full subspace fabric in MtchFbrcFlsh.py
- matching image fabrics in MtchFbrcImg.py


------------------------------   CLS SUM   ------------------------------
class prmFbrcIdf:
class fbrcScorMaps:

------------------------------   DEF SUM   ------------------------------
def Krnl1Exhst( IFb: fbrcMTXL, Rep: fbrcKernel ) -> fbrcScorMaps:

def KrnlLstAccel( IFb: fbrcMTXL, ARep: list[fbrcKernel],
                  PrmIdf: prmFbrcIdf, BinEdg: bedgSpaHst, bDisp: int=1 ):

# --------------------   Wrapper   --------------------
def KrnlLstAccel( IFb: fbrcMTXL, ARep: list[fbrcKernel],
                  PrmIdf: prmFbrcIdf, bDisp: int=1 ):

"""
from dataclasses import dataclass, field
from typing import List, Any
import numpy as np

from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Hist.DescBinAnf import bedgSpaHst

from AdminPy.Mtch.MtchHstAtt import dst_HstAttOne

import AdminPy.Recognize.RecUtil as rcut

from .MtchFbrcAnf import *



    
    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   Krnl1Exhst   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Generic top-down analysis using only vector distances for ONE representation, a
quasi-detector. No optimization (short cut with saliency or similar), therefore
called exhaustive matching, meaning the full representation height is deployed. Can
serve as a reference.

Recall that:
ix 3 is top layer with smallest grid [3 3]
ix 0 is bottom layer with largest grid [31 31]

But output in SCOR will be:
ix 0 is top layer of representation: 1 to 4


IN   IFb    the sample fabric with all four layers, ie. from an image
     Rep    the representation: statistical fabric subset description
OUT  SCOR   the score maps with counting inverted:
            0  is top layer (4 or less), nLaySus-1
            1  is next larger layer, nLaySus-2
            ...
"""
def Krnl1Exhst( IFb: fbrcMTXL, Rep: fbrcKernel ) -> fbrcScorMaps:

    SCOR       = fbrcScorMaps()

    nLayKrn    = Rep.Dim.nLay  # take 'height' of kernel

    cL=0          # counter output layers: will be inverted!: top will be at index 0

    for l in range(nLayKrn-1, -1, -1):
    
        #print(f"-----  layer {l}  -----")

        # retrieve layer from sample
        MBIS       = IFb.ABIS[l]                # [nCll ntBsv]
        MHYK       = IFb.AHYK[l]                # [nCll ntBin]
        nCll, ntBsv = MBIS.shape

        # retrieve layer from representation
        Rbis       = Rep.MBis[l]
        Rhyk       = Rep.MHyk[l]
        
        # ----------   Loop Cells   ----------
        # init scores
        ScorBis = np.zeros( FBRCNcells[l] )
        ScorHyk = np.zeros( FBRCNcells[l] )
        for c in range(nCll):
            
            # simple Euclidean distance on entire vector for both bias and
            # hyperkolum: 
            DfBis      = abs(MBIS[c,:] - Rbis)
            DfHyk      = abs(MHYK[c,:] - Rhyk)

            ScorBis[c] = np.sqrt( np.sum(DfBis**2) )
            ScorHyk[c] = np.sqrt( np.sum(DfHyk**2) )
            
        # --- Store scores as map (for visual inspection)
        # we invert counting: 0 will be top layer
        SCOR.ABis[cL] = ScorBis.reshape( FBRCDimLay[l] )
        SCOR.AHyk[cL] = ScorHyk.reshape( FBRCDimLay[l] )
        cL       += 1
    
    return SCOR
        


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   Krnl1Accel   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Accleration. The idea is to skip distance calculations when the bias values appear
too different already.

It computes a similarity measure (NOT a dissimilarity!).

"""
def Krnl1Accel( IFb: fbrcMTXL, Rep: fbrcKernel,
                Prm: prmFbrcIdf, BinEdg: bedgSpaHst, bDisp: int=1 ) -> fbrcScorMaps:

    SCOR       = fbrcScorMaps()

    nLayKrn    =  Rep.Dim.nLay  # subset 'height' 

    cL=0 # we invert the counting, top will be at index 0
    for l in range(nLayKrn-1, -1, -1):
    
        #print(f"-----  layer {l}  -----")
        # retrieve layer from sample
        MKNT       = IFb.AKNT[l]
        MBIS       = IFb.ABIS[l]
        MHYK       = IFb.AHYK[l]
        nCll, nDty = MKNT.shape
        
        # retrieve layer from representation
        Rknt       = Rep.MKnt[l] 
        Rbis       = Rep.MBis[l]
        Rhyk       = Rep.MHyk[l]
        
        # --------------------   LOOP CELLS   --------------------
        # init scores, binary task
        ScorBis = np.zeros( FBRCNcells[l] )
        ScorHyk = np.zeros( FBRCNcells[l] )
        #Scor = np.zeros( (FBRCDimLay[l][0], FBRCDimLay[l][1], nCtg) ) # multiple categories
        cSkpKnt=0; cSkpBis=0
        for c in range(nCll):

            # ----------   Saliency Count   ----------
            Sknt  = MKNT[c,:]
            Blow  = Sknt < Rknt/2    # very low count
            Bhih  = Sknt > Rknt*2    # very hih count

            if np.all(Blow) or np.all(Bhih):
                cSkpKnt += 1
                continue

            # ----------   Saliency Bias   ----------
            Mbis       = MBIS[c,:]
            DfBis      = abs(Mbis - Rbis)
            dstBis     = np.sqrt( np.sum(DfBis**2) )
            if dstBis > Prm.tolBis:
                cSkpBis += 1
                continue
            ScorBis[c] = 1 - (dstBis / Prm.tolBis)

            # ----------   HYPKOL DIST   ----------
            # simple Euclidean distance on entire vector
            if 0:
                DfHyk      = abs(MHYK[c,:] - Rhyk)
                ScorHyk[c] = np.sqrt( np.sum(DfHyk**2) )
            else:
                # weighted sum
                dst        = dst_HstAttOne( MHYK[c,:], Rhyk, BinEdg.All )
                if dst < Prm.tolHyk:
                    ScorHyk[c]  = 1 - (dst / Prm.tolHyk)

        if bDisp:
            print(f'skipped knt {cSkpKnt:3d}  bis {cSkpBis:3d}')
            
        # --- Store as map 
        # we invert counting: 0 will be top layer
        SCOR.AHyk[cL] = ScorHyk.reshape( FBRCDimLay[l] )
        SCOR.ABis[cL] = ScorBis.reshape( FBRCDimLay[l] )
        cL       += 1
    
        # ----------   Analyze Hyperkolumn Scores   ----------
        if 0:
            # needs to be corrected for similarity (this is dissimilarity)
            Ord       = np.argsort(ScorHyk) # ascending
            ScorHykO  = ScorHyk[Ord]
            ixBel     = np.flatnonzero(ScorHykO < Prm.tolHyk) # below some threshold
            #print( Ord )
            #print( ixBel )
            # --- Select above indices from array 'Ord'
            OrdSel    = Ord[ixBel]
            # apply only to corresponding cells in next layer, for which one needs to
            # upsample.
        
    return SCOR




# --------------------------------------------------------------------------------
#
#                               W R A P P E R S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   KrnlLstAccel   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Matches a list of kernels, acclerated, and determines their scores.

cfro exsbObjIdfLst.py

IN     IFb      image fabric
       ARep     list of kernels
OUT    ASCR     list of score maps, [nKrn]{nLaySus}

USE
       SCR = faly.KrnlLstAccel( FFLL, AFKrnl, PrmIdf, bDisp )
"""
def KrnlLstAccel( IFb: fbrcMTXL, ARep: list[fbrcKernel],
                  PrmIdf: prmFbrcIdf, BinEdg: bedgSpaHst, bDisp: int=1 ):

    nKrnl       = len( ARep )

    print( f"KrnlLstAccel: nKrnl {nKrnl} ", end="" )
    #PrmIdf      = i_FbrcIdfPrm()

    ALOCT = [[] for i in range(nKrnl)]           # [nKrn]{nLaySus}
    for k in range(nKrnl):

        nLaySus   = ARep[k].Dim.nLay            # nLayers for this kernel rep
        #print( f"nLay {nLaySus}" )
        
        SCOR   = Krnl1Accel( IFb, ARep[k], PrmIdf, BinEdg, bDisp ) # above

        for l in range( nLaySus ):
            Maxm   = rcut.f_MapLocMaxima( SCOR.AHyk[l] )
            ALOCT[k].append( Maxm )

            # print( f"rw={Maxm.Rw[0]}  cl={Maxm.Cl[0]}" )

        #SCOR.nLaySus = nLaySus
        
        print('.', end="")

    print('')

    return ALOCT





