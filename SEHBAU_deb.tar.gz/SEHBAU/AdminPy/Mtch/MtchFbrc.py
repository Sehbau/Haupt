"""

Matching fabric.

------------------------------   CLS SUM   ------------------------------
------------------------------   DEF SUM   ------------------------------


"""



"""FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   dst_HstAttLst   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Matching one hist-of-atts versus many. Nbin are the bin numbers for the individual
attributes, descriptor types, etc. Nbin is supposed to be given as array of
cumulative sum, ie.:

     NbinCms = i_BnumFromLoad( HedFbc.NbinAtt, HedFbc.NbinDty )

IN   Hsmp   sample hist-of-atts          [   1 ntBin]
     AH     matrix of other hist-of-atts [nOth ntBin]
     Nbin   number of bins per attribute/desctype/...

"""
def dst_HstAttLst( Hsmp, ntBin, AH, Nbin ):

    nOth, ntBin2 = shape(AH)    # number of others (many)

    assert ntBin==ntBin2, "ntBins not correct"

    Esec  = np.cumsum( Nbin )

    nBinLast = Esec[-1];

    assert nBinLast==ntBin, "total bin count incorrect: {nBinLast} <> {ntBin}: "
    
    nSec  = len(Esec)

    DstO  = np.zeros(nOth)
    for i in range(nOth):

        Hoth = AH[i,:]

        DfQ  = ( Hoth - Hsmp ) ** 2

        ixB  = 0
        ss   = 0.0
        for s, ixE in enumerate(Esec):

            dS   = np.sqrt( np.sum( DfQ[ixB:ixE] ) )
            ss  += dS / Nbin[s]
            ixB  = ixE

        DstO[i] = ss / nSec

    return DstO
        
    

