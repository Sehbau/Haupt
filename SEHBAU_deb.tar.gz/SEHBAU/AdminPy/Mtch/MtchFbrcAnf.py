"""

Matching fabric.

MtchFbrcImg.py    image-wise matching
MtchFbrcFlsh.py   full subspace matching
MtchFbrcKrnl.py   kernel matching
MtchFbrcUtil.py   utility: analysis and plotting


------------------------------   CLS SUM   ------------------------------
class prmFbrcIdf:
class fbrcScorMaps:

------------------------------   DEF SUM   ------------------------------
def i_FbrcIdfPrm( tolBis: float = 1.2,
                  tolHyk: float = 100 ) -> prmFbrcIdf:



"""
from dataclasses import dataclass, field
from typing import List, Any
import numpy as np



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class prmFbrcIdf:
    """
    Parameters for fabric matching.
    """
    tolBis:   float = 1.2
    tolHyk:   float = 100


@dataclass(slots=True)
class fbrcScorMaps:
    """
    Score maps for layers
    """
    AHyk: List[Any] = field(default_factory=lambda: [None for _ in range(4)])
    ABis: List[Any] = field(default_factory=lambda: [None for _ in range(4)])
    Busd            = [False]*4
    nLaySus: int=-1 # num of layers effectively used

    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_FbrcIdfPrm   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII

Organizational routine to setup parameters for cascade identifier.

"""
def i_FbrcIdfPrm( tolBis: float = 1.2,
                  tolHyk: float = 100 ) -> prmFbrcIdf:

    return prmFbrcIdf(
        tolBis     = tolBis,
        tolHyk     = tolHyk    )


