"""

Full subspace (flesh) matching.

So far exhaustive matching only, no acceleration implemented yet.


------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def Flsh1Exhst( IFb: fbrcMTXL, Rep: fbrcMTXL,
                Prm: prmFbrcIdf, BinEdg: bedgSpaHst, bDisp: int=1 ) -> fbrcScorMaps:

# --------------------   Wrapper   --------------------
def FlshLstExhst( IFb: fbrcMTXL, AFoc: list,
                  PrmIdf: prmFbrcIdf, BinEdg: bedgSpaHst, bDisp: int=1 ):

"""
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Hist.DescBinAnf import bedgSpaHst
from AdminPy.Mtch.MtchHstAtt import dst_HstAttOne
import AdminPy.Recognize.RecUtil as rcut
from .MtchFbrcAnf import *




# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   Flsh1Exhst   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Exhaustive flesh matching. We calculate a score map for each layer. Used for
testing.

afro Krnl1Exhst

"""
def Flsh1Exhst( IFb: fbrcMTXL, Rep: fbrcMTXL,
                Prm: prmFbrcIdf, BinEdg: bedgSpaHst, bDisp: int=1 ) -> fbrcScorMaps:

    SCOR       = fbrcScorMaps()

    nLayKrn    =  Rep.Dim.nLay  # subset 'height' 

    cL=-1 # we invert the counting, top will be at index 0
    for l in range(nLayKrn-1, -1, -1):

        cL      += 1
        ScorBis = np.zeros( FBRCNcells[l] )
        ScorHyk = np.zeros( FBRCNcells[l] )

        #print(f"-----  layer {l}  -----")
        # retrieve layer from sample
        MKNT       = IFb.AKNT[l]
        MBIS       = IFb.ABIS[l]
        MHYK       = IFb.AHYK[l]
        nCll, nDty = MKNT.shape
        
        # retrieve layer from representation
        RKNT       = Rep.AKNT[l] 
        RBIS       = Rep.ABIS[l]
        RHYK       = Rep.AHYK[l]

        szF        = Rep.Dim.ASiz[l,:]
        hgt, wth   = szF[0], szF[1]
        if 0: # hgt<2 and wth<2:
            print(f'skipped hgt {hgt}, wth {hgt}')
            SCOR.AHyk[cL] = ScorHyk.reshape( FBRCDimLay[l] )
            SCOR.ABis[cL] = ScorBis.reshape( FBRCDimLay[l] )
            continue

        mrgV = int(np.ceil(hgt/2))
        mrgH = int(np.ceil(wth/2))

        # --------------------   LOOP CELLS   --------------------
        szM        = FBRCDimLay[l,:] # is None: IFb.Dim.ASiz[l,:]
        szV, szH   = szM[0], szM[1]
        print(f" szV {szV}  szH {szH}   focus hgt {hgt}, wth {hgt}  bis " + str(RBIS.shape))
        # init scores, binary task

        cSkpKnt=0; cSkpBis=0
        for i in range(szV):
            if i<mrgV or i>=szV-mrgV: continue

            for j in range(szH):
                if j<mrgH or j>=szH-mrgH: continue

                c = i*szH+j

                #print(i,j,c)
                # ----------   Saliency Bias   ----------
                sBis=0; sHyk=0
                for ii in range(hgt):
                    for jj in range(wth):

                        ixM        = (i-mrgV+ii)*szH + (j-mrgH+jj)
                        ixF        = ii*wth + jj
                        #print(ixM,ixF)

                        # ----------   BIAS DIST   ----------
                        Mbis       = MBIS[ixM,:]
                        DfBis      = abs(Mbis - RBIS[ixF,:])
                        dstBis     = np.sqrt( np.sum(DfBis**2) )
                        if dstBis < Prm.tolBis:
                            sBis += ( 1 - (dstBis / Prm.tolBis) )
                        
                        # ----------   HYPKOL DIST   ----------
                        # weighted sum
                        dstHyk     = dst_HstAttOne( MHYK[ixM,:], RHYK[ixF,:], BinEdg.All )
                        if dstHyk < Prm.tolHyk:
                            sHyk += ( 1 - (dstHyk / Prm.tolHyk) )

                ScorBis[c] = sBis
                ScorHyk[c] = sHyk
                    
        # --- Store as map 
        # we invert counting: 0 will be top layer
        SCOR.AHyk[cL] = ScorHyk.reshape( FBRCDimLay[l] )
        SCOR.ABis[cL] = ScorBis.reshape( FBRCDimLay[l] )
        SCOR.Busd[cL] = True

        
    return SCOR



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   FlshLstExhst   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Matches a list of flesh focii and determines their scores.

Unfinished: no acceleration taking place yet!

cfro exsbObjIdfLst.py

IN     IFb      image fabric
       ARep     list of kernels
OUT    ASCR     list of score maps, [nKrn]{nLaySus}

USE
       SCR = faly.FlshLstExhst( FFLL, AFFlsh, PrmIdf, bDisp )
"""
def FlshLstExhst( IFb: fbrcMTXL, AFoc: list,
                  PrmIdf: prmFbrcIdf, BinEdg: bedgSpaHst, bDisp: int=1 ):

    nFoc       = len( AFoc )

    print( f"FlshLstExhst: nFoc {nFoc} ", end="" )
    #PrmIdf      = i_FbrcIdfPrm()

    ALOCT = [[] for i in range(nFoc)]           # [nKrn]{nLaySus}
    for k in range(nFoc):

        nLaySus   = AFoc[k].Dim.nLay            # nLayers for this kernel rep
        #print( f"nLay {nLaySus}" )
        
        SCOR      = Flsh1Exhst( IFb, AFoc[k], PrmIdf, BinEdg ) # above

        for l in range( nLaySus ):
            
            Maxm   = rcut.f_MapLocMaxima( SCOR.AHyk[l] )
            
            ALOCT[k].append( Maxm )

            # print( f"rw={Maxm.Rw[0]}  cl={Maxm.Cl[0]}" )

        #SCOR.nLaySus = nLaySus
        
        print('.', end="")

    print('')

    return ALOCT
