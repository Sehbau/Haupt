"""

------------------------------   CLS SUM   ------------------------------
------------------------------   DEF SUM   ------------------------------

# --------------------   Anaylsis   --------------------
def u_OutlFromScorFbrc( SCOR: fbrcScorMaps, dimBoxPrpRep, szImg, nLaySus: int, bDisp: int=1 ):

# --------------------   Plotting   --------------------
def p_MapsScor(figSel, Irgb, Iptch, SCORmps, nLaySus, AIprd ):
def p_MapsScorV1(figSel, Irgb, Iptch, SCORmps, nLaySus,
                 Icrst=None, Icors=None, Ifine=None ):


"""
from typing import List, Any
import numpy as np

from AdminPy.DescExtr.Texture.FabricAnf import *

from .MtchFbrcAnf import *

import AdminPy.Recognize.RecUtil as rcut


# --------------------------------------------------------------------------------
#
#                                   A N A L Y S I S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   u_OutlFromScorFbrc   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Predict location from score maps calculated with dissimilarity measure. Returns
bounding boxes of the size given in DimBoxPrpRep.

Note that indexing for layer was inverted: first layer in SCOR is coarsest (not
finest).

cfro exsbObjIdf.py (but not exsbObjIdfLst.py)

"""
def u_OutlFromScorFbrc( SCOR: fbrcScorMaps, BoxRepUrg: int, szImg: int, nLaySus: int,
                        bHyk: int=1, bDisp: int=1 ):

    AMAX      = []
    Box4      = np.zeros( (nLaySus,4), dtype=np.int32 )
    for l in range(nLaySus):

        if not SCOR.Busd[l]:
            Box4[l,:] = -1
            continue

        # we have measured dissimilarity measure and therefore take maxima (not minima)
        if bHyk==1:
            SMax      = rcut.f_MapLocMaxima( SCOR.AHyk[l] ) # hyperkolumns
        else: 
            SMax      = rcut.f_MapLocMaxima( SCOR.ABis[l] ) # biases (for testing)
        
        ixLay     = nLaySus-1-l # counting was inverted during top-down analysis
        Box4[l,:] = rcut.u_OutlFromLoctLay( SMax.Rw[0], SMax.Cl[0], ixLay, BoxRepUrg, szImg )

        if bDisp:
            print( f" rw={SMax.Rw[0]:2d}  cl={SMax.Cl[0]:2d} " )
        
        AMAX.append( SMax )

    return Box4, AMAX



# --------------------------------------------------------------------------------
#
#                               P L O T T I N G
#
# --------------------------------------------------------------------------------
import matplotlib.pyplot as plt

""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_MapsScor   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots score maps

     AIprd     list of predicted patches
"""
def p_MapsScor(figSel, Irgb, Iptch, SCORmps, nLaySus, AIprd ):

    hf = plt.figure(figSel)
    hf.clf()

    nr, nc = 4, 3

    ax = hf.add_subplot(nr, nc, 1)
    ax.imshow(Irgb)
    ax.tick_params(labelsize=5)

    ax = hf.add_subplot(nr, nc, 2)
    ax.imshow( Iptch )
    ax.set_title('Sel')
    plt.show(block=False)

    # ----------   2nd Row   ----------
    if AIprd[0] is not None and len(AIprd[0])>0:
        ax = hf.add_subplot(nr, nc, 4)
        ax.imshow( AIprd[0] )
        ax.set_title('Coarsest')
        plt.show(block=False)

    if AIprd[1] is not None and len(AIprd[1])>0:
        ax = hf.add_subplot(nr, nc, 5)
        ax.imshow( AIprd[1] )
        ax.set_title('Coarse')
        plt.show(block=False)

    if AIprd[2] is not None and len(AIprd[2])>0:
        ax = hf.add_subplot(nr, nc, 6)
        ax.imshow( AIprd[2] )
        ax.set_title('Fine')
        plt.show(block=False)
    
    # ----------   3rd Row   ----------
    ax = hf.add_subplot(nr, nc, 7)
    ax.imshow( SCORmps.AHyk[0] )
    ax.set_title('')
    ax.set_ylabel('Hyko')
    plt.show(block=False)
    
    ax = hf.add_subplot(nr, nc, 8)
    ax.imshow( SCORmps.AHyk[1] )
    ax.set_title('')
    plt.show(block=False)
    
    if nLaySus>2:
        ax = hf.add_subplot(nr, nc, 9)
        ax.imshow( SCORmps.AHyk[2] )
        ax.set_title('')
        plt.show(block=False)
        
    # ----------   4th Row   ----------
    ax = hf.add_subplot(nr, nc, 10)
    ax.imshow( SCORmps.ABis[0] )
    ax.set_title('')
    ax.set_ylabel('Bias')
    plt.show(block=False)
    
    ax = hf.add_subplot(nr, nc, 11)
    ax.imshow( SCORmps.ABis[1] )
    ax.set_title('')
    plt.show(block=False)
    
    if nLaySus>2:
        ax = hf.add_subplot(nr, nc, 12)
        ax.imshow( SCORmps.ABis[2] )
        ax.set_title('')
        plt.show(block=False)



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_MapsScorV1   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Version 1: a bit stiff.
"""
def p_MapsScorV1(figSel, Irgb, Iptch, SCORmps, nLaySus,
                 Icrst=None, Icors=None, Ifine=None ):

    hf = plt.figure(figSel)
    hf.clf()

    nr, nc = 4, 3

    ax = hf.add_subplot(nr, nc, 1)
    ax.imshow(Irgb)
    ax.tick_params(labelsize=5)

    ax = hf.add_subplot(nr, nc, 2)
    ax.imshow( Iptch )
    ax.set_title('Sel')
    plt.show(block=False)

    # ----------   2nd Row   ----------
    if Icrst is not None:
        ax = hf.add_subplot(nr, nc, 4)
        ax.imshow( Icrst )
        ax.set_title('Coarsest')
        plt.show(block=False)

    if Icors is not None:
        ax = hf.add_subplot(nr, nc, 5)
        ax.imshow( Icors )
        ax.set_title('Coarse')
        plt.show(block=False)

    if Ifine is not None and len(Ifine)>0:
        ax = hf.add_subplot(nr, nc, 6)
        ax.imshow( Ifine )
        ax.set_title('Fine')
        plt.show(block=False)
    
    # ----------   3rdd Row   ----------
    ax = hf.add_subplot(nr, nc, 7)
    ax.imshow( SCORmps.AHyk[0] )
    ax.set_title('')
    ax.set_ylabel('Hyko')
    plt.show(block=False)
    
    ax = hf.add_subplot(nr, nc, 8)
    ax.imshow( SCORmps.AHyk[1] )
    ax.set_title('')
    plt.show(block=False)
    
    if nLaySus>2:
        ax = hf.add_subplot(nr, nc, 9)
        ax.imshow( SCORmps.AHyk[2] )
        ax.set_title('')
        plt.show(block=False)
        
    # ----------   4th Row   ----------
    ax = hf.add_subplot(nr, nc, 10)
    ax.imshow( SCORmps.ABis[0] )
    ax.set_title('')
    ax.set_ylabel('Bias')
    plt.show(block=False)
    
    ax = hf.add_subplot(nr, nc, 11)
    ax.imshow( SCORmps.ABis[1] )
    ax.set_title('')
    plt.show(block=False)
    
    if nLaySus>2:
        ax = hf.add_subplot(nr, nc, 12)
        ax.imshow( SCORmps.ABis[2] )
        ax.set_title('')
        plt.show(block=False)
        

    
