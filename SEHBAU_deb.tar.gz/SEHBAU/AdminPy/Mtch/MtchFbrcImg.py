"""

Matching fabric image-wise, 1 vs many. Top-down.

For matching fabric kernels see MtchFbrcKrnl.py

------------------------------   CLS SUM   ------------------------------
class prmMtchFbrcImg

------------------------------   DEF SUM   ------------------------------
def f_MtchFbrcBisMtx( Ifb, CMX ) -> np.array:

def MTCHFBRCBIS( IFb: fbrcMTXL, COLL ):

def f_MtchFbrcHykLay( IHyk, CMX, Prm: prmMtchFbrcImg, BinEdg ):

"""
import numpy as np

from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.Mtch.MtchHstAtt import dst_HstAttOne



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class prmMtchFbrcImg:          # ''''''''''''''''''''   prmMtchFbrcImg   ''''''''''''''''''''
    """
    Parameter for matching fabric image-wise
    """
    Wgt      = np.ones( FBRCNBisTyp * FBRCNdty, dtype=np.float32)
    ixT      = -1
    sel      = 0.5


# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_MtchFbrcBisMtx   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Distances between one (sample) image bias fabric 'Ifb' and a collection of image
bias fabrics 'CMX'.

cf from wrapper below.

IN   Ifb    image bias fabric [ntBsv,]
     CMX    collection matrix [nRep,ntBsv]

USE
      DfBis = f_MtchFbrcBisMtx( FFLL.ABIS[3].flatten('F'), FMBS.L3 )
"""
def f_MtchFbrcBisMtx( Ifb: np.ndarray, CMX: np.ndarray, Wgt: np.ndarray | None=None ) -> np.array:

    # ----------   Check Arguments   ----------
    nBisT         = FBRCNBisTyp * FBRCNdty
    nRep, ntBsv   = CMX.shape
    ntBsvI        = len(Ifb)

    assert ntBsv==ntBsvI, f'not same dimensionality: {ntBsv}<>{ntBsvI}'
    assert ntBsv % nBisT==0, f'{ntBsv} / {nBisT} not divisible'

    # ----------   Check Weigts   ----------
    if Wgt is None: Wgt = np.ones( nBisT, dtype=np.float32 )
    nWgts         = len(Wgt)
    
    assert nWgts==nBisT, f"length weigth array not matching bias num {nWgts}<>{nBisT}"

    nClls         = ntBsv // nBisT

    # --------------------   Loop Reps   --------------------
    Dst    = np.empty( nRep, dtype=np.float32 )
    
    for r in range(nRep):

        # square all differences, then sum per bias
        Df2    = np.square( Ifb - CMX[r] ).reshape( nBisT, nClls )
        DfB    = Df2.sum(axis=1) # [nBisT]
        
        Dst[r] = np.sum( DfB * Wgt )   # weighting

    return Dst



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   MTCHFBRCBIS   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Top-down bias matching for the top two layers (top and upper)

For testing purposes we can supply ixT to verify that order is correct. Assumes that
target produces best results, ie use auto-correlation.

IN   IFb   image fabric, we use only bias maps of it.
     COLL  collection fabric

"""
def MTCHFBRCBIS( IFb: fbrcMTXL, COLL, Prm: prmMtchFbrcImg ):

    nRep, ntBsv3 = COLL.L3.shape

    # ------------------------------   Top   ------------------------------
    # fast matching: compare against all
    DstTop   = f_MtchFbrcBisMtx( IFb.ABIS[3].flatten('F'), COLL.L3, Prm.Wgt )

    if Prm.ixT>0:
        assert DstTop[Prm.ixT]==0    

    OrdTop  = DstTop.argsort()

    nSel    = round( nRep * Prm.sel )
    OrdTop  = OrdTop[ 0:nSel ]


    # ------------------------------   Upper   ------------------------------
    # finer matching: compare against selection 'OrdTop' 
    DstUpp   = f_MtchFbrcBisMtx( IFb.ABIS[2].flatten('F'), COLL.L2[OrdTop,:], Prm.Wgt )

    if Prm.ixT>0:
        assert DstUpp[0]==0

    OrdUpp  = DstUpp.argsort()

    OrdOrg  = OrdTop[OrdUpp]
    
    return OrdOrg
    


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_MtchFbrcHykLay   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Matching hyperkolumns of ONE layer against many.

For testing purposes we can supply ixT to verify that order is correct. Assumes that
target produces best results, ie use auto-correlation.

IN   IHyk  hyperkolumns of ONE layer
     CMX   collection matrix [nRep ntBin]

"""
def f_MtchFbrcHykLay( IHyk, CMX, Prm: prmMtchFbrcImg, BinEdg ):

    nCll, nBinC  = IHyk.shape
    nRep, ntBinR = CMX.shape

    assert ntBinR==(nCll*nBinC), f"ntBin not same: {ntBinR} vs {ntBin}"

    Dst = np.zeros(nRep)
    for r in range(nRep):

        RHyk    = CMX[r,:].reshape(nCll,nBinC,order='F')

        dst = 0
        for c in range(nCll):

            dst   += dst_HstAttOne( IHyk[c,:], RHyk[c,:], BinEdg.All )

        Dst[r] = dst

    #breakpoint()
    if Prm.ixT>0:
        assert Dst[Prm.ixT]==0    

    Ord     = Dst.argsort()

    nSel    = round( nRep * Prm.sel )
    Ord     = Ord[ 0:nSel ]
    
    return Ord
    


