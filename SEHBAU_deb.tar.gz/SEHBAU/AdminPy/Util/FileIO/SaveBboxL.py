"""

"""
import numpy as np



""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveBboxL   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

see SaveBboxL.m

"""
def SaveBboxL(sfn, Bbx, bHeadIn=None):

    # -----  Arguments  -----
    bHead = 1  # default is writing WITH header 
    if bHeadIn is not None:
        bHead = bHeadIn  # user input

    # -----  Verify Bboxes  -----
    nBbx, nPrm = Bbx.shape
    if nPrm > 4:
        print('ignoring parameters 5-')
    elif nPrm < 4:
        raise ValueError(f'found only {nPrm} parameters')

    if bHead:
        print(f'Writing {nBbx} boxes to file...')
    else:
        print(f'Writing {nBbx} boxes to file without any header...')

    # =====  Opening File  =====
    try:
        with open(sfn, 'w') as fid:
            # -----  Header  -----
            if bHead:
                fid.write(f'{nBbx}\n')

            # -----  Bboxes  -----
            for i in range(nBbx):
                Bx = Bbx[i, :].astype(np.int16)
                fid.write(f'{Bx[0]} {Bx[1]} {Bx[2]} {Bx[3]}\n')
    except IOError:
        raise IOError(f'Could not write to {sfn}')

    #print('done')
    #DispSave(sfn)
