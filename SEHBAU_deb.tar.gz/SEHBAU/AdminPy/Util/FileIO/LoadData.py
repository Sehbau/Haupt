"""

Load files.

def LoadTextLinewise( lfn ):
def LoadFltTxt( lfn, nFlt ):

"""
import numpy as np



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   LoadTextLinewise   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Loads a text file line by line.

cf LoadDescVect() in LoadDescription.py

"""
def LoadTextLinewise( lfn ):

    if lfn==None:
        print('LoadTextLinewise: no filename provided')
        return None, 0
    
    try:
        with open(lfn, 'r') as file:
            
            aLines = file.readlines()
            
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not open file {lfn}")

    # Strip newline characters
    aLines = [line.rstrip('\n') for line in aLines]
    cLin   = len(aLines)

    return aLines, cLin


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   LoadFltTxt   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads an array of floats from a text file.

"""
def LoadFltTxt( lfn, nFlt ):

    try:
        with open(lfn, 'r') as f:

            Vals = f.read().split()
            if len(Vals) < nFlt:
                raise ValueError(f"Expected at least {nFlt} floats, found {len(Vals)}")
            return np.array(Vals[:nFlt], dtype=np.float32)
        
    except FileNotFoundError:
        
        raise FileNotFoundError(f"File {lfn} not found")
