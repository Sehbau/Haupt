"""

Utility routines

def get_FinasPatWoExt( dirFina, rex ):
def get_FieldNames( C ):
def del_FilesDirPat( path, pat ):
def del_FilesPat( pat ):
def printDotProg( ):

"""

import os
import glob
from pathlib import Path



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   get_FinasPat   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Obtain filenames with regexp pattern. It's a wrapper for glob.glob

"""
def get_FinasPat( dirFina, rex ):

    aLst  = glob.glob( os.path.join( dirFina, rex ) )

    return aLst


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   get_FinasPatWoExt   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Obtain filenames with regexp pattern and return them without extension.

"""
def get_FinasPatWoExt( dirFina, rex ):

    # List the files
    aLst  = glob.glob( os.path.join( dirFina, rex ) )

    # Extract base filenames without extension
    aNam  = [ os.path.splitext( os.path.basename(p) )[0] for p in aLst ]

    return aNam



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   get_FieldNames   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Obtain the fieldnames from a struct

https://stackoverflow.com/questions/11637293/iterate-over-object-attributes-in-python

"""
def get_FieldNames( C ):

    aFn = [a for a in dir( C ) if not a.startswith('__')]

    return aFn



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   del_FilesDirPat   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Delete files by providing directory and regular expression pat.

"""
def del_FilesDirPat( path, pat ):

    for file in Path(path).glob(pat):
        file.unlink()        




""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   del_FilesPat   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Delete files with regular expression pat.

Im not sure whether this is compatible with any OS

"""
def del_FilesPat( pat ):

    for file in glob.glob( pat ):
        os.remove(file)


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   printDotProg   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Print a progress dot.

"""
def printDotProg( ):

    print('.', end='', flush=True)
        
        
