"""

Command support.

- Supports passing arguments to system calls, in particular for RennXXX wrapper
routines.

- Verifies program output for proper termination.

Called from:
- RennDscx.m
- RennMvec1.m
- RennMvecL.m
- RennFocDsc1.m
- etc

------------------------------   CLS SUM   ------------------------------
class argsCmndRenn
class dclsAdminMshp
class cmndArgs

------------------------------   DEF SUM   ------------------------------
def f_CmndExec( cmnd ):
def f_CmndExecRes( cmnd ):
def v_CmndExec( Res ):
def o_CmndArgs( proc: str ) -> cmndArgs:

def pso_OptUnrec(Out: str) -> None:

"""
from dataclasses import dataclass, field
import sys, subprocess, platform

from AdminPy.Util.FileIO.LoadData import *



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class argsCmndRenn:             # ''''''''''''''''''''   argsCmndRenn   ''''''''''''''''''''
    """
    Administrative structure for passing arguments to RennXXX wrapper routines.
    """
    opt       = ''              # options as string. set manually or with u_OptXXX, i_OptXXX
    #pthProg   = ''              # path to program, ie. from FipaExe in globalsSB.py


@dataclass
class dclsAdminMshp:            # ''''''''''''''''''''   dclsAdminMshp   ''''''''''''''''''''
    """
    Administrative structure for binary mshp
    """
    pthProg   = ''              # path to program, ie. from PthProg in globalsSB.py
    pthRef    = ''              # path to reference files

    
@dataclass
class cmndArgs:
    """
    Support structure for argument passing
    """
    proc:   str
    fpPrm:  str = ""
    opt:    str = ""
    fpMes:  str = ""            # only used for 'mvec'
    archit: str = ""            # only used for 'dscx'
    nFld:   int = field(default=None)

    
    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------
    
"""FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF f_CmndExec FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Execute a command (program) given in string 'cmnd' that already includes all
arguments. Dont pass as list []!

"""
def f_CmndExec( cmnd ):

    if sys.platform.startswith('win'):
        cmnd = cmnd.replace('/', '\\')

    Res = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

    # Access status and output
    if Res.returncode != 0:
        raise ValueError(f"command {cmnd} did not execute properly somehow")

    Out  = Res.stdout + Res.stderr

    return Out


"""FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF f_CmndExec FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Same as above but returning results (not Out)

"""
def f_CmndExecRes( cmnd ):

    if sys.platform.startswith('win'):
        cmnd = cmnd.replace('/', '\\')

    Res = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

    # Access status and output
    if Res.returncode != 0:
        raise ValueError(f"command {cmnd} did not execute properly somehow")

    return Res



"""VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV   v_CmndExec   VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

Verify command execution (run). Twice. Because occasionally it failed AND returned
zero instead of non-zero.

"""
def v_CmndExec( Res ):

    if Res.returncode != 0:                         # ^^^^^   failed   ^^^^^

        print( Res.stdout )

        print( Res.stderr )
        
        raise ValueError( f'"command " {Res.args} "did not execute properly"' )

    """ ------ Verify Termination with EoP -----

    Since occasionally my programs return # 0 despite failure, I therefore check
    also for the EoP string

    """
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:

        print( Res.stdout )

        print( Res.stderr )

        raise ValueError( f'"command " {Res.args} "did not execute properly"' )


    

"""OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_CmndArgs   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Structure for passing command line arguments (parameters) responsible for
descriptor extraction and matching. Verified with v_CmndArgs.m

Elsewhere:
- u_PrmFileGen for creating parameter files.
- u_CmndArgsCat to concatenate args.
- v_PrmFileExists for verifying parameter filenames exist.

IN    process     'dscx' | 'mvec' | 'focsel'
OUT   Args        structure

"""
def o_CmndArgs( proc: str ) -> cmndArgs:

    if proc=="dscx":

        return cmndArgs(proc=proc, archit="", nFld=5)
    
    elif proc=='dbin'  or  proc=='fabric'  or proc=='topx' or  proc=='txtra':

        return cmndArgs(proc=proc, nFld=4)
    
    elif  proc=='dqnt':

        Args.fpVoc      = ''
        Args.nFld       = 5    

    elif proc=="mvec":
        
        return cmndArgs(proc=proc, fpMes="", nFld=5)
    
    elif proc=="focsel":
        
        return cmndArgs(proc=proc, nFld=4)
    
    else:
        raise ValueError(f"process {proc} not implemented")    



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_pso_OptUnrec   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Determines if some options have not been recognized.
    
IN    Out   standard output (string)
OUT   None
"""
def pso_OptUnrec(Out: str) -> None:

    # Check if the substring exists in the output text
    if 'unrecognised option' in Out:
        print(Out)
        raise ValueError('unrecognized option')    
