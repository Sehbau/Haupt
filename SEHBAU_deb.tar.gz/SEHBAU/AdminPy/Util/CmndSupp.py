"""

Command support.

- Supports passing arguments to system calls, in particular for RennXXX wrapper
routines.

- Verifies program output for proper termination.

Called from:
- RennDscx.m
- RennMvec1.m
- RennMvecL.m
- RennFocDsc1.m
- etc

"""
from dataclasses import dataclass, field
import sys, subprocess, platform

from AdminPy.Util.FileIO.LoadData import *



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class dclsArgsCmnd:             # ''''''''''''''''''''   dclsArgsCmnd   ''''''''''''''''''''
    """
    Administrative structure for passing arguments to RennXXX wrapper routines.
    """
    opt       = ''              # options as string. set manually or with u_OptXXX, i_OptXXX
    #pthProg   = ''              # path to program, ie. from FipaExe in globalsSB.py


@dataclass
class dclsAdminMshp:            # ''''''''''''''''''''   dclsAdminMshp   ''''''''''''''''''''
    """
    Administrative structure for binary mshp
    """
    pthProg   = ''              # path to program, ie. from PthProg in globalsSB.py
    pthRef    = ''              # path to reference files

    
@dataclass
class dclsCmndArgs:
    """
    Support structure for argument passing
    """
    proc:   str
    fpPrm:  str = ""
    opt:    str = ""
    fpMes:  str = ""            # only used for 'mvec'
    archit: str = ""            # only used for 'dscx'
    nFld:   int = field(default=None)

    
    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------
    
"""FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF f_CmndExec FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Execute a command (program) given in line 'cmnd' that already includes all
arguments.

"""
def f_CmndExec( cmnd ):

    if sys.platform.startswith('win'):
        cmnd = cmnd.replace('/', '\\')

    Res = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

    # Access status and output
    if Res.returncode != 0:
        raise ValueError(f"command {cmnd} did not execute properly somehow")

    Out  = Res.stdout + Res.stderr

    return Out
        


"""VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV   v_CmndExec   VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

Verify command execution (run). Twice. Because occasionally it failed AND returned
zero instead of non-zero.

"""
def v_CmndExec( Res ):

    if Res.returncode != 0:                         # ^^^^^   failed   ^^^^^

        print( Res.stdout )

        print( Res.stderr )
        
        raise ValueError( f'"command " {Res.args} "did not execute properly"' )

    """ ------ Verify Termination with EoP -----

    Since occasionally my programs return # 0 despite failure, I therefore check
    also for the EoP string

    """
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:

        print( Res.stdout )

        print( Res.stderr )

        raise ValueError( f'"command " {Res.args} "did not execute properly"' )


    

"""OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_CmndArgs   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Structure for passing command line arguments (parameters) responsible for
descriptor extraction and matching. Verified with v_CmndArgs.m

Elsewhere:
- u_PrmFileGen for creating parameter files.
- u_CmndArgsCat to concatenate args.
- v_PrmFileExists for verifying parameter filenames exist.

IN    process     'dscx' | 'mvec' | 'focsel'
OUT   Args        structure
"""
def o_CmndArgs( proc: str ) -> dclsCmndArgs:

    if proc == "dscx":

        return dclsCmndArgs(proc=proc, archit="", nFld=5)
    
    elif proc == "mvec":
        
        return dclsCmndArgs(proc=proc, fpMes="", nFld=5)
    
    elif proc == "focsel":
        
        return dclsCmndArgs(proc=proc, nFld=4)
    
    else:
        raise ValueError(f"process {proc} not implemented")    

    

