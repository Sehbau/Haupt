"""Evaluation utilities.

------------------------------   CLS SUM   ------------------------------
------------------------------   DEF SUM   ------------------------------

"""
import numpy as np


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_AccFromPrdAct   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Recognition accuracy from a predicted array Prd given the actual labels Act
"""
def u_AccFromPrdAct( Prd, Act ):

    Bhit   = Prd==Act

    cHit   = np.count_nonzero(Bhit)

    acc    = cHit / len(Bhit)

    return acc
