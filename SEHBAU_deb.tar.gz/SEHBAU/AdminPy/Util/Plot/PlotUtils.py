"""

Utilities for plotting

"""

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   imglabN   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Displays a simple text label and count.

"""
def imglabN(label, count):

    plt.title(f'{label} ({count})')


    
