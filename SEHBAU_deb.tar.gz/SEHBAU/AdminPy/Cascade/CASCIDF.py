"""

Cascade identifier. See CASCIDF.m

"""
from dataclasses import dataclass
import os
from AdminPy.Util.CmndSupp import *
from AdminPy.Util.OrgFile.SaveFipaLst import *
from AdminPy.Util.FileIO.LoadData import *
from AdminPy.MtchVec.FileRead.LoadReadMtc import *



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class dclsCascIdfPrm:
    """
    Parameters for cascade identifier in CASCIDF
    """
    stgy: str
    prpPre: float
    nPre: int
    nImg: int
    mesFull: int = 1                            # always 1 by default

@dataclass
class dclsCascIdfPth:
    """
    Paths for cascade identifier in CASCIDF
    """
    fpMesHst: str
    fpMesKol: str
    fpMesVec: str
    fpMesDtyDis: str
    fpMesDtySim: str

@dataclass
class dclsCascArgs:
    """
    Arguments
    """
    Vec: None
    Hst: str=""

    
    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_CascIdfPrm   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Organizational routine to setup parameters for cascade identifier.

"""
def o_CascIdfPrm( nImg: int, prpPre: float = 0.5, stgy: str = "hist1st") -> dclsCascIdfPrm:

    return dclsCascIdfPrm(
        stgy   = stgy,
        prpPre = prpPre,
        nPre   = round( nImg * prpPre + 0.1 ),
        nImg   = nImg
    )


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_CascIdfPth   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Organizational routine to setup filepaths for cascade identifier.

"""
def o_CascIdfPth(pthMes: str = "") -> dclsCascIdfPth:

    return dclsCascIdfPth(
        fpMesHst    = os.path.join(pthMes, "Mes", "CscHst.txt"),
        fpMesKol    = os.path.join(pthMes, "Mes", "CscKol.txt"),
        fpMesVec    = os.path.join(pthMes, "Mes", "CscVec.txt"),
        fpMesDtyDis = os.path.join(pthMes, "Mes", "MesDtyDis.txt"),
        fpMesDtySim = os.path.join(pthMes, "Mes", "MesDtySim.txt"),
    )


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CascSortReorder   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

"""
def uu_CascSortReorder( Mes, dirc, OrdPre ):

    Mes    = np.array(Mes)
    OrdPre = np.array(OrdPre)

    # Handle direction
    if dirc in ("ascend", 1, "asc"):
        OrdFin = np.argsort(Mes)                # ascending
    elif dirc in ("descend", -1, "desc"):
        OrdFin = np.argsort(-Mes)               # descending
    else:
        raise ValueError(f"Unknown sort direction: {dirc}")

    OrdOrg = OrdPre[OrdFin]
    return OrdOrg



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   CASCIDF   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Two-stage cascade identifier, 1 versus many. Takes a query image and matches it to a
list of reference images, called a register. Assumes we are running in folder
'MtchVec'.

Stage 1:  fast matching with mhst or mkol. preselection
Stage 2:  fine matching with mvec.

cf plcCascIdf.m, lvngRunMcsc.m

IN   FpExe    filepaths of executables. 
     FpQuy    filepaths of query image (.dsc, .hst, .kolm)
     Rgst     register. generated with o_RegistSetSave.m
     Admn     paths, see o_CascIdfPth.m
     Args     command arguments
     Prm      parameters, see o_CascIdfPrm.m

OUT  Res      matching results
     Sto      standard output of commands

uu_CascSortReorder already implemented above but not verified.

"""
def CASCIDF( FpExe, FpQuy, Rgst, Admn, Args, Prm ):

    # created in o_RegistSetSave.m
    fpaRgstHst	= Rgst.fpaHst;
    fpaRgstKol 	= Rgst.fpaKol;
    fpaRgstVec 	= Rgst.fpaDsc;

    fpMesHst  	= Admn.fpMesHst;
    fpMesKol  	= Admn.fpMesKol;
    fpMesVec  	= Admn.fpMesVec;

    fpExeMhstL  = FpExe["mhstL"]
    fpExeMkolL  = FpExe["mkolL"]
    fpExeMvecL  = FpExe["mvecL"]
    
    nImg      	= Prm.nImg;

    @dataclass
    class Res:
        pass
    @dataclass
    class Fll:
        pass
    Sto = {}


    # ------------------------------   STAGE 1 (FAST)   ------------------------------
    # according to a selected strategy
    if Prm.stgy == "hist1st":

        cmndHst      = f"{fpExeMhstL} {FpQuy.hsti} {fpaRgstHst} {fpMesHst} {Args.Hst}"
        Sto["Mhst"]  = f_CmndExec(cmndHst)

        OrdHis, DisHisOrd = LoadSortFltTxt(fpMesHst, nImg)
        OrdPre            = OrdHis[:Prm.nPre]

        Res.DisHisOrd = DisHisOrd

    elif Prm.stgy == "kolm1st":
        
        cmndKol      = f"{fpExeMkolL} {FpQuy.kolm} {fpaRgstKol} {fpMesKol}"
        Sto["Mkol"]  = f_CmndExec(cmndKol)

        OrdKol, DisKolOrd = LoadSortFltTxt(fpMesKol, nImg)
        OrdPre       = OrdKol[:Prm.nPre]

        Res.DisKolOrd = DisKolOrd

    elif Prm.stgy == "ens":
        
        cmndHst = f"{fpExeMhstL} {FpQuy.hsti} {fpaRgstHst} {fpMesHst} {Args.Hst}"
        cmndKol = f"{fpExeMkolL} {FpQuy.kolm} {fpaRgstKol} {fpMesKol}"

        Sto["Mhst"] = f_CmndExec(cmndHst)
        Sto["Mkol"] = f_CmndExec(cmndKol)

        DisHisUor = LoadFltTxt(fpMesHst, nImg)
        DisKolUor = LoadFltTxt(fpMesKol, nImg)

        DisEns    = DisHisUor * DisKolUor
        OrdFin    = np.argsort(DisEns)          # ascending
        OrdPre    = OrdFin[:Prm.nPre]

    else:
        raise ValueError(f"strategy {Prm.stgy} not implemented")

    Res.OrdPre = OrdPre

    #print( DisHisOrd )
    #print( OrdPre )

    # ------------------------------   STAGE 2 (FINE)   ------------------------------
    nPre        = len( OrdPre );

    # save reduced list
    aVecRed = [ Rgst.aVec[i] for i in OrdPre ]
    SaveFipaLstPrependPath( aVecRed, Rgst.pth, fpaRgstVec )

    # execute 
    cmndVec = f"{fpExeMvecL} {FpQuy.dsc} {fpaRgstVec} {Args.Vec.fpPrm} {fpMesVec}"
    if Args.Vec.opt:
        cmndVec += f" {Args.Vec.opt}"

    Sto["Mvec"] = f_CmndExec( cmndVec )

    MesTot = LoadMtchMes( fpMesVec, nPre )
    MESdis = LoadMtchMESdty( Admn.fpMesDtyDis )
    MESsim = LoadMtchMESdty( Admn.fpMesDtySim )

    if Prm.mesFull > 0:
        Fll.MesTot = MesTot
        Fll.MESdis = MESdis
        Fll.MESsim = MESsim

    # ------------------------------   Reorder   ------------------------------
    # total (MesTot)
    Res.OrdDis = uu_CascSortReorder(MesTot[:, 0], "ascend", OrdPre)[:nPre]
    Res.OrdSim = uu_CascSortReorder(MesTot[:, 1], "descend", OrdPre)[:nPre]

    # descriptor-wise
    nDty           = MESdis.shape[1]
    Res.ORDDtyDis  = np.zeros((nDty, nPre), dtype=np.int32)
    Res.ORDDtySim  = np.zeros((nDty, nPre), dtype=np.int32)

    for d in range(nDty):
        Res.ORDDtyDis[d, :] = uu_CascSortReorder(MESdis[:, d], "ascend", OrdPre)[:nPre]
        Res.ORDDtySim[d, :] = uu_CascSortReorder(MESsim[:, d], "descend", OrdPre)[:nPre]

    return Res, Sto, Fll
