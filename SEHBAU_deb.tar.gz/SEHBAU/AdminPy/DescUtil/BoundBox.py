"""

Bounding box routines for fabric.

For bounding box from description files see directory DescExtr/Bbox/

------------------------------   DEF SUM   ------------------------------
def vrf_BboxInBounds( Box: np.ndarray, szV: int, szH: int ) :
def u_BboxRand( nBox, szVrt, szHor ):

"""

import numpy as np



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV   vrf_BboxInBounds   VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

Verifies if focus is within map shape

ai annFabric.py

"""
def vrf_BboxInBounds( Box: np.ndarray, szV: int, szH: int ) :

    top   = Box[0]
    bot   = Box[1]
    lef   = Box[2]
    rit   = Box[3]
    
    if top<0 or bot>szV-1 or lef<0 or rit>szH-1:
        print(f"top {top}  bot {bot}  lef {lef}  rit {rit}")
        raise Error( f"Bounding box out of bounds")


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_BboxRand   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Random bounding boxes
"""
def u_BboxRand( nBox, szVrt, szHor ):

    # 1. Generate random top-left corners (y1, x1)
    # Making sure they leave room for at least a 1-pixel wide/tall box
    Top = np.random.randint(0, szVrt - 1, size=nBox)
    Lef = np.random.randint(0, szHor - 1, size=nBox)

    # 2. Generate random bottom-right corners (Bot, x2) 
    # ensuring Bot > Top and x2 > Lef
    Bot = np.random.randint(Top + 1, szVrt)
    Rit = np.random.randint(Lef + 1, szHor)

    # 3. Stack them together into an Nx4 array
    BBoxs = np.column_stack((Top, Bot, Lef, Rit)).astype(np.int32)

    #BBoxs = np.array([ [5, 120, 80, 230],
     #                  [60, 90, 120, 150] ], dtype=np.int32)
    #top=5; bot=120; lef=80; rit=230

    return BBoxs
