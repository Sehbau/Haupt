% 
% Runs program mvecL (1-versus-List) for three cases:
% 1) images (matching vec files)
% 2) focii  (matching vef files)
% 3) for focii with function wrapper RennMvecL
%
% PREVIOUS  runFocVecFew.m
%


% DEPRECATED: use plcMtcZonLst.m for an example



clear;
run('c:/klab/ppc/PROD/UtilMb/globalsSB');
cd( PthProg.mtchVec );


dirFocii    = '../FocExtr/Focii/';
aFocNa      = dir( [dirFocii '*.vef'] );
%aFocNa      = aFocNa(5:end);              % select '*_f1.vef'
pthFocTst   = [dirFocii aFocNa(1).name];  % chose some testing image
fpRegist    = 'Regist/FocExamp.txt';
SaveFipaLstPrependPath( aFocNa, dirFocii, fpRegist );
finaMesFoc  = 'Mes/FocExamp.txt';

%% =========   Command   ========
cmndFoc     = [finaProg ' ' pthFocTst ' ' fpRegist ' ' finaMesFoc ' ' optS];

[Sts OutFoc] = dos(cmndFoc);

%% -------   Load Matching Results   -------
MtcFoc   	= LoadMtchMes(finaMesFoc, length(aFocNa));

%% -------   Plot Metric Measurements  --------
figure(2); clf;
[nr nc] = deal(2,1);
subplot(nr,nc,1); bar(MtcFoc(:,1)); title('Distances');
subplot(nr,nc,2); bar(MtcFoc(:,2)); title('Similarities');
% its own should be zero for distance (and high for similarity)
% note that a value of -2 means NOT loaded/matched


%% --------------------------------------------------------------
%                As Function (for the Two Focii)
%  --------------------------------------------------------------
Admin       = u_CmndAdmin();
Admin.optS  = optS;

OutFnc  = RennMvecL( pthFocTst, fpRegist, finaMesFoc, Admin );
u_StdOutOptUnrec(OutFnc);

