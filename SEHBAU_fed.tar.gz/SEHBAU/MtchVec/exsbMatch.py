"""

Matching with binary 'mvec1' in bare form, meaning without wrapper routines and plotting.

Analogous to exsbMatch.m

"""
import sys
import subprocess

## --------------------------------------------------------------
#                          DESC EXTR
#  --------------------------------------------------------------
print('Descriptor extraction for two frames...');

# win with backslash for output directory
if sys.platform.startswith('win'):

    cmndF1 = r'..\DescExtr\dscx Imgs/Frm1.png Desc\Frm1'  # raw string to handle backslash
    cmndF2 = r'..\DescExtr\dscx Imgs/Frm2.png Desc\Frm2' 
    
elif sys.platform.startswith('linux') or sys.platform.startswith('darwin'):

    cmndF1 = '../DescExtr/dscx Imgs/Frm1.png Desc/Frm1'
    cmndF2 = '../DescExtr/dscx Imgs/Frm2.png Desc/Frm2'

Res1  = subprocess.run( cmndF1, shell=True, capture_output=True, text=True)
Res2  = subprocess.run( cmndF2, shell=True, capture_output=True, text=True)


## --------------------------------------------------------------
#                          MATCH
#  --------------------------------------------------------------
# should work for both OSs, as we dont write to file
if sys.platform.startswith('win'):

    cmndM = r'mvec1 Desc/Frm1.dsc Desc/Frm2.dsc'
else:
    cmndM = r'./mvec1 Desc/Frm1.dsc Desc/Frm2.dsc'  # including ./ for linux

ResM  = subprocess.run( cmndM, shell=True, capture_output=True, text=True )


# Access status and output
if ResM.returncode != 0:
    raise ValueError("mvec1 did not execute properly somehow")

if 0:
    print( ResM.stdout )


## ------------------------------   Parse Output   ------------------------------
# no file is generated with mvec1, only standard output.
sys.path.insert(0, '..')        
#import AdminPy as sb
from AdminPy import MtchVec as mvec

# parse standard output (pso_)
Sto, Hed         = mvec.pso_Mvec1Sections( ResM.stdout )
AMesDty, mesTot  = mvec.pso_Mvec1Vals( Sto );

print( f'dis {mesTot.dis}   sim {mesTot.sim}' )



