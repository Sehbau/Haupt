
mvec1 Desc/img1.vec Desc/img2.vec

REM mvec1 Desc/img1.vec Desc/img2.vec --bDISP 8