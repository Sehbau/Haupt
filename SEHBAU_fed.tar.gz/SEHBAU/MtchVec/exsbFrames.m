% 
% Runs program mvec1, for two frames. Plots correspondence.
%
% For multiple files see exsbMvecLimg.m
%
clear;
run('../globalsSB');        % assumes script is run from dir 'MtchVec'

%% --------------------------------------------------------------
%                          DESC EXTR
%  --------------------------------------------------------------
% run descriptor extraction for two frames
fprintf('Descriptor extraction...');
pthFrm1 	= 'Imgs/Frm1.png';
pthFrm2 	= 'Imgs/Frm2.png';

pthDsc1 	= 'Desc/Frm1';
pthDsc2   	= 'Desc/Frm2';

pthDsc1     = u_PathToBackSlash( pthDsc1 );
pthDsc2     = u_PathToBackSlash( pthDsc2 );

AdminDscx 	= u_CmndAdmin( PthProg.descExtr );

OutDscx1    = RennDscx( pthFrm1, pthDsc1, AdminDscx );
OutDscx2    = RennDscx( pthFrm2, pthDsc2, AdminDscx );

fprintf('fertig\n');

%% --------------------------------------------------------------
%                          MATCH
%  --------------------------------------------------------------
fprintf('Matching...');

%% --------   Options   --------
OptK            = u_OptMvecStc();
OptK.tolMtc     = 0.1;
OptK.wgtPos     = 0.5;
OptK.wgtRGB     = 0.8;
OptK.cntTolMtc  = 0.05;
OptK.rsgTolMtc  = 0.06;
OptK.arcTolMtc  = 0.07;
OptK.strTolMtc  = 0.08;
optS            = i_OptMvec(OptK);

AdminMvec       = u_CmndAdmin( PthProg.mtchVec );
AdminMvec.optS  = optS;

OutMtc  = RennMvec1( [pthDsc1 '.vec'], [pthDsc2 '.vec'], AdminMvec );
fprintf('fertig\n');

%OutMtcOwn = RennMvec1( [pthDsc1 '.vec'], [pthDsc1 '.vec'], AdminMvec );

%% -------   Read Out StdOut   -------
[Sto Hed]         = u_MtrMesSecs( OutMtc );
[AMesDty mesTot]  = u_MtrMesScnf( Sto );

%% -------   Plot Metric Measurements   --------
figure(1); clf;
bImg        = 1;
%p_MvvDtyVx(MesI, Ndsc1I, bImg);
p_MvvDty( AMesDty );


%% --------------------------------------------------------------
%                       CORRESPONDENCE
%  --------------------------------------------------------------
fprintf('Correspondence...\n');

%% ------------   Load NNs   ----------------
finaNNcnt = 'Mes/NNspcCnt12';
[ANNCnt Ncnt nLev] = LoadNNDspace( finaNNcnt ); 
[ANNRsg Nrsg nLev] = LoadNNDspace( 'Mes/NNspcRsg12' );
[ANNArc Narc nLev] = LoadNNDspace( 'Mes/NNspcArcGst12' );
[ANNStr Nstr nLev] = LoadNNDspace( 'Mes/NNspcStrGst12' );
[ANNShp Nshp nLev] = LoadNNDspace( 'Mes/NNspcShp12' );

DispLoad( finaNNcnt );

%% ------------    Load DESCS   -------------
DSC1 = LoadDescVect( [pthDsc1 '.vec'] );
DSC2 = LoadDescVect( [pthDsc2 '.vec'] );

%% ------------    Load BonPix   -------------
[ABON1  Nbon1 SzM]  = LoadBonPixPyr( [pthDsc1 '.BonPix']);
[ABON2  Nbon2 SzM]  = LoadBonPixPyr( [pthDsc2 '.BonPix']);

%[CNT1 Ncnt1]   = LoadCntxSpcEpt([pthDsc1 '.CntEpt']);
%[CNT2 Ncnt2]   = LoadCntxSpcEpt([pthDsc2 '.CntEpt']);

%% ------   Display the 2 Frames    -------
% for illustration
figure(2); clf; 
p_SUBtig(1,2,1); imagesc( imread( pthFrm1 ) );
p_SUBtig(1,2,2); imagesc( imread( pthFrm2 ) );


%% ----------------   Contours (Skelet)   --------------
% All in unit coordinates.
% We invert y-axis: once for plotting descriptors and once for
% correspondence using utility routine u_PosVHinvertToIJ.
figure(5); clf; [nr nc]=deal(nLev,1);

for lv = 1:nLev

    p_SUBtig( nr,nc,lv, 'margin', 0.01); hold on;

    p_DescCorrespPair( 'cnt', DSC1.ACNT{lv}, DSC2.ACNT{lv} );

    PosA       = DSC1.ACNT{lv}.Pos;
    PosB       = DSC2.ACNT{lv}.Pos;

    PosA       = u_PosVHinvertToIJ( PosA );
    PosB       = u_PosVHinvertToIJ( PosB );
    PosB.Hor   = PosB.Hor + 1; % shift to right side

    p_DescCorrespLine( PosA, PosB, ANNCnt{lv} );

end
axis ij;

%% ----------------   RadSig   --------------
% In pixel coordinates; no inversion of y-axis. 
% We indicate correspondence with position info. Could also be done with
% descriptor points.
nLev = 3;
figure(6); clf; [nr nc]=deal(nLev,1);

for lv = 1:nLev

    p_SUBtig( nr,nc,lv, 'margin', 0.01); hold on;

    DA      = DSC1.ARSG{lv};
    DB      = DSC2.ARSG{lv};
    [aBon2] = p_DescCorrespPair( 'rsg', DA, DB, ...
                    SzM(lv,:), ABON1{lv}, ABON2{lv} );
    
    PosA    = DA.Pos;
    PosB    = DB.Pos;
    
    PosA    = u_PosVHscaleup( PosA, SzM(lv,:), 0 );
    PosB    = u_PosVHscaleup( PosB, SzM(lv,:), 0 );

    PosB    = u_PosVHshift( PosB, 0, SzM(lv,2) );
    
    p_DescCorrespLine( PosA, PosB, ANNRsg{lv} );
    
end
axis ij;

%% ----------------   Arcs   --------------
% In pixel coordinates; no inversion of y-axis. 
% We indicate correspondence with position info. Could also be done with
% descriptor points.
nLev = 2;
figure(7); clf; [nr nc]=deal(nLev,1);

for lv = 1:nLev

    p_SUBtig( nr,nc,lv, 'margin', 0.01); hold on;

    DA      = DSC1.AARCgst{lv};
    DB      = DSC2.AARCgst{lv};
    
    p_DescCorrespPair( 'arc', DA, DB, SzM(lv,:) );
    
    PosA    = DA.Pos;
    PosB    = DB.Pos;
    
    PosA    = u_PosVHscaleup( PosA, SzM(lv,:), 0 );
    PosB    = u_PosVHscaleup( PosB, SzM(lv,:), 0 );

    PosB    = u_PosVHshift( PosB, 0, SzM(lv,2) );
    
    p_DescCorrespLine( PosA, PosB, ANNArc{lv} );
    
end
axis ij;

%% ----------------   Strs   --------------
% same as arcs above.
nLev = 2;
figure(8); clf; [nr nc]=deal(nLev,1);

for lv = 1:nLev

    p_SUBtig( nr,nc,lv, 'margin', 0.01); hold on;

    DA      = DSC1.ASTRgst{lv};
    DB      = DSC2.ASTRgst{lv};
    
    p_DescCorrespPair( 'str', DA, DB, SzM(lv,:) );
    
    PosA    = DA.Pos;
    PosB    = DB.Pos;
    
    PosA    = u_PosVHscaleup( PosA, SzM(lv,:), 0 );
    PosB    = u_PosVHscaleup( PosB, SzM(lv,:), 0 );

    PosB    = u_PosVHshift( PosB, 0, SzM(lv,2) );
    
    p_DescCorrespLine( PosA, PosB, ANNStr{lv} );
    
end
axis ij;


