% 
% Runs program mvecL (1-versus-List) for dtop files.
%
% Assumes that exsbFrames.m was run (and better no other dsc files present)
%
clear;
run('../AdminMb/globalsSB');
cd( PthProg.mtchVec );

%% ----------   Create the Top Files   -----------
cmnd1  = ['../DescUtil/topx Desc/Frm1.dsc Dtop/Frm1'];
cmnd2  = ['../DescUtil/topx Desc/Frm2.dsc Dtop/Frm2'];

if ispc
    cmnd1    = u_PathToBackSlash( cmnd1 );
    cmnd2    = u_PathToBackSlash( cmnd2 );
end

Out1        = system( cmnd1 );
Out2        = system( cmnd2 );

%% ---------    Prepare Top Matching   ----------
fipaImgTst  = 'Dtop/Frm1.dtop';      % testing image 
aImgNaRep   = dir('Dtop/Frm*.dtop'); % representation/reference image
fpRegist    = 'Regist/FrameTop.txt';
SaveFipaLstPrependPath( aImgNaRep, 'Dtop/', fpRegist );
finaMes     = 'Mes/TopExamp.txt';
finaPrm     = 'Params/PrmMtch_PosTolSlm.txt';

%% --------   Options   --------
OptK            = o_MvecArgs();
OptK.tolMtc     = 0.1;
OptK.wgtPos     = 0.5;
OptK.wgtRGB     = 0.8;
OptK.cntTolMtc  = 0.05;
OptK.rsgTolMtc  = 0.06;
OptK.arcTolMtc  = 0.07;
OptK.strTolMtc  = 0.08;
optS            = i_MvecArgs(OptK);

%% =========   Command   ========
finaProg    = 'mvecL';
cmndImg     = [finaProg ' ' fipaImgTst ' ' fpRegist ' ' finaPrm ' ' finaMes];
%cmndImg     = [cmndImg ' ' optS];

[Sts OutImg] = system(cmndImg);
OutImg

%% -------   Load Matching Results   -------
MesImg       = LoadMtchMes( finaMes, length(aImgNaRep) );
DisDTY       = LoadMtchMESdty( 'Mes/MesDtyDis.txt' );
SimDTY       = LoadMtchMESdty( 'Mes/MesDtySim.txt' );

%% -------   Plot Metric Measurements   --------
figure(1); clf;
[nr nc] = deal(2,1);
subplot(nr,nc,1); bar( MesImg(:,1) ); title('Distances');
subplot(nr,nc,2); bar( MesImg(:,2) ); title('Similarities');




