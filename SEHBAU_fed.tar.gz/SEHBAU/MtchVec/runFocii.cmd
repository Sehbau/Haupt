
mvec1 Desc\foc1.vef Desc\foc2.vef

REM mvec1 Desc\foc1.vef Desc\foc2.vef --bDISP 8

