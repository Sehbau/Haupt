% 
% Runs demo for salient texture blobs for two images.
%
% Loads saliency file (.slc) and plots blob bounding boxes for numerous and
% high-contrast regions.
%
% Assumes script is run from directory 'Demos'
%
clear;
run('../AdminMb/globalsSB');        

%% ---------    FieldMound Image    ----------
cmnd = '../DescExtr/dscx Imgs/FieldMound.jpg Desc/FieldMound';

if ispc 
    cmnd = u_PathToBackSlash( cmnd ); end

system( cmnd );

SLC         = LoadDescSalc( 'Desc/FieldMound.slc' );
BlbBbxFld   = SLC.Blb.Box;
DscFld      = SLC.Dsc;
TxaFld      = SLC.Txa;

%% ---------    Plot FieldMound    ----------
figure(1); clf;

Bnum    = BlbBbxFld.Typ==1;        % numerous
Benk    = BlbBbxFld.Typ==8;        % high-contrast

Ifield  = imread('Imgs/FieldMound.jpg'); 

imagesc( Ifield );

p_BboxL( BlbBbxFld.Box( Bnum, :) );
p_BboxL( BlbBbxFld.Box( Benk, :), [1 0.5 0] ); % orange


%% ---------    SnowCovMount Image    ----------
cmnd = '../DescExtr/dscx Imgs/SnowCovMount.jpg Desc/SnowCovMount';

if ispc
    cmnd = u_PathToBackSlash( cmnd ); end

system( cmnd );

SLC         = LoadDescSalc( 'Desc/SnowCovMount.slc' );
BlbBbxSnw   = SLC.Blb.Box;
TxaSnw      = SLC.Txa;
DscSnw      = SLC.Dsc;

%% ---------    Plot SnowCovMount    ----------
figure(2); clf;

Bnum    = BlbBbxSnw.Typ==1;        % numerous
Benk    = BlbBbxSnw.Typ==8;        % high-contrast

Isnow = imread('Imgs/SnowCovMount.jpg'); 

imagesc( Isnow );

p_BboxL( BlbBbxSnw.Box( Bnum, :) );
p_BboxL( BlbBbxSnw.Box( Benk, :), [1 0.5 0] ); % orange


%% ---------    Plot Some Variables   ---------
GstField    = u_TxtrGstToArrs( TxaFld.Gst );
GstSnow     = u_TxtrGstToArrs( TxaSnw.Gst );
PrpPres     = [ GstField.PrpPres GstSnow.PrpPres ];
%Density     = [ MstField.Men     MstSnow.Men ]; % not so interesting
%Variability = [ MstField.Sdv     MstSnow.Sdv ]; % not so interesting

MxSizShp    = [ DscFld.MaxSizScl.Shp DscSnw.MaxSizScl.Shp ];
CvgShp      = [ DscFld.CvgShp.Deg    DscSnw.CvgShp.Deg ];
CtrRngRR    = [ DscFld.MxRngRR       DscSnw.MxRngRR ];
CtrRngBon   = [ DscFld.MxRngBon      DscSnw.MxRngBon ];
MeanMaxGry  = [ DscFld.GryMmm(2:3)   DscSnw.GryMmm(2:3)]';
nLev        = DscFld.MaxSizScl.nLev;

[aLbTxtr nBis] = o_TxtrLabels();

figure(3); clf; [nr nc] = deal( 4, 2 );

subplot(nr,nc,1);
bar( PrpPres );
set( gca, 'xtick', 1:nBis );
set( gca, 'xticklabel', aLbTxtr );
ylabel(' Prop Present');
legend( {'Field' 'Snow'} );

subplot(nr,nc,2);
bar( MxSizShp );
set( gca, 'xtick', 1:nLev );
xlabel('Level');
ylabel('Max Size Shp');
%legend( {'Field' 'Snow'} );

subplot(nr,nc,4);
bar( CvgShp );
set( gca, 'xtick', 1:nLev );
xlabel('Level');
ylabel('Coverage Shape');
%legend( {'Field' 'Snow'} );

subplot(nr,nc,3);
bar( CtrRngBon );
set( gca, 'xtick', 1:nLev );
xlabel('Level');
ylabel('Max Contrast Boundaries');
legend( {'Field' 'Snow'} );

subplot(nr,nc,5);
bar( CtrRngRR );
set( gca, 'xtick', 1:nLev );
xlabel('Level');
ylabel('Max Contrast Ridge/River');
legend( {'Field' 'Snow'} );

subplot(nr,nc,7);
bar( MeanMaxGry );
set( gca, 'xtick', 1:2 );
set( gca, 'xticklabel', {'Mean' 'Max'} );
ylabel('Mean & Max Gray');
%legend( {'Field' 'Snow'} );



%%
if 0
subplot(nr,nc,2);
bar( Density );
set( gca, 'xtick', 1:nTyp );
set( gca, 'xticklabel', aLbBlob );
ylabel(' Mean Value');
legend( {'Field' 'Snow'} );

subplot(nr,nc,3);
bar( Variability );
set( gca, 'xtick', 1:nTyp );
set( gca, 'xticklabel', aLbBlob );
ylabel('Variability');
legend( {'Field' 'Snow'} );
end
