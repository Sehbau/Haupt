% 
% Displays texture maps.
% 
clear;
run('../AdminMb/globalsSB');        

%% =========   Execute Dscx   ========
%fipaImg  = 'Imgs/img3.jpg';    fipsOut  = 'Desc/img3';
fipaImg  = 'Imgs/street.jpg';  fipsOut  = 'Desc/street';

optS    = '--saveKol --saveTxm';

cmnd    = ['../DescExtr/dscx ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd        = u_PathToBackSlash( cmnd );
    [Sts Out]   = dos(cmnd);    % excecute program for windows
elseif isunix
    [Sts Out]   = unix(cmnd);   % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 ); % verify output

%% ----------   Load    ---------
TXM                 = LoadTxtrMaps( [fipsOut '.txm'] ); 
[Txa Shp Ens Dsc] 	= LoadDescSalc( [fipsOut '.slc'] ); 

% see o_BlobLabels.m
Bhor    = Txa.Blb.Typ==5;       % horizontal
BboxHor = Txa.Blb.Box( Bhor, :);

Bvrt    = Txa.Blb.Typ==4;       % vertical
BboxVrt = Txa.Blb.Box( Bvrt, :);


%% -------------   Plot Maps   -------------
figure(2); clf;
[nr nc] = deal(4,2);

subplot(nr,nc,1);
imagesc( imread( fipaImg ) );
p_BboxL( BboxHor );
p_BboxL( BboxVrt );

subplot(nr,nc,2);
imagesc( TXM.KNT.Num ); title('Num (Count)');

subplot(nr,nc,3);
imagesc( TXM.KNT.Blk ); title('Blk (Blank)');

subplot(nr,nc,4);
imagesc( TXM.OTX.Hor ); title('Horizontal');

subplot(nr,nc,5);
imagesc( TXM.OTX.Vrt ); title('Vertical');

subplot(nr,nc,6);
imagesc( TXM.OTX.Axi ); title('Axi');

subplot(nr,nc,7);
imagesc( TXM.OTX.Nil ); title('Nil');



