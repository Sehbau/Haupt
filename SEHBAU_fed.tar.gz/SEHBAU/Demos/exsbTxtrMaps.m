% 
% Displays texture maps.
% 
clear;
run('../AdminMb/globalsSB');        

%% =========   Execute Dscx   ========
%fipaImg  = 'Imgs/img3.jpg';    fipsOut  = 'Desc/img3';
fipaImg  = 'Imgs/street.jpg';  fipsOut  = 'Desc/street';

optS    = '--saveKol --saveTxm';

cmnd    = ['../DescExtr/dscx ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd        = u_PathToBackSlash( cmnd );
    [Sts Out]   = dos(cmnd);    % excecute program for windows
elseif isunix
    [Sts Out]   = unix(cmnd);   % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 ); % verify output

%% -------------   Load    ---------------
TXM             = LoadTxtrMaps( [fipsOut '.txm'] ); 
[SLC HedSlc]    = LoadDescSalc( [fipsOut '.slc'] ); 

Irgb            = imread( fipaImg );

%% -------------   Retrieve Bboxes   -------------
aLbBlob         = o_BlobLabels();
L2LSclFct       = f_LevToLaySclFct( HedSlc.szI, HedSlc.szL );
SBbxOrg         = u_BlobBbxRtrv( SLC.Txa.Blb, aLbBlob );
SBbxLay         = u_BlobBbxRtrv( SLC.Txa.Blb, aLbBlob, L2LSclFct );

%% -------------   Plot Maps   -------------
PlotTxtrMaps( TXM, 2, Irgb );
PlotTxtrMaps( TXM, 3, Irgb, SBbxLay );

subplot(3,3,1);
p_BboxL( SBbxOrg.Hor );
p_BboxL( SBbxOrg.Vrt );

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2Jpeg( [dirFigs 'TxtrMaps'], 3 );
end

