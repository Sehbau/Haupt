%
% An example for a road scene. af exsbPlotShape.m
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'Demos'
    
strImg      = 'aachen.png';
%strImg      = 'highway.jpg';

fipaImg     = [ 'Imgs/' strImg];         % image path
fipsOut     = [ 'Desc/' strImg(1:end-4)]; % output filestem

% change to window backslash (in case we are on windows)
if ispc
    fipaImg  = u_PathToBackSlash( fipaImg ); 
    fipsOut  = u_PathToBackSlash( fipsOut ); 
end

%% --------   Options   --------
OptK            = o_DscxArgs();
OptK.nLev       = 3 ;
OptK.depth      = 3 ;
OptK.saveRegUnv = 1 ;    
OptK.saveBonSpc = 1 ;
optS            = i_DscxArgs(OptK);

%% =========   Command   ========
cmnd        = [ FipaExe.dscx ' ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd    = u_PathToBackSlash( cmnd );
end

[Sts Out]   = system(cmnd);      

v_CmndExec( Sts, Out, cmnd, 1 );

%% -------   Load Region Pixels   -------
Fixt                = o_FileExtensions();
fpDSC               = o_FinaApndExtDscx( fipsOut, Fixt ); 

[AREG KtReg]        = LoadRegUnv(   fpDSC.ruv );
[DSC Kt Hed]        = LoadDescImag( fpDSC.dsc );    
[ABON Nbon SzM AOrg] = LoadBonPixSpc( fpDSC.bspx );    
SLC                 = LoadDescSalc( fpDSC.slc );

%% ---------------    Plot    -------------------
figRed  = 1;
hf      = figure(figRed); clf; 
imagesc( imread(fipaImg) ); hold on;
p_VisSearch( SLC.Dsc.Cnt.PixRed.Pt );

%% --- Shapes
figShp  = 2;
hf = figure(figShp); clf; set(hf, 'name', 'shape'); 
for lev = 1:Kt.nLev

    % --- retrieve:
    SHP         = DSC.ASHP{lev};         % extracting one level
    SHP.LabScors = DSC.LabShpScors;
    SHP.LabSfine = DSC.LabShpSfine;
    ABonPix     = ABON{lev};
    ARegPix     = AREG(lev,:);
    Org         = AOrg{lev};

    szM         = SzM(lev,:);

    % --- plot boundaries on LEFT
    subplot(3, 2, lev*2-1); hold on;
    set(gca,'fontsize',8);
    
    Sel = p_ShpAxial( SHP, ABonPix );        % *** plot ***
    
    axis ij;
    set(gca,'xlim',[1 szM(2)]);
    set(gca,'ylim',[1 szM(1)]);
    ylabel(['Lev ' num2str(lev)] );
    
    % --- create maps on RITE
    MpTot = zeros( szM([2 1]), 'single');   % inverse: 
    for t = 1:6
        IxSel   = Sel.IxAxi( Sel.Typ==t );
        length(IxSel)
        Mp      = u_RegPixToMapSel( ARegPix, Org, IxSel, szM, 20+t*30 );
        MpTot   = MpTot + Mp;
    end
    %Bblank = MpTot==0;
    %MpTot( Bblank ) = 255;
    
    % --- plot map on RITE
    subplot(3, 2, lev*2);
    imagesc(  MpTot' ); %colormap(gray);
    set(gca,'fontsize',8);
    
end
set(gcf, 'paperposition', [0.5 0.25 7 10.75]);

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2File( [dirFigs 'RoadSceneRed'], 1, 1, figRed );
    PrintFig2File( [dirFigs 'RoadSceneShp'], 1, 1, figShp );
end

