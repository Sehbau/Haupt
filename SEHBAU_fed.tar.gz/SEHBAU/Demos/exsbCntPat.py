"""
 start with exsbTxtrMaps.py
"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')

import AdminPy as sb

from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.DescExtr.DescFile.LoadDescription import LoadCntPatVmx
from AdminPy.DescExtr.OrgAtt.OrgAtts import o_AttsLabPat
import AdminPy.DescExtr.Bbox.PlotBboxes as PltBbx

Fixt      = o_FileExtensions()

# ------------------------------   DesxExtr   ------------------------------
imgNa     = 'highway.jpg'
#imgNa     = 'street.jpg'
#imgNa     = 'forest.jpg'

imgNa     = Path( imgNa )
pthImg    = Path( 'Imgs/' ) / imgNa
pthDesc   = Path( 'Desc/' ) / imgNa.stem

cmnd      = [ Path('../DescExtr/dscx'), pthImg, pthDesc, '--saveRRE' ]

# Run descriptor extractor
Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Sts       = Res.returncode
OutDscx   = Res.stdout + Res.stderr

fpDSC     = o_FinaApndExtDscx( str(pthDesc), Fixt )

# --------------------------------------------------------------------------------
#                               CNTPAT
# --------------------------------------------------------------------------------
print('CntPat...')

cmnd      = [ Path('../DescUtil/cntpat'), fpDSC.rre, pthDesc ]

Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Sts       = Res.returncode
Out       = Res.stdout + Res.stderr

Vrt, Hor  = LoadCntPatVmx( fpDSC.cptVmx )


# ------------------------------   Plot Matrices   ------------------------------
LabAtt    = o_AttsLabPat()

import matplotlib.pyplot as plt

# Create a figure with 1 row and 2 columns of subplots
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

# plot the Vrt matrix on the first subplot
nAttSel = 11
im1 = ax1.imshow(Vrt.VEC[:,0:nAttSel], cmap='viridis', aspect='auto')
ax1.set_xticks(range(nAttSel)) 
ax1.set_xticklabels(LabAtt[0:nAttSel], rotation=45, ha='right')
ax1.set_title('Vertical (Vrt)')
fig.colorbar(im1, ax=ax1, label='Intensity')

# plot the Hor matrix on the second subplot
im2 = ax2.imshow(Hor.VEC[:,0:nAttSel], cmap='plasma', aspect='auto')
ax2.set_title('Horizontal (Hor)')
ax2.set_xticks(range(nAttSel)) 
ax2.set_xticklabels(LabAtt[0:nAttSel], rotation=45, ha='right')
fig.colorbar(im2, ax=ax2, label='Intensity')

# Automatically adjust spacing between subplots
plt.tight_layout()
plt.show(block=False)


# ------------------------------   Plot Segments   ------------------------------
# see exsbCntPat.m
