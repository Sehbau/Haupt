% 
% Runs demo for small object detection. Uses two images, birds in the sky
% and fireworks.
%
% Uses long option --txws to adjust the size of the texture window.
%
% Assumes script is run from directory 'Demos'
%
clear;
run('../AdminMb/globalsSB');        

%% ---------    Bird Image    ----------
% we run with a window size of 8 pixels.
cmnd = '../DescExtr/dscx Imgs/birds.jpg Desc/birds --txws 8';

cmnd = u_PathToBackSlash( cmnd );

system( cmnd );

SLC     = LoadDescSalc( 'Desc/birds.slc' );
Bbx     = SLC.Blb.Box;

%% ---------    Plot Bird    ----------
figure(1); clf;

Bnum    = Bbx.Typ==1;        % numerous
Benk    = Bbx.Typ==8;        % high-contrast

Ibirds = imread('Imgs/birds.jpg'); 

imagesc( Ibirds );

p_BboxL( Bbx.Box( Bnum, :) );
p_BboxL( Bbx.Box( Benk, :), [1 0.5 0] ); % orange



%% ---------    Fireworks Image    ----------
% we run with a window size of 6 pixels.
cmnd = '../DescExtr/dscx Imgs/fireworks.jpg Desc/fireworks --txws 6';

cmnd = u_PathToBackSlash( cmnd );

system( cmnd );

SLC     = LoadDescSalc( 'Desc/fireworks.slc' );
Bbx     = SLC.Blb.Box;


%% ---------    Plot Fireworks    ----------
figure(2); clf;

Bnum    = Bbx.Typ==1;        % numerous
Benk    = Bbx.Typ==8;        % high-contrast

Ifirew = imread('Imgs/fireworks.jpg'); 

imagesc( Ifirew );

p_BboxL( Bbx.Box( Bnum, :) );
p_BboxL( Bbx.Box( Benk, :), [1 0.5 0] ); % orange

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2Jpeg( [dirFigs 'SmlObjDetSky'], 1 );
end