"""Example for object identification using two-stage cascade: fabric kernel,
followed by vector matching (mvec1). This shows only the principal. 

afro exsbFabric.py, exsbFabricRec.py, plcFocProp.py

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescUtil.RennDbin import RennDbin, RennFabric, RennFbrc2Ar
from AdminPy.FocSel import RennFocHst1, RennFocDsc1

from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Texture.FabricIO import *

from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.DescExtr.Hist.DescBinAnf import *
from AdminPy.Util.UtilImg import *



# ------------------------------   Paths   ------------------------------
crrDir      = os.getcwd()
strImg      = 'room.png'
fipaImg     = crrDir / Path( 'Imgs/' + strImg )          # image path
fstmOut     = crrDir / Path( 'Desc/' + strImg[:-4] )     # output file path
Fixt        = o_FileExtensions()
fpDSC       = o_FinaApndExtDscx( fstmOut, Fixt )

# ------------------------------   Dscx (Step 1)   ------------------------------
ArgsDscx        = o_CmndArgs('dscx')
ArgsDscx.opt    = ' --saveRRE --saveCVP';

StdOut          = RennDscx( fipaImg, fstmOut, ArgsDscx, sb.PthProg['descExtr'] )

# ------------------------------   Dbin (Step 2)   ------------------------------
fpPrm           = 'Params/PrmDbin_Cabinet.txt'; 
Fixt            = o_FileExtensions()
ArgsDbin        = o_CmndArgs( 'dbin' )
ArgsDbin.fpPrm  = fpPrm
ArgsDbin.opt    = '--all'

os.chdir( sb.PthProg['descUtil'] )
OutDbin         = RennDbin( fpDSC.dsc, fstmOut, ArgsDbin )

# ------------------------------   Fabric & fbrc2arr   ------------------------------
fpDSC           = o_FinaApndExtDscx( fstmOut, Fixt )
fipaCbnt        = fpDSC.hsspa # [fstmOut Fixt.hsspa];
ArgsFbrc        = o_CmndArgs( 'fabric' );

pthFbrc         = sb.PthProg['descUtil']

# we run both, 'fabric' and 'fbrc2arr'
OutFbrc         = RennFabric( fipaCbnt, fstmOut, ArgsFbrc, pthFbrc )
OutFbAr         = RennFbrc2Ar( fpDSC.fbrc, fstmOut, pthFbrc )

# ------------------------------   Load Output   ------------------------------
dmy, HedFbc     = LoadFabric( fpDSC.fbrc )  # we need the image size for scaling factors
FFLL            = LoadFbrcArrays( fpDSC )   # FabricIO.py

BinEdg          = i_BinEdgFromLoad( HedFbc.NbinAtt, HedFbc.NbinDty )
szImg           = [HedFbc.Hed.szV, HedFbc.Hed.szH]


# --------------------------------------------------------------------------------
#                         F O C U S   E X T R A C T I O N 
# --------------------------------------------------------------------------------
# We extract a focus as representation: kernel and descriptors

# --- selected focus
top=160; bot=245; lef=450; rit=540 # black microwave/cabinet
#top=240; bot=320; lef=50; rit=95 # fire exstinguisher
#top=280; bot=315; lef=480; rit=520 # stove
#top=280; bot=320; lef=520; rit=580 # faucet
#top=180; bot=260; lef=330; rit=390 # ventilator/towel dispenser
BoxRep       = np.array([top, bot, lef, rit], dtype=np.int32)
dimBoxPrpRep = u_BboxProport( BoxRep, szImg )

# ------------------------------   kernel   ------------------------------
# wrapper in Fabric.py
FKrnl        = f_FbrcKrnlFoc1( FFLL, BoxRep, szImg )

# ------------------------------   descriptors   ------------------------------
fpFocRep     = str(fstmOut) +'_Foc1' 
ArgsRenn     = sb.Util.argsCmndRenn
pthFocSel    = sb.PthProg['focSel']

SzFocRep, OutFocRep  = RennFocDsc1( fpDSC.dsc, BoxRep, fpFocRep, ArgsRenn, pthFocSel )


# --------------------------------------------------------------------------------
#
#                        I D E N T F I C A T I O N
#
# --------------------------------------------------------------------------------
# Now we use the representation to find it in the image using a two-stage cascade
# process:
#    1)   fast-matching with fabric kernel
#    2)   slow-matching with descriptors using mvec1

# --------------------------------------------------------------------------------
#                              STEP 1: Kernel
#
# as in exsbFabricRec.py
# we look for the above focus description 'FKrnl' in the fabric description
# 'FFLL'
import AdminPy.Recognize.FbrcAly as faly

# accelerated using quick-reject conditions
PrmIdf      = faly.i_FbrcIdfPrm()
SCOR        = faly.Krnl1Accel( FFLL, FKrnl, PrmIdf, BinEdg )

# ------------------------------   Locate   ------------------------------
import AdminPy.Recognize.RecUtil as rcut
import AdminPy.Orga.PixAnf as px
AMAX      = []
AIX       = []
nLaySus   = FKrnl.Dim.nLay
BBox      = np.zeros( (nLaySus,4), dtype=np.int32 )
for l in range(nLaySus):

    SMax   = rcut.f_MapLocMaxima( SCOR.AHyk[l] )

    # -----  BoundingBox from predicted location
    ixLay     = nLaySus-1-l # counting was inverted during top-down analysis
    BBox[l,:] = u_FocBboxFromLocLay( SMax.Rw[0], SMax.Cl[0],
                                     ixLay, dimBoxPrpRep, szImg )

    print( f" rw={SMax.Rw[0]:2d}  cl={SMax.Cl[0]:2d} " )

    AMAX.append( SMax )

# ------------------------------   Focus around Loc   ------------------------------
# FabricFoc.py
BoxSmpCrst = BBox[0,:]
print(BoxSmpCrst)

fpFocSmp      = str(fstmOut) + '_FocSmp' 
SzFocSmp, OutFocSmp  = RennFocDsc1( fpDSC.dsc, BoxSmpCrst, fpFocSmp, ArgsRenn, pthFocSel )

from scipy.ndimage import zoom


# --------------------------------------------------------------------------------
#                              STEP 2: Mvec1
#
# mvec1 requires focii of same height (nLev), therefore we check:
assert SzFocRep.nLev==SzFocSmp.nLev, "nLevels not same somehow"

FixtFoc    = o_FileExtensFoc()
nLevStr    = str(SzFocRep.nLev)

fpRepLv    = fpFocRep + '_lev' + nLevStr + FixtFoc.dscf
fpSmpLv    = fpFocSmp + '_lev' + nLevStr + FixtFoc.dscf

os.chdir( sb.PthProg['mtchVec'] )
cmnd       = 'mvec1 ' + fpRepLv + ' ' + fpSmpLv 
Res        = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
v_CmndExec( Res )
#M.OutFoc      = RennMvec1( fipaQ, finaR, Admin );

#u_StdOutOptUnrec( M.OutFoc );

from AdminPy.MtchVec.MetricMeas import *
Sto, Hed           = pso_Mvec1Sections( Res.stdout )
AMesDty, totFoc    = pso_Mvec1Vals( Sto );

print( totFoc.dis )

# ------------------------------   Plot   ------------------------------
from PIL import Image
Irgb     = np.array(Image.open(fipaImg))

IptcRep      = u_IptchFromBbox( Irgb, BoxRep )  # the corresponding patch in the image
IptcSmpCrst  = u_IptchFromBbox( Irgb, BoxSmpCrst )
IptcSmpCors  = None
if nLaySus>1:
    IptcSmpCors  = u_IptchFromBbox( Irgb, BBox[1,:] )

nLaySus  = FKrnl.Dim.nLay
figScor  = 1
faly.p_MapsScor( figScor, Irgb, IptcRep, SCOR, FKrnl.Dim.nLay, IptcSmpCrst, IptcSmpCors )




