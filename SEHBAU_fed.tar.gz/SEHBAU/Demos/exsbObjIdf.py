"""Example for object identification using two-stage cascade: fabric kernel,
followed by vector matching (mvec1). This shows only the principal. 

afro exsbFabric.py, exsbFabricRec.py, plcFocProp.py

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescUtil.RennDbin import RennDbin, RennFabric, RennFbrc2Ar
from AdminPy.FocSel import RennFocHst1, RennFocDsc1

from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Texture.FabricIO import *

from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.DescExtr.Hist.DescBinAnf import *
from AdminPy.Util.UtilImg import *



# ------------------------------   Paths   ------------------------------
crrDir      = os.getcwd()
strImg      = 'room.png'
fipaImg     = crrDir / Path( 'Imgs/' + strImg )          # image path
fstmOut     = crrDir / Path( 'Desc/' + strImg[:-4] )     # output file path
Fixt        = o_FileExtensions()
fpDSC       = o_FinaApndExtDscx( fstmOut, Fixt )

# ------------------------------   Dscx (Step 1)   ------------------------------
ArgsDscx        = o_CmndArgs('dscx')
ArgsDscx.opt    = ' --saveRRE --saveCVP'; # required by dbin

StdOut          = RennDscx( fipaImg, fstmOut, ArgsDscx, sb.PthProg['descExtr'] )

# ------------------------------   Dbin (Step 2)   ------------------------------
fpPrm           = 'Params/PrmDbin_Cabinet.txt'; 
Fixt            = o_FileExtensions()
ArgsDbin        = o_CmndArgs( 'dbin' )
ArgsDbin.fpPrm  = fpPrm
ArgsDbin.opt    = '--all'

os.chdir( sb.PthProg['descUtil'] )
OutDbin         = RennDbin( fpDSC.dsc, fstmOut, ArgsDbin )

# ------------------------------   Fabric & Fbrc2arr   ------------------------------
fpDSC           = o_FinaApndExtDscx( fstmOut, Fixt )
fipaCbnt        = fpDSC.hsspa # [fstmOut Fixt.hsspa];
ArgsFbrc        = o_CmndArgs( 'fabric' );

pthFbrc         = sb.PthProg['descUtil']

# we run both, 'fabric' and 'fbrc2arr'
OutFbrc         = RennFabric( fipaCbnt, fstmOut, ArgsFbrc, pthFbrc )
OutFbAr         = RennFbrc2Ar( fpDSC.fbrc, fstmOut, pthFbrc )

# ------------------------------   Load Output   ------------------------------
dmy, HedFbc     = LoadFabric( fpDSC.fbrc )  # we need the image size for scaling factors
FImg            = LoadFbrcArrays( fpDSC )   # LoadFabric.py

BinEdg          = i_BinEdgFromLoad( HedFbc.NbinAtt, HedFbc.NbinDty )
szImg           = [HedFbc.Hed.szV, HedFbc.Hed.szH]


# --------------------------------------------------------------------------------
#                         F O C U S   E X T R A C T I O N 
# --------------------------------------------------------------------------------
# We extract a focus as representation: kernel and descriptors

# --- selected focus
top=160; bot=245; lef=450; rit=540 # black microwave/cabinet
#top=240; bot=320; lef=50; rit=95 # fire exstinguisher
#top=280; bot=315; lef=480; rit=520 # stove
#top=280; bot=320; lef=520; rit=580 # faucet
#top=180; bot=260; lef=330; rit=390 # ventilator/towel dispenser
BoxRep       = i_Bbox( top, bot, lef, rit )
BoxRepUrg    = u_BboxUnitRg( BoxRep, szImg )

# ------------------------------   kernel   ------------------------------
# wrapper in Fabric.py
FFoc         = f_FbrcFocBox1( FImg, BoxRep, szImg )
FKrnl        = f_FbrcKernel( FFoc )

# ------------------------------   descriptors   ------------------------------
fpFocRep     = str(fstmOut) +'_Foc1' 
ArgsRenn     = sb.Util.argsCmndRenn
pthFocSel    = sb.PthProg['focSel']

SzFocRep, OutFocRep  = RennFocDsc1( fpDSC.dsc, BoxRep, fpFocRep, ArgsRenn, pthFocSel )


    
# --------------------------------------------------------------------------------
#
#                        I D E N T F I C A T I O N
#
# --------------------------------------------------------------------------------
# Now we use the representation to find it in the image using a two-stage cascade
# process:
#    1)   fast-matching with fabric matching (flesh & kernel)
#    2)   slow-matching with descriptors using mvec1

# --------------------------------------------------------------------------------
#                              STEP 1: Flesh, Kernel
#
# as in exsbFabricRec.py: we look for the above focus description 'FKrnl' in the
# image fabric 'FImg'
import AdminPy.Mtch.MtchFbrcFlsh as mfbf
import AdminPy.Mtch.MtchFbrcKrnl as mfbk
import AdminPy.Mtch.MtchFbrcUtil as mfbu

PrmIdf    = mfbk.i_FbrcIdfPrm()

# flesh-based: exhaustive
SCORflsh  = mfbf.Flsh1Exhst( FImg, FFoc,  PrmIdf, BinEdg )

# kernel-based: accelerated using quick-reject conditions
SCORkrnl  = mfbk.Krnl1Accel( FImg, FKrnl, PrmIdf, BinEdg )

# ------------------------------   Locate   ------------------------------
#import AdminPy.Orga.PixAnf as px
#nLaySus   = FKrnl.Dim.nLay

BoxPrdKrnl, AMAX  = mfbu.u_OutlFromScorFbrc( SCORkrnl, BoxRepUrg, szImg, FKrnl.Dim.nLay )
BoxPrdFlsh, AMAX  = mfbu.u_OutlFromScorFbrc( SCORflsh, BoxRepUrg, szImg, FKrnl.Dim.nLay )
    
# ------------------------------   Focus around Loc   ------------------------------
# FabricFoc.py
BoxKrnlCrst  = BoxPrdKrnl[0,:]
BoxFlshCrst  = BoxPrdFlsh[0,:]
print(BoxKrnlCrst)

fpFocSmp     = str(fstmOut) + '_FocSmp' 
SzFocSmp, OutFocSmp  = RennFocDsc1( fpDSC.dsc, BoxKrnlCrst, fpFocSmp, ArgsRenn, pthFocSel )


# --------------------------------------------------------------------------------
#                              STEP 2: Mvec1
#
# mvec1 requires focii of same height (nLev), therefore we check:
assert SzFocRep.nLev==SzFocSmp.nLev, "nLevels not same somehow"

FixtFoc    = o_FileExtensFoc()
nLevStr    = str(SzFocRep.nLev)

fpRepLv    = fpFocRep + '_lev' + nLevStr + FixtFoc.dscf
fpSmpLv    = fpFocSmp + '_lev' + nLevStr + FixtFoc.dscf

os.chdir( sb.PthProg['mtchVec'] )
cmnd       = 'mvec1 ' + fpRepLv + ' ' + fpSmpLv 
Res        = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
v_CmndExec( Res )
#M.OutFoc      = RennMvec1( fipaQ, finaR, Admin );

#u_StdOutOptUnrec( M.OutFoc );

from AdminPy.MtchVec.MetricMeas import *
Sto, Hed           = pso_Mvec1Sections( Res.stdout )
AMesDty, totFoc    = pso_Mvec1Vals( Sto );

print( totFoc.dis )

# ------------------------------   Plot   ------------------------------
from PIL import Image
import AdminPy.Recognize.RecUtil as rcut
Irgb          = np.array(Image.open(fipaImg))

IptcRep       = u_IptchFromBbox( Irgb, BoxRep )  # the corresponding patch in the image

AIptchKrnl    = rcut.u_IptchFromBoxLst( Irgb, BoxPrdKrnl )
AIptchFlsh    = rcut.u_IptchFromBoxLst( Irgb, BoxPrdFlsh )

figKrnl  = 1
figFlsh  = 2
mfbu.p_MapsScor( figKrnl, Irgb, IptcRep, SCORkrnl, FKrnl.Dim.nLay, AIptchKrnl )
mfbu.p_MapsScor( figFlsh, Irgb, IptcRep, SCORflsh, FKrnl.Dim.nLay, AIptchFlsh )



