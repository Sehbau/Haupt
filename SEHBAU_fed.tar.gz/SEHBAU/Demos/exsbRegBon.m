%
% Saving and plotting of region universe and boundary space.
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'Demos'
    
strImg      = 'aachen.png';

fipaImg     = [ 'Imgs/' strImg];         % image path
fipsOut     = [ 'Desc/' strImg(1:end-4)]; % output filestem

% change to window backslash (in case we are on windows)
if ispc
    fipaImg  = u_PathToBackSlash( fipaImg ); 
    fipsOut  = u_PathToBackSlash( fipsOut ); 
end

%% --------   Options   --------
OptK            = o_DscxArgs();
OptK.nLev       = 3 ;
OptK.depth      = 3 ;
OptK.saveRegUnv = 1 ;               % ****  needs to be ON  ****
OptK.saveBonSpc = 1 ;               % ****  needs to be ON  ****
optS            = i_DscxArgs(OptK);

%% =========   Command   ========
cmnd        = [ FipaExe.dscx ' ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd    = u_PathToBackSlash( cmnd );
    [Sts Out] = dos(cmnd);      % excecute program for windows
elseif isunix
    [Sts Out] = unix(cmnd);     % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 );

%% -------   Load Region Pixels   -------
Fixt            = o_FileExtensions();
fpDSC           = o_FinaApndExtDscx( fipsOut, Fixt );

[AREG KtReg] 	= LoadRegUnv(    fpDSC.ruv );
[ABON Nbon SzM] = LoadBonPixSpc( fpDSC.bspx );
[DSC Kt Hed] 	= LoadDescImag(  fpDSC.dsc );    

if Hed.space==2,
    warning('not tested yet for scale space');
end

%% ------    Plot    ---------
Irgb         	= imread( fipaImg );
szI         	= [ Hed.szV Hed.szH ];

figure(1); clf; 
imagesc( Irgb );

figure(2); clf; 
PlotRegUnv( AREG, szI );

figure(3); clf; 
PlotRegUnv( AREG, szI, 'gray' );

figure(4); clf; 
PlotBonSpc( ABON, szI, 1 ); 
set(gcf, 'paperposition', [0.5 0.25 7 10.75]);

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2File( [dirFigs 'RegUnv'], 1, 1, 2 );
    PrintFig2File( [dirFigs 'BonSpc'], 1, 1, 4 );
end


