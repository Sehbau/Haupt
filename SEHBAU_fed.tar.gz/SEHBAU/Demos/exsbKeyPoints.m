%
% Demo for saving and loading keypoints.
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'Demos'

%% -------    Dscx 1 Image   ----------
strImg      = 'room.png';

fipaImg     = ['Imgs/' strImg];             % image path
fstmOut 	= ['Desc/' strImg(1:end-4)];    % output file path

Args        = o_CmndArgs( 'dscx' );
Args.opt    = '--saveKeyp';

[OutDscx]   = RennDscx( fipaImg, fstmOut, Args, PthProg.descExtr );


%% -------    Load & Plot KeyPoints   ---------
Fixt        = o_FileExtensions();
kypf        = [fstmOut Fixt.kyp];

[KYP Kt HedKyp]    = LoadDescKeyp( kypf );

Irgb        = imread( fipaImg );

fprintf('Plotting...Geduld...\n');
PlotDescSpcKeyPts( Irgb, HedKyp.space, KYP.ACNT, 1, 'Skel' );

% form has its own routine
PlotFormSpcKeyPts( Irgb, HedKyp.space, KYP.AFRM, 2, 'Form');

PlotDescSpcKeyPts( Irgb, HedKyp.space, KYP.AARC, 3, 'Arc' );
PlotDescSpcKeyPts( Irgb, HedKyp.space, KYP.ASTR, 4, 'Straighter' );

