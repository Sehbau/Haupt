%
% Saving and plotting of contour universe: map pixels, and the traced
% segment (curve) pixels.
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'Demos'
    
%strImg      = 'aachen.png';
%strImg      = 'room.png';
%strImg      = 'birds.jpg';
strImg      = 'highway.jpg';

fipaImg     = [ 'Imgs/' strImg];         % image path
fipsOut     = [ 'Desc/' strImg(1:end-4)]; % output filestem

% change to window backslash (in case we are on windows)
if ispc
    fipaImg  = u_PathToBackSlash( fipaImg ); 
    fipsOut  = u_PathToBackSlash( fipsOut ); 
end

%% --------   Options   --------
OptK            = o_DscxArgs();
OptK.nLev       = 6 ;
OptK.saveCntMps = 1 ;               % ****  needs to be ON  ****
OptK.saveCntUnv = 1 ;               % ****  needs to be ON  ****
%OptK.imgSpc     = 2 ;               % scale space
optS            = i_DscxArgs(OptK);

%% =========   Command   ========
cmnd        = [ FipaExe.dscx ' ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd    = u_PathToBackSlash( cmnd );
    [Sts Out] = dos(cmnd);      % excecute program for windows
elseif isunix
    [Sts Out] = unix(cmnd);     % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 );

%% -------   Load Region Pixels   -------
Fixt        = o_FileExtensions();
fpDSC       = o_FinaApndExtDscx( fipsOut, Fixt );

Irgb        = imread( fipaImg );
MPS         = LoadCntMaps( fpDSC.cntMps );
CPX         = LoadCntUniv( fpDSC.cuv );

%% ------    Plot    ---------
figNoMps    = 1;
figNoCpx    = 2;
MPS.nLev    = 4;         % one less looks better
%CPX.nLev    = 4;         % one less looks better
PlotCntMaps(   MPS, figNoMps, Irgb );
PlotCntCrvPix( CPX, figNoCpx, Irgb );


%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2File( [dirFigs 'CntMps'], 1, 1, figNoMps );
    PrintFig2File( [dirFigs 'CntUnv'], 1, 1, figNoCpx );
    %PrintFig2Jpeg( [dirFigs 'CntSpcEptRRE'], figNo );
end
