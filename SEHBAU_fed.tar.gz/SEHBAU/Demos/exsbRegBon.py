"""

Plotting regions and boundaries.

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescExtr.DescFile import LoadDescUniv, LoadDbinUniv
from AdminPy.DescExtr.Saliency import LoadDescSalc

Fixt      = o_FileExtensions()

# ------------------------------   DesxExtr   ------------------------------
#imgNa     = 'aachen.png'
imgNa     = 'highway.jpg';

imgNa     = Path( imgNa )
pthImg    = Path( 'Imgs/' ) / imgNa
pthDesc   = Path( 'Desc/' ) / imgNa.stem

# ------------------------------   Options   ------------------------------
OptK            = argsDscx()
OptK.nLev       = 3 
OptK.depth      = 3 
OptK.saveRegUnv = 1     
OptK.saveBonSpc = 1 
optS            = i_DscxArgs(OptK)

cmnd      = str(Path('../DescExtr/dscx ')) + str(pthImg) + ' ' + str(pthDesc) + ' ' + optS

# Run descriptor extractor
Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Sts       = Res.returncode
Out       = Res.stdout + Res.stderr

fpDSC     = o_FinaApndExtDscx( str(pthDesc), Fixt )


# ------------------------------   Load   ------------------------------
import AdminPy.DescExtr.DescFile.LoadFeatures as lodf

AREG, KtReg   = lodf.LoadRegUnv(   fpDSC.ruv ) 
ABON, Jbsp    = lodf.LoadBonPixSpc( fpDSC.bspx );

import imageio.v3 as iio
Irgb          = iio.imread( pthImg )
IrgbOrg       = Irgb.copy() # make a copy for the 2nd level

# ------------------------------   Retrieve   ------------------------------
from AdminPy.DescExtr.DescFile.Features.RegUtil import *
import numpy as np

# Plotting works only for level 0 if pyramid was specified (default). For higher
# levels I need to subsample Irgb to the corrsponding level
lev       = 0    
dth       = 1
ixR       = 5
IxReg     = u_RegIxLin1( AREG, lev, dth, ixR )

Row, Col  = np.unravel_index(IxReg, Irgb.shape[:2])
# blank out the region across all 3 color channels
Irgb[Row,Col,:] = 255

# ----------   Level 1   ----------
# we need to downsample the image
import skimage.transform as skimage_transform
IrgbQut   = skimage_transform.rescale(IrgbOrg, scale=(0.5, 0.5, 1), anti_aliasing=True)
IrgbQut   = (IrgbQut*255).astype(np.uint8)

lev       = 1
dth       = 0
ixR       = 3
IxReg     = u_RegIxLin1( AREG, lev, dth, ixR )

Row, Col  = np.unravel_index(IxReg, IrgbQut.shape[:2])

IrgbQut[Row,Col,:] = 255

# ------------------------------   Plot Selected Ones   ------------------------------
import matplotlib.pyplot as plt

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))

ax1.imshow(Irgb)
ax1.set_title("Original Image")
ax1.axis('off')  # Hide axes borders and labels for this subplot

ax2.imshow(IrgbQut)
ax2.set_title("Quarter Resolution")
ax2.axis('off')  # Hide axes borders and labels for this subplot

plt.tight_layout()
plt.show(block=False)


# ------------------------------   Plot All   ------------------------------
from AdminPy.DescExtr.DescFile.Features.RegUtil import *

PlotRegUnv( AREG, Irgb.shape )
PlotRegUnv( AREG, Irgb.shape, 'gray' )

PlotBonSpc( ABON, Irgb.shape, 1 )



