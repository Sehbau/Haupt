#!/usr/bin/bash
#!/bin/bash

# --- Conversion from windows to unix ---

# Saved under windows: need to eliminate the carriage return and change permission

# sed -i 's/\r$//' runDemos.sh
# bash ./runDemos.sh

echo ------------------------------------------------------------
echo		Descriptor Extraction fuer images 1 and 2 
echo ------------------------------------------------------------

../DescExtr/dscx Imgs/fireworks.jpg Desc/fireworks --bDISP 3 || { echo "dscx failed"; exit 1; }
../DescExtr/dscx Imgs/SnowCovMount.jpg Desc/SnowCovMount --bDISP 3

