"""

Displays some saliency info for two different textures.

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')

import AdminPy as sb
import AdminPy.DescExtr as dscx

Fixt, Dmy = sb.Orga.o_FileExtensions()

# ------------------------------   FieldMound   ------------------------------
fipaImg   = Path( 'Imgs/FieldMound.jpg' )
fipsDsc   = Path( 'Desc/FieldMound' )
fbinDscx  = Path( '../DescExtr/dscx' )

cmnd      = [ fbinDscx, fipaImg, fipsDsc ]

Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

if Res.returncode != 0:
    raise ValueError("dscx did not execute properly somehow")

fipaSalc  = fipsDsc.with_suffix( Fixt.salc )

SLC, Hed  = dscx.LoadDescSalc( fipaSalc )

TxaFld    = SLC.Txa
BlbFld    = SLC.Blb.Box
DscFld    = SLC.Dsc
#print( DscFld.Ndsc.Skl )

# ------------------------------   PlotFieldMound   ------------------------------
import matplotlib.pyplot as plt
import imageio.v3 as iio

Ifield = iio.imread( fipaImg )

Bnum   = BlbFld.Typ == 1          # numerous
Benk   = BlbFld.Typ == 8          # high-contrast

fig1, ax1 = plt.subplots(figsize=(10, 8))
ax1.imshow(Ifield)
ax1.axis('off')

# Plot bounding boxes
dscx.PlotBboxes.p_BboxL(ax1, BlbFld.Box[Bnum, :])                     # default color
dscx.PlotBboxes.p_BboxL(ax1, BlbFld.Box[Benk, :], rgbOrIx=[1, 0.5, 0])  # orange
#                       plt.show()


# ------------------------------   SnowCovMount   ------------------------------
fipaImg   = Path( 'Imgs/SnowCovMount.jpg' )
fipsDsc   = Path( 'Desc/SnowCovMount' )

cmnd      = [ fbinDscx, fipaImg, fipsDsc ]

Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

if Res.returncode != 0:
    raise ValueError("dscx did not execute properly somehow")

fipaSalc  = fipsDsc.with_suffix( Fixt.salc )

SLC, Hed  = dscx.LoadDescSalc( fipaSalc )

BlbSnw    = SLC.Blb.Box;
TxaSnw    = SLC.Txa;
DscSnw    = SLC.Dsc;

# ------------------------------   PlotSnowCovMount   ------------------------------
Isnow  = iio.imread( fipaImg )

Bnum   = BlbSnw.Typ == 1          # numerous
Benk   = BlbSnw.Typ == 8          # high-contrast

fig2, ax2 = plt.subplots(figsize=(10, 8))
ax2.imshow(Isnow)
ax2.axis('off')

# Plot bounding boxes
dscx.PlotBboxes.p_BboxL(ax2, BlbSnw.Box[Bnum, :])                     # default color
dscx.PlotBboxes.p_BboxL(ax2, BlbSnw.Box[Benk, :], rgbOrIx=[1, 0.5, 0])  # orange

#plt.show()
plt.show(block=False) #, plt.pause(2)


## ------------------------------   Extract Some Vars   ------------------------------
LabBlob     = sb.DescExtr.OrgAtts.o_TxtrLabels()
GstField    = dscx.Texture.u_TxtrGstToArrs( TxaFld.Gst, LabBlob.aSho )
GstSnow     = dscx.Texture.u_TxtrGstToArrs( TxaSnw.Gst, LabBlob.aSho )

# Concatenation to array
import numpy as np

PrpPres     = np.concatenate((GstField.PrpPres.reshape(1,-1),
                              GstSnow.PrpPres.reshape(1,-1)), axis=0)
MxSizShp    = np.concatenate((DscFld.MaxSizScl.Shp.reshape(1,-1),
                              DscSnw.MaxSizScl.Shp.reshape(1,-1)), axis=0)
CvgShp      = np.concatenate((DscFld.CvgShp.Deg.reshape(1,-1),
                              DscSnw.CvgShp.Deg.reshape(1,-1)),axis=0)
CtrRngRR    = np.concatenate((DscFld.MxRngRR.reshape(1,-1),
                              DscSnw.MxRngRR.reshape(1,-1)), axis=0)
CtrRngBon   = np.concatenate((DscFld.MxRngBon.reshape(1,-1),
                              DscSnw.MxRngBon.reshape(1,-1)), axis=0)

# 
MeanMaxGry  = np.array([
    DscFld.GryMmm[1],
    DscFld.GryMmm[2],
    DscSnw.GryMmm[1],
    DscSnw.GryMmm[2]
]).reshape(-1, 1)



## ------------------------------   Plot Some Vars   ------------------------------
nLev          = DscFld.MaxSizScl.nLev
BlbLab        = dscx.o_TxtrLabels()
#aLbBlob, nTyp = dscx.OrgAtts.o_TxtrLabels()

fig, axes = plt.subplots(4, 2, num=3, figsize=(10, 12))  # figure(3); clf;
axes      = axes.ravel()

# ----------  Subplot 1
ax0   = axes[0]
width = 0.25
xax   = np.arange( BlbLab.nLab )               # x-axis (label positions)

ax0.bar(xax - width/2, PrpPres[0,:], width, label='Field')
ax0.bar(xax + width/2, PrpPres[1,:], width, label='Snow')

ax0.set_xticks(xax)
ax0.set_xticklabels(BlbLab.aSho)
ax0.set_ylabel('Prop Present')
ax0.legend()
ax0.set_title('Blob Presence per Type')

# ----------  Subplot 2
ax1   = axes[1]
xax   = np.arange( nLev ) + 1                    # x-axis (levels)

ax1.bar( xax-width/2, MxSizShp[0,:], width )
ax1.bar( xax+width/2, MxSizShp[1,:], width )

ax1.set_xticks(xax)
ax1.set_xlabel('Level')
ax1.set_ylabel('Prop of Img')
ax1.set_title('Max Size by Shape')


# ----------  Subplot 3
ax2   = axes[2]

ax2.bar( xax-width/2, CvgShp[0,:], width )
ax2.bar( xax+width/2, CvgShp[1,:], width )

ax2.set_xticks(xax)
ax2.set_xlabel('Level')
ax2.set_ylabel('Prop of Img')
ax2.set_title('Coverage Shape')


# ----------  Subplot 5
ax4   = axes[4]
ax4.imshow( DscFld.DomOriCntMx )


# ----------  Subplot 6
ax5   = axes[5]
ax5.imshow( DscSnw.DomOriCntMx )


plt.show(block=False)
plt.pause(2)




