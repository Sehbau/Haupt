"""

Example for a list. Only fast identification so far.

afro exsbObjIdf.py

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescUtil.RennDbin import RennDbin, RennFabric, RennFbrc2Ar
from AdminPy.FocSel import RennFocHst1, RennFocDsc1

from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Texture.FabricIO import *

from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.DescExtr.Hist.DescBinAnf import *
from AdminPy.Util.UtilImg import *


# ------------------------------   Paths   ------------------------------
crrDir      = os.getcwd()
strImg      = 'room.png'
fipaImg     = crrDir / Path( 'Imgs/' + strImg )          # image path
fstmOut     = crrDir / Path( 'Desc/' + strImg[:-4] )     # output file path
Fixt        = o_FileExtensions()
fpDSC       = o_FinaApndExtDscx( fstmOut, Fixt )

# ------------------------------   Dscx (Step 1)   ------------------------------
ArgsDscx        = o_CmndArgs('dscx')
ArgsDscx.opt    = ' --saveRRE --saveCVP';

StdOut          = RennDscx( fipaImg, fstmOut, ArgsDscx, sb.PthProg['descExtr'] )

# ------------------------------   Dbin (Step 2)   ------------------------------
fpPrm           = 'Params/PrmDbin_Cabinet.txt'; 
Fixt            = o_FileExtensions()
ArgsDbin        = o_CmndArgs( 'dbin' )
ArgsDbin.fpPrm  = fpPrm
ArgsDbin.opt    = '--all'

os.chdir( sb.PthProg['descUtil'] )
OutDbin         = RennDbin( fpDSC.dsc, fstmOut, ArgsDbin )

# ------------------------------   Fabric & fbrc2arr   ------------------------------
fpDSC           = o_FinaApndExtDscx( fstmOut, Fixt )
fipaCbnt        = fpDSC.hsspa # [fstmOut Fixt.hsspa];
ArgsFbrc        = o_CmndArgs( 'fabric' );

pthFbrc         = sb.PthProg['descUtil']

# we run both, 'fabric' and 'fbrc2arr'
OutFbrc         = RennFabric( fipaCbnt, fstmOut, ArgsFbrc, pthFbrc )
OutFbAr         = RennFbrc2Ar( fpDSC.fbrc, fstmOut, pthFbrc )

# ------------------------------   Load Output   ------------------------------
dmy, HedFbc = LoadFabric( fpDSC.fbrc )  # we need the image size for scaling factors
FFLL        = LoadFbrcArrays( fpDSC )   # FabricIO.py
szImg       = [HedFbc.Hed.szV, HedFbc.Hed.szH]

BinEdg      = i_BinEdgFromLoad( HedFbc.NbinAtt, HedFbc.NbinDty )


# --------------------------------------------------------------------------------
#                     F K E R N E L    E X T R A C T I O N 
# --------------------------------------------------------------------------------
BOXrep    = np.zeros( (5,4), dtype=np.int32 )
BOXrep[0] = [160, 245, 450, 540] # black microwave/cabinet
BOXrep[1] = [240, 320,  50,  95] # fire exstinguisher
BOXrep[2] = [280, 315, 480, 520] # stove
BOXrep[3] = [280, 320, 520, 580] # faucet
BOXrep[4] = [180, 260, 330, 390] # ventilator/towel dispenser

#for b in range(5):
    #BOXrep[b,:] = f_BboxEnlarge1(BOXrep[b,:], szImg, (0.3, 0.3) )
    #BOXrep[b,:] = f_BboxShrink1( BOXrep[b,:], szImg, (0.15, 0.15) )
    #BOXrep[b,:] = f_BboxShrink1( BOXrep[b,:], szImg, (0.35, 0.35) )

# ------------------------------   kernel   ------------------------------
# wrapper in Fabric.py
bDisp     = 1
AFKrnl    = f_FbrcKrnlFocLst( FFLL, BOXrep, szImg, bDisp )

# ------------------------------   descriptors   ------------------------------
if 0:
    # to be implemented
    fpFocRep     = str(fstmOut) + '_Foc1' 
    ArgsRenn     = sb.Util.argsCmndRenn
    pthFocSel    = sb.PthProg['focSel']
    
    SzFocRep, OutFocRep  = RennFocDsc1( fpDSC.dsc, BoxRep, fpFocRep, ArgsRenn, pthFocSel )


# --------------------------------------------------------------------------------
#                        I D E N T F I C A T I O N
# --------------------------------------------------------------------------------

# ------------------------------   Scores TopDown Kernel   ------------------------------
import AdminPy.Recognize.FbrcAly as faly

PrmIdf    = faly.i_FbrcIdfPrm()

bDisp     = 1

# FbrcAly.py
SCR       = faly.KrnlLstAccel( FFLL, AFKrnl, PrmIdf, BinEdg, bDisp )

# ------------------------------   'Predicted' Bboxes   ------------------------------
from PIL import Image
Irgb     = np.array(Image.open(fipaImg))

nKrnl     = len(AFKrnl)

AIptcRep  = []
AIptc     = [[] for i in range(nKrnl)]

for k in range(nKrnl):

    # the selection
    BoxRep    = BOXrep[k,:]
    IptcRep   = u_IptchFromBbox( Irgb, BoxRep )  # the corresponding patch in the image
    AIptcRep.append( IptcRep )
    
    dimBoxPrp = u_BboxProport( BoxRep, szImg )

    nLaySus   = AFKrnl[k].Dim.nLay              # nLayers for this kernel rep
    for l in range( nLaySus ):

        Scor    = deepcopy( SCR[k][l] )
        ixLay   = nLaySus - 1 - l
        Box     = u_FocBboxFromLocLay( Scor.Rw[0], Scor.Cl[0], ixLay, dimBoxPrp, szImg )

        #ABox.aL[l].append( Box )

        Iptc    = u_IptchFromBbox( Irgb, Box )

        AIptc[k].append( Iptc )
        
        #print(l)


# ------------------------------   PLOT   ------------------------------
figSel = 1
hf = plt.figure(figSel)
hf.clf()

nr, nc = 6, 4

ax = hf.add_subplot(nr, nc, 1)
ax.imshow(Irgb)
ax.tick_params(labelsize=5)

for k in range(nKrnl):
    
    ax = hf.add_subplot(nr, nc, (k+1)*nc+1)
    ax.imshow( AIptcRep[k] )
    if k==0: ax.set_title('Sel')
    plt.show(block=False)

    ax = hf.add_subplot(nr, nc, (k+1)*nc+2)
    ax.imshow( AIptc[k][0] )
    if k==0: ax.set_title('Coarsest')
    plt.show(block=False)

    if AFKrnl[k].Dim.nLay>1:
        ax = hf.add_subplot(nr, nc, (k+1)*nc+3)
        ax.imshow( AIptc[k][1] )
        if k==0: ax.set_title('Coarse')
        plt.show(block=False)

    if AFKrnl[k].Dim.nLay>2:
        ax = hf.add_subplot(nr, nc, (k+1)*nc+4)
        ax.imshow( AIptc[k][2] )
        if k==0: ax.set_title('Fine')
        plt.show(block=False)

