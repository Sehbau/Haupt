"""

Example for a list. Only fast identification so far.

afro exsbObjIdf.py

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Util import o_CmndArgs, v_CmndExec, argsCmndRenn
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescUtil.RennDbin import RennDbin, RennFabric, RennFbrc2Ar
from AdminPy.FocSel import RennFocHst1, RennFocDsc1

from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Texture.FabricIO import *

from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.DescExtr.Hist.DescBinAnf import *
from AdminPy.Util.UtilImg import *


# ------------------------------   Paths   ------------------------------
crrDir      = os.getcwd()
strImg      = 'room.png'
fipaImg     = crrDir / Path( 'Imgs/' + strImg )          # image path
fstmOut     = crrDir / Path( 'Desc/' + strImg[:-4] )     # output file path
Fixt        = o_FileExtensions()
fpDSC       = o_FinaApndExtDscx( fstmOut, Fixt )

# ------------------------------   Dscx (Step 1)   ------------------------------
ArgsDscx        = o_CmndArgs('dscx')
ArgsDscx.opt    = ' --saveRRE --saveCVP';

StdOut          = RennDscx( fipaImg, fstmOut, ArgsDscx, sb.PthProg['descExtr'] )

# ------------------------------   Dbin (Step 2)   ------------------------------
fpPrm           = 'Params/PrmDbin_Cabinet.txt'; 
Fixt            = o_FileExtensions()
ArgsDbin        = o_CmndArgs( 'dbin' )
ArgsDbin.fpPrm  = fpPrm
ArgsDbin.opt    = '--all'

os.chdir( sb.PthProg['descUtil'] )
OutDbin         = RennDbin( fpDSC.dsc, fstmOut, ArgsDbin )

# ------------------------------   Fabric & fbrc2arr   ------------------------------
fpDSC           = o_FinaApndExtDscx( fstmOut, Fixt )
fipaCbnt        = fpDSC.hsspa # [fstmOut Fixt.hsspa];
ArgsFbrc        = o_CmndArgs( 'fabric' );

pthFbrc         = sb.PthProg['descUtil']

# we run both, 'fabric' and 'fbrc2arr'
OutFbrc         = RennFabric( fipaCbnt, fstmOut, ArgsFbrc, pthFbrc )
OutFbAr         = RennFbrc2Ar( fpDSC.fbrc, fstmOut, pthFbrc )

# ------------------------------   Load Output   ------------------------------
dmy, HedFbc     = LoadFabric( fpDSC.fbrc )  # we need the image size for scaling factors
FFLL            = LoadFbrcArrays( fpDSC )   # FabricIO.py
szImg           = [HedFbc.Hed.szV, HedFbc.Hed.szH]

BinEdg          = i_BinEdgFromLoad( HedFbc.NbinAtt, HedFbc.NbinDty )


# --------------------------------------------------------------------------------
#                     F K E R N E L    E X T R A C T I O N 
# --------------------------------------------------------------------------------
BOXrep    = np.zeros( (5,4), dtype=np.int32 )
BOXrep[0] = [160, 245, 450, 540] # black microwave/cabinet
BOXrep[1] = [240, 320,  50,  95] # fire exstinguisher
BOXrep[2] = [280, 315, 480, 520] # stove
BOXrep[3] = [280, 320, 520, 580] # faucet
BOXrep[4] = [180, 260, 330, 390] # ventilator/towel dispenser

for b in range(5):
    BOXrep[b,:] = f_BboxEnlarge1( BOXrep[b,:], szImg, (0.15, 0.15) )
    #BOXrep[b,:] = f_BboxShrink1( BOXrep[b,:], szImg, (0.15, 0.15) )
    #BOXrep[b,:] = f_BboxShrink1( BOXrep[b,:], szImg, (0.35, 0.35) )

# ------------------------------   kernel   ------------------------------
# wrapper in Fabric.py
bDisp     = 1
AFFOC     = f_FbrcFocLst(     FFLL, BOXrep, szImg, bDisp )
AFKrnl    = f_FbrcFocKrnlLst( FFLL, BOXrep, szImg, bDisp )

# ------------------------------   descriptors   ------------------------------
if 0:
    # to be implemented
    fpFocRep     = str(fstmOut) + '_Foc1' 
    ArgsRenn     = sb.Util.argsCmndRenn
    pthFocSel    = sb.PthProg['focSel']
    
    SzFocRep, OutFocRep  = RennFocDsc1( fpDSC.dsc, BoxRep, fpFocRep, ArgsRenn, pthFocSel )


# --------------------------------------------------------------------------------
#                        I D E N T F I C A T I O N
# --------------------------------------------------------------------------------

# ------------------------------   Scores TopDown Kernel   ------------------------------
import AdminPy.Mtch.MtchFbrcKrnl as mfbk
import AdminPy.Mtch.MtchFbrcFlsh as mfbf

PrmIdf    = mfbk.i_FbrcIdfPrm()

bDisp     = 1

ALOCTkrnl = mfbk.KrnlLstAccel( FFLL, AFKrnl, PrmIdf, BinEdg, bDisp )
ALOCTflsh = mfbf.FlshLstExhst( FFLL, AFFOC,  PrmIdf, BinEdg, bDisp )

# ------------------------------   'Predicted' Bboxes   ------------------------------
from PIL import Image
import AdminPy.Recognize.RecUtil as rcut

Irgb      = np.array(Image.open(fipaImg))

nKrnl     = len(AFKrnl)

AIPtch    = [None]*nKrnl
for k in range(nKrnl):

    BoxRep    = BOXrep[k,:] # the selection
    BoxUrg    = u_BboxUnitRg( BoxRep, szImg )

    BBox      = rcut.u_OutlFromLoctFbrc( ALOCTkrnl[k], BoxUrg, szImg )
    AIPtch[k] = u_IptchFromBboxLst( Irgb, BBox )
    

    
# ------------------------------   PLOT   ------------------------------
AIptcRep  = u_IptchFromBboxLst( Irgb, BOXrep )

import AdminPy.Recognize.RecUtil as rcut

figNo = 1

rcut.g_PtchPredPerLay( figNo, Irgb, AIptcRep, AIPtch )
