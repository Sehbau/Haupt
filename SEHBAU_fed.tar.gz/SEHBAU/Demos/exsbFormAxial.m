%
% Plots axial forms. af exsbShape.m
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'Demos'
    
typ         = 'Axial';  figForm = 3;

strImg      = 'aachen.png';
%strImg      = 'highway.jpg';

fipaImg     = [ 'Imgs/' strImg];         % image path
fipsOut     = [ 'Desc/' strImg(1:end-4)]; % output filestem

% change to window backslash (in case we are on windows)
if ispc
    fipaImg  = u_PathToBackSlash( fipaImg ); 
    fipsOut  = u_PathToBackSlash( fipsOut ); 
end

%% --------   Options   --------
OptK            = o_DscxArgs();
OptK.nLev       = 3 ;
OptK.depth      = 3 ;
OptK.saveRegUnv = 1 ;    
OptK.saveBonSpc = 1 ;
optS            = i_DscxArgs(OptK);

%% =========   Command   ========
cmnd        = [ FipaExe.dscx ' ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    cmnd    = u_PathToBackSlash( cmnd );
end

[Sts, Out]  = system(cmnd);      

v_CmndExec( Sts, Out, cmnd, 1 );

%% -------   Load Region Pixels   -------
Fixt                = o_FileExtensions();
fpDSC               = o_FinaApndExtDscx( fipsOut, Fixt ); 

[AREG KtReg]        = LoadRegUnv(   fpDSC.ruv );
[DSC Kt Hed]        = LoadDescImag( fpDSC.dsc );    
[ABON Nbon SzM AOrg] = LoadBonPixSpc( fpDSC.bspx );    
SLC                 = LoadDescSalc( fpDSC.slc );

[LbAtts, LbAttSG]   = o_AttsLabels();
DSC                 = u_DescMxToStcOfArr( DSC, LbAttSG );

%% -----------------   Plot Forms   ------------------------
hf = figure(figForm); clf; set(hf, 'name', 'form'); 
for lev = 1:Kt.nLev

    % --- retrieve:
    FRM         = DSC.ARSG{lev};         % extracting one level

    ABonPix     = ABON{lev};
    ARegPix     = AREG(lev,:);
    Org         = AOrg{lev};

    szM         = SzM(lev,:);

    % ----------   Plot boundaries on LEFT   ----------
    subplot(3, 2, lev*2-1); hold on;
    set(gca,'fontsize',8);
    
    Sel         = p_FormAxial( FRM, ABonPix );   % *** plot ***
    
    axis ij;
    set(gca,'xlim',[1 szM(2)]);
    set(gca,'ylim',[1 szM(1)]);
    ylabel(['Lev ' num2str(lev)] );
    
    % ----------   Plot map on RITE   ---------
    % create map
    MpTot = zeros( szM([2 1]), 'single');   
    for t = 1:6
        IxSel   = Sel.IxAxi( Sel.Typ==t );
        % length(IxSel)
        Mp      = u_RegPixToMapSel( ARegPix, Org, IxSel, szM, 20+t*30 );
        MpTot   = MpTot + Mp;
    end
    
    subplot(3, 2, lev*2);
    imagesc(  MpTot' ); 
    set(gca,'fontsize',8);
    
end
set(gcf, 'paperposition', [0.5 0.25 7 10.75]);

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2File( [dirFigs 'RoadSceneForm' typ], 1, 1, figForm );
end

