% 
% Runs program cntpat
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'Demos'

%% --------------------------------------------------------------
%                          DESC EXTR
%  --------------------------------------------------------------
fprintf('Descriptor extraction...');

fipaImg 	= 'Imgs/highway.jpg';
%fipaImg 	= 'Imgs/room.png';
%fipaImg 	= 'Imgs/aachen.png';
%fipaImg 	= 'Imgs/birds.jpg';

[pth nast ext] = fileparts( fipaImg );

fipsOut 	= [ 'Desc/' nast ];

if ispc
    fipsOut    = u_PathToBackSlash( fipsOut );
end

ArgsDscx        = o_CmndArgs( 'dscx' );
ArgsDscx.opt    = '--saveRRE';
v_CmndArgs( ArgsDscx );

OutDscx         = RennDscx( fipaImg, fipsOut, ArgsDscx, PthProg.descExtr );

fprintf('Dscx fertig\n');

%% --------------------------------------------------------------
%                          CNTPAT
%  --------------------------------------------------------------
fprintf('CntPat...');
Fixt        = o_FileExtensions();
fpDSC       = o_FinaApndExtDscx( fipsOut, Fixt );

cmnd        = [ '../DescUtil/cntpat ' fpDSC.rre ' ' fipsOut ];

if ispc
    cmnd    = u_PathToBackSlash( cmnd );
end

[StO Out] 	= system( cmnd );         

bVerifyEOP	= 1;
v_CmndExec( StO, Out, cmnd, bVerifyEOP );
pso_ErrPresent( Out );

%% -------------   Load Output   -------------
[DUV Kt Hed]  	= LoadDescUniv( fpDSC.dsc ); DispLoad( fpDSC.dsc );
Pat            	= LoadCntPat( fpDSC.cntpat );
RRE             = LoadCntRRE( fpDSC.rre );

Irgb            = imread( fipaImg );

%% -------------   Plot Pattern   -------------
figPat = 2;
figure(figPat); clf;
subplot(2,1,1); imagesc(Irgb);
subplot(2,1,2);
hold on;
p_PatLin( Pat.Vrt, Pat.Vrt.RGB );
p_PatLin( Pat.Hor, Pat.Hor.RGB );
axis ij;
ts  = sprintf('nVrt/Hor %d %d', Pat.Vrt.nLin, Pat.Hor.nLin );
title( ts );

%% -------------   Plot RRE   -------------
% we plot ALL rre contours for comparison
figNo = 5;
PlotCntUnvKpt( RRE, Irgb, Hed.space, figNo );

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2Jpeg( [dirFigs 'CntPat'], figPat );
    
end




