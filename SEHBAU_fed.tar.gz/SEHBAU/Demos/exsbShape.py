"""

Plots specific shapes. Not finished yet.

The script is a continuation of example script exsbRegBon.py

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescExtr.DescFile import LoadDescUniv, LoadDbinUniv
from AdminPy.DescExtr.Saliency import LoadDescSalc

Fixt      = o_FileExtensions()

# ------------------------------   DesxExtr   ------------------------------
imgNa     = 'aachen.png'
#imgNa     = 'highway.jpg'

imgNa     = Path( imgNa )
pthImg    = Path( 'Imgs/' ) / imgNa
pthDesc   = Path( 'Desc/' ) / imgNa.stem

# ------------------------------   Options   ------------------------------
OptK            = argsDscx()
OptK.nLev       = 3 
OptK.depth      = 3 
OptK.saveRegUnv = 1     
OptK.saveBonSpc = 1 
optS            = i_DscxArgs(OptK)

cmnd      = str(Path('../DescExtr/dscx ')) + str(pthImg) + ' ' + str(pthDesc) + ' ' + optS

# Run descriptor extractor
Res       = subprocess.run(cmnd, shell=True, capture_output=True, text=True)

Sts       = Res.returncode
Out       = Res.stdout + Res.stderr

fpDSC     = o_FinaApndExtDscx( str(pthDesc), Fixt )


# ------------------------------   Load & Retrieve   ------------------------------
import AdminPy.DescExtr.DescFile.LoadFeatures as lodf

AREG, KtReg   = lodf.LoadRegUnv(   fpDSC.ruv ) # not tested yet
ABON, Jbsp    = lodf.LoadBonPixSpc( fpDSC.bspx );    

DUV, Hed      = LoadDescUniv( fpDSC.dsc )
#SLC, Hed      = LoadDescSalc( fpDSC.salc )

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
import numpy as np

from AdminPy.DescExtr.DescFile.Features.RegUtil import *

import imageio.v3 as iio

if 0:
    Irgb   = iio.imread( pthImg )

    fig1, axes = plt.subplots(4, 2, num=2, figsize=(10, 8))
    axes   = axes.ravel()
    
    ax1    = axes[0]
    ax1.imshow(Irgb)
    ax1.axis('off')

# ------- boundaries & regions:     
fig, axes = plt.subplots(3, 2, figsize=(7, 10.75))
fig.suptitle("shape", fontsize=10)

for lv in range(KtReg.nLev):

    lvx1 = lv + 1 # 1-based index used for titles/labels
    
    # --- retrieve:
    SHP          = DUV.ASHP[lv]
    ABonPix      = ABON[lv]
    ARegPix      = AREG[lv,:]
    Org          = Jbsp.AOrg[lv]
    szM          = Jbsp.SzM[lv,:] # map size
    
    # ------   LEFT COLUMN: boundaries
    AxLef = axes[lv,0]
    
    IxSel, Typ = p_ShpAxial( SHP, ABonPix, AxLef )
    
    AxLef.tick_params(labelsize=8)
    AxLef.invert_yaxis()                # equivalent to 'axis ij'
    AxLef.set_xlim([1, szM[1]])
    AxLef.set_ylim([szM[0],1])          # inverted coordinates check boundary constraints
    AxLef.set_ylabel(f"Lev {lvx1}")
    
    # ------  RITE COLUMN: regions
    MpTot = np.zeros( szM, dtype=np.float32)
    
    for t in range(1, 7): # Loops 1 through 6

        Btyp   = Typ==t
        IxTyp  = IxSel[Btyp]
        
        Mp     = u_RegPixToMapSel( ARegPix, Org, IxTyp, szM, 20 + t * 30 )
        MpTot += Mp
        
    AxRit = axes[lv, 1]
    
    im    = AxRit.imshow( MpTot, cmap='gray', aspect='auto', origin='upper')
    AxRit.tick_params(labelsize=8)

# Adjust spacing so labels don't clip over neighboring axes
plt.tight_layout()
plt.show(block=False)
