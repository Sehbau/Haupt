% 
% Compares the two image spaces (save with --saveIsp).
%
% It also plots the contour skeleton.
%
% Uses long options:
%   --is      to set the type of space (pyramid or scale space).
%   --saveIsp to save the space to file with extension .isp
%
% Assumes script is run from directory 'Demos'
%
clear;
run('../AdminMb/globalsSB');        

%% ---------    Run the 2 Spaces    ----------
cmndPyr = '../DescExtr/dscx Imgs/room.png Desc/roompyr --saveIsp'; 
cmndScs = '../DescExtr/dscx Imgs/room.png Desc/roomscs --is 2 --saveIsp';
%cmndScs = [cmndScs ' --cntMinCtr 0.05']; 

if ispc
    cmndPyr = u_PathToBackSlash( cmndPyr ); 
    cmndScs = u_PathToBackSlash( cmndScs ); 
end

[OutPyr]    = system( cmndPyr );
[OutScs]    = system( cmndScs );

[GryPyr RGBpyr DimPyr] = LoadImgSpace( 'Desc/roompyr.isp' );
[GryScs RGBscs DimScs] = LoadImgSpace( 'Desc/roomscs.isp' );

[DUVpyr HedP]   = LoadDescUniv( 'Desc/roompyr.dsc' );
[DUVscs HedS]   = LoadDescUniv( 'Desc/roomscs.dsc' );

SLCPyr          = LoadDescSalc( 'Desc/roompyr.slc' );
SLCSsp          = LoadDescSalc( 'Desc/roomscs.slc' );

%% ---------    Plot Skeleton Contours  ----------
% This is reduced set (not full set)
Irgb = imread('Imgs/room.png');

figure(3); clf;
nLev    = HedP.nLev;
[nr nc] = deal( nLev, 2 );
szI     = size(Irgb);

for l = 1:nLev
    
    % --------   Pyramid   ---------
    subplot(nr, nc, l*2-1);
    imagesc( GryPyr{l} ); colormap(gray);
    %imagesc( RGBpyr{l} );
    %imagesc( imresize( Irgb, 1 / 2^(l-1)) ); 
    
    szM = round( szI / 2^(l-1) );
    p_CntFromAtts( DUVpyr.ACNT{l}, szM );     

    set(gca,'fontsize',5);
    if l==1, title('Pyramid'); end

    % --------   Scale Space   ---------
    subplot(nr, nc, l*2);
    imagesc( GryScs{l} ); colorbar();
    %range(GryScs{l}(:))
    %imagesc( RGBscs{l} );

    p_CntFromAtts( DUVscs.ACNT{l}, szI );     

    set(gca,'fontsize',5);
    if l==1, title('Scale Space'); end
    
end


%% ---------   Some Stats   ----------
DscPyr  = SLCPyr.Dsc;
DscSsp  = SLCSsp.Dsc;

figure(4); clf; 

xax = 1:nLev;

subplot(2,2,1); hold on;

plot( xax, DscPyr.MxRngRR, 'b-');
plot( xax, DscPyr.MxRngEg, 'b:');

plot( xax, DscSsp.MxRngRR, 'r-' );
plot( xax, DscSsp.MxRngEg, 'r:' );

set( gca, 'xtick', 1:nLev );
ylabel('Max Contrast');
xlabel('Level');
legend({'Pyr RR' 'PyrEdg' 'Ssp RR' 'Ssp Edg'}, 'location', 'southwest');

subplot(2,2,2); hold on;

plot( xax, DscPyr.Nrdg, 'b-');
plot( xax, DscPyr.Nriv, 'b--');
plot( xax, DscPyr.Nedg, 'b.-');
plot( xax, DscPyr.Ndsc.Skl, 'b:');

plot( xax, DscSsp.Nrdg, 'r-');
plot( xax, DscSsp.Nriv, 'r--');
plot( xax, DscSsp.Nedg, 'r.-');
plot( xax, DscSsp.Ndsc.Skl, 'r:');

set( gca, 'xtick', 1:nLev );
ylabel('N ridges/rivers');
xlabel('Level');
legend({'PyrRdg' 'PyrRiv' 'PyrEdg' 'PyrSkl'...
        'SspRdg' 'SspRiv' 'SspEdg' 'SspSkl'}, ...
    'location', 'northeast');
