#!/usr/bin/bash
#!/bin/bash
@echo off

# --- Conversion from windows to unix ---

# Saved under windows: need to eliminate the carriage return and change permission

# tr -d "\r" < runEss.sh > tmp.sh
# chmod u+x runEss.sh
# bash ./runEss.sh

# --------------------------------------------------------------------------------
# 
#                   Essential functionality
# 
# --------------------------------------------------------------------------------

echo ------------------------------------------------------------
echo		Descriptor Extraction fuer images 1 and 2 
echo ------------------------------------------------------------

cd DescExtr

./dscx Imgs/img1.jpg Desc/img1 || { echo "dscx failed"; exit 1; }
./dscx Imgs/img2.jpg Desc/img2


echo ------------------------------------------------------------
echo		Matching the two Images
echo ------------------------------------------------------------

# we change to matching directory, because we require directory 'Mes'
cd ../MtchVec || { echo "Failed to cd to ../MtchVec"; exit 1; }

./mvec1 ../DescExtr/Desc/img1.dsc ../DescExtr/Desc/img2.dsc

cd ../DescExtr || { echo "Failed to cd back to ../DescExtr"; exit 1; }


echo ------------------------------------------------------------
echo		Converting Output
echo ------------------------------------------------------------

echo ---	Histogram to Array
# we turn the histogram file into a single array 
./h2arr Desc/img1.hst Desc/img1

echo ---	Attributes to Vector-Matrix
# we generate vector matrices
./d2vmx Desc/img1.dsc Desc/img1

echo --- 	Binned attributes to Bin-Vectors
# we generate bin-vector matrices from dsb file
./dbn2vmx Desc/img1.dsb Desc/img1

cd ..

echo ------------------------------------------------------------
echo		Matching Texture of two Images
echo ------------------------------------------------------------
cd MtchTxt

./mtxt1 ../DescExtr/Desc/img1.slc ../DescExtr/Desc/img2.slc || { echo "mtxt1 failed"; exit 1; }

cd ..

echo ------------------------------------------------------------
echo		DescUtil:  cntpat, topx
echo ------------------------------------------------------------

echo we first run with saving option 'saveRRE'
cd DescExtr

./dscx Imgs/img1.jpg Desc/img1 --saveRRE || { echo "dscx failed!"; exit 1; }

cd ..

cd DescUtil

echo now we apply the utilities:

echo ---	cntpat
./cntpat ../DescExtr/Desc/img1.rre Desc/img1 || { echo "cntpat failed!"; exit 1; }

echo ---	topx
./topx ../DescExtr/Desc/img1.dsc Desc/img1 || { echo "topx failed!"; exit 1; }

cd ..

echo Soweit so gut.


