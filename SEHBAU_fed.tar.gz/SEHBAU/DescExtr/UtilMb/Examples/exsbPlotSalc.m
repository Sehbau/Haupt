%
% Example for loading and plotting the saliency info. 
%
% Run from WITHIN directory DescExtr/UtilMb/Examples
%
% Function scripts in directory 'Vect/'
%
% af cc_Dbas.m
%
clear;
run('../../../globalsSB.m');

pthSalc     = '../../Desc/img1.slc';       % saliency file
%pthSalc     = '../../Desc/img2.slc';       
%pthSalc     = '../../Desc/aachen.slc';     

Irgb        = imread('../../Imgs/img1.jpg');

[YZ Shp Ens Dsc]  = LoadDescSalc(pthSalc, aBlobTypS);  

% identify bounding boxes of some blobs
Bnum    = YZ.Blb.Typ==1;        % numerous
Bbln    = YZ.Blb.Typ==2;        % blank
Benk    = YZ.Blb.Typ==8;        % high-contrast

%% ---------------   Salient Regions   ------------------
% taken from cc_Dbas.m
figi(20); [nr nc]=deal(2,3);

% ------   Contours   ------
p_SUBtig(nr,nc,1); imagesc( Irgb ); hold on; p_Cross(128);
axgray;

p_BboxL( YZ.Blb.Box( Bnum, :) );
p_BboxL( YZ.Blb.Box( Benk, :), [1 0.5 0] ); % orange
%p_BboxL( Blb.Box( Bktc, :), [.2 .2 .2] );
imglabN( 'Cnt Num/Ken ', [nnz(Bnum) nnz(Benk)] );

% ------   Shapes ALL  ------
p_SUBtig(nr,nc,2); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
p_BboxL( Shp.Box );
imglabN( 'ShpAll ', Shp.nBox );

% ------   Shapes HighContrast  ------
BhihCtr  = Shp.Ctr > mean(Shp.Ctr) * 0.66;
BoxHiCtr = Shp.Box( BhihCtr, : );

p_SUBtig(nr,nc,4); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
p_BboxL( BoxHiCtr );
imglabN( 'ShpHiCtr ', size(BoxHiCtr,1));

% ------   Shapes HighCrowdedness  ------
BhihCwd  = Shp.Cwd > 8; % mean(Shp.Cwd) * 0.66;
BoxHiCwd = Shp.Box( BhihCwd, : );

p_SUBtig(nr,nc,3); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
p_BboxL( BoxHiCwd );
imglabN( 'ShpCwd ', size(BoxHiCwd,1));

% ------   Shapes Large  ------
[V Ord] = sort( Shp.Cvg, 'descend');
%Blrg    = Shp.Cvg > mean(Shp.Cvg) * 1.2;
nSel    = min( length(Ord), 35 );
BoxLrg  = Shp.Box( Ord(1:nSel), : );

p_SUBtig(nr,nc,5); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
p_BboxL( BoxLrg );
imglabN( 'ShpLrg ', size(BoxLrg,1));

% ------   Spots   -------
p_SUBtig(nr,nc,6); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
nSel    = min( 5, YZ.Spt.Px.nCo );
p_VisSearch( YZ.Spt.Px.Pt(1:nSel,:) );
imglabN( 'Spots ', nSel);

%% ------------------    Ensemble   --------------------
% 
figi(21); [nr nc]=deal(1,2);

% ------   All   ------
p_SUBtig(nr,nc,1); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
p_BboxL( Ens.Box );
imglabN( 'EnsAll', Ens.nBox );

% ------   G to L   -------
p_SUBtig(nr,nc,2); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
Ix      = Ens.OrdGtoL.Ix;
BoxGtoL = Ens.Box( Ix, :);
p_BboxL( BoxGtoL, 'var' );
imglabN( 'GtoL ', size(BoxGtoL,1));
