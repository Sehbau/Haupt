%
% Reads descriptor file header, namely struct fhedDesc in
% E_DESC/UtilIO/DescFileAnf.h.
%
% cf LoadDescImag.m, LoadFocDesc.m 
%
function [H] = ReadDescFileHead( fileID, typExp )

versExp     = 1.03;

nLev   = fread(fileID, 1,  'int=>int');      % # of pyramid levels
szV    = fread(fileID, 1,  'int=>int');      % vertical image size
szH    = fread(fileID, 1,  'int=>int');      % horizontal image size
ntDsc  = fread(fileID, 1,  'int=>int');      % # of total desc
typ    = fread(fileID, 1,  'uint8=>uint8');  % file typ (imag|focus)

% flags (unsigned char)
H.depth  = fread(fileID, 1,  'uint8=>uint8');  % depth of segmentation
H.space  = fread(fileID, 1,  'uint8=>uint8');  % image space (pyr | ss)
bFlg3  = fread(fileID, 1,  'uint8=>uint8');  % not used at the moment
bFlg4  = fread(fileID, 1,  'uint8=>uint8');  % not used at the moment
bFlg5  = fread(fileID, 1,  'uint8=>uint8');  % not used at the moment

versLod = fread(fileID, 1,  'float=>single');  % version loaded

assert(typ==typExp,'file idf not correct: %d, expected %d', typ, typExp);
assert(nLev>0 && nLev<12,'nLev not correct: %d', nLev);
assert(szV>0 && szV<5000, 'szV unreasonable: %d', szV);
assert(szH>0 && szH<5000, 'szH unreasnoable: %d', szH);
assert( abs(versLod-versExp)<0.001, ...
        'Version depreciated: is %1.3f. new %1.3f', versLod, versExp);

H.nLev  = nLev;
H.szV   = szV;
H.szH   = szH;
H.ntDsc = ntDsc;


end

