%
% Plots position (vertical, horizontal) as dots. Default color is black.
% Assumes no manipulation (ie. scaling). 
%
% Use u_PosXXX for manipulations such as scaling and introducing offsets.
%
%
function [P] = p_PosVH( P, col )

%nPos    = P.nPos;

if nargin==2
    col = 'k';
end

plot( P.Hor, P.Vrt, '.', 'color', col );

end

