%
% Reads blobs as saved under wb_ShpOut in ShpIOutsz.h (filled in
% SHPOutOrd() of SHPPYR.h).
%
% cf LoadDescSalc.m
%
% IN    bIxOne   zero- or one-indexing (C/python, Matlab)
%
function [B] = ReadShpOut( fileID, bIxOne )

[B.Box nBx] = ReadBboxLbin( fileID );

B.Typ     = fread( fileID, nBx, 'float=>single' ); % N/A (irrelevant)
B.Are     = fread( fileID, nBx, 'float=>single' ); % area of CC
B.Cvg     = fread( fileID, nBx, 'float=>single' ); % coverage
B.Ctr     = fread( fileID, nBx, 'float=>single' ); % contrast
B.Cwd     = fread( fileID, nBx, 'float=>single' ); % crowdedness (contours)

B.Lev     = fread( fileID, nBx, 'uint8=>uint8' ) + bIxOne; % level
B.IxShp   = fread( fileID, nBx, 'int32=>int32' ) + bIxOne; % shape index
B.IxBon   = fread( fileID, nBx, 'int32=>int32' ) + bIxOne; % boundary index

%B.OrdGtoL    = ReadIxArr( fileID ) ;            % order global-to-local
%B.OrdGtoL.Ix = B.OrdGtoL.Ix + bIxOne;           % make one-indexing

B.nBox    = nBx;

end

