%
% Descriptor type as short strings.
% 
% sa u_LabDscTyp.m
%
function [aDty nDty] = o_DescTypes( typ )

if strcmp( typ, 'crasshp' )

    aDty    = {'Cnt' 'Rsg' 'Arc' 'Str' 'Shp'};

elseif strcmp( typ, 'crasst' )

    aDty    = {'Skl' 'Rsg' 'Arc' 'Str' 'Shp' 'Ttg'};

%elseif strcmp( typ, 'crassb' )

%    aDty    = {'Skl' 'Rsg' 'Arc' 'Str' 'Shp' 'Bnd'};

elseif strcmp( typ, 'crasstb' )

    aDty    = {'Skl' 'Rsg' 'Arc' 'Str' 'Shp' 'Ttrg' 'Bndg'};

elseif strcmp( typ, 'Crasstb' )

    aDty    = {'Cnt' 'Rsg' 'Arc' 'Str' 'Shp' 'Ttrg' 'Bndg'};

elseif strcmp( typ, 'sklrasshp' )

    aDty    = {'Skl' 'Rsg' 'Arc' 'Str' 'Shp'};

elseif strcmp( typ, 'cras' )

    aDty    = {'Skl' 'Rsg' 'Arc' 'Str'};

elseif strcmp( typ, 'fixt' ) % vector file extensions

    aDty    = {'vecCnt' 'vecRsg' 'vecArc' 'vecStr' 'vecShp'...
               'vecTtg' 'vecBnd'};

elseif strcmp( typ, 'fixtLev' ) % vector level file extension

    aDty    = {'levCnt' 'levRsg' 'levArc' 'levStr' 'levShp'...
               'levTtg' 'levBnd'};
else
    
    fprintf('typ %s not implemented', typ);
end
    

nDty    = length(aDty);


end

