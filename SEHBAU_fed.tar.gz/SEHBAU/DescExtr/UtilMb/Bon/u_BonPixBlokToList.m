%
% Rearrange from struct-of-array to list.
%
function [aBon] = u_BonPixBlokToList( BON ) 

nBon    = BON.nBon;
    
aBon = cell(nBon,1);
for b = 1:nBon
    
    anf  = BON.Anf(b);
    nPx  = BON.Npx(b);
    
    assert( nPx < 30000, 'nPx very large %d', nPx );
    
    Rng  = anf : anf+nPx-1;       % index range

    %Rng
    
    Pix.Rw = BON.Pix.Rw( Rng );
    Pix.Cl = BON.Pix.Cl( Rng );
    
    aBon{b} = Pix;
    
end



