%
% Attribute names (labels) for a descriptor.
%
% An attribute label has at most 6 characters. 
%
% cf exampleShapeChar.m, cc_ovoT.m, f_ShpAlySpc.m
%
function [LS] = o_AttsLabels()


%% ----------   contour   ---------  9
LS.Cnt = {'len' 'str' 'ori' 'xco' 'yco'   'red' 'grn' 'blu' 'tif'};
LS.Skl = LS.Cnt;

%% ----------   radial signature   ----------  10 + 5
LS.Rsg = {'rad' 'cir' 'eloR' 'eloF' 'cncv'   'bs1' 'bs2' 'bs3' 'bs4' 'bs5'...
          'star' 'dent' 'red' 'grn' 'blu'};

%% ----------   arc   ---------  9 + 8
LS.Arc = {'len' 'krv' 'dir' 'am1' 'am2'   'smo' 'spz' 'run' 'eck' ...
          'xco' 'yco' 'red' 'grn' 'blu'   'tifE1' 'tifE2' 'tifPk'};
      
%% ----------   str   ---------  10 + 3
LS.Str = {'les' 'str' 'ifx' 'wig' 'bog'   'amp' 'smo' 'red' 'grn' 'blu' ...
          'tifE1' 'tifE2' 'tifPk'};
        
%%  ---------    bndg   ---------  10      
LS.Bndg = {'len' 'agx' 'tig' 'dns' 'ori'   'xco' 'yco' 'red' 'grn' 'blu'};
      
%% ----------   shape   ---------   ShpAbstAtts.h

% ------ attsShpStrOri, ia Scors
%Lbs = 'Vrt   Hor   Dg1   Dg2   Axi   Adg   Vab   Hab   Dab   Tri   Nil   ';
%Lshp.Scors = u_AttLabArrToList( Lbs );

% ------ attsShpStrFin, ia Sfine
%Lbs = 'Vrt   Hor   Vti   Hti   Vob   Hob   Dg2   Dg1   Axi   Uni   Dul   Cvg   Agx   Ori   Nil   Dre   Vir   Fnf   ';
%Lshp.Sfine = u_AttLabArrToList( Lbs );

% ------ attsShpRadSeg, ia Ras
%Lbs = 'Rad   Elo   Ron   Riss  SteUgfSteEngSteDowSteUppOpnDowOpnUpwLigUgfLigEngLigDowLigUppOpnRitOpnLef';
%Lshp.ShpV.Ras = u_AttLabArrToList( Lbs );
  
%LS.Shp = [ Lshp.Scors(:); Lshp.Sfine(:); Lshp.Ras(:) ];
LS.Shp = {'vrt' '' '' '' '' 'xco' 'yco' 'red' 'grn' 'blu'};


%% ----------   tetragon   ---------   
aLbGeom = { 'Les'   'Elo'    'Wide'   'High'    'Rhom'  ...
            'Pllo'  'Tria'   'Irrg'   'PlHor'   'PlVrt' ...
            'Ger'   'Wth'
            };
aLbLage = { 'AxVrt'  'AxHor'   'Axial'   'Lean1'  'Lean2'   ...
            'Neig1'  'Neig2'
            };
        
aLbUtil = { 'ori' 'xco' 'yco' 'tifE1' 'tifE2' 'tifPk' };

LS.Ttrg = [ aLbGeom(:); aLbLage(:); aLbUtil(:) ];

%% ------------------------   Num of Labels   ----------------------
if 0
    aFldNas     =  fieldnames(LS);
    for f = 1:length(aFldNas)
        
        fl       = aFldNas{f};
        fln      = ['n' fl];
        aLabs    = LS.(fl);
        nAtt     = length( aLabs );
        
        LS.(fln) = nAtt;
    end
end



end % MAIN

