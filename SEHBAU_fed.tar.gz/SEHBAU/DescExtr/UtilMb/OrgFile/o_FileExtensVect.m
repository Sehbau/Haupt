%
% File extensions for vector types.
%
function [E] = o_FileExtensVect()

E.cnt  = '.vecCnt';
E.rsg  = '.vecRsg';
E.arc  = '.vecArc';
E.str  = '.vecStr';
E.shp  = '.vecShp';

E.bnd  = '.vecBnd';
E.ttg  = '.vecTtg';

E.aFna = fieldnames( E );
E.n    = length( E.aFna );



