%
% Simple demo. To be run from directory '/DescExtr/'.
%
% Runs program dscx and loads essential files. Assumes the organization as
% given in the repository.
%
% In case windows does not run the executable:
% 1) https://de.mathworks.com/matlabcentral/answers/316233-can-t-run-external-program
% 2) or execute in shell, and then proceed with 'Load Output'.
% 
clear;

if ispc
    % excecute program for windows
    [sts Out] = dos('dscx Imgs/img2.jpg Desc\img2'); % backslash
elseif isunix
    [sts Out] = unix('./dscx Imgs/img2.jpg Desc/img2');  
end

if sts~=0, 
    Out
    fprintf('Program did not execute at all: sts=%d', sts);
    pause();
end

%% -------   Load Output (Selected)   -------
% from here on we require paths, therefore set global variable in
% globalsSB.m
globalsSB;

% description (attributes)
[DSC Kt Hed]    = LoadDescImag( 'Desc/img2.dsc' );    

% saliency 
[SLC HedSlc]    = LoadDescSalc(  'Desc/img2.slc' );

% histogram
[HST HedHst]    = LoadDescHist( 'Desc/img2.hst' );


%% ---------   h2arr  ---------
% We apply binary h2arr, that turns a hist file into a single array
if ispc
    [sts Out] = dos('h2arr Desc/img2.hst Vect\img2'); % backslash
elseif isunix
    [sts Out] = unix('h2arr Desc/img2.hst Vect/img2');  
end

assert( sts==0, 'status not 0, but %d. h2arr did not execute properly', sts);

Hari        = LoadHistImgArr( 'Vect/img2.hari' );



%% -----------------   PLOT    --------------------
% We plot from description file, that contains the keypoints.
fprintf('Plotting...');

Irgb    = imread( 'Imgs/img2.jpg');

% -----   Plot Contours  -----
hf = figure(1); clf; set(hf, 'name', 'Contours');

imagesc( Irgb);  hold on;
    
CNTlv = DSC.ACNT{1};         % extracting one level
    
p_CntFromAtts(CNTlv, [Hed.szV Hed.szH]);     

title('Contours (Abstracted) 1st Level');

% -----   Plot Tetragons  -----
hf = figure(2); clf; set(hf, 'name', 'Tetragons');

imagesc( Irgb);  hold on;
    
TTGlv = DSC.ATTRG{1};         % extracting one level
    
p_TtrgLst( TTGlv );     

title('Tetragons (Abstracted) 1st Level');

% ------   Histogram    ---------
figure(3); clf;
bar( Hari );
title('Histogram-of-Attributes');

fprintf('simple demo completed\n');


