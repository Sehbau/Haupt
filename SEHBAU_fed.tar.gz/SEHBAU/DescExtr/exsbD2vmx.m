%
% Example for generating the vector file (from the description file).
%
% Assumes that description file has already been generated.
%
% To be run from directory 'DescExtr'.
%
clear; 
run('../AdminMb/globalsSB');

imgNa   = 'img1';
vecOut  = ['Vect/' imgNa];

%% ----------------------   Execute   -----------------------------
cmnd    = ['d2vmx Desc/' imgNa '.dsc ' vecOut ];

if ispc
    [Sts Out] = dos(cmnd);          % excecute program for windows
elseif isunix
    [Sts Out] = unix(['./' cmnd]);  % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 );

%% ----------------------   Load   -----------------------------
[FixtVec nDty] = o_FileExtensVect();

% We reorder for plotting:
%              cnt rsg arc str bnd ttg shp
OrdDty      = [ 1   2   3   4   7   6   5 ];  

cTopRow     = 1;                % for plotting
figure(1); clf;
for d = 1:nDty
    
    ixDsc 	= OrdDty(d);
    fextVec = FixtVec.aVec{ixDsc};
    dty     = fextVec(4:end);
    
    %% ------   Load Vectors   -------
    lfnVec     = [vecOut '.' fextVec ];
    [VMX nDsc nAtt AttLbs] = LoadDescVect( lfnVec );

    % we might face NAN that cannot be read by sscanf:
    % we then try with num2str instead
    if nDsc<0, 
        [VMX nDsc] = f_SscanfVectMxWithNan( VMX, nAtt );
    end    
    
    %% ------   Load Levels   -------
    lfnLev      = [vecOut '.' FixtVec.aLev{ixDsc} ];
    [Lev nDsc2] = LoadDescVectLev( lfnLev );
    
    assert( nDsc==nDsc2, 'nDsc not same: %d <> %d', nDsc, nDsc2 );
    
    %% ------   Plot   ------
    if ismember( ixDsc, [1 3 4 7] );
        subplot(4,4,cTopRow);
        cTopRow = cTopRow + 1;
    elseif ixDsc==2  % form
        subplot(4,1,2);
    elseif ixDsc==5  % shape
        subplot(4,1,3);
    elseif ixDsc==6  % tetragon
        subplot(4,1,4);
    end
    imagesc(VMX); colorbar;
    
    set( gca, 'xtick', 1:nAtt, 'xticklabel', AttLbs );
    set( gca, 'xticklabelrotation', 45 );
    title( dty );
    
end






