%
% Example for generating the vector file (from the description file).
%
% Assumes that description file has already been generated.
%
% To be run from directory 'DescExtr'.
%
clear; 
run('../globalsSB');

imgNa   = 'img1';
vecOut  = ['Vect/' imgNa];

cmnd    = ['d2vmx Desc/' imgNa '.dsc ' vecOut ];

if ispc
    [Sts Out] = dos(cmnd);      % excecute program for windows
elseif isunix
    [Sts Out] = unix(cmnd);     % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 );

%% --------    Load   ---------
aFixtVec    = o_DescTypes('fixtVec');
aFixtLev    = o_DescTypes('fixtLev');
aDtyS       = o_DescTypes('Crasstb');
nDty        = length(aDtyS);

% Order:       cnt rsg arc str bnd ttg shp
OrdDty      = [ 1   2   3   4   7   6   5 ];  

figure(1); clf;
for d = 1:nDty
    
    ixDsc = OrdDty(d);

    %% ------   Load Vectors   -------
    [VMX nDsc nAtt AttLbs] = LoadDescVect( [vecOut '.' aFixtVec{ixDsc} ] );

    % we might face NAN that cannot be read by sscanf:
    % we then try with num2str instead
    if nDsc<0, 
        [VMX nDsc] = f_SscanfVectMxWithNan( VMX, nAtt );
    end    
    
    %% ------   Load Levels   -------
    [Lev nDsc2] = LoadDescVectLev( [vecOut '.' aFixtLev{ixDsc} ] );
    
    assert( nDsc==nDsc2, 'nDsc not same: %d <> %d', nDsc, nDsc2 );
    
    %% ------   Plot   ------
    if d<6,
        subplot(3,4,d);
    elseif d==6  % tetragon
        subplot(3,2,4);
    else         % shape
        subplot(3,1,3);
    end
    imagesc(VMX); colorbar;
    
    set( gca, 'xtick', 1:nAtt, 'xticklabel', AttLbs );
    set( gca, 'xticklabelrotation', 45 );
    title( aDtyS{ixDsc} );
    
end






