%
% Example for generating the bin-vector file (from the desc-bin file).
%
% af exsbD2vmx.m
%
% Assumes that description file has already been generated.
%
% To be run from directory 'DescExtr'.
%
clear; 
run('../AdminMb/globalsSB');

Fixt    = o_FileExtensions();

imgNa   = 'img1';
fpDsb   = ['Desc/' imgNa Fixt.dsbi];
vbnOut  = ['Vect/' imgNa];

%% ----------------------   Execute   -----------------------------
cmnd    = ['dbn2vmx ' fpDsb ' ' vbnOut ];

if ispc
    [Sts Out] = dos(cmnd);      % excecute program for windows
elseif isunix
    [Sts Out] = unix(['./' cmnd]); % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 );

%% ----------------------   Load   -----------------------------
FixtVec     = o_FileExtensVect();

% Order:       cnt rsg arc str bnd ttg shp
OrdDty      = [ 1   2   3   4   5];  
%OrdDty      = [ 1   3   4   5];  
%OrdDty      = [ 1   2   3   4   7   6   5 ];  
nDty        = length(OrdDty);
cTopRow     = 1;                % for plotting
figure(1); clf;
for d = 1:nDty
    
    ixDsc   = OrdDty(d);
    fextVec = FixtVec.aVbn{ixDsc};  % .aVbn   (NOT .aVec)
    dty     = fextVec(4:end);

    %% ------   Load Vectors   -------
    [VMX Dim AttLbs] = LoadDescVebn( [vbnOut '.' fextVec ] );
    nDsc = Dim.nDsc;
    
    % we might face NAN that cannot be read by sscanf:
    % we then try with num2str instead
    if Dim.nDsc<0, 
        [VMX nDsc] = f_SscanfVectMxWithNan( VMX, Dim.nAtt );
    end    
    
    %% ------   Load Levels   -------
    [Lev nDsc2] = LoadDescVectLev( [vbnOut '.' FixtVec.aLev{ixDsc} ] );
    
    if ( nDsc~=nDsc2 ) 
        warning( 'nDsc not same for %s: %d <> %d', dty, nDsc, nDsc2 ); end
    
    %% ------   Plot   ------
    if ismember( ixDsc, [1 3 4] );
        subplot(3,4,cTopRow);
        cTopRow = cTopRow + 1;
    elseif ixDsc==2  % rsg
        subplot(3,1,2);
    elseif ixDsc==5  % shape
        subplot(3,1,3);
    end
    imagesc(VMX); colorbar;
    
    set( gca, 'xtick', 1:Dim.nAtt, 'xticklabel', AttLbs );
    set( gca, 'xticklabelrotation', 45 );
    title( dty );
    
end






