REM runs a focus for image 1 and 2

focxv1 Desc/img1.vec 80 160 80 150 Focii\foc1
focxv1 Desc/img2.vec 80 160 80 150 Focii\foc2
focxv1 Desc/aachen.vec 80 160 80 150 Focii\aachen

focxh1 Desc/img1.vec 80 160 80 150 Focii\foc1
focxh1 Desc/img2.vec 80 160 80 150 Focii\foc2