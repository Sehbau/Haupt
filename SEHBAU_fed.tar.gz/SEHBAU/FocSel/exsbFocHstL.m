%
% Runs program focxhL (histogram), collecting a set of histograms for the
% bounding boxes in file BboxFocii.txt in same directory. Loads histogram
% array as block.
%
% To be run from directory FocSel/
% 
clear;
run('../AdminMb/globalsSB');
%cd( PthProg.focExtr );

imgNa    = 'img1';
%imgNa    = 'aachen';

%% ---------   Boundbox   --------
bbxf        = 'BboxFocii.txt';

%% =========   Command   ========
fipaDsc     = ['Desc/' imgNa '.dsc'];
fipsOut     = ['FOCII'];        % output file name (win backslash!)

cmnd        = ['fochstL ' fipaDsc ' ' bbxf ' ' fipsOut];
[Sts Out]   = system(cmnd);

v_CmndExec( Sts, Out, cmnd, 1 );

%% -------   Load Hist File   -------
pthList     = [fipsOut '.hsfL'];

[AHST Sz]   = LoadFocHistArr( pthList );    

DispLoad( pthList );

%% --------   Plot Flat Univariate   ---------
figure(1); clf; [nr nc]=deal(2,1);
subplot(nr,nc,1);
bar( AHST{1}.Uni.Cnt );
ylabel('nFocii');
xlabel('Bins');
