@echo off
REM
REM Run focus selection.
REM

REM focxv1 Desc/img1.vec 120 160 20 150
REM focxh1 Desc/img1.vec 120 160 20 150

..\DescExtr\h2arr Focii\img1.hsf1 Focii\img1 --bDISP 2
