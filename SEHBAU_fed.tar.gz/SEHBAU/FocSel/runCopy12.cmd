REM copies vector files to matching directory

copy Focii\foc1.vef ..\MtchVec\Desc
copy Focii\foc2.vef ..\MtchVec\Desc
copy Focii\aachen.vef ..\MtchVec\Desc



