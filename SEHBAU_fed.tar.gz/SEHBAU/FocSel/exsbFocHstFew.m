%
% Runs several focus extractions using wrapper function RennFocxh1.
% 
% PREVIOUS  runDsc1.m
% PRESENT   runFocHstFew.m, sa runFocxv1.m
% NEXT      runMvec1.m
%
clear;
run('../AdminMb/globalsSB');
cd( PthProg.focSel );                     
strVec    = 'img1';
%strVec    = 'img2';

% copy bin files (NOT vector files)
copyfile('../DescExtr/Desc/img1.dsb', 'Desc/img1.dsb') 

% Prepare a few focii regions:
%             top bot lef rit
ABbox      = zeros(4,4);            % allocate
ABbox(1,:) = [10 40  10 40];  
ABbox(2,:) = [10 80  10 80];  
ABbox(3,:) = [10 120 10 120]; 
ABbox(4,:) = [10 150 10 150]; 

Fixt        = o_FileExtensions();   % better use this

pthDsc      = ['Desc/' strVec '.dsc'];

Args        = o_CmndArgs( 'focsel' );

%% ========   LOOP   =======
nFoc    = size(ABbox,1);
Nlev    = size(nFoc,1);
Ndsc    = size(nFoc,1);
for f = 1:4

    pthOut  = ['Focii/' strVec '_f' num2str(f)]; 

    if ispc
        pthOut  = u_PathToBackSlash( pthOut ); end

    Sz      = RennFocHst1( pthDsc, ABbox(f,:), pthOut, Args );
    Nlev(f) = Sz.nLev;
    Ndsc(f) = Sz.ntDsc;
    
end



