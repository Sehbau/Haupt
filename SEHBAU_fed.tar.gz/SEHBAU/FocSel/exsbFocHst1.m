%
% Runs program fochst1, extracting one histogram with bounding box specified
% as arguments.
% 
% RUN first exsbFocDsc1.m (see sequence in exsbAll.m)
%
% This program requires the presence of the binary file (.veb)
%
% To be run from dir FocSel/
% 
clear;
run('../AdminMb/globalsSB');
%cd( PthProg.focExtr );

imgNa    = 'img1';
%imgNa    = 'aachen';

%% ---------   Boundbox   --------
%             top bot lef rit
%Bbox      = [100 400 100 300];  % mitte etwa
%Bbox      = [0 300 0 200];     % links oben
Bbox      = [300 500 200 350];  % rechts unten
%Bbox      = [0 500 200 350];  % rechts 

% turn bounding box and file number into string
bboxStr     = sprintf('%d %d %d %d', Bbox(1), Bbox(2), Bbox(3), Bbox(4));

[FextImg FextFoc] = o_FileExtensions();

%% =========   Command   ========
fipaDsc     = ['Desc/' imgNa FextImg.dsc];
fipsOut     = ['Focii/' imgNa];        % output file name (win backslash!)

if ispc
    fipsOut  = u_PathToBackSlash(fipsOut); % slash to backslash for windows
end

cmnd      	= ['fochst1 ' fipaDsc ' ' bboxStr ' ' fipsOut];
[Sts Out]	= system(cmnd);

%% ---------   Load Hist File   -------
[HFU HFB Nunf Nbif Floc]  = LoadFocHist( [fipsOut FextFoc.hstf1] );    

[Hari len]  = u_HistCatFlat( HFU, HFB, Nunf, Nbif, Floc );

%% --------   Convert To Array   ------------
% we use 'h2arr' to convert it to a single array (sa exsbH2arr.m)
fpHari      = ['Focii/' imgNa];
cmndToArr   = ['../DescExtr/h2arr ' fipsOut FextFoc.hstf1 ' ' fpHari ];

if ispc
    cmndToArr = u_PathToBackSlash( cmndToArr ); end

[Sts Out] = system( cmndToArr ); 
v_CmndExec( Sts, Out, cmndToArr, 1 );

lfp         = [fpHari FextFoc.harf];
HariC       = LoadHistImgArr( lfp );
DispLoad( lfp );

%% --------   Plot Flat Univariate   ---------
% copied from exampleLoadHist.m (DescExtr)
figure(1); [nr nc]=deal(4,1);
subplot(nr,nc,1);
bar(HFU.Skl); ylabel('Skl');

subplot(nr,nc,2);
bar(HFU.Rsg); ylabel('RadSig');

subplot(nr,nc,3);
bar(HFU.Arc); ylabel('Arc');

subplot(nr,nc,4);
bar(HFU.Str); ylabel('Str');

%subplot(nr,nc,1);
%bar(HFU.Rdg); ylabel('Ridge');

%subplot(nr,nc,2);
%bar(HFU.Riv); ylabel('River');

%subplot(nr,nc,3);
%bar(HFU.Edg); ylabel('Edge');


%% --------   Plot Flat Bivariate   ---------
figure(2); [nr nc]=deal(4,1);
subplot(nr,nc,1);
bar(HFB.Skl); ylabel('Skl');

subplot(nr,nc,2);
bar(HFB.Rsg); ylabel('RadSig');

subplot(nr,nc,3);
bar(HFB.Arc); ylabel('Arc');

subplot(nr,nc,4);
bar(HFB.Str); ylabel('Str');

%subplot(nr,nc,1);
%bar(HFB.Rdg); ylabel('Ridge');

%subplot(nr,nc,2);
%bar(HFB.Riv); ylabel('River');

%subplot(nr,nc,3);
%bar(HFB.Edg); ylabel('Edge');

%%
% verify:
%figure(3); clf;
%bar( [Hari-HariC] );

