"""

Runs the python example scripts. See also exsbAll.m for comments.

Ensure that the main folder is called 'SEHBAU' and not 'SEHBAU_win|ubu...'

For full list of demos see Matlab scripts (exsbAll.m)

"""
import os

# Get current working directory
crrDir = os.getcwd()

# Check if we are in the SEHBAU directory
if len(crrDir) < 6 or not crrDir[-6:] == 'SEHBAU':
    print('Start from within folder SEHBAU') 
    os.chdir('c:/klab/ppc/SEHBAU/')  # Change to SEHBAU directory


# ------------------------------   Simple Examples   ------------------------------
os.chdir('DescExtr')

os.system('python exsbDscxSimp.py')

os.chdir('../MtchVec')

os.system('python exsbMatch.py')

os.chdir('..')


## -------------------------------------------------------------------------
#                       Descriptor Extraction  (dscx)
#  -------------------------------------------------------------------------
os.chdir('DescExtr')

os.system('python exsbDscxFull.py')

os.chdir('..')

## ----------------------------    Essentials   ---------------------------
os.chdir('Demos')

os.system('python exsbSmlObjDet.py')

os.system('python exsbSalBlobs.py')

os.system('python exsbProposals.py')

os.system('python exsbTxtrMaps.py')

os.chdir('..')


## ---------------------------------------------------------------------
#                            CONVERSIONS
#  ---------------------------------------------------------------------
os.chdir('DescExtr')

print('Demo Hists & Vectors');

os.system('python exsbH2arr.py')
os.system('python exsbD2vmx.py')

os.chdir('..')


# ------------------------------   PlaceRecognition   ------------------------------

# The following is only useful if we continue with MATCHING demo scripts as in
# exsbAll.m (Matlab), otherwise one might move on to plcAll.py in directory
# DemoPlcRec.
if 0:
    os.chdir('DemoPlcRec')

    print('Demo Place Recognition (Essentials)');

    os.system('python plcDscx.py')
    os.system('python plcMtcImg.py')
    
    os.chdir('..')


print('exsbAll.py completed. Bereit fuer mehr.');
