"""

Runs the python example scripts. See also exsbAll.m for comments.

Ensure that the main folder is called 'SEHBAU' and not 'SEHBAU_win|ubu...'

For full list of demos see Matlab scripts (exsbAll.m)

"""
import os

finaPyExe = 'python'        # on some systems
# finaPyExe = 'python3'     # ...on other systems

# Get current working directory
crrDir = os.getcwd()

# Check if we are in the SEHBAU directory
if len(crrDir) < 6 or not crrDir[-6:] == 'SEHBAU':
    print('Start from within folder SEHBAU') 
    os.chdir('c:/klab/ppc/SEHBAU/')  # Change to SEHBAU directory


# ------------------------------   Simple Examples   ------------------------------
os.chdir('DescExtr')

os.system(finaPyExe + ' exsbDscxSimp.py')

os.chdir('../MtchVec')

os.system(finaPyExe + ' exsbMatch.py')

os.chdir('..')


## -------------------------------------------------------------------------
#                       Descriptor Extraction  (dscx)
#  -------------------------------------------------------------------------
os.chdir('DescExtr')

os.system(finaPyExe + ' exsbDscxFull.py')

os.chdir('..')

## ----------------------------    Essentials   ---------------------------
os.chdir('Demos')

os.system(finaPyExe + ' exsbProposals.py')

os.system(finaPyExe + ' exsbSmlObjDet.py')

os.system(finaPyExe + ' exsbTxtrMaps.py')

os.system(finaPyExe + ' exsbSalBlobs.py')

os.system(finaPyExe + ' exsbRoadScene.py') # not fully implemented yet

os.chdir('..')


## ---------------------------------------------------------------------
#                            CONVERSIONS
#  ---------------------------------------------------------------------
os.chdir('DescExtr')

print('Demo Hists & Vectors');

os.system(finaPyExe + ' exsbH2arr.py')
os.system(finaPyExe + ' exsbD2vmx.py')

os.chdir('..')


# ------------------------------   PlaceRecognition   ------------------------------

# The following is only useful if we continue with MATCHING demo scripts as in
# exsbAll.m (Matlab), otherwise one might move on to plcAll.py in directory
# DemoPlcRec.
if 0:
    os.chdir('DemoPlcRec')

    print('Demo Place Recognition (Essentials)');

    os.system(finaPyExe + ' plcDscx.py')
    os.system(finaPyExe + ' plcMtcImg.py')
    
    os.chdir('..')


print('exsbAll.py completed. Bereit fuer mehr.');
