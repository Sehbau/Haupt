"""

Organizational routines and variables.

"""

from dataclasses import dataclass



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   o_FileExtensions   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

File extensions

"""
def o_FileExtensions():

    @dataclass
    class D:
        
        # ----- contours
        dscRRE = '.dscRRE'
        cntEpt = '.CntEpt'

        # ----- image
        dsc  = '.dsc'
        dsbi = '.dsb'
        hsti = '.hst'
        # hstc = '.hstc'     # collection (collHimg)
        # utzi = '.utz'      # utilities (deployed yet?)

        kolm = '.kol'        # kolumns
        txtm = '.txm'        # texture maps
        salc = '.slc'        # saliency

        qbbx = '.qbbx'       # proposals bbox
        qdsc = '.qdsc'       # proposals descriptors

        cvpo = '.cvpo'       # curve partitions organization (deployed yet?)

        bbox = '.Bbox'       # s_FunvBboxAll, ai dscx.cpp

        bonBbx = '.BonBbox'  # s_BonBboxPyr
        bonAsp = '.BonAsp'
        bonPix = '.BonPix'

        # ----- shape
        shp = '.shp'

        # ----- collection
        collHst = '.hstc'    # collHimg
        collSlc = '.slcc'    # ???
        collVec = '.vecc'    # still used!?

        # ----- maps
        mapUch = '.mpu'

    @dataclass
    class F:
        # ----- focus
        dscf = '.dsf'
        hstf1 = '.hsf1'      # PROD/FocExtr/focxh1.cpp
        hstfL = '.hsfL'

    return D, F


