"""

Load files.

"""

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   LoadTextLinewise   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Loads a text file line by line.

cf LoadDescVect() in LoadDescription.py

"""
def LoadTextLinewise( lfn ):

    try:
        with open(lfn, 'r') as file:
            
            aLines = file.readlines()
            
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not open file {lfn}")

    # Strip newline characters
    aLines = [line.rstrip('\n') for line in aLines]
    cLin   = len(aLines)

    return aLines, cLin
