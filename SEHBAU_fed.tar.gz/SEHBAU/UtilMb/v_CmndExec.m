%
% Verify command execution using status. Out is used for verification of
% EOP string or for displaying Out itself.
%
% IN  status   a value equal 0 means succesful execution.
%
% fka u_CheckStatusExec.m
%     v_ProgExec
%
function [] = v_CmndExec( status, Out, cmnd, bVerifyEOP )
        
if nargin > 1
    if iscell( Out )
        % it may be a list of lines, as loaded with LoadTextLineWise.m
        OutDisp = Out(:);
        Out     = cat( 2, Out{:});
    else
        OutDisp = Out;
    end
end
            
if status~=0
    
    if nargin>1
        
        OutDisp
        if nargin>2
            cmnd
        end
    end
    
    error('Program/command did not succeed: status is not 0, but %d', ...
        status); 
end

if nargin<4, return; end

%% ------  Verify Proper Termination  -----
if bVerifyEOP > 0

    ixEOP = strfind( Out, 'EndOfProgram');

    if isempty(ixEOP)
        warning('Program %s not properly terminated.', cmnd);
        OutDisp
        fprintf('Paused');
        pause();
    end

end

end % end of function

