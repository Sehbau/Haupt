%
% Reads a struct-of-maps that had been saved as data matrix.
%
% It is in analogy to struct-of-arrays.
%
% ai LoadTxtrMaps.m
% 
function [S szD] = ReadStcMapFlt( fid, aFieldNames, szM )

% first load as data matrix
[S szD]     = ReadMtrxFlt( fid );

% now turn into a struct-of-array
S           = u_MtrxToStcArr( S, aFieldNames );

% now reshape arrays to maps
S           = u_StcArrToStcMap( S, szM );
end

