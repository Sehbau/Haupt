"""

Shape descriptor extraction for place recognition demo.

More details in plcShpExtr.m

"""
import sys, subprocess
from collections import namedtuple
import numpy as np
from pathlib import Path
sys.path.insert(0, '..')

import AdminPy as sb

# selection bboxes
ntupPrmBboxes = namedtuple('PrmBboxes', ['minHgt', 'minWth'])
Prm         = ntupPrmBboxes( 16, 16 )

dirImg      = Path( 'Imgs/' )
dirDsc      = Path( 'Desc/' )
dirPtch     = Path( 'Ptch/' )
dirShps     = Path( 'Shps/' )

sb.Util.del_FilesDirPat( dirPtch, '*' )
sb.Util.del_FilesDirPat( dirShps, '*' )

FextDsc, FextFoc  = sb.Orga.o_FileExtensions();
fipaBbx     = 'BboxPtchs.txt'          # same name for all images 
ppthPtchx   = sb.FipaExe['ptchxL']
ppthShpx    = sb.FipaExe['shpx']

## -----  List of Images  -----
aImgNam     = list( dirDsc.glob( '*.dsc' ) )
nImg        = len(aImgNam)
if nImg==0:
    print('No images found.')
    raise NoImages

# ------------------------------   LOOP IMAGES   ------------------------------
for i in range(nImg):

    imgNam  = Path( aImgNam[i].stem )
    print(imgNam)

    # -------------------  LOAD  ----------------------
    fpSal   = dirDsc / imgNam.with_suffix( FextDsc.salc )
    fpPrp   = dirDsc / imgNam.with_suffix( FextDsc.qbbx )
    fpDsc   = dirDsc / imgNam.with_suffix( FextDsc.qdsc )

    SLC, Hed   = sb.DescExtr.LoadDescSalc( fpSal )
    QBbx, Nr   = sb.DescExtr.LoadDescPropBbox( fpPrp )
    QDsc       = sb.DescExtr.LoadDescPropAtts( fpDsc )


    # -------------------  BBOXES  ----------------------
    # --- we choose general shapes from the proposal file
    BbxSel      = QBbx.ShpGen
    RGBchn      = QDsc.Shp.RGB
    RGBSel      = np.column_stack((RGBchn.Red, RGBchn.Grn, RGBchn.Blu))
    nBbx, nPrm  = BbxSel.shape
    
    # --------------------   Selection   --------------------
    if False:  # same as MATLAB's "if 0"
        IxLrg = np.arange(nBbx)   # take all (0-based indices)
    else:
        # box height and width
        BxHgt = BbxSel[:, 1] - BbxSel[:, 0]
        BxWth = BbxSel[:, 3] - BbxSel[:, 2]

        # Find indices of "large" boxes
        IxLrg = np.where((BxHgt > Prm.minHgt) & (BxWth > Prm.minWth))[0]

    nLrg = len(IxLrg)
    print(f"Selected {nLrg} props [{nLrg/nBbx:.2f}]")

    # --- subselect using IxLrg
    BbxSel      = BbxSel[IxLrg,:]
    RGBSel      = RGBSel[IxLrg,:]
    
    sb.Util.SaveBboxL( fipaBbx, BbxSel )      # save bounding boxes

    # -------------------  PATCHEXTR  ----------------------
    fipaImg = dirImg / imgNam.with_suffix( '.jpg')
    fistOut = dirPtch / 'P'

    cmndX   = [ppthPtchx, fipaImg, fipaBbx, fistOut]

    Res     = subprocess.run(cmndX, capture_output=True, text=True)

    sb.Util.v_CmndExec( Res ) 

    # -------------------  SHAPEEXTR  ----------------------
    Nbon = np.zeros(nLrg, dtype=np.int32)
    Ncrv = np.zeros(nLrg, dtype=np.int32)

    for s in range(nLrg):   

        # ---------   create patch path   ----------
        fipaPtch1 = dirPtch / f"P{s}.png"

        # ---------   create rgb triplet   ----------
        rgb = (RGBSel[s, :] * 255).astype(np.uint8)
        #strRgb = f"{rgb[0]} {rgb[1]} {rgb[2]}"

        # ---------   create shape output path   ----------
        fipsShp = dirShps / Path( str(imgNam) + '_S' + str(s) )

        # ---------   create command   ----------
        cmndS = [ppthShpx, fipaPtch1, str(rgb[0]), str(rgb[1]), str(rgb[2]), fipsShp]

        # ---------   execute command   ----------
        Res = subprocess.run(cmndS, shell=True, capture_output=True, text=True)

        sb.Util.v_CmndExec( Res )

        # ---------   parse output   ----------
        nBon, nCrv, umf  = sb.ShpExtr.pso_Shpx( Res.stdout )   
        Nbon[s] = nBon
        Ncrv[s] = nCrv

    # ---------   stats printing   ----------
    print(f"Stats for img {i}:")
    print(f"\t# bons min-max    {Nbon.min():2d}-{Nbon.max():3d}")
    print(f"\t# crvs min-max    {Ncrv.min():2d}-{Ncrv.max():3d}")
    print(f"\t# zero bons/crvs  {np.sum(Nbon == 0):2d}/{np.sum(Ncrv == 0):2d}")


print('plcShpExtr completed')    
