%
% Generating a quant vocabulary. Loops sus-groups and images.
%
% afro iclQntVoc.m
%
% PREVIOUS  plcVbnToVmx.m
% CURRENT   plcQntVoc.m
% NEXT      plcVocApply.m
%
clear;
run('../AdminMb/globalsSB');

IxImg       = [0,1,2,3,6];

% loads the indices for the subspaces
GSS         = load( FipaPrm.ssGrps );  

%% ------------------   Admin & Args   -----------------
Admin.bSaveQntV = 0 ;       % =0 means will write to '.\ztst'
Admin.pthOut    = 'Desc\ztmp'; % used if bSaveQntV=0
Admin.pthExe    = PthProg.descUtil;
Admin.finaFrmt  = 7;

Pths            = o_DirNamesExmp( '../DemoPlcRec/' );
Fidf            = o_FileNameIdf();

Args            = o_CmndArgs('dqnt');

% we need to change to utility directory, where the SS indices lie (in
% directory Vocab):
cd( PthProg.descUtil );

%% ------------------------------------------------------------------------
%                             LOOP GROUPS     
%
IxGrpSel = 1:GSS.ntGrp;         % all
%IxGrpSel = 22:GSS.ntGrp;         % last X
%IxGrpSel = [1 4 5 10 27 30 33];
%IxGrpSel = [6 9 35];
%IxGrpSel = [34 35];
nGrpSel 	= length( IxGrpSel );

for g = 1:nGrpSel

    finaGrp     = GSS.aFina{ IxGrpSel(g)};
    [dty idSS]  = u_QuantGroupName( finaGrp );
    
    [Voc Hed] 	= ICL_VOCCREAT( Pths, IxImg, finaGrp, Args, Admin );
    
    StQnts      = u_QuantCodeRange( Voc );
    Hed.minV    = StQnts.minV;
    Hed.maxV    = StQnts.maxV;
    
    % ----------------------   Save   ---------------------
    sfp = sprintf('%s%s_%s_%s.txt', Pths.vocab, Fidf.vocSeg, dty, idSS);
    
    if 1
        SaveQuantArr( Voc, Hed, sfp );
        fprintf('\t\t\t\t\t\t'); DispSave( sfp );
    end
    
end

cd( '../DemoPlcRec/' );
