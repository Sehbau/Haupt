%
% Creating the book of quant vocabularies.
%
% PREVIOUS  plcQntVoc.m
% CURRENT   plcQntBook.m
% NEXT      plcBookApply.m
%
clear;
run('../AdminMb/globalsSB');

GSS     = load( FipaPrm.ssGrps );  DispLoad( FipaPrm.ssGrps );

%% ------------------   Finas   -----------------
Pths    	= o_DirNamesExmp( '../DemoPlcRec/' );
Fidf     	= o_FileNameIdf();

%% ------------------------------------------------------------------------
%                             LOOP GROUPS     
IxGrpSel    = [1:GSS.ntGrp];
nGrpSel     = length( IxGrpSel );

fprintf('                                 nQnt  dimSus / dimOrig\n');
Nvoc = zeros(nGrpSel,1);
AVoc = cell(nGrpSel,1);
for g = 1:nGrpSel
    
    ixGrp  	= IxGrpSel(g);
    fina   	= GSS.aFina{ ixGrp };
    lab   	= GSS.aLab{ ixGrp };

    %fpPrm  = [ 'Colltil/Vocab/' fina ];
    fpVoc   = [ 'Vocab/' Fidf.vocSeg '_' lab '.txt' ];

    fprintf('%-30s ', fpVoc );
    
    if ~exist( fpVoc, 'file' )
        fprintf('\t\t\t\t\t\t\t does not exist\n' );
        continue;
    end
    
    [dty idSS]  = u_QuantGroupName( fina );
    
    [Voc Hed]   = LoadQuantArr( fpVoc );
    Nvoc(g)     = Hed.nQnt;
    AVoc{g}     = Voc;
    
    fprintf(' %4d       %2d / %3d\n', Hed.nQnt, Hed.dimSus, Hed.dimOrg );

end
ntVoc       = sum(Nvoc);
fprintf('ntVoc                           %d\n', ntVoc);

%% -------------------   Save   ----------------------
sfp     = [ FipaPrm.bookOtl ];
if 0
    save( sfp, 'GSS', 'AVoc', 'Nvoc', 'ntVoc' );
end



