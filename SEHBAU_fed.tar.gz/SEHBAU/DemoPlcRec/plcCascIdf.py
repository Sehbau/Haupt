"""

If I were to fully exploit pathlib/Path, I had to adjust in module CASCIDF.
"""
import sys
from pathlib import Path
sys.path.insert(0, '..')
import AdminPy as sb
from dataclasses import dataclass

# -----  paths  -----
pthOpr      = Path.cwd()
DirNames    = sb.Orga.o_DirNames()
Pths        = sb.Orga.o_DirsPrependPath( DirNames, pthOpr )
prmMtcTyp   = ""

# -----  the images  -----
IxImg       = [0, 1, 2, 3, 6]
nImg        = len(IxImg)

# -----  selection & parameters  -----
#stgy     = 'top1st';        # band & grid 
# --- texture first. using mtxtc (collection)
#stgy     = 'txtgBand';        # band histograms
#stgy     = 'txtgGrid';        # grid map
#stgy     = 'txtgComb';        # band & grid 
# --- ens
stgy     = 'enstoptxtgBand';
# --- other
#stgy        = "hist1st"           # histogram first
#stgy      = "kolm1st"          # kolumn first
#stgy      = "ens"              # ensemble

Prms        = sb.Cascade.o_CascIdfPrm( nImg, 0.5, stgy )
Admn        = sb.Cascade.o_CascIdfPth( )

## -----  arguments command  -----
ArgsMvec    = sb.Util.o_CmndArgs( 'mvec' )

ArgsCasc     = sb.Cascade.dclsCascArgs
ArgsCasc.Vec = ArgsMvec

## -----  register  -----
Fixt, Dmy   = sb.Orga.o_FileExtensions()   
RgstFinas   = sb.Mtch.o_RegistFileNames();
RgstFipas   = sb.Orga.o_DirsPrependPath( RgstFinas, Pths.rgst )

sb.Mtch.v_RegistValid( RgstFipas.dsc )

RgstDsc     = sb.Mtch.o_RegistSetSave(     RgstFipas, Pths.desc, "", IxImg, Fixt, 7 ) 
RgstTop     = sb.Mtch.o_RegistSetSaveDtop( RgstFipas, Pths.dtop, '', IxImg, Fixt, 7 )

@dataclass
class RGST:
    pass    

RGST.Fipa   = RgstFipas
RGST.Dsc    = RgstDsc
RGST.Top    = RgstTop

FixtColl       = sb.Orga.o_FileExtensColl()
Admn.FinaColl  = sb.Orga.o_FileNameColl( Pths.coll, FixtColl )

# ------------------------------   LOOP IMAGES   ------------------------------
print(f"MTCHCSC  {Prms.stgy}  prpPre {Prms.prpPre:.1f}  nPre {Prms.nPre}")

import numpy as np

AMesTot    = [None] * nImg  
AOrdPre    = [None] * nImg
AMESdis    = [None] * nImg
AMESsim    = [None] * nImg

ORDdis     = np.zeros((nImg, Prms.nPre), dtype=np.float32)
ORDsim     = np.zeros((nImg, Prms.nPre), dtype=np.float32)

AORDDtyDis = [None] * nImg
AORDDtySim = [None] * nImg
DM         = np.zeros((nImg, nImg), dtype=np.float32)
SM         = np.zeros((nImg, nImg), dtype=np.float32)
NNdis      = np.zeros((nImg, Prms.nPre), dtype=np.int32)
NNsim      = np.zeros((nImg, Prms.nPre), dtype=np.int32)

for i, ixi in enumerate(IxImg):

    fnQuy      = RgstDsc.aFipaDsc[i][:-4]
    fpQuy      = Pths.desc / fnQuy

    FpQuy      = sb.Orga.o_FinaApndExtRepFrmt( fpQuy, Fixt )
    FpQuy.dtop = Pths.dtop / Path( fnQuy + Fixt.dtop )
    
    Res, Sto, Fll = sb.Cascade.CASCIDF( sb.FipaExe, FpQuy, RGST, Admn, ArgsCasc, Prms )
    
    # print( Res.OrdPre )
    
    # --- reduced (only indices)
    AOrdPre[i]  = Res.OrdPre
    
    ORDdis[i,:] = Res.OrdDis
    ORDsim[i,:] = Res.OrdSim
    
    AORDDtyDis[i] = Res.ORDDtyDis
    AORDDtySim[i] = Res.ORDDtySim

    NNdis[i,:]   = Res.OrdDis          # nearest neighbors distance
    NNsim[i,:]   = Res.OrdSim          # nearest neighbors similarity

    DM[ i, Res.OrdDis ]  = Fll.MesTot[:,0]
    SM[ i, Res.OrdSim ]  = Fll.MesTot[:,1]

    sb.Util.printDotProg()


# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))
im1 = ax1.imshow(DM, aspect="auto")
plt.colorbar(im1, ax=ax1)
ax1.set_title("distance")

im2 = ax2.imshow(SM, aspect="auto")
plt.colorbar(im2, ax=ax2)
ax2.set_title("similarity")

plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)
