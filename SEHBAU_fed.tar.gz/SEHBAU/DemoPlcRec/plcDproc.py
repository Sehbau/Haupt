"""

More descriptor processing: binning

More details in plcDproc.m

"""
import sys, subprocess, os, glob
import numpy as np
from pathlib import Path
sys.path.insert(0, '..')
import AdminPy as sb

# --- directories
DirNames    = sb.Orga.o_DirNames()
Fixt, Dmy   = sb.Orga.o_FileExtensions()   

fipaDbin    = Path( sb.FipaExe['dbin'] )      # file path of program binary
fipaDemo    = Path( '../DemoPlcRec' )

# --- list of image files
aDsc        = list( Path(DirNames.desc).glob( '*' + Fixt.dsc ) )
nImg        = len( aDsc )

# I need to change dir, because dbin requires parameter files
os.chdir( sb.PthProg['descUtil'] )  

# ------------------------------   LOOP IMAGES   ------------------------------
for fipaDsc in aDsc:

    outNast = fipaDsc.stem;
    
    fipsBin = Path(DirNames.dbin) / outNast                  # output filestem
    
    cmnd    = [ fipaDbin, fipaDemo / fipaDsc, fipaDemo / fipsBin ]
    
    Res     = subprocess.run(cmnd, shell=True, capture_output=True, text=True)
    
    sb.Util.v_CmndExec( Res )

    sb.Util.printDotProg()


# ------------------------------   Collecting   ------------------------------
os.chdir( fipaDemo )

aHstNa     = glob.glob("Dbin/*.hsspa")    # representation/reference image
finaLst    = 'Regist/FinasHst.txt';
sb.Orga.SaveFipaLstPrependPath( aHstNa, '', finaLst )

fipsColl   = 'Coll/COLLHST';

# -----  build, execute, verify command  -----
cmnd       = f"{sb.FipaExe['collhimg']} {finaLst} {fipsColl}"

Res        = subprocess.run( cmnd, shell=True, capture_output=True, text=True)

sb.Util.v_CmndExec( Res )

# ----------   Load Collection   ----------
Fixt       = sb.Orga.o_FileExtensColl()

HSTC, Nbin = sb.DescExtr.LoadHist.LoadCollHist( fipsColl + Fixt.hsspa )

sb.DescExtr.LoadHist.DispBnumSpat( Nbin )

print(np.sum(HSTC))



