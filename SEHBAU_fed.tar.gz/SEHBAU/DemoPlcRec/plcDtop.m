%
% Descriptor top levels extraction for place recognition demo. 
% 
% Run from directory DemoPlcRec/
%
% PREVIOUS  plcDscx.m
% CURRENT   plcDtop.m
% NEXT      
%
clear;
run('../AdminMb/globalsSB');
% cd( PthProg.plcRec );     

dirDsci     = 'Desc/';              
dirDtop     = 'Dtop/';              

dirDsci     = u_PathToBackSlash( dirDsci ); % change to window backslash

Fixt        = o_FileExtensions();

%% -----  List of Images  -----
aImg    = dir( [dirDsci '*' Fixt.dsc] );
nImg    = length(aImg);

%% ----------   Top Extraction   ----------
optS    = ''; 
for i = 1:nImg
    
    imgName = aImg(i).name;
    outNast = aImg(i).name(1:end-4);
    
    fipaImg = [dirDsci imgName];      % filepath image 
    fipsOut	= [dirDtop outNast];      % output filestem
    
    cmnd   	= [FipaExe.topx ' ' fipaImg ' ' fipsOut ' ' optS];
    
    [sts OutDscx] = system(cmnd);       % excecute program
    
    v_CmndExec( sts, OutDscx, cmnd );

    fprintf('.');
    
end
fprintf('\n');
