"""

Ego-motion of the frames in place recognition demo.

"""
import sys, glob, subprocess, os
from pathlib import Path
sys.path.insert(0, '..')
import AdminPy as sb

dirDsc   = Path( 'Desc/' )

aFina    = list( dirDsc.glob( '*.dsc' ) )
nFrm     = len(aFina)

fipaMotVec = sb.FipaExe['motvec']        # file path of program binary

# --------------------   Loop Images   --------------------
AVec = [None]*(nFrm-1)
for i in range(nFrm-1):

    fina1   = aFina[i] 
    fina2   = aFina[i+1]
    
    cmnd    = [ fipaMotVec, fina1, fina2 ]
    
    Res     = subprocess.run(cmnd, shell=True, capture_output=True, text=True)
    
    sb.Util.v_CmndExec( Res )

    AVec[i] = sb.MtchVec.LoadMotVec( 'Mes/A.MotVec' )

    sb.Util.printDotProg()


# --------------------   Plot Images   --------------------
import matplotlib.pyplot as plt
import numpy as np

plt.figure(1, figsize=(8, 10))
plt.clf()

for i in range(nFrm - 1):
    
    ax = plt.subplot(2, 2, i+1)

    Vec = AVec[i]   

    # mean dissimilarity
    print(np.mean(Vec.Dis))

    # ----- Reliable Vectors -----
    Brlb = Vec.Dis < 0.25
    rtoRel = np.count_nonzero(Brlb) / float(Vec.nMot)
    print(f"Reliable {rtoRel:1.2f}")

    # extract reliable
    Vec.Ep1  = Vec.Ep1[Brlb, :]
    Vec.Ep2  = Vec.Ep2[Brlb, :]
    Vec.nMot = Vec.Ep1.shape[0]

    # compute average radial motion vector
    RadRw = Vec.Ep2[:, 0] - Vec.Ep1[:, 0]
    RadCl = Vec.Ep2[:, 1] - Vec.Ep1[:, 1]
    menRw = np.mean(RadRw)
    menCl = np.mean(RadCl)

    # -----  plot motion vectors  -----
    sb.MtchVec.PlotMotVec( Vec, 1, ax )
    ax.plot([0, menCl], [0, menRw], 'k')

    # keep axes square
    ax.set_aspect('equal', adjustable='box')

    sb.Util.printDotProg

plt.tight_layout()
plt.show(block=False)

