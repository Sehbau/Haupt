%
% Converting attribute values to (vector) matrices, both for
% real-vectors and discretized (binned) vectors, also called bin-vectors.
%
% sa exsbD2vmx.m, exsbDbn2vmx.m
%
% PREVIOUS  plcDscx.m
% CURRENT   plcVbnToVmx.m
% NEXT      plcQntXXX
%
clear;
run('../AdminMb/globalsSB');

dirImg      = 'Imgs/';
%pthOpr      = [pwd '/'];            % path of operation
%pthDsc      = [pthOpr 'Desc/000000']; 
dirDesc     = 'Desc/';
dirVect     = 'Vect/';
%fipsVect    = [pthOpr 'Vect/000000']; 
%pthColl     = [pthOpr 'Coll/'];         
Pths        = o_DirNamesExmp;

FixtDsc     = o_FileExtensions();

%% -----  the images  -----
aImg        = dir( [dirImg '*.jpg'] );
nImg        = length(aImg);
IxImg       = [0 1 2 3 6];

neDsc       = nImg * 5000;          % number of estimated descriptors

%% -------------------   LOOP IMAGES  -------------------------
% If we were to use ICL_DbnToVmx.m, then we had to adjust the filename
% format. Here we carry out both, bin-vector and real-vector to matrix
% conversion.
for i = 1:nImg
    
    imgName = aImg(i).name(1:end-4);
    
    % -----  bin-vectors to matrix  -----
    fipaDsb = [dirDesc imgName FixtDsc.dsbi];  % filepath bin-file
    fipsOut	= [dirVect imgName];            % output filestem
    
    cmnd   	= [ FipaExe.dbn2vmx ' ' fipaDsb ' ' fipsOut];
    
    [sts Out] = system(cmnd);       % excecute program
    
    v_CmndExec( sts, Out, cmnd );
    
    % -----  real-vectors to matrix  -----
    fipaDsc = [dirDesc imgName FixtDsc.dsc];  % filepath descfile
    
    cmnd   	= [ FipaExe.d2vmx ' ' fipaDsc ' ' fipsOut];

    [sts Out] = system(cmnd);       % excecute program

    v_CmndExec( sts, Out, cmnd );
    
    fprintf('.');
end


