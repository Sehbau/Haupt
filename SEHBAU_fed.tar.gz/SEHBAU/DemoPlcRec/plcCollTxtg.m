%
% Collects texturegrams.
%
% Run first the script plcDscx.m to extract the descriptors.
%
% PREVIOUS  plcDscx.m
% CURRENT   plcCollTxtg.m
% NEXT      plcMtcTxtColl.m
%
clear;
run('../AdminMb/globalsSB');

pthOpr      = [pwd '/'];            % path of operation
DirNames    = o_DirNamesExmp();
Pths        = o_DirsPrependPath( DirNames, pthOpr );

IxImg       = [ 0 1 2 3 6 ];

%% -----  register  -----
Fixt        = o_FileExtensions();
RgstFina    = o_RegistFileNames();
RgstFipa    = o_DirsPrependPath( RgstFina, Pths.rgst );

dmy         = o_RegistSetSave( RgstFipa, Pths.desc, '', IxImg, Fixt, 7 );

v_RegistValid( RgstFipa.slc );

aFpSlc      = LoadTextLineWise( RgstFipa.slc );
fp1st       = aFpSlc{1};

%% ====================   Collect Texture   ======================
FixtColl        = o_FileExtensColl();
[FinaColl Fist]	= o_FileNameColl( Pths.coll, FixtColl );

cmndColl    = sprintf('%s %s %s', ...
                FipaExe.collsalc, RgstFipa.slc, Fist.salcFs );

fprintf('%s...', cmndColl);
[status OutColl] = system( cmndColl );
v_CmndExec( status, OutColl, cmndColl, 1 );
fprintf('done\n');

[TXTR  Hed] = LoadCollTxtr( FinaColl );

%% --------------------   Stats  -----------------------
StsColl   	= f_CollTxtrStats( TXTR );

%% --------------------   Reshape Output   -----------------------
szGrd       = [5 5];             % grid size
% --- from collection:
Txgg1       = TXTR.GRD(1,:);
aLb         = o_TxtrLabels(1);
nTxtBis     = length(aLb);

% extract as maps for plotting 
TxgMaps     = u_TxtrGramGridArrToMap( Txgg1, szGrd, aLb );
Irgb        = imread('Imgs/0000000.jpg');

figNo       = 5;
PlotTxtrGramGrids( TxgMaps, figNo, aLb, Irgb );

% extract as matrix for transformer
TxgMx       = u_TxtrGramGridArrToMtrx( Txgg1, szGrd, nTxtBis ); 

% --- load from saliency file directly, for comparison
SLC         = LoadDescSalc( fp1st );
Grids       = SLC.Txa.Grm.Grid;     % [25 7] ^= sequence x components

% must be the same of course:
Df          = TxgMx - Grids;
if any(Df(:)),
    error('not properly arranged somehow');
end

% normalize:
nrm         = 40;
MxNrm       = u_TxtrGramGridArrToMtrx( Txgg1, szGrd, nTxtBis, nrm );

% and do it for the entire collection:
GNRM        = u_TxtrGramGridCollReshape( TXTR.GRD, szGrd, nTxtBis, nrm );

%% --------------------   Plot   -----------------------
figNo = 4;
PlotCollTxtrStats( StsColl, figNo );
    
figure(6); clf;
imagesc( MxNrm ); colorbar;
set(gca, 'xticklabel', aLb );
title('First Image');

figure(7); clf;
imagesc( GNRM ); colorbar;
ylabel('All Images');
xlabel('Grid Units');



