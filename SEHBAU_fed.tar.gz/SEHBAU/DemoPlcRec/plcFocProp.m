%
% Descriptor selection from proposals (.slc, .qprp). 
%
% Run first the script plcDscx.m to extract the descriptors.
%
% PREVIOUS  plcDscx.m
% CURRENT   plcFocProp.m
% NEXT      plc
%
clear;
run('../globalsSB');

dirDsc      = 'Desc/';
dirFoc      = 'Focii/';

if ispc
    %dirDsc  = u_PathToBackSlash( dirDsc ); % not necessary I think
    dirFoc  = u_PathToBackSlash( dirFoc ); 
end
Fext        = o_FileExtensions();

Admin         = u_CmndAdmin();
Admin.pthProg = PthProg.focSel;

%% -----  List of Images  -----
[aImgNam nImg]  = u_DirWotExt( [dirDsc '*.dsc'] );

if nImg==0
    fprintf('No images found.'); return;
end

%% ----------   Focus Extraction Per Image  -----------
optS    = '';
for i = 1:nImg
    
    imgNam  = aImgNam{i}; %aDsc(i).name(1:end-4);

    fpDsc 	= [dirDsc imgNam Fext.dsc ];    
    fpSal   = [dirDsc imgNam Fext.salc];
    fpPrp   = [dirDsc imgNam Fext.qbbx];

    % --- load saliency and proposals
    [Txa Shp Ens Dsc]   = LoadDescSalc( fpSal );
    [QBbx Nr]           = LoadDescPropBbox( fpPrp );

    % --- we choose general shapes from the proposal file
    BbxSel      = QBbx.ShpGen;
    nBbx        = size(BbxSel,1);
    
    % --- take all OR select based on size (if desired)
    if 1
        IxLrg       = 1:nBbx;                       % take all
    else
        % identify the large ones (at least 17*17 pixels)
        BxHgt       = BbxSel(:,2) - BbxSel(:,1);    % box height
        BxWth       = BbxSel(:,4) - BbxSel(:,3);    % box width
        IxLrg       = find( BxHgt>16 & BxWth>16 );  % large ones
    end
    nLrg        = length(IxLrg);
    
    % ---------  LOOP FOCII  ------------
    for l = 1:nLrg
        
        f       = IxLrg(l);
        Bbx     = BbxSel(f,:);

        fpOut   = [dirFoc imgNam '_F' num2str(f-1)];
        
        [SzDsc OutDsc] = RennFocDsc1( fpDsc, Bbx, fpOut, Admin );
        [SzHst OutHst] = RennFocHst1( fpDsc, Bbx, fpOut, Admin );
        
        assert( SzDsc.nLev==SzHst.nLev, 'nLev not same');
        % not same, because we use full set for histogramming
        %assert( SzDsc.ntDsc==SzHst.ntDsc, 'nLev not same');
        
        fprintf('.');
    end
end

fprintf('\n');




