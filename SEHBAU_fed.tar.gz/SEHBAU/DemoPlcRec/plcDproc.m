%
% Descriptor processing: 
% - top extraction as wrapper function. 
% - applying 'dbin' as wrapper function.
% - loading spatial histograms and preparing them for a transformer
% 
% Start from directory DemoPlcRec. It will switch to DescUtil further
% below.
%
% PREVIOUS  plcDscx.m
% CURRENT   plcDproc.m
% NEXT      plcQntVoc.m
%
clear;
run('../AdminMb/globalsSB');

IxImg       = [0,1,2,3,6];

Dirs        = o_DirNamesExmp();
Fixt        = o_FileExtensions();

%% ----------   Top Extraction   ----------
ICL_TOPX( FipaExe.topx, IxImg, Dirs, Fixt, 7 );


%% ----------   Binning   ---------
optS        = 'Params/PrmDbin_Crude.txt';
%optS        = 'Params/PrmDbin_Refnd.txt';

% I need to change to directory of 'dbin' to access the edge files.
cd( PthProg.descUtil );
% and therefore adjust the paths
pthDemo     = '../DemoPlcRec/';
Dirs        = o_DirNamesExmp( pthDemo );

% a bit pointless to provide fullpath for executable
ICL_DBIN( FipaExe.dbin, IxImg, Dirs, Fixt, 7, optS );


%% ----------   CollHist   ---------
aImgNaRep   = dir( [Dirs.dbin '*' Fixt.hsspa] );    % representation/reference image
finaLst     = 'Regist/FinasHsspa.txt';
SaveFipaLstPrependPath( aImgNaRep, Dirs.dbin, finaLst );

fipsColl    = [ Dirs.coll 'COLL'];

fpProg      = FipaExe.collhimg;  
v_ProgExists( fpProg ); 

% -------   Execute Command   --------
cmnd         = sprintf('%s %s %s', fpProg, finaLst, fipsColl );
[status Out] = system( cmnd );
v_CmndExec( status, Out, cmnd );

cd( pthDemo );

%% -------   Load Collected Histogram   -------
FixtColl        = o_FileExtensColl();

[HSTC Nbin]     = LoadCollHist( [ fipsColl FixtColl.hsspa ] );

% -------   Subselect   --------
% Example for subselection of spatial histogram
[HSTSel NbinS]  = u_HspaSel( HSTC, Nbin, 'cntfrm' );

% -------   Prepare for Transformer   ---------- 
% If we were to feed the histogram directly (without projection: input size
% = embedding size ), then it makes sense to ensure proper dimensionality
% before feeding it to the transformer
nAttnHed    = 7;                % number of attention heads
IxTrf       = u_IxTrimToAttHed( HSTSel, NbinS.nCells, NbinS.nBinPerCell, nAttnHed );
HSTT        = HSTSel(:,IxTrf.Ix);   % this goes into the direct transformer

%% -------  Plot  -------
figure(1); 
imagesc(HSTT);
ylabel('Samples (nImg)');
xlabel( sprintf('Input Size %d', IxTrf.nSel) );
