%
% Texture matching, with a collection bank using executable mtxtc.
%
% Run first the script plcDscx.m to extract the descriptors.
%
% PREVIOUS  plcCollTxtg.m
% CURRENT   plcMtcTxtColl.m, sa plcMtcTxtIdv.m
% NEXT      
%
clear;
run('../AdminMb/globalsSB');

pthOpr      = [pwd '/'];            % path of operation
DirNames    = o_DirNamesExmp();
Pths        = o_DirsPrependPath( DirNames, pthOpr );

IxImg       = [ 0 1 2 3 6 ];

%% -----  register  -----
RgstFina    = o_RegistFileNames();
RgstFipa    = o_DirsPrependPath( RgstFina, Pths.rgst );

v_RegistValid( RgstFipa.slc );

aFpSlc      = LoadTextLineWise( RgstFipa.slc );
fp1st       = aFpSlc{1};

%% ====================   MTCHTXT   ======================
FixtColl    = o_FileExtensColl();
FinaColl    = o_FileNameColl( Pths.coll, FixtColl );

% ---- for simplicity we match only 1-versus-all
fprintf('MTCHTXT\n');
fidfTxt     = 'Txtr';
PthM        = o_FileNameMtxtc( 1, fidfTxt );

%Wgt         = o_WgtTxtrMtch();

cmndBnd     = sprintf('%s %s %s', FipaExe.mtxtc, fp1st, FinaColl.txgb );
cmndGrd     = sprintf('%s %s %s', FipaExe.mtxtc, fp1st, FinaColl.txgg );

[StsBnd OutBnd] = system( cmndBnd ); 
[StsGrd OutGrd] = system( cmndGrd ); 

v_CmndExec( StsBnd, OutBnd, cmndBnd, 1 );
v_CmndExec( StsGrd, OutGrd, cmndGrd, 1 );

bDisp       = 1;
Mes         = LoadMeasMtxtc( PthM, bDisp );

Dis.TxgTot  = Mes.Txg.Grd + Mes.Txg.Bnd;    % combine to total

%% ---------------   Plot   --------------
xLab    = {'0-0' '0-1' '0-2' '0-3' '0-6'};

figure(2); clf;
[nr nc] = deal(1,3);

% ------------   1st Row (Texturegrams)   ------------
subplot(nr,nc,1);
bar( Mes.Txg.Grd ); 
set(gca, 'xticklabel', xLab);
ylabel('Distances');
title('Txg Grid');

subplot(nr,nc,2);
bar( Mes.Txg.Bnd ); 
set(gca, 'xticklabel', xLab);
title('Txg Band');

subplot(nr,nc,3);
bar( Dis.TxgTot ); 
set(gca, 'xticklabel', xLab);
title('Txg Tot');

