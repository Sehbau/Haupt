%
% Collecting the bin-vectors to a single matrix.
%
% PREVIOUS  plcVbnToVmx.m
% CURRENT   plcCollVecBin.m
% NEXT      plcQntHist.m
%
clear;
run('../AdminMb/globalsSB');

dirImg      = 'Imgs/';
pthOpr      = [pwd '/'];            % path of operation
%pthDsc      = [pthOpr 'Desc/000000']; 
%dirDesc     = 'Desc/';
%dirVect     = 'Vect/';
fipsVect    = [pthOpr 'Vect/000000']; 
pthColl     = [pthOpr 'Coll/'];              

[aFext nDty] = o_FileExtensVect( );
nDty        = 5;

FixtDsc     = o_FileExtensions();

%% -----  the images  -----
aImg        = dir( [dirImg '*.jpg'] );
nImg        = length(aImg);
IxImg       = [0 1 2 3 6];

neDsc       = nImg * 5000;          % number of estimated descriptors

%% ----------------------   LOOP DESCTYPES   --------------------------
% Now we concatenate the bin matrices. 
for d = 1:nDty

    fext    = aFext.aVbn{d};
    dty     = fext(4:end);
    
    COLL    = ICL_COLLBIN( fipsVect, IxImg, fext, neDsc );
    
    if COLL.ntV==0
        fprintf('   ****  no descriptors for %s  ****\n', dty);
        continue;
    end
    
    % the unique vectors and their hash base:
    QNT   	= f_QuntForm( COLL.BIN, dty );

    sfn     = sprintf('%sQNT_%s%s', pthColl, dty );
    
    if 1
        save( sfn, 'QNT' );
        DispSave( sfn );
    end

    %% -------  Plot  -------
    figure(d);
    
    subplot(1,2,1); imagesc( COLL.BIN ); colorbar;

    title(['All Bin Vectors for ' dty]); 
    %subplot(1,2,1); imagesc(COLL.QNT(end-10000:end,:));
    subplot(2,2,2); imagesc( QNT.QNT ); title('Quants');
    subplot(2,2,4); plot( QNT.KtO ); title('Ordered Freq');

end
