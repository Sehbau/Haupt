"""

Focus selection with proposals.

More details in plcFocProp.m

"""
import sys, subprocess
import numpy as np
from pathlib import Path
sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.FocSel import RennFocHst1, RennFocDsc1
from AdminPy.DescExtr.Saliency import *
from AdminPy.DescExtr.DescFile.LoadDescription import LoadDescPropAtts

FextDsc     = o_FileExtensions();

dirDsc      = Path( 'Desc/' )
dirFoc      = Path( 'Focii/' )

sb.Util.del_FilesDirPat( dirFoc, '*' )

aDsc        = list( dirDsc.glob( '*.dsc' ) ) # list of descriptor files
nImg        = len(aDsc)
if nImg==0:
    print('no descriptor files found. Perhaps run plcDscx.py')
    breakpoint()

Args     = sb.Util.argsCmndRenn
pthProg  = sb.PthProg['focSel']


# ------------------------------   LOOP IMAGES   ------------------------------
for i in range(nImg):

    fpDsc   = aDsc[i]
    imgNam  = Path( fpDsc.stem )                 # remove .jpg extension

    fpSal   = dirDsc / imgNam.with_suffix( FextDsc.salc )
    fpPrp   = dirDsc / imgNam.with_suffix( FextDsc.qbbx )

    QBbx, Nr    = LoadDescPropBbox( fpPrp )
    SLC         = LoadDescSalc( fpSal )
    
    # --- we choose general shapes from the proposal file
    BbxSel      = QBbx.ShpGen;
    nBbx, nPrm  = BbxSel.shape

    # --------------------   Selection   --------------------
    if False:
        IxLrg = np.arange(nBbx)   # take all (0-based indices)
    else:
        minHgt = 16
        minWth = 16

        # box height and width
        BxHgt = BbxSel[:, 1] - BbxSel[:, 0]
        BxWth = BbxSel[:, 3] - BbxSel[:, 2]

        # Find indices of "large" boxes
        IxLrg = np.where((BxHgt > minHgt) & (BxWth > minWth))[0]

    nLrg = len(IxLrg)
    print(f"Selected {nLrg} props [{nLrg/nBbx:.2f}]")

    # --------------------   Focii   --------------------
    for f in range(nBbx):
    
        Bbx     = BbxSel[f,:]
        fpFoc   = dirFoc / Path( str(imgNam) + '_F' + str(f) ) 

        SzHst, OutHst = RennFocHst1( str(fpDsc), Bbx, str(fpFoc), Args, pthProg )
        SzDsc, OutDsc = RennFocDsc1( str(fpDsc), Bbx, str(fpFoc), Args, pthProg )

        #print(Bbx)

        assert SzDsc.nLev==SzHst.nLev, 'nLev not same'

        print('.', end='', flush=True)

        
    print('')
