"""

Descriptor extraction for place recognition demo with zones.

More details in plcFocZon.m

"""
import sys, glob, subprocess
sys.path.insert(0, '..')
from globalsSB import *
from CmndSupp import *

from OrgFileNames import *
from LoadDescSalc import *
from LoadProposals import LoadDescPropBbox
from RennFocSel import *

FextDsc, FextFoc  = o_FileExtensions();

dirDsc      = 'Desc/'
dirFoc      = 'Focii/'

# --- List of descriptor files
aDsc        = glob.glob( os.path.join( dirDsc, '*.dsc' ) )
nImg        = len(aDsc)

Admin       = adminCmnd
Admin.pthProg  = PthProg['focSel']


# ------------------------------   LOOP IMAGES   ------------------------------
for i in range(nImg):

    fpDsc   = aDsc[i]
    imgName = os.path.basename( fpDsc )[:-4]    # remove .jpg extension

    fpSal   = os.path.join( dirDsc, imgName + FextDsc.salc )
    fpPrp   = os.path.join( dirDsc, imgName + FextDsc.qbbx )

    QBbx, Nr           = LoadDescPropBbox( fpPrp )
    Txa, Shp, Ens, Dsc = LoadDescSalc( fpSal )
    
    # --- we choose general shapes from the proposal file
    BbxSel      = QBbx.ShpGen;
    nBbx, nPrm  = BbxSel.shape

    # --------------------   Focii   --------------------
    for f in range(nBbx):
    
        Bbx     = BbxSel[f,:]
        fpFoc   = dirFoc + imgName + '_F' + str(f)

        SzHst, OutHst = RennFocHst1( fpDsc, Bbx, fpFoc, Admin )
        SzDsc, OutDsc = RennFocDsc1( fpDsc, Bbx, fpFoc, Admin )

        #print(Bbx)

        assert SzDsc.nLev==SzHst.nLev, 'nLev not same'

        print('.', end='', flush=True)

        
    print('')
