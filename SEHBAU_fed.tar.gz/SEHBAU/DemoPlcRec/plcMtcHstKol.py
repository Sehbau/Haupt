"""

Matching hists and kolumns

more in plcMtcHstKol.m

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')
import AdminPy as sb

## ----------   Prepare Input Args   --------
progMhst    = Path( '../MtchHst/mhstL' )
progMkol    = Path( '../MtchHst/mkolL' )

dirDesc     = Path( 'Desc/' )

fipaHstTst  = dirDesc / Path( '0000000.hst' )    # testing image 
fipaKolTst  = dirDesc / Path( '0000000.kol' )    # testing image 

aHstRep     = list( dirDesc.glob( '*.hst' ) ) # representation/reference image
aKolRep     = list( dirDesc.glob( '*.kol' ) ) # representation/reference image

finaRgstHst = Path( 'Regist/FinasHst.txt' )
finaRgstKol = Path( 'Regist/FinasKol.txt' )

sb.MtchVec.Register.SaveFipaLst( aHstRep, finaRgstHst )
sb.MtchVec.Register.SaveFipaLst( aKolRep, finaRgstKol )

finaMesHst  = Path( 'Mes/HstLst.txt' )
finaMesHuor = Path( 'Mes/HstUor.txt' )     # cannot be changed
finaMesKol  = Path( 'Mes/KolLst.txt' )
finaMesKuor = Path( 'Mes/KolUor.txt' )     # cannot be changed


## =========   Command Mhst/Mkol  ========
cmndHst      = [ Path( sb.FipaExe['mhstL'] ), fipaHstTst,  finaRgstHst, finaMesHst ]
Res          = subprocess.run( cmndHst, shell=True, capture_output=True, text=True )
sb.Util.v_CmndExec( Res )

cmndKol      = [ Path( sb.FipaExe['mkolL'] ), fipaKolTst, finaRgstKol, finaMesKol ]
Res          = subprocess.run( cmndKol, shell=True, capture_output=True, text=True )
sb.Util.v_CmndExec( Res )


## -------   Load Matching Results   -------
nRep         = len(aHstRep);

OrdHis, DisHisOrd = sb.Util.LoadSortFltTxt( finaMesHst, nRep )
OrdKol, DisKolOrd = sb.Util.LoadSortFltTxt( finaMesKol, nRep )

DisHisUor    = sb.Util.LoadFltTxt( finaMesHuor, nRep );
DisKolUor    = sb.Util.LoadFltTxt( finaMesKuor, nRep );

# ------------------------------   Plot   ------------------------------
import matplotlib.pyplot as plt
import numpy as np

xLab = ['0-0', '0-1', '0-2', '0-3', '0-6']
xPos = np.arange(len(xLab))

plt.figure(2)
plt.clf()

plt.subplot(2, 1, 1)
plt.bar(xPos, DisHisUor)
plt.xticks(xPos, xLab)
plt.ylabel('Distances')
plt.title('Histogram Differences')

plt.subplot(2, 1, 2)
plt.bar(xPos, DisKolUor)
plt.xticks(xPos, xLab)
plt.ylabel('Distances')
plt.title('Kolumn Differences')

plt.tight_layout()
plt.show(block=False)
plt.pause(.01)

import time
time.sleep(1)


