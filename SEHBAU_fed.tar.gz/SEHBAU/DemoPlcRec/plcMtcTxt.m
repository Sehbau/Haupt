%
% Texture matching with bounding boxes.
%
% Run first the script plcDscx.m to extract the descriptors.
%
% PREVIOUS  plcDscx.m
% CURRENT   plcMtcTxt.m
% NEXT      
%
clear;
run('../AdminMb/globalsSB');

dirImg      = 'Imgs/';
pthOpr      = [pwd '/'];            % path of operation
pthRgst     = [pthOpr 'Regist/'];              
pthDsc      = [pthOpr 'Desc/'];     
prmMtcTyp   = '';

%% -----  the images  -----
aImg        = dir( [dirImg '*.jpg'] );
nImg        = length(aImg);
IxImg       = [0 1 2 3 6];

%% -----  register  -----
Fixt        = o_FileExtensions();
Rgst        = o_RegistSetSave( pthRgst, pthDsc, '', IxImg, Fixt, 7 );

v_RegistValid( Rgst.fpaSlc );

aFpSlc      = LoadTextLineWise( Rgst.fpaSlc );
fp1st       = aFpSlc{1};

%% ====================   MTCHTXT   ======================
fprintf('MTCHTXT\n');
fpMesTxt        = 'Mes/MesTxt';
PthM.Fixd       = o_FileNameMeas( 1 );
PthM.User       = o_FileNameMeas( fpMesTxt );
PthM.User.txtStm = fpMesTxt;

Wgt  = o_WgtTxtrMtch();

Dis  = f_MtxtL( FipaExe.mtxt1, fp1st, aFpSlc, PthM, Wgt );


%% ---------------   Plot   --------------
xLab    = {'0-0' '0-1' '0-2' '0-3' '0-6'};

figure(1); clf;
bar(Dis.Grid); 
set(gca, 'xticklabel', xLab);
ylabel('Distances');
title( sprintf('Texture') );

