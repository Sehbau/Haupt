%
% Texture matching, with individual pairs using executable mtxt1.
%
% Run first the script plcDscx.m to extract the descriptors.
%
% PREVIOUS  plcDscx.m
% CURRENT   plcMtcTxtIdv.m, sa plcMtcTxtColl.m
% NEXT      
%
clear;
run('../AdminMb/globalsSB');

dirImg      = 'Imgs/';
pthOpr      = [pwd '/'];            % path of operation
pthRgst     = [pthOpr 'Regist/'];              
pthDsc      = [pthOpr 'Desc/'];     
prmMtcTyp   = '';

%% -----  the images  -----
aImg        = dir( [dirImg '*.jpg'] );
nImg        = length(aImg);
IxImg       = [ 0 1 2 3 6 ];

%% -----  register  -----
Fixt        = o_FileExtensions();
RgstFina    = o_RegistFileNames();
RgstFipa    = o_DirsPrependPath( RgstFina, pthRgst );

Rgst        = o_RegistSetSave( RgstFipa, pthDsc, '', IxImg, Fixt, 7 );

v_RegistValid( RgstFipa.slc );

aFpSlc      = LoadTextLineWise( RgstFipa.slc );
fp1st       = aFpSlc{1};

%% ====================   MTCHTXT   ======================
fprintf('MTCHTXT\n');
fidfTxt     = 'Txt1';
PthM        = o_FileNameMtxt1( 1, fidfTxt );

Wgt         = o_WgtTxtrMtch();

Dis         = f_MtxtL( FipaExe.mtxt1, fp1st, aFpSlc, PthM, Wgt );


%% ---------------   Plot   --------------
xLab    = {'0-0' '0-1' '0-2' '0-3' '0-6'};

figure(1); clf;
[nr nc] = deal(2,4);

% ------------   1st Row (Texturegrams)   ------------
subplot(nr,nc,1);
bar( Dis.TxgGrid ); 
set(gca, 'xticklabel', xLab);
ylabel('Distances');
title('Txg Grid');

subplot(nr,nc,2);
bar( Dis.TxgSenk ); 
set(gca, 'xticklabel', xLab);
title('Txg Vertical');

subplot(nr,nc,3);
bar( Dis.TxgWaag ); 
set(gca, 'xticklabel', xLab);
title('Txg Horizontal');

subplot(nr,nc,4);
bar( Dis.TxgTot ); 
set(gca, 'xticklabel', xLab);
title('Txg Tot');

% -------------   Bbox   -----------
subplot(nr,nc,5);
bar( Dis.Bbx ); 
set(gca, 'xticklabel', xLab);
title('BlobBbx');

% ------------   2nd Row (Freckles)   ------------
if 0
subplot(nr,nc,5);
bar( Dis.FrkLay ); 
set(gca, 'xticklabel', xLab);
ylabel('Distances');
title('Frk Lay');

subplot(nr,nc,6);
bar( Dis.FrkGrid ); 
set(gca, 'xticklabel', xLab);
title('Frk Grid');

subplot(nr,nc,7);
bar( Dis.FrkSenk); 
set(gca, 'xticklabel', xLab);
title('Frk Vertical');

subplot(nr,nc,8);
bar( Dis.FrkWaag); 
set(gca, 'xticklabel', xLab);
title('Frk Horizontal');
end

% ------------   3rd Row (FrkTot & Blobs)   ------------
if 0
subplot(nr,nc,9);
bar( Dis.FrkTot ); 
set(gca, 'xticklabel', xLab);
ylabel('Distances');
title('Frk Tot');
end


%title( sprintf('Texture') );

