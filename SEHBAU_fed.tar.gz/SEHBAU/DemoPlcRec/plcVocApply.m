%
% Applying a quant vocabulary.
%
% afro iclVocApply.m
%
% PREVIOUS  plcQntVoc.m
% CURRENT   plcVocApply.m
% NEXT      
%
clear;
run('../AdminMb/globalsSB');

IxImg 	= [0,1,2,3,6];

GSS     = load( FipaPrm.ssGrps );  DispLoad( FipaPrm.ssGrps );

%% ------------------   Admin & Args   -----------------
Admin.bSaveQntIx = 0 ;       % =0 means will write to pthOut
Admin.pthOut    = 'Desc\ztmp'; % used if bSaveQntIx=0
Admin.pthExe    = PthProg.descUtil;
Admin.finaFrmt  = 7;

Args            = o_CmndArgs('dqnt');
Pths            = o_DirNamesExmp( '../DemoPlcRec/' );
Fidf            = o_FileNameIdf();

% we need to change to utility directory, where the SS indices lie (in
% directory Vocab):
cd( PthProg.descUtil );

%% ------------------------------------------------------------------------
%                             LOOP GROUPS     
IxGrpSel    = [1:3];
nGrpSel     = length( IxGrpSel );

for g = 1:nGrpSel
    
    ixGrp       = IxGrpSel(g);
    jGrp.fina   = GSS.aFina{ ixGrp };
    jGrp.lab    = GSS.aLab{ ixGrp };

    Args.fpPrm  = [ 'Vocab/' jGrp.fina ];
    Args.fpVoc  = [ 'Vocab/' Fidf.vocSeg '_' jGrp.lab '.txt' ];
    
    if ~exist( Args.fpVoc, 'file' )
        fprintf('vocab %s does not exist\n', Args.fpVoc );
        continue;
    end
    
    [dty idSS]  = u_QuantGroupName( jGrp.fina );
    
    %% ----------------------   Apply   --------------------
    [QST Hed]   = ICL_VOCAPPLY( Pths, IxImg, jGrp, Args, Admin );
    
    
    %% ----------------------   Plot   ---------------------
    figure(g);
    imagesc( QST );
    title( jGrp.lab );
    pause(.2);
    
end
    
cd( '../DemoPlcRec/' );
