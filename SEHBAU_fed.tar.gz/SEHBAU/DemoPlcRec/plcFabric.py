"""

Fabric generation, direct method that saves the cabinet as temporary file only.

"""
import sys, subprocess, os, glob
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Orga.SaveFipaLst import SaveFipaLstPrependPath
from AdminPy.DescExtr.Hist.DescBinAnf import DispBnumSpat
from AdminPy.DescProc.RennDbin import RennDbinFabric
from AdminPy.Collection.LoadCollHist import LoadCollHist
from AdminPy.Util.CmndSupp import o_CmndArgs


# --- directories
DirNames    = o_DirNames()
Fixt        = o_FileExtensions()   

fipaDbin    = Path( sb.FipaExe['dbin'] )      # file path of program binary
fipaFabric  = Path( sb.FipaExe['fabric'] )

fipaDemo    = Path( '../DemoPlcRec' )

# --- list of image files
aDsc        = list( Path(DirNames.desc).glob( '*' + Fixt.dsc ) )
nImg        = len( aDsc )

Args        = o_CmndArgs('fabric') 
Args.fpPrm  = 'Params/PrmDbin_Cabinet.txt'

# I need to change dir, because dbin requires parameter files
os.chdir( sb.PthProg['descProc'] )  

print('Fabric generation...', end='')
# ------------------------------   LOOP IMAGES   ------------------------------
for fipaDsc in aDsc:

    outNast = fipaDsc.stem;
    
    fipsFbrc = fipaDemo / Path(DirNames.dbin) / outNast      # output filestem

    RennDbinFabric( fipaDemo / fipaDsc, fipsFbrc, Args, fipaDbin, fipaFabric )

    sb.Util.printDotProg()
print('fertig')

# ------------------------------   Register File   ------------------------------
os.chdir( fipaDemo )

aFbrcNa    = glob.glob("Dbin/*.fbrc")    
finaLst    = 'Regist/FinasFbrc.txt';
SaveFipaLstPrependPath( aFbrcNa, '', finaLst )

