%
% Applying a book (a set of quant vocabularies).
%
% PREVIOUS  plcQntBook.m
% CURRENT   plcBookApply.m, af plcVocApply.m
% NEXT      
%
clear;
run('../AdminMb/globalsSB');

IxImg 	= [0,1,2,3,6];
nImg    = length(IxImg);

BOOK    = load( FipaPrm.bookOtl );  DispLoad( FipaPrm.bookOtl );
GSS     = BOOK.GSS;
IxBeg   = [0; cumsum(BOOK.Nvoc)];

%% ------------------   Admin & Args   -----------------
Admin.bSaveQntIx = 0 ;       % =0 means will write to pthOut
Admin.pthOut    = 'Desc\ztmp'; % used if bSaveQntIx=0
Admin.pthExe    = PthProg.descUtil;
Admin.finaFrmt  = 7;

Args            = o_CmndArgs('dqnt');
Pths            = o_DirNamesExmp( '../DemoPlcRec/' );
%Fidf            = o_FileNameIdf();
Fixt            = o_FileExtensions();
aDty            = o_DescTypes('cfasshp');
%AttsLabR        = o_AttsLabels();
%AttsLabB        = o_AttsLabBin();
%IXATTR          = o_AttIxAsFields( AttsLabR, 1 );
%IXATTB          = o_AttIxAsFields( AttsLabB, 1 );

%% ------------------------------------------------------------------------
%                             LOOP IMAGES     
%
QSTC        = zeros( nImg, BOOK.ntVoc, 'single' );
Nqnt        = zeros( nImg, 1 );
for i = 1:nImg,     

    ixi     = IxImg(i);
    
    % ----------   FileStemWidf   ------------
    ffst        = o_FileNameFrmt( Pths.veci, ixi, '', Admin.finaFrmt );
    %ffst  = [ Fina1.veci num2str(ixi) ];
 
    PosDunv     = LoadDunvPos( ffst, aDty );    
    
    Admin.ixi   = i;
    
    QIM         = f_VocabImg( GSS, IxBeg, Admin, ffst, PosDunv );
    %QIMv1      = f_VocabImgV1( GSS, IxBeg, Admin, ffst );

    QSTC(i,:) 	= cat(1, QIM.AQst{:});

    fprintf('img %d,  nWrds %d\n', i, QIM.ntQnt );
    
    Nqnt(i)     = QIM.ntQnt;

    %% ----------------  Save  --------------------
    if 1
        sfn     = [ ffst Fixt.qim ];
        %save( sfn, 'QIM' );
    end

    
    %% ----------------  Plot  --------------------
    if 1
        figure(1); clf;
        plot( QIM.PosRel(:,2), 1-QIM.PosRel(:,1), '.');
        pause(.1);
    end
    
    % ----- progress dots (not really useful for only 6 images)
    if mod(i,round(nImg/20))==0, 
        fprintf('.' );
    end     
    
end

%% --------------   Plot   --------------
figure(1); clf;
imagesc( QSTC );

