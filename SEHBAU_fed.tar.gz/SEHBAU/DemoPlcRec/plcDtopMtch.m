%
% Matching descriptor tops. All-against-all (as opposed to few pairs in
% plcMtcImg.m)
% 
% Run from directory DemoPlcRec/
%
% PREVIOUS  plcDtop.m
% CURRENT   plcDtopMtch.m
% NEXT      
%
clear;
run('../AdminMb/globalsSB');
% cd( PthProg.plcRec );     

dirDtop     = 'Dtop/';              
IxImg       = [0 1 2 3 6];

%% -----  finas & paths  -----
Fixt        = o_FileExtensions();
RgstFina    = o_RegistFileNames();
RgstFipa    = o_DirsPrependPath( RgstFina, [PthProg.mtchVec 'Regist/']);

Rgst        = o_RegistSetSaveDtop( RgstFipa, dirDtop, ...   
                                    '', IxImg, Fixt, 7 );

aFipa       = LoadTextLineWise( RgstFipa.dtop );

fpMesDtop   = 'Mes/MesDtop.txt';
lineArgs    = '';

nImg        = length(IxImg);

%% ----------   Descriptor Matching   ----------
% all-against-all
MesMx   = zeros( nImg, nImg );
for i = 1:nImg
    
    finaQuy = aFipa{i};

    cmndV   = [ FipaExe.mvecL ' ' finaQuy ' ' RgstFipa.dtop ' ' fpMesDtop ' ' lineArgs ]; 
    OutMvec = f_CmndExec( cmndV ); 
    
    MesDtop = LoadMtchMes( fpMesDtop, nImg );   
    
    MesMx(i, :) = MesDtop(:,1);
    
    fprintf('.');
    
end
fprintf('\n');

figure(1); clf;
imagesc( MesMx );

%% ------------   Now with Function   -----------
Admn        = o_MvecAdmin( PthProg.mtchVec );
Args        = o_CmndArgs( 'mvec' );
Args.fpMes  = Admn.fpMesVec;

bPlot       = 1;
bDisp       = 1;
[Ens DTY]   = MVECLXLfull( RgstFipa.dtop, RgstFipa.dtop, Admn, Args,...
                     	'', bPlot, bDisp );
                    
%% ------------   verify   --------                     
DfMes = MesMx - Ens.DM;               
if any( DfMes(:) ), warning('not same'); end

