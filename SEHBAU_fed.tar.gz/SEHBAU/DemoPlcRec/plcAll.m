%
% Runs all scripts for place recognition
%
% Runs 5 downsized frames from the living room collection.
%

plcDscx             % descriptor extraction

%% -----   (Whole) Image   -----
plcMtcImg           % vector matching
plcMtcHstKol     	% histogram and kolumn matching
plcMtcTxt           % texture (bboxes)
plcCascIdf          % cascade identifier

plcCorrSelf         % self-correlating all frames

%% -----   Focii using Zones   -----
plcFocZon           % uses focdsc1 and fochst1
plcMtcZon1o1        % uses mvec1 and improvised hist-distances
plcMtcZonLst        % uses mvecL, mhstL

% potential improvement (not deployed yet)
% plcFocZonHst.m    % I dont have a binary that exploits a pack of histograms.m
% plcMtcZonHst.m


%% -----   Focii using Proposals   -----
% ( note that this will overwrite some of the files generated above.
%   Running zones above again, will work only if you clear the files. )
%
plcFocProp          % uses focdsc1 and fochst1
plcMtcProp          % uses mvec1


%% -----   ShapeExtraction using ShapeProposals   -----
plcShpExtr          % uses shpx
plcMtcShp           % uses mshp1


%% -----   EgoMotionFlow   -----
plcMotEgo           % uses motvec1

%% -----   Quants   -----
plcCollVecBin
plcQntHist

fprintf('Demo Place Recognition completed\n');