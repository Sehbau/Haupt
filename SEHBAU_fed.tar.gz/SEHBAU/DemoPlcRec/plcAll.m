%
% Runs all scripts for place recognition
%
% Runs 5 downsized frames from the living room collection.
%

plcDscx             % descriptor extraction

%% -----   (Whole) Image   -----
plcMtcImg           % vector matching
plcMtcHstKol     	% histogram and kolumn matching
plcMtcTxtIdv        % texture using executable mtxt1

plcCollTxtg         % collect texturegrams using executable collsalc
plcMtcTxtColl       % texture using executable mtxtc

plcDtop             % extract top descriptions
plcDtopMtch         % match top descriptions

plcCascIdf          % cascade identifier

plcCorrSelf         % self-correlating all frames

plcDproc            % dtop again, binning using dbin
plcVecToVmx         % vectors to matrix

% plcTransFormer    does not exist, only as python script

%% -----   Focii using Zones   -----
plcFocZon           % uses focdsc1 and fochst1
plcMtcZon1o1        % uses mvec1 and improvised hist-distances
plcMtcZonLst        % uses mvecL, mhstL

% potential improvement (not deployed yet)
% plcFocZonHst.m    % I dont have a binary that exploits a pack of histograms.m
% plcMtcZonHst.m


%% -----   Focii using Proposals   -----
% ( note that this will overwrite some of the files generated above.
%   Running zones above again, will work only if you clear the files. )
%
plcFocProp          % uses focdsc1 and fochst1
plcMtcProp          % uses mvec1


%% -----   ShapeExtraction using ShapeProposals   -----
plcShpExtr          % uses shpx
plcMtcShp           % uses mshp1


%% -----   EgoMotionFlow   -----
plcMotEgo           % uses motvec1


%% -----   Quants with Radix  -----
plcQntVoc
plcVocApply         % rather for testing
plcQntBook          % collects vocabularies to a book
plcBookApply        % applies a book

%% -----   Quants with Hashing  -----
plcCollVecBin
plcQntHist

fprintf('Quants completed\n');


fprintf('Demo Place Recognition completed\n');


