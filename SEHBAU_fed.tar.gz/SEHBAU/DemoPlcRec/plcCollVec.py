"""

Collecting vector matrices. Assumes the description files are already present,
ie. see plcAll.py for sequence.

"""
import sys, subprocess
from pathlib import Path
sys.path.insert(0, '..')
import numpy as np

import AdminPy as sb

dscTyp      = 'skl'

# -----  paths  -----
pthOpr      = Path.cwd()
DirNames    = sb.Orga.o_DirNames()
Pths        = sb.Orga.o_DirsPrependPath( DirNames, pthOpr )

IxImg       = [0, 1, 2, 3, 6] # only for generating register file

# -----  register  -----
Fixt, Dmy   = sb.Orga.o_FileExtensions()   
RgstFinas   = sb.Mtch.o_RegistFileNames();
RgstFipas   = sb.Orga.o_DirsPrependPath( RgstFinas, Pths.rgst )

dmy         = sb.Mtch.o_RegistSetSave( RgstFipas, Pths.desc, "", IxImg, Fixt, 7) 

sb.Mtch.v_RegistValid( RgstFipas.dsc )

FixtColl    = sb.Orga.o_FileExtensColl();
FinaColl    = sb.Orga.o_FileNameColl( Pths.coll, FixtColl )

# ------------------------------   Collect   ------------------------------
cmnd        = [ sb.FipaExe['collvec'], RgstFipas.dsc, dscTyp, str(Pths.coll)+'/' ]

Res         = subprocess.run( cmnd, shell=True, capture_output=True, text=True )
OutColl     = Res.stdout + Res.stderr

# ------------------------------   Load   ------------------------------
from AdminPy import Collection as cl
COLLVEC, ntDsc, nDim = cl.LoadColl.LoadCollVec(    Pths.coll, dscTyp )
CollLab, ntDsc2      = cl.LoadColl.LoadCollVecLab( Pths.coll, dscTyp )

# NOTE: the image labels (numbers) in CollLab[:,1] correspond to the loop counter of
# program 'collvec' (starting with 0) and NOT to the indices as provided above with
# array 'IxImg'

# ------------------------------   Stats   ------------------------------
mxnDsc, MxnDsc  = cl.LoadColl.u_CollDscCount( CollLab )
print( f"mxnDsc  {mxnDsc}" )
print( MxnDsc ) 

# ------------------------------   Plotting   ------------------------------
import matplotlib.pyplot as plt

plt.imshow(COLLVEC, aspect="auto", cmap="viridis")

plt.colorbar()

plt.xlabel("Attributes")
plt.ylabel("Desc")
plt.title( dscTyp )

plt.show(block=False)

