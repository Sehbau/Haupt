%
% Example for executable 'dbin'
%
% Two steps:
% 1) run executable 'dscx' with options --saveRRE and --saveCVP
% 2) run executable 'dbin' with a parameter file from directory 'Params'
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'DescUtil'

%% -------    Dscx 1 Image   ----------
strImg      = 'room.png';

fipaImg     = ['Imgs/' strImg];             % image path
fstmOut 	= ['Desc/' strImg(1:end-4)];    % output file path

ArgsDscx        = o_CmndArgs( 'dscx' );
ArgsDscx.opt    = ' --saveRRE --saveCVP';

[OutDscx]   = RennDscx( fipaImg, fstmOut, ArgsDscx, PthProg.descExtr );

%% -------   Dbin   -------
%fpPrm       = '';
%fpPrm       = 'Params/PrmDbin_Example.txt';
%%fpPrm      = 'Params/PrmDbin_Crude.txt'; 
fpPrm      = 'Params/PrmDbin_Refnd.txt'; 
%fpPrm      = 'Params/PrmDbin_Cabinet.txt'; 

fstmOut     = u_PathToBackSlash( fstmOut ); % change to window backslash

Fixt        = o_FileExtensions();

%% ---------   Dbin   ----------- 
fipaDsc         = [ fstmOut Fixt.dsc];
ArgsDbin        = o_CmndArgs( 'dbin' );
ArgsDbin.fpPrm  = fpPrm; 
ArgsDbin.opt    = '--all';

cd( PthProg.descUtil );
[OutDbin]   = RennDbin( fipaDsc, fstmOut, ArgsDbin );

%% -------   Load Output   -------
fpDSC           = o_FinaApndExtDscx( fstmOut, Fixt );

[DSC Kt Hed]    = LoadDescUniv( fpDSC.dsc ); DispLoad(fpDSC.dsc);
[DBN Kt]        = LoadDbinUniv( fpDSC.dsbi );   

[HSTI HedHst]   = LoadDescHist( fpDSC.hsti ); DispLoad( fpDSC.hsti );

[HCLW HedClw]   = LoadDescHistClw( fpDSC.hsspa ); DispLoad( fpDSC.hsspa );
[HFLT HedFlt]   = LoadDescHistFlt( fpDSC.hsflt ); DispLoad( fpDSC.hsflt );

Irgb            = imread( fipaImg ); 

%% --------   Concatenate Cells   -------------
Nbin            = HCLW.Nbin;

HMXTOT          = u_HistCatClw( HCLW ); % [nCells ntBin]

%% ------------   Plot Overview   ------------------
figure(1); clf;

subplot(2,2,1);
imagesc(Irgb);

subplot(2,2,2);
imagesc(HCLW.Ncnt);
title('Contour Numerosity');

subplot(2,1,2);
imagesc(HMXTOT); 
ylabel( 'Cells' );
xlabel( 'Bins' );
title('All Desctypes Concatenated');

%% ------------   Plot Num Maps   ------------------
figNo       = 2;

% assign the numerosity maps to a separate struct
MNum.Cnt    = HCLW.Ncnt;
MNum.Frm    = HCLW.Nfrm;
MNum.Str    = HCLW.Nstr;
MNum.Arc    = HCLW.Narc;
MNum.Shp    = HCLW.Nshp;

PlotHspaUNIVMaps( MNum, figNo, 'Mnum' );

%% --------   Concatenate Cells Per DescType   ----------
HMXCLW  = i0_HistClwUniv( Nbin, HCLW.nCells );

% allocate the arrays: [nCells nBinDty]
CNT     = i0_HistClwDty1( HCLW.nCells, Nbin.Cnt );
FRM     = i0_HistClwDty1( HCLW.nCells, Nbin.Frm );
ARC     = i0_HistClwDty1( HCLW.nCells, Nbin.Arc );
STR     = i0_HistClwDty1( HCLW.nCells, Nbin.Str );
SHP     = i0_HistClwDty1( HCLW.nCells, Nbin.Shp );

for c = 1:HCLW.nCells
    
    CNT.UNI(c,:) = HCLW.ACNT{c}.Uni;
    CNT.BIV(c,:) = HCLW.ACNT{c}.Biv;

    FRM.UNI(c,:) = HCLW.AFRM{c}.Uni;
    FRM.BIV(c,:) = HCLW.AFRM{c}.Biv;

    ARC.UNI(c,:) = HCLW.AARC{c}.Uni;
    ARC.BIV(c,:) = HCLW.AARC{c}.Biv;

    STR.UNI(c,:) = HCLW.ASTR{c}.Uni;
    STR.BIV(c,:) = HCLW.ASTR{c}.Biv;

    SHP.UNI(c,:) = HCLW.ASHP{c}.Uni;
    SHP.BIV(c,:) = HCLW.ASHP{c}.Biv;
    
end

%% -------  Plot Individual DescTypes  -------
figure(3); clf;
[nr,nc]=deal(5,2);

subplot(nr,nc,1);
imagesc( CNT.UNI );
title('Univariate');
ylabel('Cnt','fontweight','bold');

subplot(nr,nc,2);
imagesc( CNT.BIV );
title('Bivariate');
ylabel('nCells','fontweight','bold');

subplot(nr,nc,3);
imagesc( FRM.UNI );
ylabel('Frm','fontweight','bold');

subplot(nr,nc,4);
imagesc( FRM.BIV );

subplot(nr,nc,5);
imagesc( ARC.UNI );
ylabel('Arc','fontweight','bold');

subplot(nr,nc,6);
imagesc( ARC.BIV );

subplot(nr,nc,7);
imagesc( STR.UNI );
ylabel('Str','fontweight','bold');

subplot(nr,nc,8);
imagesc( STR.BIV );

subplot(nr,nc,9);
imagesc( SHP.UNI );
ylabel('Shp','fontweight','bold');



fprintf('done\n');






