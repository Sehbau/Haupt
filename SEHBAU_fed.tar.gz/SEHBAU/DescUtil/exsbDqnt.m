%
% Example for generating quant values and indices. 
%
% Assumes that vbnDsc file has already been generated.
%
% To be run from directory 'DescUtil'.
%
clear; 
run('../AdminMb/globalsSB');

FixtVec     = o_FileExtensVect();

%% ----------------   Collecting Mode   ----------------
cmnd = 'dqnt ../DescExtr/Vect/img1.vbnCnt Desc\tst Vocab/PrmDqnt_Cnt_Geo.txt';

[StsC OutC] = system( cmnd );

Qcd     = LoadQuantArr( 'Desc\tst.qcdCnt' ); % radix-based code

% Qcd is collected for a list of images and the unique set is formed
% thereof, ie. ICL_VOCCREAT.m. The unique set is saved and used as
% vocabulary in dictionary mode, see next step.

%% ----------------   Dictionary Mode   ----------------
% Vocabulary file 'VocSeg_Cnt_Geo.txt' has already been created before, ie.
% using ICL_VOCCREAT.m. Now we apply it, creating a 'dix' file and a 'qst'
% file.
cmnd = 'dqnt ../DescExtr/Vect/img1.vbnCnt Desc\tst Vocab/PrmDqnt_Cnt_Geo.txt Vocab/VocSeg_Cnt_Geo.txt';

[StsA OutA] = system( cmnd );

% dix file: contains the indices pointing into the dictionary (to the
% quants in VocSeg_Cnt_Geo.txt)
Dix         = LoadQuantArr( 'Desc\tst.dixCnt' ); 

% qst file: a histogram of those quant indices: also called quistogram.
[Qst nHbin] = LoadArrIntTxt( 'Desc\tst.qstCnt' );

%% --- Plot
figure(1); clf;
bar( Qst );
xlabel('Quant Index');
ylabel('Count')
title('Quistogram');









