@echo off
REM
REM Two-phase: dxtr, dbin
REM

REM -----  jpegs
set IMG=img1
REM set IMG=build2
REM set IMG=street
REM set IMG=firework
REM set IMG=buildtall
set EXT=.jpg

REM -----  pngs
REM set IMG=aachen
REM set IMG=room
REM set EXT=.png

echo ------------------------------   dscx   ------------------------------
..\DescExtr\dscx ..\DescExtr\Imgs\%IMG%%EXT% ..\DescExtr\Desc\%IMG% --sfs || ( echo !!!!! dscx failed & exit /b )

echo ------------------------------   dbin   ------------------------------
dbin ..\DescExtr\Desc\%IMG%.dsc Desc\%IMG% Params\PrmDbin_Crude.txt || ( call :PrintFailure dbin & exit /b )

REM not that this call of 'dbin' will overwrite the files of the previous call 
dbin ..\DescExtr\Desc\%IMG%.dsc Desc\%IMG% Params\PrmDbin_Refnd.txt || ( call :PrintFailure dbin & exit /b )

echo Bins completed.

exit /b


REM FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   PrintFailure   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
:PrintFailure
echo !!!!! Program %~1 failed
exit /b
