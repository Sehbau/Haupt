%
% Example for reading from map at keypoints.
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'DescUtil'

%% -------    Dscx 1 Image   ----------
strImg      = 'room.png';

fipaImg     = ['Imgs/' strImg];             % image path
fstmOut 	= ['Desc/' strImg(1:end-4)];    % output file path

Args        = o_CmndArgs( 'dscx' );
Args.opt    = '--saveKeyp';

[OutDscx]   = RennDscx( fipaImg, fstmOut, Args, PthProg.descExtr );

%% -------    Load Map   --------
% we load a depth (range) map
fipaMap     = 'Imgs/room_dth.mpf';
[Mtif szM]  = LoadMapFlt( fipaMap );

StsMp       = f_ArrStat( Mtif(:) );

%% -------    Load & Plot KeyPoints   ---------
Fixt        = o_FileExtensions();
kypf        = [fstmOut Fixt.kyp];

[KYP Kt HedKyp]    = LoadDescKeyp( kypf );

if 0
    fprintf('Plotting keypoints...Geduld...\n');
    PlotDescSpcKeyPts( Mtif, HedKyp.space, KYP.ACNT, 1, 'Contours' );
    PlotDescSpcKeyPts( Mtif, HedKyp.space, KYP.AARC, 2, 'Arcs' );
    PlotDescSpcKeyPts( Mtif, HedKyp.space, KYP.ASTR, 3, 'Straighters' );

    PlotFormSpcKeyPts( Mtif, HedKyp.space, KYP.AFRM, 4, 'Form' );
end

%% ----------------    ReadAtDpt   --------------------
cmnd    = [ FipaExe.ratkpt ' ' kypf ' ' fipaMap ' ' fstmOut ];

if ispc
    [Sts Out] = dos(cmnd);      % excecute program for windows
elseif isunix
    [Sts Out] = unix(cmnd);     % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 );

%% ------------    Load   -----------
vkypf   = [fstmOut Fixt.vkyp];

VLS     = LoadDkypVals( vkypf );

%% -----------   Generel Demo   -----------
% one figure showing 
figDemo = 1;
figure(figDemo); clf;
[nr,nc] = deal(2,2);

Irgb    = imread( fipaImg );

subplot(nr,nc,1);
imagesc(Irgb);

subplot(nr,nc,2);
imagesc(Mtif);
title('Map (Depth/Range)');

subplot(nr,nc,3);
imagesc( zeros( szM ) ); hold on;
p_DkypVls( KYP.ACNT{1}, VLS.ASKL{1}, StsMp, 'btw_is_mip' );
title('Contours (Skel)');

subplot(nr,nc,4);
imagesc( zeros( szM ) ); hold on;
FRM     = KYP.AFRM{1};
nRoct   = length(FRM.Bole);
p_RoctVls( FRM, 1:nRoct, VLS.AFRM{1}, StsMp );
title('Form');

%% -------------   Plot All   ------------
fprintf('Plotting with values...Geduld...\n');
PlotDkypVlsSpc( HedKyp.space, szM, StsMp, KYP.ACNT, VLS.ASKL, 5, 'Contours');
PlotDkypVlsSpc( HedKyp.space, szM, StsMp, KYP.AARC, VLS.AARC, 6, 'Arcs');
PlotDkypVlsSpc( HedKyp.space, szM, StsMp, KYP.ASTR, VLS.ASTR, 7, 'Straighters');

PlotFormSpcKypVls( HedKyp.space, szM, StsMp, KYP.AFRM, VLS.AFRM, 8, 'Forms');

%% ------------   3D Plot  -------------
% my attempt
Coo     = KYP.ACNT{1};
Vls     = VLS.ASKL{1};
%fct     = 20;
P.Ep1     = [ Coo.Ep1 5-Vls.Ep1 ];
P.Ep2     = [ Coo.Ep2 5-Vls.Ep2 ];
P.Btw     = [ Coo.Btw 5-Vls.Btw ];

figure(9); clf; hold on;
col = [ 0.5 0.5 0.5 ];
for i = 1:Coo.nPts
    Ep1 = P.Ep1(i,:);
    Ep2 = P.Ep2(i,:);
    Mip = P.Btw(i,:);
    
    X   = [Ep1(1) Mip(1) Ep2(1) ];
    Y   = [Ep1(2) Mip(2) Ep2(2) ];
    Z   = [Ep1(3) Mip(3) Ep2(3) ];
    
    hp  = plot3( Y, X, Z );
    set( hp, 'color', col );
    %line([ Ep1(2)  Mip(2) ],  [ Ep1(1)  Mip(1) ], [ Ep1(3)  Mip(3) ], 'color', col);
    %line([ Mip(2)  Ep2(2) ],  [ Mip(1)  Ep2(1) ], [ Mip(3)  Ep2(3) ], 'color', col);
    %line([ Ep1(2)  Mip(2) ],  [ Ep1(1)  Mip(1) ], [ Ep1(3)  Mip(3) ], 'color', col);
    %line([ Mip(2)  Ep2(2) ],  [ Mip(1)  Ep2(1) ], [ Mip(3)  Ep2(3) ], 'color', col);
end
axis ij;

%% -----------------   Print Figure   -----------------------
if bPRINTFIGS
    PrintFig2File( [dirFigs 'ReadAtDpt'], 1, 1, figDemo );
end






