@echo off
REM
REM Runs the executable 'readatkpt' for one image.
REM

set IMG=room
set EXT=.png

echo ------------------------------   dscx   ------------------------------
..\DescExtr\dscx Imgs\%IMG%%EXT% Desc\%IMG% --saveKeyp || ( echo !!!!! dscx failed & exit /b )


echo ------------------------------   readatkpt   ------------------------------
readatkpt Desc\%IMG%.kyp Imgs\%IMG%_dth.mpf Desc\%IMG% || ( echo !!!!! readatkpt failed & exit /b )
   REM ..\..\SEHBAU\DescExtr\h2arr Desc\%IMG%.hst Desc\%IMG% --bDISP 3
)
