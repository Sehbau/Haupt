%
% Example for applying 'h2arr' to histograms as outputted by dbin.
%
% Must succeed example script exsbDbin.m
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'DescUtil'

strImg      = 'room.png';

fstmOut 	= ['Desc/' strImg(1:end-4)];    % output file path

fstmOut     = u_PathToBackSlash( fstmOut ); % change to window backslash

Fixt        = o_FileExtensions();

%% -------   Load Output   -------
% as produced by previous script exsbDbin.m
fpDSC           = o_FinaApndExtDscx( fstmOut, Fixt );

[HCLW HedClw]   = LoadDescHistClw( fpDSC.hsspa ); DispLoad( fpDSC.hsspa );
[HFLT HedFlt]   = LoadDescHistFlt( fpDSC.hsflt ); DispLoad( fpDSC.hsflt );

%% --------   Concatenate Cells   -------------
Nbin            = HCLW.Nbin;

HMXTOT          = u_HistCatClw( HCLW ); 
[nCells nBinPerCell]  = size( HMXTOT );
ntBinSpa        = nCells * nBinPerCell;

HMXTOT          = HMXTOT';
HspaLin         = int32( HMXTOT(:) );

%% ---------   Run 'h2arr'   ------------

cmndFlt  = '../DescExtr/h2arr Desc/room.hsflt Desc/room';

cmndFlt  = u_PathToBackSlash( cmndFlt ); % change to window backslash

system( cmndFlt );

cmndSpa  = '../DescExtr/h2arr Desc/room.hsspa Desc/room';

cmndSpa  = u_PathToBackSlash( cmndSpa ); % change to window backslash

system( cmndSpa );

%% --------    Load   ---------
fpOut       = 'Desc/room';
Fixt        = o_FileExtensions();
lfpFlt      = [fpOut Fixt.harflt];
lfpSpa      = [fpOut Fixt.harspa];

Hflt            = LoadHistImgArr( lfpFlt );
[HSPA DimSpa]   = LoadHistSpatArr( lfpSpa );
DispLoad( lfpFlt );

ntBinsFlt   = length(Hflt);
ntBinsSpa   = prod( DimSpa ); % length(Hspa);
fprintf('ntBinsFlat %5d\n', ntBinsFlt );
fprintf('ntBinsSpat %5d\n', ntBinsSpa );

%% ----------   Verify   ---------
% dbin vs h2arr
assert( ntBinSpa==ntBinsSpa );
Df          =   HspaLin - HSPA(:);
assert( all( Df == 0 ) );

%% -------   Plot   -------
figure(1); clf;
subplot(2,1,1);
bar( Hflt );
title( [ 'ntBinsFlat ' num2str(ntBinsFlt) ] );

subplot(2,1,2);
imagesc(HSPA);
title( 'Spatial Histograms (Matrix)' );
ylabel('Cell');
xlabel('BinsPerCell');


