%
% Example for executable 'fabric' and 'fbrc2arr'
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'DescUtil'

%% -------   image file and parameters   --------
dirImg      = 'Imgs/';
strImg      = 'room.png';

fpPrm       = 'Params/PrmDbin_Cabinet.txt'; % coarser
%fpPrm      = 'Params/PrmDbin_Fabric.txt'; % finer

fipaImg     = [dirImg  strImg];      	% image path
fistImg     = strImg(1:end-4);
fstmOut 	= ['Desc/' fistImg];        % output file path

fstmOut     = u_PathToBackSlash( fstmOut ); % change to window backslash
Fixt        = o_FileExtensions();

%% --------   Dscx   --------
ArgsDscx        = o_CmndArgs( 'dscx' );
ArgsDscx.opt    = ' --saveRRE --saveCVP  --saveTxm';
v_CmndArgs( ArgsDscx );

[OutDscx]   = RennDscx( fipaImg, fstmOut, ArgsDscx, PthProg.descExtr );
% OutDscx

%% ---------   Dbin   ----------- 
fipaDsc         = [ fstmOut Fixt.dsc];

ArgsDbin        = o_CmndArgs( 'dbin' );
ArgsDbin.fpPrm  = fpPrm; 
ArgsDbin.opt    = '--all';

[OutDbin]   = RennDbin( fipaDsc, fstmOut, ArgsDbin ); 
% OutDbin

%% ---------   Fabric   ----------- 
fipaCbnt    = [fstmOut Fixt.hsspa];
ArgsFbrc    = o_CmndArgs( 'fabric' );
fpDSC       = o_FinaApndExtDscx( fstmOut, Fixt );

pthFbrc     = PthProg.descUtil; 

[OutFbrc]   = RennFbrc(    fipaCbnt,   fstmOut, ArgsFbrc, pthFbrc );
[OutFbAr]   = RennFbrc2Ar( fpDSC.fbrc, fstmOut, [],       pthFbrc );

%% -----------------------------------------------------------------------
%                            LOAD 
%
[FBRC HedFbrc]  = LoadFabric( fpDSC.fbrc );   DispLoad( fpDSC.fbrc );

% adjust some of the bin numbers
[NbinAtt NbinSum] = i_HistBinNumAdjAtt( HedFbrc.NbinAtt );

% now load as arrays as saved with 'fbrc2arr' (RennFbrc2Ar)
% we use LoadCollHist (because it was saved in that format)
fprintf('Loading kolumns...\n');
HYK0       = LoadCollHist( fpDSC.fbArK0 );
HYK1       = LoadCollHist( fpDSC.fbArK1 );
HYK2       = LoadCollHist( fpDSC.fbArK2 );
HYK3       = LoadCollHist( fpDSC.fbArK3 );

fprintf('Loading bias maps...\n');
[MP0 Hed0 MP0v1]  = LoadFabricMapAsArr( fpDSC.fbArM0 ); DispLoad( fpDSC.fbArM0 );
[MP1 Hed1 MP1v1]  = LoadFabricMapAsArr( fpDSC.fbArM1 ); 
[MP2 Hed2 MP2v1]  = LoadFabricMapAsArr( fpDSC.fbArM2 ); 
[MP3 Hed3 MP3v1]  = LoadFabricMapAsArr( fpDSC.fbArM3 ); 
 
% load the count (num) maps
NUM0        = LoadCollHist( fpDSC.fbArN0 );
NUM1        = LoadCollHist( fpDSC.fbArN1 );
NUM2        = LoadCollHist( fpDSC.fbArN2 );
NUM3        = LoadCollHist( fpDSC.fbArN3 );

%% -----------  verify Maps  -------------
% We compare output of executable fabric with output of fbrc2arr and use
% vertical map of contour and form

% contour
LinV1   = MP1v1(:);
LvrtCV1 = LinV1(1:Hed1.nRix);
LvrtC   = MP1(:,1);
MvrtC   = FBRC.MP1.Cnt.Vrt';
DfCv1   = MvrtC(:) - LvrtCV1;
DfC     = MvrtC(:) - LvrtC;
assert(any(DfCv1)==0)
assert(any(DfC)==0)

% form
LvrtF   = MP1(:,6); %LinV1( (1:Hed1.nRix ) + Hed1.nRix*5 );
MvrtF   = FBRC.MP1.Frm.Vrt';
DfF     = MvrtF(:) - LvrtF;
assert(any(DfF)==0)

MNcnt   = reshape(NUM3(:,1),3,3);
DfN     = MNcnt-single(FBRC.K3.Ncnt');
assert(any(DfN(:))==0)

%% -----------  NumBins  -------------
PerTyp  = HedFbrc.NbinDty.PerTyp;
Nflt    = [ PerTyp.Nuni; PerTyp.Nbiv];
ntBin   = sum(Nflt(:));

% -----  verify:
assert(HedFbrc.NbinDty.nBinPerCell==ntBin,'total num of bins incorrect');

%% -----------------------------------------------------------------------
%                            PLOT 
fprintf('Plotting the different layers...\n');
figBase	= 1;
Irgb  	= imread( fipaImg ); 
hf0     = PlotFbrcMaps( FBRC.MP0, FBRC.K0, figBase,   Irgb );
hf1     = PlotFbrcMaps( FBRC.MP1, FBRC.K1, figBase+1, Irgb );
hf2     = PlotFbrcMaps( FBRC.MP2, FBRC.K2, figBase+2, Irgb );
hf3     = PlotFbrcMaps( FBRC.MP3, FBRC.K3, figBase+3, Irgb );
set(gcf,'name', 'Layer 3');

%% --- for comparison
fprintf('Plotting the texture maps for comparison...\n');
TXM             = LoadTxtrMaps( fpDSC.txm );
figTxtrMaps 	= 5;
PlotTxtrMaps( TXM, figTxtrMaps, Irgb );
set(gcf,'name', 'Texture Maps');
fprintf('done\n');

%% ----------   Kolumns   ---------------
figure(6); clf; [nr,nc]=deal(4,1);
subplot(nr,nc,1); imagesc( HYK0 ); colorbar(); ylabel('Lay 0'); title('Hykos');
subplot(nr,nc,2); imagesc( HYK1 ); colorbar(); ylabel('Lay 1');
subplot(nr,nc,3); imagesc( HYK2 ); colorbar(); ylabel('Lay 2');
subplot(nr,nc,4); imagesc( HYK3 ); colorbar(); ylabel('Lay 3');
%% ----------   NumMaps   ---------------
figNum = 7;
PlotFbrcMapNum( NUM0, NUM1, NUM2, NUM3, figNum, Irgb );

%%
figure(8); clf;
Sm  = sum( HYK0, 1);

plot( Sm, 'k' ); hold on;

Xatt    = single(cumsum( NbinSum.Arr ));
Xdty    = single(cumsum( PerTyp.Nt' ));
Xflt    = single(cumsum( Nflt(:) ));

mxAtt  = max(Sm)*1.1;
mxDty  = max(Sm)*1.4;
mxFlt  = max(Sm)*1.2;
plot([Xatt Xatt],[0 mxAtt+0.3],'g');
plot([Xdty Xdty],[0 mxDty+0.5],'r');
plot([Xflt Xflt],[0 mxFlt+0.7],'m');





