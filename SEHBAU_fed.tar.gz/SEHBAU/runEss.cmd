@echo off
REM --------------------------------------------------------------------------------
REM 
REM Essential functionality.
REM 
REM We run programs dscx, mvec1, h2arr, d2vmx, dbn2vmx, mtxt1, cntpat, topx
REM
REM --------------------------------------------------------------------------------

echo ------------------------------------------------------------
echo		Descriptor Extraction fuer images 1 and 2 
echo ------------------------------------------------------------

cd DescExtr

dscx Imgs\img1.jpg Desc\img1 || ( echo dscx failed! & exit /b )
dscx Imgs\img2.jpg Desc\img2 || ( echo dscx failed! & exit /b )

cd ..

echo ------------------------------------------------------------
echo		Matching the two Images (Vectorially)
echo ------------------------------------------------------------

REM we change to matching directory, because we require directory 'Mes'
cd MtchVec

mvec1 ..\DescExtr\Desc\img1.dsc ..\DescExtr\Desc\img2.dsc

cd ..


echo ------------------------------------------------------------
echo		Converting Output
echo ------------------------------------------------------------

cd DescExtr

echo ---	Histogram to Array
REM we turn the histogram file into a single array 
h2arr Desc\img1.hst Desc\img1 || ( echo h2arr failed! & exit /b )

echo ---	Attributes to Vector-Matrix
REM we generate vector matrices
d2vmx Desc\img1.dsc Desc\img1 || ( echo d2vmx failed! & exit /b )

echo --- 	Binned attributes to Bin-Vectors (Matrix)
REM we generate bin-vector matrices from dsb file
dbn2vmx Desc\img1.dsb Desc\img1 || ( echo dbn2vmx failed! & exit /b )

cd ..

echo ------------------------------------------------------------
echo		Matching the two Images (Texture)
echo ------------------------------------------------------------
cd MtchTxt

mtxt1 ..\DescExtr\Desc\img1.slc ..\DescExtr\Desc\img2.slc  || ( echo mtxt1 failed! & exit /b )

cd ..

echo ------------------------------------------------------------
echo		DescUtil (cntpat, topx)
echo ------------------------------------------------------------

echo we first run with saving option 'saveRRE'
cd DescExtr
   dscx Imgs\img1.jpg Desc\img1 --saveRRE || ( echo dscx failed! & exit /b )
cd ..

cd DescUtil

echo now we apply cntpat:
echo ---	cntpat
cntpat ..\DescExtr\Desc\img1.rre Desc\img1 || ( echo cntpat failed! & exit /b )

echo ---	topx
topx ..\DescExtr\Desc\img1.dsc Desc\img1 || ( echo topx failed! & exit /b )

cd ..

echo Soweit so gut.




