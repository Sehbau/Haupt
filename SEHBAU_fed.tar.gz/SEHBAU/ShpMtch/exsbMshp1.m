%
% Example for running shape matching.
%
clear;

[sts, Out] = system('mshp1 ../ShpExtr/Desc/p48.shp ../ShpExtr/Desc/p49.shp');

assert( sts== 0);
Out

[Mes Rts Spk]  = pso_Mshp1( Out );

% ensemble:  arc * str * rsg 
ens     = Mes(1) * Mes(2) * Mes(3);




