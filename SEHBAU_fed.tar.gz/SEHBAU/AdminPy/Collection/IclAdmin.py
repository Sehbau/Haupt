"""

Administrative info of image collections (image databases).

def u_CollPaths(dbas: int) -> tuple[ dclsCollPaths, dclsCollInfo ]:

"""
from __future__ import annotations # 3.12
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np
from typing import List, Optional, Any

from AdminPy.Util.FileIO.LoadData import *


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class dclsCollDirNames:
    """ Struct holding directory names for an image collection.
    in Mb: o_DirNamesImgColl.m

    For demos we use dclsDirNames in OrgFileNames.py
    """
    imgs    : str = 'IMGdown/'  # location of images. to be set by user.
    
    dsci    : str = 'DSCimg/'
    dtop    : str = 'DSCtop/'
    vect    : str = 'VECimg/'
    coll    : str = 'DSCcoll/'  # collected hists/txtr/vects
    descNN  : str = 'DSCnn/'
    fold    : str = 'Fold/'
    
    regist  : str = 'Regist/'
    params  : str = 'Params/'
    mesMtch : str = 'MesMtch/'


@dataclass
class dclsCollPaths:
    """ Struct holding paths for an image collection.
    in Mb: u_CollPaths.m
    """
    imgs:     Path = Path()  # images
    dscDir:   Path = Path()  # OUTPUT files

    dsci:     Path = Path()
    dtop:     Path = Path()
    dbin:     Path = Path()
    veci:     Path = Path()

    coll:     Path = Path()  # collected description - concatenated across files
    fold:     Path = Path()  
    hist:     Path = Path()
    descNN:   Path = Path()
    regist:   Path = Path()
    mesMtch:  Path = Path()


@dataclass
class dclsCollInfo:
    
    aFinas: List[str] = field(default_factory=list)
    nCat:     Optional[int] = None
    name:     str = ''
    nFinas:   Optional[int] = None
    nImg:     Optional[int] = None
    ftxFinas: Optional[Path] = None
    LabImg:   Optional[np.ndarray] = None
    aCatLab:  Optional[List[str]] = None
    szI:      Optional[tuple] = None
    IxImgLrn: Optional[np.ndarray] = None
    IxImgTst: Optional[np.ndarray] = None
    nImgLrn:  Optional[int] = None
    nImgTst:  Optional[int] = None
    LbLrn:    Optional[np.ndarray] = None
    LbTst:    Optional[np.ndarray] = None
    Pth:      Optional[Any] = None  # could be another dataclass



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollPaths   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Collections. For place recognition see u_CollPlcRec

"""
def u_CollPaths(dbas: int) -> tuple[ dclsCollPaths, dclsCollInfo ]:

    J    = dclsCollInfo()
    P    = dclsCollPaths()
    name = ''

    # ---------------- Database selection ----------------
    if dbas == 7:
        stem, nCat, name = 'OLTO', 8, 'UrbNat'
    elif dbas == 10:
        stem, nCat, name = 'IndOut15', 15, 'IndOut15'
    elif dbas == 31:
        stem, nCat, name = 'DOCU/Ch_lower', 24, 'LetLow'
    elif dbas == 37:
        stem, nCat, name = 'VOC', 20, 'VOC'
    elif dbas == 50:
        stem, nCat, name = 'Indoor', 67, 'Indoor67'
    elif dbas == 52:
        stem, nCat = 'PLR_NYU2', np.nan
    elif dbas == 60:
        stem, nCat, name = Path(r'CAMSDD/training'), 30, 'Cam30'
    elif dbas == 61:
        stem, nCat = Path(r'CAMSDD/validation'), 30
    elif dbas == 62:
        stem, nCat, name = Path(r'CAMSDD/test'), 30, 'Cam30Test'
    elif dbas == 17:
        stem, nCat, name = 'SINR45', 45, 'SINR45'
    elif dbas == 100:
        stem, nCat, name = 'CIFAR10', 10, 'Cif10'
    elif dbas == 200:
        stem, nCat = 'cityscapes', np.nan
    else:
        raise ValueError(f"Database {dbas} not specified")

    J.nCat = nCat
    J.name = name

    # ---------------- Paths setup ----------------
    DRV = Path("G:/")
    # use dataclass with directorynames above for creating full path:
    P.imgs    = DRV / "IMGdown" / stem
    P.dscDir  = DRV / "IMGdat" / stem

    # consider using structure above:
    P.dsci    = P.dscDir / "DSCimg"
    P.dtop    = P.dscDir / 'DSCtop'       # top files
    P.dbin    = P.dscDir / 'DSCbin'       # bin files
    P.veci    = P.dscDir / 'VECimg'      # vector files

    P.coll    = P.dscDir / "DSCcoll"
    P.fold    = P.dscDir / "Folds"
    P.hist    = P.dscDir / "LHST"
    P.descNN  = P.dscDir / "DSCnn"
    P.regist  = P.dscDir / "Regist"
    P.mesMtch = P.dscDir / "MesMtch"

    # --- Special cases ---
    if dbas == 10:
        P.imgs = P.imgs / "SameSize"
    elif dbas == 50:
        P.imgs = P.imgs / "Images"
    elif dbas == 200:
        P.imgs = DRV / "IMGdown" / "cityscapes_data" / "leftImg8bit" / "train" / "aachen"

    # ---------------- Load filenames ----------------
    ftxFinas = P.dscDir / "ImgFinas.txt"
    if ftxFinas.is_file():
        with ftxFinas.open("r", encoding="utf-8") as f:
            J.aFinas = [line.strip() for line in f if line.strip()]
        J.nFinas = len(J.aFinas)
        J.nImg = J.nFinas
        J.ftxFinas = ftxFinas

    # ---------------- Load image labels ----------------
    ftxImgLab = P.dscDir / "ImgCatLb.txt"
    if ftxImgLab.is_file():
        J.LabImg = np.loadtxt(ftxImgLab, dtype=int)
        if J.aFinas:
            assert len(J.LabImg) == J.nFinas
    elif dbas == 52:
        fileScenes = P.imgs / "Scenes.npy"
        if fileScenes.is_file():
            scenes = np.load(fileScenes, allow_pickle=True)
            J.aFinas = list(scenes)
            J.nFinas = len(J.aFinas)
            np.unique(scenes, return_index=True, return_inverse=True)
            P.imgs = P.imgs / "Images"
    elif dbas == 100:
        from LoadImages import LoadImgCIF10  # custom function
        _, J.LabImg = LoadImgCIF10()
    else:
        print("No file ImgCatLb.txt found")

    # ---------------- Load category labels ----------------
    ftxCatLab = P.dscDir / "CatgNames.txt"
    if ftxCatLab.is_file():
        pass  # Assume external category list loaded
    elif dbas == 7:
        J.aCatLab = ['coast', 'forest', 'highway', 'city',
                     'mountain', 'country', 'street', 'building']
    elif dbas == 100:
        J.aCatLab = ['airplane', 'automobile', 'bird', 'cat', 'deer',
                     'dog', 'frog', 'horse', 'ship', 'truck']
    else:
        print("No file CatgNames.txt found")

    # ---------------- CIFAR10 ----------------
    if dbas == 100 and J.LabImg is not None:
        J.szI = (32, 32)
        J.IxImgLrn = np.arange(1, 50001)
        J.IxImgTst = np.arange(50001, 60001)
        J.nImgLrn = 50000
        J.nImgTst = 10000
        J.LbLrn = J.LabImg[J.IxImgLrn - 1]
        J.LbTst = J.LabImg[J.IxImgTst - 1]

    # ---------------- VOC ----------------
    if dbas == 37:
        from u_Vo7Paths import u_Vo7Paths
        J.Pth = u_Vo7Paths()  # expected to return a similar dataclass
        # VOCinit() placeholder
        J.nFinas = 9963

    return P, J


