"""

Administrative info of image collections (image databases).

def u_CollPaths(dbas: int) -> tuple[ dclsCollPaths, dclsCollInfo ]:

"""
from __future__ import annotations # 3.12
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np
from typing import List, Optional, Any
from types import SimpleNamespace

from AdminPy.Util.FileIO.LoadData import *




# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class dclsCollFoldFina:
    """ Struct holding filenames for indices and labels of ONE fold
    """
    ixTrn:    Path = Path()  
    ixPrd:    Path = Path()  
    lbTrn:    Path = Path()  
    lbPrd:    Path = Path()  


# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CollFoldFina   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Indices and labels for one fold.

"""
def u_CollFoldFina( pth, nFld, fold ):

    F       = dclsCollFoldFina
    
    idf     = f"K{nFld}_F{fold}"

    F.ixTrn = pth / Path( idf + "_IxTrn.txt" )
    F.ixPrd = pth / Path( idf + "_IxPrd.txt" )
    F.lbTrn = pth / Path( idf + "_LbTrn.txt" )
    F.lbPrd = pth / Path( idf + "_LbPrd.txt" )

    return F


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   LoadFoldIx   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Load the Indices and labels for one fold.

"""
def LoadFoldIx( Finas ):

    S = SimpleNamespace(
        IxTrn = LoadArrIntTxt( Finas.ixTrn ),
        IxPrd = LoadArrIntTxt( Finas.ixPrd ),
        LbTrn = LoadArrIntTxt( Finas.lbTrn ),
        LbPrd = LoadArrIntTxt( Finas.lbPrd ),
    )
    S.nPrd  = len( S.LbPrd )

    return S


