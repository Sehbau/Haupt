"""

Processing on collections (or lists) of images.

"""
from .IclAdmin import *
from .IclFold import *
from .IclProc import *
from .LoadColl import *




