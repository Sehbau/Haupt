"""

Texture 


---------------   DEF SUM   ---------------

def ReadYtgDim( file ):
def u_TxtrGstToArrs( T, aBlobLab ):
def LoadTxtrMaps( lfp ):

def LoadCollTxtg( FinaColl ):
def f_CollTxtrStats( C ):

def u_TxtrGramGridArrToMtrx(Arr, szG, nTxtBis, nrm=None):
def u_TxtrGramGridCollReshape( MX, szG, nTxtBis, nrm=None):

def PlotCollTxtrStats(C, figNo=1):

"""
import numpy as np
from dataclasses import dataclass
import matplotlib.pyplot as plt

from AdminPy.Util.FileIO.ReadValues import *

from AdminPy.Util.FileIO.LoadData import *
from AdminPy.Util.Stats.Stats import *
from AdminPy.DescExtr.OrgAtt.OrgAtts import *



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadYtgDim   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Analogous to ReadYtgDim.m

"""
def ReadYtgDim( file ):

    @dataclass
    class S:
        pass
    
    S.szL      = np.fromfile(file, dtype=np.int32, count=2)
    S.szFll    = np.fromfile(file, dtype=np.int32, count=2)

    winSzRaw   = np.fromfile(file, dtype=np.uint8, count=1)[0]
    S.winSiz   = np.int8(winSzRaw)

    S.vrtToCvd = np.fromfile(file, dtype=np.float32, count=1)[0]
    S.horToCvd = np.fromfile(file, dtype=np.float32, count=1)[0]

    if not (4 < S.winSiz < 256):
        raise ValueError(f"window size unreasonable: {S.winSiz}")

    S.szL   = S.szL
    S.nRix  = int(S.szL[0] * S.szL[1])

    return S


    
""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_TxtrGstToArrs   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Texture global stats to array, for the 7 biases.

cf exsbSalBlobs.py

"""
def u_TxtrGstToArrs( T, aBlobLab ):

    #aBlobLab = list(T.__dict__.keys())
    #aBlobLab = aBlobLab[4:11]                   # get rid of __xxx__
    nTyp     = len(aBlobLab)

    @dataclass
    class S:
        PrpPres = np.zeros(nTyp, dtype=np.float32)
        Men     = np.zeros(nTyp, dtype=np.float32)
        Sdv     = np.zeros(nTyp, dtype=np.float32)

    for i, lb in enumerate(aBlobLab):

        fld = getattr( T, lb )

        #print( fld )
        #print(dir(fld.__dataclass_params__))
        #print( dir(fld) )
        
        
        S.Men[i]     = fld.men
        S.Sdv[i]     = fld.sdv
        S.PrpPres[i] = fld.prpPres

    return S



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadTxtrMaps   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads texture maps of ONE file.

RET TXM

"""
def LoadTxtrMaps( lfp ):

    # --------------------   Open File   --------------------
    try:
        file = open(lfp, 'rb')
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not open file {lfp}")
    
    @dataclass
    class KNT:
        pass

    @dataclass
    class CRM:
        pass

    ## ============   Header   =============
    Dim      = ReadYtgDim( file )
    szL      = Dim.szL

    print( szL )
    
    ## ============   Maps Count   =============
    KNT.Num   	= ReadMapGen( file, szL, np.int16 )
    KNT.Blk   	= ReadMapGen( file, szL, np.int16 );
    KNT.DomNum  = ReadMapGen( file, szL, np.int16 );
    KNT.DomEnk	= ReadMapGen( file, szL, np.float32 );
    
    ## ============   Maps Txt & Sal   =============
    # orientation texture (NOT blob biases, see ReadOtxMAPsts)
    aFldOtx     = [ 'Vrt', 'Hor', 'Dg1', 'Dg2', 'Axi', 'Nil', 'Uni' ]
    OTX         = ReadStcMapFlt( file, aFldOtx, szL );

    # saliency maps
    aFldSmp     = [ 'Len', 'Ctr', 'Enk', 'Bgt', 'Drk', 'Cvr' ] 
    SAL         = ReadStcMapFlt( file, aFldSmp, szL );

    # chromatic maps
    aFldSts     = ['Min', 'Max', 'Sum', 'Sdv']
    CRM.Red     = ReadStcMapFlt( file, aFldSts, szL );
    CRM.Grn     = ReadStcMapFlt( file, aFldSts, szL );
    CRM.Blu     = ReadStcMapFlt( file, aFldSts, szL );

    # ----------   Trailer (Idf)   ----------
    idf = np.fromfile( file, dtype=np.int32, count=1)

    # --------------------   Close File   --------------------
    file.close

    if idf != 826:
        raise ValueError("idf incorrect")


    @dataclass
    class TXM:
        pass
    TXM.KNT = KNT
    TXM.OTX = OTX
    TXM.SAL = SAL
    TXM.CRM = CRM
    
    return TXM


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollTxtg   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the collected texturegrams. In analogy to LoadCollTxtg.m

"""
def LoadCollTxtg( FinaColl ):

    @dataclass
    class TXTR:
        pass

    @dataclass
    class Hed:
        pass    
    
    TXTR.GST, Hed.Gs = LoadBankVec( FinaColl.txgs )
    TXTR.GRD, Hed.Gg = LoadBankVec( FinaColl.txgg )
    TXTR.BND, Hed.Gb = LoadBankVec( FinaColl.txgb )

    return TXTR, Hed


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_CollTxtrStats   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

cf plcCollTxtg.py
"""
def f_CollTxtrStats( C ):

    @dataclass
    class S:
        pass

    S.Gst   = f_MtrxColStat( C.GST )
    S.Bnd   = f_MtrxColStat( C.BND )
    S.Grd   = f_MtrxColStat( C.GRD )

    return S


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_TxtrGramGridArrToMtrx   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

cf plcCollTxtg.py
"""
def u_TxtrGramGridArrToMtrx(Arr, szG, nTxtBis, nrm=None):

    Arr = np.asarray(Arr)       # Ensure Arr is a NumPy array for proper indexing
    
    nGu = int(np.prod(szG))     # number of grid units (grid size)

    assert nTxtBis * nGu == len(Arr), 'dimensions not matching somehow'

    Ix1 = np.arange(0, nGu)

    M = np.zeros((nGu, nTxtBis), dtype=np.float32)
    for i in range(0, nTxtBis):
        
        IxL    = Ix1 + i * nGu
        M[:,i] = Arr[IxL]

    # normalization, if 4th argument is specified
    if nrm is not None:
        M[:,0] = M[:,0] / nrm

    return M


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_TxtrGramGridCollReshape   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

cf plcCollTxtg.py
"""
def u_TxtrGramGridCollReshape( MX, szG, nTxtBis, nrm=None):

    MX  = np.asarray(MX)       # ensure Arr is a NumPy array for proper indexing

    nImg, nFet = MX.shape

    NM = np.zeros((nImg, nFet), dtype=np.float32)
    for i in range(0, nImg):

        Mx      = u_TxtrGramGridArrToMtrx( MX[i,:], szG, 7, nrm )
        NM[i,:] = Mx.flatten()

    return NM


""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotCollTxtrStats   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

cf plcCollTxtg.py
"""
def PlotCollTxtrStats(C, figNo=1):

    Lb = o_TxtrLabels()

    fig = plt.figure(figNo)
    plt.clf()

    nr, nc = 3, 1

    # ---- Subplot 1 ----
    ax1 = plt.subplot(nr, nc, 1)
    ax1.bar(np.arange(len(C.Gst.Men)), C.Gst.Men)
    ax1.set_title("Gst")
    ax1.grid(True, axis='y')
    ax1.set_yticks(np.arange(0, 0.9, 0.1))
    ax1.set_ylim([0, 0.85])
    ax1.set_xticks( np.arange(Lb.nLab))
    ax1.set_xticklabels(Lb.aSho)

    # ---- Subplot 2 ----
    ax2 = plt.subplot(nr, nc, 2)
    ax2.bar(np.arange(len(C.Grd.Men)), C.Grd.Men)
    ax2.set_title("Grid")

    # ---- Subplot 3 ----
    ax3 = plt.subplot(nr, nc, 3)
    ax3.bar(np.arange(len(C.Bnd.Men)), C.Bnd.Men)
    ax3.set_title("Band")

    plt.tight_layout()
    plt.show(block=False)
    plt.pause(.01)

