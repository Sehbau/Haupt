"""

Loading histograms as arrays. For images or for collections.

Loading as structure not implemented yet (and perhaps not necessary?).

def LoadHistImgArr(lfn):
def ReadBnumDsc1(fileID):
def ReadBnumSpat(fileID):
def ReadDescBinNum(fileID):
def LoadCollHist(pthFile):

def DispBnumDsc1( N, jStr ):
def DispBnumSpat( N ):

"""
from pathlib import Path
from dataclasses import dataclass
import numpy as np

from AdminPy.Orga import OrgFileNames


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class dimGrid:
    """
    Dimensions of grid. N of vertical times N of horizontal cells (units)
    """
    ver: int
    hor: int

@dataclass
class bnumDsc1:
    """
    Bin numbers: used for loading the collection in LoadCollHist
    """
    uni: int
    biv: int
    tot: int

@dataclass
class bnumSpat:
    """

    """
    nCells:      int
    nBinPerCell: int
    ntBin:       int
    Dim:         dimGrid
    Cnt:         bnumDsc1
    Frm:         bnumDsc1
    Arc:         bnumDsc1
    Str:         bnumDsc1
    Shp:         bnumDsc1

@dataclass
class DescBinNum:
    """
    Bin numbers: used for loading the collection in LoadCollHist (ReadDescBinNum.m)
    """
    Tot: np.ndarray

    FltUni: np.ndarray
    FltBiv: np.ndarray
    SpaUni: np.ndarray
    SpaBiv: np.ndarray

    CntUni: np.ndarray
    RsgUni: np.ndarray
    ArcUni: np.ndarray
    StrUni: np.ndarray

    shpUni: int
    shpBiv: int
    ttrgUni: int
    ttrgBiv: int
    bndgUni: int
    bndgBiv: int



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

def read_int16(fileID) -> int:
    """Reads a single int16 from a binary file and returns a Python int."""
    return np.fromfile(fileID, dtype=np.int16, count=1).item()

def read_int32(fileID) -> int:
    """Reads a single int32 from a binary file and returns a Python int."""
    return np.fromfile(fileID, dtype=np.int32, count=1).item()


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadHistImgArr   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the image histogram array from a text file.
Equivalent to LoadHistImgArr.m
    
RET  np.ndarray: 1D array of integers.

"""
def LoadHistImgArr(lfn):

    try:
        with open(lfn, 'r') as file:
            return np.loadtxt(file, dtype=np.int32)
            #H = []
            #for line in file:
             #   parts = line.strip().split()
              #  for p in parts:
               #     try:
                #        H.append(int(p))
                 #   except ValueError:
                  #      print(f"Warning: Skipping invalid token: {p}")

                    #line = line.strip()
                #if line and line.isdigit():  # skips empty and non-numeric lines
                 #   H.append(int(line))
                    
            #H = [int(line.strip()) for line in file if line.strip()]
            
    except FileNotFoundError:
        raise FileNotFoundError(f"file {lfn} not found")

    return np.array(H, dtype=np.int32)


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBnumDsc1   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the descriptor bin numbers as saved in C under w_DescBinNum. 

"""
def ReadBnumDsc1(fileID):

    uni = read_int32(fileID)
    biv = read_int32(fileID)
    tot = read_int32(fileID)
    
    return bnumDsc1( uni, biv, tot )


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBnumSpat   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the descriptor bin numbers as saved in C under w_DescBinNum. 

"""
def ReadBnumSpat(fileID):

    N             = bnumSpat
    N.nCells      = read_int32(fileID)
    N.nBinPerCell = read_int32(fileID)
    N.ntBin       = read_int32(fileID)

    Dim           = dimGrid
    Dim.ver       = read_int16(fileID)
    Dim.hor       = read_int16(fileID)
    N.Dim         = Dim
    
    N.Cnt         = ReadBnumDsc1(fileID)
    N.Frm         = ReadBnumDsc1(fileID)
    N.Arc         = ReadBnumDsc1(fileID)
    N.Str         = ReadBnumDsc1(fileID)
    N.Shp         = ReadBnumDsc1(fileID)

    N.Ndsc        = np.array([N.Cnt.tot, N.Frm.tot, N.Arc.tot, N.Str.tot, N.Shp.tot],
                             dtype=np.int32)
    return N

    
""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescBinNum   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the descriptor bin numbers as saved in C under w_DescBinNum.

"""
def ReadDescBinNum(fileID):

    def read_int(n):
        return np.fromfile(fileID, dtype=np.int32, count=n)

    def read_uint8(n):
        return np.fromfile(fileID, dtype=np.uint8, count=n).astype(np.int32)

    # ---------- Total ----------
    Tot    = read_int(4)

    # ---------- Hist Type ----------
    FltUni = read_int(7)
    FltBiv = read_int(7)
    SpaUni = read_int(7)

    SpaBiv = read_int(2)
    SpaBiv = np.concatenate([SpaBiv, [0, 0, 0]])

    # ---------- Individual DescTypes ----------
    sep = read_int(1)[0]
    assert sep == -1
    CntUni = read_int(4)

    sep = read_int(1)[0]
    assert sep == -1
    RsgUni = read_int(13)

    sep = read_int(1)[0]
    assert sep == -1
    ArcUni = read_uint8(8)

    sep = read_int(1)[0]
    assert sep == -1
    StrUni = read_int(4)

    sep = read_int(1)[0]
    assert sep == -1
    shpUni = read_int(1)[0]
    shpBiv = read_int(1)[0]

    sep = read_int(1)[0]
    assert sep == -1
    ttrgUni = read_int(1)[0]
    ttrgBiv = read_int(1)[0]

    bndgUni = read_int(1)[0]
    bndgBiv = read_int(1)[0]

    # ---------- Trailer ----------
    idfEof = read_int(1)[0]
    assert idfEof == 444

    return DescBinNum(
        Tot, FltUni, FltBiv, SpaUni, SpaBiv,
        CntUni, RsgUni, ArcUni, StrUni,
        shpUni, shpBiv, ttrgUni, ttrgBiv,
        bndgUni, bndgBiv
    )


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCollHist   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads a matrix of histograms, [nImg ntBin], as collected with program
collhimg. 

As saved in C under E_DESC/CollHist/CollHistUtil.h-s_CollHist().

Flat histograms not impl. yet

"""
def LoadCollHist( pthFile ):

    pthP = Path( pthFile )
    pth  = str( pthP.parent )   # directory path
    nam  = pthP.stem            # filename without the LAST extension
    ext  = pthP.suffix          # the last extension ('.hst')

    Fixt = OrgFileNames.o_FileExtensColl()

    bFull = (ext == Fixt.hsall)  # full, as from dscx
    bFlat = (ext == Fixt.hsflt)  # flat, as from dbin
    bSpat = (ext == Fixt.hsspa)  # spatial, as from dbin
    bFhyk = "fbk" in ext         # fabric hyperkolumns

    with open(pthFile, "rb") as f:

        print(f"Loading {pthFile} ", end="")

        # ------- Header (Size) -------
        nImg = np.fromfile(f, dtype=np.int32, count=1)[0]
        nBin = np.fromfile(f, dtype=np.int32, count=1)[0]

        print(f"[{nImg} {nBin}]...", end="")

        # ------- Data Matrix -------
        HST = np.fromfile(f, dtype=np.int32, count=nImg * nBin).astype(np.float32)

        # MATLAB: reshape(HST, nBin, nImg)'
        HST = HST.reshape((nImg, nBin))

        # ------- BinNumbers -------
        if bFull:
            Nbin = ReadDescBinNum(f)            # is above
        elif bFlat:
            printf("not impl. yet")
            breakpoint()
        elif bSpat:
            Nbin = ReadBnumSpat(f)
        elif bFhyk:
            Nbin = bnumSpat                     # is above
            if (ext==Fixt.fbk4):
                Nbin.nCells      = 9
            elif (ext==Fixt.fbk3):
                Nbin.nCells      = 49
            elif (ext==Fixt.fbk2):
                Nbin.nCells      = 15*15
            elif (ext==Fixt.fbk1):
                Nbin.nCells      = 31*31
                
            Nbin.nBinPerCell = int( nBin / Nbin.nCells )
        else:
            print( 'LoadCollHist: Nbin not implemented' )
            breakpoint()
        print("done.")

    # -------- Verify --------
    if bFull:
        ntBin = np.sum(Nbin.Tot)
        nDim  = HST.shape[1]

        if ntBin != nDim:
            print(
                f"WARNING LoadCollHist: sum of bin numbers {ntBin} != dims of histogram {nDim}"
            )

    return HST, Nbin



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_HspaSel   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Selects a subset of the spatial histograms, based on a specified label.

"""
def u_HspaSel( H, Nbin, sel ):

    nCll     = Nbin.nCells;
    nBpC     = Nbin.nBinPerCell;

    if sel=='cnt':
        IxB   = np.arange( Nbin.Cnt.tot )
        nRed  = len(IxB)

    SHF  = np.repeat(np.arange(nCll) * nRed, nRed).reshape(-1, nRed).T
    IXB  = np.repeat(IxB[:, np.newaxis], nCll, axis=1)
    IXS  = SHF + IXB
    IxS  = IXS.flatten(order='F')

    H    = H[:, IxS]

    Nbin.nBinPerCell = nRed
    Nbin.ntBin       = nRed*nCll
        
    return H, Nbin



    
# --------------------------------------------------------------------------------
#                                     D I S P 
# --------------------------------------------------------------------------------

""" DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD   DispBnumDsc1   DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD

bnumDsc1
"""
def DispBnumDsc1( N, jStr ):

    print(f"{jStr}  uni/biv/tot  {N.uni:>4} {N.biv:>4} {N.tot:>4}")

    
""" DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD   DispBnumSpat   DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD

bnumSpat
"""
def DispBnumSpat( N ):

    print(f"{'nCells':<15} {N.nCells:>6} {'  ('} {N.Dim.ver} {'x'} {N.Dim.hor} {')'}")
    print(f"{'nBinPerCell':<15} {N.nBinPerCell:>6}")
    print(f"{'ntBin':<15} {N.ntBin:>6}")

    DispBnumDsc1( N.Cnt, 'Cnt' )
    DispBnumDsc1( N.Frm, 'Frm' )
    DispBnumDsc1( N.Arc, 'Arc' )
    DispBnumDsc1( N.Str, 'Str' )
    DispBnumDsc1( N.Shp, 'Shp' )
