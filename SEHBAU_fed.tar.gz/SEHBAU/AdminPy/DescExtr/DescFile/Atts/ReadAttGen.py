"""

Reading general attributes, ie. position, color, etc.

For individual attributes see Read{Dsc}Att

def ReadAttPos( fid ):
def ReadAttRgb( fid, nDsc ):
def ReadAttLabels( fid, nAtt ):
def ReadRgbSpread( fid ):

"""
from dataclasses import dataclass, field
import struct
import numpy as np

from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescFile.PixPoints.ReadPixPoints import *



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class dclsAttRgb:       # ''''''''''''''''''''   dclsAttRgb   ''''''''''''''''''''
    """
    RGB triplet.
    """
    Red: np.ndarray
    Grn: np.ndarray
    Blu: np.ndarray


@dataclass
class OriDom:
    """
    Dominant orientation.
    """
    vrt: float
    hor: float
    obl: float
    axi: float
    uni: float
    nil: float


@dataclass
class OriDomSpc:
    """
    A space of dominant orientations.
    """
    nLev: int
    ALev: list = field(default_factory=list)



    
# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttPos   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
#
# Reads contour attributes as saved under CntIO.h-w_CntAtt
# cf ReadCntAtt.m
#
def ReadAttPos( fid, datTyp=np.float32 ):

    @dataclass
    class P:
        pass
    
        nPos  = np.fromfile( fid, dtype=np.int32, count=1 )[0] 

        Vrt   = np.fromfile( fid, datTyp, count=nPos)  # vertical position
        Hor   = np.fromfile( fid, datTyp, count=nPos)  # horizontal position

    return P



# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttRgb   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
#
# Reads Rgb values. af ReadAttRgb.m
# cf ReadCntAtt.py
#
def ReadAttRgb( fid, nDsc, conversion="float32" ):

    dtype  = np.dtype( conversion )

    RedArr = np.fromfile( fid, dtype=dtype, count=nDsc)  
    GrnArr = np.fromfile( fid, dtype=dtype, count=nDsc)  
    BluArr = np.fromfile( fid, dtype=dtype, count=nDsc)  

    return dclsAttRgb( Red=RedArr, Grn=GrnArr, Blu=BluArr )



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttLabels   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads attribute labels. See ReadAttLab.m for details.

"""
def ReadAttLabels( fid, nAtt ):
    
    Lbf = fid.read( nAtt * 6 )
    
    Lbf = np.frombuffer( Lbf, dtype='S1').reshape(-1, 6).astype(str)

    return [ ''.join(row.astype(str)).strip() for row in Lbf ]



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadRgbSpread   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

See ReadRgbSpread.m

"""
def ReadRgbSpread( fid ):

    @dataclass
    class S:
        pass
    
    S.bunt    = np.fromfile( fid, dtype=np.float32, count=1 )[0]
    
    S.minRo   = np.fromfile( fid, dtype=np.float32, count=1 )[0]
    S.minGo   = np.fromfile( fid, dtype=np.float32, count=1 )[0]
    S.minBo   = np.fromfile( fid, dtype=np.float32, count=1 )[0]

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttFarbig   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

See ReadAttFarbig.m

"""
def ReadAttFarbig( fid ):

    @dataclass
    class S:
        pass

    S.Sprd    = ReadRgbSpread( fid );
    S.PixRed  = ReadPixRCs( fid );
    S.IxRed   = ReadIxvArr( fid );

    return S



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescStsSpa   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

See ReadDescStsSpa.m

"""
def ReadDescStsSpa( fid ):

    @dataclass
    class S:
        pass
    
    S.nBand   = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    
    S.Grit    = np.fromfile( fid, dtype=np.float32, count=S.nBand*S.nBand )
    S.Bsnk    = np.fromfile( fid, dtype=np.float32, count=S.nBand )
    S.Bwag    = np.fromfile( fid, dtype=np.float32, count=S.nBand )

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescStsSpa   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

 Reads the dominance biases for orientations

 cf ReadDescStats.m

af ReadOriDomF.m

"""
def ReadOriDomF(fid):

    vals = np.fromfile(fid, dtype=np.float32, count=6)

    S = OriDom(
        vrt=vals[0],
        hor=vals[1],
        obl=vals[2],
        axi=vals[3],
        uni=vals[4],
        nil=vals[5],
    )

    A = vals

    return S, A


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadOriDomSpcF   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads a space of dominance biases (for orientations)

Outputs as both, struct and matrix.

cf ReadDescStats.m

"""
def ReadOriDomSpcF(fid):

    # MATLAB: fread(fid,1,'int=>single')
    nLev = int(np.fromfile(fid, dtype=np.int32, count=1)[0])

    Mx = np.zeros((nLev, 6), dtype=np.float32)

    S = OriDomSpc(nLev=nLev)

    for l in range(nLev):

        Stc, A = ReadOriDomF(fid)

        S.ALev.append( Stc )

        Mx[l,:] = A

    return S, Mx
