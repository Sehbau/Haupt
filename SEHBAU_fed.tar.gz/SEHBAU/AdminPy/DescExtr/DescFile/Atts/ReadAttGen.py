"""

Reading general attributes, ie. position, color, etc.

For individual attributes see Read{Dsc}Att

def ReadAttPos( fid ):
def ReadAttRgb( fid, nDsc ):
def ReadAttLabels( fid, nAtt ):

"""
import struct
import numpy as np


# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttPos   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
#
# Reads contour attributes as saved under CntIO.h-w_CntAtt
# cf ReadCntAtt.m
#
def ReadAttPos( fid ):

    class P:
    
        nPos  = int.from_bytes( fid.read(4), 'little')

        Vrt   = np.fromfile( fid, dtype=np.float32, count=nPos)  # vertical position
        Hor   = np.fromfile( fid, dtype=np.float32, count=nPos)  # horizontal position

    return P



# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttRgb   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
#
# Reads Rgb values. af ReadAttRgb.m
# cf ReadCntAtt.py
#
def ReadAttRgb( fid, nDsc ):

    class P:

        Red = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        Grn = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        Blu = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    return P


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   ReadAttLabels   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Reads attribute labels. See ReadAttLab.m for details.

"""
def ReadAttLabels( fid, nAtt ):
    
    Lbf = fid.read( nAtt * 6 )
    
    Lbf = np.frombuffer( Lbf, dtype='S1').reshape(-1, 6).astype(str)

    return [''.join(row.astype(str)).strip() for row in Lbf]



