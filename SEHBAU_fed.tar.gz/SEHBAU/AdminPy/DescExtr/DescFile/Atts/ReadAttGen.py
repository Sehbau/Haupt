"""

Reading general attributes, ie. position, color, etc.

For individual attributes see Read{Dsc}Att

def ReadAttPos( fid ):
def ReadAttRgb( fid, nDsc ):
def ReadAttLabels( fid, nAtt ):
def ReadRgbSpread( fid ):

"""
from dataclasses import dataclass
import struct
import numpy as np

from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescFile.PixPoints.ReadPixPoints import *


# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttPos   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
#
# Reads contour attributes as saved under CntIO.h-w_CntAtt
# cf ReadCntAtt.m
#
def ReadAttPos( fid, datTyp=np.float32 ):

    @dataclass
    class P:
        pass
    
        nPos  = np.fromfile( fid, dtype=np.int32, count=1 )[0] 

        Vrt   = np.fromfile( fid, datTyp, count=nPos)  # vertical position
        Hor   = np.fromfile( fid, datTyp, count=nPos)  # horizontal position

    return P



# RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttRgb   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
#
# Reads Rgb values. af ReadAttRgb.m
# cf ReadCntAtt.py
#
def ReadAttRgb( fid, nDsc ):

    @dataclass
    class P:
        pass

        Red = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        Grn = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        Blu = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    return P


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttLabels   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads attribute labels. See ReadAttLab.m for details.

"""
def ReadAttLabels( fid, nAtt ):
    
    Lbf = fid.read( nAtt * 6 )
    
    Lbf = np.frombuffer( Lbf, dtype='S1').reshape(-1, 6).astype(str)

    return [ ''.join(row.astype(str)).strip() for row in Lbf ]



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadRgbSpread   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

See ReadRgbSpread.m

"""
def ReadRgbSpread( fid ):

    @dataclass
    class S:
        pass
    
    S.bunt    = np.fromfile( fid, dtype=np.float32, count=1 )[0]
    
    S.minRo   = np.fromfile( fid, dtype=np.float32, count=1 )[0]
    S.minGo   = np.fromfile( fid, dtype=np.float32, count=1 )[0]
    S.minBo   = np.fromfile( fid, dtype=np.float32, count=1 )[0]

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttFarbig   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

See ReadAttFarbig.m

"""
def ReadAttFarbig( fid ):

    @dataclass
    class S:
        pass

    S.Sprd    = ReadRgbSpread( fid );
    S.PixRed  = ReadPixRCs( fid );
    S.IxRed   = ReadIxvArr( fid );

    return S




