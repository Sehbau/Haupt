"""

  Reads strs attributes and space.

"""
import numpy as np
from dataclasses import dataclass

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import *
from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescFile.PixPoints.ReadPixPoints import *



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadStrAtt   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads str attributes as saved under StrIO.h-w_StrSpc

"""
def ReadStrAtt( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = ReadDescAttHead( fid );
    S.nStr  = nDsc;
    #print(nDsc)
    
    # --------------------   Data   --------------------

    # =====   Geometry   =====
    LbGeo   = ['Les', 'Str', 'Ifx', 'Wig', 'Bog', 'Amp']
    S.Geo   = ReadStcArr( fid, np.float32, LbGeo )
    
    S.Smo   = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # =====   Appearance   =====
    S.RGB   = ReadAttRgb( fid, nDsc )

    # =====   Position   =====
    S.DirS  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Pos   = ReadAttPos( fid )

    # =====   Origin   =====
    S.Orgn  = ReadDescOrgn( fid, nDsc )
    S.Pts   = ReadDescPtsS( fid );

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int16, count=1)

    assert idf==4444, f"ReadStrAtt: idf not correct. is {idf}"

    return S, nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadStrBinUni   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

see ReadStrBinUni.m
"""
def ReadStrBinUni( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    S.nStr  = nDsc;

    # --------------------   Data   --------------------

    # =====   Geometry   =====
    S.Les   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Str   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Ori   = np.fromfile( fid, dtype=np.int32, count=nDsc )  

    # =====   Appearance   =====
    S.Red   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Grn   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Blu   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    
    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadStrSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of str attributes as saved under StrIO.h-w_StrSpc

"""
def ReadStrSpc( fid ):

    nLev = np.fromfile(fid, dtype=np.int32, count=1)[0]  # # of levels
    #nLev, Nstr = ReadDescSpcHead( fid )

    #print( nLev )
    #print( Nstr )

    ASTR = [None] * nLev
    Nstr = [None] * nLev
    for l in range( 0, nLev ):

        ASTR[l], nStr   = ReadStrAtt( fid );

        Nstr[l] = nStr

    return ASTR, Nstr


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadStrBinBiv   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadStrBinBiv( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    

    # --------------------   Header   --------------------
    nDsc    = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    S.nStr  = nDsc;

    # --------------------   Data   --------------------
    S.LS   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.LO   = np.fromfile( fid, dtype=np.int32, count=nDsc )  

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadStrBinSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadStrBinSpc( fid ):

    nLev = np.fromfile( fid, dtype=np.int32, count=1 )[0]

    #print( nLev )
    
    @dataclass
    class S:                                    # returning as structure
        pass    

    S.AUNI  = [None] * nLev
    S.ABIV  = [None] * nLev
    S.APOSA = [None] * nLev
    S.APOSQ = [None] * nLev

    for l in range( 0, nLev ):

        S.AUNI[l]   = ReadStrBinUni( fid );
        S.ABIV[l]   = ReadStrBinBiv( fid );

        S.APOSA[l]   = ReadAttPos( fid, datTyp=np.float32 )
        S.APOSQ[l]   = ReadAttPos( fid, datTyp=np.uint8 )

    return S



    
