"""

  Reads contour attributes and space.

"""
import numpy as np
from dataclasses import dataclass

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import ReadDescSpcHead, ReadDescAttHead
#from .Util.ReadDescHeaders import ReadDescSpcHead, ReadDescAttHead


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntAtt   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads contour attributes as saved under CntIO.h-w_CntSpc

"""
def ReadCntAtt( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = ReadDescAttHead( fid );
    S.nCnt  = nDsc;

    # --------------------   Data   --------------------

    # =====   Geometry   =====
    S.Les   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Str   = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # =====   Position   =====
    S.Ori   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Pos   = ReadAttPos( fid )

    # =====   Appearance   =====
    S.RGB   = ReadAttRgb( fid, nDsc )
    S.Ctr   = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int16, count=1)

    assert idf==1111, f"ReadCntAtt: idf not correct. is {idf}"

    return S, nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of contour attributes as saved under CntIO.h-w_CntSpc

"""
def ReadCntSpc( fid ):

    nLev, Ncnt = ReadDescSpcHead( fid )

    #print( nLev )
    #print( Ncnt )

    ACNT = [None] * nLev
    for l in range( 0, nLev ):

        ACNT[l], nCnt   = ReadCntAtt( fid );

        assert Ncnt[l] == nCnt, 'contour count not matching'

    return ACNT, Ncnt



    
