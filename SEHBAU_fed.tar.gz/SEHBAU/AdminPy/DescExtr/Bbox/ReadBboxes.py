"""

Reads bounding boxes.

def ReadBboxLtxt(fid):
def ReadBboxLbin(fid):

"""
import os
import numpy as np



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBboxLtxt   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads bounding boxes saved as integers from a TEXT file and returns them as array.

Equivalent to MATLAB's ReadBboxLtxt.m.

RET  ABbox    np.ndarray (nBox, 4) with [top, bottom, left, right] entries.
     nBox     int: number of bounding boxes read.


"""
def ReadBboxLtxt(fid):

    # --------------------   Header   --------------------
    nBox = int(fid.readline().strip())
    #print(f"[nBox {nBox:4d}] ", end='')

    # --------------------   Bboxes   --------------------
    nEnt = 4  # number of bbox entries (>=4)
    ABbox = np.zeros((nBox, nEnt), dtype=np.int16)

    for l in range(nBox):
        line = fid.readline()
        if not line:
            print("Warning: Unexpected end of fid.")
            break

        parts = list(map(int, line.strip().split()))
        if len(parts) < nEnt:
            print("Warning: Row not completely read.")
            break

        ABbox[l, :] = parts[:nEnt]

    return ABbox, nBox



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBboxLbin   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads bounding boxes saved as integers from a BINARY file and returns them as array.

Equivalent to MATLAB's ReadBboxLbin.m.

RET  ABbox    np.ndarray (nBox, 4) with [top, bottom, left, right] entries.
     nBox     int: number of bounding boxes read.

"""
def ReadBboxLbin(fid):

    # --------------------   Header   --------------------
    nBox = np.fromfile(fid, dtype=np.int32, count=1)[0]
    # print(f"[nBox {nBox:4d}]")

    # --------------------   Bboxes   --------------------
    Top = np.fromfile(fid, dtype=np.int32, count=nBox)
    Bot = np.fromfile(fid, dtype=np.int32, count=nBox)
    Lef = np.fromfile(fid, dtype=np.int32, count=nBox)
    Rit = np.fromfile(fid, dtype=np.int32, count=nBox)

    ABbox = np.column_stack((Top, Bot, Lef, Rit))

    return ABbox, nBox

