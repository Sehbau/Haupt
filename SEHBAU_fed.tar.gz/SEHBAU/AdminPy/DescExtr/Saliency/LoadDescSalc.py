"""

Loads saliency file

"""
from dataclasses import dataclass

from AdminPy.DescExtr.Saliency.ReadSaliency import *
from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescType.ReadDescTyp import *
from AdminPy.DescExtr.Bbox.ReadFeatures import *
from AdminPy.DescExtr.DescFile.Atts import *
from AdminPy.DescExtr.DescFile.LoadDescription import ReadDescStats



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescSalc   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads saliency file.

RET SLC, Hed  (with fields Txa, Blb, Shp, Ens, Dsc) 

"""
def LoadDescSalc( lfp ):

    # --------------------   Open File   --------------------
    try:
        file = open(lfp, 'rb')
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not open file {lfp}")
    
    #disp_load(lfp)  # mimic DispLoad(lfp)

    # --------------------   Header   --------------------
    Hed      = ReadSalcFileHead( file, 33 )

    @dataclass
    class SLC:
        pass
    
    # --------------------   Texture   --------------------
    @dataclass
    class Txa:
        pass

    # -----  Global Stats
    Txa.Gst     = ReadTxtrMapStats( file )

    # -----  Texturegrams
    @dataclass
    class Grm:
        pass
    
    Grm.Grid    = ReadMtrxDat( file, np.float32 )
    Grm.Bvrt    = ReadMtrxDat( file, np.int32 )
    Grm.Bhor    = ReadMtrxDat( file, np.int32 )

    Txa.Grm     = Grm

    # --------------------   Blobs   --------------------
    @dataclass
    class Blb:
        pass
    # -----  bboxes and asps
    Blb.Box     = ReadBlobOut( file )
    
    # -----   freckles
    #@dataclass
    #class Frkl:
    #    pass
    
    #Frkl.Lay  = np.fromfile( file, dtype=np.float32, count=7 )
    #Frkl.Spa  = ReadBlobStsSpa( file )

    #Blb.Frkl  = Frkl
    
    # --------------------   Shapes   --------------------
    Shp      = ReadShpOut( file )
    

    # --------------------   Spots/Bunt   --------------------
    Txa.Spt   = ReadPixvRCf( file )
    Txa.Bnt   = ReadPixvRCf( file )
    Txa.mxBnt = np.fromfile( file, dtype=np.float32, count=1 )[0]

    idf      = np.fromfile( file, dtype=np.int32, count=1)[0]
    if idf != -11111:
        raise ValueError("idf incorrect")


    # --------------------   Ensemble   --------------------
    Ens      = ReadSalcBbxEns( file )


    # --------------------   DescStats   --------------------
    #print('bef DescStats')
    Dsc      = ReadDescStats( file )
    
    file.close

    SLC.Txa = Txa
    SLC.Blb = Blb
    SLC.Shp = Shp
    SLC.Ens = Ens
    SLC.Dsc = Dsc
    
    return SLC, Hed


