"""

Labels of descriptor types

"""

def o_DescTypes(typ):

    if typ == 'crasshp':

        aDty = ['Cnt', 'Frm', 'Arc', 'Str', 'Shp']
        
    elif typ == 'crasst':
        
        aDty = ['Skl', 'Frm', 'Arc', 'Str', 'Shp', 'Ttg']
        
    elif typ == 'crasstb':
        
        aDty = ['Skl', 'Frm', 'Arc', 'Str', 'Shp', 'Ttrg', 'Bndg']
        
    elif typ == 'Crasstb':
        
        aDty = ['Cnt', 'Frm', 'Arc', 'Str', 'Shp', 'Ttrg', 'Bndg']
        
    elif typ == 'sklrasshp':
        
        aDty = ['Skl', 'Frm', 'Arc', 'Str', 'Shp']
        
    elif typ == 'cras':
        
        aDty = ['Skl', 'Frm', 'Arc', 'Str']
        
    elif typ == 'fixtVec':
        
        aDty = ['vecCnt', 'vecFrm', 'vecArc', 'vecStr', 'vecShp',
                 'vecTtg', 'vecBnd']
        
    elif typ == 'fixtLev':
        
        aDty = ['levCnt', 'levFrm', 'levArc', 'levStr', 'levShp',
                 'levTtg', 'levBnd']
        
    else:
        raise NotImplementedError(f"Descriptor type '{typ}' not implemented")
        #print(f"typ '{typ}' not implemented")

    nDty  = len(aDty)
        
    return aDty, nDty
