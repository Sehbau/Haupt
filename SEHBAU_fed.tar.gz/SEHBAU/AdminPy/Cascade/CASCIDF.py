"""

Cascade identifier. See CASCIDF.m

"""
from dataclasses import dataclass
import os
from AdminPy.Util.CmndSupp import *
from AdminPy.Orga.SaveFipaLst import *
from AdminPy.Util.FileIO.LoadData import *
from AdminPy.MtchVec.FileRead.LoadReadMtc import *

from AdminPy.Mtch.OrgFile import * #o_FileNameMtxtc



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class dclsCascIdfPrm:
    """
    Parameters for cascade identifier in CASCIDF
    """
    stgy:     str
    prpPre:   float
    nPre:     int
    nImg:     int
    bMesFull: int = 1                            # always 1 by default
    bCombMes: int = 1                            # always 1 by default

@dataclass
class dclsCascIdfPth:
    """
    Paths for cascade identifier in CASCIDF
    """
    fpMesHst: str
    fpMesTxt: str
    fpMesKol: str
    fpMesVec: str

    fpMesDtyDis: str
    fpMesDtySim: str

@dataclass
class dclsCascArgs:
    """
    Arguments
    """
    Vec: None
    Hst: str=""

    
    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_CascIdfPrm   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Organizational routine to setup parameters for cascade identifier.

"""
def o_CascIdfPrm( nImg: int,
                  prpPre: float = 0.5,
                  stgy: str = "hist1st",
                  bCombMes: int = 1 ) -> dclsCascIdfPrm:

    return dclsCascIdfPrm(
        stgy     = stgy,
        prpPre   = prpPre,
        nPre     = round( nImg * prpPre + 0.1 ),
        nImg     = nImg,
        bCombMes = bCombMes
    )


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_CascIdfPth   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Organizational routine to setup filepaths for cascade identifier.

"""
def o_CascIdfPth(pthMes: str = "") -> dclsCascIdfPth:

    return dclsCascIdfPth(
        fpMesHst    = os.path.join(pthMes, "Mes", "CscHst.txt"),
        fpMesTxt    = os.path.join(pthMes, "Mes", "CscTxt.txt"),
        fpMesKol    = os.path.join(pthMes, "Mes", "CscKol.txt"),
        fpMesVec    = os.path.join(pthMes, "Mes", "CscVec.txt"),

        fpMesDtyDis = os.path.join(pthMes, "Mes", "MesDtyDis.txt"),
        fpMesDtySim = os.path.join(pthMes, "Mes", "MesDtySim.txt"),
    )


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_CascSortReorder   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

"""
def uu_CascSortReorder( Mes, dirc, OrdPre ):

    Mes    = np.array(Mes)
    OrdPre = np.array(OrdPre)

    # Handle direction
    if dirc in ("ascend", 1, "asc"):
        OrdFin = np.argsort(Mes)                # ascending
    elif dirc in ("descend", -1, "desc"):
        OrdFin = np.argsort(-Mes)               # descending
    else:
        raise ValueError(f"Unknown sort direction: {dirc}")

    OrdOrg = OrdPre[OrdFin]
    return OrdOrg



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   CASCIDF   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Two-stage cascade identifier, 1 versus many. Takes a query image and matches it to a
list of reference images, called a register. Assumes we are running in folder
'MtchVec'.

Stage 1:  fast matching with mhst or mkol. preselection
Stage 2:  fine matching with mvec.

cf plcCascIdf.m, lvngRunMcsc.m

IN   FpExe    filepaths of executables. 
     FpQuy    filepaths of query image (.dsc, .hst, .kolm)
     Rgst     register. generated with o_RegistSetSave.m
     Admn     paths, see o_CascIdfPth.m
     Args     command arguments
     Prm      parameters, see o_CascIdfPrm.m

OUT  Res      matching results
     Sto      standard output of commands

uu_CascSortReorder already implemented above but not verified.

"""
def CASCIDF( FpExe, FpQuy, RGST, Admn, Args, Prm ):

    # created in o_RegistSetSave.m
    fpaRgstHst	= RGST.Fipa.hst;
    fpaRgstSlc	= RGST.Fipa.slc;
    fpaRgstKol 	= RGST.Fipa.kol;
    fpaRgstDsc 	= RGST.Fipa.dsc;    
    fpaRgstTop 	= RGST.Fipa.dtop;

    # created in o_CascIdfPth.m
    fpMesHst  	= Admn.fpMesHst
    fpMesTxt  	= Admn.fpMesTxt
    fpMesKol  	= Admn.fpMesKol
    fpMesVec  	= Admn.fpMesVec

    fpExeMhstL  = FpExe["mhstL"]
    fpExeMkolL  = FpExe["mkolL"]
    fpExeMvecL  = FpExe["mvecL"]
    fpExeMtxtc  = FpExe["mtxtc"]

    nImg      	= Prm.nImg;
    stgy        = Prm.stgy;

    @dataclass
    class Res:
        pass
    @dataclass
    class Fll:
        pass
    Sto = {}


    # --------------------------------------------------------------------------------
    #
    #                                STAGE 1 (FAST)
    #
    # according to a selected strategy
    OrdPre      = []
    DisPreOrd   = []

    ixTxtg      = stgy.find("txtg")

    # ---------------------   Texturegrams Collected  -----------------------
    if ixTxtg != -1:

        typ     = stgy[ixTxtg + 4:]

        fidfTxt = "Txtr"
        PthM    = o_FileNameMtxtc(1, fidfTxt)

        if typ == "Band":

            cmndBnd = f"{fpExeMtxtc} {FpQuy.salc} {Admn.FinaColl.txgb}"
            ResBnd  = subprocess.run(cmndBnd, shell=True, capture_output=True, text=True)
            
            v_CmndExec( ResBnd )
            
            DisTxt, _ = LoadFltTxtEof( PthM.txtBand )

        elif typ == "Grid":

            cmndGrd = f"{fpExeMtxtc} {FpQuy.salc} {Admn.FinaColl.txgg}"
            ResGrd  = subprocess.run(cmndGrd, shell=True, capture_output=True, text=True)
            
            v_CmndExec( ResGrd )

            DisTxt, _ = LoadFltTxtEof( PthM.txtGrid )

        elif typ == "Comb":

            cmndBnd = f"{fpExeMtxtc} {FpQuy.salc} {Admn.FinaColl.txgb}"
            cmndGrd = f"{fpExeMtxtc} {FpQuy.salc} {Admn.FinaColl.txgg}"
            
            ResBnd  = subprocess.run(cmndBnd, shell=True, capture_output=True, text=True)
            ResGrd  = subprocess.run(cmndGrd, shell=True, capture_output=True, text=True)

            v_CmndExec( ResBnd )
            v_CmndExec( ResGrd )
        
            # load both
            Mes    = LoadMeasMtxtc( PthM )
            
            DisTxt = Mes.Grd + Mes.Bnd

        else:
            raise RuntimeError(f"CASCIDF: stgy {stgy}, typ {typ} not implemented")

        OrdPre    = np.argsort( DisTxt )
        DisOrd    = DisTxt[ OrdPre ]

        OrdPre    = OrdPre[ :Prm.nPre ]
        DisPreOrd = DisOrd[ :Prm.nPre ]    

    # ------------------------------   Top1st   ------------------------------
    if "top" in stgy:

        aFipaTop  = [ RGST.Top.aFipaDtop[i] for i in range(nImg) ]
        SaveFipaLstPrependPath( aFipaTop, RGST.Top.pth, fpaRgstTop )

        # --- build command
        cmndTop   = f"{fpExeMvecL} {FpQuy.dtop} {fpaRgstTop} {fpMesVec}"
        # append options
        #if Args.Vec.opt:
        #    cmndTop += f" {Args.Vec.opt}"

        # --- execute command
        Sto["Mtop"]    = f_CmndExec( cmndTop )

        MesTop    = LoadMtchMes( fpMesVec, nImg )
        DisTop    = MesTop[:,0]
        
        OrdTop    = np.argsort(DisTop)
        DisTopOrd = np.sort(DisTop)

        OrdPre    = OrdTop[:Prm.nPre]

        Res.DisTopOrd = DisTopOrd


    # ------------------------------   Hist1st   ------------------------------
    if "enstoptxtg" in stgy:

        DisEns     = DisTxt * DisTop        # elementwise multiply

        OrdEns     = np.argsort(DisEns)     # indices of ascending sort
        DisEnsOrd  = DisEns[OrdEns]         # sorted values (optional)
        
        OrdPre     = OrdEns[:Prm.nPre]      # first nPre (0-based indexing)
    
    # ------------------------------   Hist1st   ------------------------------
    if stgy == "hist1st":

        cmndHst      = f"{fpExeMhstL} {FpQuy.hsti} {fpaRgstHst} {fpMesHst} {Args.Hst}"
        Sto["Mhst"]  = f_CmndExec(cmndHst)

        OrdHis, DisHisOrd = LoadSortFltTxt(fpMesHst, nImg)
        OrdPre            = OrdHis[:Prm.nPre]

        Res.DisHisOrd = DisHisOrd

    elif stgy == "kolm1st":
        
        cmndKol      = f"{fpExeMkolL} {FpQuy.kolm} {fpaRgstKol} {fpMesKol}"
        Sto["Mkol"]  = f_CmndExec(cmndKol)

        OrdKol, DisKolOrd = LoadSortFltTxt(fpMesKol, nImg)
        OrdPre       = OrdKol[:Prm.nPre]

        Res.DisKolOrd = DisKolOrd

    elif stgy == "ens":
        
        cmndHst = f"{fpExeMhstL} {FpQuy.hsti} {fpaRgstHst} {fpMesHst} {Args.Hst}"
        cmndKol = f"{fpExeMkolL} {FpQuy.kolm} {fpaRgstKol} {fpMesKol}"

        Sto["Mhst"] = f_CmndExec(cmndHst)
        Sto["Mkol"] = f_CmndExec(cmndKol)

        DisHisUor = LoadFltTxt(fpMesHst, nImg)
        DisKolUor = LoadFltTxt(fpMesKol, nImg)

        DisEns    = DisHisUor * DisKolUor
        OrdFin    = np.argsort(DisEns)          # ascending
        OrdPre    = OrdFin[:Prm.nPre]



    Res.OrdPre = OrdPre

    #print( DisHisOrd )
    #print( OrdPre )

    # --------------------------------------------------------------------------------
    #
    #                                STAGE 2 (FINE)
    #
    nPre    = len( OrdPre )
    if nPre==0:
        raise ValueError(f"CASCIDF: no preselection carried out: strategy {stgy}" )

    # generate and save preselected list
    aVecRed = [ RGST.Dsc.aFipaDsc[i] for i in OrdPre ]
    SaveFipaLstPrependPath( aVecRed, RGST.Dsc.pth, fpaRgstDsc )

    # --- build command
    cmndVec = f"{fpExeMvecL} {FpQuy.dsc} {fpaRgstDsc} {Args.Vec.fpPrm} {fpMesVec}"
    # append options
    if Args.Vec.opt:
        cmndVec += f" {Args.Vec.opt}"

    # --- execute command
    Sto["Mvec"] = f_CmndExec( cmndVec )

    MesTot = LoadMtchMes( fpMesVec, nPre )
    MESdis = LoadMtchMESdty( Admn.fpMesDtyDis )
    MESsim = LoadMtchMESdty( Admn.fpMesDtySim )

    nDty   = MESdis.shape[1]

    
    # --------------------------------------------------------------------------------
    #
    #                                COMBINE 
    #
    # Weight distances from fine matching by distances from fast matching
    if Prm.bCombMes:

        if len(DisPreOrd) > 0: 

            mxV       = np.max(DisPreOrd)
            SimPreOrd = mxV - DisPreOrd
            
            MesTot[:,0] *= DisPreOrd
            MesTot[:,1] *= SimPreOrd
            
            for d in range(nDty):
                MESdis[:,d] *= DisPreOrd
                MESsim[:,d] *= SimPreOrd


    # ------------------------------   Track Full   ------------------------------
    if Prm.bMesFull > 0:
        Fll.MesTot = MesTot
        Fll.MESdis = MESdis
        Fll.MESsim = MESsim


    # ------------------------------   Reorder   ------------------------------
    
    # -----  total (MesTot)
    Res.OrdDis = uu_CascSortReorder( MesTot[:,0], "ascend", OrdPre)[:nPre]
    Res.OrdSim = uu_CascSortReorder( MesTot[:,1], "descend", OrdPre)[:nPre]

    # -----  descriptor-wise
    nDty           = MESdis.shape[1]
    Res.ORDDtyDis  = np.zeros((nDty, nPre), dtype=np.int32)
    Res.ORDDtySim  = np.zeros((nDty, nPre), dtype=np.int32)

    for d in range(nDty):
        Res.ORDDtyDis[d, :] = uu_CascSortReorder( MESdis[:,d], "ascend",  OrdPre)[:nPre]
        Res.ORDDtySim[d, :] = uu_CascSortReorder( MESsim[:,d], "descend", OrdPre)[:nPre]

    return Res, Sto, Fll
