"""

Deep sets network. Classification of one descriptor type.

INP     DSC   [nDsc nAtt], number of descriptors x number of attributes

"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader



""" ------------------------------   clsDatasetDvmx   ------------------------------

    Dataset preparation.

       ADSC: descriptors as vector matrix       {nImg}[nDsc nAtt]
       ALbl: numpy array of labels, shape       {nImg}[nDsc 3] (level, imgNo, unused)
"""
class clsDatasetDvmx(Dataset):

    def __init__(self, ADSC, ALbl):

        self.ADSC = ADSC
        self.ALbl = ALbl
        
    def __len__(self):
        return len(self.ADSC)
    
    def __getitem__(self, ix):

        DSC     = self.ADSC[ix]

        DSCtns  = torch.from_numpy(DSC).float()
        
        LblI    = int(self.ALbl[ix])
        
        return DSCtns, LblI



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   COLT_DSC_VAR   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Custom collate function for DataLoader.

Pads variable-length sequences up to the longest sample IN THIS SPECIFIC BATCH.

BTCH is a list of tuples: [(DSC, label)_0,
                           (DSC, label)_1
                           ...
                           (DSC, label)_n]

"""
def COLT_DSC_VAR( BTCH ):

    ADSC   = [item[0] for item in BTCH]
    ALbl   = torch.tensor([item[1] for item in BTCH], dtype=torch.long)
    
    szBtc  = len(BTCH)
    nAtt   = ADSC[0].shape[1]

    mxnDsc = max(Dsc.shape[0] for Dsc in ADSC)
    
    # --- initalize zero-padded tensors
    DSCpad = torch.zeros(szBtc, mxnDsc, nAtt)
    MSKpad = torch.zeros(szBtc, mxnDsc, dtype=torch.bool)
    
    # --- fill in the valid contents
    for i in range(szBtc):
        n               = ADSC[i].shape[0]
        DSCpad[i, :n]   = ADSC[i]
        MSKpad[i, :n]   = True
        
    return DSCpad, MSKpad, ALbl


""" ------------------------------   PROC_Dsc   ------------------------------

Process descriptors, phi and rho networks.

"""
class PROC_Dsc(nn.Module):

    def __init__(self, nAtt, dimHid):

        super().__init__()

        self.net_Phi = nn.Sequential(
            nn.Linear(nAtt, dimHid),
            nn.GELU(),
            nn.Linear(dimHid, dimHid),
            nn.GELU(),
            #nn.LayerNorm(dimHid) # did not improve
        )
        
        self.net_Rho = nn.Sequential(
            nn.Linear(dimHid * 3 + 1, dimHid), 
            nn.GELU()
            #nn.Linear(dimHid)
        )

    def forward(self, DSC, MASK=None):

        # DSC shape: [szBtc nDsc nAtt]
        
        # --------------------   Phi Network   --------------------
        DSC   = self.net_Phi(DSC) # [szBtc nDsc dimHid]

        # --------------------   Aggregation   --------------------
        if MASK is not None:

            DSCmax  = DSC.masked_fill( ~MASK.unsqueeze(-1), float('-inf') )

            POOLmax = DSCmax.max(dim=1).values

            DSCmen  = DSC.masked_fill( ~MASK.unsqueeze(-1), 0 )

            nValid  = MASK.sum(dim=1, keepdim=True).clamp(min=1)

            POOLmen = DSCmen.sum(dim=1) / nValid

            DF2M    = (DSC - POOLmen.unsqueeze(1))
            DF2M    = DF2M.masked_fill( ~MASK.unsqueeze(-1), 0.0)

            POOLvar = (DF2M ** 2).sum(dim=1) / nValid
            POOLstd = torch.sqrt(POOLvar + 1e-6)

            nDesc   = torch.log1p(nValid)

        else:
            
            POOLmax = DSC.max(dim=1).values
            POOLmen = DSC.mean(dim=1)

            DF2M    = (DSC - POOLmen.unsqueeze(1))
            POOLvar = (DF2M ** 2).sum(dim=1)
            POOLstd = torch.sqrt(POOLvar + 1e-6)

            nDesc = torch.full(
                (DSC.shape[0], 1),
                np.log1p(DSC.shape[1]),
                device=DSC.device
            )
        
        # Concatenate them into a fixed size: [szBtc dimHid*3+1]
        DCAT    = torch.cat([POOLmax, POOLmen, POOLstd, nDesc], dim=-1)
        
        # --------------------   Rho Network   --------------------
        return self.net_Rho(DCAT) # [szBtc dimHid]


""" ------------------------------   MOD_DSCclsf   ------------------------------

Model for classification of descriptor vector matrices.

"""
class MOD_DSCclsf(nn.Module):

    def __init__(self, nAtt, dimHid, nCls):

        super(MOD_DSCclsf, self).__init__()

        self.f_Proc = PROC_Dsc( nAtt, dimHid )

        self.f_Clsf = nn.Sequential( nn.Linear(dimHid, nCls) )
        
    def forward(self, DSCraw, MSK):

        DSCproc  = self.f_Proc( DSCraw, MSK )

        LOGT     = self.f_Clsf( DSCproc )
        
        return LOGT
    
