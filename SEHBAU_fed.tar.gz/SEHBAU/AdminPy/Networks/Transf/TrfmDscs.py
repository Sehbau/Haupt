"""

A ViT-like transformer model for classification with the descriptor vector matrices
for segments, ie. contour, form, arc, straighter, etc. Uses padding to account for
variable lengths. Single attention head.

---------------   CLS/DEF SUM   ---------------
class clsDatasetDvmx(Dataset):
def COLT_DSC_VAR( BTCH ):
class ENC_Dsc(nn.Module):
class MOD_DSCclsf(nn.Module):

"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# max number of descriptors: corresponds to max length sequence
# Note: I did not check yet, whether a new image exceeds the max.
csMxnDsc = 1000                 



"""------------------------------   clsDatasetDvmx   ------------------------------

    Dataset preparation. It is the same as clsDatasetDvmx in DeepSet.py but includes
    coordinates as separate input.

       ADSC: descriptors as vector matrix       {nImg}[nDsc nAtt]
       ACOO: coordinates, vertical & horizontal {nImg}[nDsc 2]
       ALbl: numpy array of labels, shape       {nImg}[nDsc 3] (level, imgNo, unused)
"""
class clsDatasetDvmx(Dataset):

    def __init__(self, ADSC, ACOO, ALbl):

        self.ADSC = ADSC
        self.ACOO = ACOO
        self.ALbl = ALbl
        
    def __len__(self):
        return len(self.ADSC)
    
    def __getitem__(self, ix):

        DSC     = self.ADSC[ix]
        COO     = self.ACOO[ix]

        DSCtns  = torch.from_numpy(DSC).float()
        COOtns  = torch.from_numpy(COO).float()
        
        LblI    = int(self.ALbl[ix])
        
        return DSCtns, COOtns, LblI

    
""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   COLT_DSC_VAR   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Custom collate function for DataLoader.

Same as COLT_DSC_VAR in DeepSet.py, but:
1) includes coordinates
2) takes a maximum for the desc count: NOT efficient. Better organize as in DeepSet.py

BTCH is a list of tuples: [(DSC, COO, label)_0,
                           (DSC, COO, label)_1
                           ...
                           (DSC, COO, label)_n]
"""
def COLT_DSC_VAR( BTCH ):

    ADSC   = [item[0] for item in BTCH]
    ACOO   = [item[1] for item in BTCH]
    ALbl   = torch.tensor([item[2] for item in BTCH], dtype=torch.long)
    
    szBtc  = len(BTCH)
    szEmb  = ADSC[0].shape[1]
    
    # --- initalize zero-padded tensors
    DSCpad = torch.zeros(szBtc, csMxnDsc, szEmb)
    COOpad = torch.zeros(szBtc, csMxnDsc, 2)
    MSKpad = torch.zeros(szBtc, csMxnDsc, dtype=torch.bool)
    
    # --- fill in the valid contents
    for i in range(szBtc):
        n               = ADSC[i].shape[0]
        DSCpad[i, :n]   = ADSC[i]
        COOpad[i, :n]   = ACOO[i]
        MSKpad[i, :n]   = True
        
    return DSCpad, COOpad, MSKpad, ALbl
    


""" ------------------------------   ENC_Dsc   ------------------------------

Encoder layer.

"""
class ENC_Dsc(nn.Module):
    
    def __init__(self, szEmb, dimFF ):

        super(ENC_Dsc, self).__init__()
        
        self.szEmb     = szEmb
        
        # Projects 2D coordinates [v,h] into the object feature space
        self.proj_Coord = nn.Linear(2, szEmb)
        
        # Standard Single-Head Attention Projections
        self.proj_Quy   = nn.Linear(szEmb, szEmb)
        self.proj_Key   = nn.Linear(szEmb, szEmb)
        self.proj_Val   = nn.Linear(szEmb, szEmb)
        
        self.proj_Out   = nn.Linear(szEmb, szEmb)
        self.f_Norm1    = nn.LayerNorm(szEmb)
        self.f_Norm2    = nn.LayerNorm(szEmb)
        
        self.ffn = nn.Sequential(
            nn.Linear(szEmb, szEmb * dimFF ),
            nn.GELU(),
            nn.Linear(szEmb * dimFF, szEmb)
        )

    def forward(self, DSC, COO, MSK=None):
        """
        DSC   [szBtc csMxnDsc szEmb] raw descriptors
        COO   [szBtc csMxnDsc 2    ] normalized coordinates
        MSK   [szBtc csMxnDsc      ] padding mask
        """
        szB, nDsc, szEmb = DSC.shape
        
        # 1. Project coordinates and add them to object features (Position Embedding)
        #PosEmb    = self.proj_Coord(COO)
        DSC       = DSC + COO # PosEmb  
        RESD      = DSC
        
        # 2. Standard Attention projections
        QUY = self.proj_Quy(DSC)
        KEY = self.proj_Key(DSC)
        VAL = self.proj_Val(DSC)
        
        # 3. Pure dot-product attention matrix calculation
        # [szB nDsc nDsc]
        SCORattn = torch.matmul(QUY, KEY.transpose(-2, -1)) / (self.szEmb ** 0.5)
        
        # 4. Masking Step (Block padded objects)
        if MSK is not None:
            MSK2D    = MSK.unsqueeze(1) 
            SCORattn = SCORattn.masked_fill( ~MSK2D, float('-inf'))
        
        WGTSattn     = F.softmax(SCORattn, dim=-1)
        
        if MSK is not None:
            WGTSattn = WGTSattn.masked_fill( ~MSK2D, 0.0)

        # 5. Aggregate and output
        CNTXT    = torch.matmul(WGTSattn, VAL)
        DSC      = self.f_Norm1(RESD + self.proj_Out(CNTXT))
        DSC      = self.f_Norm2(DSC  + self.ffn(DSC))
        return DSC


""" ------------------------------   MOD_DSCclsf   ------------------------------

Model for classification of descriptor vector matrices.

"""
class MOD_DSCclsf(nn.Module):

    def __init__(self, nAtt, szEmb, nLay, dimFF, nCls):

        super(MOD_DSCclsf, self).__init__()

        self.proj_DscUp  = nn.Linear( nAtt, szEmb)
        self.proj_CooUp  = nn.Linear( 2, szEmb )

        self.f_Encoder = nn.ModuleList([
            ENC_Dsc( szEmb, dimFF )
            for _ in range(nLay)
        ])
        # if one encoder layer only:
        # self.BACKB  = ENC_Dsc(szEmb)

        self.f_Clsf = nn.Sequential(
            nn.Linear(szEmb, szEmb),
            nn.GELU(),
            #nn.Dropout(0.1),
            nn.Linear(szEmb, nCls)
        )
        
    def forward(self, DSCraw, COOraw, MSK):

        DSC   = self.proj_DscUp( DSCraw )
        COO   = self.proj_CooUp( COOraw )
        
        # 1. Update features using masked attention
        for lay in self.f_Encoder:
            DSC = lay( DSC, COO, MSK )

        DSCupd   = DSC
        #DSCupd  = self.BACKB(DSC, COO, MSK)
        
        # 2. MASKED GLOBAL POOLING STEP:
        # Padded elements are zeroed out so they do not taint the average calculation.
        DSCmsk  = DSCupd * MSK.unsqueeze(-1).float()
        
        # Sum elements and divide by actual valid counts per scene sequence
        DscSum  = torch.sum(DSCmsk, dim=1)
        Knts    = torch.sum(MSK, dim=1, keepdim=True).float()
        SCENvec = DscSum / Knts
        
        # 3. Predict scene categories
        LOGT    = self.f_Clsf(SCENvec)
        return LOGT

    

