"""

Set Transformer using cross-attention.

"""

