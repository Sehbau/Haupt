"""

Prepares data matrices for classification, in particular for transformers.

---------------   CLS SUM   ---------------

---------------   DEF SUM   ---------------
def u_IxTrimToAttHed(HSP, nCll, nEmb, nHed):
def u_ArrEmbToDiv(HSP, nCll, nEmb, nHed):


"""
import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np



# --------------------------------------------------------------------------------
#                                   C L A S S E S 
# --------------------------------------------------------------------------------



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_IxTrimToAttHed   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Generates the index array for reducing a feature matrix to a divisible
number of components for a transformer (that requires equal
dimensionality for attention heads).
 
IN   HSP   data [nSmp nFet(nCll*nEmb)]. used for verification only
     nCll  nCells | sequence length
     nEmb  embedding size
     nHed  number of attention heads
OUT  IxS   selected indices

"""
def u_IxTrimToAttHed(HSP, nCll, nEmb, nHed):

    nSmp, nFet = HSP.shape
    nFetC      = nCll * nEmb

    assert nFet == nFetC, f"feature dimy not matching: {nFet} (HSP) <> {nFetC} (calc)"

    vMod = nEmb % nHed
    if vMod == 0:
        return np.arange(nEmb), nEmb, nFet      # no reduction necessary

    nRed = nEmb - vMod                          # reduced (trimmed) dimensionality
    
    IxB  = np.arange(nRed)  
    SHF  = np.repeat(np.arange(nCll) * nRed, nRed).reshape(-1, nRed).T
    IXB  = np.repeat(IxB[:, np.newaxis], nCll, axis=1)
    IXS  = SHF + IXB
    IxS  = IXS.flatten(order='F')

    ntNew = nRed * nCll
    assert ntNew == len(IxS), "reduced dimy not correct"

    return IxS, nRed, ntNew    



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_ArrEmbToDiv   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Deprecated. Better use u_IxTrimToAttHed above.

Reduces the spatial histograms to a divisible number for a transformer (that
requires equal dimensionality for attention heads). In other words, it is direct
embedding without projection, that is input size will be (almost) embedding size. We
simply omit the last bins to make it fit to the number heads.

IN    HSP  (np.ndarray): data [nSmp, nFet(nCll*nEmb)]
      nCll (int): nCells | sequence length
      nEmb (int): embedding size
      nHed (int): number of attention heads
        
OUT   np.ndarray: possibly reduced data
"""
def u_ArrEmbToDiv( HSP, nCll, nEmb, nHed ):

    nSmp, nFet = HSP.shape
    nFetC      = nCll * nEmb

    assert nFet == nFetC, f"feature dimy not matching: {nFet} (HSP) <> {nFetC} (calc)"

    vMod = nEmb % nHed
    if vMod == 0:
        return HSP, nEmb, nFet                  # no reduction necessary

    nRed = nEmb - vMod                          # reduced (clipped) dimensionality
    
    IxB  = np.arange(nRed)  
    SHF  = np.repeat(np.arange(nCll) * nRed, nRed).reshape(-1, nRed).T
    IXB  = np.repeat(IxB[:, np.newaxis], nCll, axis=1)
    IXS  = SHF + IXB
    IxS  = IXS.flatten(order='F')

    RED  = HSP[:, IxS]

    ntNew = nRed * nCll
    assert ntNew == len(IxS), "reduced dimy not correct"

    return RED, nRed, ntNew    
