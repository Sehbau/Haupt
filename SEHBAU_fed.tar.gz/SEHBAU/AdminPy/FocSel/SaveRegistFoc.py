"""

"""
#import glob, os
from pathlib import Path

from AdminPy.Util.OrgFile.SaveFipaLst import *


""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveRegistFoc   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

see SaveRegistFoc.m

cf plcMtcProp.py

"""
def SaveRegistFoc( dirFoc, aImgNames, dirRegist, fext, neLev ):

    nImg = len(aImgNames);

    if nImg==0:
        print(f"SaveRegistFoc: no filenames in aImgNames for {fext} in {dirFoc}")

    # --------------------   Histogram   --------------------
    if fext == 'hsf1':

        aFipas  = [None] * nImg
        
        for i in range(nImg):

            imgNa   = aImgNames[i].stem
        
            #pat     = dirFoc / Path( imgNa + '_F*.' + fext )
            aFinas  = list( dirFoc.glob( imgNa + '_F*.' + fext ) )

            #pat     = os.path.join( dirFoc, str(imgNa) + '_F*.' + fext )
            #aFinas  = glob.glob( pat )
            
            nFocDet = len( aFinas )
            
            if nFocDet==0:
                continue
            
            sfpRgst = dirRegist / Path( f'Foc{imgNa}.rgsth' )
            SaveFipaLst( aFinas, sfpRgst )
            #sfpRgst = f'{dirRegist}/Foc{imgNa}.rgsth'
            
            aFipas[i] = sfpRgst
            
    # --------------------   Vectors   --------------------
    elif fext == 'dsf':
        
        aFipas = [[None for _ in range(neLev)] for _ in range(nImg)]
        
        for i in range(nImg):

            imgNa   = aImgNames[i].stem
        
            for l in range(neLev):

                pat      = str(imgNa) + '_F*_lev' + str(l+1) + '.' + fext
                aFinas   = list( dirFoc.glob ( pat ) )
                
                #pat = os.path.join( dirFoc, str(imgNa) + '_F*_lev' + str(l+1) + '.' + fext )
                #aFinas  = glob.glob( pat )
            
                nFocDet = len( aFinas )
            
                if nFocDet==0:
                    continue
            
                sfpRgst = dirRegist / Path( f'Foc{imgNa}_Lev{l+1}.rgstv' )
                SaveFipaLst( aFinas, sfpRgst )
                #sfpRgst = f'{dirRegist}/Foc{imgNa}_Lev{l+1}.rgstv'
            
                aFipas[i][l] = sfpRgst

    else:
        raise NotImplemented( f'file extension {fext} not implemented' );
    

    return aFipas
