"""

Creates bounding box parameters (TBLR) for a variety of image partitions, called
zones here. Can be used for extracting focii or for partitioning the image itself.

Types of partitoning: 
- 4 quarters and center
- stripes vertical and horizontal for (3 or 4 in number)

Degree of overlap: overlapping or separate.

ai plcDscxZon.m
"""
import numpy as np
from dataclasses import dataclass, field

# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class DC_BboxZones:
    Bbox: list = field(default_factory=np.zeros((0, 4), dtype=np.int16)) 
    aLab: list = field(default_factory=list)
    nZon: int = -1

    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   u_ZonesBboxes   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Main function

IN   szM    map size
OUT  S      struct with zones

"""
def u_ZonesBboxes( szM ):

    hgt, wth = szM

    hh = hgt / 2
    wh = wth / 2

    Q4C    = np.zeros((5, 4), dtype=np.int16)
    Q4C[0] = [0, int(hh), 0, int(wh)]                # TL
    Q4C[1] = [int(hh) + 1, hgt, 0, int(wh)]            # BL
    Q4C[2] = [0, int(hh), int(wh) + 1, wth]            # TR
    Q4C[3] = [int(hh) + 1, hgt, int(wh) + 1, wth]        # BR

    h4     = hgt / 4
    w4     = wth / 4
    Q4C[4] = [int(h4), int(h4 + hh), int(w4), int(w4 + wh)]  # Center

    S = {}

      
    DQ4C = DC_BboxZones( Bbox = Q4C[[4, 0, 2, 1, 3]],  # [Cen, TL, TR, BL, BR]
                         aLab = ['Cen', 'TL', 'TR', 'BL', 'BR'],
                         nZon = 5 )
    S['Q4C'] = DQ4C

    # --------------------   Stripes Overlapping   --------------------
    S['Ola3'] = uu_ZonesOlap(szM, 3 )
    S['Ola3']['Horz'].aLab = ['TopOla', 'MidOla', 'BotOla'] 
    S['Ola3']['Vert'].aLab = ['LefOla', 'MidOla', 'RitOla']
    
    #S['Ola3']['Horz']['aLab'] = ['TopOla', 'MidOla', 'BotOla']
    #S['Ola3']['Vert']['aLab'] = ['LefOla', 'MidOla', 'RitOla']

    S['Ola4'] = uu_ZonesOlap(szM, 4 ) 
    S['Ola4']['Horz'].aLab = ['TopOla', 'Above', 'Below', 'BottomOla']
    S['Ola4']['Vert'].aLab = ['LefOla', 'LeftOfC', 'RiteOfC', 'RitOla']
    #S['Ola4']['Horz']['aLab'] = ['TopOla', 'Above', 'Below', 'BottomOla']
    #S['Ola4']['Vert']['aLab'] = ['LefOla', 'LeftOfC', 'RiteOfC', 'RitOla']

    # --------------------   Stripes Separate   --------------------
    S['Sep3'] = uu_ZonesSepr(szM, 3 )
    S['Sep3']['Horz'].aLab = ['TopSep', 'MidSep', 'BotSep']
    S['Sep3']['Vert'].aLab = ['LefSep', 'MidSep', 'RitSep']
    #S['Sep3']['Horz']['aLab'] = ['TopSep', 'MidSep', 'BotSep']
    #S['Sep3']['Vert']['aLab'] = ['LefSep', 'MidSep', 'RitSep']

    S['Sep4'] = uu_ZonesSepr(szM, 4 )

    # --------------------   Mesh 3 Olap   --------------------
    # combined overlapping
    Msh3 = DC_BboxZones(
        Bbox = np.vstack( [ S['Ola3']['Horz'].Bbox, S['Ola3']['Vert'].Bbox ] ),
        aLab = ['TopOla', 'MidOlaH', 'BotOla', 'LefOla', 'MidOlaV', 'RitOla'],
        nZon = 6 )
    
    S['Msh3'] = Msh3
    
#    S['Msh3'] = {
#        'Bbox': np.vstack([S['Ola3']['Horz']['Bbox'], S['Ola3']['Vert']['Bbox']]),
#        'aLab': ['TopOla', 'MidOlaH', 'BotOla', 'LefOla', 'MidOlaV', 'RitOla'],
#        'nZon': 6
#    }

    # --------------------   Mesh 3 Sepr   --------------------
    # separate
#    S['Msh3sep'] = {
#        'Bbox': np.vstack([S['Sep3']['Horz']['Bbox'], S['Sep3']['Vert']['Bbox']]),
#        'aLab': ['TopSep', 'MidSepH', 'BotSep', 'LefSep', 'MidSepV', 'RitSep'],
#        'nZon': 6
#    }

    return S


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   uu_ZonesOlap   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Overlapping.
"""
def uu_ZonesOlap( szM, nZon ):

    szV, szH = szM
    Bbx = np.zeros((nZon, 4), dtype=np.int16)

    # Vertical
    HorSpc = np.round(np.linspace(0, szH, nZon + 2)).astype(int)
    
    for b in range(nZon):
        Bbx[b] = [0, szV, HorSpc[b], HorSpc[b + 2]]
        
    S = {}
    S['Vert'] = DC_BboxZones( Bbox = Bbx, nZon = nZon )
        
    #S = {'Vert': {'Bbox': Bbx.copy(), 'nZon': nZon}}

    # Horizontal
    VerSpc = np.round(np.linspace(0, szV, nZon + 2)).astype(int)
    
    for b in range(nZon):
        Bbx[b] = [VerSpc[b], VerSpc[b + 2], 0, szH]
        
    S['Horz'] = DC_BboxZones( Bbox = Bbx, nZon = nZon )
    #S['Horz'] = {'Bbox': Bbx.copy(), 'nZon': nZon}

    return S


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   uu_ZonesSepr   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Separate.
"""
def uu_ZonesSepr( szM, nZon ):

    szV, szH = szM
    Bbx = np.zeros((nZon, 4), dtype=np.int16)

    # Vertical
    HorSpc = np.round(np.linspace(0, szH, nZon + 1)).astype(int)

    for b in range(nZon):
        Bbx[b] = [0, szV, HorSpc[b], HorSpc[b + 1]]

    S = {}
    S['Vert'] = DC_BboxZones( Bbox = Bbx, nZon = nZon )
    #S = {'Vert': {'Bbox': Bbx.copy(), 'nZon': nZon}}

    # Horizontal
    VerSpc = np.round(np.linspace(0, szV, nZon + 1)).astype(int)
    
    for b in range(nZon):
        Bbx[b] = [VerSpc[b], VerSpc[b + 1], 0, szH]
        
    S['Horz'] = DC_BboxZones( Bbox = Bbx, nZon = nZon )
    #S['Horz'] = {'Bbox': Bbx.copy(), 'nZon': nZon}

    return S
