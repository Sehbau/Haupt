"""

Focus selection.

------------------------------   CLS SUM   ------------------------------
class focRng:
class prmFocScl:

------------------------------   DEF SUM   ------------------------------
def f_FocBxRngGrd( Box: int, Scl: float ) -> focRng:

def u_FocFileNameLi( pth: str | Path, ctg, ist, ext ) -> str:
def u_FocFileNameLily( pth: str | Path, ctg, ist, nLay, ext ) -> str:

"""
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import numpy.typing as npt

#from AdminPy.Orga.OrgFileNames import o_FileExtensFoc



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class focRng:                    # ''''''''''''''''''''   focRng   ''''''''''''''''''''
    """
    Row and column index ranges for a focus.
    """
    Rw: npt.NDArray[np.int32]   # row indices
    Cl: npt.NDArray[np.int32]   # col indices
    
    nRow: int
    nCol: int


@dataclass
class prmFocScl:              # ''''''''''''''''''''   prmFocScl   ''''''''''''''''''''
    """

    The scaling factors for bbox to map. Not deployed yet. See also prmFbrcFocSel in Fabric.py

    """
    vrt: float
    hor: float


    
    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FocBxRngGrd   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Extracting coordinate ranges for a bounding box scaled to some grid by scaling
factors in 'Scl'

FocRng  = fs.f_FocBxRngGrd( Box, PrmScl.Scl[ixLay] )

cf f_FocRngsFbrc in Fabric.py

"""
def f_FocBxRngGrd( Box: int, Scl: float ) -> focRng:

    sclV  = Scl[0]
    sclH  = Scl[1]
    
    top   = np.floor( float(Box[0]) * sclV ).astype(np.int32)
    bot   = np.floor( float(Box[1]) * sclV ).astype(np.int32)
    lef   = np.floor( float(Box[2]) * sclH ).astype(np.int32)
    rit   = np.floor( float(Box[3]) * sclH ).astype(np.int32)

    #print( "tblr", top, bot, lef, rit )
    
    RwRng   = np.arange( top, bot )
    ClRng   = np.arange( lef, rit )

    Rng     = focRng( Rw=RwRng, Cl=ClRng, nRow=len(RwRng), nCol=len(ClRng) )

    return Rng






""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_FocFileNameLi   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Simple filename consisting of label and instance:   Lab{category}_i{instance}

ai annFabric.py

"""
def u_FocFileNameLi( pth: str | Path, ctg, ist, ext ) -> str:

    fn = str(pth) + f"/Lab{ctg}_i{ist}" + ext

    return fn


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_FocFileNameLily   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Filename consisting of label, instance and number of layers/levels:

                   Lab{category}_i{instance}_ly{nLay/Lev}

ai annFabric.py

"""
def u_FocFileNameLily( pth: str | Path, ctg, ist, nLay, ext ) -> str:

    fn = str(pth) + f"/Lab{ctg}_i{ist}_ly{nLay}" + ext

    return fn



    

