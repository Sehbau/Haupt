"""

"""

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveFipaLst   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS
"""
def SaveFipaLst( aFina, sfn ):

    try:
        with open(sfn, 'w') as fid:
            for item in aFina:
                fid.write( f"{item}\n" )
    except IOError:
        raise RuntimeError(f"SaveFipaLst: could not write to {sfn}")


    
""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveFipaLstPrependPath   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

cf o_RegistSetSave

"""
def SaveFipaLstPrependPath( aFina, pth, sfn ):

    try:
        with open(sfn, 'w') as fid:
            for item in aFina:
                #fname = item[:-4]
                fid.write( f"{pth}{item}\n" )
                
    except IOError:
        raise RuntimeError(f"SaveFipaLstPrependPath: could not write to {sfn}")
