"""

Utilities for plotting

---------------   DEF SUM   ---------------
def imglabN(label, count):
def p_LossInit( ):
def p_LossUpdate( ax, Loss, line ):

def fig_MoveToLowRit( event=None ):

"""

import matplotlib.pyplot as plt


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   imglabN   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Displays a simple text label and count.

"""
def imglabN(label, count):

    plt.title(f'{label} ({count})')





""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_LossInit   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Displays a simple text label and count.

"""
def p_LossInit( ):

    plt.ion()
    fig, ax = plt.subplots()
    line, = ax.plot([], [], 'r-')  # 'r-' creates a solid red line
    ax.set_title("Live Training Loss Profile")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss")
    ax.grid(True)

    fig.canvas.manager.window.after( 50, fig_MoveToLowRit ) # sb.Util.Plot.

    return ax, line

    
""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_LossUpdate   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Displays a simple text label and count.

"""
def p_LossUpdate( ax, Loss, line ):

    # 2. Update the dynamic plot data
    xax     = list( range(1, len(Loss) + 1) )
    line.set_xdata(xax)
    line.set_ydata(Loss)
        
    # Rescale plot limits dynamically to fit the new values
    ax.relim()
    ax.autoscale_view()
    
    # 3. Force Matplotlib to redraw the figure immediately
    plt.draw()
    plt.pause(0.1)  # Brief pause allows the GUI thread to paint
    

    
""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   fig_MoveToLowRit   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Places the figure to the lower rite.

"""
def fig_MoveToLowRit( event=None ):

    """Callback function triggered when the figure window manager establishes itself."""
    try:
        Mngr   = plt.get_current_fig_manager()
        Win    = Mngr.window
        
        # 1. Fetch dimension maps
        wScrn  = Win.winfo_screenwidth()
        hScrn  = Win.winfo_screenheight()
        wFig   = Win.winfo_width()
        hFig   = Win.winfo_height()
        
        # 2. Factor in OS scaling (if physical/logical pixels mismatch)
        # Windows/Linux taskbar padding safety buffer
        buffer_y = 80 
        buffer_x = 20
        
        x = wScrn - wFig - buffer_x
        y = hScrn - hFig - buffer_y
        #print( f"x={x}, y={y}" )
        x = 1200
        y = 400
        #print( f"x={x}, y={y}" )

        # 3. Direct geometry override
        Win.geometry(f"+{int(x)}+{int(y)}")

    except Exception as e:
        pass
    
