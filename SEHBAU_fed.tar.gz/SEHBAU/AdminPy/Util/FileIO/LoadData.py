"""

Load data files.

def LoadTextLinewise( lfn ):
def LoadArrIntTxt( lfn ):
def LoadArrFltTxtPur( lfn, nFlt ):
def LoadFltTxtEof(lfn):
def LoadSortFltTxt( lfn: str, nFlt: int ):
def LoadBankVec(pthFile):

"""
import numpy as np
from dataclasses import dataclass
from pathlib import Path


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class dclsHeadBankVec:          # ''''''''''''''''''''   dclsHeadBankVec   ''''''''''''''''''''
    """
    Header for a bank of vectors
    """
    idf: int
    szHed: int
    nGrp: int
    nDimGrp: int
    vers: float
    nVec: int = None
    nDim: int = None

    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadTextLinewise   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads a text file line by line.

cf LoadDescVect() in LoadDescription.py

"""
def LoadTextLinewise( lfn ):

    if lfn==None:
        print('LoadTextLinewise: no filename provided')
        return None, 0
    
    try:
        with open(lfn, 'r') as file:
            
            aLines = file.readlines()
            
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not open file {lfn}")

    # Strip newline characters
    aLines = [line.rstrip('\n') for line in aLines]
    cLin   = len(aLines)

    return aLines, cLin

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadArrIntTxt   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Reads an array of integers whose length is specified as header.

"""
def LoadArrIntTxt( lfn ):

    # --- load all at once to a flat NumPy array
    Arr = np.fromfile( lfn, dtype=int, sep=' ')
    
    # --- segregate header / data
    lenE  = Arr[0]
    Arr   = Arr[1:]
    
    # --- verify length
    assert len(Arr) == lenE, \
        f"File corrupted: Expected {lenE} items, but read {len(Arr)}."
        
    return Arr


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadArrFltTxtPur   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Reads an array of floats from a text file, whereby the number of floats is specified
as argument.

"""
def LoadArrFltTxtPur( lfn, nFlt ):

    try:
        with open(lfn, 'r') as f:

            Vals = f.read().split()
            if len(Vals) < nFlt:
                raise ValueError(f"Expected at least {nFlt} floats, found {len(Vals)}")
            return np.array(Vals[:nFlt], dtype=np.float32)
        
    except FileNotFoundError:
        
        raise FileNotFoundError(f"File {lfn} not found")


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadFltTxtEof   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads an array of floats from a text file, until end-of-file, ie. as saved as in
st_ArrPurF.

"""
def LoadFltTxtEof(lfn):

    lfn = Path(lfn)

    if not lfn.exists():
        raise RuntimeError(f"file {lfn} not found")

    with lfn.open('r') as f:
        A = np.fromstring(f.read(), sep=' ', dtype=np.float32)

    #A = np.loadtxt(lfn, dtype=np.float32)

    # Ensure 1D (MATLAB column vector behavior)
    #A = np.atleast_1d(A)

    nRed = A.size

    return A, nRed


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadSortFltTxt   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads a sorting saved as order/value in two columns, ie. from st_SortFlt().

"""
def LoadSortFltTxt( lfn: str, nFlt: int ):

    try:
        Dat = np.loadtxt(lfn, dtype={"names": ("idx", "val"),
                                     "formats": ("i4", "f4")})
    except OSError:
        raise FileNotFoundError(f"File {lfn} not found")

    if len(Dat) != nFlt:
        raise ValueError(f"Expected {nFlt} rows, got {len(Dat)}")

    Ord = Dat["idx"] 
    Vls = Dat["val"].astype(float)

    return Ord, Vls


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadBankVec   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads a bank of vectors (or any matrix of floats)

"""
def LoadBankVec(pthFile):

    pthFile = Path(pthFile)

    if not pthFile.exists():
        raise RuntimeError(f"could not open {pthFile}")

    with pthFile.open('rb') as f:

        # ------- Header (Size) -------
        nRow = np.fromfile(f, dtype=np.int32, count=1)[0]
        nCol = np.fromfile(f, dtype=np.int32, count=1)[0]

        idf     = np.fromfile(f, dtype=np.int32, count=1)[0]
        szHed   = np.fromfile(f, dtype=np.int32, count=1)[0]
        nGrp    = np.fromfile(f, dtype=np.int32, count=1)[0]
        nDimGrp = np.fromfile(f, dtype=np.int32, count=1)[0]

        vers = np.fromfile(f, dtype=np.float32, count=1)[0]

        print(f"[{nRow:4d} {nCol:4d}]")

        # ------- Data -------
        ntVal = nRow * nCol

        MTX = np.fromfile(f, dtype=np.float32, count=ntVal)

    if MTX.size != ntVal:
        raise RuntimeError(
            f"read fewer values than expected: {MTX.size} < {ntVal}"
        )

    # ------- Reshape to Matrix -------
    # MATLAB:
    # MTX = reshape(MTX, nCol, nRow)';
    #
    # Equivalent in NumPy:
    MTX = MTX.reshape((nCol, nRow), order='F').T

    Hed = dclsHeadBankVec(
        idf=idf,
        szHed=szHed,
        nGrp=nGrp,
        nDimGrp=nDimGrp,
        vers=vers,
        nVec=nRow,
        nDim=nCol
    )

    return MTX, Hed
