"""

Read arrays, matrices and (mathematical) spaces thereof.


def ReadIxsArr( file ):
def ReadIxvArr( file ):

def ReadMtrxDat( file, conversion ):
def ReadMapGen( file, szM, conversion ):

# ----------   Stc of Arr   ----------
def u_MtrxToStcArr( Mx, aFldNames ):
def ReadStcMapFlt( file, aFieldNames, szM ):
def ReadStcArr( file, dtypeIN, aFieldNames ):

"""
import numpy as np
from dataclasses import dataclass
from collections import namedtuple


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------


        
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadIxsArr   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads an index array from a binary file and returns an IxsArr class.
Equivalent to ReadIxsArr.m

"""
def ReadIxsArr( file ):

    class IxsArr:
    
        def __init__(self, nEnt, Ix):
            self.nEnt = nEnt      # number of entries
            self.Ix   = Ix        # index array
            
    nEnt = np.fromfile(file, dtype=np.int32, count=1)[0]

    Ix   = np.fromfile(file, dtype=np.int32, count=nEnt)
    
    return IxsArr(nEnt, Ix)


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadIxvArr   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads an index array from a binary file and returns an IxvArr class.
Equivalent to ReadIxvArr.m

"""
def ReadIxvArr( file ):

    class IxvArr:
    
        def __init__(self, nEnt, Ix, Vl):
            self.nEnt = nEnt      # number of entries
            self.Ix   = Ix        # index array
            self.Vl   = Vl        # value array
            
    nEnt = np.fromfile(file, dtype=np.int32, count=1)[0]

    Ix   = np.fromfile(file, dtype=np.int32,   count=nEnt)
    Vl   = np.fromfile(file, dtype=np.float32, count=nEnt)
    
    return IxvArr(nEnt, Ix, Vl)





""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadMtrxDat   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads a data matrix [nRow nCol] that was saved feature-/columnwise in C, that is
'inverse' [nCol nRow]. We therefore reshape to 'standard' format here.

EXAMPLE: descriptor attributes were saved in C by writing the attribute arrays
sequentially, ie. Len, Str, Ori. Thus when loaded, the data corresponds to [nAtt
nDsc]. We then reshape to [nDsc nAtt] format.

Use ReadStcArr() below, to read and turn into struct-of-arrays in one function.

ai ReadStrAtt(), ReadArcAtt(), LoadTxtrMaps(), ...

IN    fid         file pointer
      dtypeIN     datatype conversion, 
                   ie. np.float32, np.int32

See ReadMtrxDat.m

"""
def ReadMtrxDat( file, dtypeIN ):

    # ----------   Header   ----------
    nFet = int(np.fromfile(file, dtype=np.int32, count=1)[0])
    nObs = int(np.fromfile(file, dtype=np.int32, count=1)[0])

    # print( nFet, nObs )
    
    # ----------   Matrix   ----------
    ARR      = np.fromfile(file, dtype=dtypeIN, count=nObs * nFet)

    # ----------   Reshape   ----------
    Mtx      = ARR.reshape((nFet, nObs)).T #, order = 'F' )

    SizeDesc = namedtuple('SizeDesc', ['nObs','nFet'])
    szD      = SizeDesc( nObs=nObs, nFet=nFet )

    return Mtx, szD    



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadMapGen   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Analogous to ReadMapGen.m

cf LoadTxtrMaps

"""
def ReadMapGen( file, szM, conversion ):

    # Ensure szM is a tuple in row form
    if len(szM) != 2:
        raise ValueError("szM must have exactly two dimensions")

    nPx = szM[0] * szM[1]

    # --------------------   Read   --------------------
    Mcm = np.fromfile( file, dtype=conversion, count=nPx )

    # --------------------   Reshape   --------------------
    Map = Mcm.reshape( (szM[0], szM[1] ))

    return Map


# --------------------------------------------------------------------------------
#                               S T C   of   A R R
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_MtrxToStcArr   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Analogous to u_MtrxToStcArr.m

cf ReadStcMapFlt

"""
def u_MtrxToStcArr( Mx, aFldNames ):

    nObs, nFet = Mx.shape
    #nFet, nObs = Mx.shape
    nFlds      = len(aFldNames)

    assert nFlds == nFet, f"nFeatures not matching: {nFlds} <> {nFet}"

    AArr = { aFldNames[i]: Mx[:,i] for i in range(nFlds) }

    return AArr



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_StcArrToStcMap   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

See u_StcArrToStcMap.m

"""
def u_StcArrToStcMap( R, szM ):

    nRow, nCol = szM[0], szM[1]
    for key in R:

        Mlin   = R[key]
        #Map    = Mlin.reshape((nCol,nRow)) 
        Map    = Mlin.reshape((nRow,nCol)) 
        R[key] = Map
        
    return R



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadStcMapFlt   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

See ReadStcMapFlt.m

"""
def ReadStcMapFlt( file, aFieldNames, szM ):

    # first load as data matrix
    Mx, szD     = ReadMtrxDat( file, np.float32 )

    # now turn into a struct-of-array
    SofArr      = u_MtrxToStcArr( Mx, aFieldNames )

    # now reshape arrays to maps
    SofMps      = u_StcArrToStcMap( SofArr, szM )

    return SofMps


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadStcArr   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

See ReadStcArr.m

"""
def ReadStcArr( file, dtypeIN, aFieldNames ):

    # first load as data matrix
    Mx, szD     = ReadMtrxDat( file, dtypeIN )

    #print( szD )

    # now turn into a struct-of-array
    SofArr      = u_MtrxToStcArr( Mx, aFieldNames )

    return SofArr


