"""

Command support.

- Supports passing arguments to system calls, in particular for RennXXX wrapper
routines.

- Verifies program output for proper termination.

Called from:
- RennDscx.m
- RennMvec1.m
- RennMvecL.m
- RennFocDsc1.m
- etc

"""
from dataclasses import dataclass
import platform


@dataclass
class dclsAdminCmnd:            # ''''''''''''''''''''   dclsAdminCmnd   ''''''''''''''''''''
    """
    Administrative structure for passing arguments to RennXXX wrapper routines.
    """

    pthProg   = ''       # path to program, ie. from FipaExe in globalsSB.py
    optS      = ''       # options as string. set manually or with u_OptXXX, i_OptXXX
    bOSisWin  = platform.system()=='Windows'




"""VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV   v_CmndExec   VVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

Verify command execution (run). Twice. Because occasionally it failed AND returned
zero instead of non-zero.

"""
def v_CmndExec( Res ):

    if Res.returncode != 0:                         # ^^^^^   failed   ^^^^^

        print( Res.stdout )

        print( Res.stderr )
        
        raise ValueError( f'"command " {Res.args} "did not execute properly"' )

    """ ------ Verify Termination with EoP -----

    Since occasionally my programs return # 0 despite failure, I therefore check
    also for the EoP string

    """
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:

        print( Res.stdout )

        print( Res.stderr )

        raise ValueError( f'"command " {Res.args} "did not execute properly"' )

    

    


