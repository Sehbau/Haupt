"""

Simples Stats

"""
import numpy as np
from dataclasses import dataclass


@dataclass
class MtrxColStat:
    """ Simple Stats for a matrix
    """
    Men: np.ndarray
    Min: np.ndarray
    Max: np.ndarray
    Rng: np.ndarray


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_MtrxColStats   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
"""
def f_MtrxColStat(M):

    S = MtrxColStat(
        Men=np.mean(M, axis=0),
        Min=np.min(M, axis=0),
        Max=np.max(M, axis=0),
        Rng=None
    )

    S.Rng = S.Max - S.Min

    return S
