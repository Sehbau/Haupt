"""Some paramaters. Ideally they would be all set through the parameter files for
the individual programs, but since we are not fully flexible yet, we have a few,
explicit structures.

"""
from dataclasses import dataclass, field


# ------------------------------   Texture   ------------------------------
@dataclass
class prmTexture:
    # grams grid 
    szGrd:   list  = field(default_factory=lambda: [5,5])
    nTxtBis: int   = 7
    nrm:     float = 40                # normalization factor for numerosity bias


