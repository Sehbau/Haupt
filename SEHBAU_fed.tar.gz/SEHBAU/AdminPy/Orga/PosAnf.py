"""

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------


"""
from dataclasses import dataclass

import numpy as np

from typing import IO, Type


@dataclass
class attPos:
    nPos: int
    Vrt:  np.ndarray  # vertical position
    Hor:  np.ndarray  # horizontal position

    @classmethod
    def from_file(cls, fid: IO, datTyp: Type = np.float32) -> "attPos":
        """Factory method to read binary data directly into the dataclass."""
        nPos = np.fromfile(fid, dtype=np.int32, count=1)[0]
        Vrt  = np.fromfile(fid, dtype=datTyp, count=nPos)
        Hor  = np.fromfile(fid, dtype=datTyp, count=nPos)
        
        return cls(nPos=nPos, Vrt=Vrt, Hor=Hor)
