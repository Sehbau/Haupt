"""

def LoadMtchMes( lfn, nImg ):
def LoadMotVec( lfn ):

"""
import numpy as np
from dataclasses import dataclass


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class dclsMotVec:
    """
    Motion vectors.
    """
    Ep1: np.ndarray   # shape (nMot, 2), float32
    Ep2: np.ndarray
    Cen: np.ndarray
    Mag: np.ndarray   # shape (nMot,), float32
    Dir: np.ndarray
    Dis: np.ndarray
    nMot: int
    idf: int
    nRdg: int
    nRiv: int
    nEdg: int
    nSkl: int
    nRsg: int
    nArc: int
    nStr: int
    

    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadMtchMes   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

see LoadMtchMes.m
"""
def LoadMtchMes( lfn, nImg ):
    try:
        with open(lfn, 'r') as fileID:

            Mes = np.zeros((nImg, 4), dtype=np.float32)

            for i in range(nImg):
                
                line   = fileID.readline()
                values = list(map(float, line.strip().split()))
                if len(values) != 4:
                    raise ValueError(f"Line {i+1} does not contain 4 values")
                Mes[i, :] = values
                
            return Mes
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not open file {lfn}")



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadMtchMESdty   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads matching results for each desctype column-wise [nMtc nDscTyp]

"""
def LoadMtchMESdty(lfn: str) -> np.ndarray:

    try:
        with open(lfn, "r") as f:

            Hed = f.readline().strip().split()
            if len(Hed) < 2:
                raise ValueError(f"Invalid Hed in {lfn}")

            nMtc, nDty = map(int, Hed[:2])

            Dat = np.fromfile(f, sep=" ", dtype=float)

    except OSError:
        raise FileNotFoundError(f"Could not open file {lfn}")

    if Dat.size != nMtc * nDty:
        raise ValueError(
            f"Expected {nMtc*nDty} values, got {Dat.size} in {lfn}"
        )

    Mes = Dat.reshape((nMtc, nDty)).astype(np.float32)
    
    return Mes    

    

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadMotVec   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

see LoadMotVec.m
"""
def LoadMotVec( lfn ):

    with open(lfn, 'rb') as fid:

        # ---------------- Header ----------------
        nMot = int(np.fromfile( fid, dtype=np.int32, count=1)[0])

        # ---------------- Vectors ----------------
        Ep1 = np.fromfile( fid, dtype=np.float32, count=nMot*2)
        Ep2 = np.fromfile( fid, dtype=np.float32, count=nMot*2)
        Cen = np.fromfile( fid, dtype=np.float32, count=nMot*2)

        Mag = np.fromfile( fid, dtype=np.float32, count=nMot)
        Dir = np.fromfile( fid, dtype=np.float32, count=nMot)
        Dis = np.fromfile( fid, dtype=np.float32, count=nMot)

        # ---------------- Trailer ----------------
        idf  = int(np.fromfile( fid, dtype=np.int32, count=1)[0])
        nRdg = int(np.fromfile( fid, dtype=np.int32, count=1)[0])
        nRiv = int(np.fromfile( fid, dtype=np.int32, count=1)[0])
        nEdg = int(np.fromfile( fid, dtype=np.int32, count=1)[0])
        nSkl = int(np.fromfile( fid, dtype=np.int32, count=1)[0])

        nRsg = int(np.fromfile( fid, dtype=np.int32, count=1)[0])
        nArc = int(np.fromfile( fid, dtype=np.int32, count=1)[0])
        nStr = int(np.fromfile( fid, dtype=np.int32, count=1)[0])

    # Check identifier
    if idf != 7771:
        print(f"file identifier not correct {idf}. Expected 7771")
        input("Pausing in LoadMotVec... (press Enter to continue)")

    # Reshape endpoints and centers
    Ep1 = Ep1.reshape((nMot, 2))
    Ep2 = Ep2.reshape((nMot, 2))
    Cen = Cen.reshape((nMot, 2))

    print(f"Loaded {nMot} vectors")

    return dclsMotVec( Ep1, Ep2, Cen, Mag, Dir, Dis,
                       nMot, idf, nRdg, nRiv, nEdg, nSkl, nRsg, nArc, nStr )
