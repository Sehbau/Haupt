% 
% Runs program mtxt1, for three frames and takes distances 1-2 and 1-3
%
% Plots correspondence for 1-2.
%
% af exsbFrame.m (in MtchVec)
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'MtchHst'

%% --------------------------------------------------------------
%                          DESC EXTR
%  --------------------------------------------------------------
% run descriptor extraction for three frames in directory MtchVec
fprintf('Descriptor extraction...');
cd( PthProg.mtchVec );
fipaFrm1 	= 'Imgs/Frm1.png';
fipaFrm2 	= 'Imgs/Frm2.png';
fipaFrm3 	= 'Imgs/Frm3.png';

fipsDsc1 	= 'Desc/Frm1';
fipsDsc2   	= 'Desc/Frm2';
fipsDsc3   	= 'Desc/Frm3';

if ispc
    fipsDsc1    = u_PathToBackSlash( fipsDsc1 );
    fipsDsc2    = u_PathToBackSlash( fipsDsc2 );
    fipsDsc3    = u_PathToBackSlash( fipsDsc3 );
end

ArgsDscx        = o_CmndArgs( 'dscx' );
ArgsDscx.opt    = '--saveBon';
v_CmndArgs( ArgsDscx );

OutDscx1    = RennDscx( fipaFrm1, fipsDsc1, ArgsDscx, PthProg.descExtr );
OutDscx2    = RennDscx( fipaFrm2, fipsDsc2, ArgsDscx, PthProg.descExtr );
OutDscx3    = RennDscx( fipaFrm3, fipsDsc3, ArgsDscx, PthProg.descExtr );

fprintf('Dscx fertig\n');

%% --------------------------------------------------------------
%                          MATCH
%  --------------------------------------------------------------
fprintf('Matching...');
cd( PthProg.mtchTxt );

dfLackBox   = 200;              % distance value when no match was possible

dirFrm      = '../MtchVec/Desc/';
fpSlc1      = [dirFrm 'Frm1.slc'];
fpSlc2      = [dirFrm 'Frm2.slc'];
fpSlc3      = [dirFrm 'Frm3.slc'];

mesIdf12    = 'Txt12';
mesIdf13    = 'Txt13';
fist12      = ['Mes/' mesIdf12];
fist13      = ['Mes/' mesIdf13];

cmnd12 = sprintf('mtxt1 %s %s %s %1.2f', fpSlc1, fpSlc2, fist12, dfLackBox );
cmnd13 = sprintf('mtxt1 %s %s %s %1.2f', fpSlc1, fpSlc3, fist13, dfLackBox );

if ispc 
    cmnd12 = u_PathToBackSlash( cmnd12 ); 
    cmnd13 = u_PathToBackSlash( cmnd13 ); 
end

%% --------   Execute & Load 1 vs 2   -----------
[Sts1 Out1] = system( cmnd12 );
v_CmndExec( Sts1, Out1, cmnd12, 1 );

Fina12      = o_FileNameMtxt1( 1, mesIdf12 );
M12         = LoadMeasMtxt1( Fina12 );

% geht nur, wenn auch Txa1/2 vertauscht sind
% NNMs12    = LoadFltTxtEof( 'Mes/Txt1NNMsCol.txt' );
% NNIx12    = LoadIntTxtEof( 'Mes/Txt1NNIxCol.txt' ) + 1;
% NNvl      = [NNMs12 single(NNIx12)];

%% --------   Execute & Load 1 vs 3   -----------
[Sts2 Out2] = system( cmnd13 );
v_CmndExec( Sts2, Out2, cmnd13, 1 );

Fina13      = o_FileNameMtxt1( 1, mesIdf13 );
M13         = LoadMeasMtxt1( Fina13 );

%% --------    Analyze   ---------
Wgt         = o_WgtTxtrMtch();

Des12       = dis_Txtr( M12, Wgt );
Des13       = dis_Txtr( M13, Wgt );

fprintf('\n');
fprintf('Txg  12: %7.2f  13: %7.2f\n', Des12.txgTot, Des13.txgTot );
fprintf('Bbox 12: %7.2f  13: %7.2f\n', Des12.bbx, Des13.bbx );
%

figMesTxtg  = 4;
%figMesFrkl  = 5;
figCorrsp   = 8;

%% ------------   Plot Metric Measurements Texturegrams  ----------------
LbTxtr      = o_TxtrLabels();
LbBand      = LbTxtr(1:7);

figure(figMesTxtg); clf; [nr,nc]=deal(3,2);

subplot(nr,nc,1);
bar([ M12.Txg.Snk M13.Txg.Snk ]);
set(gca,'xticklabel',{'12' '13'});
set(gca,'xticklabel', LbBand );
set(gca,'xlim',[0.4 7.6]);
ylabel('Distance');
title('Band Vertical');

subplot(nr,nc,2);
bar([ M12.Txg.Wag M13.Txg.Wag ]);
set(gca,'xticklabel', LbBand );
set(gca,'xlim',[0.4 7.6]);
title('Band Horizontal');

subplot(nr,nc,3);
bar([ M12.Txg.Grd M13.Txg.Grd ]);
set(gca,'xticklabel', LbBand );
set(gca,'xlim',[0.4 7.6]);
ylabel('Distance');
title('Grid');

subplot(nr,nc,4);
bar([ Des12.txgTot Des13.txgTot ]);
set(gca,'xticklabel',{'12' '13'});
set(gca,'xlim',[0.4 2.6]);
title('Total (Gram)');

subplot(nr,nc,5);
bar([ M12.Bbx.Dis M13.Bbx.Dis ]);
set(gca,'xticklabel', LbTxtr );
ylabel('Distance');
legend({'1vs2' '1vs3'});
title('Blob Bbox');

subplot(nr,nc,6);
bar([ Des12.bbx Des13.bbx ]);
set(gca,'xticklabel',{'12' '13'});
set(gca,'xlim',[0.4 2.6]);
title('Total (Blob)');


%% ------------   Plot Metric Measurements Freckles  ----------------
if 0
figure(figMesFrkl); clf; [nr,nc]=deal(3,2);

subplot(nr,nc,1);
bar([ M12.Frk.LayDff M13.Frk.LayDff ]);
set(gca,'xticklabel', LbBand );
set(gca,'xlim',[0.4 7.6]);
title('Lay');

subplot(nr,nc,2);
bar([ M12.Frk.Grd M13.Frk.Grd ]);
set(gca,'xticklabel', LbBand );
set(gca,'xlim',[0.4 7.6]);
title('Grid');

subplot(nr,nc,3);
bar([ M12.Frk.Snk M13.Frk.Snk ]);
set(gca,'xticklabel',{'12' '13'});
set(gca,'xticklabel', LbBand );
set(gca,'xlim',[0.4 7.6]);
ylabel('Distance');
title('Band Vertical');

subplot(nr,nc,4);
bar([ M12.Frk.Wag M13.Frk.Wag ]);
set(gca,'xticklabel', LbBand );
set(gca,'xlim',[0.4 7.6]);
title('Band Horizontal');

% ----- totals and ensembles -----
subplot(nr,nc*3,13);
bar([ Des12.frkLay Des13.frkLay ]);
title('Lay');

subplot(nr,nc*3,14);
bar([ Des12.frkGrd Des13.frkGrd ]);
title('Grid');

subplot(nr,nc*3,15);
bar([ Des12.frkSnk Des13.frkSnk ]);
title('Vertical');

subplot(nr,nc*3,16);
bar([ Des12.frkWag Des13.frkWag ]);
title('Horizontal');

subplot(nr,nc*3,17);
bar([ Des12.frkTot Des13.frkTot ]);
title('Tot Frk');
end


%% --------------------------------------------------------------
%                       CORRESPONDENCE
%  --------------------------------------------------------------
% We compare 1 versus 2.
fprintf('Correspondence for 1 vs 2 ...\n');

% -------------   Create one image   --------------
Ifrm1   = imread( [PthProg.mtchVec fipaFrm1] );
Ifrm2   = imread( [PthProg.mtchVec fipaFrm2] );
Iboth   = cat(2, Ifrm1, Ifrm2 );
[ihgt iwth nCh] = size( Ifrm1 );

% ------------    Load Saliency Files   -------------
Fixt    = o_FileExtensions();
SLC1    = LoadDescSalc( fpSlc1 );
SLC2    = LoadDescSalc( fpSlc2 );
Txa1    = SLC1.Txa;
Txa2    = SLC2.Txa;
Blb1    = SLC1.Blb.Box;
Blb2    = SLC2.Blb.Box;

% shift bboxes of 2nd frame to the right
Blb2.Box(:,3) = Blb2.Box(:,3) + iwth;
Blb2.Box(:,4) = Blb2.Box(:,4) + iwth;

Cen1    = u_BboxCen( Blb1.Box );
Cen2    = u_BboxCen( Blb2.Box );

% ---------------   Plot   -------------
figure(figCorrsp); clf;
imagesc( Iboth ); hold on;

if 0
    p_BlobBboxes( Blb1 );   % plot all
    p_BlobBboxes( Blb2 );
end

ColBias = u_ColBlob();

for b = 1:Blb1.nBox
    
    dis     = M12.NNMs(b);
    
    % a value of 99 means no match found (invalid)
    if dis==99, continue; end    % no match
    
    ix      = M12.NNIx(b);
    
    typ     = Blb1.Typ(b);
    col     = ColBias(typ,:);
    
    p_BboxL( Blb1.Box( b, :), col );    % left side
    
    p_BboxL( Blb2.Box( ix, :), col );   % rite side
    
    % bounding box centers (verification)
    %plot( Cen1.Cl(b),  Cen1.Rw(b), '*' );
    %plot( Cen2.Cl(ix), Cen2.Rw(ix), '*' );
    
    % correspondence line:
    hl = line( [Cen1.Cl(b) Cen2.Cl(ix)], [Cen1.Rw(b) Cen2.Rw(ix)] );
    set( hl, 'linewidth', 4-dis*2 );
    
    
end






