% 
% Runs program mtxt1, for three frames and takes distances 1-2 and 1-3
%
% Plots correspondence for 1-2.
%
% af exsbFrame.m (in MtchVec)
%
clear;
run('../AdminMb/globalsSB'); % assumes script is run from dir 'MtchHst'

%% --------------------------------------------------------------
%                          DESC EXTR
%  --------------------------------------------------------------
% run descriptor extraction for three frames in directory MtchVec
fprintf('Descriptor extraction...');
cd( PthProg.mtchVec );
fipaFrm1 	= 'Imgs/Frm1.png';
fipaFrm2 	= 'Imgs/Frm2.png';
fipaFrm3 	= 'Imgs/Frm3.png';

fipsDsc1 	= 'Desc/Frm1';
fipsDsc2   	= 'Desc/Frm2';
fipsDsc3   	= 'Desc/Frm3';

if ispc
    fipsDsc1    = u_PathToBackSlash( fipsDsc1 );
    fipsDsc2    = u_PathToBackSlash( fipsDsc2 );
    fipsDsc3    = u_PathToBackSlash( fipsDsc3 );
end

ArgsDscx        = o_CmndArgs( 'dscx' );
ArgsDscx.opt    = '--saveBon';
v_CmndArgs( ArgsDscx );

OutDscx1    = RennDscx( fipaFrm1, fipsDsc1, ArgsDscx, PthProg.descExtr );
OutDscx2    = RennDscx( fipaFrm2, fipsDsc2, ArgsDscx, PthProg.descExtr );
OutDscx3    = RennDscx( fipaFrm3, fipsDsc3, ArgsDscx, PthProg.descExtr );

fprintf('Dscx fertig\n');

%% --------------------------------------------------------------
%                          MATCH
%  --------------------------------------------------------------
fprintf('Matching...');
cd( PthProg.mtchTxt );

dfLackBox   = 200;              % distance value when no match was possible

dirFrm      = '../MtchVec/Desc/';
fpSlc1      = [dirFrm 'Frm1.slc'];
fpSlc2      = [dirFrm 'Frm2.slc'];
fpSlc3      = [dirFrm 'Frm3.slc'];

mesFil12    = 'Mes/Txt12';
mesFil13    = 'Mes/Txt13';

cmnd12 = sprintf('mtxt1 %s %s %s %1.2f', fpSlc1, fpSlc2, mesFil12, dfLackBox );
cmnd13 = sprintf('mtxt1 %s %s %s %1.2f', fpSlc1, fpSlc3, mesFil13, dfLackBox );

if ispc 
    cmnd12 = u_PathToBackSlash( cmnd12 ); 
    cmnd13 = u_PathToBackSlash( cmnd13 ); 
end

%% --------   Execute & Load 1 vs 2   -----------
[Sts1 Out1] = system( cmnd12 );
v_CmndExec( Sts1, Out1, cmnd12, 1 );

FinaMes     = o_FileNameMeas( 1 );
Fina12      = o_FileNameMeas( mesFil12 );

% --- Grams ---
DfGrid12    = LoadFltTxtEof( Fina12.txtGrid );
% single value (sum of snk and wag)
dfBand12    = LoadFltTxtEof( Fina12.txtBand ); 

DfBand12Snk = LoadFltTxtEof( FinaMes.txtBandSnk );
DfBand12Wag = LoadFltTxtEof( FinaMes.txtBandWag );

% --- Blobs ---
DfBlob12    = LoadFltTxtEof( Fina12.txtBlob ); % array
NNMs12      = LoadFltTxtEof( FinaMes.txtNNMsRow );
NNIx12      = LoadIntTxtEof( FinaMes.txtNNIxRow ) + 1;
% geht nur, wenn auch Txa1/2 vertauscht sind
% NNMs12    = LoadFltTxtEof( 'Mes/Txt1NNMsCol.txt' );
% NNIx12    = LoadIntTxtEof( 'Mes/Txt1NNIxCol.txt' ) + 1;

% NNvl      = [NNMs12 single(NNIx12)];

%% --------   Execute & Load 1 vs 3   -----------
[Sts2 Out2] = system( cmnd13 );
v_CmndExec( Sts2, Out2, cmnd13, 1 );

Fina13      = o_FileNameMeas( mesFil13 );

% --- Grams
DfGrid13    = LoadFltTxtEof( Fina13.txtGrid );
DfBand13Snk = LoadFltTxtEof( FinaMes.txtBandSnk );
DfBand13Wag = LoadFltTxtEof( FinaMes.txtBandWag );

% --- Blobs
DfBlob13    = LoadFltTxtEof( Fina13.txtBlob );

%% --------    Analyze   ---------
Wgt         = o_WgtTxtrMtch();

dfTxtg12    = DfGrid12'    * Wgt.Grid + ...
              DfBand12Snk' * Wgt.Band + ...
              DfBand12Wag' * Wgt.Band;
          
dfTxtg13    = DfGrid13'    * Wgt.Grid + ...
              DfBand13Snk' * Wgt.Band + ...
              DfBand13Wag' * Wgt.Band;

dfBlob12    = DfBlob12' * Wgt.Blob ;
dfBlob13    = DfBlob13' * Wgt.Blob ;

fprintf('Mes 12: %1.3f  13: %1.3f\n', dfBlob12, dfBlob13);

figMes      = 3;
figCorrsp   = 4;

%% ------------   Plot Metric Measurements   ----------------
LbTxtr      = o_TxtrLabels();
LbBand      = LbTxtr(1:7);

figure(figMes); clf; [nr,nc]=deal(3,2);

subplot(nr,nc,1);
bar([ DfBand12Snk DfBand13Snk ]);
set(gca,'xticklabel', LbBand );
set(gca,'xlim',[0.4 7.6]);
title('Band Vertical');

subplot(nr,nc,2);
bar([ DfBand12Wag DfBand13Wag ]);
set(gca,'xticklabel', LbBand );
set(gca,'xlim',[0.4 7.6]);
title('Band Horizontal');

subplot(nr,nc,3);
bar([ DfGrid12 DfGrid13 ]);
set(gca,'xticklabel', LbBand );
set(gca,'xlim',[0.4 7.6]);
title('Grid');

subplot(nr,nc,4);
bar([dfTxtg12 dfTxtg13]);
set(gca,'xticklabel',{'12' '13'});
set(gca,'xlim',[0.4 2.6]);
title('Total (Gram)');

subplot(nr,nc,5);
bar([ DfBlob12 DfBlob13 ]);
set(gca,'xticklabel', LbTxtr );
ylabel('Difference');
legend({'1vs2' '1vs3'});
title('Bias');

subplot(nr,nc,6);
bar([dfBlob12 dfBlob13]);
set(gca,'xticklabel',{'12' '13'});
set(gca,'xlim',[0.4 2.6]);
title('Total (Blob)');

%% --------------------------------------------------------------
%                       CORRESPONDENCE
%  --------------------------------------------------------------
% We compare 1 versus 2.
fprintf('Correspondence for 1 vs 2 ...\n');

% -------------   Create one image   --------------
Ifrm1   = imread( [PthProg.mtchVec fipaFrm1] );
Ifrm2   = imread( [PthProg.mtchVec fipaFrm2] );
Iboth   = cat(2, Ifrm1, Ifrm2 );
[ihgt iwth nCh] = size( Ifrm1 );

% ------------    Load Saliency Files   -------------
Fixt    = o_FileExtensions();
SLC1    = LoadDescSalc( fpSlc1 );
SLC2    = LoadDescSalc( fpSlc2 );
Txa1    = SLC1.Txa;
Txa2    = SLC2.Txa;

% shift bboxes of 2nd frame to the right
Txa2.Blb.Box(:,3) = Txa2.Blb.Box(:,3) + iwth;
Txa2.Blb.Box(:,4) = Txa2.Blb.Box(:,4) + iwth;

Cen1    = u_BboxCen( Txa1.Blb.Box );
Cen2    = u_BboxCen( Txa2.Blb.Box );

% ---------------   Plot   -------------
figure(figCorrsp); clf;
imagesc( Iboth ); hold on;

if 0
    p_BlobBboxes( Txa1.Blb );   % plot all
    p_BlobBboxes( Txa2.Blb );
end

ColBias = u_ColBlob();

for b = 1:Txa1.Blb.nBox
    
    dis     = NNMs12(b);
    
    % a value of 99 means no match found (invalid)
    if dis==99, continue; end    % no match
    
    ix      = NNIx12(b);
    
    typ     = Txa1.Blb.Typ(b);
    col     = ColBias(typ,:);
    
    p_BboxL( Txa1.Blb.Box( b, :), col );    % left side
    
    p_BboxL( Txa2.Blb.Box( ix, :), col );   % rite side
    
    % bounding box centers (verification)
    %plot( Cen1.Cl(b),  Cen1.Rw(b), '*' );
    %plot( Cen2.Cl(ix), Cen2.Rw(ix), '*' );
    
    % correspondence line:
    hl = line( [Cen1.Cl(b) Cen2.Cl(ix)], [Cen1.Rw(b) Cen2.Rw(ix)] );
    set( hl, 'linewidth', 4-dis*2 );
    
    
end






