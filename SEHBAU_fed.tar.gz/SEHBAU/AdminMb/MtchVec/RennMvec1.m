%
% Wrapper routine for program mvec1
%
% sa RennDscx.m
% 
% IN    pthDsc1 description file 1, .dsc | .dsf
%       pthDsc2 description file 2, .dsc | .dsf
%       Args   	arguments (o_CmndArgs) 
% OUT   Out     standard output
% 
function [Out] = RennMvec1( pthDsc1, pthDsc2, Args, pthProg )

if nargin==3, 
    pthProg = ''; 
end
fpProg  = [pthProg 'mvec1'];

if exist( fpProg, 'file')==2,
    error('Program path not correct: %s', fpProg);
end

% ensure order of parameter file and measurement file
if ~isempty( Args.fpPrm )

    cmnd = [ fpProg ' ' pthDsc1 ' ' pthDsc2 ' ' Args.fpPrm ...
             ' ' Args.fpMes ' ' Args.opt ];
else
    
    cmnd = [ fpProg ' ' pthDsc1 ' ' pthDsc2 ' ' Args.fpMes ...
             ' ' Args.opt ];
end

[status Out] = system( cmnd );            % excecute program

%% ------  Status  ------
if status>0
    Out
    warning('Command %s returns exit code > 0 (see Out above)', cmnd);
end

%% ------  Verify Proper Termination  -----
ixEOP = strfind(Out,'EndOfProgram');
if isempty(ixEOP)
    warning('Command %s not executed. See Out below', cmnd);
    Out
    LoadDescImag( pthDsc2 );
    fprintf('paused'); pause();
end


