%
% Filepaths for binary mvecL.
%
% For options and parameters see o_MvecArgs.m
%
% sa o_CascIdfPth
%
function [P] = o_MvecAdmin( pthOpr )

if nargin==0
    pthOpr = '';
end

P.fpMesVec      = [ pthOpr 'Mes/TotVec.txt'];

P.fpMesDtyDis   = [ pthOpr 'Mes/MesDtyDis.txt']; % unchangeable
P.fpMesDtySim   = [ pthOpr 'Mes/MesDtySim.txt']; % unchangeable

%P.pthPrm        = [ pthOpr 'Params/' ];
%P.pthRgs        = [ pthOpr 'Regist/' ];

P.pthProg       = pthOpr;



