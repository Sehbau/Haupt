%
% Plots motion vectors, by simply connecting the two endpoints.
%
% IN    V     struct with vectors
%       bRad  radial option. Will subtract starting point
%
function [] = PlotMotVec( V, bRadial )

if nargin==1
    bRadial = 0;
end

colLine = [0.7 0.7 0.7];

Rw1     = V.Ep1(:,1);
Cl1     = V.Ep1(:,2);
Rw2     = V.Ep2(:,1);   
Cl2     = V.Ep2(:,2);

% -----   Radial Plotting   -----
if bRadial
    % we overwrite Rw2 and Cl2
    Rw2  = V.Ep2(:,1) - Rw1;
    Cl2  = V.Ep2(:,2) - Cl1;
end

% ----------   Loop Vectors   ----------
for m = 1:V.nMot
    
    %dir     = V.Dir(m);
    %mag     = V.Mag(m);
    
    %if mag>0.05, continue; end
    
    %if dir < 1.2  ||  dir > 2.6, continue; end

    if bRadial
        plot( [0 Cl2(m)], [0 Rw2(m)], 'color', colLine );
    else
        
        plot( [Cl1(m) Cl2(m)], [Rw1(m) Rw2(m)], 'color', colLine );

        % starting point
        plot( Cl1(m), Rw1(m),  ['r.'], 'markersize', 3); 
    end
    
end