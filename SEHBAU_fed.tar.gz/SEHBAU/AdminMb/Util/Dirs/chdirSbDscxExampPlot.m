function [] = chdirSbDscxExampPlot()
    chdir('c:/klab/ppc/SEHBAU/AdminMb/DescExtr/Examples/');
end

