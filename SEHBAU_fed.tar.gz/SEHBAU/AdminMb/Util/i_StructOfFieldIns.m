%
% Insert an object to each field of S.
%
% Not utilized yet.
%
% EXAMPLE
%
function [ S ] = i_StructOfFieldIns( S, Obj )

aFldNa   = fieldnames( S );
nFldNa   = length( aFldNa );

for f = 1:nFldNa
    fn          = aFldNa{f};
    S.(fn).(nf) = Obj;
end

end

