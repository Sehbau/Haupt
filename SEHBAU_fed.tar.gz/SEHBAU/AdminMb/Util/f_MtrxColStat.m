%
% Statistics for the columns of a matrix.
%
% af f_ArrStat.m
%
function [S] = f_MtrxColStat( M )

S.Men   = mean( M, 1 );
S.Min   = min( M, [], 1 );
S.Max   = max( M, [], 1 );
S.Rng   = S.Max - S.Min;    

end

