%
% Reads a textfile linewise.
%
% sa LoadTextLineWise.m
%
function [aLines cL] = ReadTextLineWise( fileID ) 

aLines  = cell(0,1);

tline   = fgetl(fileID);        % read first line
cL      = 0;
while ischar(tline)
    
    cL = cL+1;
    aLines{cL} = tline;

    tline = fgetl(fileID);
end

end


