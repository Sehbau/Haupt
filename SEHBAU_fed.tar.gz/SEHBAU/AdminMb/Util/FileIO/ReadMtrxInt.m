%
% Same as ReadMtrxFlt but for integer.
%
% Used for reading bins and histograms.
%
% cf ReadShpHist.m, ReadArcBinUni.m
% af ReadMtrxFlt.m
%
function [ARR szD] = ReadMtrxInt( fid )
error('deprectaed');
%% ----------   Header   ----------
nFet    = fread(fid, 1, 'uint8=>int'); % number of features
nObs    = fread(fid, 1, 'int=>int');   % number of observations

%% ----------   Matrix   ----------
ARR     = fread(fid, nObs * nFet, 'int32=>single'); 

%% ----------   reshape   ----------
ARR     = reshape(ARR, [nObs nFet]);

szD.nFet = nFet;
szD.nObs = nObs;

end

