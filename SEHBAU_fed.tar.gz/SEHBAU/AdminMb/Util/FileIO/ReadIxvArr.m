%
% Index array with value (float)
% 
% Reads as saved under w_IxvArr
%
% We make it one-indexing for Matlab. 
%
function [S] = ReadIxvArr(fileID) 

S.nEnt   = fread( fileID,      1, 'int=>int' );
S.Ix     = fread( fileID, S.nEnt, 'int=>int' ) + 1; 
S.Vl     = fread( fileID, S.nEnt, 'float=>single' ); 
