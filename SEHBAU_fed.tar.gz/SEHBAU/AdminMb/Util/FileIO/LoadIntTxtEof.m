%
% Loads a single array of ints (written as text) until end-of-file, ie.
% as saved as in st_ArrInt.
%
function [A] = LoadIntTxtEof( lfn ) 

fid	= fopen(lfn, 'r');
if (fid<0), error('file %s not found', lfn); end

A   = fscanf( fid, '%d' );

A   = int32( A );

fclose(fid);


