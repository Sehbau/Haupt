%
% Map retrieval: converts maps that were saved linearly, to original matrix
% format. Assumes arrays are of same size.
%
% Technically: turns a structure of arrays into a structure of maps.
%
% cf LoadTxtrMaps.m
% sa u_MtrxToStcArr.m
%
function [R] = u_StcArrToStcMap( R, szM )

aFldNa  = fieldnames( R );
nFld    = length(aFldNa);

for f = 1:nFld
    fn      = aFldNa{f};
    R.(fn)  = permute( reshape( R.(fn), szM([2 1])), [2 1] );
end

end

