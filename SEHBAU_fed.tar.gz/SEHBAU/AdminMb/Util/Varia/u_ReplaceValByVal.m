%
% Replace one value by another, vector or matrix.
%
function [ V ] = u_ReplaceValByVal( V, trg, rpl )

if isvector( V )
    
    Bdet    = V==trg;
    V(Bdet) = rpl;
    
elseif ismatrix( V )

    [nRow nCol] = size( V );

    for r = 1:nRow
        Bdet =  V(r,:)==trg ;
        V(r,Bdet) = rpl;
    end
else
    error('not implemented for this type of input');
end

end

