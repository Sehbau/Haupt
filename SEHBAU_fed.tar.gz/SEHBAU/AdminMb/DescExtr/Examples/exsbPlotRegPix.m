%
% Saving and plotting region pixels.
%
clear;
run('../../../AdminMb/globalsSB');      % assumes script is run from dir 'Demos'
    
strImg      = 'aachen.png';

fipaImg     = [ PthProg.descExtr 'Imgs/' strImg];         % image path
fipsOut     = [ PthProg.descExtr 'Desc/' strImg(1:end-4)]; % output filestem

% change to window backslash (in case we are on windows)
if ispc
    fipaImg  = u_PathToBackSlash( fipaImg ); 
    fipsOut  = u_PathToBackSlash( fipsOut ); 
end

%% --------   Options   --------
OptK            = o_DscxArgs();
OptK.nLev       = 4 ;
OptK.saveRpx    = 1 ;    
optS            = i_DscxArgs(OptK);

%% =========   Command   ========
cmnd        = [ FipaExe.dscx ' ' fipaImg ' ' fipsOut ' ' optS];

if ispc
    [Sts Out] = dos(cmnd);      % excecute program for windows
elseif isunix
    [Sts Out] = unix(cmnd);     % excecute program for unix
end

v_CmndExec( Sts, Out, cmnd, 1 );

%% -------   Load Region Pixels   -------
Fixt            = o_FileExtensions();

[AREG KtReg] 	= LoadRegPix(   [fipsOut Fixt.regPix] );
[DSC Kt Hed] 	= LoadDescImag( [fipsOut Fixt.dsc] );    

if Hed.space==2,
    warning('not implemented yet for scale space');
end

%% ------    Plot    ---------
Irgb         	= imread( fipaImg );
szI         	= [ Hed.szV Hed.szH ];

figure(1); clf; 
imagesc( Irgb );

figure(2); clf; 
PlotRegPix( AREG, szI );

figure(3); clf; 
PlotRegPix( AREG, szI, 'gray' );




