%
% Loads the saliency array, [nImg nAsp], as collected with program
% collsalc. Does not verify file extension.
%
% As saved in C under E_DESC/CollSalc/CollSalcIO.h
%
function [SLC Dim] = LoadCollSalc( pthFile )

fileID      = fopen(pthFile, 'r');
if fileID<0, 
    error('could not open %s.', pthFile); 
end

%% -------   Header (Size)   --------
nImg        = fread(fileID, 1,  'int=>int');
nAsp        = fread(fileID, 1,  'int=>int');
fprintf('[%d %d]\n', nImg, nAsp);

%% -------   Data Matrix   --------
SLC         = fread( fileID, nImg*nAsp, 'float=>single');
SLC         = reshape(SLC, nAsp, nImg)';

fclose(fileID);

Dim.nImg    = nImg;
Dim.nAsp    = nAsp;

DispLoad(pthFile);

end

