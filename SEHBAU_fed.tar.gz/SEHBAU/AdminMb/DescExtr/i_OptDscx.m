% 
% Creates long-option string arguments for program dscx.
%
% IN    O   argument structure with fields set by user, ie. u_OptDscxStc.m
% OUT   S   arguments as string 
%
function S = i_OptDscx( O )

error('deprecated:  use i_DscxArgs now');

%% -----  Verify Fieldnames  ------
aFldn       = fieldnames(O);
nFldFound   = length(aFldn);

if O.nFld~=nFldFound, 
    fprintf('too many fields present somehow\n');
    O
    fprintf('pausing');
end


%% -----  Extraction/Saving  -----
S = '';
if O.saveRRE>0,   S = [S ' --saveRRE'];  end
if O.saveCVP>0,   S = [S ' --saveCVP'];  end
if O.saveKol>0,   S = [S ' --saveKol'];  end
if O.saveProp>0,  S = [S ' --saveProp'];  end

if O.saveRpx>0,   S = [S ' --saveRpx'];  end
if O.saveBbox>0,  S = [S ' --saveBbox'];  end
if O.saveBon>0,   S = [S ' --saveBon'];   end


%% -----  Archit  -----
if O.nLev>-1,
    assert(O.nLev>0 && O.nLev<10);
    S = [S ' --nLev ' num2str(O.nLev)];
end
if O.depth>-1,
    assert(O.depth>0 && O.depth<5);
    S = [S ' --depth ' num2str(O.depth)];
end
if O.is>-1,
    assert(O.is>0 && O.is<3);
    S = [S ' --is ' num2str(O.is)];
end

