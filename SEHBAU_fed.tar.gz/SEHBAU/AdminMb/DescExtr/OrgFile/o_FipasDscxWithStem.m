% 
% DEP
%
function S = o_FipasDscxWithStem( stm, Fixt )

warning('deprecated. use o_FinaApndExtDscx');

o_FinaApndExtDscx( stm, Fixt );

end

