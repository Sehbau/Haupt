%
% File extensions for vector types.
%
% sa o_FileExtensions.m
%    o_DescTypes.m
%
function [E nExt] = o_FileExtensVect()

E.cnt  = '.vecCnt';
E.rsg  = '.vecRsg';
E.arc  = '.vecArc';
E.str  = '.vecStr';
E.shp  = '.vecShp';

E.bnd  = '.vecBnd';
E.ttg  = '.vecTtg';

E.aFna = fieldnames( E );
E.n    = length( E.aFna );

% as arrays without dot
E.aVec  = {'vecCnt' 'vecRsg' 'vecArc' 'vecStr' 'vecShp'...
           'vecTtg' 'vecBnd' };

E.aVbn  = {'vbnCnt' 'vbnRsg' 'vbnArc' 'vbnStr' 'vbnShp'...
           'vbnTtg' 'vbnBnd' };

E.aLev = {'levCnt' 'levRsg' 'levArc' 'levStr' 'levShp'...
          'levTtg' 'levBnd' };
      
nExt = length( E.aVec );      
