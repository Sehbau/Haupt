%
% Reads RGB spread as written with w_RgbSpread in RgbUtil.h
%
% cf ReadDescStats.m
%
function [S] = ReadRgbSpread( fid )

S.bunt    = fread( fid, 1, 'float=>single' );

S.minRo   = fread( fid, 1, 'float=>single' );
S.minGo   = fread( fid, 1, 'float=>single' );
S.minBo   = fread( fid, 1, 'float=>single' );

end

