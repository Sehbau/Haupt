%
% Reads space of contour attributes as saved under CntIO.h-w_CntSpc
%
function [ACNT Ncnt] = ReadCntSpc(fid)

[nLev Ncnt] = ReadDescSpcHead( fid );

ACNT  = cell(nLev,1);
for l = 1:nLev
    
    [ACNT{l} nCnt] = ReadCntAtt(fid);
    
    assert( Ncnt(l)==nCnt, 'contour count not matching' );
    
end

end

