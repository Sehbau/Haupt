%
% Reads radsig bins as saved under ArcIObin.h-w_ArcBin1D
%
function [S nArc] = ReadArcBinUni(fileID)

%%  ====================   Header   ====================
nArc    = fread( fileID, 1, 'int=>single'); % # descriptors

%%  ====================   Data   ====================
Lb      = {'Les' 'Krv' 'Dir' 'Spz' 'Eck' 'Run' 'Ifx' 'Red' 'Grn' 'Blu'};
S       = ReadStcArr( fileID, 'int32=>single', Lb );
S.nArc  = nArc;

end

