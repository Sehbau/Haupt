%
% Reads space of str attributes as saved under StrIO.h-w_StrSpc
%
function [AUNI NStr] = ReadStrBinSpc(fid)

nLev  = fread(fid, 1,    'int=>int');      % # of levels

AUNI  = cell(nLev,1);
ABIV  = cell(nLev,1);
for l = 1:nLev
    
    % ReadStrBinXXX not in use yet. Using contours
    [AUNI{l} nStr1] = ReadCntBinUni(fid); % same as for contours
    [ABIV{l} nStr2] = ReadCntBinBiv(fid); % same as for contours
    
    assert( nStr1==nStr2, 'straighter count not matching' );
        
    S.APOSA{l}    = ReadAttPos( fid, 'float=>single' );
    S.APOSQ{l}    = ReadAttPos( fid, 'uint8=>uint8' ); 
end

end

