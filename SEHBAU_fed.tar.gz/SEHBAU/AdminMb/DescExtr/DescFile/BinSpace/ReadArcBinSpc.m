%
% Reads space of arc attributes as saved under ArcIO.h-w_ArcSpc
%
function [AUNI Narc] = ReadArcBinSpc(fid)

nLev    = fread(fid, 1,    'int=>int');      % # of levels

AUNI    = cell(nLev,1);
ABIV    = cell(nLev,1);
Narc    = zeros( nLev, 1 );
for l = 1:nLev
    
    [AUNI{l} nArc1] = ReadArcBinUni(fid);
    [ABIV{l} nArc2] = ReadArcBinBiv(fid);
    
    assert( nArc1==nArc2, 'contour count not matching' );
    
    Narc(l)     = nArc1;

    S.APOSA{l}    = ReadAttPos( fid, 'float=>single' );
    S.APOSQ{l}    = ReadAttPos( fid, 'uint8=>uint8' );  
end

end

