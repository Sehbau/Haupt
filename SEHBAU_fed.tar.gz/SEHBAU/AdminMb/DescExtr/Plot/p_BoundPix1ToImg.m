%
% Plots a single boundary to image (axis ij).
%
% For plotting to x/y plot, see p_BoundPix1ToPlot
%
function hp = p_BoundPix1ToImg( Pix, col, liwi, bJit )

if nargin==3, bJit=0;  end % if jitter not specified, then OFF

% add some jitter to avoid overlap 
if bJit>0, off = ( rand(1)-0.5 ) * bJit;
else       off = 0; end
    
% from zero to one-indexing adding 1.0
hp = plot( single(Pix.Cl)+off, single(Pix.Rw)+off, '-');

set(hp, 'color', col);          % default color. might be overwritten
set(hp, 'linewidth', liwi );

end

