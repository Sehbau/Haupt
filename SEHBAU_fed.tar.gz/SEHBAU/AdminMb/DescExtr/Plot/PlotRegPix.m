%
% Plots region pixels as color by default or as gray-scale if specified
% with third argument
% 
function [] = PlotRegPix( AREG, SzM, bGray )

if nargin==2
    bGray = 0;
else
    bGray = strcmp( bGray, 'gray');
end

[nLev depth] = size( AREG );

%% -----   Compute Map Sizes   -------
% we compute pyramid. scale space would use same size for all maps.
if length(SzM)<=3

    szI     = SzM;
    SzM     = zeros( nLev, 2 );
    SzM(1,:) = szI(1:2);
    for l = 2:nLev
        SzM(l,:) = SzM(l-1,:) / 2;
    end
end

%% -----   Plot Pixels   ------
[nr nc]     = deal(nLev, depth);    % # of rows/cols for subplots
for l = 1:nLev
    
    szI         = SzM(l,:);
    [szV, szH]   = deal( szI(1), szI(2) );

    for d = 1:depth
        
        REG     = AREG{ l, d };
        nCC     = REG.nCC;
    
        nPxMap = szV*szH;
        
        % --- init dimension as in C
        Mgry   = zeros( szH, szV, 'uint8');
        Irgb   = zeros( szH, szV, 3, 'uint8');
        
        for c = 1:nCC
            
            anf     = REG.Anf(c);         % starting index
            trm     = REG.Anf(c+1)-1;     % terminating index
            %fprintf('%d-%d  %d\n', anf, enf, enf-anf );
            
            red     = REG.RGB(c,1);
            grn     = REG.RGB(c,2);
            blu     = REG.RGB(c,3);
            
            gry     = red*0.2989 + grn*0.5870 + blu*0.1140;
            
            % ----  Mgry:
            Mgry( REG.IxLin( anf:trm ) ) = gry;
            
            % ----  Irgb: we add color
            Irgb( REG.IxLin( anf:trm ) )            = uint8(red);
            Irgb( REG.IxLin( anf:trm ) + nPxMap )   = uint8(grn);
            Irgb( REG.IxLin( anf:trm ) + nPxMap*2 ) = uint8(blu);
            
        end
        
        % from C to matlab
        Mgry    = flipud( Mgry' );       
        Irgb    = rot90( Irgb );
        
        % -----------   Plot   -------------
        subplot(nr, nc, depth * (l-1) + d ); hold on;
        if bGray
            imagesc(Mgry); colormap(gray);
        else
            imagesc(Irgb);
        end
        
        axis tight;
        set(gca,'fontsize',5);
        if l==1, title( ['depth ' num2str(d)], 'fontsize', 12); end
        if d==1, ylabel(['Lev = ' num2str(l)], 'fontsize', 12); end
    end
    
end