
error('use p_BoundPixLij or p_BoundPixLxy' );

