%
% Concatenates bin-vectors for a collection of images for ONE desctype.
%
% Variables fpstDbn and IxImg work if fpstDbn is constant (ie. 'DSC') and
% image names distinguish by themselves by number only (ie.
% 'DSC1','DSC2'...).
% 
% cf iclCatDbnVmx.m
%
% IN    fpstDbn     path+filestem for textfile holding bin-vector matrix
%       IxImg       image indices
%       fextDty     extension, 'vbnCnt'
%       neDsc       estimated no. of desriptors to be collected
%
function COLL = f_CollBinDty( fpstDbn, IxImg, fextDty, neDsc )

nImg    = length(IxImg);

fprintf('%s   %s   %s\n', repelem('-',30), fextDty, repelem('-',30) );

COLL.BIN    = [];       % init is below (i==1)
ctV         = 0;        % count total number of vectors
for i = 1:nImg

    ixStr   = num2str( IxImg(i) );

    % -----  load  -----
    fipa    = [ fpstDbn ixStr ];

    [VMX Dim] = LoadDescVebn( [fipa '.' fextDty ], i==1 );

    nDsc    = Dim.nDsc;
    nAtt    = Dim.nAtt;
    
    % we might face NAN that cannot be read by sscanf:
    % we then try with num2str instead
    if nDsc<0, 
        [VMX nDsc] = f_SscanfVectMxWithNan( VMX, nAtt );
    end    

    %nLev    = length(BIN.CNT);

    % -----  init / append  -----
    if i==1
        COLL.BIN = zeros( neDsc, nAtt, 'uint8');
    end
    
    COLL.BIN(   ctV+(1:nDsc), : ) = VMX;
    %COLL.LbLev( ctV+(1:nDsc) )    = Lb.(dty);
    ctV     = ctV + nDsc;

    if i==1
        nAttc = size(COLL.BIN,2);
        assert( nAtt==nAttc, ...
            'Attribute size not matching: expected %d, is %d', nAtt, nAttc);
    end
    
    if mod(i,round(nImg/40))==0, fprintf('.'); end
    
end
fprintf('ntBinVec  %7d\n', ctV );

% --- trim to actual
COLL.BIN    = COLL.BIN(1:ctV, :);      
%COLL.LbLev  = COLL.LbLev(1:ctV);      
COLL.ntV    = ctV;

end






