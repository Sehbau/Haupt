%
% Generates quant id for the descriptor types of an entire image.
%
% cf plcQntHist.m
% 
% IN  VEB   struct with VEB for each desctype
%     Q     quant universe
% OUT V     quant ids
%
function V = f_HashBinImg( VEB, Q )

V.Cnt  = f_HashVbnMx( VEB.Cnt, Q.CNT.HashBase, Q.CNT.QntHsh );
V.Rsg  = f_HashVbnMx( VEB.Rsg, Q.RSG.HashBase, Q.RSG.QntHsh );
V.Arc  = f_HashVbnMx( VEB.Arc, Q.ARC.HashBase, Q.ARC.QntHsh );
V.Str  = f_HashVbnMx( VEB.Str, Q.STR.HashBase, Q.STR.QntHsh );
V.Shp  = f_HashVbnMx( VEB.Shp, Q.SHP.HashBase, Q.SHP.QntHsh );

%V.Crm  = f_HashVbnMx( VEB.Crm, Q.CRM.HashBase, Q.CRM.QntHsh );
    
end






