%
% Calculates the scale factors for scaling coordinates from level to layer.
%
% IN   szLev   level, ie. original image resolution
%      szLay   layer (size of texture map)
%
function [S] = f_LevToLaySclFct( szLev, szLay )

% we subtract one due to the shift from zero- to one-indexing
S   = single( szLay-1 ) ./ single( szLev-1 );

end

