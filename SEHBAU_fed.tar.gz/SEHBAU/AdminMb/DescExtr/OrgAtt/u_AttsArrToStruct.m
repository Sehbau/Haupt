%
% Turns an array of attributes Arr [nDsc nAtt] into a struct with fields
% as specified by aAttNames.
%
% ai cc_ovoT.m, f_Shp
%
% NOT WELL ORGANIZED: better use u_MtrxToStcArr
%
% IN   Arr        [nDsc nAtt]
%      aAttNames  attribute names, ie. 'Vrt', 'Hor', ...
% OUT  S          struct with fields .Vrt, .Hor, ...each one [nDsc 1]
%
function [S] = u_AttsArrToStruct( ARR, aAttNames )

[nDsc nAtt]   =  size(ARR);
[nFld lenFld] = size(aAttNames);

assert( nAtt==nFld, 'nAtts/nFlds not matching: %d <> %d', nAtt, nFld );

%% -------   Change Labels from Char to List   --------
if lenFld==6
    aAttTxt   = aAttNames;
    aAttNames = cell(nFld,1);
    for f = 1:nFld
        lab  = aAttTxt(f,:);
        Bspc = isspace( lab );
        lab  = lab( ~Bspc );
        aAttNames{f} = lab;
    end
end

%% --------    Matrix to List   ----------
% better deploy u_MtrxToStcArr
S = struct;
for i = 1:nFld
    % aAttNames{i}
    S.( aAttNames{i} ) = ARR(:,i);
end
    
end

