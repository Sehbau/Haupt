%
% Attribute names (labels) for a bin-vector. 
%
% See o_AttsLabels for more info.
%
% cf LoadDescVect.m, LoadCollVec.m
%
function [LB Lshp] = o_AttsLabBin()


%% ----------   contour   ---------  6
% wt_CntVbn, CntIObin.h
LB.Cnt = {'len' 'str' 'ori' 'red' 'grn'   'blu'};
LB.Skl = LB.Cnt;

%% ----------   radial signature   ----------  4 + 3 + 6
% wt_RsgVbn, RsgIObin.h
%  int  **Adr[nFld] = {  &Rds, &Elo, &Cir, &Ori,
%			&Red, &Grn, &Blu,
%			&Cncv, &Bis1, &Bis2, &Bis3, &Bis4, &Bis5 };  

LB.Rsg = {'rad' 'elo' 'cir' 'ori' 'red'   'grn' 'blu' 'ccv' 'bs1' 'bs2'... 
          'bs3' 'bs4' 'bs5' };
%LB.Rsg = {'rad' 'elo' 'cir' 'ori' 'red'   'grn' 'blu' 'ccv' };

%% ----------   arc   ---------  10
% wt_ArcVbn, ArcIObin.h
% int  **Adr[nFld] = {
%         &Les, &Krv, &Dir, &Spz, &Eck,   &Run, &Ifx, &Red, &Grn, &Blu };  
LB.Arc = {'les' 'krv' 'dir' 'spz' 'eck'   'run' 'ifx' 'red' 'grn' 'blu' };
      
%% ----------   str   ---------  6
% wt_StrVbn, StrIObin.h
% int  **Adr[nFld] = {  &Les, &Str, &Ori, &Red, &Grn, &Blu };  

LB.Str = {'les' 'str' 'ori' 'red' 'grn' 'blu'};
        
%%  ---------    bndg   ---------  10      
LB.Bndg = {'len' 'agx' 'tig' 'dns' 'ori'   'vpo' 'hpo' 'red' 'grn' 'blu'};
      
%% ----------   shape   ---------   ShpAbstAtts.h

% ------ abnShpStrOri, ia Scors
Lbs = 'Vrt   Hor   Dg1   Dg2   Axi   Adg   Vab   Hab   Dab   Tri   Nil   ';
Lshp.Scors = u_AttLabArrToList( Lbs );

% ------ abnShpStrFin, ia Sfine
Lbs = 'Vrt   Hor   Vti   Hti   Vob   Hob   Dg2   Dg1   Axi   Uni   Dul   Cvg   Agx   Ori   Nil   Dre   Vir   Fnf   ';
Lshp.Sfine = u_AttLabArrToList( Lbs );

% ------ attsShpRadSeg, ia Ras
Lbs = 'Rad   Elo   Ron   Riss  SteUgfSteEngSteDowSteUppOpnDowOpnUpwLigUgfLigEngLigDowLigUppOpnRitOpnLef';
Lshp.Ras = u_AttLabArrToList( Lbs );
 
% ------ abnShpAuto
Lbs = 'SprA  SprS  Prx   Etg   Ort   Gri   Rbns  ';
Lshp.Auto = u_AttLabArrToList( Lbs );

%Lshp.Gol = {'rib' 'ori' 'elo' 'agx'};

%LbsGen = {'vpo' 'hpo' 'red' 'grn' 'blu'};

%LB.Shp = [ Lshp.Scors(:); LbsGen(:) ];
%LB.Shp = [ Lshp.Scors(:); Lshp.Sfine(:); Lshp.Ras(:); LbsGen(:) ];
LB.Shp = [ Lshp.Scors(:); Lshp.Sfine(:); Lshp.Ras(:); Lshp.Auto(:) ];
            %LbsGen(:) ];
%LB.Shp = {'vrt' 'hor' 'dg1' 'dg2' 'axi' 'vpo' 'hpo' 'red' 'grn' 'blu'};


%% ----------   tetragon   ---------   
aLbGeom = { 'Les'   'Elo'    'Wide'   'High'    'Rhom'  ...
            'Pllo'  'Tria'   'Irrg'   'PlHor'   'PlVrt' ...
            'Ger'   'Wth'
            };
aLbLage = { 'AxVrt'  'AxHor'   'Axial'   'Lean1'  'Lean2'   ...
            'Neig1'  'Neig2'
            };
        
aLbUtil = { 'ori' 'vpo' 'hpo'};

LB.Ttrg = [ aLbGeom(:); aLbLage(:); aLbUtil(:) ];

%% ------------   DOUBLES   ---------------
LB.Ttg  = LB.Ttrg;
LB.Bnd  = LB.Bndg;

%% ------------------------   Num of Labels   ----------------------
if 0
    aFldNas     =  fieldnames(LS);
    for f = 1:length(aFldNas)
        
        fl       = aFldNas{f};
        fln      = ['n' fl];
        aLabs    = LS.(fl);
        nAtt     = length( aLabs );
        
        LS.(fln) = nAtt;
    end
end



end % MAIN

