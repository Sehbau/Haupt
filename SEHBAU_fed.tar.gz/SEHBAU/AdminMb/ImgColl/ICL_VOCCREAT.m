%
% Creates a vocabulary of quants for a collection of images for ONE group
% (of ONE desctype). We run executable 'dqnt' in collecting mode.
%
% cf iclQntVoc.m, plcQntVoc.m
%
% IN    Fina1       o_FileStems
%       IxImg       image indices
%       finaGrp     ie. 'PrmDqnt_Cnt_Geo.txt'
%
function [Qvoc Hed] = ICL_VOCCREAT( Fina1, IxImg, finaGrp, Args, Admin )

[dty idSS]  = u_QuantGroupName( finaGrp );
Fixt        = o_FileExtensVect();                       

bSaveDesc   = Admin.bSaveQntV;

nImg        = length(IxImg);
fprintf('-----------------  %s  %s  -----------------\n', dty, idSS);

Qvoc = [];
for i = 1:nImg,     

    ixi     = IxImg(i);
    
    % ----------   FileStemWidf   ------------
    ffst = o_FileNameFrmt( Fina1.veci, ixi, '', Admin.finaFrmt );

    if bSaveDesc==1
        pthOut = ffst;
    else 
        pthOut = Admin.pthOut;
    end
    pthOut = u_PathToBackSlash(pthOut); % slash to backslash for windows

    % ----------   Execute   ------------
    fpDsb       = [ ffst '.vbn' dty ];
    Args.fpPrm  = [ 'Vocab/' finaGrp ];
    Args.fpVoc  = '';         % ensure it is empty, since we collect only

    StdOut      = RennDqnt( fpDsb, pthOut, Args, Admin.pthExe );
    
    if ixi==IxImg(1), 
        pso_OptUnrec(StdOut); 
        StdOut
    end
    
    % -----------   Collect   ----------
    lfn         = [ pthOut Fixt.qntCod dty ];
    [Qnt Hed]   = LoadQuantArr( lfn );
    
    Qord        = sort(Qnt, 'ascend');
    Qvoc        = union( Qvoc, Qord );  % quant vocabulary
    
    % ----- progress
    % instead of dots, we report quant-collection size
    if mod(i,round(nImg/20))==0, 
        fprintf('%d ', length( Qvoc ) );
    end     
    
    if i==1
        DispLoad( lfn );
    end
    
end
fprintf('%d-%d done\n', IxImg(1), IxImg(end));
Hed.nQnt    = length( Qvoc );

end






