%
% Generate dtop files from a list of dsc files given as a list of indices.
% It uses function o_FileNameFrmt to create the number-based filename.
%
% cf iclDtop.m, plzRun.m
%
% IN  fipaExe    filepath of executable
%     IxImg      list of indices
%     Fina1      struct with filestems as for example in o_FileStems.
%     FixtImg    file extensions
%     finaFrmt   format of filename, see o_FileNameFrmt
%     Args       arguments to topx executable
%
function [ ] = ICL_TOPX( fipaExe, IxImg, Fina1, FixtImg, finaFrmt, Args )

%% -------------   Arguments   -----------
if exist( fipaExe, 'file')==2,
    error('Program path not correct: %s', fipaExe );
end

if nargin==4
    finaFrmt    = 0;
    Args        = '';
end
if nargin==5
    Args        = '';
end

%% -------------   LOOP LIST   -----------
nImg    = length(IxImg);

fprintf('ICL_TOPX: running %d images:', nImg);
for i = 1:nImg,     

    ixi     = IxImg(i);
    
    pthDsc  = o_FileNameFrmt( Fina1.dsci, ixi, FixtImg.dsc, finaFrmt );
    pthOut  = o_FileNameFrmt( Fina1.dtop, ixi, '', finaFrmt );

    %pthImg = [ Fina1.descFile num2str(ixi) FixtImg.dsc ];
    %pthOut = [ Fina1.dtopFile num2str(ixi)];
    
    % ----------   Execute   ------------
    cmnd    = [ fipaExe ' ' pthDsc ' ' pthOut ' ' Args ];

    StdOut  = f_CmndExec( cmnd );
    
    if ixi==IxImg(1), 
        pso_OptUnrec(StdOut); 
        StdOut
    end
    
    if mod(i,round(nImg/40))==0, fprintf('.'); end  % progress dots
    
    %pause();
    
end
fprintf('%d-%d done\n', IxImg(1), IxImg(end));

end

