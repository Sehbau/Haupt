%
% Applies a vocabulary to a collection of images for ONE group and also
% collects the quistograms. We run executable 'dqnt' in dictionary mode.
% 
% This is more useful for testing. In an actual application per image, we
% rather loop the groups per image.
%
% cf iclVocApply.m
%
% IN    Fina1       o_FileStems
%       IxImg       image indices
%       finaGrp     ie. 'PrmDqnt_Cnt_Geo.txt'
%
function [QST Hed] = ICL_VOCAPPLY( Fina1, IxImg, jGrp, Args, Admin )

[dty idSS]  = u_QuantGroupName( jGrp.fina );
Fixt        = o_FileExtensVect();                       

bSaveDesc   = Admin.bSaveQntIx;

nImg        = length(IxImg);
fprintf('------------  nImg %d  %s  %s  ------------\n', nImg, dty, idSS);

for i = 1:nImg,     

    ixi     = IxImg(i);
    
    % ----------   FileStemWidf   ------------
    ffst = o_FileNameFrmt( Fina1.veci, ixi, '', Admin.finaFrmt );
    %ffst  = [ Fina1.veci num2str(ixi) ];
    
    if bSaveDesc==1
        pthOut = ffst;
    else
        pthOut = Admin.pthOut;
    end
    pthOut = u_PathToBackSlash(pthOut); % slash to backslash for windows

    % ----------   Execute   ------------
    fpDsb       = [ ffst '.vbn' dty ];

    % ensure we specified a vocabulary (because we are in dictionary mode)
    if isempty( Args.fpVoc )
        error('vocabulary file not specified'); end

    StdOut      = RennDqnt( fpDsb, pthOut, Args, Admin.pthExe );

    if ixi==IxImg(1), 
        pso_OptUnrec(StdOut); 
        StdOut
    end
    
    % -----------   Load   ----------
    lfn         = [ pthOut Fixt.qntDix dty ];
    [Dix Hed]   = LoadQuantArr( lfn );
    nDix        = length(Dix);

    lfn         = [ pthOut Fixt.qntHst dty ];
    [Qst nHbin] = LoadArrIntTxt( lfn );

    if i==1
        QST = zeros( nImg, nHbin, 'single' );
    end
    
    QST(i,:) = Qst;
    %assert( nVix==nHbin, 'Array lengths not matching: %d <> %d', nVix, 
    %Hst'
    
    % ----- progress
    if mod(i,round(nImg/20))==0, 
        fprintf('.' );
    end     
    
    if i==1
        DispLoad( lfn );
    end
    
end
fprintf('%d-%d done\n', IxImg(1), IxImg(end));
%Hed.nQnt    = length( Qvoc );

end






