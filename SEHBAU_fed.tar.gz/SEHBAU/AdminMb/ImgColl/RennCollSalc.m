%
% Wrapper for collsalc.
%
% fka COLL_TXTR.m
%
% cf iclDscx.m, plzRun.m
%
function [Out] = RennCollSalc( fpBin, fist, IxImg, ...
                                fext, fpRgst, FinaColl, nameFormat )

nImg    = length( IxImg );

fprintf('RennCollSalc for %d images: ', nImg);

if nargin==6
    nameFormat = 0;
end

o_RegistGenAndSave( fist, IxImg, fext, fpRgst, nameFormat );

cmnd    = sprintf('%s %s %s', fpBin, fpRgst, FinaColl.salcFs );

fprintf('%s...', cmnd);

[status Out] = system( cmnd );
v_CmndExec( status, Out, cmnd, 1 );

fprintf('done\n');

end