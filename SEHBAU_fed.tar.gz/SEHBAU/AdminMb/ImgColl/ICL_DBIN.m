%
% Binning and hists for a list of images using executable 'dbin'.
%
% cf iclDbin.m
% af ICL_TOPX.m
%
% IN  fipaExe    filepath of executable
%     IxImg      list of indices
%     Fips1      struct with filestems as for example in o_FileStems.
%     FixtImg    file extensions
%     finaFrmt   format of filename, see o_FileNameFrmt
%     Args       arguments to topx executable
%
function [ ] = ICL_DBIN( fipaExe, IxImg, Fips1, FixtImg, finaFrmt, argStr )

%% -------------   Arguments   -----------
if exist( fipaExe, 'file')==2,
    error('Program path not correct: %s', fipaExe );
end

if nargin==4
    finaFrmt    = 0;
    argStr      = '';
end
if nargin==5
    argStr      = '';
end

%% -------------   LOOP LIST   -----------
nImg    = length(IxImg);

fprintf('ICL_DBIN: running %d images with path&stem %s...\n', nImg, Fips1.dbin );
for i = 1:nImg,     

    ixi     = IxImg(i);
    
    pthDsc  = o_FileNameFrmt( Fips1.dsci, ixi, FixtImg.dsc, finaFrmt );
    pthOut  = o_FileNameFrmt( Fips1.dbin, ixi, '', finaFrmt );

    %pthImg = [ Fina1.descFile num2str(ixi) FixtImg.dsc ];
    %pthOut = [ Fina1.dtopFile num2str(ixi)];
    
    % ----------   Execute   ------------
    cmnd    = [ fipaExe ' ' pthDsc ' ' pthOut ' ' argStr ];

    bTryDebug = 1;
    StdOut  = f_CmndExec( cmnd, bTryDebug );
    
    if ixi==IxImg(1), 
        pso_OptUnrec(StdOut); 
        StdOut
    end
    
    if mod(i,round(nImg/40))==0, fprintf('.'); end  % progress dots
    
    %pause();
    
end
fprintf('%d-%d done\n', IxImg(1), IxImg(end));

end

