%
% Writes header for a collection of histograms as loaded in LoadCollHist.m
%
% cf ICL_COLLFBRCHYKO.m
%
%
%
function [] = SaveCollHistInit( nImg, nBin, sfp )

fid     = fopen( sfp, 'wb');

if fid==0
    error('Could not open %s\n', sfp); 
end

fwrite( fid, nImg, 'int32' );   % number of images
fwrite( fid, nBin, 'int32' );   % number of bins

fclose(fid);

end

