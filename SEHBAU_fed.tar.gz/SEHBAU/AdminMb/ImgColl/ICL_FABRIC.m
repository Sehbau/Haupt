%
% Fabric
%
% cf iclFabric.m
% af ICL_DBIN.m
%
% IN  fipaExe    filepath of executable
%     IxImg      list of indices
%     Fina1      struct with filestems as for example in o_FileStems.
%     FixtImg    file extensions
%     finaFrmt   format of filename, see o_FileNameFrmt
%     argStr     arguments to topx executable
%
function [ ] = ICL_FABRIC( fipaExe, IxImg, Fips1, FixtImg, finaFrmt, argStr )

%% -------------   Arguments   -----------
if exist( fipaExe, 'file')==2,
    error('Program path not correct: %s', fipaExe );
end
if nargin==4
    finaFrmt    = 0;
    argStr      = '';
end
if nargin==5
    argStr      = '';
end

%% -------------   LOOP LIST   -----------
nImg    = length(IxImg);

%fprintf('ICL_FABRIC: running %d images with path&stem %s...\n', nImg, Fips1.dbin );
for i = 1:nImg,     

    ixi     = IxImg(i);
    
    pthCbnt = o_FileNameFrmt( Fips1.cbnt, ixi, FixtImg.hsspa, finaFrmt );
    pthOut  = o_FileNameFrmt( Fips1.fbrc, ixi, '', finaFrmt );
    
    % ----------   Execute   ------------
    cmnd    = [ fipaExe ' ' pthCbnt ' ' pthOut ];% ' ' argStr ];

    bTryDebug = 0; % geht gar nicht mit diesem Program
    StdOut  = f_CmndExec( cmnd, bTryDebug );
    
    if ixi==IxImg(1), 
        pso_OptUnrec(StdOut); 
        StdOut
    end
    
    if mod(i,round(nImg/40))==0, fprintf('.'); end  % progress dots
    
    %pause();
    
end
fprintf('%d-%d done\n', IxImg(1), IxImg(end));

end

