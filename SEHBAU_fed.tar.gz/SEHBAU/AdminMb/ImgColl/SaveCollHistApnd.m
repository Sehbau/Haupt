%
% Writes header for a collection of histograms as loaded in LoadCollHist.m
%
% cf ICL_COLLFBRCHYKO.m
%
%
%
function [] = SaveCollHistApnd( Mx, sfp )

fid     = fopen( sfp, 'ab');

if fid==0
    error('Could not open %s\n', sfp); 
end

fwrite( fid, Mx(:), 'int32' );   

fclose(fid);

end

