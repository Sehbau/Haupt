"""

Definitions carrying out processes (executables) for a list of images, called by
corresponding scripts iclXXXX.py

Consider renaming to IclListProc.py | ListDescExtr

------------------------------   DEF SUM   ------------------------------
def DSCX( aImg, fipaDscx, Pths, Args )

def DBIN( fipaExe, IxImg, Fips1, FixtImg, finaFrmt=0, argStr='' ):

def TOPX( fipaExe, IxImg, Fips1, FixtImg, finaFrmt=0, argStr='' ):

def FABRIC( fipaExe, IxImg, Fips1, FixtImg, finaFrmt=0 ):


Elsewhere:
- ICL_COLLFBRCXXX in Collecting.py

"""
import os, subprocess, shlex
from pathlib import Path

import AdminPy.Util as sbUt
from AdminPy.Util import v_CmndExec
from AdminPy.Orga.OrgFileNames import *



# --------------------------------------------------------------------------------
#
#                            D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   DSCX   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Descriptor extraction for a collection (a list of images).

"""
def DSCX( aImg, fipaDscx, dirDsc, Args ):

    sbUt.vrf_ExecutableExists( fipaDscx )

    for fipaImg in aImg:

        fipsOut = dirDsc / fipaImg.stem

        #            arg0      arg1     arg2      arg3          arg4
        cmnd   = [ fipaDscx, fipaImg, fipsOut, Args.fpPrm ]

        if Args.opt:
            if isinstance(Args.opt, str):
                cmnd += shlex.split( Args.opt )
            else:
                cmnd += list(Args.opt)

        #print( cmnd )

        Res    = subprocess.run( cmnd, capture_output=True, text=True)

        sbUt.v_CmndExec( Res )
        
        sbUt.printDotProg()

    return 0



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   DBIN   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Binning and hists for a list of images using executable 'dbin'.

cf iclDbin.py

IN  fipaExe    filepath of executable
    IxImg      list of indices
    Fips1      struct with filestems as for example in o_FileStems.
    FixtImg    file extensions
    finaFrmt   format of filename, see o_FileNameFrmt
    argStr     arguments to topx executable

"""
def DBIN( fipaExe, IxImg, Fips1, FixtImg, finaFrmt=0, argStr='' ):

    # -------------   Arguments   -----------
    sbUt.vrf_ExecutableExists( fipaExe )

    # -------------   LOOP LIST   -----------
    nImg = len(IxImg)

    stepDisp = max(1, round(nImg / 40))             # progress dots

    print( f"ICL_DBIN: running {nImg} images "
           f"with path&stem {Fips1.dbin}..."  )

    for i in range(nImg):

        ixi = IxImg[i]

        pthDsc = o_FileNameFrmt( Fips1.dsci, ixi, FixtImg.dsc, finaFrmt )
        pthOut = o_FileNameFrmt( Fips1.dbin, ixi, '',          finaFrmt )

        # ----------   Execute   ------------
        cmnd   = [ fipaExe, pthDsc, pthOut ]

        if argStr:
            cmnd += shlex.split(argStr)

        #bTryDebug = 1
        StdOut = sbUt.f_CmndExec(cmnd)#, bTryDebug)

        if ixi == IxImg[0]:
            sbUt.pso_OptUnrec(StdOut)
            print(StdOut)

        # progress dots
        if (i + 1) % stepDisp == 0:
            print('.', end='', flush=True)

    print(f"{IxImg[0]}-{IxImg[-1]} done")    

    return 0



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   TOPX   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Generate dtop files from a list of dsc files given as a list of indices.
It uses function o_FileNameFrmt to create the number-based filename.

cf iclDtop.py

IN  fipaExe    filepath of executable
    IxImg      list of indices
    Fips1      struct with filestems as for example in o_FileStems.
    FixtImg    file extensions
    finaFrmt   format of filename, see o_FileNameFrmt
    argStr     arguments to topx executable. I dont think there are any...

"""
def TOPX( fipaExe, IxImg, Fips1, FixtImg, finaFrmt=0, argStr='' ):

    # -------------   Arguments   -----------
    sbUt.vrf_ExecutableExists( fipaExe )

    # -------------   LOOP LIST   -----------
    nImg = len(IxImg)

    stepDisp = max(1, round(nImg / 40))             # progress dots

    print( f"ICL_TOPX: running {nImg} images "
           f"with path&stem {Fips1.dtop}..."  )

    for i in range(nImg):

        ixi = IxImg[i]

        pthDsc = o_FileNameFrmt( Fips1.dsci, ixi, FixtImg.dsc, finaFrmt )
        pthOut = o_FileNameFrmt( Fips1.dtop, ixi, '',          finaFrmt )

        # ----------   Execute   ------------
        cmnd   = [ fipaExe, pthDsc, pthOut ]

        if argStr:
            cmnd += shlex.split(argStr)

        #bTryDebug = 1
        StdOut = sbUt.f_CmndExec(cmnd)#, bTryDebug)

        #if ixi == IxImg[0]:
         #   sbUt.pso_OptUnrec(StdOut)
          #  print(StdOut)

        # progress dots
        if (i + 1) % stepDisp == 0:
            print('.', end='', flush=True)

    print(f"{IxImg[0]}-{IxImg[-1]} done")    

    return 0



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   FABRIC   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Fabric

cf iclFabric.py

IN  fipaExe    filepath of executable
    IxImg      list of indices
    Fips1      struct with filestems as for example in o_FileStems.
    FixtImg    file extensions
    finaFrmt   format of filename, see o_FileNameFrmt

"""
def FABRIC( fipaExe, IxImg, Fips1, FixtImg, finaFrmt=0 ):

    # -------------   Arguments   -----------
    sbUt.vrf_ExecutableExists( fipaExe )

    # -------------   LOOP LIST   -----------
    nImg = len(IxImg)

    stepDisp = max(1, round(nImg / 40))             # progress dots
    
    print( f"ICL_FABRIC: running {nImg} images "
           f"with path&stem {Fips1.fbrc}..."  )

    for i in range(nImg):

        ixi = IxImg[i]

        pthCbnt = o_FileNameFrmt( Fips1.cbnt, ixi, FixtImg.hsspa, finaFrmt )
        pthOut  = o_FileNameFrmt( Fips1.fbrc, ixi, '',            finaFrmt )

        # ----------   Execute   ------------
        cmnd   = [ fipaExe, pthCbnt, pthOut ]

        #bTryDebug = 1
        StdOut = sbUt.f_CmndExec(cmnd)#, bTryDebug)

        #if ixi == IxImg[0]:
            #sbUt.pso_OptUnrec(StdOut)
            #print(StdOut)

        # progress dots
        if (i + 1) % stepDisp == 0:
            print('.', end='', flush=True)

    print(f"{IxImg[0]}-{IxImg[-1]} done")    

    return 0
