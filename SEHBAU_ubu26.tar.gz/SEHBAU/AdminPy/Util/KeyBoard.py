"""

Cross-platform 'getch' and 'kbhit'

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------

"""
import sys
import os
import select


if sys.platform == "win32":

    import msvcrt

    def getch():
        return msvcrt.getch()

    def kbhit():
        return msvcrt.kbhit()

else:
    import termios
    import tty

    _fd = sys.stdin.fileno()
    _old_settings = None

    def _set_raw():
        global _old_settings

        if _old_settings is None:
            _old_settings = termios.tcgetattr(_fd)
            tty.setraw(_fd)

    def _restore():
        global _old_settings

        if _old_settings is not None:
            termios.tcsetattr(_fd, termios.TCSADRAIN, _old_settings)
            _old_settings = None

    def getch():
        _set_raw()
        try:
            return os.read(_fd, 1)
        finally:
            _restore()

    def kbhit():
        _set_raw()
        try:
            return bool(select.select([sys.stdin], [], [], 0)[0])
        finally:
            _restore()
