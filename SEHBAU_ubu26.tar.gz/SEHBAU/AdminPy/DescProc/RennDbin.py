"""

Wrapper function for program dbin, fabric & fbrc2arr

Executable 'dbin' needs to be run in its directory as the edge files are only in
that directory.

------------------------------   CLS SUM   ------------------------------
-

------------------------------   DEF SUM   ------------------------------
def RennDbin( fpDsc, fipaOut, Args, dirExe='' ):
def RennFabric( fpCbnt, fipaOut, Args, dirExe='' ):
def RennFbrc2Ar( fpFbrc, fipaOut, dirExe='' ):
def RennDbinFabric( fpDsc, fipaOut, Args, fpDbin, fpFabric ):

"""
import subprocess, platform
from dataclasses import dataclass, asdict
import shlex


# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------
    
""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennDbin   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for dbin.

cf exsbDbin.py

IN    fpDsc   filestem
      fipaOut output filepath
      Args    arguments
OUT   Res     results, incl. standard output/error

"""
def RennDbin( fpDsc, fipaOut, Args, fpExe ):

    cmnd  = [ str(fpExe), str(fpDsc), str(fipaOut), str(Args.fpPrm) ]

    if Args.opt:
        if isinstance(Args.opt, str):
            cmnd += shlex.split(Args.opt)
        else:
            cmnd += list(Args.opt)

    #print("Command:", shlex.join(cmnd))

    Res = subprocess.run( cmnd, capture_output=True, text=True )
    
    # --------------------   Verify Proper Termination   --------------------
    if Res.returncode != 0 or 'EndOfProgram' not in Res.stdout:
        
        print('Program dbin was not executed properly:' )
        print('Command:', shlex.join(cmnd))
        print('Return code:', Res.returncode)
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        cmnd2     = cmnd + list(' --bDISP 3')

        Res2 = subprocess.run( cmnd2, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')

    return Res.stdout



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennFabric   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for fbrc.

cf exsbFabric.py

IN    fpCbnt  cabinet file, spatial histograms generated with 32x32 grid
      fipaOut output filepath
      Args    arguments
OUT   Res     results, incl. standard output/error

"""
def RennFabric( fpCbnt, fipaOut, Args, fpExe ):

    cmnd = [ str(fpExe), str(fpCbnt), str(fipaOut) ]

    if Args.opt:
        if isinstance(Args.opt, str):
            cmnd += shlex.split(Args.opt)
        else:
            cmnd += list(Args.opt)

    #print("Command:", shlex.join(cmnd))

    Res  = subprocess.run( cmnd, capture_output=True, text=True )
    
    # --------------------   Verify Proper Termination   --------------------
    if Res.returncode != 0 or 'EndOfProgram' not in Res.stdout:
        
        print('Program fabric was not executed properly:' )
        print('Command:', shlex.join(cmnd))
        print('Return code:', Res.returncode)
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        cmnd2     = cmnd + list(' --bDISP 3')

        Res2 = subprocess.run( cmnd2, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')

    return Res.stdout


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennFbrc2Ar   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for fbrc2arr.

cf exsbDbin.py

IN    fpFbrc  fabric file
      fipaOut output filepath
      Args    arguments
OUT   Res     results, incl. standard output/error

"""
def RennFbrc2Ar( fpFbrc, fipaOut, fpExe ):

    cmnd  = [ str(fpExe), str(fpFbrc), str(fipaOut) ]

    Res = subprocess.run( cmnd, capture_output=True, text=True )
    
    # --------------------   Verify Proper Termination   --------------------
    if Res.returncode != 0 or 'EndOfProgram' not in Res.stdout:
        
        print('Program fbrc2arr was not executed properly. Output below:' )
        print('Command:', shlex.join(cmnd))
        print('Return code:', Res.returncode)
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        cmnd2     = cmnd + list(' --bDISP 3')

        Res2 = subprocess.run( cmnd2, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')

    return Res.stdout



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennDbinFabric   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Creates fabric saving dbin cabinet output temporarily only.
"""
def RennDbinFabric( fpDsc, fipaOut, Args, fpDbin, fpFabric ):

    fpTmp = "./tmpCbnt"
    
    cmnd  = [ str(fpDbin), str(fpDsc), fpTmp, str(Args.fpPrm) ]

    Res = subprocess.run( cmnd, capture_output=True, text=True )

    # --------------------   Verify Proper Termination   --------------------
    if Res.returncode != 0 or 'EndOfProgram' not in Res.stdout:
        
        print('Program dbin was not executed properly:' )
        print('Command:', shlex.join(cmnd))
        print('Return code:', Res.returncode)
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        cmnd2     = cmnd + list(' --bDISP 3')

        Res2 = subprocess.run( cmnd2, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')
    
    # ------------------------------   Fabric   ------------------------------
    cmnd = [ str(fpFabric), fpTmp+'.hsspa', str(fipaOut) ]

    Res  = subprocess.run( cmnd, capture_output=True, text=True )

    # --------------------   Verify Proper Termination   --------------------
    if Res.returncode != 0 or 'EndOfProgram' not in Res.stdout:
        
        print('Program fabric was not executed properly:' )
        print('Command:', shlex.join(cmnd))
        print('Return code:', Res.returncode)
        print( Res.args )
        print( Res.stdout )
        print( Res.stderr )

        print( 'Debugging...' )
        cmnd2  = cmnd + list(' --bDISP 3')

        Res2   = subprocess.run( cmnd2, capture_output=True, text=True )

        print( Res2.stdout )


        
    
    
