
"""
Creates global variables for SEHBAU.
"""

# ------------------------------ ROOT PATHS ------------------------------

# Set these environment variables on each operating system,
# or adjust the defaults below.

rootSehBau = Path(os.environ.get( 'SEHBAU_ROOT', r'c:\klab\ppc\SEHBAU' ))

pthSehqul = Path(os.environ.get( 'SEHQUL_ROOT', r'c:\klab\ppc\SEHQUL' ))


# ------------------------------ VARIABLES ------------------------------

bOSisWin = os.name == 'nt'

ExeSuff = '.exe' if bOSisWin else ''


# ------------------------------ DIRS ------------------------------------

DirProg = {

    'descExtr': 'DescExtr',
    'descProc': 'DescProc',
    'descUtil': 'DescUtil',
    'mtchVec':  'MtchVec',
    'mtchHst':  'MtchHst',
    'mtchTxt':  'MtchTxt',
    'focSel':   'FocSel',
    'shpExtr':  'ShpExtr',
    'shpMtch':  'ShpMtch',
    'plcRec':   'DemoPlcRec',
    'sgrRGB':   'DemoSgrRGB',
    'baum':     'DemoBaum'
}


# ------------------------------ PATHABS ---------------------------------

PthProg = {
    key: rootSehBau / val
    for key, val in DirProg.items()
}


# ------------------------------ EXECUTABLES -----------------------------

# Dictionary of binary names, without extensions.

# Construct absolute executable paths.

FipaExe = {
    key: PthProg[dirKey] / (binName + ExeSuff)
    for key, (dirKey, binName) in BinNames.items()
}


# ------------------------------ VERIFY EXISTENCE ------------------------

for fn, prna in FipaExe.items():

    if not prna.is_file():
        print(f"WARNING: program {fn} not found: {prna}")

    elif not bOSisWin and not os.access(prna, os.X_OK):
        print(f"WARNING: program {fn} is not executable: {prna}")
