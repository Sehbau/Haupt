"""

------------------------------   CLS SUM   ------------------------------
------------------------------   DEF SUM   ------------------------------

# --------------------   Loading   --------------------


# --------------------   Anaylsis   --------------------


# --------------------   Plotting   --------------------



"""
import subprocess, platform, shlex
from pathlib import Path
from typing import List, Any
import numpy as np

from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.Mtch.OrgFile.OrgFileNameMtch import *
from AdminPy.Util.FileIO.LoadData import *
from AdminPy.DescExtr.Texture.FabricIO import LoadFbrcKrnlHed
from .MtchFbrcAnf import *

import AdminPy.MtchFbrc.MtchFbrcUtil as mfbu
import AdminPy.Recognize.RecUtil as rcut



# --------------------------------------------------------------------------------
#
#                               R O U T I N E S
#
# --------------------------------------------------------------------------------


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennMfbrcKrnl   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for mfbrckrnl1.

cf exsbFabricRecKrnl.py

"""
def RennMfbrcKrnl( fipaFbrc, fipaKrnl, Args, fpExe ):

    # ----------   Arguments   ----------
    if isinstance(Args.opt, str):
        opt = shlex.split(Args.opt)
    else:
        opt = list(Args.opt)

    cmndBase = [ str(fpExe), str(fipaFbrc), str(fipaKrnl) ]

    # append parameter and measurement file
    if Args.fpPrm:
        cmnd  = cmndBase + [Args.fpPrm, Args.fpMes, *opt]

    else: 
        cmnd  = cmndBase + [Args.fpMes, *opt]

    #print( cmnd )
    
    # -----   Execute
    Res = subprocess.run( cmnd, capture_output=True, text=True )
    
    # ------  Verify Proper Termination  -----
    if Res.returncode != 0 or 'EndOfProgram' not in Res.stdout:

        print('Program mfbrckrnl1 was not executed properly. Output below:' )
        print('Commmand: ', shlex.join(cmnd) )
        print('Return code:', Res.returncode)
        print( Res.stdout )
        print( Res.stderr )

        input('Pausing')

    return Res


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennMfbrcKrnlLst   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Cycles a list of kernels calling RennMfbrcKrnl above.

cf exsbObjIdfLst.py

"""
def RennMfbrcKrnlLst( fipaFbrc, aLst, Args, fpExe ):

    nKrnl = len(aLst)
    ALOCT = [None]*nKrnl
    for k in range(nKrnl):
    
        Res        = RennMfbrcKrnl( fipaFbrc, aLst[k], Args, fpExe )

        Dim, Nfet  = LoadFbrcKrnlHed( aLst[k] )        
    
        SCOR       = mfbu.LoadScorMapsKrnlC2F( Dim.nLay )

        ALoct      = [None]*Dim.nLay
        for l in range( Dim.nLay ):

            # dissimilarity measure, ergo minima
            ALoct[l]    = rcut.f_MapLocMinima( SCOR.AHyk[l] )

        ALOCT[k] = ALoct

    return ALOCT




        

    
