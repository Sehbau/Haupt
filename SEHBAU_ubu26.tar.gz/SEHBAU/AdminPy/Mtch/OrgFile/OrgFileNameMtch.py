"""

Filenames for measurement results.

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def o_FileNameMtxtc( ppndPth: Optional[Union[str, int]] = None,
                     fidfUser: Optional[str] = None ):
def o_FinaMtchKrnl( ):

"""
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Optional, Union


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class fileNameMtchTxtc:
    """
    Texturegrams.
    """
    txtGridBis: str = "TxtrGridBis.txt"
    txtBand:    str = "TxtrBand.txt"

    frklLay:    str = "TxtrFrklLay.txt"
    frklGrt:    str = "TxtrFrklGrt.txt"
    frklSnk:    str = "TxtrFrklSnk.txt"
    frklWag:    str = "TxtrFrklWag.txt"

    txtGrid:    str = "Grid.txt"
    txtBand:    str = "Band.txt"
    txtBlob:    str = "BlobBbx.txt"

    # optional field (added only if fidfUser used)
    fidfUser: Optional[str] = None


@dataclass
class fileNameMtchFbrc:
    """
    Fabric.
    """
    bisCollL0: str = "Mes/FbrcBisL0.txt"
    bisCollL1: str = "Mes/FbrcBisL1.txt"
    bisCollL2: str = "Mes/FbrcBisL2.txt"
    bisCollL3: str = "Mes/FbrcBisL3.txt"

    hykLstItg: str = 'Mes/FbrcHykItg'      # cannot be changed. binary
    hykLstClw: str = 'Mes/FbrcHykClw'

    scmpBisL0: str = 'Mes/ScorMapBis_L0' # cannot be change. binary
    scmpBisL1: str = 'Mes/ScorMapBis_L1'
    scmpBisL2: str = 'Mes/ScorMapBis_L2'
    scmpBisL3: str = 'Mes/ScorMapBis_L3'

    scmpHykL0: str = 'Mes/ScorMapHyk_L0' # cannot be change. binary
    scmpHykL1: str = 'Mes/ScorMapHyk_L1'
    scmpHykL2: str = 'Mes/ScorMapHyk_L2'
    scmpHykL3: str = 'Mes/ScorMapHyk_L3'
    
    
    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FileNameMtxtc   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

see o_FileNameMtxtc.m


 Filepaths/names for measurement files outputted by executable mtxtc
 (matching a collection).

 sa o_FileNameMtxt1.m

 IN   ppndPth    [optional] prepend a path or string

 USE 
 - for filestems only. No directory name prepended
           FinaMes  = o_FileNameMtxt( );     

 - for fixed finas/paths. Prepends directory 'Mes/'
           FinaMes  = o_FileNameMtxt( 1 );     

 - for user-defined finas. Prepends mesFil12:  
           mesFil12 = 'Txt12';
           Fina12   = o_FileNameMtxt( 1, mesFil12 );  

 sa o_FileNames, o_FileNameMvec, etc.

"""
def o_FileNameMtxtc( ppndPth: Optional[Union[str, int]] = None,
                     fidfUser: Optional[str] = None ):

    S = fileNameMtchTxtc()

    # ---- nargin == 0 ----
    if ppndPth is None:
        return S

    # ---- prepend filestem identifier ----
    if fidfUser is not None:
        
        S.txtGrid  = fidfUser + S.txtGrid
        S.txtBand  = fidfUser + S.txtBand
        S.txtBlob  = fidfUser + S.txtBlob
        S.fidfUser = fidfUser

    # ---- prepend path logic ----
    if isinstance(ppndPth, str):
        ppndPth = Path(ppndPth)

    elif isinstance(ppndPth, (int, float)):
        if ppndPth > 0:
            ppndPth = Path("Mes")
        else:
            return S
    else:
        raise TypeError(f"input {ppndPth} not implemented")

    # ---- prepend path to all fields ----
    for f in fields(S):
        fn  = f.name
        val = getattr(S, fn)

        if val is not None:
            setattr( S, fn, str(ppndPth / val) )

    return S


""" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO   o_FinaMtchKrnl   OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO


Filepaths/names for measurement files outputted by executable mfbrckrnl1

"""
def o_FinaMtchKrnl( ):

    S    = fileNameMtchFbrc()

    aBis = [None] * 4
    aHyk = [None] * 4

    aBis[0] = S.scmpBisL0
    aBis[1] = S.scmpBisL1
    aBis[2] = S.scmpBisL2
    aBis[3] = S.scmpBisL3

    aHyk[0] = S.scmpHykL0
    aHyk[1] = S.scmpHykL1
    aHyk[2] = S.scmpHykL2
    aHyk[3] = S.scmpHykL3
    
    return aBis, aHyk




