

import os, sys

finaPyExe = sys.executable

os.system( finaPyExe + ' exsbDbin.py')
os.system( finaPyExe + ' exsbFabric.py')
os.system( finaPyExe + ' exsbReadAtKpt.py')
