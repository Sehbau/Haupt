"""

Example for applying executable 'mfbrckrnl1', extracting a focus, creating a kernel,
and then matching the kernel against the own image.

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Util import *
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescProc.RennDbin import RennDbin, RennFabric, RennFbrc2Ar

from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Texture.FabricIO import *
from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.DescExtr.Hist.DescBinAnf import *
from AdminPy.Util.UtilImg import *

strImg          = 'room.png'

crrDir          = os.getcwd()
fipaImg         = crrDir / Path( 'Imgs/' + strImg )            # image path
fstmOut         = crrDir / Path( 'Desc/' + strImg[:-4] )     # output file path

Fixt            = o_FileExtensions()
fpDSC           = o_FinaApndExtDscx( fstmOut, Fixt )

# --------------------------------------------------------------------------------
#                             DSCX, DBIN, FABRIC
#                            same as exsbFabric.py
# --------------------------------------------------------------------------------

# ------------------------------   Dscx (Step 1)   ------------------------------

ArgsDscx        = o_CmndArgs('dscx')
ArgsDscx.opt    = ' --saveRRE --saveCVP';

StdOut          = RennDscx( fipaImg, fstmOut, ArgsDscx, sb.FipaExe['dscx'] )

# ------------------------------   Dbin (Step 2)   ------------------------------
os.chdir( sb.PthProg['descProc'] )

fpPrm           = 'Params/PrmDbin_Cabinet.txt'; 
#fipaDsc         = str(fstmOut) + Fixt.dsc 
ArgsDbin        = o_CmndArgs( 'dbin' )
ArgsDbin.fpPrm  = fpPrm
ArgsDbin.opt    = '--all'

OutDbin         = RennDbin( fpDSC.dsc, fstmOut, ArgsDbin, sb.FipaExe['dbin'] )

# ------------------------------   Fabric & fbrc2arr   ------------------------------
fpDSC           = o_FinaApndExtDscx( fstmOut, Fixt )
fipaCbnt        = fpDSC.hsspa # [fstmOut Fixt.hsspa];
ArgsFbrc        = o_CmndArgs( 'fabric' );

# we run both, 'fabric' and 'fbrc2arr'
OutFbrc         = RennFabric( fipaCbnt, fstmOut, ArgsFbrc, sb.FipaExe['fabric'] )
OutFbAr         = RennFbrc2Ar( fpDSC.fbrc, fstmOut, sb.FipaExe['fbrc2arr'] )

# ------------------------------   Load Output   ------------------------------
# we assume that script exsbFabric.py has alread been executed
dmy, HedFbc = LoadFabric( fpDSC.fbrc )  # we need the image size for scaling factors
FImg        = LoadFbrcArrays( fpDSC, 0 )   # FabricIO.py



# --------------------------------------------------------------------------------
#                         F O C U S   E X T R A C T I O N 
# --------------------------------------------------------------------------------
# we extract a subset of the fabric description

top=160; bot=245; lef=450; rit=540 # black microwave/cabinet
#top=240; bot=320; lef=50; rit=95 # fire exstinguisher
#top=280; bot=315; lef=480; rit=520 # stove
#top=280; bot=320; lef=520; rit=580 # faucet
#top=180; bot=260; lef=330; rit=390 # ventilator/towel dispenser
#top=0; bot=479; lef=0; rit=50
#top=0; bot=50; lef=0; rit=639
#top=0; bot=240; lef=0; rit=320
BoxRep   = i_Bbox( top, bot, lef, rit )

# --- the scaling factors
szImg    = [HedFbc.Hed.szV, HedFbc.Hed.szH]
PrmScl   = i_PrmFbrcFocScl( szImg[0], szImg[1] )

# --- extract and create kernel
IXlin    = f_FbrcFocRngs( BoxRep, PrmScl ) # the linear indices
FFoc     = f_FbrcFocXtr( FImg, IXlin )  # extract focus (subspace)
FKrnl    = f_FbrcKernel( FFoc )         # kernel: take mean of hyperkolumns/biases

BoxRepUrg = u_BboxUnitRg( BoxRep, szImg )

# ----------   Save   ----------
FixtFoc     = o_FileExtensFoc()
sfnKrnl     = crrDir / Path( str(fstmOut) + str(f"_P0") + FixtFoc.fbk )
SaveFbrcKernel( FKrnl, sfnKrnl )

# -------------------------------------------------------------------
#                             M A T C H 
# -------------------------------------------------------------------
# we look for the above focus description 'FKrnl' in the image fabric description
from AdminPy.Util.CmndSupp import *
from AdminPy.MtchFbrc.RennMfbrc import *

os.chdir( sb.PthProg['mtchFbrc'] )

Args        = o_CmndArgs( 'mtch' )
Res         = RennMfbrcKrnl( fpDSC.fbrc, sfnKrnl, Args, sb.FipaExe['mfbrckrnl1'] )

# ----------   Load Score Maps   ----------
import AdminPy.MtchFbrc.MtchFbrcUtil as mfbu

SCOR      = mfbu.LoadScorMapsKrnlC2F( FKrnl.Dim.nLay )


# ------------------------------   Locate   ------------------------------
import AdminPy.Recognize.RecUtil as rcut
import AdminPy.DescExtr.Features.PixAnf as px

ALoct     = []
AIX       = []
nLaySus   = FKrnl.Dim.nLay
BBoxOut   = np.zeros( (nLaySus,4), dtype=np.int32 )
Sitg      = np.zeros( SCOR.AHyk[nLaySus-1].shape, dtype=np.float32 )
for l in range(nLaySus):

    # We measured differently for exhaustive and accelerated, therefore we use
    # minima search for exhaustive, and maxima search for accelerated case:
    
    # dissimilarity measure, ergo minima
    Loct    = rcut.f_MapLocMinima( SCOR.AHyk[l] )

    # -----  BoundingBox from predicted location
    ixLay     = nLaySus-1-l # counting was inverted during top-down analysis
    BBoxOut[l,:]=rcut.u_OutlFromLoctLay( Loct.Rw[0], Loct.Cl[0], ixLay, BoxRepUrg, szImg )

    print( f" rw={Loct.Rw[0]:2d}  cl={Loct.Cl[0]:2d} " )

    ALoct.append( Loct )

    # -----  linear indices
    szHor     = FBRCDimLay[0][1]
    AIX.append( px.u_PixRCtoIx( Loct, szHor ) )


# ------------------------------   Plot   ------------------------------
from PIL import Image
Irgb         = np.array(Image.open(fipaImg))

IptcRep      = u_IptchFromBbox( Irgb, BoxRep )  # the corresponding patch in the image

AIptchOut    = rcut.u_IptchFromBoxLst( Irgb, BBoxOut )

figNo = 1
mfbu.p_MapsScor( figNo, Irgb, IptcRep, SCOR, nLaySus, AIptchOut )
