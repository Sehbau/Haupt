"""

Lacks the DSCX, DBIN and FABRIC section, see exsbFabricKrnl.py

Example for top-down recognition strategy with fabric kernel description.

Example is an extension of exsbFabricKrnl.py by Python code for kernel matching.

"""
import sys, subprocess
import numpy as np
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Util import *
from AdminPy.DescExtr.RennDscx import RennDscx, i_DscxArgs, argsDscx
from AdminPy.DescProc.RennDbin import RennDbin, RennFabric, RennFbrc2Ar

from AdminPy.DescExtr.Texture.Fabric import *
from AdminPy.DescExtr.Texture.FabricAnf import *
from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.DescExtr.Texture.FabricIO import *
from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.DescExtr.Hist.DescBinAnf import *
from AdminPy.Util.UtilImg import *


# ------------------------------   Paths   ------------------------------
crrDir      = os.getcwd()
strImg      = 'room.png'
fipaImg     = crrDir / Path( 'Imgs/' + strImg )            # image path
fstmOut     = crrDir / Path( 'Desc/' + strImg[:-4] )     # output file path
Fixt        = o_FileExtensions()
fpDSC       = o_FinaApndExtDscx( fstmOut, Fixt )

# ------------------------------   Load Output   ------------------------------
# we assume that script exsbFabric.py has alread been executed
dmy, HedFbc = LoadFabric( fpDSC.fbrc )  # we need the image size for scaling factors
FImg        = LoadFbrcArrays( fpDSC, 0 )   # FabricIO.py

BinEdg      = i_BinEdgFromLoad( HedFbc.NbinAtt, HedFbc.NbinDty )


# --------------------------------------------------------------------------------
#                         F O C U S   E X T R A C T I O N 
# --------------------------------------------------------------------------------
# we extract a subset of the fabric description
top=160; bot=245; lef=450; rit=540 # black microwave/cabinet
#top=240; bot=320; lef=50; rit=95 # fire exstinguisher
#top=280; bot=315; lef=480; rit=520 # stove
#top=280; bot=320; lef=520; rit=580 # faucet
#top=180; bot=260; lef=330; rit=390 # ventilator/towel dispenser
#top=0; bot=479; lef=0; rit=50
#top=0; bot=50; lef=0; rit=639
#top=0; bot=240; lef=0; rit=320
BoxRep   = i_Bbox( top, bot, lef, rit )

# --- the scaling factors
szImg    = [HedFbc.Hed.szV, HedFbc.Hed.szH]
PrmScl   = i_PrmFbrcFocScl( szImg[0], szImg[1] )

# --- extract and create kernel
IXlin    = f_FbrcFocRngs( BoxRep, PrmScl ) # the linear indices
FFoc     = f_FbrcFocXtr( FImg, IXlin )  # extract focus (subspace)
FKrnl    = f_FbrcKernel( FFoc )         # kernel: take mean of hyperkolumns/biases

BoxRepUrg = u_BboxUnitRg( BoxRep, szImg )


# -------------------------------------------------------------------
#                             M A T C H 
# -------------------------------------------------------------------

# ------------------------------   Python Code   ------------------------------

# we look for the above focus description 'FKrnl' in the image fabric description
# 'FImg'
import AdminPy.MtchFbrc.MtchFbrcKrnl as mfbk

# --- exhaustive, no acceleration / optimization
SCORexhst   = mfbk.Krnl1Exhst( FImg, FKrnl ) 

# --- accelerated using quick-reject conditions
PrmIdf      = mfbk.i_FbrcIdfPrm()
SCORaccel   = mfbk.Krnl1Accel( FImg, FKrnl, PrmIdf, BinEdg )

# ------------------------------   Executable   ------------------------------

# ----------   Save   ----------
FixtFoc     = o_FileExtensFoc()
sfnKrnl     = crrDir / Path( str(fstmOut) + str(f"_P0") + FixtFoc.fbk )
SaveFbrcKernel( FKrnl, sfnKrnl )

# ----------   Match   ----------
from AdminPy.Util.CmndSupp import *
from AdminPy.MtchFbrc.RennMfbrc import *

Args        = o_CmndArgs( 'mtch' )
os.chdir( sb.PthProg['mtchFbrc'] )
Res         = RennMfbrcKrnl( fpDSC.fbrc, sfnKrnl, Args, sb.FipaExe['mfbrckrnl1'] )

# ----------   Load Score Maps   ----------
SCOREXexh  = mfbu.LoadScorMapsKrnlC2F( FKrnl.Dim.nLay )


# ------------------------------   Locate   ------------------------------
import AdminPy.Recognize.RecUtil as rcut
import AdminPy.DescExtr.Features.PixAnf as px

AMINexh   = []
AMAXacc   = []
AIXexh    = []
AIXacc    = []
nLaySus   = FKrnl.Dim.nLay
BBoxExh   = np.zeros( (nLaySus,4), dtype=np.int32 )
BBoxAcc   = np.zeros( (nLaySus,4), dtype=np.int32 )
Sitg      = np.zeros( SCORaccel.AHyk[nLaySus-1].shape, dtype=np.float32 )
for l in range(nLaySus):

    # We measured differently for exhaustive and accelerated, therefore we use
    # minima search for exhaustive, and maxima search for accelerated case:
    
    # dissimilarity measure, ergo minima
    MinExh    = rcut.f_MapLocMinima( SCORexhst.AHyk[l] )

    # similarity measure, ergo maxima
    MaxAcc    = rcut.f_MapLocMaxima( SCORaccel.AHyk[l] )

    # -----  BoundingBox from predicted location
    ixLay     = nLaySus-1-l # counting was inverted during top-down analysis
    BBoxExh[l,:]=rcut.u_OutlFromLoctLay( MinExh.Rw[0], MinExh.Cl[0], ixLay, BoxRepUrg, szImg )
    BBoxAcc[l,:]=rcut.u_OutlFromLoctLay( MaxAcc.Rw[0], MaxAcc.Cl[0], ixLay, BoxRepUrg, szImg )

    print( f" rw={MinExh.Rw[0]:2d}  cl={MinExh.Cl[0]:2d} " )

    AMINexh.append( MinExh )
    AMAXacc.append( MaxAcc )

    # -----  linear indices
    szHor     = FBRCDimLay[0][1]
    AIXexh.append( px.u_PixRCtoIx( MinExh, szHor ) )
    AIXacc.append( px.u_PixRCtoIx( MaxAcc, szHor ) )

    # -----  observe whether acceleration still produces same results
    IxEx   = AIXexh[l]
    IxAc   = AIXacc[l]
    if IxEx[0]!=IxAc[0]:
        print('exhaustive and acceleration not same for layer {l}')

#M7   = SCORaccel.AHyk[0]
#from scipy.ndimage import zoom
#M15  = zoom(M7, zoom=(15/7, 15/7), order=1)

# ------------------------------   Plot   ------------------------------
from PIL import Image
import AdminPy.MtchFbrc.MtchFbrcUtil as mfbu

Irgb         = np.array(Image.open(fipaImg))

IptcRep      = u_IptchFromBbox( Irgb, BoxRep )  # the corresponding patch in the image

AIptchExh    = rcut.u_IptchFromBoxLst( Irgb, BBoxExh )
AIptchAcc    = rcut.u_IptchFromBoxLst( Irgb, BBoxAcc )

figExhst = 1
figAccel = 2

mfbu.p_MapsScor( figExhst, Irgb, IptcRep, SCORexhst, nLaySus, AIptchExh )
mfbu.p_MapsScor( figAccel, Irgb, IptcRep, SCORaccel, nLaySus, AIptchAcc )

# -------------- Executable, again
figExe = 3
mfbu.p_MapsScor( figExe, Irgb, IptcRep, SCOREXexh, nLaySus, AIptchAcc )
