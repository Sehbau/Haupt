

import os, sys

finaPyExe = sys.executable


os.system( finaPyExe + ' exsbFabricKrnl.py') # executable

#os.system( finaPyExe + ' exsbFabricKrnlPy.py') # Python code
#os.system( finaPyExe + ' exsbFabricRec.py') # Python code
