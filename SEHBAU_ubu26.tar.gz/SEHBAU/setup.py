"""
Setting up python code:

- checking for necessary modules
- setting rooth path variable 'rootSehBau'

"""
import importlib.util
import sys

# ------------------------------   Check Modules   ------------------------------
def u_CheckModules(*modNames):

    PipName = {
        'numpy'      : 'numpy',
        'matplotlib' : 'matplotlib',
        'skimage'    : 'scikit-image',
        'torch'      : 'torch'
    }

    Missing = []

    for modName in modNames:
        if importlib.util.find_spec(modName) is None:
            Missing.append(modName)

    if Missing:
        print("ERROR: Missing Python modules:\n")

        for modName in Missing:
            pipName = PipName.get(modName, modName)
            print(f"  {modName:15s}: {sys.executable} -m pip install {pipName}")

        sys.exit(1)
    else:
        print('Modules numpy, matplotlib, skimage present.')


# ------------------------------   Set Rootpath   ------------------------------
from pathlib import Path
import re


def u_SetRootSehBau():

    sfnGlob = Path('AdminPy/globalsSB.py')
    sRoot   = str(Path.cwd())

    if not sfnGlob.exists():
        print(f"ERROR: File not found: {sfnGlob}")
        sys.exit(1)

    sTxt = sfnGlob.read_text(encoding='utf-8')

    # Find assignment to rootSehBau
    Pat = r'(?m)^\s*rootSehBau\s*=.*$'

    sLine = f"rootSehBau = Path( {sRoot!r} )"

    sTxt, nRepl = re.subn(Pat, sLine, sTxt)

    if nRepl != 1:
        print(f"ERROR: Expected exactly one rootSehBau definition, found {nRepl}")
        sys.exit(1)

    # Save modified file
    sfnGlob.write_text(sTxt, encoding='utf-8')

    print(f"variable rootSehBau now set to: {sRoot}")
    print(f"updated file: {sfnGlob.resolve()}")



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_DispProceed   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
"""
def u_DispProceed():

    print(f'')
    print(f'ready to run the example scripts:')
    print(f'      {Path(sys.executable).stem} exsbAll.py')



# ------------------------------   Execute   ------------------------------    
u_CheckModules('numpy', 'matplotlib', 'skimage') #, 'torch')
u_SetRootSehBau()
u_DispProceed()    
