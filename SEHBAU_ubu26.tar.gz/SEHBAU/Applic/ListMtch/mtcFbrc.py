"""

Matching fabrics, 1 vs many. Testing script.

PREVIOUS  iclCollFbrcMaps.py, iclCollFbrcHyko.py
PRESENT   mtcFbrc.py
NEXT      

"""
import sys, subprocess
from pathlib import Path
from dataclasses import is_dataclass

sys.path.insert(0, '../../../SEHBAU')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *
from AdminPy.Collection.IclAdmin import *
from AdminPy.Collection.Collecting import *
from AdminPy.Collection.LoadCollHist import *
from AdminPy.Collection.Register import *
from AdminPy.DescExtr.Hist.LoadFabric import *
from AdminPy.Mtch.MtchFbrcImg import *
from AdminPy.Mtch.OrgFile.OrgFileNameMtch import *
from AdminPy.Util.CmndSupp import *

# ------------------------------   Collections   ------------------------------
bas = 7 # OLTO
#bas = 10; # IndOut15
#bas = 17; # SINR45
#bas = 52; dos('del g:\IMGdat\PLR_NYU2\DSCimg\*.*');
#bas = 60;  # CAMSDD training
#bas = 61;  # CAMSDD validation
#bas = 62;  # CAMSDD testing
#bas = 50;   # indoor67
#bas = 100   # cifar10
#bas = 37;   # vo7 saved to ztst 
#bas = 200; # cityscapes saved to ztst 

PrmMtch     = prmMtchFbrcImg()
# modify if desired:
#                            contours                  forms
#                       vrt hor axi  nil  uni   vrt hor axi  nil  uni
PrmMtch.Wgt = np.array([ 1,  1, 0.5, 0.5, 0.5,   1,  1, 0.5, 0.5, 0.5])

# ------------------------------   Paths, Folds   ------------------------------
Pths, Jcoll = u_CollPaths( bas )
FixtImg     = o_FileExtensions()
FixtColl    = o_FileExtensColl()
FinaColl    = o_FileNameColl( Pths.hist, FixtColl )
Fips1       = o_FileStems( Pths, '', 'cab_fbrc' )

fipaF2Arr   = sb.FipaExe['fbrc2arr']
pthOut      = Path("tmp/fbar")
fpDSC       = o_FinaApndExtDscx( pthOut, FixtImg )

fnMesMtch   = fileNameMtchFbrc()

aFbrcNa     = o_FileNameFrmtLst( 'Fbrc_', Jcoll.Ix0Img, '.fbrc' )
rgstFbrc    = "Regist/FinasFbrc.txt"
SaveFipaLstPrependPath( aFbrcNa, Pths.dbin, rgstFbrc )
v_RegistValid( rgstFbrc )

# -----------------------------   Load   -----------------------------
#fSet        = 3 # finest layer ??? it's coarsest layer
fSet        = 2 #  fine layer
bDispLoad   = 1 
FHYK, Nbin  = LoadCollFbrcHyko( FinaColl, fSet, bDispLoad )
FMBS, Heds  = LoadCollFbrcMaps( FinaColl )

# FMBS.L3

# --------------------------------------------------------------------------------
#                               L O O P   I M A G E S
# --------------------------------------------------------------------------------
Ix0Img   = Jcoll.Ix0Img
nImg     = len(Ix0Img)

print(f"Running {bas}, nImg {nImg}", end="")
cHit = 0
for i in range(0,nImg):

    ixi     = Ix0Img[i]

    pthFbrc  = o_FileNameFrmt( Fips1.fbrc, ixi, '', Jcoll.finaFrmt )

    fipaFbrc = Path(pthFbrc).with_suffix(FixtImg.fbrc)

    # ------------------------------   Init (on 1st image)   ------------------------------
    # scaling factors for focus selection
    if i==0:
        # obtain image size from fabric file
        dmy, HedFbc = LoadFabric( fipaFbrc )

        BinEdg      = i_BinEdgFromLoad( HedFbc.NbinAtt, HedFbc.NbinDty )
        szImg       = [HedFbc.Hed.szV, HedFbc.Hed.szH]

    # ------------------------------   fbrc2arr   ------------------------------
    cmnd = [ fipaF2Arr, fipaFbrc, pthOut ]
    
    try:
        Res    = subprocess.run(cmnd, capture_output=True, text=True, check=True)
        StdOut = Res.stdout
    except subprocess.CalledProcessError as e:
        print(f"Command execution failed: {e.stderr}")
        StdOut = e.stderr


    # ------------------------------   Load   ------------------------------
    bDispLoad  = i==0
    IFb        = LoadFbrcArrays( fpDSC, bDispLoad )
    

    # --------------------------------------------------------------------------------
    #                                 MATCH
    #

    # ------------------------------   Bias [executable]   ------------------------------
    if 1:
        fpMbis = sb.FipaExe['mfbrcbis'];

        cmndM3 = [ fpMbis, fpDSC.fbArM3, FinaColl.fbm3 ]
        cmndM2 = [ fpMbis, fpDSC.fbArM2, FinaColl.fbm2 ]

        ResM  = subprocess.run( cmndM3, capture_output=True, text=True, check=True)
        v_CmndExec( ResM )
        DstTop = LoadArrFltHed( fnMesMtch.bisCollL3 )

        ResM  = subprocess.run( cmndM2, capture_output=True, text=True, check=True)
        v_CmndExec( ResM )
        DstUpp = LoadArrFltHed( fnMesMtch.bisCollL2 )

        #print(DstUpp2[0:10])
        DstEns    = DstTop * DstUpp
        DstEns[i] = np.inf
        
        OrdBis    = ( DstEns ).argsort()
        
        OrdBis    = OrdBis[0:Jcoll.nImg-1]
        #OrdBis = OrdBis[0:round(Jcoll.nImg/2)]
        
    # ------------------------------   Bias [PYTHON]   ------------------------------
    elif 0:
        # top-down
        PrmMtch.ixT = i    # for testing purposes
        OrdBis, DstTop  = MTCHFBRCBIS( IFb, FMBS, PrmMtch )
    else:
        print('No selection made')
        breakpoint()

    # --------------------------------------------------------------------------------
    #                                   H Y K O
    # --------------------------------------------------------------------------------
    if 0:
    # ------------------------------   FULL [PYTHON]   ------------------------------
        if 0:
            OrdFin   = f_MtchFbrcHykLay( IFb.AHYK[fSet], FHYK, PrmMtch, BinEdg )

    # ------------------------------   FULL [executable]   ------------------------------
        elif 1:
            lay     = '3'
            fpMhykL = sb.FipaExe['mfbrchykL']
            cmnd    = [ fpMhykL, fipaFbrc, rgstFbrc, lay ]

            ResML   = subprocess.run( cmnd, capture_output=True, text=True)
            v_CmndExec( ResML )
            
            FinaMes = fileNameMtchFbrc()
            
            DisItg  = sb.Util.LoadArrFltHed( FinaMes.hykLstItg )
            DisMtx  = sb.Util.LoadMtrxFlt( FinaMes.hykLstClw )
            
            DisItg[i] = np.inf
            OrdFin    = DisItg.argsort()
            
    elif 0:
    # ------------------------------   SELC [PYTHON]   ------------------------------
        # selected from bias ordering
        PrmMtch.ixT = -1
        OrdHyk   = f_MtchFbrcHykLay( IFb.AHYK[fSet], FHYK[OrdBis,:], PrmMtch, BinEdg )
        OrdFin   = OrdBis[OrdHyk]
    else:
        # if none of the above
        OrdFin   = OrdBis

    # ------------------------------   Evaluate   ------------------------------
    LbCtg    = Jcoll.LabImg[OrdFin[0:Jcoll.nImg-1]]
    Knt, Edg = np.histogram( LbCtg, bins=Jcoll.nCat )
    ixMx     = Knt.argmax()
    ctgPrd   = LbCtg[ixMx]

    ctgTru   = Jcoll.LabImg[i];
    bHit     = ctgPrd==ctgTru
    cHit    += bHit

    if 1:
        print( f"i {i:3d}, {ctgTru}:  prd {ctgPrd} ({bHit})" )
    elif i%Jcoll.stepDisp==0:
        sb.Util.printDotProg()
        

acc   = cHit / (Jcoll.nImg-1)
print(f"acc {acc:1.4f}")

DispTermNext( 'mtcFbrc.py', 'evaluation' )

# -----------------------------   Plot   -----------------------------
if 1:
    sb.Util.p_Img( 1, FHYK, "Hyperkolumns" )

    sb.Util.p_Img( 4, FMBS.L3, "Bias Maps Layer 3" )



