"""

Descriptor top levesl for place recognition demo.

More details in plcDtop.m

"""
import sys, subprocess
from pathlib import Path

sys.path.insert(0, '..')

import AdminPy as sb
from AdminPy.Orga.OrgFileNames import *

# --- directories
DirNames    = o_DirNames()
Fixt        = o_FileExtensions()   

fipaTopx    = Path( sb.FipaExe['topx'] )      # file path of program binary

# --- list of image files
aImg        = list( Path(DirNames.desc).glob( '*' + Fixt.dsc ) )
nImg        = len( aImg )

# ------------------------------   LOOP IMAGES   ------------------------------
for fipaImg in aImg:

    outNast = fipaImg.stem;
    
    fipsTop = Path(DirNames.dtop) / outNast                  # output filestem
    
    cmnd    = [ fipaTopx, fipaImg, fipsTop ]
    
    Res     = subprocess.run(cmnd, capture_output=True, text=True)
    
    sb.Util.v_CmndExec( Res )

    

    sb.Util.printDotProg()

