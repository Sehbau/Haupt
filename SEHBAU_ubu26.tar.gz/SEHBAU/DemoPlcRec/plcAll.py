"""

The equivalent of plcAll.m. 

"""

import os, sys

finaPyExe = sys.executable

os.system(finaPyExe + ' plcDscx.py')

## -----   Whole Image   -----
os.system(finaPyExe + ' plcMtcImg.py')
os.system(finaPyExe + ' plcMtcHstKol.py')

os.system(finaPyExe + ' plcCollTxtg.py')
os.system(finaPyExe + ' plcMtcTxtColl.py')

os.system(finaPyExe + ' plcFabric.py') # new
os.system(finaPyExe + ' plcMtcFbrc.py') # new

os.system(finaPyExe + ' plcDtop.py')
os.system(finaPyExe + ' plcDtopMtch.py')

os.system(finaPyExe + ' plcCascIdf.py')

#os.system(finaPyExe + ' plcCorrSelf.py')   # does not exist yet
 
os.system(finaPyExe + ' plcDproc.py')       # binning

os.system(finaPyExe + ' plcTransformerHspa.py')       

os.system(finaPyExe + ' plcCollVec.py')   # collects the vector matrices
os.system(finaPyExe + ' plcDeepSetOne.py')       
os.system(finaPyExe + ' plcDeepSetTwo.py')       
os.system(finaPyExe + ' plcTransformerDscs.py')       


## -----   ShapeExtraction using ShapeProposals   -----
os.system(finaPyExe + ' plcShpExtr.py')
# with old module dependencies 
# os.system(finaPyExe + ' plcMtcShp.py')  

## -----   Ego Motion   -----
os.system(finaPyExe + ' plcMotEgo.py')


## -----   Focii using Proposals   -----
# disabled because its a bit slow
if 0:
    os.system(finaPyExe + ' plcFocProp.py')
    os.system(finaPyExe + ' plcMtcProp.py')


## -----   Focii using Zones   -----
# with old module dependencies
#os.system(finaPyExe + ' plcFocZon.py')
#os.system(finaPyExe + ' plcMtcZon1o1.py') # does not exist
# 
# os.system(finaPyExe + ' plcMtcZonLst.py')



print('Demo Place Recognition Completed')



