"""

Example using wrapper routine RennDscx()

Analogous to exsbDscxFull.m

"""
import sys
from pathlib import Path
sys.path.insert(0, '..')
from dataclasses import is_dataclass

import AdminPy as sb
from AdminPy import DescExtr as dscx
from AdminPy.DescExtr.RennDscx import RennDscx
from AdminPy.DescExtr.DescFile import * # LoadDescUniv, LoadDbinUniv
from AdminPy.Orga.OrgFileNames import o_FileExtensions, o_FinaApndExtDscx
from AdminPy.Util.CmndSupp import argsCmndRenn

strImg 	= Path('img1.jpg')
#strImg = Path('img2.jpg')

pthImg	= Path( 'Imgs/' ) / strImg         # image path
pthOut 	= Path( 'Desc/' ) / strImg.stem    # outpath 
optS    = '--depth 2'                      

# ------------------------------   Execute Explicitly   ------------------------------
# not much new here (coming form exsbDscxSimp.py)
cmnd  = [ str(sb.FipaExe['dscx']), str(pthImg), str(pthOut), optS ]

import subprocess

Res = subprocess.run( cmnd, capture_output=True, text=True )

if Res.returncode != 0:
    raise ValueError("dscx did not execute properly somehow")

# ------------------------------   Execute With Wrapper Function   ---------------------
# this is new:
Args       = argsCmndRenn()          # CmndSupp.py
Args.opt   = '--depth 2'             # dont use 'optS'
#Args.opt   = '--sVMX'               # save vector matrices at once
  
StdOut     = RennDscx( pthImg, pthOut, Args, sb.FipaExe['dscx'] )


# ------------------------------   Load   ------------------------------
if 1:
    # appending all file extensions for convenience, thus generating fpDSC.dsc,
    # fpDSC.dsb, ...
    FixtImg     = o_FileExtensions()
    fpDSC       = o_FinaApndExtDscx( str(pthOut), FixtImg )
    DUV, Hed    = LoadDescUniv( fpDSC.dsc )
    BIN, HedB   = LoadDbinUniv( fpDSC.dsbi )
    #AVMX        = LoadDescVMX( fpDSC.vmx )

    #RRE         = LoadCntRRE( fpDSC.rre ) # see exsbCntPat.py
    #print(RRE.ARDG[0].Ori)
    
else:
    # or explicitly
    fpDsc       = pthOut.with_suffix('.dsc')
    fpBin       = pthOut.with_suffix('.dsb')
    DUV, Hed    = LoadDescUniv( fpDsc )
    BIN, HedB   = LoadDbinUniv( fpBin )

# from dataclasses import asdict
print( f'Head  nLev {Hed.nLev}  depth {Hed.depth}' )

from dataclasses import fields

FldNames = [f.name for f in fields(DUV)]
print( FldNames )

print( DUV.Labs.Shp.Sco )



