"""

Descriptor anfang.

To be developed from:
- LoadDescription.py
- ReadDescHeaders.py
- ...

------------------------------   CLS SUM   ------------------------------
dimRast

------------------------------   DEF SUM   ------------------------------


"""
from dataclasses import dataclass, field
import numpy as np


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass(slots=True)
class dimRast:          # ''''''''''''''''''''   dimRast   ''''''''''''''''''''
    """Dimension of raster. Simple version with only one integrated layer. See
    FabricAnf.py for 4-layer version.
    """
    vrt:     int = 3
    hor:     int = 3
    nCll:    int = 9

    vrtBase: int = 4
    horBase: int = 4
    nUnits:  int = 16


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_DimRast   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII

Set dimension parameters of raster (overlapping windows)
"""
def i_DimRast( vrt: int, hor: int ) -> dimRast:

    D          = dimRast()

    D.vrt      = vrt
    D.hor      = hor
    D.nCll     = vrt*hor

    D.vrtBase  = vrt+1
    D.horBase  = hor+1
    D.nUnits   = D.vrtBase * D.horBase

    return D


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_RastWin   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Calculate the indices for the windows
"""
def f_RastWin( Dim: dimRast ):

    Base     = np.arange( Dim.nUnits ).reshape( Dim.vrtBase, Dim.horBase )

    IXWin    = np.lib.stride_tricks.sliding_window_view(Base, (2,2))
    IXWin    = IXWin.reshape( Dim.nCll, 4 )

    return IXWin
    
