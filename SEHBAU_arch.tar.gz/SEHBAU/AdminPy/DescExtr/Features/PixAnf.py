"""

Pixels. As row/col/val, etc.

As used for reading boundary pixels, RecUtil.py

For pixels and points loaded from 'dscx' see PixPointsAnf.py

------------------------------   CLS SUM   ------------------------------
class pixRCi:
class pixRCv:

------------------------------   DEF SUM   ------------------------------
def i_PixRCv( nEnt )->pixRCv:
def u_PixRCtoIx( Px: pixRCv, szH: int ):

Elsewhere:
- position in PosAnf.py
- pixels and points loaded from 'dscx' in PixPointsAnf.py

"""
from dataclasses import dataclass, field
import numpy as np
import numpy.typing as npt



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass(slots=True)
class pixRCi:                # ''''''''''''''''''''   pixRCi   ''''''''''''''''''''
    """
    Pixel coordinates as row and columns. 'i' for integer.
    """
    Rw:   npt.NDArray[np.int32]   = None
    Cl:   npt.NDArray[np.int32]   = None
    nEnt: int=0
    

@dataclass(slots=True)
class pixRCv:                # ''''''''''''''''''''   pixRCv   ''''''''''''''''''''
    """
    Pixel coordinates as row and colums AND their values. 'v' for values.
    """
    Rw:   npt.NDArray[np.int32]   = None
    Cl:   npt.NDArray[np.int32]   = None
    Vl:   npt.NDArray[np.float32] = None
    nEnt: int=0


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_PixRCv   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII

Sets all entries to zero.

cfro RecUtil.py
"""
def i_PixRCv( nEnt: int ) -> pixRCv:

    return pixRCv(
        Rw = np.zeros( nEnt,  dtype=np.int32 ),
        Cl = np.zeros( nEnt,  dtype=np.int32 ),
        Vl = np.zeros( nEnt,  dtype=np.float32 ), nEnt=nEnt   )
    

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_PixRCtoIx   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Linear (map) index from the coordinates.
"""
def u_PixRCtoIx( Px: pixRCv, szH: int ):

    return np.array( Px.Rw*szH + Px.Cl )
