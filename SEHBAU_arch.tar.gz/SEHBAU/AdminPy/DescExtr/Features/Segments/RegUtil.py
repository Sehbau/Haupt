"""

Region utilities.

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def u_RegUnivNpx( AREG ):

def u_RegIxLin1( AREG, lev, dth, ixR ):
def u_RegCoord1( AREG, lev, dth, ixR, szM ):

def u_RegPixToMapD1(REG, szM):
def u_RegPixToMapSel( ARegPix, Org, IxReg, szM, gry ):

"""
import numpy as np

import matplotlib.pyplot as plt

import warnings



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_RegUnivNpx   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Determines number of pixels for each boundary of the boundary space.

IN    AREG      region universe, [nLev][depth]
OUT   Npix      [nLev][nBonPerLev]
"""
def u_RegUnivNpx( AREG ):

    nLev, depth  = AREG.shape

    ANPix    = []
    for l in range(nLev):

        NPix = []
        for d in range(depth):

            nReg   = AREG[l][d].nCC
            Npix   = np.zeros( nReg, dtype=np.int32 )

            Anf    = AREG[l][d].Anf
            for r in range(nReg):
                Npix[r] = Anf[r+1]-Anf[r]

            NPix.append(Npix)
            
        ANPix.append(NPix)

    return ANPix



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_RegIxLin1   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Extracts linear region indices for ONE region of the region universe, by specifying
level, depth and region index.

IN    AREG   region universe
      lev    level
      dth    depth
      ixR    selected region index
OUT   IxReg  linear region indices
"""
def u_RegIxLin1( AREG, lev, dth, ixR ):

    RegL    = AREG[lev][dth]

    anf     = RegL.Anf[ixR]
    trm     = RegL.Anf[ixR+1]
    IxReg   = RegL.IxLin[anf:trm]

    return IxReg


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_RegCoord1   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Extracts row and column coordinates of ONE region from the region universe, by
specifying level, depth and region index.

IN    AREG      region universe
      szM       map size
OUT   Row, Col  coordinates
"""
def u_RegCoord1( AREG, lev, dth, ixR, szM ):

    # --- same as above for u_RegIxLin1
    RegL    = AREG[lev][dth]

    anf     = RegL.Anf[ixR]
    trm     = RegL.Anf[ixR+1]
    IxReg   = RegL.IxLin[anf:trm]

    # from linear indices to coordinates:
    Row, Col  = np.unravel_index(IxReg, szM )

    return Row, Col



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_RegPixToMapD1   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Places region pixels for one depth into a gray-map and an RGB map.

IN    REG    region structure, nCC, Anf, RGB, IxLin
      szM    map size
OUT   Mgry   uint8 [szV szH]
      Irgb   uint8 [szV szH, 3]
"""
def u_RegPixToMapD1(REG, szM):

    szV, szH = szM
    nCC      = REG.nCC
    nPxMap   = szV * szH

    Mgry = np.zeros( (szV, szH),    dtype=np.uint8)
    Irgb = np.zeros( (szV, szH, 3), dtype=np.uint8)

    for c in range(nCC):

        anf = REG.Anf[c]
        trm = REG.Anf[c+1]

        Ix  = REG.IxLin[anf:trm]

        red, grn, blu = REG.RGB[c]

        gry = red * 0.2989 + grn * 0.5870 + blu * 0.1140

        # --- gray map
        Mgry.flat[Ix] = np.uint8(gry)

        # --- RGB map
        iv, ih = np.unravel_index( Ix, szM )
        Irgb[iv, ih, 0] = np.uint8(red)
        Irgb[iv, ih, 1] = np.uint8(grn)
        Irgb[iv, ih, 2] = np.uint8(blu)
        # this plots the maps side-by-side:
        #Irgb.flat[Ix]              = np.uint8(red)
        #Irgb.flat[Ix + nPxMap]     = np.uint8(grn)
        #Irgb.flat[Ix + nPxMap * 2] = np.uint8(blu)

    return Mgry, Irgb



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_RegPixToMapSel   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Places selected CCs (their region pixels) from different depths (of one tree/level)
into one map (no RGB plotting).
    
IN   ARegPix  region pixels from one tree (list of objects/dicts)
     Org      origin object/dict with keys 'Dth' and 'CC'
     IxReg    the selected regions to be placed into the map (array/list)
     szM      size map 
     gry      gray-scale level
OUT  Mp       map

"""
def u_RegPixToMapSel( ARegPix, Org, IxReg, szM, gry ):

    Mp = np.zeros( szM, dtype=np.int32 )
    
    for ixr in IxReg:

        dth   = Org.Dth[ixr]
        ixCC  = Org.CC[ixr]

        Rpx   = ARegPix[dth]
        af    = Rpx.Anf[ixCC]   # anfang of selected CC
        ed    = Rpx.Anf[ixCC+1] # ende
        
        IxLin        = Rpx.IxLin[af:ed]
        
        IxRow, IxCol = np.unravel_index( IxLin, szM ) # order='F'
        
        Mp[IxRow, IxCol] = gry         # assign the gray value to the map
        
    return Mp



