"""

Boundary utilities.


------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def u_BonNpixSpc( ABON ):
def u_BonCoord1( ABON, lev, ixR ):
def f_BonPixShift( aPix, offRw, offCl ):


"""
import numpy as np



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_BonNpixSpc   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Determines number of pixels for each boundary of the boundary space.

IN    ABON      boundary space
OUT   Npix      [nLev][nBonPerLev]
"""
def u_BonNpixSpc( ABON ):

    nLev    = len( ABON )

    NPix    = []
    for l in range(nLev):

        nBon   = len( ABON[l] )
        Npix   = np.zeros( nBon, dtype=np.int32 )

        for b in range(nBon):
            
            Npix[b] = ABON[l][b].nEnt

        NPix.append(Npix)

    return NPix



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_BonCoord1   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Extracts row and column coordinates of ONE (region) boundary from the boundary space, by
specifying level and region index.

IN    ABON      region universe
OUT   Row, Col  coordinates
"""
def u_BonCoord1( ABON, lev, ixR ):

    Bon     = ABON[lev][ixR]

    return Bon.Rw, Bon.Cl



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_BonPixShift   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Shifts boundary pixel coordinates by row and column offsets.

IN    aPix : list of boundary pixel objects with Rw and Cl attributes.
      offRw : int or float, row offset.
      offCl : int or float, column offset.

OUT   aScl : list of shifted boundary pixel objects.
"""
def f_BonPixShift( aPix, offRw, offCl ):

    aScl = []

    for Pix in aPix:
        Pix.Rw += offRw
        Pix.Cl += offCl
        aScl.append(Pix)

    return aScl
