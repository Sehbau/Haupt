"""

Reads region and boundary pixels from file.

------------------------------   CLS SUM   ------------------------------
none here. See PixAnf and FeatSegAnf

------------------------------   DEF SUM   ------------------------------
def ReadRegPixBlok(fileID) -> regPixBlok:
def ReadBonPixSegw(fileID: io.BufferedReader, bDisp: bool = False):

def ReadCrvPixBlok to be impl. 

"""
from dataclasses import dataclass, field
import io
from typing import List
import numpy as np

from AdminPy.DescExtr.Features.PixAnf import *
from AdminPy.DescExtr.Features.FeatSegAnf import *


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
# none here. See PixAnf and FeatSegAnf


# --------------------------------------------------------------------------------
#                                 D E F I N I T I O N S
# --------------------------------------------------------------------------------

""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadRegPixBlok   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Loads the region pixels as block (not as segments)
    
Loads as saved under w_BWcoco() in CoCoIO.h.

Plotted with PlotRegPix.m
"""
def ReadRegPixBlok(fileID) -> regPixBlok:
    
    # %% ====  sizes  ====
    nON    = int(np.fromfile(fileID, dtype=np.int32, count=1)[0])
    nCC    = int(np.fromfile(fileID, dtype=np.int32, count=1)[0])

    # %% ====  pixels  ====
    IxLin  = np.fromfile(fileID, dtype=np.int32, count=nON)
    LbCC   = np.fromfile(fileID, dtype=np.int32, count=nON)
    Anf    = np.fromfile(fileID, dtype=np.int32, count=nCC+1)
    
    # Read RGB values as unsigned 8-bit integers
    RGBraw = np.fromfile(fileID, dtype=np.uint8, count=nCC * 3)

    # --- verify
    idf    = np.fromfile(fileID, dtype=np.int32, count=1)[0]
    assert idf == -1, f"Verification failed: expected -1, got {idf}"

    # %% ====  rearrange RGB matrix  ====
    # MATLAB: reshape(RGB, 3, nCC)' reads column-wise, then transposes.
    # Python: Reshaping directly to (nCC, 3) yields the identical structure.
    RGB    = RGBraw.reshape(nCC, 3)

    # Instantiate and return the typed dataclass object
    return regPixBlok(
        IxLin = IxLin,
        LbCC  = LbCC,
        Anf   = Anf,
        RGB   = RGB,
        nON   = nON,
        nCC   = nCC
    )


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBonPixSegw   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Loads the boundary pixels segment-wise from a binary file.

IN   fileID   An open binary file object (e.g., opened with 'rb')
     bDisp    Boolean flag to print layout diagnostics
OUT  A BonPixResult instance containing (APix, nBon, szM, Org)
"""
def ReadBonPixSegw(fileID: io.BufferedReader, bDisp: bool = False):

    # ====  sizes  ====
    # MATLAB: fread(fileID, 1, 'int=>single')
    nBon = np.fromfile(fileID, dtype=np.int32, count=1)[0]
    szM  = np.fromfile(fileID, dtype=np.int32, count=2)

    if bDisp:
        print(f"\t[{int(szM[0]):4d} {int(szM[1]):4d}] nBon {nBon:4d} ", end="")

    # ====  arrays  ====
    APix = []
    # Initialize Org arrays inside the dataclass structure
    Dth = np.zeros(nBon, dtype=np.uint8)
    CC  = np.zeros(nBon, dtype=np.int32)

    for b in range(nBon):

        nPx = np.fromfile(fileID, dtype=np.int32, count=1)[0]

        # MATLAB: fread(fileID, 1, 'uint8=>single') + 1
        # Keeps 1-based indexing if you want compatibility with previous MATLAB code
        # Change "+ 1.0" to "+ 0.0" if you are fully migrating to 0-based Python indexing!
        Dth[b] = np.fromfile(fileID, dtype=np.uint8, count=1)[0]
        CC[b]  = np.fromfile(fileID, dtype=np.int32, count=1)[0]

        # Read row and column coordinate sequences
        Rw = np.fromfile(fileID, dtype=np.int16, count=nPx)
        Cl = np.fromfile(fileID, dtype=np.int16, count=nPx)

        # Instantiate a dataclass for this block of pixels
        APix.append( pixRCi( Rw=Rw, Cl=Cl, nEnt=nPx ) )

    # construct the final Org object
    Org = regOrigin( Dth=Dth, CC=CC )

    # File footer validation check
    idf = np.fromfile(fileID, dtype=np.int32, count=1)[0]
    assert idf == 626, f"File corruption or offset mismatch error: {idf} != 626"

    if bDisp:
        print()

    return APix, nBon, szM, Org



