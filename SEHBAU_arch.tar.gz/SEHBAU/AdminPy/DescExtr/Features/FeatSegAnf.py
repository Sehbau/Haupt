"""

Feature segments. Regions and their boundaries.

For regions the organization of data structures is as provided here.
For boundaries we use also the pixel data structures in PixAnf.py


------------------------------   CLS SUM   ------------------------------
class regPixBlok:       data
class regOrigin:        info
class regUnvFetCount:   info

class bonInfo:          info

------------------------------   DEF SUM   ------------------------------


Elsewhere:
- pixels in PixAnf.py
- position in PosAnf.py

"""
import os
from dataclasses import dataclass, field
from typing import List, Any

import numpy as np


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class regPixBlok:
    """
    Structure representing region pixels as a block.
    """
    IxLin: np.ndarray = None
    LbCC:  np.ndarray = None
    Anf:   np.ndarray = None
    RGB:   np.ndarray = None
    nON:   int = 0
    nCC:   int = 0


@dataclass
class regOrigin:
    """
    Holds depth and connected component indices
    """
    Dth: np.ndarray = None  # tree depth array
    CC:  np.ndarray = None  # connected component index array


@dataclass
class regUnvFetCount:
    """
    Structure holding the sizes/counts matrices for the universe.
    Returned as 2nd argument when loading.
    """
    Ncc: np.ndarray = None
    Non: np.ndarray = None
    nLev: int = -1


@dataclass
class bonSpcInfo:
    """
    Holds sizes and origin for boundary pixels for a space.
    Returned as 2nd argument when loading.
    """
    Nbon: np.ndarray  # Array tracking number of boundaries per level
    SzM:  np.ndarray  # map sizes per level [nLev 2]
    AOrg: List[Any]   # List containing OrgData instances for each level



