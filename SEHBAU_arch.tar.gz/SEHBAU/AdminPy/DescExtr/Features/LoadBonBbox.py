"""

Loading bounding boxes.

cfro exsbSmlObjReg.py

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def LoadBonBboxPyr(lfn: str | Path) -> bonBboxPyr:
def LoadBboxFunv(lfn: str | Path) -> funvBbox:

"""
import os
from dataclasses import dataclass, field
from typing import List, Any
from pathlib import Path

import numpy as np
import numpy.typing as npt

#from AdminPy.DescExtr.Features.FeatSegAnf import *

    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

@dataclass(slots=True)
class bonBboxPyr:
    """Bounding boxes per pyramid level.

    Each level contains an (nBon, 6) float32 array:
    [top, bottom, left, right, contrast, depth].
    """
    ABbox: list[npt.NDArray[np.float32]]
    Nbon:  npt.NDArray[np.int32]
    IxX:   npt.NDArray[np.int32]


def LoadBonBboxPyr(lfn: str | Path) -> bonBboxPyr:

    with open(lfn, "r", encoding="utf-8") as fid:

        # --------------------   Head   --------------------
        HedLine = fid.readline().split()

        # ----- nLev
        nLev    = int( HedLine[0] )
        print(f"[nLev {nLev}] ", end="")

        # ----- Counts per level
        Nbon    = np.empty(nLev, dtype=np.int32)
        for l in range(nLev):
            Nbon[l] = int( HedLine[l+1] )
            print(f"{Nbon[l]:4d} ", end="")

        print()

        # --------------------   Data   --------------------
        # ----- Bounding boxes and extrema
        ABbox = []
        IxX = None

        for l in range(nLev):
            nBon = int(Nbon[l])
            PRM = np.empty((nBon, 6), dtype=np.float32)

            for c in range(nBon):
                line = fid.readline()
                if not line:
                    raise EOFError(
                        f"Unexpected end of file at level {l}, bbox {c}"
                    )

                values = np.fromstring(line, sep=" ", dtype=np.int32)

                if values.size < 6:
                    raise ValueError(
                        f"Incomplete bbox row at level {l}, bbox {c}: "
                        f"expected 6 values, got {values.size}"
                    )

                PRM[c, :] = values[:6]

            ABbox.append(PRM)

            # Indices of extrema
            line = fid.readline()
            if not line:
                raise EOFError(
                    f"Unexpected end of file while reading IxX at level {l}"
                )

            values = np.fromstring(line, sep=" ", dtype=np.int32)
            if values.size < 2:
                raise ValueError(
                    f"Expected 2 extrema indices at level {l}"
                )

            IxX = values[:2].copy()

        # ----- End marker
        line = fid.readline()
        if not line:
            raise EOFError("Missing end marker 222")

        idEnd = int(line.split()[0])
        if idEnd != 222:
            raise ValueError(f"Invalid end marker: expected 222, got {idEnd}")

    return bonBboxPyr( ABbox=ABbox, Nbon=Nbon, IxX=IxX )



@dataclass(slots=True)
class funvBbox:
    """Bounding boxes per pyramid level and map depth. as saved in .bonBbxRaw file

    ABbox[l][d] has shape (Nflk[l, d], 6), with columns:
    [top, bottom, left, right, contrast, depth].
    """
    ABbox: list[list[npt.NDArray[np.float32]]]
    Nflk: npt.NDArray[np.int32]


def LoadBboxFunv(lfn: str | Path) -> funvBbox:

    with open(lfn, "r", encoding="utf-8") as fid:

        # --------------------   Head   --------------------
        HedLine = fid.readline().split()
        # ----- nLev / depth
        nLev, depth = map(int, HedLine[:2])
        print(f"[nLev {nLev}, depth {depth}]")

        # ----- Counts
        Nflk = np.empty((nLev, depth), dtype=np.int32)

        c=2
        for l in range(nLev):
            for d in range(depth):
                Nflk[l,d] = int( HedLine[c] )
                c += 1

        print(Nflk)

        # --------------------   Data   --------------------
        # ----- Bounding boxes
        ABbox = []

        for l in range(nLev):
            ABoxLev = []

            for d in range(depth):
                nCC = int(Nflk[l, d])
                PRM = np.empty((nCC, 6), dtype=np.float32)

                for c in range(nCC):
                    line = fid.readline()
                    if not line:
                        raise EOFError(
                            f"Unexpected end of file at level {l}, "
                            f"depth {d}, bbox {c}"
                        )

                    row = np.fromstring(line, sep=" ", dtype=np.int32)
                    if row.size < 6:
                        raise ValueError(
                            f"Incomplete bbox at level {l}, depth {d}, "
                            f"bbox {c}: expected 6 values, got {row.size}"
                        )

                    PRM[c, :] = row[:6]

                ABoxLev.append(PRM)

            ABbox.append(ABoxLev)

        # ----- End marker
        line = fid.readline()
        if not line:
            raise EOFError("Missing end marker 222")

        idEnd = int(line.split()[0])
        if idEnd != 222:
            raise ValueError(f"Invalid end marker: expected 222, got {idEnd}")

    return funvBbox(ABbox=ABbox, Nflk=Nflk)
