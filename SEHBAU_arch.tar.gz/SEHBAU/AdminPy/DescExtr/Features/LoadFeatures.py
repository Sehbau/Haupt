"""

Loading feature segments and keypoints.

Dataclasses for feature segments in RegRead.py
Dataclasses for feature info is in here.

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def LoadRegUnv(lfn):
def LoadBonPixSpc(lfn: str, bDisp: bool = False):

def LoadDescKeyp(lfn: str, vers: int = 2):

def ReadDkypVlsF( fid, bPt4):
def ReadDkypVlsF( fid: BinaryIO, bPt4: bool ) -> dkypVls:
def ReadDkypVlsSpcF( fid: BinaryIO, bFll: bool = False ) -> Tuple[List[dkypVls], np.ndarray]:
def ReadFrmKypVlsSpc( fid: BinaryIO ) -> Tuple[List[np.ndarray], np.ndarray]:
def LoadDkypVals( lfn: str ) -> Tuple[dkypVlsUnv, dkypNvls, Any]:

to be implemented:
  def LoadCntUnv


"""
import os
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, BinaryIO, Tuple
from pathlib import Path

import numpy as np
import numpy.typing as npt

from AdminPy.DescExtr.Features.FeatSegAnf import *
from AdminPy.DescExtr.Features.Segments.ReadFeatSeg import *

from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import *
from AdminPy.DescExtr.DescFile.PixPoints.ReadPixPoints import *


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadRegUnv   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the region universe RUV as saved with s_FunvReg.m (FunvIO.h)
Plotted with PlotRegUnv.m, p_RegPixDepthOne

"""
def LoadRegUnv(lfn):

    try:
        # Open in binary read mode ('rb')
        fileID = open(lfn, 'rb')
    except FileNotFoundError:
        raise FileNotFoundError(f"file {lfn} not found")

    # %% -----------   Header   -------------
    # 'int=>single' reads a 4-byte int and casts it
    nLev  = int(np.fromfile(fileID, dtype=np.int32, count=1)[0])
    depth = int(np.fromfile(fileID, dtype=np.int32, count=1)[0])

    # Pre-allocate zero matrices
    Ncc = np.zeros((nLev, depth), dtype=np.int32)
    Non = np.zeros((nLev, depth), dtype=np.int32)

    # Python loops are 0-indexed: 0 to nLev-1 and 0 to depth-1
    for l in range(nLev):
        for d in range(depth):
            nCC = int(np.fromfile(fileID, dtype=np.int32, count=1)[0])
            nON = int(np.fromfile(fileID, dtype=np.int32, count=1)[0])
            
            Ncc[l, d] = nCC
            Non[l, d] = nON

    # %% -----------   Pixels   -------------
    # Create a 2D object array to act exactly like MATLAB's cell(nLev, depth)
    APIX = np.empty((nLev, depth), dtype=object)
    
    for l in range(nLev):
        for d in range(depth):
            # Calls your previously defined ReadRegPixBlok dataclass function
            APIX[l,d] = ReadRegPixBlok(fileID)

    # %% -----------   Trailer   -------------
    idf = np.fromfile(fileID, dtype=np.int32, count=1)[0]
    assert idf == -22222, f"LoadRegUnv: end-btw idf not correct. Expected -22222, got {idf}"

    fileID.close()

    # Wrap metadata fields into a dataclass object
    Kt = regUnvFetCount( Ncc=Ncc, Non=Non, nLev=nLev )

    #print()  # Mimics fprintf('\n')
    
    return APIX, Kt




""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadBonPixSpc   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the boundary space BSP, the space of boundary pixels, as saved under
B_BON/Util/BonIO.h-s_BonPixPyr()
    
IN   lfn      file path string
     bDisp    boolean flag to print layout diagnostics
OUT  APIX     list of level pixel data cells
     J        a bonSpcInfo dataclass object containing level metadata

"""
def LoadBonPixSpc(lfn: str, bDisp: bool = False):

    if not os.path.exists(lfn):
        raise FileNotFoundError(f"file {lfn} not found")
        
    with open(lfn, 'rb') as fileID:

        # -----  header  -----
        nLev  = int(np.fromfile(fileID, dtype=np.uint8, count=1)[0])
        NbonH = np.fromfile(fileID, dtype=np.int32, count=nLev)
        
        if bDisp:
            print(f"[nLev {nLev}] ")
            
        # =====  Space
        APIX = []
        
        # Pre-initialize tracking containers for dataclass construction
        Nbon  = np.zeros( nLev, dtype=np.int32)
        SzM   = np.zeros( (nLev, 2), dtype=np.int32)
        AOrg = []
        
        for l in range(nLev):

            # Calls the previously translated block processing function
            APix, nBon, szM, Org = ReadBonPixSegw( fileID, bDisp )
            
            APIX.append(APix)
            Nbon[l]    = nBon
            SzM[l,:]   = szM
            AOrg.append(Org)
            
        # Parse footer indicator block
        idf = np.fromfile(fileID, dtype=np.int32, count=1)[0]
        
        # fileID closes automatically here due to the 'with' context manager
        
    # File footer validation check
    assert idf == 333, f"File corruption or offset mismatch error: {idf} != 333"
    
    # Wrap tracking arrays into the J dataclass container
    J = bonSpcInfo( Nbon=Nbon, SzM=SzM, AOrg=AOrg )
    
    return APIX, J



@dataclass
class dunvNumKyp:
    Ncnt: List[int] = field(default_factory=list)
    Nfrm: List[int] = field(default_factory=list)
    Narc: List[int] = field(default_factory=list)
    Nstr: List[int] = field(default_factory=list)
    nLev: int = 0
    szV: float = 0.0
    szH: float = 0.0
    ntDsc: float = 0.0

@dataclass
class dunvKEYP:
    ACNT: List[Any] = field(default_factory=list)  # Output of ReadDescPtsSpcF
    AFRM: List[Any] = field(default_factory=list)  # Output of ReadFrmKeyPtsSpc
    AARC: List[Any] = field(default_factory=list)  # Output of ReadDescPtsSpcS
    ASTR: List[Any] = field(default_factory=list)  # Output of ReadDescPtsSpcS


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescKeyp   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

    Loads the descriptor keypoints as generated with option --saveKeyp.
"""
def LoadDescKeyp(lfn: str, vers: int = 2): # -> tuple[dunvKEYP, dunvNumKyp, Hed]:

    if not os.path.exists(lfn):
        raise FileNotFoundError(f"file {lfn} not found")
        
    with open(lfn, 'rb') as fileID:

        ## -----------------------   Header   ---------------------------
        Hed = ReadDescFileHead(fileID, 15)
        
        ## -----------------------   Spaces   ---------------------------
        D   = dunvKEYP()
        Kt  = dunvNumKyp()
        
        D.ACNT, Kt.Ncnt = ReadDescPtsSpcF(fileID)   # skelet
        D.AFRM, Kt.Nfrm = ReadFrmKeyPtsSpc(fileID)  # form
        D.AARC, Kt.Narc = ReadDescPtsSpcS(fileID)   # arcs
        D.ASTR, Kt.Nstr = ReadDescPtsSpcS(fileID)   # strs
        
        ## -----------------------   Trailer   ---------------------------
        idfArr = np.fromfile(fileID, dtype=np.int32, count=1)
        idf    = int(idfArr[0]) if idfArr.size > 0 else None
            
    if idf is None or idf != 99999:
        print(f"file identifier not correct {idf}. Expected 99999")
        input("pausing in LoadDescImag... Press Enter to continue.")

    ## ------   A2S   -------
    Kt.nLev  = int(Hed.nLev)
    Kt.szV   = float(Hed.szV)
    Kt.szH   = float(Hed.szH)
    Kt.ntDsc = float(Hed.ntDsc)

    return D, Kt, Hed



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDkypVlsF   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

def ReadDkypVlsF( fid, bPt4):

    P = {}

    # Read 1 32-bit integer and cast to single (float32), matching 'int=>single'
    n_pts_arr = np.fromfile(fid, dtype=np.int32, count=1)
    if n_pts_arr.size == 0:
        raise EOFError("Reached end of file while reading nPts.")
        
    P['nPts'] = n_pts_arr.astype(np.float32)[0]
    
    # Use an integer count for reading the subsequent arrays
    n_vls = int(n_pts_arr[0])

    # Read n_vls 32-bit floats ('float=>single')
    P['Ep1'] = np.fromfile(fid, dtype=np.float32, count=n_vls)
    P['Ep2'] = np.fromfile(fid, dtype=np.float32, count=n_vls)
    P['Btw'] = np.fromfile(fid, dtype=np.float32, count=n_vls)

    if bPt4:
        P['Ep4'] = np.fromfile(fid, dtype=np.float32, count=n_vls)

    return P
"""


    
@dataclass
class dkypVls:
    nPts: np.float32
    Ep1: np.ndarray
    Ep2: np.ndarray
    Btw: np.ndarray
    Ep4: Optional[np.ndarray] = None


"""RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDkypVlsF   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the values saved with keypoints. Single array.

It's the same function as ReadDescPtsF.m but only for a single array, not two arrays
(coordinates).

IN  fid    file pointer (opened with 'rb').
    bPt4   (bool): flag indicating whether to read the fourth array (Ep4).
OUT         values corresponding to keypoints (not point themselves)

"""
def ReadDkypVlsF( fid: BinaryIO, bPt4: bool ) -> dkypVls:

    nPtsRaw = np.fromfile( fid, dtype=np.int32, count=1 )
    if nPtsRaw.size == 0:
        raise EOFError("Unexpected end of file while reading nPts.")

    nPts    = np.float32( nPtsRaw[0] )  # # descriptors ('int=>single')
    nVls    = int( nPtsRaw[0] )

    Ep1     = np.fromfile( fid, dtype=np.float32, count=nVls )
    Ep2     = np.fromfile( fid, dtype=np.float32, count=nVls )
    Btw     = np.fromfile( fid, dtype=np.float32, count=nVls )

    Ep4     = None
    if bPt4:
        Ep4 = np.fromfile( fid, dtype=np.float32, count=nVls )

    return dkypVls( nPts=nPts, Ep1=Ep1, Ep2=Ep2, Btw=Btw, Ep4=Ep4 )




""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDkypVlsSpcF   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of keypoints as saved under DescAttIO.h-w_DescPtsSpcF

For contours, arc, str. For form see below.

"""
def ReadDkypVlsSpcF( fid: BinaryIO, bFll: bool = False ) -> Tuple[List[dkypVls], np.ndarray]:

    nLev, Npts = ReadDescSpcHead( fid )

    ALev: List[dkypVls] = []
    for l in range( int( nLev ) ):
        
        levData = ReadDkypVlsF( fid, bFll )
        
        assert Npts[l] == levData.nPts, 'point count not matching'
        
        ALev.append( levData )

    return ALev, Npts



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   ReadFrmKypVlsSpc   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Reads space of form coordinates

cfro LoadDescKeyp below
"""
def ReadFrmKypVlsSpc( fid: BinaryIO ) -> Tuple[List[np.ndarray], np.ndarray]:

    nLev, Nfrm = ReadDescSpcHead( fid )

    AFRM: List[np.ndarray] = []
    for l in range( int( nLev ) ):

        frmDat, szD = ReadMtrxDat( fid, np.float32 )

        assert Nfrm[l] == szD.nObs, 'frm count not matching'

        AFRM.append( frmDat )

    return AFRM, Nfrm




@dataclass
class dkypVlsUnv:
    ASKL: List[dkypVls]
    AARC: List[dkypVls]
    ASTR: List[dkypVls]
    AFRM: List[Any]      # Replace Any with your Form dataclass once translated


@dataclass
class dkypNvls:
    Nskl: np.ndarray
    Narc: np.ndarray
    Nstr: np.ndarray
    Nfrm: np.ndarray


    
""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDkypVals   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the values taken at descriptor keypoints.

"""
def LoadDkypVals( lfn: str ) -> Tuple[dkypVlsUnv, dkypNvls, Any]:

    if not os.path.isfile( lfn ):
        raise FileNotFoundError( f'file {lfn} not found' )

    with open( lfn, 'rb' ) as fileID:

        # -----------------------   Header   ---------------------------
        Hed = ReadDescFileHead( fileID, 16 )

        # -----------------------   Spaces   ---------------------------
        ASKL, Nskl = ReadDkypVlsSpcF( fileID )   # skelet

        AARC, Narc = ReadDkypVlsSpcF( fileID )   # arc

        ASTR, Nstr = ReadDkypVlsSpcF( fileID )   # str

        AFRM, Nfrm = ReadFrmKypVlsSpc( fileID )  # form

        # -----------------------   Trailer   ---------------------------
        idfRaw = np.fromfile( fileID, dtype=np.int32, count=1 )

    idf = int(idfRaw.item()) if idfRaw.size == 1 else None
    #idf = int( idfRaw ) if idfRaw.size > 0 else None

    if idf is None or ( idf != 99999 ):
        print( f'file identifier not correct {idf}. Expected 99999' )
        input( 'pausing in LoadDkypVals' )

    D  = dkypVlsUnv( ASKL=ASKL, AARC=AARC, ASTR=ASTR, AFRM=AFRM )
    Kt = dkypNvls(   Nskl=Nskl, Narc=Narc, Nstr=Nstr, Nfrm=Nfrm )

    return D, Kt, Hed

