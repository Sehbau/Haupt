"""
Bin numbers

------------------------------   CLS SUM   ------------------------------
class dimGrid:
class bnumDsc1:
class bnumSpaClw:

------------------------------   DEF SUM   ------------------------------
def ReadBnumDsc1(fileID):
def ReadBnumSpat(fileID):
def ReadBnumATT(fid ):

def f_HistClwNbinTotDty1( N: bnumDsc1 ) -> bnumDsc1:

def i_HistBinNumAdjAtt( NATT: bnumATT ):
def u_BnumFromSpaClw( N: bnumSpaClw ):

def i_BinEdgFromLoad( NbinAtt: bnumATT, NbinDty ):

def DispBnumDsc1( N, jStr ):
def DispBnumSpat( N ):

"""
import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, IO
from collections.abc import Sequence
from copy import deepcopy
import numpy as np

from AdminPy.Orga import OrgFileNames



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
"""
Dimensions of grid. vertical x horizontal
"""
@dataclass(slots=True)
class dimGrid:
    ver: int
    hor: int

"""
Bin count for one descriptor type
"""
@dataclass(slots=True)
class bnumDsc1:
    uni: int
    biv: int
    tot: int

"""
Bin count spatial for universe
"""
@dataclass(slots=True)
class bnumSpaClw:

    nCells:      int = -1
    nBinPerCell: int = -1
    ntBin:       int = -1

    Dim:    'dimGrid' = None
    
    Cnt:    'bnumDsc1' = None
    Frm:    'bnumDsc1' = None
    Arc:    'bnumDsc1' = None
    Str:    'bnumDsc1' = None
    Shp:    'bnumDsc1' = None

    Ndsc:   np.ndarray = None

"""
Bin count for attributes
"""
@dataclass(slots=True)
class bnumATT:

    CntUni: np.ndarray = None
    FrmUni: np.ndarray = None
    ArcUni: np.ndarray = None
    StrUni: np.ndarray = None

    shpUni:  int = None  
    shpBiv:  int = None
    ttrgUni: int = None
    ttrgBiv: int = None
    bndgUni: int = None
    bndgBiv: int = None

    
"""
Edges of spatial histogram (cellwise)
"""
@dataclass(slots=True)
class bedgSpaHst:
    Att: np.array = None
    Dty: np.array = None
    All: np.array = None

    
    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBnumDsc1   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the bin numbers for ONE desctype as written by w_BnumDsc1 in
DescBinAnf.h

cf LoadCollHist.py, ReadBnumSpat

"""
def ReadBnumDsc1( fid ):

    uni = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    biv = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    tot = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    
    return bnumDsc1( uni, biv, tot )



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBnumSpat   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the bin numbers for spatial histograms as written by w_BnumSpaClw DescBinAnf.h

sa/af ReadDescBinNum

cf LoadFabric.m, LoadCollHist.m

cf ReadBnumSpat.m

"""
def ReadBnumSpat( fid: IO[bytes] ) -> bnumSpaClw:

    N             = bnumSpaClw()
    
    N.nCells      = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    N.nBinPerCell = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    N.ntBin       = int(np.fromfile(fid, dtype=np.int32, count=1)[0])

    N.Dim = dimGrid(
        int(np.fromfile(fid, dtype=np.int16, count=1)[0]),
        int(np.fromfile(fid, dtype=np.int16, count=1)[0])
    )
 
    N.Cnt         = ReadBnumDsc1(fid)
    N.Frm         = ReadBnumDsc1(fid)
    N.Arc         = ReadBnumDsc1(fid)
    N.Str         = ReadBnumDsc1(fid)
    N.Shp         = ReadBnumDsc1(fid)

    N.Ndsc        = np.array([N.Cnt.tot, N.Frm.tot, N.Arc.tot, N.Str.tot, N.Shp.tot],
                             dtype=np.int32)
    return N



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadBnumATT   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Loads the descriptor bin numbers for the individual attributes as saved
in C under w_BnumATT (DescBinAnf.h)

Note: bin count not entirely correct. It lacks trippling the chromatic
values. Use i_HistBinNumAdj.m for that.

cf ReadDescBinNum in LoadCollHist.py and ???

"""
def ReadBnumATT( fid ) -> bnumATT:

    N   = bnumATT()

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.CntUni = np.fromfile(fid, dtype=np.int32, count=4)

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.FrmUni = np.fromfile(fid, dtype=np.int32, count=13)

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.ArcUni = np.fromfile(fid, dtype=np.uint8, count=8).astype(np.int32)

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.StrUni = np.fromfile(fid, dtype=np.int32, count=4)

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.shpUni = np.fromfile(fid, dtype=np.int32, count=1)[0]

    N.shpBiv = np.fromfile(fid, dtype=np.int32, count=1)[0]

    sep = np.fromfile(fid, dtype=np.int32, count=1)[0]; assert sep == -1

    N.ttrgUni = np.fromfile(fid, dtype=np.int32, count=1)[0]

    N.ttrgBiv = np.fromfile(fid, dtype=np.int32, count=1)[0]

    N.bndgUni = np.fromfile(fid, dtype=np.int32, count=1)[0]

    N.bndgBiv = np.fromfile(fid, dtype=np.int32, count=1)[0]    
    
    return N



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_HistClwNbinTotDty1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
"""
def f_HistClwNbinTotDty1( N: bnumDsc1 ) -> bnumDsc1:

    N.tot  = N.uni + N.biv
    
    return N

import numpy as np
from types import SimpleNamespace



""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_HistBinNumAdjAtt   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII

Adjusts histogram bin numbers for chromatics.
    
cf exsbFabric.m, i_HistBinNumAdjTot.m
    
IN    NInn    incoming numbers, as read by ReadBnumATT.m
OUT   NAdj, S adjusted bin numbers, total bin count

"""
def i_HistBinNumAdjAtt( NInn: bnumATT ) -> bnumATT :

    NAdj  = deepcopy(NInn)         # copy
    # MATLAB: NAdj.CntUni(end) = NAdj.CntUni(end)*3;
    NAdj.CntUni[-1] *= 3   # chromatics * 3

    # MATLAB: ixCrm = 5; NAdj.FrmUni(ixCrm) = NAdj.FrmUni(ixCrm)*3;
    ixCrm = 4
    NAdj.FrmUni[ixCrm] *= 3 # chromatics * 3

    # MATLAB: ixCrm = 8;
    ixCrm = 7
    NAdj.ArcUni[ixCrm] *= 3

    # MATLAB: ixCrm = 4;
    ixCrm = 3
    NAdj.StrUni[ixCrm] *= 3

    # --- total bin count
    S        = SimpleNamespace()

    S.ntbCnt = sum(NAdj.CntUni) * 4  # including skeleton!

    # no more modifications: from here on verification
    S.ntbFrm = sum(NAdj.FrmUni)
    S.ntbArc = sum(NAdj.ArcUni)
    S.ntbStr = sum(NAdj.StrUni)

    S.ntbShp = NAdj.shpUni

    # flat uni-dimensional fabric
    S.ntbFltUniFbrc = S.ntbCnt + S.ntbFrm + S.ntbArc + S.ntbStr + S.ntbShp

    # S.Arr becomes a 2D NumPy array
    S.Arr = np.concatenate([NAdj.CntUni, NAdj.FrmUni, NAdj.ArcUni, NAdj.StrUni])
    #S.Arr = np.array( [NAdj.CntUni, NAdj.FrmUni, NAdj.ArcUni, NAdj.StrUni] )

    return NAdj, S



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_BnumFromSpaClw   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
"""
def u_BnumFromSpaClw( N: bnumSpaClw ):

    S = SimpleNamespace()

    S.Ntot = np.array([N.Cnt.tot, N.Frm.tot, N.Arc.tot, N.Str.tot, N.Shp.tot])
    S.Nuni = np.array([N.Cnt.uni, N.Frm.uni, N.Arc.uni, N.Str.uni, N.Shp.uni])
    S.Nbiv = np.array([N.Cnt.biv, N.Frm.biv, N.Arc.biv, N.Str.biv, N.Shp.biv])
    
    S.Nflt   = np.hstack( (S.Nuni, S.Nbiv) )
    S.ntBin  = S.Nflt.sum()
    S.ntBin2 = N.Ndsc.sum()

    assert S.ntBin==S.ntBin2, 'total num of bins incorrect'
    
    return S


""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_BinEdgFromLoad   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII

Obtain bin numbers from loaded files, adjusted.
    
IN    NbinAtt    as read by ReadBnumATT.m
      NbinDty    as read by ??? (above?)
OUT   NbinCms    array of integers with number of bins as cumulative sum

"""
def i_BinEdgFromLoad( NbinAtt: bnumATT, NbinDty ):
    
    _, NbinSum = i_HistBinNumAdjAtt( NbinAtt ) # above

    Nspa    = u_BnumFromSpaClw( NbinDty ) # above

    Eatt    = NbinSum.Arr.cumsum()
    Edty    = Nspa.Nflt.cumsum()
    
    Etot    = np.concatenate( ( Eatt, Edty ), axis=0 )
    Etot    = np.unique(Etot)
    
    # -----  verify:
    assert NbinDty.nBinPerCell==Nspa.ntBin, 'total num of bins incorrect (2)'

    Bedg      = bedgSpaHst()
    Bedg.Att  = Eatt
    Bedg.Dty  = Edty
    Bedg.All  = Etot
    
    return Bedg


# --------------------------------------------------------------------------------
#                                     D I S P 
# --------------------------------------------------------------------------------

""" DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD   DispBnumDsc1   DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD

bnumDsc1
"""
def DispBnumDsc1( N, jStr ):

    print(f"{jStr}  uni/biv/tot  {N.uni:>4} {N.biv:>4} {N.tot:>4}")

    
""" DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD   DispBnumSpat   DDDDDDDDDDDDDDDDDDDDDDDDDDDDDD

bnumSpaClw
"""
def DispBnumSpat( N ):

    print(f"{'nCells':<15} {N.nCells:>6} {'  ('} {N.Dim.ver} {'x'} {N.Dim.hor} {')'}")
    print(f"{'nBinPerCell':<15} {N.nBinPerCell:>6}")
    print(f"{'ntBin':<15} {N.ntBin:>6}")

    DispBnumDsc1( N.Cnt, 'Cnt' )
    DispBnumDsc1( N.Frm, 'Frm' )
    DispBnumDsc1( N.Arc, 'Arc' )
    DispBnumDsc1( N.Str, 'Str' )
    DispBnumDsc1( N.Shp, 'Shp' )

