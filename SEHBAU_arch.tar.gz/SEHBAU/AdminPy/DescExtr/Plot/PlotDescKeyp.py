"""

Plots descriptor keypoints and their values (taken from a map)


------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------

--------------------   Keypoints
--- cnt/arc/str
def p_DescKeyPts(PT, col, ax=None):
def PlotDescSpcKeyPts(Irgb, typSpc, AKey, figNo, titStr):

--- form
def p_RoctList(Roct, IxSel=None, col='rand', bEckOnly=False, ax=None):
def PlotFormSpcKeyPts(Irgb, typSpc, AKey, figNo, titStr):

--------------------   Values (at Keypoints)

---------- ONE Level

--- cnt/arc/str
def p_DkypVls( PT: Any, VL: Any, StsV: Any, typ: str ) -> None:

--- form
def p_RoctVls(Roct, IxSel=None, VLS=None, StsV=None, ax=None):

---------- Space

--- cnt/arc/str
def PlotDkypVlsSpc(typSpc, szI, StsMp, AKyp, AVls, figNo, figTit):
--- form
def PlotFormSpcKypVls(typSpc, szI, StsMp, AKey, AVls, figNo, titStr):



"""
from typing import Any
import warnings
import math
import numpy as np
import matplotlib.pyplot as plt

from AdminPy.Util.UtilImg import f_ImgPyr



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_DescKeyPts   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plot descriptor keypoints given as two endpoints and a midpoint.
Absolute coordinates only.

PT contains Ep1, Ep2 and Btw.

"""
def p_DescKeyPts(PT, col, ax=None):

    if ax is None:
        ax = plt.gca()

    nDsc = PT.Ep1.shape[0]

    for i in range(nDsc):

        Ep1 = PT.Ep1[i]
        Ep2 = PT.Ep2[i]
        Mip = PT.Btw[i]

        # (row, column) -> (y, x)
        ax.plot( [Ep1[1], Mip[1]], [Ep1[0], Mip[0]], color=col )

        ax.plot( [Mip[1], Ep2[1]], [Mip[0], Ep2[0]], color=col )



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotDescSpcKeyPts   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plot a space of keypoints.

IN
    Irgb : np.ndarray     Input image.
    typSpc : int    1: image pyramid; otherwise, scale space.
    AKey : list     Keypoints for each level.
    figNo : int     Figure number.
    titStr : str    Figure title.
"""
def PlotDescSpcKeyPts(Irgb, typSpc, AKey, figNo, titStr):

    if typSpc == 1:
        APyr, nLev = f_ImgPyr(Irgb)
    else:
        nLev = len(AKey)
        warnings.warn("Scale space not verified yet")

    hf = plt.figure(figNo)
    hf.clf()
    hf.canvas.manager.set_window_title(titStr)

    nRows = math.ceil(nLev / 2)

    for l in range(nLev):
        ax = hf.add_subplot(nRows, 2, l + 1)

        if typSpc == 1:
            ax.imshow(APyr[l], cmap='gray')
        else:
            ax.imshow(Irgb, cmap='gray')

        p_DescKeyPts(AKey[l], 'k', ax=ax)        

    plt.tight_layout()
    plt.show(block=False)
    
        

""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_RoctList   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plot a list of rectangular octagonal contours (Rocts).

    Parameters
    ----------
    Roct : object
        Structure containing the contour coordinates:
        Topp, Bott, Leff, Ritt, Tole, Tori, Rito, Ribo,
        Bole, Bori, Leto, Lebo.
    IxSel : array-like or int, optional
        Indices of contours to plot (MATLAB-style, starting at 1).
        -1 or None selects all contours.
    col : str or array-like
        Line color, or 'rand' for a random color per contour.
    bEckOnly : bool
        If True, plot only the corner points.
    ax : matplotlib.axes.Axes, optional
        Axes to plot into.
    """
def p_RoctList(Roct, IxSel=None, col='rand', bEckOnly=False, ax=None):

    if ax is None:
        ax = plt.gca()

    nCrv = len(Roct.Topp)

    # Select contours
    if IxSel is None:
        IxSel = np.arange(1, nCrv + 1)
    elif np.isscalar(IxSel) and IxSel == -1:
        IxSel = np.arange(1, nCrv + 1)
    else:
        IxSel = np.atleast_1d(IxSel)

    nCrv = len(IxSel)

    bRand = isinstance(col, str) and col == 'rand'
    liwi = 1
    off = 0.2

    for i in range(nCrv):

        # Convert MATLAB index to Python index
        ix = int(IxSel[i]) - 1

        topp = float(Roct.Topp[ix]) - off
        bott = float(Roct.Bott[ix]) + off
        leff = float(Roct.Leff[ix]) - off
        ritt = float(Roct.Ritt[ix]) + off

        tole = float(Roct.Tole[ix]) - off
        tori = float(Roct.Tori[ix]) + off
        rito = float(Roct.Rito[ix]) - off
        ribo = float(Roct.Ribo[ix]) + off

        bole = float(Roct.Bole[ix]) - off
        bori = float(Roct.Bori[ix]) + off
        leto = float(Roct.Leto[ix]) - off
        lebo = float(Roct.Lebo[ix]) + off

        # MATLAB: X = column, Y = row
        Xco = np.array([
            tole, tori, ritt, ritt,
            bori, bole, leff, leff
        ]) + 1

        Yco = np.array([
            topp, topp, rito, ribo,
            bott, bott, lebo, leto
        ]) + 1

        if bEckOnly:
            ax.plot(Xco, Yco, 'k.', markersize=4)

        else:
            hp, = ax.plot(Xco, Yco, '.-')
            ax.plot(Xco, Yco, 'k.', markersize=4)

            if bRand:
                lineCol = np.random.rand(3)
            else:
                lineCol = col

            hp.set_color(lineCol)
            hp.set_linewidth(liwi)    


""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotFormSpcKeyPts   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plot a space of keypoints for the form descriptor.

    Parameters
    ----------
    Irgb : np.ndarray or PIL.Image
        Input image.
    typSpc : int
        1: image pyramid; otherwise, scale space.
    AKey : list
        Roct structures for each level.
    figNo : int
        Figure number.
    titStr : str
        Figure title.
    """
def PlotFormSpcKeyPts(Irgb, typSpc, AKey, figNo, titStr):

    if typSpc == 1:
        APyr, nLev = f_ImgPyr(Irgb)
    else:
        nLev = len(AKey)
        warnings.warn("Scale space not verified yet")

    hf = plt.figure(figNo)
    hf.clf()
    hf.canvas.manager.set_window_title(titStr)

    nRows = math.ceil(nLev / 2)

    for l in range(nLev):
        ax = hf.add_subplot(nRows, 2, l + 1)

        if typSpc == 1:
            ax.imshow(APyr[l])
        else:
            ax.imshow(Irgb)

        nRoct = len( AKey[l].Tole)

        bEckOnly = False
        col = np.array([0.5, 0.5, 0.5])

        p_RoctList(
            AKey[l],
            np.arange(1, nRoct + 1),
            col,
            bEckOnly,
            ax=ax
        )

    plt.tight_layout()
    plt.show(block=False)



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_DkypVls   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots values at descriptor keypoints (absolute coordinates only).
It's an extension of p_DescKeyPts.m

IN       typ   'ep3_is_mip'

"""
def p_DkypVls( PT: Any, VL: Any, StsV: Any, typ: str ) -> None:

    if typ == 'btw_is_mip':
        PT_Mip = PT.Btw
        VL_Mip = VL.Btw
    elif typ == 'ep3_is_mip':
        PT_Mip = PT.Ep3
        VL_Mip = VL.Ep3
    else:
        raise ValueError( f'typ {typ} not specified' )

    vMin = StsV.min
    vMax = StsV.max
    rng  = vMax - vMin

    nDsc = PT.Ep1.shape[0]

    for i in range( nDsc ):

        Ep1 = PT.Ep1[i, :]
        Ep2 = PT.Ep2[i, :]
        Mip = PT_Mip[i, :]

        ve1 = VL.Ep1[i]
        ve2 = VL.Ep2[i]
        vmp = VL_Mip[i]

        ve1 = float( np.clip( ( ve1 - vMin ) / rng, 0.0, 1.0 ) )
        ve2 = float( np.clip( ( ve2 - vMin ) / rng, 0.0, 1.0 ) )
        vmp = float( np.clip( ( vmp - vMin ) / rng, 0.0, 1.0 ) )

        if typ == 'btw_is_mip':
            # absolute coordinates, ij format
            # X/Y, alora C/R
            # plt.plot( [ Ep1[1], Mip[1] ], [ Ep1[0], Mip[0] ], color=col )
            # plt.plot( [ Mip[1], Ep2[1] ], [ Mip[0], Ep2[0] ], color=col )

            col1 = ( ve1, ve1, ve1 )
            col2 = ( ve2, ve2, ve2 )
            colm = ( vmp, vmp, vmp )

            # --- only the endpoints
            plt.plot( Ep1[1], Ep1[0], '.', color=col1 )
            plt.plot( Ep2[1], Ep2[0], '.', color=col2 )
            plt.plot( Mip[1], Mip[0], '.', color=colm )

            # --- make it a line of 4 segments (4 quarters)
            Qp1 = ( Ep1 + Mip ) / 2.0        # quarter point btw Ep1 and Mip
            Qp2 = ( Ep2 + Mip ) / 2.0

            # the end quarter-segments in colors 'col1' and 'col2'
            # the two center quarter-segments in color 'colm'
            plt.plot( [ Ep1[1], Qp1[1] ], [ Ep1[0], Qp1[0] ], color=col1 )
            plt.plot( [ Ep2[1], Qp2[1] ], [ Ep2[0], Qp2[0] ], color=col2 )
            plt.plot( [ Qp1[1], Mip[1] ], [ Qp1[0], Mip[0] ], color=colm )
            plt.plot( [ Qp2[1], Mip[1] ], [ Qp2[0], Mip[0] ], color=colm )

        else:
            raise ValueError( f'typ {typ} not specified' )
    


""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_RoctVls   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plot a list of Rocts with values.

Each of the eight contour segments is colored according to
the mean value of its two endpoint values.

    Parameters
    ----------
    Roct : object
        Structure containing the contour coordinates.
    IxSel : array-like or int, optional
        Selected contour indices (MATLAB-style, starting at 1).
        None or -1 selects all contours.
    VLS : np.ndarray
        Values associated with each contour.
        Expected shape: [nRoct, nValues].
    StsV : arrStat
        Statistics containing min and max.
    ax : matplotlib.axes.Axes, optional
        Axes to plot into.
"""
def p_RoctVls(Roct, IxSel=None, VLS=None, StsV=None, ax=None):

    if ax is None:
        ax = plt.gca()

    nCrv = len(Roct.Topp)

    # Select contours
    if IxSel is None or (np.isscalar(IxSel) and IxSel == -1):
        IxSel = np.arange(1, nCrv + 1)
    else:
        IxSel = np.atleast_1d(IxSel)

    nCrv = len(IxSel)

    minV = StsV.min
    maxV = StsV.max
    rngV = maxV - minV

    liwi = 1
    off = 0.2

    for i in range(nCrv):

        # Convert MATLAB index to Python index
        ix = int(IxSel[i]) - 1
        Vls = np.asarray(VLS[ix, :], dtype=float)

        topp = float(Roct.Topp[ix]) - off
        bott = float(Roct.Bott[ix]) + off
        leff = float(Roct.Leff[ix]) - off
        ritt = float(Roct.Ritt[ix]) + off

        tole = float(Roct.Tole[ix]) - off
        tori = float(Roct.Tori[ix]) + off
        rito = float(Roct.Rito[ix]) - off
        ribo = float(Roct.Ribo[ix]) + off

        bole = float(Roct.Bole[ix]) - off
        bori = float(Roct.Bori[ix]) + off
        leto = float(Roct.Leto[ix]) - off
        lebo = float(Roct.Lebo[ix]) + off

        # Coordinates: x = column, y = row
        Xco = np.array([
            tole, tori, ritt, ritt,
            bori, bole, leff, leff
        ]) + 1

        Yco = np.array([
            topp, topp, rito, ribo,
            bott, bott, lebo, leto
        ]) + 1

        # Close the contour
        Xco = np.append(Xco, Xco[0])
        Yco = np.append(Yco, Yco[0])
        Vls = np.append(Vls, Vls[0])

        # Mean value per segment
        Vm = (Vls[:-1] + Vls[1:]) / 2

        # Normalize to [0, 1]
        if rngV != 0:
            Vm = (Vm - minV) / rngV
        else:
            Vm = np.zeros_like(Vm)

        for s in range(8):

            rg = [s, s + 1]

            hp, = ax.plot( Xco[rg], Yco[rg], '.-', color=[Vm[s]] * 3, linewidth=liwi )

            ax.plot( Xco[rg], Yco[rg], 'k.', markersize=4 )        



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotDkypVlsSpc   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plot a space of values taken at keypoints.

    Parameters
    ----------
    typSpc : int
        1: image pyramid; otherwise, scale space.
    szI : tuple or array-like
        Original image dimensions (height, width).
    StsMp : arrStat
        Statistics of the map values.
    AKyp : list
        Keypoint structures for each level.
    AVls : list
        Values associated with the keypoints at each level.
    figNo : int
        Figure number.
    figTit : str
        Figure title.
    """
def PlotDkypVlsSpc(typSpc, szI, StsMp, AKyp, AVls, figNo, figTit):

    hf = plt.figure(figNo)
    hf.clf()
    hf.canvas.manager.set_window_title(figTit)

    nLev = len(AKyp)

    if typSpc != 1:
        warnings.warn("Scale space not verified yet")

    nRows = math.ceil(nLev / 2)

    for l in range(nLev):

        ax = hf.add_subplot(nRows, 2, l + 1)

        if typSpc == 1:
            # MATLAB: zeros(szI / 2^(l-1))
            szLev = np.maximum(
                1,
                np.round(np.asarray(szI) / (2 ** l)).astype(int)
            )
        else:
            szLev = szI

        ax.imshow(np.zeros(szLev), cmap='gray')

        p_DkypVls( AKyp[l], AVls[l], StsMp, 'btw_is_mip' ) # ax=ax )

    hf.tight_layout()            
    plt.show(block=False)



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotFormSpcKypVls   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plot a space of values taken at form-descriptor keypoints.

    Parameters
    ----------
    typSpc : int
        1: image pyramid; otherwise, scale space.
    szI : tuple or array-like
        Original image dimensions (height, width).
    StsMp : arrStat
        Statistics of the map values.
    AKey : list
        Roct structures for each level.
    AVls : list
        Values associated with the Rocts at each level.
    figNo : int
        Figure number.
    titStr : str
        Figure title.
"""
def PlotFormSpcKypVls(typSpc, szI, StsMp, AKey, AVls, figNo, titStr):

    hf = plt.figure(figNo)
    hf.clf()
    hf.canvas.manager.set_window_title(titStr)

    nLev = len(AKey)

    if typSpc != 1:
        warnings.warn("Scale space not verified yet")

    nRows = math.ceil(nLev / 2)

    for l in range(nLev):

        ax = hf.add_subplot(nRows, 2, l + 1)

        if typSpc == 1:
            szLev = np.maximum(
                1,
                np.round(np.asarray(szI) / (2 ** l)).astype(int)
            )
        else:
            szLev = szI

        ax.imshow(np.zeros(szLev), cmap='gray')

        nRoct = len(AKey[l].Tole)

        p_RoctVls(
            AKey[l],
            np.arange(1, nRoct + 1),
            AVls[l],
            StsMp,
            ax=ax
        )

    hf.tight_layout()    
    plt.show(block=False)
