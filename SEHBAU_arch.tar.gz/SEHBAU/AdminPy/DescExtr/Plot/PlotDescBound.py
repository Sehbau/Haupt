"""

Plot boundaries of specific descriptors. 

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------

def p_ShpAxial(SHP, ABonPix, ax ):
def p_FrmAxial(FRM, ABonPix, ax ):
def p_FrmSmall(FRM, ABonPix, BOX, ax ):

def p_FormBoundPix(FRM, aBon, typ):

"""
import numpy as np

import matplotlib.pyplot as plt

import warnings

from AdminPy.Util.DataStruct import u_MtrxToStcArrDict
from AdminPy.DescExtr.OrgAtt.OrgAtts import LbsShpScors, LbsShpSfine, u_AttLabArrToList
from AdminPy.DescExtr.OrgAtt.OrgAtts import LbsFormRospA, LbsFormRospB

from AdminPy.Util.Plot.PlotUtils import colPalette
from AdminPy.DescExtr.Plot.PlotFeatures import *




# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_ShpAxial   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots axial shapes: vertical, horizontal and axial.

Boundary pixels are plotted in gray by default and colorized according to their
structural attributes.


IN    SHP      shape descriptors for one level.
                  STR.Vrt, STR.Hor, STR.Axi
                  SFI.Vrt, SFI.Hor, SFI.Axi
                  IxBon1
      ABonPix  list of boundary pixel structures, with Cl and Rw coordinates.

OUT   IxAxi     boundary indices of axial shapes
      Typ       corresponding shape types

    Type classification
    -------------------
    1 = vertical coarse
    2 = vertical fine
    3 = horizontal coarse
    4 = horizontal fine
    5 = axial coarse
    6 = axial fine
    """
def p_ShpAxial(SHP, ABonPix, ax ):

    aLbCors = u_AttLabArrToList( LbsShpScors )
    aLbFine = u_AttLabArrToList( LbsShpSfine )
    
    Scors   = u_MtrxToStcArrDict( SHP.STR, aLbCors )
    Sfine   = u_MtrxToStcArrDict( SHP.SFI, aLbFine )

    # ----- Colors -----
    colGray = [0.8, 0.8, 0.8]

    drkRed  = [0.8, 0.0, 0.0]
    fllRed  = [1.0, 0.0, 0.0]

    drkBlu  = [0.0, 0.2, 0.6]
    fllBlu  = [0.0, 0.0, 1.0]

    drkGrn  = [0.0, 0.5, 0.0]
    fllGrn  = [0.0, 1.0, 0.0]

    # ----- Initialize -----
    nShp = len(SHP.IxBon)

    IxAxi = np.zeros(nShp, dtype=np.int32)
    Typ   = np.zeros(nShp, dtype=np.int32)

    c = 0

    for b in range(nShp):

        ixBon = SHP.IxBon[b]

        BonPix = ABonPix[ixBon]

        hp, = ax.plot(
            BonPix.Cl,
            BonPix.Rw,
            color=colGray
        )

        # ----- Extract attributes -----
        vrtCrs = Scors['VrtC'][b]
        horCrs = Scors['HorC'][b]
        axiCrs = Scors['AxiC'][b]

        vrtFin = Sfine['VrtF'][b]
        horFin = Sfine['HorF'][b]
        axiFin = Sfine['AxiF'][b]

        col = None
        typ = 0

        # ----- Vertical -----
        if vrtCrs > 0.5:
            col = drkRed
            typ = 1

        if vrtFin > 0.5:
            col = fllRed
            typ = 2

        # ----- Horizontal -----
        if horCrs > 0.5:
            col = drkBlu
            typ = 3

        if horFin > 0.5:
            col = fllBlu
            typ = 4

        # ----- Axial -----
        if axiCrs > 0.5:
            col = drkGrn
            typ = 5

        if axiFin > 0.5:
            col = fllGrn
            typ = 6

        # ----- Assign color and collect indices -----
        if col is not None:

            hp.set_color(col)

            IxAxi[c] = ixBon
            Typ[c] = typ

            c += 1

    # ----- Trim & Return -----
    return IxAxi[:c], Typ[:c]



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_FrmAxial   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots axial forms: vertical, horizontal and axial.

afro p_ShpAxial above.

Boundary pixels are plotted in gray by default and colorized according to their
structural attributes.


IN    FRM      form descriptors for one level.
                  STR.Vrt, STR.Hor, STR.Axi
                  SFI.Vrt, SFI.Hor, SFI.Axi
                  IxBon1
      ABonPix  list of boundary pixel structures, with Cl and Rw coordinates.

OUT   IxAxi     boundary indices of axial shapes
      Typ       corresponding shape types

"""
def p_FrmAxial(FRM, ABonPix, ax ):

    aLbRospA = u_AttLabArrToList( LbsFormRospA )
    aLbRospB = u_AttLabArrToList( LbsFormRospB )

    RospA   = u_MtrxToStcArrDict( FRM.RospA, aLbRospA )
    RospB   = u_MtrxToStcArrDict( FRM.RospB, aLbRospB )

    # ----- Colors -----
    colGray = [0.8, 0.8, 0.8]

    drkRed  = [0.8, 0.0, 0.0]
    fllRed  = [1.0, 0.0, 0.0]

    drkBlu  = [0.0, 0.2, 0.6]
    fllBlu  = [0.0, 0.0, 1.0]

    drkGrn  = [0.0, 0.5, 0.0]
    fllGrn  = [0.0, 1.0, 0.0]

    # ----- Initialize -----
    nFrm = len(FRM.IxBon)

    IxAxi = np.zeros(nFrm, dtype=np.int32)
    Typ   = np.zeros(nFrm, dtype=np.int32)

    c = 0

    for b in range(nFrm):

        ixBon = FRM.IxBon[b]

        BonPix = ABonPix[ixBon]

        if RospA['AreN'][b] > 0.15:
            continue            # skip very large forms

        hp, = ax.plot(
            BonPix.Cl,
            BonPix.Rw,
            color=colGray
        )

        # ----- Extract attributes -----
        hihAny  = RospA['High'][b]
        widAny  = RospA['Wide'][b]
        axiAny  = RospA['Axial'][b]

        hihVol  = RospA['Higv'][b]
        widVol  = RospA['Widv'][b]
        axiVol  = RospB['Volm'][b]

        col = None
        typ = 0

        # ----- Vertical -----
        if hihAny > 0.5:
            col = drkRed
            typ = 1

        if hihVol > 0.5:
            col = fllRed
            typ = 2

        # ----- Horizontal -----
        if widAny > 0.5:
            col = drkBlu
            typ = 3

        if widVol > 0.5:
            col = fllBlu
            typ = 4

        # ----- Axial -----
        if axiAny > 0.5:
            col = drkGrn
            typ = 5

        if axiVol > 0.5:
            col = fllGrn
            typ = 6

        # ----- Assign color and collect indices -----
        if col is not None:

            hp.set_color(col)

            IxAxi[c] = ixBon
            Typ[c] = typ

            c += 1

    # ----- Trim & Return -----
    return IxAxi[:c], Typ[:c]



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_FrmSmall   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots small forms.

Boundary pixels are plotted in gray by default and colorized according to their
structural attributes.

IN    FRM      form descriptors for one level.
      ABonPix  list of boundary pixel structures, with Cl and Rw coordinates.

OUT   IxAxi     boundary indices of axial shapes
      Typ       corresponding shape types

"""
def p_FrmSmall(FRM, ABonPix, BOX, ax ):

    aLbRospA = u_AttLabArrToList( LbsFormRospA )
    aLbRospB = u_AttLabArrToList( LbsFormRospB )

    RospA   = u_MtrxToStcArrDict( FRM.RospA, aLbRospA )
    RospB   = u_MtrxToStcArrDict( FRM.RospB, aLbRospB )

    # ----- Initialize -----
    nFrm = len(FRM.IxBon)

    IxAxi = np.zeros(nFrm, dtype=np.int32)
    Typ   = np.zeros(nFrm, dtype=np.int32)

    Col   = colPalette()
    
    c = 0

    for b in range(nFrm):

        ixBon  = FRM.IxBon[b]

        BonPix = ABonPix[ixBon]

        Box    = BOX[ixBon,:]

        if RospA['AreN'][b] > 0.005:
            continue            # skip very large forms

        ctr     = FRM.Ctr[b]
        #print(ctr)
        #ctrN    = ctr / 255.0
        ctrS      = ctr 
        color     = (ctrS,ctrS,ctrS)
        linewidth = ctr*10

        p_BoundPix1ToImg( ax, BonPix, color, linewidth )

        p_BoundBox1( ax, Box )

        IxAxi[c] = ixBon
        Typ[c]   = 0

        c += 1

    # ----- Trim & Return -----
    return IxAxi[:c], Typ[:c]



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_FormBoundPix   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots boundaries of a form descriptor.

IN  FRM   form descriptor.
    aBon  list of all boundaries in segment-wise organization.
    typ : str
          'nofet': No feature highlighting.
          'cir':   Highlight circular features.
          'elo':   Highlight elongated features.
"""
def p_FormBoundPix( FRM, aBon, typ, ax ):

    gry = 0.8

    for i in range(FRM.nRsg):

        colBon = [gry, gry, gry]
        colPol = [1.0, 1.0, 1.0]
        liwi   = 1

        cir    = FRM.RdSig['cir'][i]
        elo    = FRM.RdSig['eloR'][i]

        if typ == 'nofet':
            pass

        elif typ == 'cir':

            if cir > 0.15:

                gb     = max(gry - cir, 0)
                colBon = [gb + np.tanh(cir) * 1.3, gb, gb]
                colPol = [1, 0, 0]

                plt.plot( FRM.Pol.Hor[i], FRM.Pol.Vrt[i], '.', color=colPol )

        elif typ == 'elo':

            if elo > 0.75:

                gb     = max(gry - elo, 0)
                colBon = [gb + np.tanh(elo) * 1.25, gb, gb]
                colPol = [1, 0, 0]

                plt.plot( FRM.Pol.Hor[i], FRM.Pol.Vrt[i], '.', color=colPol )

        else:
            raise ValueError(f"Type '{typ}' not implemented")

        ixBon = FRM.IxBon[i]

        bJit = 0

        p_BoundPix1ToImg( ax, aBon[ixBon], colBon, liwi, bJit )
