"""

Plots descriptors. Mostly as outline using the attribute values to reconstruct the
spatial position. Routine p_DescPairSbS plot also the boundaries.

Only 4 descriptors so far.

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def p_CntFromAtts( CNT, szM=None, col='y', ax=None ):
def p_ArcPts( ARC ): 
def p_TtrgLst( TL, szM ):
def p_ShpPoleFromPos( SHP, szI=None, ax=None ):

def p_PatLin(Pat, col, ax=None):
def p_PosVH( P: arrPos, col='k' ):

def p_DescPairSbS( dty, A, B, szM, aBon1=None, aBon2=None):

"""
import numpy as np

import copy

import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse

from AdminPy.DescExtr.DescFile.LoadDescription import u_TtrgRtrv1
from AdminPy.DescExtr.DescFile.PosAnf import *

from AdminPy.DescExtr.Features.Segments.BonUtil import f_BonPixShift
from AdminPy.DescExtr.Plot.PlotDescBound import *
from AdminPy.DescExtr.Plot.PlotFeatures import *



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_CntFromAtts   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

see p_CntAtt.m

"""
def p_CntFromAtts( CNT, szM=None, col='y', ax=None ):

    if ax is None:
        ax = plt.gca()

    bUnitRng = szM is None
    bColRGB  = szM is None

    if not bUnitRng:
        szV, szH = szM[0], szM[1]

    for i in range(CNT.nCnt):

        ori = CNT.Ori[i]
        les = CNT.Les[i]
        ctr = CNT.Ctr[i]

        yrd = np.sin(ori) * les / 2
        xrd = np.cos(ori) * les / 2

        if bUnitRng:
            posV   = 1 - CNT.Pos.Vrt[i]
            posH   = CNT.Pos.Hor[i]
            xVals  = [posH - xrd, posH + xrd]
            yVals  = [posV + yrd, posV - yrd]
        else:
            xrd   *= szH
            yrd   *= szV
            posV   = CNT.Pos.Vrt[i] * szV
            posH   = CNT.Pos.Hor[i] * szH
            xVals  = [posH - xrd, posH + xrd]
            yVals  = [posV - yrd, posV + yrd]

        if bColRGB:
            rgb = [ CNT.RGB.Red[i], CNT.RGB.Grn[i], CNT.RGB.Blu[i] ]
        else:
            rgb = col if isinstance(col, (list, tuple)) else {'y': [1,1,0]}.get(col, [1,1,0])

        ax.plot( xVals, yVals, color=rgb, linewidth=0.2 + 2 * ctr)    


        
""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_ArcPts   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

see p_ArcAtt.m

"""
def p_ArcPts( ARC ): #, szM=None, col='y', ax=None ):

    for i in range(ARC.nArc):
        
        # endpoint - peakpoint - endpoint
        Y = [ ARC.Pts.Ep1[i][0], ARC.Pts.Btw[i][0], ARC.Pts.Ep2[i][0] ]
        X = [ ARC.Pts.Ep1[i][1], ARC.Pts.Btw[i][1], ARC.Pts.Ep2[i][1] ]

        # Add color
        red   = ARC.RGB.Red[i]
        grn   = ARC.RGB.Grn[i]
        blu   = ARC.RGB.Blu[i]
        color = (red, grn, blu)
        color = [ 1, 1, 0 ]

        # Plot the arc
        hl, = plt.plot( X, Y, color=color )

        # Emphasize peakpoint by placing a dot
        plt.plot( X[1], Y[1], '.', color=color )


    
""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_TtrgLst   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

see p_TtrgLst.m

"""
def p_TtrgLst( TL, szM ):

    szV = szM[0]
    szH = szM[1]

    colOrng = [255/255, 128/255, 0/255]   # orange
    colBlue = [0/255, 0/255, 255/255]     # blue

    for i in range( TL.nTtg ):
    
        Axe, Cor, Tg   = u_TtrgRtrv1( TL, i )

        plt.plot( [cl * szH for cl in Cor.Cl], 
                  [rw * szV for rw in Cor.Rw], color=colOrng )

        plt.plot( [cl * szH for cl in Axe.Cl], 
                  [rw * szV for rw in Axe.Rw], color=colBlue )
    


""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_ShpPoleFromPos   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

see p_ShpPoleFromPos.m

"""
def p_ShpPoleFromPos( SHP, szI=None, ax=None ):


    if ax is None:
        ax = plt.gca()

    bUnitRng = szI is None  # unit-range if size is given

    for i in range(SHP.nShp):
        
        posV = SHP.Pos.Vrt[i]
        posH = SHP.Pos.Hor[i]
        rds  = SHP.RAS[i,0]
        #print(rds)

        if rds == 0:
            rds = 0.01

        if bUnitRng:
            posV = 1 - posV  # convert from image to Cartesian
        else:
            posV = posV * szI[0]
            posH = posH * szI[1]
            rds = rds * szI[0] / 2  # scale for better visual appearance

        wth = hgt = rds * 2

        ellipse = Ellipse(
            (posH, posV), width=wth, height=hgt,
            edgecolor=[SHP.RGB.Red[i], SHP.RGB.Grn[i], SHP.RGB.Blu[i]],
            facecolor='none'
        )
        ax.add_patch(ellipse)    
        



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_PatLin   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots a list of lines from structure patLin.

IN  Pat   pattern as produced by cntpat.exe
    col   either as vector [1 3] E [0..1] or as a list [nLin 3] E [0..1]

af p_CntFromVect

"""
def p_PatLin(Pat, col, ax=None):
    
    if ax is None:
        ax = plt.gca()

    nLin = Pat.nLin
    bColByTyp = isinstance(col, str) and col == "typ"

    if bColByTyp:
        # type 1: ridge red, 2: river blue, 3: edge cyan
        Col = np.array([
            [1, 0, 0],
            [0, 0, 1],
            [0, 1, 1],
        ], dtype=float)

    elif hasattr(col, "Red") and hasattr(col, "Grn") and hasattr(col, "Blu"):
        Red = np.asarray(col.Red)
        Grn = np.asarray(col.Grn)
        Blu = np.asarray(col.Blu)

    else:
        col = np.asarray(col, dtype=float)

        if col.ndim == 1:
            # One RGB color for every line
            Red = np.full(nLin, col[0])
            Grn = np.full(nLin, col[1])
            Blu = np.full(nLin, col[2])
        else:
            # One RGB color per line: shape (nLin, 3)
            Red, Grn, Blu = col[:, 0], col[:, 1], col[:, 2]

    Ep1 = Pat.Ep1
    Ep2 = Pat.Ep2
    aHnd = []

    for i in range(nLin):
        wgt = Pat.Wgt[i]
        typ = int(Pat.Typ[i])

        # MATLAB plots column as x and row as y
        hl, = ax.plot(
            [ Ep1[i,1], Ep2[i,1] ],
            [ Ep1[i,0], Ep2[i,0] ],
            linewidth = 0.2 + 4 * wgt,
        )

        if bColByTyp and typ > 0:
            if typ > len(Col):
                raise ValueError(f"Unknown line type {typ}; expected 1–3")
            hl.set_color(Col[typ - 1])
        elif not bColByTyp:
            hl.set_color([Red[i], Grn[i], Blu[i]])

        aHnd.append(hl)

    return aHnd        



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_PosVH   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots positions (vertical, horizontal) as dots.

IN  P    position object with Vrt and Hor attributes.
    col  marker color. str or tuple, default='k'
    -------
    P : object
        Unchanged position object.
    """
def p_PosVH( P: arrPos, col='k' ):

    plt.plot( P.Hor, P.Vrt, '.', color=col)


""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_DescPairSbS   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots a pair of descriptor sets in preparation for a correspondence plot.

Note that we add the shift in some of the originals, . no deep copy is made! 

IN      A:      First descriptor set (left)
        B:      Second descriptor set (right)
        szM:    Image dimensions [height, width]
        aBon1:  Boundary information for A
        aBon2:  Boundary information for B

OUT     Out     shifted positions or boundary information of B

"""
def p_DescPairSbS( dty, A, Borg, szM, aBon1=None, aBon2=None, ax=None):

    B = copy.deepcopy(Borg)  # ensure we dont modify original

    if dty == 'cnt':

        # Remain in unit coordinates
        B.Pos.Hor += 1
        Out = B.Pos

        p_CntFromAtts(A) # PlotDescriptors.py
        p_CntFromAtts(B)

        plt.xlim(0, 2)
        plt.ylim(0, 1)

    elif dty == 'form':

        # Absolute pixel coordinates
        aBon2 = f_BonPixShift(aBon2, 0, szM[1])
        Out   = aBon2

        p_FormBoundPix(A, aBon1, 'nofet', ax)
        p_FormBoundPix(B, aBon2, 'nofet', ax)

        # Poles as dots, without pixel correction
        # note. This is not deepcopied, so we can reuse it for plotting correspondence lines later
        Apos = u_PosVHscaleup(A.Pos, szM, 0)
        Bpos = u_PosVHscaleup(B.Pos, szM, 0)

        Bpos = u_PosVHshift(Bpos, 0, szM[1])

        p_PosVH( Apos, 'k' )
        p_PosVH( Bpos, 'r' )

        plt.xlim(0, szM[1] * 2)
        plt.ylim(0, szM[0])

    elif dty == 'arc':

        B.Pts = u_DescPtsShift(B.Pts, 0, szM[1])

        p_ArcPts(A)
        p_ArcPts(B)

        plt.xlim(0, szM[1] * 2)
        plt.ylim(0, szM[0])

        Out = B.Pts

    elif dty == 'str':

        B.Pts = u_DescPtsShift(B.Pts, 0, szM[1])

        p_StrPts(A)
        p_StrPts(B)

        plt.xlim(0, szM[1] * 2)
        plt.ylim(0, szM[0])

        Out = B.Pts

    else:
        raise ValueError(f'Descriptor {dty} not implemented')

    plt.gca().tick_params(axis='x', colors='0.5', labelsize=6)
    plt.gca().tick_params(axis='y', labelsize=6)

    return Out
    
