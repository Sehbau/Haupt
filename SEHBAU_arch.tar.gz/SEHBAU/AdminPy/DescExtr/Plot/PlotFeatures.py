"""

Plotting region segments, their boundaries, keypoints for contours.

Elsewhere:
- boundaries in PlotDescBound.py
- keypoints in PlotDescKeyp.py

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------

--------------------   Regions   --------------------
def PlotRegUnv(AREG, SzM, bGray=0):

--------------------   Boundaries   --------------------
def p_BoundPix1ToPlot(Pix, szV, col='b', bJit=0, ctr=0):
def p_BoundPix1ToImg( Ax, Pix, col='b', liwi=1, bJit=0 ):

def p_BoundList( aBon, modus, szV, col=None, bJit=0, ctr=0 ):

def PlotBonSpc(ABON, szI, bImgSpc):

--------------------   Contours   --------------------
def p_CntKeyPts(S, col, typ, ax=None):
def PlotCntUnvKpt(CUV, Irgb, typIsp, figNo):

"""

import numpy as np
import matplotlib.pyplot as plt
import math
from skimage.transform import resize

import matplotlib.pyplot as plt

import warnings

from AdminPy.DescExtr.Features.Segments.RegUtil import *
#from AdminPy.DescExtr.Features.Segments.BonUtil import *

from AdminPy.Util.Plot.PlotUtils import colPalette
from AdminPy.DescExtr.Bbox.PlotBboxes import *





# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotRegUnv   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots region pixels of a universe, in color by default or in grayscale if specified.

IN     AREG   list of lists [nLev][depth]
       SzM    map sizes per level
       bGray  int or str: 0 = color, 'gray' = grayscale
"""
def PlotRegUnv(AREG, SzM, bGray=0):

    bGray = (bGray == 'gray')

    nLev  = len(AREG)
    depth = len(AREG[0])

    # ----- Compute map sizes -----
    SzM = np.asarray(SzM, dtype=int)

    if SzM.ndim == 1:
        # Compute pyramid level sizes
        szI  = SzM.copy()
        ASzM = np.zeros((nLev, 2), dtype=int)

        ASzM[0,:] = szI[:2]

        for l in range(1, nLev):
            ASzM[l,:] = ASzM[l-1,:] // 2

    else:
        ASzM = SzM.astype(int)

    # ----- Plot pixels -----
    fig, axes = plt.subplots(
        nLev, depth,
        figsize=(3 * depth, 3 * nLev),
        squeeze=False
    )

    for l in range(nLev):

        szI = ASzM[l]

        for d in range(depth):

            REG = AREG[l][d]

            Mgry, Irgb = u_RegPixToMapD1(REG, szI)

            ax = axes[l,d]

            # ----- Plot -----
            if bGray:
                ax.imshow(Mgry, cmap='gray', vmin=0, vmax=255)
            else:
                ax.imshow(Irgb)

            ax.axis('tight')
            ax.tick_params(labelsize=5)

            if l == 0:
                ax.set_title(f'depth {d}', fontsize=12)

            if d == 0:
                ax.set_ylabel(f'Lev = {l}', fontsize=12)

    plt.tight_layout()
    plt.show(block=False)



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_BoundPix1ToPlot   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots a single boundary in an x/y coordinate system. Row coordinates are inverted
(szV - Rw).

IN  Pix   pixRCi structure
    szV   vertical image dimension
    col   color
    bJit  adds random offset to avoid overlapping boundaries
    ctr   Contrast parameter controlling line width
OUT hp    Plot handle

"""
def p_BoundPix1ToPlot( Pix, szV, col='b', bJit=0, ctr=0):

    # Add jitter to avoid overlap
    off = np.random.rand() * 0.2 if bJit > 0 else 0

    #off += 1 # from zero-indexing to image pixels !?

    # Plot boundary
    hp, = plt.plot(
        np.asarray( Pix.Cl, dtype=np.float32 ) + off,
        np.asarray( szV - Pix.Rw, dtype=np.float32 ) + off,
        '-',
        color=col
    )

    # ----- Contrast -----
    if ctr > 0:
        liwi = int(np.ceil(ctr / 50))
        hp.set_linewidth(liwi)

    return hp


""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_BoundPix1ToImg   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots a single boundary to image, axis ij.

IN  Ax    axis
    col   color
    Pix   pixRCi structure
    szV   vertical image dimension
    bJit  adds random offset to avoid overlapping boundaries
OUT hp    Plot handle

"""
def p_BoundPix1ToImg( Ax, Pix, col='b', liwi=1, bJit=0 ):

    # Add jitter to avoid overlap
    off = np.random.rand() * 0.2 if bJit > 0 else 0

    off += 1                    # from zero-indexing to image pixels

    hp   = Ax.plot( Pix.Cl+off, Pix.Rw+off,
                    '-', color = col, linewidth = liwi )

    return hp



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_BoundList   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots a list of boundaries.

IN  aBon   list of boundary structures (Cl, Rw).
    modus  'plot' or 'img'.
    szV    vertical image dimension
    col    color or structure, optional
              Default color or structure with Red, Grn, Blu arrays.
              RGB values in the structure are assumed to be in [0, 255].
    bJit    jitter to avoid overlapping boundaries.
    ctr     contrast parameter controlling line width.

OUT  List of Matplotlib Line2D handles.

"""
def p_BoundList( aBon, modus, szV, col=None, bJit=0, ctr=0 ):

    # ----- Color handling -----
    bColor = False

    if col is None:
        col = [0.6, 0.6, 0.6]

    elif hasattr(col, 'Red'):
        bColor = True
        RGB = col
        col = [0.6, 0.6, 0.6]

    elif np.isscalar(col):
        col = [0.6, 0.6, 0.6]

    # ----- Plot boundaries -----
    nBon = len(aBon)

    print(f'Plotting {nBon:4d} boundaries...', end='')

    hp = []

    if modus.lower() == 'plot':

        for b in range(nBon):

            # Plot boundary in default color
            hb = p_BoundPix1ToPlot(
                aBon[b], szV, col, bJit, ctr
            )

            # Assign individual RGB color
            if bColor:
                red = RGB.Red[b] / 255.0
                grn = RGB.Grn[b] / 255.0
                blu = RGB.Blu[b] / 255.0

                hb.set_color([red, grn, blu])

            hp.append(hb)

    elif modus.lower() == 'img':

        raise NotImplementedError(
            "Mode 'img' not implemented yet."
        )

    else:
        raise ValueError(
            f"Mode '{modus}' not implemented. Use 'plot' or 'img'."
        )

    print('done')

    return hp



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotBonSpc   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots the boundary space.

IN   ABON    Boundary space [nLev], each entry containing a list of boundaries.
     szI     image size (szV, szH).
     bImgSpc 1 = pyramid space
             2 = scale space
"""
def PlotBonSpc(ABON, szI, bImgSpc):

    nLev = len(ABON)

    # ----- Compute map sizes -----
    szI = np.asarray(szI)

    if bImgSpc == 1:
        # Pyramid: compute level sizes
        SzM = np.zeros((nLev, 2), dtype=int)
        SzM[0, :] = szI[:2]

        for l in range(1, nLev):
            SzM[l, :] = SzM[l-1, :] // 2

    elif bImgSpc == 2:
        # Same size for entire space
        warnings.warn('Scale space not verified yet')
        SzM = np.tile(szI[:2], (nLev, 1))

    else:
        raise ValueError(f'bImgSpc = {bImgSpc} not implemented.')

    # ----- Plot boundaries -----
    fig, axes = plt.subplots(
        nLev, 1,
        figsize=(8, 3 * nLev),
        squeeze=False
    )

    for l in range(nLev):

        APix     = ABON[l]
        szV, szH = SzM[l]

        ax = axes[l, 0]

        # Plot boundaries
        plt.sca(ax)

        #                              col jit ctr
        p_BoundList( APix, 'plot', szV, 1,  1,  0 )

        ax.axis('tight')
        ax.tick_params(labelsize=5)
        ax.set_ylabel(f'Lev = {l}', fontsize=12)

    plt.tight_layout()
    plt.show( block=False )

    return fig, axes



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_CntKeyPts   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plot contours using keypoints.

IN  S : object or dict
        Structure containing Ep1, Ep2 and either Mip, Btw or Ep3.
        May also contain a nested Pts structure.
    col : color
    typ : str
        'abs' : absolute image coordinates
        'scl' : normalized coordinates
    ax : matplotlib.axes.Axes, optional
        Target axes. Uses current axes if None.
"""
def p_CntKeyPts(S, col, typ, ax=None):

    if ax is None:
        ax = plt.gca()

    # Support MATLAB-style structures
    def has_field(obj, name):
        return name in obj if isinstance(obj, dict) else hasattr(obj, name)

    def get_field(obj, name):
        return obj[name] if isinstance(obj, dict) else getattr(obj, name)

    if has_field(S, "Pts"):
        S = get_field(S, "Pts")
        Mip = get_field(S, "Btw")
    elif has_field(S, "Btw"):
        Mip = get_field(S, "Btw")
    else:
        Mip = get_field(S, "Ep3")

    Ep1 = get_field(S, "Ep1")
    Ep2 = get_field(S, "Ep2")

    nCnt = Ep1.shape[0]

    for i in range(nCnt):

        x1, y1 = Ep1[i,1], Ep1[i,0]
        x2, y2 = Ep2[i,1], Ep2[i,0]
        xm, ym = Mip[i,1], Mip[i,0]

        if typ == "abs":
            # Absolute image coordinates
            ax.plot([x1, xm], [y1, ym], color=col)
            ax.plot([xm, x2], [ym, y2], color=col)

        elif typ == "scl":
            # Normalized coordinates: invert vertical axis
            ax.plot([x1, x2], [1 - y1, 1 - y2], color=col)

        else:
            raise ValueError(f"typ '{typ}' not specified")


""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotcntUnvKpt   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plot the contour universe using keypoints.

IN
    CUV : object
        Contour universe with ARDG, ARIV and AEDG lists.
    Irgb : ndarray
        Original image.
    typIsp : int
        1 = image pyramid (downscale image per level)
        2 = same image for all levels
    figNo : int
        Matplotlib figure number.
"""
def PlotCntUnvKpt(CUV, Irgb, typIsp, figNo):

    nLev = len(CUV.ARDG)

    print(
        f"Plotting contour universe with keypoints "
        f"for {nLev} levels...",
        end=""
    )

    nr = math.ceil(nLev / 2)
    nc = 2

    fig, axes = plt.subplots(
        nr, nc,
        num=figNo,
        clear=True,
        squeeze=False
    )

    for l in range(nLev):

        ax = axes.flat[l]

        if typIsp == 1:
            # Downscale image for pyramid level (MATLAB: 1 / 2^(l-1))
            scale = 1.0 / (2 ** l)
            h = round(Irgb.shape[0] * scale)
            w = round(Irgb.shape[1] * scale)

            I = resize(
                Irgb,
                (h, w),
                preserve_range=True,
                anti_aliasing=True
            ).astype(Irgb.dtype)

        elif typIsp == 2:
            I = Irgb

        else:
            raise ValueError(
                f"Image space type {typIsp} not implemented"
            )

        ax.imshow(I)

        Rdg = CUV.ARDG[l]
        Riv = CUV.ARIV[l]
        Edg = CUV.AEDG[l]

        # Edges, rivers and ridges
        p_CntKeyPts( Edg, "c", "abs", ax=ax)
        p_CntKeyPts( Riv, "b", "abs", ax=ax)
        p_CntKeyPts( Rdg, "r", "abs", ax=ax)

        ax.tick_params(labelsize=5)

    # Hide unused subplot(s)
    for l in range(nLev, nr * nc):
        axes.flat[l].set_visible(False)

    plt.tight_layout()
    plt.show(block=False)

    print("done")        


    
