"""

  Reads form attributes and space. And bins as well.

------------------------------   CLS SUM   ------------------------------
class attFrm:

------------------------------   DEF SUM   ------------------------------
def ReadFrmAtt( fid ):
def ReadFrmSpc( fid ):

def ReadFrmBinUni( fid ):
def ReadFrmBinSpc( fid ):
def ReadFrmBinBiv( fid ):

"""
import numpy as np
from dataclasses import dataclass

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.PosAnf import *
from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import ReadDescSpcHead, ReadDescAttHead


from dataclasses import dataclass
import numpy as np


@dataclass
class attFrm:
    nRsg:   int = 0
    RdSig:  np.ndarray = None
    RospA:  np.ndarray = None
    RospB:  np.ndarray = None
    RoEck:  np.ndarray = None
    BospA:  np.ndarray = None
    Bglid:  np.ndarray = None
    Ori:    np.ndarray = None
    OriSax: np.ndarray = None
    Pos:    any = None
    Cod:    np.ndarray = None
    RGB:    any = None
    Ctr:    np.ndarray = None
    IxBon:  np.ndarray = None

    

""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadFrmSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads form attributes as saved under (?? RsgIO.h-w_RsgSpc)

"""
def ReadFrmAtt( fid ):

    S       = attFrm()
    
    # --------------------   Header   --------------------
    nDsc    = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    S.nRsg  = nDsc

    # --------------------   Data   --------------------
    # =====   Geometry   =====
    S.RdSig, dmy = ReadMtrxDat( fid, np.float32 )

    S.RospA, dmy = ReadMtrxDat( fid, np.float32 )
    S.RospB, dmy = ReadMtrxDat( fid, np.float32 )
    S.RoEck, dmy = ReadMtrxDat( fid, np.float32 )

    S.BospA, dmy = ReadMtrxDat( fid, np.float32 )
    S.Bglid, dmy = ReadMtrxDat( fid, np.float32 )
    
    # =====   Position   =====
    S.Ori    = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.OriSax = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Pos    = arrPos.from_file( fid )

    S.Cod    = np.fromfile( fid, dtype=np.uint8, count=nDsc) 

    # =====   Appearance   =====
    S.RGB    = ReadAttRgb( fid, nDsc )
    S.Ctr    = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # =====   Util   =====
    S.IxBon  = np.fromfile( fid, dtype=np.int32, count=nDsc)  

    # --------------------   Trailer   --------------------
    idf      = np.fromfile( fid, dtype=np.int16, count=1)

    assert idf == 2222, f"ReadFrmAtt: idf not correct. is {idf}"

    return S, nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadFrmSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of contour attributes as saved under RsgIO.h-w_RsgSpc

"""
def ReadFrmSpc( fid ):

    nLev, Nrsg = ReadDescSpcHead( fid )

    #print( nLev )
    #print( Nrsg )

    ARSG = [None] * nLev
    for l in range( 0, nLev ):

        ARSG[l], nRsg   = ReadFrmAtt( fid );

        assert Nrsg[l] == nRsg, 'contour count not matching'

    return ARSG, Nrsg


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadFrmBinUni   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

see ReadFrmBinUni.m
"""
def ReadFrmBinUni( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    S.nRsg  = nDsc;

    # --------------------   Data   --------------------
    S.Abn   = ReadMtrxDat( fid, np.int32 )
    S.Rgb   = ReadAttRgb(  fid, nDsc, np.uint8 )
    S.AspA  = ReadMtrxDat( fid, np.uint8 )
    S.Ecke  = ReadMtrxDat( fid, np.uint8 )
    
    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadFrmBinBiv   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadFrmBinBiv( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    

    # --------------------   Header   --------------------
    nDsc    = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    S.nRsg  = nDsc;

    # --------------------   Data   --------------------
    S.RO   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.RE   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.RC   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.REO  = np.fromfile( fid, dtype=np.int32, count=nDsc )  

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadFrmBinSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadFrmBinSpc( fid ):

    nLev = np.fromfile( fid, dtype=np.int32, count=1 )[0]

    #print( nLev )
    
    @dataclass
    class S:                                    # returning as structure
        pass    

    S.AUNI  = [None] * nLev
    S.ABIV  = [None] * nLev
    S.APOSA = [None] * nLev
    S.APOSQ = [None] * nLev
    for l in range( 0, nLev ):

        S.AUNI[l]   = ReadFrmBinUni( fid );
        S.ABIV[l]   = ReadFrmBinBiv( fid );

        S.APOSA[l]   = arrPos.from_file( fid, datTyp=np.float32 )
        S.APOSQ[l]   = arrPos.from_file( fid, datTyp=np.uint8 )
        
    return S



    
def deprecated():

    if 0:
        S.Rds   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        S.Cir   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        S.EloR  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        S.Cncv  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        
        S.Bis1  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        S.Bis2  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        S.Bis3  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        S.Bis4  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        S.Bis5  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        
        S.Star  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
        S.Dent  = np.fromfile( fid, dtype=np.float32, count=nDsc)  
