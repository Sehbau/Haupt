"""

  Reads contour attributes and space. And bins as well.

------------------------------   CLS SUM   ------------------------------
class cntAtt:

------------------------------   DEF SUM   ------------------------------
def ReadCntAtt( fid ):
def ReadCntSpc( fid ):

def ReadCntBinUni( fid ):
def ReadCntBinSpc( fid ):
def ReadCntBinBiv( fid ):


"""
import numpy as np
from dataclasses import dataclass

from .ReadAttGen import *
from AdminPy.DescExtr.DescFile.PosAnf import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import ReadDescSpcHead, ReadDescAttHead
from AdminPy.DescExtr.DescFile.PixPoints.PixPointsAnf import ReadDescPtsF
#from .Util.ReadDescHeaders import ReadDescSpcHead, ReadDescAttHead

# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class cntAtt:
    nCnt: int = 0
    Les:  np.ndarray = None
    Str:  np.ndarray = None
    Ori:  np.ndarray = None
    Pos:  any        = None
    RGB:  any        = None
    Ctr:  np.ndarray = None
    Pts:  any        = None


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntAtt   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads contour attributes as saved under CntIO.h-w_CntSpc

"""
def ReadCntAtt( fid, bWithPts: int=0 ):

    S = cntAtt()
    
    # --------------------   Header   --------------------
    nDsc    = ReadDescAttHead( fid );
    S.nCnt  = nDsc;

    # --------------------   Data   --------------------

    # =====   Geometry   =====
    S.Les   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Str   = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # =====   Position   =====
    S.Ori   = np.fromfile( fid, dtype=np.float32, count=nDsc)  
    S.Pos   = arrPos.from_file( fid ) # ReadAttPos( fid )

    # =====   Appearance   =====
    S.RGB   = ReadAttRgb( fid, nDsc )
    S.Ctr   = np.fromfile( fid, dtype=np.float32, count=nDsc)  

    # =====   Points  =====
    # used for RRE in LoadCntUnvKpt.m
    if bWithPts:
        bPt4    = 0
        S.Pts   = ReadDescPtsF( fid, bPt4 )

    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fid, dtype=np.int16, count=1)

    assert idf==1111, f"ReadCntAtt: idf not correct. is {idf}"

    return S, nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of contour attributes as saved under CntIO.h-w_CntSpc

"""
def ReadCntSpc( fid, bWithPts: int=0 ):

    nLev, Ncnt = ReadDescSpcHead( fid )

    #print( nLev )
    #print( Ncnt )

    ACNT = [None] * nLev
    for l in range( 0, nLev ):

        ACNT[l], nCnt   = ReadCntAtt( fid, bWithPts )

        assert Ncnt[l] == nCnt, 'contour count not matching'

    return ACNT, Ncnt



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntBinUni   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

see ReadCntBinUni.m
"""
def ReadCntBinUni( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    
    
    # --------------------   Header   --------------------
    nDsc    = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    S.nCnt  = nDsc;

    # --------------------   Data   --------------------

    # =====   Geometry   =====
    S.Les   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Str   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Ori   = np.fromfile( fid, dtype=np.int32, count=nDsc )  

    # =====   Appearance   =====
    S.Red   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Grn   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.Blu   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    
    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntBinBiv   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadCntBinBiv( fid ):

    @dataclass
    class S:                                    # returning as structure
        pass    

    # --------------------   Header   --------------------
    nDsc    = np.fromfile( fid, dtype=np.int32, count=1 )[0]
    S.nCnt  = nDsc;

    # --------------------   Data   --------------------
    S.LS   = np.fromfile( fid, dtype=np.int32, count=nDsc )  
    S.LO   = np.fromfile( fid, dtype=np.int32, count=nDsc )  

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadCntBinSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

"""
def ReadCntBinSpc( fid ):

    nLev = np.fromfile( fid, dtype=np.int32, count=1 )[0]

    #print( nLev )
    
    @dataclass
    class S:                                    # returning as structure
        pass    

    S.AUNI  = [None] * nLev
    S.ABIV  = [None] * nLev
    S.APOSA = [None] * nLev
    S.APOSQ = [None] * nLev
    for l in range( 0, nLev ):

        S.AUNI[l]   = ReadCntBinUni( fid );
        S.ABIV[l]   = ReadCntBinBiv( fid );

        S.APOSA[l]   = arrPos.from_file( fid, datTyp=np.float32 )
        S.APOSQ[l]   = arrPos.from_file( fid, datTyp=np.uint8 )
        #S.APOSA[l]   = ReadAttPos( fid, datTyp=np.float32 )
        #S.APOSQ[l]   = ReadAttPos( fid, datTyp=np.uint8 )

    return S





    
