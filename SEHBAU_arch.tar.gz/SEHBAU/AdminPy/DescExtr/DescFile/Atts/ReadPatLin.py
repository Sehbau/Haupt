"""

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------

"""
from dataclasses import dataclass
from typing import BinaryIO

import numpy as np
import numpy.typing as npt

from   AdminPy.DescExtr.DescFile.Atts.ReadAttGen import * 


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class patLinVmx:
    """
    Line pattern. Very explicit for convenience.
    """
    nLin: int
    nAtt: int
    VEC:  np.ndarray


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------


@dataclass(slots=True)
class patLin:

    nLin: int
    Ep1: npt.NDArray[np.float32]  # (nLin, 2)
    Ep2: npt.NDArray[np.float32]  # (nLin, 2)
    Mip: npt.NDArray[np.float32]  # (nLin, 2)
    Ori: npt.NDArray[np.float32]
    Len: npt.NDArray[np.float32]
    Wgt: npt.NDArray[np.float32]
    Typ: npt.NDArray[np.float32]
    Lev: npt.NDArray[np.float32]
    RGB: object  # Replace with the return type of ReadAttRgb

    @classmethod
    def read(cls, fileID: BinaryIO) -> "patLin":
        def read_exact(dtype, count):
            arr = np.fromfile(fileID, dtype=dtype, count=count)
            if arr.size != count:
                raise EOFError(
                    f"Expected {count} values of {np.dtype(dtype)}, "
                    f"got {arr.size}"
                )
            return arr

        # Header
        nLin = int(read_exact(np.int32, 1)[0])

        def read_points():
            Vls = read_exact(np.float32, nLin * 2)
            return Vls.reshape( nLin, 2 ).copy()

        Ep1 = read_points()
        Ep2 = read_points()
        Mip = read_points()

        # Geometry
        Ori = read_exact(np.float32, nLin)
        Len = read_exact(np.float32, nLin)
        Wgt = read_exact(np.float32, nLin)

        # Util
        Typ = read_exact(np.uint8, nLin).astype(np.float32)
        Lev = read_exact(np.uint8, nLin).astype(np.float32)

        RGB = ReadAttRgb(fileID, nLin)

        # Trailer
        idf = int(read_exact(np.int32, 1)[0])
        if idf != 99999:
            raise ValueError(f"Invalid patLin trailer: expected 99999, got {idf}")

        return cls(
            nLin = nLin,
            Ep1 = Ep1,
            Ep2 = Ep2,
            Mip = Mip,
            Ori = Ori,
            Len = Len,
            Wgt = Wgt,
            Typ = Typ,
            Lev = Lev,
            RGB = RGB,
        )


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadPatLinVmx   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads line pattern as vector matrix.
    
IN      fileID      an open text file object.
OUT     patLinVmx   a dataclass instance containing nLin, nAtt, and VEC.

"""
def ReadPatLinVmx( file ) -> patLinVmx:


    Line    = np.fromstring(file.readline(), dtype=np.int32, sep=' ')

    # ------------   Header   --------------
    nLin   = int(Line[0])
    nAtt   = int(Line[1])

    # ------------   Data   --------------
    nElm   = nLin * nAtt
    VMX    = np.fromfile(file, dtype=np.float32, sep=' ', count=nElm).reshape( nLin, nAtt )

    return patLinVmx( nLin=nLin, nAtt=nAtt, VEC=VMX )
