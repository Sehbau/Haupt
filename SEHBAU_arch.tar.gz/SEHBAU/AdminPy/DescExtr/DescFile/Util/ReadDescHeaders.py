"""

Headers for descriptor files and attribute lists.

------------------------------   CLS SUM   ------------------------------
class descFileHeadUniv:
descFileHeadVect

------------------------------   DEF SUM   ------------------------------
def ReadDescFileHead( fid, typExp ):
def ReadDescSpcHead(fid):
def ReadDescAttHead( fid ):
def ReadDescOrgn( fid, nDsc ):

"""
from dataclasses import dataclass

import numpy as np


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass#(slots=True)
class descFileHeadUniv:
    """
    Description file header for description file (universe)
    """
    nLev   = 0
    szV    = 0
    szH    = 0
    ntDsc  = 0
    typ    = 0
    
    depth  = 0
    space  = 0
    bFlg3  = 0
    bFlg4  = 0
    bFlg5  = 0

    versLod = 0.0


@dataclass()
class descFileHeadVect:
    """
    Description file header for vector matrix file
    """
    nLev   = 0
    Ndsc   = np.array
    nAtt   = 0

    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescFileHead   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the header of a descriptor file (.dsc)

"""
def ReadDescFileHead( fid, typExp ):

    versExp = 1.03

    S       = descFileHeadUniv()

    S.nLev  = np.fromfile( fid, dtype=np.int32, count=1)[0]     # # of pyramid levels
    S.szV   = np.fromfile( fid, dtype=np.int32, count=1)[0]     # vertical image size
    S.szH   = np.fromfile( fid, dtype=np.int32, count=1)[0]     # horizontal image size
    S.ntDsc = np.fromfile( fid, dtype=np.int32, count=1)[0]     # # of total desc
    S.typ   = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # file typ (imag|fidcus)

    S.depth = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # depth of segmentation
    S.space = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # image space (pyr | ss)
    S.bFlg3 = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # not used at the moment
    S.bFlg4 = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # not used at the moment
    S.bFlg5 = np.fromfile( fid, dtype=np.uint8, count=1)[0]     # not used at the moment

    S.versLod = np.fromfile( fid, dtype=np.float32, count=1)[0]  # version loaded

    assert S.typ == typExp, f'file idf not correct: {S.typ}, expected {typExp}'
    assert S.nLev > 0 and S.nLev < 12, f'nLev not correct: {S.nLev}'
    assert S.szV > 0 and S.szV < 5000, f'szV unreasonable: {S.szV}'
    assert S.szH > 0 and S.szH < 5000, f'szH unreasonable: {S.szH}'
    assert abs(S.versLod - versExp) < 0.001, f'Version depreciated: is {S.versLod:.3f}. new {versExp:.3f}'
    #Hed = descFileHeadUniv( nLev, szV, szH, ntDsc, versLod, depth, space )

    return S



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescVectHead   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the header of a vector-matrix file (.vec{Dsc})

"""
def ReadDescVectHead( fid ):

    S       = descFileHeadVect()

    Line    = np.fromstring(fid.readline(), dtype=np.int32, sep=' ')

    S.nLev = Line[0]
    S.Ndsc = Line[1 : 1 + S.nLev]
    S.nAtt = Line[1 + S.nLev]

    #S.nLev  = np.fromfile( fid, dtype=np.int32, count=1)[0]    # num of levels
    #S.Ndsc  = np.fromfile( fid, dtype=np.int32, count=S.nLev)  # num of descriptors
    #S.nAtt  = np.fromfile( fid, dtype=np.int32, count=1)[0]    # num of attributes

    return S

    
""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescSpcHead   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads SPACE header (ReadDescSpcHead.m )

cf Read{Dsc}Att.py, ie ReadCntAtt.

"""
def ReadDescSpcHead(fid):

    nLev = np.fromfile(fid, dtype=np.int32, count=1)[0]  # # of levels
    Ndsc = np.fromfile(fid, dtype=np.int32, count=nLev)  # # of descriptors

    return nLev, Ndsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescAttHead   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads descriptor ATTRIBUTE header (ReadDescSpcHead.m )

cf Read{Dsc}Att.py, ie ReadCntAtt.

"""
#@dataclass
#class descAttHead:
#    nDsc: int
#    bTif: int
#    bCol = 0

def ReadDescAttHead( fid ):

    nDsc = np.fromfile( fid, dtype=np.int32, count=1)[0] 
    bNap = np.fromfile( fid, dtype=np.uint8, count=1)[0] # not applicable

    return nDsc



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescOrgn   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads descriptor origin information as saved in C under w_DescOrgn.

cfro ReadArcAtt, ReadStrAtt

"""
def ReadDescOrgn( fid, nDsc ):

    @dataclass
    class S:
        pass
    
    S.Anf    = np.fromfile( fid, dtype=np.int32, count=nDsc)
    S.Npx    = np.fromfile( fid, dtype=np.int32, count=nDsc)
    S.IxBtw  = np.fromfile( fid, dtype=np.int32, count=nDsc)
    S.OrgCrv = np.fromfile( fid, dtype=np.int32, count=nDsc)
    S.OrgDth = np.fromfile( fid, dtype=np.uint8, count=nDsc)
        
    return S
