"""

Read (individual) pixels and points.

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------

"""
from dataclasses import dataclass, field
from typing import BinaryIO

import numpy as np
import numpy.typing as npt

ArrayI32 = npt.NDArray[np.int32]
ArrayF32 = npt.NDArray[np.float32]

def _read(fid: BinaryIO, dtype, count: int) -> np.ndarray:
    """Read exactly count values, or raise if the file is truncated."""
    data = np.fromfile(fid, dtype=dtype, count=count)
    if data.size != count:
        raise EOFError(f"Expected {count} values, got {data.size}")
    return data


# ------------------------------   pixRCs   ------------------------------
@dataclass(slots=True)
class pixRCs:
    """
    Pixel coordinates stored as row/column pairs.
    cfro ReadAttGen.py
    """
    nCo: int
    szM: tuple[int, int]
    Rw: ArrayI32
    Cl: ArrayI32
    Pt: ArrayI32 = field(init=False)

    def __post_init__(self):
        self.Pt = np.column_stack((self.Rw, self.Cl)).astype(
            np.int32, copy=False
        )

    @classmethod
    def read(cls, fid: BinaryIO) -> "pixRCs":
        nCo = int(_read(fid, np.int32, 1)[0])
        szM = tuple(int(x) for x in _read(fid, np.int32, 2))

        Rw = _read(fid, np.int16, nCo).astype(np.int32)
        Cl = _read(fid, np.int16, nCo).astype(np.int32)

        return cls(nCo=nCo, szM=szM, Rw=Rw, Cl=Cl)


# ------------------------------   pixvRCf   ------------------------------
@dataclass(slots=True)
class pixvRCf:
    """
    Pixel coordinates with an associated float value per pixel.
    cfro LoadDescSalc.py
    """
    Px: pixRCs
    V: ArrayF32

    @classmethod
    def read(cls, fid: BinaryIO) -> "pixvRCf":
        Px = pixRCs.read(fid)
        V = _read(fid, np.float32, Px.nCo)
        return cls(Px=Px, V=V)


# ------------------------------   descPtsS   ------------------------------
@dataclass(slots=True)
class descPtsS:
    """
    Descriptor points stored as int16 coordinates, returned as float32.
    cfro ReadArcAtt, ReadStrAtt
    """
    nPts: int
    Ep1: ArrayF32
    Ep2: ArrayF32
    Btw: ArrayF32

    @classmethod
    def read(cls, fid: BinaryIO) -> "descPtsS":
        nPts = int(_read(fid, np.int32, 1)[0])
        shape = (nPts, 2)
        count = nPts * 2

        def read_points() -> ArrayF32:
            return _read(fid, np.int16, count).astype(np.float32).reshape(shape)

        return cls(
            nPts=nPts,
            Ep1=read_points(),
            Ep2=read_points(),
            Btw=read_points(),
        )

    
# ------------------------------   descPtsF   ------------------------------
@dataclass(slots=True)
class descPtsF:
    nPts: int
    Ep1: npt.NDArray[np.float32]
    Ep2: npt.NDArray[np.float32]
    Btw: npt.NDArray[np.float32]
    Ep4: npt.NDArray[np.float32] | None = None


"""
called from ReadCntAtt
"""
def ReadDescPtsF(fileID, bPt4: bool) -> descPtsF:

    nPts  = int(np.fromfile(fileID, dtype=np.int32, count=1)[0])
    nCo   = nPts * 2
    shape = (nPts, 2)

    def read_points():

        return np.fromfile(
            fileID, dtype=np.float32, count=nCo ).reshape( nPts, 2 ).copy()

    Ep1 = read_points()
    Ep2 = read_points()
    Btw = read_points()
    Ep4 = read_points() if bPt4 else None

    return descPtsF(nPts=nPts, Ep1=Ep1, Ep2=Ep2, Btw=Btw, Ep4=Ep4)


# ------------------------------   descCor4F   ------------------------------
@dataclass(slots=True)
class descCor4F:
    """
    Four descriptor-point arrays stored as float32 coordinates.
    cfro ReadTtrgAtt
    """
    nPts: int
    Ep1: ArrayF32
    Ep2: ArrayF32
    Ep3: ArrayF32
    Ep4: ArrayF32

    @classmethod
    def read(cls, fid: BinaryIO) -> "descCor4F":

        nPts  = int( _read(fid, np.int32, 1)[0])
        shape = (nPts, 2)
        count =  nPts * 2

        def read_points() -> ArrayF32:
            return _read(fid, np.float32, count).reshape(shape)

        return cls(
            nPts=nPts,
            Ep1=read_points(),
            Ep2=read_points(),
            Ep3=read_points(),
            Ep4=read_points(),
        )


# ------------------------------   Huellen   ------------------------------
# for compatibility with Matlab
def ReadPixRCs(fid):
    return pixRCs.read(fid)


def ReadPixvRCf(fid):
    return pixvRCf.read(fid)


def ReadDescPtsS(fid):
    return descPtsS.read(fid)


def ReadDescCor4F(fid):
    return descCor4F.read(fid)





