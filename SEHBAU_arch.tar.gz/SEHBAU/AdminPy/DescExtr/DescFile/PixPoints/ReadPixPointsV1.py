"""Reads pixels and points as saved by dscx. For boundary pixels see Features/PixAnf.py.

def ReadPixRCs( fid ):
def ReadPixvRCf( fid ):
def ReadDescPtsS( fid ):
def ReadDescCor4F( fid ):

"""

import numpy as np



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadPixRCs   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Read pixels as rows and cols in short.

cf ReadAttFarbig in ReadAttGen.py

"""
def ReadPixRCs( fid ):

    class S:

        nCo = np.fromfile( fid, dtype=np.int32, count=1)[0]
        szM = tuple( np.fromfile( fid, dtype=np.int32, count=2) )

        #print(nCo)
        #print(szM)

        # Read as int16 and convert to int32
        Rw = np.fromfile( fid, dtype=np.int16, count=nCo).astype(np.int32)
        Cl = np.fromfile( fid, dtype=np.int16, count=nCo).astype(np.int32)
    
        Pt = np.column_stack((Rw, Cl))  # Combined [row, col] points
    
    return S



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadPixvRCf   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

ReadPixRCs with (associated) values as float (w_PixvRCf in PixIO.h)

cf LoadDescSaliency

"""
def ReadPixvRCf( fid ):

    class S:
        pass

    S.Px    = ReadPixRCs( fid )                 # above
    
    S.V     = np.fromfile( fid, dtype=np.float32, count=S.Px.nCo)

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescPtsS   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

see ReadDescPtsS.m

cf ReadArcAtt.py

"""
def ReadDescPtsS( fid ):

    class S:
        pass

    nPts = int(np.fromfile( fid, dtype=np.int32, count=1)[0])

    nCo  = nPts * 2

    Dim  = tuple( ( nPts, 2 ) )
        
    # Read int16 values and convert to float32
    int16 = np.int16
    flt32 = np.float32

    S.Ep1 = np.fromfile( fid, dtype=int16, count=nCo).astype(flt32).reshape( Dim )
    S.Ep2 = np.fromfile( fid, dtype=int16, count=nCo).astype(flt32).reshape( Dim )
    S.Btw = np.fromfile( fid, dtype=int16, count=nCo).astype(flt32).reshape( Dim )

    S.nPts = nPts
    
    return S



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescCor4F   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

see ReadDescPtsS.m

cf ReadTtrgAtt

"""
def ReadDescCor4F( fid ):

    class S:
        pass

    nPts = int(np.fromfile( fid, dtype=np.int32, count=1)[0])

    nCo  = nPts * 2

    Dim  = tuple( ( nPts, 2 ) )
        
    flt32 = np.float32

    S.Ep1 = np.fromfile( fid, dtype=flt32, count=nCo).reshape( Dim )
    S.Ep2 = np.fromfile( fid, dtype=flt32, count=nCo).reshape( Dim )
    S.Ep3 = np.fromfile( fid, dtype=flt32, count=nCo).reshape( Dim )
    S.Ep4 = np.fromfile( fid, dtype=flt32, count=nCo).reshape( Dim )

    S.nPts = nPts
    
    return S
