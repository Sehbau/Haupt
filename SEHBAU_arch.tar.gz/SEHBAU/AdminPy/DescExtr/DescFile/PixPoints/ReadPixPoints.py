"""

------------------------------   CLS SUM   ------------------------------
------------------------------   DEF SUM   ------------------------------
def ReadFrmKeyPts(fid):


def ReadDescPtsSpcF(fid, bFll=0):
def ReadFrmKeyPtsSpc(fid):

"""
from dataclasses import dataclass, field
from typing import BinaryIO

import numpy as np
import numpy.typing as npt

from .PixPointsAnf import *

from AdminPy.Util.FileIO.ReadValues import *
from AdminPy.Util.DataStruct import *
from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import *



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadFrmKeyPts   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads the keypoints of the form descriptor as saved under w_RsgRoCoo() in RsgIO.h

cf ReadFrmKeyPtsSpc.m
"""
def ReadFrmKeyPts(fid):

    # 1. Read nFrm: 1 integer (4 bytes)
    # np.fromfile returns an array, so we take [0] to get the scalar integer
    nFrm = int(np.fromfile(fid, dtype=np.int32, count=1)[0])
    
    # 2. Read the matrix data (Expected to return the matrix 'Mx' and size 'szD')
    # This calls your custom matrix reading helper
    Mx, szD = ReadMtrxDat(fid, np.int16 )
    
    # 3. Define the labels list
    lbls = [
        'Tole', 'Tori', 'Rito', 'Ribo',
        'Bole', 'Bori', 'Leto', 'Lebo',
        'Topp', 'Bott', 'Leff', 'Ritt'
    ]
    
    # 4. Convert the matrix to a list of dicts/structs using your custom helper
    S = u_MtrxToStcArrDcls(Mx, lbls)
    
    return S, nFrm



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescPtsSpcF   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of FLOAT keypoints as saved under DescAttIO.h-w_DescPtsSpcF

"""
def ReadDescPtsSpcF(fid, bFll=0):
    
    # Read the header data
    nLev, Npts = ReadDescSpcHead(fid)
    
    # Initialize the list (equivalent to cell array in MATLAB)
    ALev = [None] * nLev
    
    for l in range(nLev):

        ALev[l] = ReadDescPtsF(fid, bFll)
        
        # Verify the point count matches the header metadata
        assert ALev[l].nPts == Npts[l], 'point count not matching'
        
    return ALev, Npts



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescPtsSpcF   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of SHORT keypoints as saved under DescAttIO.h-w_DescPtsSpcS

cf LoadDescKeyp

af ReadDescPtsSpcF

"""
def ReadDescPtsSpcS(fid, bFll=0):

    # Read the spatial header data
    nLev, Npts = ReadDescSpcHead(fid)
    
    # Initialize the list (equivalent to cell array in MATLAB)
    ALev = [None] * nLev
    
    for l in range(nLev):
        # Call the short keypoint read function
        # Note: MATLAB code ignores bFll inside this loop, but passes it if needed
        ALev[l] = ReadDescPtsS(fid)
        
        # Verify the point count matches the header metadata
        assert ALev[l].nPts == Npts[l], 'point count not matching'
        
    return ALev, Npts



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadFrmKeyPtsSpc   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads space of form coordinates

cf LoadDescKeyp.m
"""
def ReadFrmKeyPtsSpc(fid):

    # Read the spatial header metadata
    nLev, Nfrm = ReadDescSpcHead(fid)
    
    # Initialize a list of None elements (equivalent to cell(nLev, 1))
    AFRM = [None] * nLev
    
    for l in range(nLev):
        # Unpack the struct array/list (S) and the frame count (nFrm / nRsg)
        AFRM[l], nRsg = ReadFrmKeyPts(fid)
        
        # Verify the read frame count matches the header specification
        assert Nfrm[l] == nRsg, 'rsg count not matching'
        
    return AFRM, Nfrm


