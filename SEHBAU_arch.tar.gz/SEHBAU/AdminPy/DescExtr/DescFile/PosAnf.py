"""

Position. The normalized coordinates for the descriptors.

I think this can be optimized.

Plotting in PlotDescriptors.py

------------------------------   CLS SUM   ------------------------------
class attPos:

------------------------------   DEF SUM   ------------------------------
def u_PosVHinvertToIJ(P):
def u_PosVHshift( P, offV, offH ):
def u_PosVHscaleup( P: attPos , szM, typCorr=1):

"""
from dataclasses import dataclass

import numpy as np

from typing import IO, Type

@dataclass
class posSvl:
    """ coordinates of a single position """
    vrt: float
    hor: float


@dataclass
class arrPos:
    """ an array of position coordinates """
    nPos: int
    Vrt:  np.ndarray  # vertical position
    Hor:  np.ndarray  # horizontal position

    @classmethod
    def from_file(cls, fid: IO, datTyp: Type = np.float32) -> "arrPos":
        """Factory method to read binary data directly into the dataclass."""
        nPos = np.fromfile(fid, dtype=np.int32, count=1)[0]
        Vrt  = np.fromfile(fid, dtype=datTyp, count=nPos)
        Hor  = np.fromfile(fid, dtype=datTyp, count=nPos)
        
        return cls(nPos=nPos, Vrt=Vrt, Hor=Hor)



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_PosVHinvertToIJ   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Inverts vertical (y) axis for IJ format.
"""
def u_PosVHinvertToIJ( P: arrPos ):

    P.Vrt = 1.0 - P.Vrt

    return P    



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_PosVHinvertToIJ   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Scales up position coordinates by map size szM and performs optional coordinate
corrections.

IN   P     position class with Vrt and Hor attributes.
     szM   map size [height, width].
     typCorr : int, default=1
            0: No correction (zero-indexing).
            1: Correction for pixel coordinates (quasi one-indexing).
OUT  P     same position class with scaled coordinates 

"""
def u_PosVHscaleup( P: arrPos , szM, typCorr=1):

    if typCorr == 0:
        P.Vrt = P.Vrt * float(szM[0])
        P.Hor = P.Hor * float(szM[1])

    elif typCorr == 1:
        P.Vrt = P.Vrt * szM[0] + 1
        P.Hor = P.Hor * szM[1] + 1

    else:
        raise ValueError(
            f"Correction {typCorr} not implemented"
        )

    return P


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_PosVHshift   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Shifts position coordinates by vertical and horizontal offsets.
Modifies P in place.
"""
def u_PosVHshift( P, offV, offH ):

    P.Vrt += offV
    P.Hor += offH

    return P
