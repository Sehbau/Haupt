"""

Loading and reading of descriptor attributes for ONE image. Includes contour
pattern, but not keypoints.

Saliency and proposals in directory Saliency

------------------------------   CLS SUM   ------------------------------
class descUniv:
class dbinUniv:

------------------------------   DEF SUM   ------------------------------
def LoadDescUniv( lfp ):
def LoadDbinUniv( lfp ):

def LoadDescVMX( lfp ):
def LoadDescVect( lfp ):
def LoadDescVectLev( lfp ):

def LoadDescPropAtts( lfn ):
def LoadCntPat(lfn: str | Path) -> tuple[cntPat, object]:
def LoadCntPatVmx( lfp ):
def LoadCntRRE(lfn: str | Path) -> CntRRE:

def u_TtrgRtrv1( S, ix ):

def ReadDescStats( file ):

Elsewhere:
- LoadDescSalc in LoadDescSalc.py
- LoadDescKeyp in LoadFeatures.py
- nearest neibors in LoadDescNN.py

"""

import sys, os
import numpy as np
from dataclasses import dataclass
from typing import Any, Tuple
from pathlib import Path

from AdminPy.DescExtr.DescFile.Util.ReadDescHeaders import *
from AdminPy.DescExtr.DescFile.Atts.ReadCntAtt import * #as CntRout
import AdminPy.DescExtr.DescFile.Atts.ReadFrmAtt as FrmRout
import AdminPy.DescExtr.DescFile.Atts.ReadArcAtt as ArcRout
import AdminPy.DescExtr.DescFile.Atts.ReadStrAtt as StrRout
import AdminPy.DescExtr.DescFile.Atts.ReadShpAtt as ShpRout
import AdminPy.DescExtr.DescFile.Atts.ReadTtrgAtt as TtgRout
import AdminPy.DescExtr.DescFile.Atts.ReadBndgAtt as BndRout
from   AdminPy.DescExtr.DescFile.Atts.ReadAttGen import * 
from   AdminPy.DescExtr.DescFile.Atts.ReadPatLin import * 

from AdminPy.DescExtr.DescType.ReadDescTyp import *
from AdminPy.DescExtr.Bbox.ReadFeatures import *
from AdminPy.DescExtr.OrgAtt.OrgAtts import *
from AdminPy.Util.UtilSscanf import *
from AdminPy.Util.FileIO.LoadData import *


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class labShpAbst:
    Sco: Any = None
    Sfi: Any = None

@dataclass
class labDescUniv:
    Shp: labShpAbst

@dataclass
class descUniv:
    """
    The descriptor universe. To be filled by LoadDescUniv below.
    """
    ACNT:   Any  = None
    AFRM:   Any  = None
    AARC:   Any  = None
    ASTR:   Any  = None
    ASHP:   Any  = None
    ATTRG:  Any  = None
    ABNDG:  Any  = None
    Labs:   Any  = None

@dataclass
class dbinUniv:
    """
    The bin-descriptor universe. To be filled by LoadDbinUniv below.
    """
    CNT:   Any  = None
    FRM:   Any  = None
    ARC:   Any  = None
    STR:   Any  = None
    SHP:   Any  = None

    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescUniv   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads description (attributes) for one image. 

Analogous to LoadDescUniv.m

"""
def LoadDescUniv( lfp ):

    fileID   = open(lfp, 'rb')

    # --------------------   Header   --------------------
    Hed    = ReadDescFileHead( fileID, 10 )

    #print(Hed)

    # --------------------   DescSpaces   --------------------
    DUV = descUniv()
    DUV.ACNT, Ncnt   = ReadCntSpc( fileID )
    DUV.AFRM, Nrsg   = FrmRout.ReadFrmSpc( fileID )

    nLev, Narc       = ReadDescSpcHead( fileID )
    nLev, Nstr       = ReadDescSpcHead( fileID )
    
    DUV.AARC, Narc   = ArcRout.ReadArcSpc( fileID )
    DUV.ASTR, Nstr   = StrRout.ReadStrSpc( fileID )

    DUV.ASHP, Nshp   = ShpRout.ReadShpSpc( fileID )

    idfBtw     = np.fromfile( fileID, dtype=np.int32, count=1)
    assert idfBtw==66666, f"LoadDescUniv: in-btw idf not correct. is {idfBtw}"

    DUV.ATTRG, Nttrg = TtgRout.ReadTtrgSpc( fileID )
    DUV.ABNDG, Nbndg = BndRout.ReadBndgSpc( fileID )

    # --------------------   Labels   --------------------
    # only for some attributes of the shape descriptor
    nDsc, nAttShpCors = DUV.ASHP[0].STR.shape
    nDsc, nAttShpFine = DUV.ASHP[0].SFI.shape

    Sco  = ReadAttLabels( fileID, nAttShpCors )
    Sfi  = ReadAttLabels( fileID, nAttShpFine )

    Shp  = labShpAbst( Sco, Sfi )
    
    DUV.Labs = labDescUniv(Shp=Shp) 
    
    # --------------------   Trailer Idf   --------------------
    idfEnd     = np.fromfile( fileID, dtype=np.int32, count=1)
    
    fileID.close()

    assert idfEnd==99999, f"LoadDescUniv: end-btw idf not correct. is {idfEnd}"

    return DUV, Hed


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDbinUniv   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads description (attributes) for one image. 

Analogous to LoadDbinUniv.m

"""
def LoadDbinUniv( lfp ):

    fileID   = open(lfp, 'rb')

    # --------------------   Header   --------------------
    Hed          = ReadDescFileHead( fileID, 55 )
    #print(Hed)

    # --------------------   DescSpaces   --------------------
    BIN = dbinUniv()
    BIN.CNT     = ReadCntBinSpc( fileID )
    BIN.FRM     = FrmRout.ReadFrmBinSpc( fileID )
    BIN.ARC     = ArcRout.ReadArcBinSpc( fileID )
    BIN.STR     = StrRout.ReadStrBinSpc( fileID ) 

    BIN.SHP     = ShpRout.ReadShpBinSpc( fileID )
    BIN.TTRG    = TtgRout.ReadTtrgBinSpc( fileID )

    # --------------------   Trailer Idf   --------------------
    idfEnd     = np.fromfile( fileID, dtype=np.int32, count=1 )
    
    fileID.close()

    assert idfEnd==888, f"LoadDbinUniv: end idf not correct. is {idfEnd}"

    return BIN, Hed



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescVMX   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads vector file [nDsc nAtt] as generated with option '--sVMX'

ti 

"""
def LoadDescVMX( lfp ):

    AVMX = []
    
    try:
        with open(lfp, 'rt') as file:

            # --------------------   Header   --------------------
            Line1   = np.fromstring(file.readline(), dtype=np.int32, sep=' ')
            nDty    = Line1[0]
            nLev    = Line1[1]
            NtVls   = np.fromstring(file.readline(), dtype=np.int32, sep=' ')
            print(NtVls)

            # --------------------   LOOP DESCTYPES   --------------------
            for d in range(nDty):
                Hed   = ReadDescVectHead(file)

                #print(Hed)
                nAttL = Hed.nAtt
                ntDsc = np.sum(Hed.Ndsc)
            
                nVls  = nAttL * ntDsc

                assert nVls==NtVls[d], 'somehow not correct'

                VMX   = np.fromfile(file, dtype=np.float32, sep=' ', count=nVls).reshape( ntDsc, nAttL )

                #nVred = VMX.size

                AVMX.append(VMX)
            
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not find {lfp}")

    return AVMX



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescVect   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads vector file [nDsc nAtt]

"""
def LoadDescVect( lfp ):

    # -------   Load Matrix   ---------
    try:
        with open(lfp, 'rt') as file:

            Hed  = ReadDescVectHead(file)

            #print(Hed)
            nAttL = Hed.nAtt
            ntDsc = np.sum(Hed.Ndsc)
            
            nVls  = nAttL * ntDsc

            VMX   = np.fromfile(file, dtype=np.float32, sep=' ', count=nVls).reshape( ntDsc, nAttL )

            nVred = VMX.size
            
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not find {lfp}")

    #print(f"Loaded: {lfp}")  # Equivalent to DispLoad(lfp)

    # -------   Obtain expected nAtt from Labels   --------
    base, ext = os.path.splitext(lfp)
    dty    = ext[4:]            # remove '.att', '.dsc', etc. => gets descriptor type
    Labs   = o_AttsLabels()     # obtains all labels
    AttLbs = getattr( Labs, dty ) 
    nAtt   = len(AttLbs)

    assert nAtt==nAttL, f'mismatch in num of atts {nAtt}<>{nAttL}'
    
    # -------   Reshape   --------
    if nVls != nVred:

        print( nVls, nVred )
        print(f'{dty} not properly read. Perhaps NQAN present. Reading as text.')
        Hed.nAtt   = -1
        VMX, nLin  = LoadTextLinewise( lfp )
        print(f'{nLin} lines read.')

    else:
        nDsc, nAtt = VMX.shape
        print(f"{dty} matrix is [{nDsc:4d} {nAtt:2d}].")
        #fprintf('%s matrix is [%4d %2d].\n', dty, nDsc, nAtt );

    return VMX, Hed, AttLbs



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescVectLev   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the array with level indices [nDsc 1]

"""
def LoadDescVectLev( lfp ):

    # -------   Load Matrix   ---------
    try:
        with open(lfp, 'rt') as file:

            Lev = np.fromfile(file, sep=' ', dtype=np.int32)
            
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not find {lfp}")

    nDsc   = len(Lev)
    minLev = Lev.min()
    maxLev = Lev.max()

    if minLev < 0:
        raise ValueError("Level smaller than 0 not possible")
    if maxLev > 10:
        raise ValueError("Level larger than 10 not possible")

    return Lev, nDsc



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescPropAtts   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads proposals

cf exsbProposals.py
"""
def LoadDescPropAtts( lfn ):

    fileID   = open( lfn, 'rb')

    class DSC:
        pass

    # --------------------   Head   --------------------
    DSC.nShp        = np.fromfile( fileID, dtype=np.int32, count=1)
    DSC.nTtg        = np.fromfile( fileID, dtype=np.int32, count=1)

    # --------------------   Data   --------------------
    DSC.Shp, nShp   = ShpRout.ReadShpAtt( fileID )
    DSC.Ttg, nTtg   = TtgRout.ReadTtrgAtt( fileID )
    
    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fileID, dtype=np.int32, count=1)

    fileID.close()

    assert idf==78000, f"LoadDescPropAtts: trail idf not correct. is {idf}"


    return DSC



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCntPat   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads line pattern as saved under s_AxiCnt in AxiIO.h

"""
@dataclass(slots=True)
class cntPat:
    Vrt: patLin
    Hor: patLin

def LoadCntPat(lfn: str | Path) -> tuple[cntPat, object]:

    with open(lfn, "rb") as fileID:
        Hed = ReadDescFileHead(fileID, 101)

        Pat = cntPat(
            Vrt = patLin.read(fileID),
            Hor = patLin.read(fileID),
        )

    return Pat, Hed



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCntPatVmx   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the contour pattern as vector matrix

"""
@dataclass(slots=True)
class cntPat:
    Vrt: object
    Hor: object

def LoadCntPatVmx( lfp ) -> cntPat:

    try:
        with open(lfp, 'rt') as file:

            Line    = np.fromstring(file.readline(), dtype=np.int32, sep=' ')

            # --------------------   Header   --------------------
            nSet    = Line[0]

            # --------------------   Data   --------------------
            Vrt = ReadPatLinVmx( file )
            Hor = ReadPatLinVmx( file )
            
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not find {lfp}")

    
    return cntPat( Vrt=Vrt, Hor=Hor )



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadCntRRE   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads all contour spaces (RRE), also known as the full set of contours.

Loads as saved under CntIOrre.h:si_RREspc.
"""
@dataclass(slots=True)
class CntRRE:
    ARDG: object
    ARIV: object
    AEDG: object
    Longst: npt.NDArray[np.float32]


def LoadCntRRE(lfn: str | Path) -> tuple[ CntRRE, object ]:

    with open(lfn, "rb") as fid:

        Hed        = ReadDescFileHead(fid, 100)

        nLev, Nrdg = ReadDescSpcHead(fid)
        nLev, Nriv = ReadDescSpcHead(fid)
        nLev, Nedg = ReadDescSpcHead(fid)

        # contour spaces, including keypoints
        bWithPts = True
        ARDG, Nrdg2 = ReadCntSpc( fid, bWithPts )
        ARIV, Nriv2 = ReadCntSpc( fid, bWithPts )
        AEDG, Nedg2 = ReadCntSpc( fid, bWithPts )

        Longst = np.fromfile(
            fid, dtype=np.float32, count=Hed.nLev
        )

    #DispLoad(lfn)

    return CntRRE(
        ARDG=ARDG,
        ARIV=ARIV,
        AEDG=AEDG,
        Longst=Longst,
    ), Hed



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   u_TtrgRtrv1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Retrieves one tetragon from a list. See u_TtrgRtrv1.m for details.

"""
def u_TtrgRtrv1( S, ix ):

    class Axe:
        Rw = [S.Ax.Ep1[ix, 0], S.Ax.Ep2[ix, 0]]
        Cl = [S.Ax.Ep1[ix, 1], S.Ax.Ep2[ix, 1]]

    class Cor:
        Rw = [ S.Cop.Ep1[ix, 0], S.Cop.Ep2[ix, 0], S.Cop.Ep3[ix, 0], S.Cop.Ep4[ix, 0] ]
        Cl = [ S.Cop.Ep1[ix, 1], S.Cop.Ep2[ix, 1], S.Cop.Ep3[ix, 1], S.Cop.Ep4[ix, 1] ]

    class O:
        vrt     = S.Pos.Vrt[ix]
        hor     = S.Pos.Hor[ix]
        ori     = S.Ori[ix]
        oriAbs  = abs(ori)

        axV     = S.LAGE['AxVrt'][ix]  # vertical
        axH     = S.LAGE['AxHor'][ix]  # horizontal

        Rgb     = [S.RGB.Red[ix], S.RGB.Grn[ix], S.RGB.Blu[ix]]

        ixBon   = S.IxBon[ix] 

    return Axe, Cor, O



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_DescMxToStcOfArr   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Ich hab die subgroups nicht.

Turns arrays of structs (matrices) into struct of arrays given attribute
names from o_AttsLabels.m
    
USE:
    LbAtts, LbAttSG = o_AttsLabels()
    DSC             = u_DescMxToStcOfArr(DSC, LbAttSG)

def u_DescMxToStcOfArr( DSC, LbAttSG ):

    # MATLAB: length(DSC.ACNT) counts elements in the array
    nLev = len(DSC.ACNT)

    for l in range(nLev):

        # ----------  form   ----------
        # Extracting the level object by 0-based indexing
        FRM = DSC.AFRM[l]         
        
        # Mutate the fields inside the FRM object
        FRM.RdSig = u_MtrxToStcArr(FRM.RdSig, LbAttSG.Frm.RdSig)
        FRM.RospA = u_MtrxToStcArr(FRM.RospA, LbAttSG.Frm.RospA)
        FRM.RospB = u_MtrxToStcArr(FRM.RospB, LbAttSG.Frm.RospB)
        FRM.RoEck = u_MtrxToStcArr(FRM.RoEck, LbAttSG.Frm.RoEck)
        
        # ----------  shape   ----------
        # Extracting and mutating the SHP object
        SHP = DSC.ASHP[l]         
        
        SHP.STR = u_MtrxToStcArr(SHP.STR, LbAttSG.Shp.Scors) 
        SHP.SFI = u_MtrxToStcArr(SHP.SFI, LbAttSG.Shp.Sfine) 

    return DSC
"""


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescStats   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

cf LoadDescSalc

"""
def ReadDescStats( file ):

    @dataclass
    class S:
        pass
    
    S.MaxSizScl = ReadDescTypSpcF( file );
    S.MenSizScl = ReadDescTypSpcF( file );
    S.MaxSizAbs = ReadDescTypSpcF( file );

    S.Ndsc  	  = ReadDescTypSpcI( file );
    S.IxMx   	  = ReadDescTypSpcI( file );

    nLev = S.Ndsc.nLev
    
    S.CvgBon    = ReadFeatCoverage( file, nLev );
    S.CvgShp    = ReadFeatCoverage( file, nLev );

    # ----------   Smoothness   ----------
    @dataclass
    class Smo:
        pass

    Smo.ArcMen = np.zeros(nLev, dtype=np.float32)
    Smo.ArcMax = np.zeros(nLev, dtype=np.float32)
    Smo.StrMen = np.zeros(nLev, dtype=np.float32)
    Smo.StrMax = np.zeros(nLev, dtype=np.float32)
    
    for l in range(nLev):

        arc  = ReadAttDom(file)
        strt = ReadAttDom(file)
        
        Smo.ArcMen[l] = arc.men
        Smo.ArcMax[l] = arc.max
        Smo.StrMen[l] = strt.men
        Smo.StrMax[l] = strt.max

    S.Smo = Smo

    idf = np.fromfile( file, dtype=np.int32, count=1)[0]
    if idf != -11111:
        raise ValueError("idf incorrect")
    
    # ----- shape2 -----
    S.AreShp    = np.fromfile(file, dtype=np.float32, count=nLev)
    S.ShpGrpSpc = np.fromfile(file, dtype=np.float32, count=3)

    # ----- appearance -----
    S.GryMmm   = np.fromfile(file, dtype=np.uint8, count=3).astype(np.int32)
    S.MxRngRR  = np.fromfile(file, dtype=np.uint8, count=nLev).astype(np.int32)
    S.MxRngEg  = np.fromfile(file, dtype=np.uint8, count=nLev).astype(np.int32)
    S.MxRngBon = np.fromfile(file, dtype=np.uint8, count=nLev).astype(np.int32)

    S.Nbon = np.fromfile(file, dtype=np.int32, count=nLev)
    S.Nrdg = np.fromfile(file, dtype=np.int32, count=nLev)
    S.Nriv = np.fromfile(file, dtype=np.int32, count=nLev)
    S.Nedg = np.fromfile(file, dtype=np.int32, count=nLev)

    S.NpxBon = np.fromfile(file, dtype=np.int32, count=nLev)
    S.NpxRdg = np.fromfile(file, dtype=np.int32, count=nLev)
    S.NpxRiv = np.fromfile(file, dtype=np.int32, count=nLev)
    S.NpxEdg = np.fromfile(file, dtype=np.int32, count=nLev)
    
    # ----------   Farbigkeit   ----------
    #print('bef Farbigkeit')
    S.Cnt = ReadAttFarbig( file )
    S.Bon = ReadAttFarbig( file )

    S.DomOriCnt, S.DomOriCntMx = ReadOriDomSpcF( file )
    S.DomOriShp, S.DomOriShpMx = ReadOriDomSpcF( file )

    return S

    

