"""Focus extraction from fabric. The extracted focus is a subspace.

For kernel generation see Fabric.py.

The naming of the layers for a subspace is:

    coarsest  (crst)
    coarse    (cors)
    fine      (fine)
    finest    (fnst)

but is dynamic due to the varying size of a focus. The highest layer of the subspace
is always the coarsest. The lowest layer always comes from the bottom layer of the
image fabric. And since the counting is reversed during top-down recognition in
FbrcAly.py, the subspace indices are reversed.

More explicitly: case when subspace height reaches the top layer of the image
fabric:

      3    crst      coming from top layer of the image fabric
      2    cors        "     "   upper "
      1    fine        "     "   lower "
      0    fnst        "     "   bottom "

Case when subspace height is three:

      2    crst      coming from UPPER layer (not top) of the image fabric
      1    cors        "     "   lower "
      0    fine        "     "   bottom "



------------------------------   CLS SUM   ------------------------------
class fbrcFocIX

------------------------------   DEF SUM   ------------------------------

def f_FbrcFocRngs( top: int, bot: int, lef: int, rit: int, Prm: prmFbrcFocSel ) -> fbrcFocIX:
def f_FbrcFocXtr( FLL: fbrcMTX, IX: fbrcFocIX ) -> fbrcMTX:


Elsewhere:
- f_FbrcKernel in Fabric.py

"""
from dataclasses import dataclass
import numpy as np
import numpy.typing as npt
from copy import deepcopy

from .FabricAnf import *
from AdminPy.FocSel.FocAnf import *
from AdminPy.MtchFbrc.MtchFbrcKrnl import *



# --------------------------------------------------------------------------------
#                             D A T A   C L A S S E S 
# --------------------------------------------------------------------------------


@dataclass
class fbrcFocIX:           # ''''''''''''''''''''   fbrcFocIX   ''''''''''''''''''''
    """Linear indices for the fabric layers

    """
    L: list[npt.NDArray[np.int32] | None] = field( default_factory=lambda: [None] * 4 )

    ASiz:   npt.NDArray[np.int32] = None # [4 2] the focus dimensions

    Ncll:   npt.NDArray[np.int32] = None # [4 1] the focus sizes

    nLayEnc : int=-1

    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FbrcFocRngs   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Extracting coordinate ranges for the fabric pyramid from a bounding box. No compensation
for upsampling.

"""
def f_FbrcFocRngs( Box: np.ndarray, Prm: prmFbrcFocSel ) -> fbrcFocIX:

    IX    = fbrcFocIX()

    Mrg   = Prm.Mrg
    
    ARng  = [None]*4
    Nrow  = np.empty( 4, dtype=np.int32)

    Ncol  = np.empty( 4, dtype=np.int32)

    #print(Prm.Scl)

    for l in range(4):
        ARng[l]  = f_FocBxRngGrd( Box, Prm.Scl[l] )     # FocAnf.py
        Nrow[l]  = ARng[l].nRow
        Ncol[l]  = ARng[l].nCol

    #print( Nrow )
    #print( Ncol )
    
    # ----------   Min Size for Lay0   ----------
    # ensure that bottom layer has at least one cell selected
    Rng0  = deepcopy(ARng[0])
    if Rng0.Rw.size==0:
        #print( Box )
        vrt0      = Prm.Scl[0][0]
        Rng0.Rw   = np.array( [np.floor( float(Box[0]) * vrt0 )], dtype=np.int32)
        Rng0.nRow = 1
    if Rng0.Cl.size==0:
        #print( Box )
        hor0      = Prm.Scl[0][1]
        Rng0.Cl   = np.array( [np.floor( float(Box[2]) * hor0 )], dtype=np.int32)
        Rng0.nCol = 1
    ARng[0] = deepcopy(Rng0)
        
    # ----------   Linear Indices   ----------
    SidLen = FBRCDimLay[:,0]

    ASiz   = np.empty( (4,2), dtype=np.int32)
    for l in range(4):
        Rng      = deepcopy(ARng[l])
        IX.L[l]  = (Rng.Rw[:, None] * SidLen[l] + Rng.Cl).flatten(order='F') 
        ASiz[l,:] = [Rng.nRow, Rng.nCol]

    IX.ASiz     = ASiz 

    IX.Ncll     = np.prod(IX.ASiz, axis=1).astype(np.int32)

    # Count is not decreasing continuously!?
    # I have cases like this: [14,  0,  3,  0]
    # that means I need to find the first zero
    ix0        = np.flatnonzero(IX.Ncll == 0)
    IX.nLayEnc = int(ix0[0]) if ix0.size else 4
    #ix1st0      = np.argmax( IX.Ncll == 0)
    #    if ix1st0>0:
    #        IX.nLayEnc  = ix1st0
    #    else:
    #        IX.nLayEnc  = 4
    
    return IX



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FbrcFocXtr   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Extracting a subspace from the full fabric for a specified bounding box given as
index structure.

"""
def f_FbrcFocXtr( FLL: fbrcMTXL, IX: fbrcFocIX ) -> fbrcMTXL:

    Dim  = deepcopy(FLL.Dim)       

    SEL  = m_FbrcMTXL( IX.nLayEnc, IX.Ncll, Dim.ntBin, Dim.ntBsv, Dim.nDscT )

    for l in range(4):
        SEL.AHYK[l]  = FLL.AHYK[l][ IX.L[l],: ] # [nCellSel ntBin]
        SEL.ABIS[l]  = FLL.ABIS[l][ IX.L[l],: ] # [nCellSel nBis]
        SEL.AKNT[l]  = FLL.AKNT[l][ IX.L[l],: ] # [nCellSel nDscTyp]

    # adjust these fields
    Dim.ASiz    = IX.ASiz
    Dim.Ncll    = IX.Ncll
    Dim.nLay    = IX.nLayEnc
    
    SEL.Dim     = Dim
    
    return SEL








