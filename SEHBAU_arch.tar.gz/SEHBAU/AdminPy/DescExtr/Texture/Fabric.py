"""Fabric manipulations. So far only kernel formation.

Elsewhere:
- matching in FbrcAly.py
- Anfang in FabricAnf.py
- loading in LoadFabric.py

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def f_FbrcKernel( FB: fbrcMTX ) -> fbrcKernel:

def f_FbrcFocBox1( FFLL: fbrcMTXL, Box: int, szImg: int ) -> fbrcKernel :

inactive: def f_FbrcKrnlFoc1(   FFLL: fbrcMTXL, Box, szV, szH ) -> fbrcKernel:
def f_FbrcKrnlFocLst( FFLL: fbrcMTXL, BBox, szImg, bDisp: int=0 ) -> list[fbrcKernel] :

def f_FbrcFocLst(     FFLL: fbrcMTXL, BBox: int, szImg: int, bDisp: int=0 ) -> list:
def f_FbrcFocKrnlLst( FFLL: fbrcMTXL, BBox: int, szImg: int, bDisp: int=0 ) -> list[fbrcKernel]:

"""
from dataclasses import dataclass
import numpy as np
import numpy.typing as npt

from .FabricAnf import *
from AdminPy.DescExtr.Texture.FabricFoc import *

#from AdminPy.FocSel.FocAnf import *



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_FbrcFocBbox   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII

"""
def i_FbrcFocBbox( Box, szVimg, szHimg ):

    print()
#    PrmScl      = i_PrmFbrcFocScl( szVimg, szHimg )

#    sclLay      = PrmScl.Scl[ixLay]
#    mrgLay      = PrmScl.Mrg[ixLay]
    


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FbrcKernel   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Takes first-order stats of the fabric. Full | subspace (focus). If subspace, then it
is a 'true' kernel.

IN    FB    fabric. image or focus. typically focus.

"""
def f_FbrcKernel( FB: fbrcMTXL ) -> fbrcKernel:

    S      = fbrcKernel()

    Dim    = FB.Dim

    assert Dim.ntBin > 0, 'ntBin not set'
    assert Dim.ntBsv > 0, 'ntBsv not set'
    assert Dim.nDscT > 0, 'nDscT not set'

    nLay   = Dim.nLay
    
    #print( f"--- nLay {nLay}" )
    S.MHyk   = np.zeros( (nLay, Dim.ntBin), dtype=np.float32 )
    S.MBis   = np.zeros( (nLay, Dim.ntBsv), dtype=np.float32 )
    S.MKnt   = np.zeros( (nLay, Dim.nDscT), dtype=np.float32 )
    
    for l in range( nLay ):

        if FB.AHYK[l].size==0:                  # should not occur
            print( Dim.ASiz )
            breakpoint()
        
        S.MHyk[l,:] = np.mean( FB.AHYK[l], axis=0 ) 
        S.MBis[l,:] = np.mean( FB.ABIS[l], axis=0 ) 
        S.MKnt[l,:] = np.mean( FB.AKNT[l], axis=0 ) 

    S.Dim = Dim


    # ------------------------------   Shell   ------------------------------
    nRow, nCol = Dim.ASiz[0,:]
    if nRow>2 and nCol>2:

        S.Shll  = np.empty( (4, Dim.ntBin), dtype=np.float32 )
        
        M       = np.arange(0,nRow*nCol).reshape(nRow,nCol)

        # Find midpoints, rounding to overlap 
        rwT     = int(np.ceil( M.shape[0]/2))
        rwB     = int(np.floor(M.shape[0]/2))
        clR     = int(np.floor(M.shape[1]/2))
        clL     = int(np.ceil( M.shape[1]/2))

        # Slice into 4 quadrants
        IxTL    = M[:rwT, :clL].flatten()
        IxTR    = M[:rwT, clR:].flatten()
        IxBL    = M[rwB:, :clL].flatten()
        IxBR    = M[rwB:, clR:].flatten()
        
        #print( IxTL, IxTR, IxBL, IxBR )
        S.Shll[0,:] = np.mean( FB.AHYK[0][IxTL,:], axis=0 )
        S.Shll[1,:] = np.mean( FB.AHYK[0][IxTR,:], axis=0 )
        S.Shll[2,:] = np.mean( FB.AHYK[0][IxBL,:], axis=0 )
        S.Shll[3,:] = np.mean( FB.AHYK[0][IxBR,:], axis=0 )

        S.bShllPres = 1
    else:
        S.bShllPres = 0    # ensure it is 0
        S.Shll      = None # ensure it is none
        #print('no shell: ' + str(S.Shll.size) +  '.')
        
    return S



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FbrcFocBox1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Extracts the subspace at bounding box, a focus.

IN    FFLL   image fabric
      Box    bounding box
      szImg  image size

cfro  exsbObjIdf.py
"""
def f_FbrcFocBox1( FFLL: fbrcMTXL, Box: int, szImg: int ) -> fbrcMTXL :

    # --- the scaling factors
    PrmScl   = i_PrmFbrcFocScl( szImg[0], szImg[1] )

    # --- extract and create kernel
    IXlin    = f_FbrcFocRngs( Box, PrmScl ) # the linear indices
    FFOC     = f_FbrcFocXtr( FFLL, IXlin )  # extract focus (subspace)
    
    return FFOC


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FbrcKrnlFoc1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Takes the kernel for the bounding box 'Box' from the image fabric (bounding box
typically a focus). It is a wrapper function for f_FbrcKernel above. For a list of
bounding boxes see function below.

IN    FFLL   image fabric
      Box    bounding box
      szImg  image size

cfro  exsbObjIdf.py

def f_FbrcKrnlFoc1( FFLL: fbrcMTXL, Box: int, szImg: int ) -> fbrcKernel :

    # --- the scaling factors
    PrmScl   = i_PrmFbrcFocScl( szImg[0], szImg[1] )

    # --- extract and create kernel
    IXlin    = f_FbrcFocRngs( Box, PrmScl ) # the linear indices
    FFOC     = f_FbrcFocXtr( FFLL, IXlin )  # extract focus (subspace)
    FKrnl    = f_FbrcKernel( FFOC )         # kernel: take mean of hyperkolumns/biases
    
    return FKrnl
"""



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FbrcFocLst   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Generating a list of fabric focii for the list of bounding boxes in Bbox

IN    FFLL  image fabric
      BBox  list/array of bounding boxes

cfro  exsbObjIdfLst.py
afro  f_FbrcFoc1 above
"""
def f_FbrcFocLst( FFLL: fbrcMTXL, BBox: int, szImg: int, bDisp: int=0 ) -> list:

    nBox, nFet = BBox.shape

    assert nFet==4, 'more than 4 parameters for bounding box?'
    
    # --- the scaling factors
    PrmScl   = i_PrmFbrcFocScl( szImg[0], szImg[1] )

    AFOC = []
    for b in range(nBox):
    
        IXlin    = f_FbrcFocRngs( BBox[b,:], PrmScl ) # the linear indices
        FFOC     = f_FbrcFocXtr( FFLL, IXlin )  # extract focus (subspace)

        AFOC.append(FFOC)
        
    return AFOC



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_FbrcFocKrnlLst   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Generating a list of kernels for the bounding boxes in Bbox. It's the same as above
but with the kernel-generating function added.

IN    FFLL  image fabric
      BBox  list/matrix of bounding boxes

cfro  exsbObjIdfLst.py
afro  f_FbrcKrnlFoc1 above
"""
def f_FbrcFocKrnlLst( FFLL: fbrcMTXL, BBox: int, szImg: int, bDisp: int=0 ) -> list[fbrcKernel]:

    nBox, nFet = BBox.shape

    assert nFet==4, 'more than 4 parameters for bounding box?'
    
    # --- the scaling factors
    PrmScl   = i_PrmFbrcFocScl( szImg[0], szImg[1] )

    AKrnl = []
    for b in range(nBox):
    
        IXlin    = f_FbrcFocRngs( BBox[b,:], PrmScl ) # the linear indices
        FFOC     = f_FbrcFocXtr( FFLL, IXlin )  # extract focus (subspace)
        FKrnl    = f_FbrcKernel( FFOC )         # kernel: take mean of hyperkolumns/biases

        if bDisp>0:
            print( f"nLay {FKrnl.Dim.nLay}   nCells {FKrnl.Dim.Ncll}" )

        AKrnl.append(FKrnl)
        
    return AKrnl
