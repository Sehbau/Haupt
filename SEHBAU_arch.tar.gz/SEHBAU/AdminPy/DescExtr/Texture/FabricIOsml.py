"""

Fabric IO of lists (sammlung)

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def SaveSmlgFBRCKRN(C: fbrcStsLst, StFb, Dim, pth: str):
def LoadSmlgFBRCKRN(pth: str) -> tuple[fbrcStsLst, dimFabric]:


"""


""" SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS   SaveSmlgFBRCKRN   SSSSSSSSSSSSSSSSSSSSSSSSSSSSSS

Saves the fbrcStsLst instance metadata and 2D/3D matrix blocks to a raw binary file.
"""
def SaveSmlgFBRCKRN(C: fbrcStsLst, StFb, Dim, pth: str):

    with open(pth, 'wb') as f:

        nLayMx = int(StFb.nLayMx)
        
        # ----------   Header   ----------
        np.array([ nLayMx, Dim.ntBin, Dim.ntvBis, Dim.ntvKnt ], dtype=np.int32).tofile(f)
        
        # frequency array (variable size based on layers)
        np.array( StFb.Frq[:nLayMx], dtype=np.int32).tofile(f)
        print( StFb.Frq )

        # ----------   Data Matrices   ----------
        for l in range(nLayMx):

            # Safe safeguard to skip uninitialized slots if applicable
            if C.AHYK[l] is None:
                continue
                
            C.AHYK[l].astype(np.float32).tofile(f)
            C.ABis[l].astype(np.float32).tofile(f)
            C.AKnt[l].astype(np.float32).tofile(f)


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadSmlgFBRCKRN   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads raw binary file content and parses it back into reconstructed 2D and 3D shapes.
Returns a tuple containing the (fbrcStsLst_instance, Frq_list, ntBin, ntvBis, ntvKnt).
"""
def LoadSmlgFBRCKRN(pth: str) -> tuple[fbrcStsLst, dimFabric]:

    with open(pth, 'rb') as f:

        # ----------   Header   ----------
        Hyprm   = np.fromfile(f, dtype=np.int32, count=4)
        nLayMx  = int(Hyprm[0])
        ntBin   = int(Hyprm[1])
        ntvBisL = int(Hyprm[2])
        ntvKntL = int(Hyprm[3])

        # frequency
        Frq    = np.fromfile(f, dtype=np.int32, count=nLayMx).tolist()
        print( Frq )
        
        # ----------   Data Matrices   ----------
        C    = fbrcStsLst()
        
        for l in range(nLayMx):

            nIst = Frq[l]
            #print( nIst )
            
            # Determine correct dynamic shapes to read back structural matrices
            if l == 0:
                dimHyk = (nIst, ntBin)
                dimBis = (nIst, ntvBisL)
                dimKnt = (nIst, ntvKntL)
            else:
                dimHyk = (nIst, ntBin,   l + 1)
                dimBis = (nIst, ntvBisL, l + 1)
                dimKnt = (nIst, ntvKntL, l + 1)

            #print( dimHyk )
            #print( dimBis )
            #print( dimKnt )
                
            # Compute raw flat count boundaries
            ntvHykF = int(np.prod(dimHyk))
            ntvBisF = int(np.prod(dimBis))
            ntvKntF = int(np.prod(dimKnt))
            
            # Deserialize stream and reshape exactly matching initialization
            C.AHYK[l] = np.fromfile(f, dtype=np.float32, count=ntvHykF).reshape(dimHyk)
            C.ABis[l] = np.fromfile(f, dtype=np.float32, count=ntvBisF).reshape(dimBis)
            C.AKnt[l] = np.fromfile(f, dtype=np.float32, count=ntvKntF).reshape(dimKnt)

        Dim         = dimFabric()
        Dim.ntBin   = ntBin
        Dim.ntvBis  = ntvBisL
        Dim.ntvKnt  = ntvKntL
            
        return C, Dim



