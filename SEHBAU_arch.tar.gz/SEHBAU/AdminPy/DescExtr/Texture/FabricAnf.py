"""

Fabric: the macro-texture formed from descriptors cnt, frm, arc, str & shp

Focus extraction in FabricFoc.py
Focus matching in MtchFbrcXXX.py

Four layers forming a pyramid:

      3    [ 3,3]       top 
      2    [ 7,7]       upper
      1    [15,15]      lower
      0    [31,31]      bottom

The naming of the corresponding layers for a fabric subspace (ie. focus) are:

      3    coarsest  (crst)
      2    coarse    (cors)
      1    fine      (fine)
      0    finest    (fnst)

------------------------------   CLS SUM   ------------------------------
class dimFabric
class fbrcMTXL
class fbrcKernel
class smglFBRCKRN
class prmFbrcFocSel

------------------------------   DEF SUM   ------------------------------
def i_PrmFbrcFocScl( szV: int, szH: int ) -> prmFbrcFocSel:
def u_FbrcCatKntMap( MP ):

def m_FbrcMTXL( nLay, Ncll, ntBin, ntvBis, ntvKnt ) -> fbrcMTXL:
def m_SmlgFBRCKRN( StFb, Dim ) -> smglFBRCKRN:

"""
from dataclasses import dataclass, field
import numpy as np
import numpy.typing as npt



# --------------------------------------------------------------------------------
#                                 G L O B A L S
# --------------------------------------------------------------------------------

# Layer dimensions and sizes for full space
FBRCDimLay = np.array([
    [31, 31],
    [15, 15],
    [ 7,  7],
    [ 3,  3] ])

FBRCNcells        = np.prod(FBRCDimLay, axis=1) # 961, 225, 49, 9
FBRCDimGrdBase    = np.array([32, 32])

FBRCNBisTyp       = 5
FBRCNdty          = 2

FBRC_SHELL_PRES   = 9999
FBRC_SHELL_ABSN   = -1111


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass(slots=True)
class dimFabric:                # ''''''''''''''''''''   dimFabric   ''''''''''''''''''''
    """Architectural dimensions of fabric, typically used for extracted subspace.

    ia 'Dim' in fbrcMTXL below
    """
    ASiz:   npt.NDArray[np.int32] = None # [4 2] the map/focus dimensions (shapes)

    Ncll:   npt.NDArray[np.int32] = None # [4 1] the map sizes (# of rixels / cells)

    nLay :    int = -1          # 4 for full pyramid, or less for subspace/focus

    ntBin:    int = -1          # num of total bins
    ntBsv:    int = -1          # num of total bias values (nBis*nDtyUsed)
    nDscT:    int = -1          # nDty, num of desctypes
    
    nBis:     int = 5           # bias types. dg1, dg2 were dropped during fbrc2arr conversion
    nDty:     int = 2

        
@dataclass(slots=True)
class fbrcMTXL:                 # ''''''''''''''''''''   fbrcMTXL   ''''''''''''''''''''
    """Fabric as matrices, the 12 matrices as generated with 'fbrc2arr'.

    Instantiations as
    - image fabric: FFLL, FImg, IFb: full pyramid
    - focus fabric: FFOC, FFoc: subspace of full
    - collected: 
    """
    Dim:  dimFabric = None
    
    # --- hyperkolumns, ntBin is same    {nLay}[nCells ntBin]
    AHYK: list[npt.NDArray[np.float32]] = field(default_factory=lambda: [None] * 4)
                                                
    # --- bias maps, nBis * (cnt + frm)  {nLay}[nCells ntBsv]
    ABIS: list[npt.NDArray[np.float32]] = field(default_factory=lambda: [None] * 4)

    # --- count maps, nDscTyp            {nLay}[nCells nDscT]
    AKNT: list[npt.NDArray[np.float32]] = field(default_factory=lambda: [None] * 4)


@dataclass(slots=True)
class fbrcKernel:               # ''''''''''''''''''''   fbrcKernel   ''''''''''''''''''''
    """Fabric kernel: mean vectors per layer. For focus typically, but could be used
    for full pyramid as well. Also regarded as a matrix [nLaySus ntBin/ntBsv/nDscT]

    """
    Dim:  dimFabric = None

    MHyk: npt.NDArray[np.float32] = None    # [nLaySus ntBin]
    MBis: npt.NDArray[np.float32] = None    # [nLaySus ntBsv]
    MKnt: npt.NDArray[np.float32] = None    # [nLaySus nDscT]

    bShllPres: int = 0
    Shll: npt.NDArray[np.float32] = None    # [4 ntBin] shell (quadrants for lay=0)


@dataclass(slots=True)
class smglFBRCKRN:               # ''''''''''''''''''''   smglFBRCKRN   ''''''''''''''''''''
    """List of fabric kernels, that is for different instances or categories. Kernel
    matrix appears transposed to [ntBin nLaySus], in order to be able to express the
    case for tiny focus subspaces consisting of one layer only, for which the last
    dimension is then dropped.

    nLay is used here twice: once for the varying focus sizes (tiny to huge), and
    then for the actual layers.
    
    {nLayApp}[nIst  ntBin/ntBsv/nDscT  nLaySus]

    nLayApp = 1, 2, 3 and 4
    {0}[nIst  ntBin/ntBsv/nDscT]
    {1}[nIst  ntBin/ntBsv/nDscT 2]
    {2}[nIst  ntBin/ntBsv/nDscT 3]
    {3}[nIst  ntBin/ntBsv/nDscT 4]

    """
    AAMHyk: list[npt.NDArray[np.float32]] = field(default_factory=lambda: [None] * 4)
    AAMBis: list[npt.NDArray[np.float32]] = field(default_factory=lambda: [None] * 4)
    AAMKnt: list[npt.NDArray[np.float32]] = field(default_factory=lambda: [None] * 4)


@dataclass(slots=True)
class prmFbrcFocSel:        # ''''''''''''''''''''   prmFbrcFocSel   ''''''''''''''''''''
    """The scaling factors for bbox (in original resolution) to map resolution, for
    four different layers as in the fabric description.

    cfro f_FbrcFocRngs
    
    - Scl     scaling factor for multiplication from image reso to layer reso (I think)
    - Mrg     margin size for compensating for subsampling
    - SclGrd  scaling factors for multiplication from image reso to cabinet reso. not used yet.

    """
    Scl: npt.NDArray[np.float32] = field(
        default_factory=lambda: np.zeros((4, 2), dtype=np.float32) )
    Mrg: npt.NDArray[np.int32] = field(
        default_factory=lambda: np.zeros((4, 2), dtype=np.int32) )



@dataclass
class fbrcLayers:          # ''''''''''''''''''''   fbrcLayers   ''''''''''''''''''''
    """
    The four layers. General use
    """
    aL: list = field(default_factory=lambda: [[] for _ in range(4)])
    # aL = [[] for _ in range(4)] this merges lists somehow
    # aL = [None]*4   I cannot append to this

    

    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

"""IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_PrmFbrcFocScl   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII

Calculates the scaling factors for extracting focii from fabric maps.

IN   szV, szH   image size (or cabinet size?)
OUT  P          .Scl   scaling factors for all four layers
                .Mrg   size of margin
"""
def i_PrmFbrcFocScl( szV: int, szH: int ) -> prmFbrcFocSel:

    P      = prmFbrcFocSel()
    #LaySiz = np.array([32, 16, 8, 4]) # layer size (plus 1)

    # --- scale factors and margins to layer sizes
    Scl    = np.zeros( (4,2), dtype=np.float32 )
    Mrg    = np.zeros( (4,2), dtype=np.int32 )
    for l in range(4):

        Scl[l][0] = FBRCDimLay[l][0] / float(szV)
        Scl[l][1] = FBRCDimLay[l][1] / float(szH)
        Mrg[l][0] = round(szV / (FBRCDimLay[l][0]+1) / 2)
        Mrg[l][1] = round(szH / (FBRCDimLay[l][0]+1) / 2)

    P.Scl   = Scl
    P.Mrg   = Mrg

    #P.vrt0  = 31 / float(szV)
    #P.hor0  = 31 / float(szH)

    # --- scale factors to cabinet grid
    # not deployed yet:
    #SclGrd = np.zeros( (2), dtype=np.float32 )
    #SclGrd[0] = szV / FBRCDimGrdBase[0]
    #SclGrd[1] = szH / FBRCDimGrdBase[1]

    return P


""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_FbrcCatKntMap   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Concatenates the count maps to a single block. Deprecated I think.

"""
def u_FbrcCatKntMap( MP ):

    KT = np.stack( (MP.Ncnt, MP.Nfrm, MP.Narc, MP.Nstr, MP.Nshp), axis=2 )
    
    return KT


""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   m_FbrcMTXL   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII

Allocate fabric as outputted by fbrc2arr

"""
def m_FbrcMTXL( nLay, Ncll, ntBin, ntBsv, nDscT ) -> fbrcMTXL:

    M   = fbrcMTXL()
    
    for l in range(nLay):
        M.AHYK[l]   = np.zeros( (Ncll[l], ntBin),  dtype=np.float32 )
        M.ABIS[l]   = np.zeros( (Ncll[l], ntBsv),  dtype=np.float32 )
        M.AKNT[l]   = np.zeros( (Ncll[l], nDscT),  dtype=np.float32 )

    return M



""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   m_SmlgFBRCKRN   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII

Allocate a list of fabric kernels of arbitrary size, a sammlung.

Max pyramid height is given in StFb.nLayMx. If we collect small objects only, it
might be only 1 or 2. For collecting arbitrary sized objects, it can be up to 4.

cfro SML_FBRCkern in Samml.py

"""
def m_SmlgFBRCKRN( StFb, Dim ) -> smglFBRCKRN:

    C   = smglFBRCKRN()

    # first (zeroth) layer
    C.AAMHyk[0] = np.zeros( (StFb.Frq[0], Dim.ntBin), dtype=np.float32 )
    C.AAMBis[0] = np.zeros( (StFb.Frq[0], Dim.ntBsv), dtype=np.float32 )
    C.AAMKnt[0] = np.zeros( (StFb.Frq[0], Dim.nDscT), dtype=np.float32 )
    
    # layers 2-4 (1-3)
    for l in range(1,StFb.nLayMx):
        C.AAMHyk[l] = np.zeros( (StFb.Frq[l], Dim.ntBin, l+1), dtype=np.float32 )
        C.AAMBis[l] = np.zeros( (StFb.Frq[l], Dim.ntBsv, l+1), dtype=np.float32 )
        C.AAMKnt[l] = np.zeros( (StFb.Frq[l], Dim.nDscT, l+1), dtype=np.float32 )

    return C




