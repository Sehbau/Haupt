"""

Wrapper function for program dscx

------------------------------   CLS SUM   ------------------------------
class argsDscx:

------------------------------   DEF SUM   ------------------------------
def i_DscxArgs( O: argsDscx ) -> str:
def RennDscx( fipaImg, fipaOut, Args, fpExe ):


"""
import subprocess, platform
from dataclasses import dataclass, asdict
from pathlib import Path
import shlex


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class argsDscx:             # ''''''''''''''''''''   argsDscx   ''''''''''''''''''''
    """
    Administrative structure for passing arguments to dscx

    equivalent to o_DscxArgs.m 
    
    USE  - not utilized yet.
         - or:
           O = DscxArgs( saveRRE=1, saveKol=1, nLev=3, depth=2, imgSpc=1 )
           cmnd = i_DscxArgs(O)
           print( cmnd )
    
    """
    ## -----   Saving  -----
    saveRRE   = 0     # saving of RRE space (full set)
    saveCVP   = 0     # saving of full CVP space
    saveKol   = 0     # saving of kolumns
    saveTxm   = 0     # saving of texture maps

    # setting the following two has no effect!!
    saveBin   = 0     # saving of bins. default ON!!
    saveProp  = 0     # saving proposals. default ON!!

    # feature
    saveRegUnv    = 0     # region universe
    saveBonSpc    = 0     # boundary space

    # other
    saveBonBoxRaw = 0  # saves .bonBboxRaw 
    saveBonMore   = 0  # .bonBbox, .bonAsp
    saveCuvKpt    = 0  # saves .cuvKpt

    noSave        = 0     # saving of description # does this work?

    ## -----  Archit  -----
    # a value of -1 signals that no modification is desired. default remains.
    nLev      = -1 
    depth     = -1 
    imgSpc    = -1    # image space (pyramid or scale space)
    imgFlt    = -1    # image filtering
    
    ## -----  Other   -----
    optS      = ''


""" IIIIIIIIIIIIIIIIIIIIIIIIIIIIII   i_DscxArgs   IIIIIIIIIIIIIIIIIIIIIIIIIIIIII
"""
def i_DscxArgs( O: argsDscx ) -> str:

    # Verify field count
    #aFldn     = list(asdict(O).keys())
    #nFldFound = len(aFldn)

    #if O.nFld != 0 and O.nFld != nFldFound:
     #   print("Warning: unexpected number of fields in DscxArgs")

    S = "" 

    # ----- Extraction/Saving -----
    if O.saveRRE > 0: S += " --saveRRE"
    if O.saveCVP > 0: S += " --saveCVP"
    if O.saveKol > 0: S += " --saveKol"
    if O.saveTxm > 0: S += " --saveTxm"
    if O.saveProp > 0: S += " --saveProp"
    if O.saveCuvKpt > 0: S += " --saveCuvKpt"
    if O.saveRegUnv > 0: S += " --saveRuv"
    if O.saveBonSpc > 0:    S += " --saveBsp"
    if O.saveBonBoxRaw > 0: S += " --saveBonBboxRaw"
    if O.saveBonMore > 0:   S += " --saveBonMore"

    # ----- Archit -----
    if O.nLev > -1:
        assert 0 < O.nLev < 10, "nLev must be between 1 and 9"
        S += f" --nLev {O.nLev}"

    if O.depth > -1:
        assert 0 < O.depth < 5, "depth must be between 1 and 4"
        S += f" --depth {O.depth}"

    if O.imgSpc > -1:
        assert 0 < O.imgSpc < 3, "imgSpc must be 1 or 2"
        S += f" --is {O.imgSpc}"

    if O.imgFlt > -1:
        assert 0 <= O.imgFlt < 4, "imgFlt must be 0–3"
        S += f" --if {O.imgFlt}"

    # ----- Other -----
    S += f" {O.optS.strip()}"

    return S.strip()    


    
""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennDscx   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for dscx. By default assumes that routine is run from
directory 'DescExtr', or add it by 4th argument.

cf exsbDscxFull.py, exsbDbin.py

IN    fipaImg image filepath
      fipaOut output filepath
      Args    arguments
OUT   Res     results, incl. standard output/error

"""
def RennDscx( fipaImg, fipaOut, Args, fpExe ):

    cmnd = [ str(fpExe), str(fipaImg), str(fipaOut) ]

    if Args.opt:
        if isinstance(Args.opt, str):
            cmnd += shlex.split(Args.opt)
        else:
            cmnd += list(Args.opt)

    # ----------   Execute   ----------
    Res = subprocess.run( cmnd, capture_output=True, text=True )
#    Res = subprocess.run( cmnd, capture_output=True, text=True ,
#                          encoding="utf-8", errors="replace")

    # --------------------   Verify Proper Termination   --------------------
    if Res.returncode != 0 or 'EndOfProgram' not in Res.stdout:
        
        print('Program dscx was not executed properly.')
        print('Command:', shlex.join(cmnd))
        print('Return code:', Res.returncode)
        print(Res.stdout)
        print(Res.stderr)
        
        print( 'Debugging...' )
        cmnd2     = cmnd + ['--bDISP', '3']

        Res2 = subprocess.run( cmnd2, capture_output=True, text=True )

        print( Res2.stdout )
        
        input('Pausing')

    return Res.stdout



