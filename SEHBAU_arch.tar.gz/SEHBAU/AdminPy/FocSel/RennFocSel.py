"""

Wrapper functions for programs fochst1, focdsc1, ...


------------------------------   CLS SUM   ------------------------------
class focSelSiz

------------------------------   DEF SUM   ------------------------------
def RennFocHst1( fipaDsc, Bbx, fipaOut, Args, pthProg ):
def RennFocDsc1( fipaDsc, Bbx, fipaOut, Args, pthProg ):

"""
import subprocess, re, platform
from dataclasses import dataclass
from pathlib import Path
import shlex



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass(slots=True)                      
class focSelSiz:                # ''''''''''''''''''''   focSelSiz   ''''''''''''''''''''
    """
    The two variables obtain from the (standard) output of fochst1 or focdsc1
    """
    nLev:  int | None = None
    ntDsc: int | None = None



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------
    
""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennFocHst1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for fochst1.

IN    fipaDsc image filepath
      Bbx     one bounding box (TBLR)
      fipaOut output filepath
      Args    arguments
      pthProg path of program
OUT   Out     standard output

"""
def RennFocHst1( fipaDsc, Bbx, fipaOut, Args, fpExe ):

    # ----------   Arguments   ----------
    if isinstance(Args.opt, str):
        opt = shlex.split(Args.opt)
    else:
        opt = list(Args.opt)

    cmnd = [ str(fpExe), str(fipaDsc), *[str(x) for x in Bbx], str(fipaOut), *opt ]

    #print("Command:", shlex.join(cmnd))
    
    Res = subprocess.run( cmnd, capture_output=True, text=True )
    
    # ------  Verify Proper Termination  -----
    if Res.returncode != 0 or 'EndOfProgram' not in Res.stdout:

        print('Program fochst1 was not executed properly:' )
        print('Command:', shlex.join(cmnd))
        print('Return code:', Res.returncode)
        print( Res.stdout )
        print( Res.stderr )
        raise RuntimeError('fochst1 execution failed')

    # -----   Analyse StdOut  -----
    Sz   = focSelSiz()

    # find 'nLevFoc' and get the number right after it
    lev  = re.search(r"nLevFoc (\d+)", Res.stdout )
    
    if lev:
        Sz.nLev = int(lev.group(1))

    # find 'ntDsc' and get the number right after it
    ntDsc = re.search(r"ntDsc (\d+)", Res.stdout )
    if ntDsc:
        Sz.ntDsc = int( ntDsc.group(1) )
    
    return Sz, Res.stdout



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennFocDsc1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for focdsc1. Same as above but different binary name.

cf exsbObjIdf.py

"""
def RennFocDsc1( fipaDsc, Bbx, fipaOut, Args, fpExe ):

    # ----------   Arguments   ----------
    if isinstance(Args.opt, str):
        opt = shlex.split(Args.opt)
    else:
        opt = list(Args.opt)

    cmnd = [ str(fpExe), str(fipaDsc), *[str(x) for x in Bbx], str(fipaOut), *opt ]

    #print("Command:", shlex.join(cmnd))

    Res = subprocess.run( cmnd, capture_output=True, text=True )
    
    # ------  Verify Proper Termination  -----
    if Res.returncode != 0 or 'EndOfProgram' not in Res.stdout:

        print('Program focdsc1 was not executed properly:' )
        print('Command:', shlex.join(cmnd))
        print('Return code:', Res.returncode)
        print( Res.stdout )
        print( Res.stderr )
        raise RuntimeError('focdsc1 execution failed')

    # -----   Analyse StdOut  -----
    Sz   = focSelSiz()

    # find 'nLevFoc' and get the number right after it
    lev  = re.search(r"nLevFoc (\d+)", Res.stdout )
    if lev:
        Sz.nLev = int(lev.group(1))

    # find 'ntDsc' and get the number right after it
    ntDsc = re.search(r"ntDsc (\d+)", Res.stdout )
    if ntDsc:
        Sz.ntDsc = int( ntDsc.group(1) )
    
    return Sz, Res.stdout

