"""

Loads descriptor nearest-neibors, as outputted by mvec1.exe

------------------------------   CLS SUM   ------------------------------
class finasNNDspc:

class descNNs:
class descNNDspc:

------------------------------   DEF SUM   ------------------------------
def ReadDescNNs(fid) -> descNNs:
def LoadNNDspace(lfn: str) -> tuple[list[descNNs], np.ndarray, int]:

this is wrapper loading all:
def LoadNNDspaces( pth: Path=''  ) -> descNNDspc:

"""

from dataclasses import dataclass, field
import numpy as np
from pathlib import Path



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass(slots=True)
class finasNNDspc:
    """
    Holds the filenames for the measurement files, like so:
    Cnt: str = 'Mes/NNspcCnt12'
    Frm: str = 'Mes/NNspcFrm12'
    Arc: str = 'Mes/NNspcArcGst12'
    Str: str = 'Mes/NNspcStrGst12'
    Shp: str = 'Mes/NNspcShp12'
    """
    idf: str = "12"

    Cnt: str = field(init=False)
    Frm: str = field(init=False)
    Arc: str = field(init=False)
    Str: str = field(init=False)
    Shp: str = field(init=False)

    def __post_init__(self):
        self.Cnt = f"Mes/NNspcCnt{self.idf}"
        self.Frm = f"Mes/NNspcFrm{self.idf}"
        self.Arc = f"Mes/NNspcArcGst{self.idf}"
        self.Str = f"Mes/NNspcStrGst{self.idf}"
        self.Shp = f"Mes/NNspcShp{self.idf}"
        
    
@dataclass(slots=True)
class descNNs:
    """
    Nearest neighbors
    """
    Ix:     np.ndarray # indices
    Mes:    np.ndarray # measurements (similarity, dissimilarity)
    nDsc:   int        # num of descriptors
    menMes: float      # mean measurement


@dataclass
class descNNDspc:
    """
    A universe of NN indices.
    """
    ACNT: list[descNNs]
    Ncnt: np.ndarray

    AFRM: list[descNNs]
    Nfrm: np.ndarray

    AARC: list[descNNs]
    Narc: np.ndarray

    ASTR: list[descNNs]
    Nstr: np.ndarray

    ASHP: list[descNNs]
    Nshp: np.ndarray

    nLev: int


    
# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------
    
""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescNNs   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR


cfro below (LoadDescNNs)
"""
def ReadDescNNs(fid) -> descNNs:

    nDsc = int(np.fromfile(fid, dtype=np.int32, count=1)[0])

    print(f'{nDsc:4d}', end=' ')

    Ix  = np.fromfile(fid, dtype=np.int32, count=nDsc)
    Mes = np.fromfile(fid, dtype=np.float32, count=nDsc)

    return descNNs(
        Ix     = Ix,
        Mes    = Mes,
        nDsc   = nDsc,
        menMes = float(np.mean(Mes))
    )



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadNNDspace   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads a space of NN indices and their measurement values,
as saved under s_DescNNsSpc in DescNNio.h.

"""
def LoadNNDspace(lfn: str) -> tuple[list[descNNs], np.ndarray, int]:

    try:
        with open(lfn, 'rb') as fid:

            # Number of pyramid levels (uint8)
            nLev = int(np.fromfile(fid, dtype=np.uint8, count=1)[0])

            #print(f'nLev {nLev}:  ', end='')

            ALev = []
            Ndsc = np.ones(nLev, dtype=np.int32)

            for l in range(nLev):

                NN = ReadDescNNs(fid)

                ALev.append(NN)
                Ndsc[l] = NN.nDsc

            #print()

    except OSError as e:
        raise OSError(f'Could not open file {lfn}') from e

    return ALev, Ndsc, nLev



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadNNDspaces   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the measured NN spaces. Assumes we are in directory MtchVec

"""
def LoadNNDspaces( pth: Path='', idf: str=None  ) -> descNNDspc:

    F = finasNNDspc( idf )

    ANNCnt, Ncnt, nLev = LoadNNDspace( pth / Path(F.Cnt) )
    ANNFrm, Nfrm, nLev = LoadNNDspace( pth / Path(F.Frm) )
    ANNArc, Narc, nLev = LoadNNDspace( pth / Path(F.Arc) )
    ANNStr, Nstr, nLev = LoadNNDspace( pth / Path(F.Str) )
    #ANNShp, Nshp, nLev = LoadNNDspace( pth / Path(F.Shp) )
    ANNShp, Nshp  = None, None

    return descNNDspc(
        ACNT = ANNCnt, Ncnt = Ncnt,
        AFRM = ANNFrm, Nfrm = Nfrm,
        AARC = ANNArc, Narc = Narc,
        ASTR = ANNStr, Nstr = Nstr,
        ASHP = ANNShp, Nshp = Nshp,
        nLev = nLev
    )

