"""Matching analysis of nearest-neighbor descriptors.

Takes mean of estimated NN locations. Nothing more.

cfro exsbMatchImg.py

------------------------------   CLS SUM   ------------------------------
class nndAlyLev:
class nndAlyArr:
class nndAlyDUV:
class nndTolDuv:

------------------------------   DEF SUM   ------------------------------
def f_NNclust( NN, Pos, tolMes ) -> nndAlyLev:
def f_NNclustSpc( ANN, ADSC, nLev, tolMes ) -> nndAlyArr:
def f_NNAlyDUV( NNS, DUV, nLev, TolMes, jStr: str=None ):

"""
import subprocess
import platform

from dataclasses import dataclass, field

import numpy as np

from typing import IO, Type

from AdminPy.DescExtr.DescFile.PosAnf import *

bDISPMtchAlys = 0

# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------

@dataclass
class nndAlyLev:
    """
    NN analysis for one level.

    returned by f_NNclust
    """
    vrt:   float = -1
    hor:   float = -1
    pHit:  float = -1
    cVld:  int   = -1


@dataclass
class nndAlyArr:
    """
    NN analysis across multiple levels.
    """
    Vrt:  np.ndarray = field(init=False)
    Hor:  np.ndarray = field(init=False)
    Phit: np.ndarray = field(init=False)
    Cvld: np.ndarray = field(init=False)

    menVrt  = float
    menHor  = float
    menPhit = float
    

    def __init__(self, nLev: int):
        self.Vrt  = np.full(nLev, -1.0, dtype=np.float32)
        self.Hor  = np.full(nLev, -1.0, dtype=np.float32)
        self.Phit = np.full(nLev, -1.0, dtype=np.float32)
        self.Cvld = np.full(nLev, -1, dtype=np.int32)

    def append(self, Oth):
        self.Vrt  = np.concatenate((self.Vrt,  Oth.Vrt))
        self.Hor  = np.concatenate((self.Hor,  Oth.Hor))
        self.Phit = np.concatenate((self.Phit, Oth.Phit))
        self.Cvld = np.concatenate((self.Cvld, Oth.Cvld))    
    

@dataclass
class nndAlyDUV:

    Cnt  : object = None
    Frm  : object = None
    Arc  : object = None
    Str  : object = None


@dataclass
class nndTolDuv:

    cnt  = 0.5
    frm  = 0.5
    arc  = 0.5
    stg  = 0.5
    
    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_NNclust   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Clustering NN hits.

cf exsbMatchSml.py

"""
def f_NNclust( NN, Pos, tolMes ) -> nndAlyLev:

    sVrt=0.0; sHor=0.0; cVld=0; cNoNN=0
    for i in range(NN.nDsc):

        # Skip loose matches
        if NN.Mes[i] > tolMes:
            continue

        ix = NN.Ix[i]

        if ix == 0:
            cNoNN += 1
            continue

        cVld += 1
        sVrt += Pos.Vrt[ix]
        sHor += Pos.Hor[ix]

    if cVld:
        menVrt = sVrt / cVld
        menHor = sHor / cVld
        pHit   = cVld / NN.nDsc
    else:
        menVrt = np.nan;  menHor = np.nan;  pHit=np.nan

    if bDISPMtchAlys>2:
        print( f'menVrt/Hor:    {menVrt:1.4f} {menHor:1.4f}    cVld {cVld:3d} ({pHit:1.4f})' )

    return nndAlyLev( menVrt, menHor, pHit, cVld )
    



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_NNclustSpc   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Clustering NN hits.

cf exsbMatchSml.py

"""
def f_NNclustSpc( ANN, ADSC, nLev, tolMes, jStr ) -> nndAlyArr:
    
    if bDISPMtchAlys: print( jStr )

    LocEst = nndAlyArr( nLev )

    for l in range(nLev):

        tolMesLev   = ANN[l].menMes * tolMes

        NNaly = f_NNclust( ANN[l], ADSC[l].Pos, tolMesLev )

        #print( f'menVrt/Hor:    {menVrt:1.4f} {menHor:1.4f}    cVld {cVld:3d} ({pHit:1.4f})' )

        LocEst.Vrt[l]  = NNaly.vrt
        LocEst.Hor[l]  = NNaly.hor
        LocEst.Phit[l] = NNaly.pHit
        LocEst.Cvld[l] = NNaly.cVld

    LocEst.menVrt  = np.nanmean( LocEst.Vrt )
    LocEst.menHor  = np.nanmean( LocEst.Hor )
    LocEst.menPhit = np.nanmean( LocEst.Phit )

    if bDISPMtchAlys>1:
        print( f'menVrt/Hor:    {LocEst.menVrt:1.4f} {LocEst.menHor:1.4f}', end='')
        print( f'    menPhit:  {LocEst.menPhit:1.4f}' )
        
    return LocEst



""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_NNAlyDUV   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
"""
def f_NNAlyDUV( NNS, DUV, nLev, TolMes, jStr: str=None ):

    if jStr and bDISPMtchAlys:
        print(jStr)
    
    LOC      = nndAlyDUV()
    LOC.Cnt  = f_NNclustSpc( NNS.ACNT, DUV.ACNT, nLev, TolMes.cnt, 'Cnt' ) 
    LOC.Frm  = f_NNclustSpc( NNS.AFRM, DUV.AFRM, nLev, TolMes.frm, 'Frm' ) 
    LOC.Arc  = f_NNclustSpc( NNS.AARC, DUV.AARC, nLev, TolMes.arc, 'Arc' ) 
    LOC.Str  = f_NNclustSpc( NNS.ASTR, DUV.ASTR, nLev, TolMes.stg, 'Str' ) 

    LocEst   = nndAlyArr(0)
    LocEst.append( LOC.Cnt )
    LocEst.append( LOC.Frm )
    LocEst.append( LOC.Arc )
    LocEst.append( LOC.Str )

    menVrt = (LOC.Cnt.menVrt + LOC.Frm.menVrt + LOC.Arc.menVrt + LOC.Str.menVrt)/4
    menHor = (LOC.Cnt.menHor + LOC.Frm.menHor + LOC.Arc.menHor + LOC.Str.menHor)/4

    if bDISPMtchAlys:
        print( f'menVrt/Hor:    {menVrt:1.4f} {menHor:1.4f}  _____')

    locT = posSvl( menVrt, menHor )
    
    return locT, LOC


