"""

------------------------------   CLS SUM   ------------------------------
------------------------------   DEF SUM   ------------------------------
def PlotMotVec( Vec, bRadial, ax ):

"""

import copy
import matplotlib.pyplot as plt
import numpy as np

#from AdminPy.DescExtr.DescFile.PosAnf import *
#from AdminPy.DescExtr.Features.Segments.BonUtil import f_BonPixShift

#from AdminPy.DescExtr.Plot.PlotDescriptors import *
#from AdminPy.DescExtr.Plot.PlotDescBound import *
#from AdminPy.DescExtr.Plot.PlotFeatures import *



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotMotVec   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots the motion vectors.

IN    V        struct with vectors
      bRadial  radial option. Will subtract starting point
"""
def PlotMotVec( Vec, bRadial, ax ):


    colLine = (0.7, 0.7, 0.7)  # gray color

    Rw1, Cl1 = Vec.Ep1[:, 0], Vec.Ep1[:, 1]
    Rw2, Cl2 = Vec.Ep2[:, 0], Vec.Ep2[:, 1]

    if bRadial:
        # subtract starting point (radial mode)
        Rw2 = Rw2 - Rw1
        Cl2 = Cl2 - Cl1

    for m in range(Vec.nMot):
        
        #dir_ = Vec.aDir[m]
        #mag  = Vec.Mag[m]

        if bRadial:
            ax.plot( [0, Cl2[m]], [0, Rw2[m]], color=colLine)
        else:
            ax.plot( [Cl1[m], Cl2[m]], [Rw1[m], Rw2[m]], color=colLine)
            # starting point marker
            ax.plot( Cl1[m], Rw1[m], "r.", markersize=3)

    
