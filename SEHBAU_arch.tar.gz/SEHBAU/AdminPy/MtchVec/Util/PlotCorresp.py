"""

Utilities for plotting correspondence.

See:
PlotCorrespSbS.py    side-by-side plotting: two plots
PlotCorrespFlw.py    plotting into one plot, quasi as flow

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def p_DescCorrespLine(A, B, NN):

"""

import copy
from copy import deepcopy
import matplotlib.pyplot as plt
import numpy as np

from AdminPy.DescExtr.DescFile.PosAnf import *
from AdminPy.DescExtr.Features.Segments.BonUtil import f_BonPixShift

from AdminPy.DescExtr.Plot.PlotDescriptors import *
from AdminPy.DescExtr.Plot.PlotDescBound import *
from AdminPy.DescExtr.Plot.PlotFeatures import *

#from AdminPy.Util.DataStruct import u_MtrxToStcArrDict
from AdminPy.DescExtr.OrgAtt.OrgAtts import *
from AdminPy.MtchVec.FileRead.LoadDescNN import descNNs



# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   p_DescCorrespLine   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

Plots correspondence lines between positions in A and their nearest neighbors in B,
given indices in NN. No shifting of coordinates (for the purpose of side-by-side
plotting) taking place here.

cfro PlotCorrespSbs.py, ...

IN    A      positions with Vrt and Hor arrays
      B      positions, may include shift for side-by-side plotting. User must control that.
      NN     DescNNs (Ix, Mes, nDsc, menMes)
"""
def p_DescCorrespLine( A, B, NN: descNNs ):

    bReportZeroIx = 1
    cNoNN = 0

    for i in range(NN.nDsc):

        # Skip loose matches
        if NN.Mes[i] > NN.menMes * 0.8:
            continue

        v1 = A.Vrt[i]
        h1 = A.Hor[i]

        ix = NN.Ix[i]

        if ix == 0:
            cNoNN += 1
            continue

        v2 = B.Vrt[ix]
        h2 = B.Hor[ix]

        # Correspondence line
        hl = plt.plot( [h1, h2], [v1, v2],
            color=0.7 + np.random.rand(3) * 0.2,
            linestyle='--'
        )

    if bReportZeroIx > 0 and cNoNN > 0:
        print(
            f'cNoNN {cNoNN:3d}/{NN.nDsc:3d} '
            f'[{cNoNN / NN.nDsc:1.3f}]'
        )




