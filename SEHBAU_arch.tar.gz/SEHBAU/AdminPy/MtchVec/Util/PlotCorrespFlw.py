"""

Plotting correspondence into one plot, quasi as flow ('Flw').

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def PlotCorrespCntFlw( ACNT1, ACNT2, nLev, ANN, szI, figNo, shift: str=None ):
def PlotCorrespFrmFlw( AFRM1, AFRM2, nLev, ANN, SzM, figNo, ABON1, ABON2 ):

"""
import copy
from copy import deepcopy
import matplotlib.pyplot as plt
import numpy as np

from AdminPy.DescExtr.DescFile.PosAnf import *
from AdminPy.DescExtr.Features.Segments.BonUtil import f_BonPixShift

from AdminPy.DescExtr.Plot.PlotDescriptors import *
from AdminPy.DescExtr.Plot.PlotDescBound import *
from AdminPy.DescExtr.Plot.PlotFeatures import *

from AdminPy.Util.DataStruct import u_MtrxToStcArrDict
from AdminPy.DescExtr.OrgAtt.OrgAtts import *

from .PlotCorresp import *


# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotCorrespCntFlw   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

All in unit coordinates.

"""
def PlotCorrespCntFlw( ACNT1, ACNT2, nLev, ANN, szI, figNo ):

    fig, AXES = plt.subplots( nLev, 1, num=figNo, figsize=(8, 3 * nLev),
                              clear=True, squeeze=False )

    # All in unit coordinates.
    # We invert y-axis: once for plotting descriptors and once for
    # correspondence using utility routine u_PosVHinvertToIJ.
    for lv in range(nLev):

        ax = AXES[lv, 0]
        plt.sca(ax)

        p_CntFromAtts( ACNT1[lv] )              # PlotDescriptors.py
        plt.xlim(0, 1)
        plt.ylim(0, 1)

        PosA = ACNT1[lv].Pos
        PosB = ACNT2[lv].Pos

        PosA = u_PosVHinvertToIJ(PosA)
        PosB = u_PosVHinvertToIJ(PosB)

        p_DescCorrespLine( PosA, PosB, ANN[lv] )

        #ax.invert_yaxis()

    plt.tight_layout()
    plt.show(block=False)



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotCorrespFrmFlw   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

In pixel coordinates; no inversion of y-axis. 
We indicate correspondence with position info. Could also be done with
descriptor points.

"""
def PlotCorrespFrmFlw( AFRM1, AFRM2, nLev, ANN, SzM, figNo, ABON1, ABON2 ):

    fig, AXES = plt.subplots( nLev, 1, num=figNo, clear=True, figsize=(10, 12) )

    fig.subplots_adjust(hspace=0.01)

    for lv in range(nLev):

        ax = AXES[lv]
        plt.sca(ax)

        DA    = deepcopy( AFRM1[lv] )
        DB    = deepcopy( AFRM2[lv] )

        PosA  = deepcopy(DA.Pos)
        PosB  = deepcopy(DB.Pos)

        #print(DA.Pos.Vrt[0:10])
        
        szM   = SzM[lv,:]

        # Convert RdSig matrices to structured arrays
        # once would be sufficient, but since we pass struct we must leave it here
        DA.RdSig = u_MtrxToStcArrDict( DA.RdSig, aLbFormRdSigGeo )
        DB.RdSig = u_MtrxToStcArrDict( DB.RdSig, aLbFormRdSigGeo )
    
        # Plot descriptors
        p_FormBoundPix( DA, ABON1[lv], 'nofet', ax)
        
        # scale position values (they are unit range)
        PosA  = u_PosVHscaleup( PosA, szM, 0 )
        p_PosVH( PosA, 'k' )

        PosB  = u_PosVHscaleup( PosB, szM, 0 )
        
        #print(PosA.Vrt[0:10])    
        
        # Plot correspondence lines
        p_DescCorrespLine( PosA, PosB, ANN[lv] )
        
        # Image coordinates: y-axis points downwards
        ax.set_ylim( szM[0], 0)

    plt.tight_layout()
    plt.show(block=False)
    
