"""

Plotting correspondence side by side.

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def PlotCorrespCntSbS( ACNT1, ACNT2, nLev, ANN, szI, figNo ):
def PlotCorrespFrmSbS( AFRM1, AFRM2, nLev, ANN, SzM, figNo, ABON1, ABON2, shift: str=None ):

"""
import copy
from copy import deepcopy
import matplotlib.pyplot as plt
import numpy as np

from AdminPy.DescExtr.DescFile.PosAnf import *
from AdminPy.DescExtr.Features.Segments.BonUtil import f_BonPixShift

from AdminPy.DescExtr.Plot.PlotDescriptors import *
from AdminPy.DescExtr.Plot.PlotDescBound import *
from AdminPy.DescExtr.Plot.PlotFeatures import *

from AdminPy.Util.DataStruct import u_MtrxToStcArrDict
from AdminPy.DescExtr.OrgAtt.OrgAtts import *

from .PlotCorresp import *


# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotCorrespCntSbS   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

All in unit coordinates.

"""
def PlotCorrespCntSbS( ACNT1, ACNT2, nLev, ANN, szI, figNo ):

    fig, AXES = plt.subplots( nLev, 1, num=figNo, figsize=(8, 3 * nLev),
                              clear=True, squeeze=False )

    # All in unit coordinates.
    # ??? We invert y-axis: once for plotting descriptors and once for
    # correspondence using utility routine u_PosVHinvertToIJ.
    for lv in range(nLev):

        ax = AXES[lv, 0]
        plt.sca(ax)

        #ax.invert_yaxis()

        p_DescPairSbS( 'cnt', ACNT1[lv], ACNT2[lv], szI )

        PosA = deepcopy( ACNT1[lv].Pos )
        PosB = deepcopy( ACNT2[lv].Pos )

        PosA = u_PosVHinvertToIJ(PosA)
        PosB = u_PosVHinvertToIJ(PosB)

        PosB.Hor += 1 # shift to right side

        p_DescCorrespLine( PosA, PosB, ANN[lv] )

        #ax.invert_yaxis()

    plt.tight_layout()
    plt.show(block=False)


""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   PlotCorrespFrmSbS   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP

In pixel coordinates, because we plot the boundary pixels for illustration.

No inversion of y-axis.

We indicate correspondence with position info. Could also be done with
descriptor points.

"""
def PlotCorrespFrmSbS( AFRM1, AFRM2, nLev, ANN, SzM, figNo, ABON1, ABON2, shift: str=None ):

    fig, AXES = plt.subplots( nLev, 1, num=figNo, clear=True, figsize=(10, 12) )

    fig.subplots_adjust(hspace=0.01)

    for lv in range(nLev):

        ax = AXES[lv]
        plt.sca(ax)

        DA    = deepcopy( AFRM1[lv] )
        DB    = deepcopy( AFRM2[lv] )

        PosA  = deepcopy(DA.Pos)
        PosB  = deepcopy(DB.Pos)

        #print(DA.Pos.Vrt[0:10])
        
        szM   = SzM[lv,:]

        # Convert RdSig matrices to structured arrays
        # once would be sufficient, but since we pass struct must leave it here
        DA.RdSig = u_MtrxToStcArrDict( DA.RdSig, aLbFormRdSigGeo )
        DB.RdSig = u_MtrxToStcArrDict( DB.RdSig, aLbFormRdSigGeo )
    
        # Plot descriptor correspondences
        aBon2 = p_DescPairSbS( 'form', DA, DB, szM, ABON1[lv], ABON2[lv], ax )
        
        # scale positions 
        PosA  = u_PosVHscaleup( PosA, szM, 0 )
        PosB  = u_PosVHscaleup( PosB, szM, 0 )
        
        #print(PosA.Vrt[0:10])    

        PosB = u_PosVHshift( PosB, 0, szM[1] )
        
        # Plot correspondence lines
        p_DescCorrespLine( PosA, PosB, ANN[lv] )
        
        # Image coordinates: y-axis points downwards
        ax.set_ylim( szM[0], 0)

    plt.tight_layout()
    plt.show(block=False)
    
    
