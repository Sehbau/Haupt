"""

------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def RennMvec1( fipaDsc1, fipaDsc2, Args, pthProg ):

"""
import subprocess
import platform
from pathlib import Path
import shlex


# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   RennMvec1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Administrative wrapper for mvec1.

cf exsbMatchSml.py

"""
def RennMvec1( fipaDsc1, fipaDsc2, Args, fpExe ):

    fipaDsc1  = str(fipaDsc1)                   # ensure it is string
    fipaDsc2  = str(fipaDsc2) 

    # ----------   Arguments   ----------
    if isinstance(Args.opt, str):
        opt = shlex.split(Args.opt)
    else:
        opt = list(Args.opt)

    # I think I could also feed Path
    cmndBase = [ str(fpExe), str(fipaDsc1), str(fipaDsc2) ]

    # append parameter and measurement file
    if Args.fpPrm:
        cmnd  = cmndBase + [Args.fpPrm, Args.fpMes, *opt]
    else: 
        cmnd  = cmndBase + [Args.fpMes, *opt]

    #print( cmnd )
    
    # -----  python 3.11
    Res = subprocess.run( cmnd, capture_output=True, text=True )
    
    # ------  Verify Proper Termination  -----
    ixEOP = Res.stdout.find('EndOfProgram')
    if ixEOP<0:
        print('Program mvec1 was not executed properly. Output below:' )
        print('Commmand was: ' + str(Res.args) )
        print( Res.stdout )
        print( Res.stderr )
        quit()

    return Res




