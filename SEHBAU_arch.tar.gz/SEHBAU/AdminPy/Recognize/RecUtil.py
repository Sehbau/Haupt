"""

Recognition utilities.

Elsewhere:
- bounding boxes in UtilImg.py


------------------------------   CLS SUM   ------------------------------

------------------------------   DEF SUM   ------------------------------
def f_MapLocMinima( Mp, Prm: prmSelSuppCyc=None ) -> pixRCv:
def f_MapLocMaxima( Mp, Prm: prmSelSuppCyc=None ) -> pixRCv:

def u_OutlFromLoctLay( rwLay, clLay, ixLay, rad: float, szVimg, szHimg ):
def u_OutlFromLoctFbrc( ASCR: fbrcScorMaps, BoxUrg, szImg, nLaySus ):

def u_IptchFromBoxLst( Irgb, Box4 ):

def g_PtchPredPerLay( figNo, Irgb, AIptcRep, AIPtch ):


"""
from dataclasses import dataclass

import numpy as np

import matplotlib.pyplot as plt

from AdminPy.DescExtr.Features.PixAnf import i_PixRCv, pixRCv
from AdminPy.MtchFbrc.MtchFbrcKrnl import *
from AdminPy.DescExtr.Texture.FabricAnf import *
#from AdminPy.DescExtr.Texture.FabricFoc import *
from AdminPy.Util.UtilImg import *



# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass(slots=True)
class prmSelSuppCyc:          # ''''''''''''''''''''   PrmSelSuppCyc   ''''''''''''''''''''
    """
    Parameters for selection suppression cycle
    """
    nSel: int = 5
    rad:  int = 2
    


# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_MapLocMinima   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Find nSel local minima using a selection-suppression cycle

IN   Mp     2D map of float values. Lower values are better.
     Prm    parameters
            - nLoc   Number of minima to select.
            - rd     suppression radius in pixels
OUT  Min    struct with minima. struct in PixAnf.h

"""
def f_MapLocMinima( Mp, Prm: prmSelSuppCyc=None ) -> pixRCv:

    if Mp is None: 
        return i_PixRCv( 0 )
        
    nR, nC = Mp.shape

    if Prm is None:
        Prm = prmSelSuppCyc()

    nSel   = Prm.nSel
    rad    = Prm.rad

    # Sort all pixels by increasing value
    Ord    = np.argsort( Mp.ravel() )

    # Suppression mask
    BWsupp = np.zeros((nR, nC), dtype=bool)

    Min  = i_PixRCv(nSel)
    c    = 0
    for ox in Ord:

        rw, cl = np.unravel_index(ox, Mp.shape)

        # --- already suppressed by a previously selected minimum?
        if BWsupp[rw, cl]:
            continue

        # --- Select this minimum
        Min.Rw[c] = rw
        Min.Cl[c] = cl
        Min.Vl[c] = Mp[rw, cl]

        c += 1
        if c == nSel:
            break
        
        # --- Suppress neighborhood
        r0 = max(0,  rw - rad)
        r1 = min(nR, rw + rad + 1)

        c0 = max(0,  cl - rad)
        c1 = min(nC, cl + rad + 1)

        BWsupp[r0:r1, c0:c1] = True
        
        
    return Min


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_MapLocMaxima   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Find nSel local maxima using a selection-suppression cycle

IN   Mp     2D map of float values. Lower values are better.
     Prm    parameters
            - nLoc   Number of maxima to select.
            - rd     suppression radius in pixels
OUT  Max    struct with maxima. struct in PixAnf.h

"""
def f_MapLocMaxima( Mp, Prm: prmSelSuppCyc=None ) -> pixRCv:

    if Mp is None: 
        return i_PixRCv( 0 )
        
    nR, nC = Mp.shape

    if Prm is None:
        Prm = prmSelSuppCyc()

    nSel   = Prm.nSel
    rad    = Prm.rad

    # Sort all pixels by increasing value
    Ord    = np.argsort( Mp.ravel() )[::-1]

    # Suppression mask
    BWsupp = np.zeros((nR, nC), dtype=bool)

    Max  = i_PixRCv(nSel)
    c    = 0
    for ox in Ord:

        rw, cl = np.unravel_index(ox, Mp.shape)

        # --- already suppressed by a previously selected maximum?
        if BWsupp[rw, cl]:
            continue

        # --- Select this maximum
        Max.Rw[c] = rw
        Max.Cl[c] = cl
        Max.Vl[c] = Mp[rw, cl]

        c += 1
        if c == nSel:
            break
        
        # --- Suppress neighborhood
        r0 = max(0,  rw - rad)
        r1 = min(nR, rw + rad + 1)

        c0 = max(0,  cl - rad)
        c1 = min(nC, cl + rad + 1)

        BWsupp[r0:r1, c0:c1] = True
        
        
    return Max


""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   f_MapLocMaximaLst   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Did not work because we allocated to NLAYS but kernels can be smaller, that is we
have to deal with None somehow.

Carries out f_MapLocMaxima for a list, typically a pyramid.

"""
def f_MapLocMaximaLst( AMaps: list )-> list:

    nMps  = len( AMaps )
    ALoct = [None] * nMps
    for l in range( nMps ):
        ALoct[l]  = f_MapLocMaxima( AMaps[l] ) # above
    
    return ALoct

    
""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_OutlFromLoctLay   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Creates a bounding box around center location 'rwLay, clLay' that originates from
layer 'ixLay'. Box dimensions are created with proportions 'dimPrp' for the image
size 'szImg'.

We compensate for shifts by adding margin as calculated in i_PrmFbrcFocScl

Idea: we have a predicted location by a kernel and we want to extract the focus.

IN   rwLay, clLay     coordinates in layer resolution
     ixLay
     dimPrp           tuple, vertical, horizontal E [0,1]
     szImg            tuple, vertical, horizontal, absolute in pixels

cfro exsbObjIdf.py
"""
def u_OutlFromLoctLay( rwLay, clLay, ixLay, dimPrp: float, szImg ):

    szVimg      = szImg[0]
    szHimg      = szImg[1]
    
    PrmScl      = i_PrmFbrcFocScl( szVimg, szHimg )

    sclLay      = PrmScl.Scl[ixLay]
    mrgLay      = PrmScl.Mrg[ixLay]

    # --- scale up location to image resolution and shift by margin
    rw          = rwLay / sclLay[0] + mrgLay[0]*2       
    cl          = clLay / sclLay[1] + mrgLay[1]*2       

    # --- now the bounding box dimensions
    radV        = dimPrp[0] / 2
    radH        = dimPrp[1] / 2
    top         = round( rw - szVimg*radV )  
    bot         = round( rw + szVimg*radV )
    lef         = round( cl - szHimg*radH )
    rit         = round( cl + szHimg*radH )

    # --- ensure the box is within image bounds
    if top<0:
        top = 0
    if bot > szVimg-1:
        bot = szVimg-1    
    if lef<0:
        lef = 0
    if rit > szHimg-1:
        rit = szHimg-1    
        
    Box         = np.array( [top, bot, lef, rit] )
    
    return Box



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_OutlFromLoctFbrc   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

List version of u_OutlFromLoctLay

cfro exsbObjIdfLst.py
"""
def u_OutlFromLoctFbrc( ALoct: list, BoxUrg: float, szImg: int ):

    nLaySus = len(ALoct)
    
    BBox    = np.empty( (nLaySus,4), np.int32 )
    for l in range( nLaySus ):

        Loct    = ALoct[l]
        ixLay   = nLaySus - 1 - l
        Box     = u_OutlFromLoctLay( Loct.Rw[0], Loct.Cl[0], ixLay, BoxUrg, szImg )

        BBox[l,:] = Box
    
    return BBox



""" UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU   u_IptchFromBoxLst   UUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

Extracts the patches for the list of (predicted) bounding boxes in Box4, typically
the 4 layers of the fabric.

cfro demo scripts

"""
def u_IptchFromBoxLst( Irgb, Box4 ):

    nBox, dim    = Box4.shape

    assert dim==4, f'dimensions not correct somehow:[ {nBox} x {dim} ]'

    AIptc = [None]*4
    for l in range(nBox):

        AIptc[l]  = u_IptchFromBbox( Irgb, Box4[l,:] ) # UtilImg.py
    
    return AIptc



""" PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP   g_PtchPredPerLay   PPPPPPPPPPPPPPPPPPPPPPPPPPPPPP
"""
def g_PtchPredPerLay( figNo, Irgb, AIptcRep, AIPtch ):

    hf = plt.figure(figNo )
    hf.clf()

    nKrnl = len( AIptcRep )
    
    nr, nc = 6, 4

    ax = hf.add_subplot(nr, nc, 1)
    ax.imshow(Irgb)
    ax.tick_params(labelsize=5)

    for k in range(nKrnl):
    
        ax = hf.add_subplot(nr, nc, (k+1)*nc+1)
        ax.imshow( AIptcRep[k] )
        if k==0: ax.set_title('Sel')
        plt.show(block=False)

        ax = hf.add_subplot(nr, nc, (k+1)*nc+2)
        ax.imshow( AIPtch[k][0] )
        if k==0: ax.set_title('Coarsest')
        plt.show(block=False)

        nLaySus = len(AIPtch[k]) # AFKrnl[k].Dim.nLay
        if nLaySus>1:
            ax = hf.add_subplot(nr, nc, (k+1)*nc+3)
            ax.imshow( AIPtch[k][1] )
            if k==0: ax.set_title('Coarse')
            plt.show(block=False)
            
        if nLaySus>2:
            ax = hf.add_subplot(nr, nc, (k+1)*nc+4)
            ax.imshow( AIPtch[k][2] )
            if k==0: ax.set_title('Fine')
            plt.show(block=False)





