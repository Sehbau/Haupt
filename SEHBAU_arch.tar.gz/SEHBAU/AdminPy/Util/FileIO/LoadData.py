"""

Load data files: arrays as text or binary from measurements, sortings, vectors,
matrices, etc.

------------------------------   CLS SUM   ------------------------------
class fhedBankVec:

------------------------------   DEF SUM   ------------------------------
def LoadTextLinewise( lfn ):

def LoadArrIntTxt( lfn ):
def LoadArrFltTxtPur( lfn, nFlt ):

def LoadFltTxtEof(lfn):
def LoadSortFltTxt( lfn: str, nFlt: int ):
def LoadArrFltHed(sfp):

def LoadMtrxFlt(lfp):
def LoadBankVec( pthFile, bDisp: int=0 ):

"""
import os
import struct
import numpy as np
from dataclasses import dataclass
from pathlib import Path


# --------------------------------------------------------------------------------
#                                 D A T A   C L A S S E S 
# --------------------------------------------------------------------------------
@dataclass
class fhedBankVec:              # ''''''''''''''''''''   fhedBankVec   ''''''''''''''''''''
    """
    Header for a bank of vectors
    """
    idf:     int
    szHed:   int
    nGrp:    int
    nDimGrp: int
    vers:    float
    nVec:    int = None
    nDim:    int = None

    

# --------------------------------------------------------------------------------
#
#                                 D E F I N I T I O N S
#
# --------------------------------------------------------------------------------

""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadTextLinewise   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads a text file line by line.

cf LoadDescVect() in LoadDescription.py

"""
def LoadTextLinewise( lfn ):

    if lfn==None:
        print('LoadTextLinewise: no filename provided')
        return None, 0
    
    try:
        with open(lfn, 'r') as file:
            
            aLines = file.readlines()
            
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not open file {lfn}")

    # Strip newline characters
    aLines = [line.rstrip('\n') for line in aLines]
    cLin   = len(aLines)

    return aLines, cLin


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadArrIntTxt   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Reads an array of integers whose length is specified as header.

"""
def LoadArrIntTxt( lfn ):

    # --- load all at once to a flat NumPy array
    Arr = np.fromfile( lfn, dtype=int, sep=' ')
    
    # --- segregate header / data
    lenE  = Arr[0]
    Arr   = Arr[1:]
    
    # --- verify length
    assert len(Arr) == lenE, \
        f"File corrupted: Expected {lenE} items, but read {len(Arr)}."
        
    return Arr


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadArrFltTxtPur   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Reads an array of floats from a text file, whereby the number of floats is specified
as argument.

"""
def LoadArrFltTxtPur( lfn, nFlt ):

    try:
        with open(lfn, 'r') as f:

            Vals = f.read().split()
            if len(Vals) < nFlt:
                raise ValueError(f"Expected at least {nFlt} floats, found {len(Vals)}")
            return np.array(Vals[:nFlt], dtype=np.float32)
        
    except FileNotFoundError:
        
        raise FileNotFoundError(f"File {lfn} not found")


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadFltTxtEof   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads an array of floats from a text file, until end-of-file, ie. as saved as in
st_ArrPurF.

"""
def LoadFltTxtEof(lfn):

    lfn = Path(lfn)

    if not lfn.exists():
        raise RuntimeError(f"file {lfn} not found")

    with lfn.open('r') as f:
        A = np.fromstring(f.read(), sep=' ', dtype=np.float32)

    nRed = A.size

    return A, nRed


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadSortFltTxt   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads a sorting saved as order/value in two columns, ie. from st_SortFlt().

"""
def LoadSortFltTxt( lfn: str, nFlt: int ):

    try:
        Dat = np.loadtxt(lfn, dtype={"names": ("idx", "val"),
                                     "formats": ("i4", "f4")})
    except OSError:
        raise FileNotFoundError(f"File {lfn} not found")

    if len(Dat) != nFlt:
        raise ValueError(f"Expected {nFlt} rows, got {len(Dat)}")

    Ord = Dat["idx"] 
    Vls = Dat["val"].astype(float)

    return Ord, Vls


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadArrFltHed   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads an array of floats as save with wb_ArrFltHed in FileIO.h

"""
def LoadArrFltHed(lfp):

    with open(lfp, 'rb') as fp:

        # ---------- Header ----------
        nVls = np.fromfile(fp, dtype=np.int32, count=1)

        if len(nVls) != 1:
            raise ValueError(f"LoadArrFltHed: invalid header in {lfp}")

        nVls = int(nVls[0])

        if nVls < 0:
            raise ValueError(f"LoadArrFltHed: invalid array length {nVls}")

        # ---------- Data ----------
        Arr = np.fromfile(fp, dtype=np.float32, count=nVls)

        if len(Arr) != nVls:
            raise ValueError(
                f"LoadArrFltHed: expected {nVls} floats, "
                f"read {len(Arr)}"
            )

    return Arr


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadMtrxFlt   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads a matrix of floats

"""
def LoadMtrxFlt(lfp):

    with open(lfp, 'rb') as fp:

        # ---------- Header ----------
        nRw = np.fromfile(fp, dtype=np.int32, count=1)
        nCl = np.fromfile(fp, dtype=np.int32, count=1)

        if len(nRw) != 1 or len(nCl) != 1:
            raise ValueError(f"LoadMtrxFlt: invalid header in {lfp}")

        nRw = int(nRw[0])
        nCl = int(nCl[0])

        if nRw <= 0 or nCl <= 0:
            raise ValueError(
                f"LoadMtrxFlt: invalid dimensions {nRw} x {nCl}"
            )

        # ---------- Data ----------
        Mtrx = np.fromfile(fp, dtype=np.float32, count=nRw*nCl)

        if len(Mtrx) != nRw*nCl:
            raise ValueError(
                f"LoadMtrxFlt: expected {nRw*nCl} floats, "
                f"read {len(Mtrx)}"
            )

        Mtrx = Mtrx.reshape((nRw, nCl))

    return Mtrx


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadBankVec   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads a bank of vectors (or any matrix of floats)

"""
def LoadBankVec( pthFile, bDisp: int=0 ):

    pthFile = Path(pthFile)

    if not pthFile.exists():
        raise RuntimeError(f"could not open {pthFile}")

    with pthFile.open('rb') as f:

        # ------- Header (Size) -------
        nRow = np.fromfile(f, dtype=np.int32, count=1)[0]
        nCol = np.fromfile(f, dtype=np.int32, count=1)[0]

        idf     = np.fromfile(f, dtype=np.int32, count=1)[0]
        szHed   = np.fromfile(f, dtype=np.int32, count=1)[0]
        nGrp    = np.fromfile(f, dtype=np.int32, count=1)[0]
        nDimGrp = np.fromfile(f, dtype=np.int32, count=1)[0]

        vers = np.fromfile(f, dtype=np.float32, count=1)[0]

        if bDisp:
            print(f"[{nRow:4d} {nCol:4d}]")

        # ------- Data -------
        ntVal = nRow * nCol

        MTX = np.fromfile(f, dtype=np.float32, count=ntVal)

    if MTX.size != ntVal:
        raise RuntimeError(
            f"read fewer values than expected: {MTX.size} < {ntVal}"
        )

    # ------- Reshape to Matrix -------
    # MATLAB:
    # MTX = reshape(MTX, nCol, nRow)';
    #
    # Equivalent in NumPy:
    MTX = MTX.reshape((nCol, nRow), order='F').T

    Hed = fhedBankVec(
        idf=idf,
        szHed=szHed,
        nGrp=nGrp,
        nDimGrp=nDimGrp,
        vers=vers,
        nVec=nRow,
        nDim=nCol
    )

    return MTX, Hed



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadMapFlt   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads a float map saved in the binary format s_MapFltX (MapIOx.h).

IN    lfn   filename
OUT   M     matrix with shape [szV, szH]
      szM   size map, tuple (szV, szH)
"""
def LoadMapFlt(lfn):

    if not os.path.isfile(lfn):
        raise FileNotFoundError(f"cannot find file {lfn}")

    with open(lfn, 'rb') as f:

        # -------- Header --------
        szV, szH = struct.unpack('ii', f.read(8))

        # -------- Data --------
        M = np.fromfile(f, dtype=np.float32, count=szV * szH)

    # -------- Bring Matrix to Shape --------
    # MATLAB: reshape(M, [szH szV]); permute(M, [2 1])
    M   = M.reshape((szV, szH)).copy()
    #M   = M.reshape((szH, szV)).T.copy()

    szM = (szV, szH)

    #DispLoad(lfn)

    return M, szM
