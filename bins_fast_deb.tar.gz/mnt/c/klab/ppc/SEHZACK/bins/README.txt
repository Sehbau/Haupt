This is a buffer for the unix compilations. Files here will be transfered archived to ../bins_fast_xxx
