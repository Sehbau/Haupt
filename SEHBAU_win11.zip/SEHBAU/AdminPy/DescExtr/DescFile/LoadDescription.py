"""

Reads descriptor attributes, once as fields LoadDescImag and once as vectors
LoadDescVect (if it was converted)

def LoadDescImag( lfp ):
def LoadDbinImag( lfp ):
def LoadDescVect( lfp ):
def LoadDescVectLev( lfp ):
def LoadDescPropAtts( lfn ):
def u_TtrgRtrv1( S, ix ):

"""

import sys, os
import numpy as np
from dataclasses import dataclass

import AdminPy.DescExtr.DescFile.Util.ReadDescHeaders as ReadHed
import AdminPy.DescExtr.DescFile.Atts.ReadCntAtt as CntRout
import AdminPy.DescExtr.DescFile.Atts.ReadRsgAtt as RsgRout
import AdminPy.DescExtr.DescFile.Atts.ReadArcAtt as ArcRout
import AdminPy.DescExtr.DescFile.Atts.ReadStrAtt as StrRout
import AdminPy.DescExtr.DescFile.Atts.ReadShpAtt as ShpRout
import AdminPy.DescExtr.DescFile.Atts.ReadTtrgAtt as TtgRout
import AdminPy.DescExtr.DescFile.Atts.ReadBndgAtt as BndRout
from   AdminPy.DescExtr.DescFile.Atts.ReadAttGen import * 

from AdminPy.DescExtr.DescType.ReadDescTyp import *
from AdminPy.DescExtr.Bbox.ReadFeatures import *
from AdminPy.DescExtr.OrgAtt.OrgAtts import *
from AdminPy.Util.UtilSscanf import *
from AdminPy.Util.FileIO.LoadData import *



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescImag   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads description (attributes) for one image. 

Analogous to LoadDescImag.m

"""
def LoadDescImag( lfp ):

    fileID   = open(lfp, 'rb')

    # --------------------   Header   --------------------
    Hed    = ReadHed.ReadDescFileHead( fileID, 10 )

    #print(Hed)

    # --------------------   DescSpaces   --------------------
    DSC = {};
    DSC['ACNT'], Ncnt   = CntRout.ReadCntSpc( fileID )
    DSC['ARSG'], Nrsg   = RsgRout.ReadRsgSpc( fileID )

    nLev, Narc          = ReadHed.ReadDescSpcHead( fileID )
    nLev, Nstr          = ReadHed.ReadDescSpcHead( fileID )
    
    DSC['AARC'], Narc   = ArcRout.ReadArcSpc( fileID )
    DSC['ASTR'], Nstr   = StrRout.ReadStrSpc( fileID )

    DSC['ASHP'], Nshp   = ShpRout.ReadShpSpc( fileID )

    idfBtw     = np.fromfile( fileID, dtype=np.int32, count=1)
    assert idfBtw==66666, f"LoadDescImag: in-btw idf not correct. is {idfBtw}"

    DSC['ATTRG'], Nttrg = TtgRout.ReadTtrgSpc( fileID )
    DSC['ABNDG'], Nbndg = BndRout.ReadBndgSpc( fileID )

    # --------------------   Labels   --------------------
    # only for some attributes of the shape descriptor
    nDsc, nAttShpCors = DSC['ASHP'][0].STR.shape
    nDsc, nAttShpFine = DSC['ASHP'][0].SFI.shape

    @dataclass
    class Labs:
        pass

    @dataclass
    class Shp:
        pass

    Labs.Shp     = Shp
    
    Labs.Shp.Sco = ReadAttLabels( fileID, nAttShpCors )
    Labs.Shp.Sfi = ReadAttLabels( fileID, nAttShpFine )

    DSC['Labs'] =  Labs
    
    # --------------------   Trailer Idf   --------------------
    idfEnd     = np.fromfile( fileID, dtype=np.int32, count=1)
    
    fileID.close()

    assert idfEnd==99999, f"LoadDescImag: end-btw idf not correct. is {idfEnd}"

    return DSC, Hed


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDbinImag   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads description (attributes) for one image. 

Analogous to LoadDbinImag.m

"""
def LoadDbinImag( lfp ):

    fileID   = open(lfp, 'rb')

    # --------------------   Header   --------------------
    Hed    = ReadHed.ReadDescFileHead( fileID, 55 )

    #print(Hed)

    # --------------------   DescSpaces   --------------------
    BIN = {};
    BIN['CNT']   = CntRout.ReadCntBinSpc( fileID )
    BIN['RSG']   = RsgRout.ReadRsgBinSpc( fileID )
    BIN['ARC']   = ArcRout.ReadArcBinSpc( fileID )
    BIN['STR']   = StrRout.ReadStrBinSpc( fileID ) 

    BIN['SHP']   = ShpRout.ReadShpBinSpc( fileID )
    BIN['TTRG']  = TtgRout.ReadTtrgBinSpc( fileID )

    # --------------------   Trailer Idf   --------------------
    idfEnd     = np.fromfile( fileID, dtype=np.int32, count=1 )
    
    fileID.close()

    assert idfEnd==888, f"LoadDbinImag: end idf not correct. is {idfEnd}"

    return BIN, Hed



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescVect   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads vector file [nDsc nAtt]

"""
def LoadDescVect( lfp ):

    # -------   Load Matrix   ---------
    try:
        with open(lfp, 'rt') as file:

            VEC = np.fromfile(file, sep=' ', dtype=np.float32)
            
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not find {lfp}")

    #print(f"Loaded: {lfp}")  # Equivalent to DispLoad(lfp)

    # -------   Obtain expected nAtt from Labels   --------
    base, ext = os.path.splitext(lfp)
    dty    = ext[4:]            # remove '.att', '.dsc', etc. => gets descriptor type
    Labs   = o_AttsLabels()     # obtains all labels
    AttLbs = getattr( Labs, dty ) 
    nAtt   = len(AttLbs)

    
    # -------   Reshape   --------
    nElm   = len(VEC)

    if nElm % nAtt > 0:

        print(f'{dty} not properly read. Perhaps NQAN present. Reading as text.')
        nDsc = -1
        VMX, nLin  = LoadTextLinewise( lfp )
        print(f'{nLin} lines read.')

    else:

        VMX    = VEC.reshape( (-1,nAtt))
        
        nDsc, nAtt = VMX.shape
        print(f"{dty} matrix is [{nDsc:4d} {nAtt:2d}].")
        #fprintf('%s matrix is [%4d %2d].\n', dty, nDsc, nAtt );

    return VMX, nDsc, AttLbs, nAtt



""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescVectLev   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads the array with level indices [nDsc 1]

"""
def LoadDescVectLev( lfp ):

    # -------   Load Matrix   ---------
    try:
        with open(lfp, 'rt') as file:

            Lev = np.fromfile(file, sep=' ', dtype=np.int32)
            
    except FileNotFoundError:
        raise FileNotFoundError(f"Could not find {lfp}")

    nDsc   = len(Lev)
    minLev = Lev.min()
    maxLev = Lev.max()

    if minLev < 0:
        raise ValueError("Level smaller than 0 not possible")
    if maxLev > 10:
        raise ValueError("Level larger than 10 not possible")

    return Lev, nDsc


""" LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL   LoadDescPropAtts   LLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

Loads proposals

cf exsbProposals.py
"""
def LoadDescPropAtts( lfn ):

    fileID   = open( lfn, 'rb')

    class DSC:
        pass

    DSC.Shp, nShp   = ShpRout.ReadShpAtt( fileID )
    DSC.Ttg, nTtg   = TtgRout.ReadTtrgAtt( fileID )
    
    # --------------------   Trailer   --------------------
    idf     = np.fromfile( fileID, dtype=np.int32, count=1)

    fileID.close()

    assert idf==78000, f"LoadDescPropAtts: trail idf not correct. is {idf}"


    return DSC

    

""" FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF   u_TtrgRtrv1   FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

Retrieves one tetragon from a list. See u_TtrgRtrv1.m for details.

"""
def u_TtrgRtrv1( S, ix ):

    class Axe:
        Rw = [S.Ax.Ep1[ix, 0], S.Ax.Ep2[ix, 0]]
        Cl = [S.Ax.Ep1[ix, 1], S.Ax.Ep2[ix, 1]]

    class Cor:
        Rw = [ S.Cop.Ep1[ix, 0], S.Cop.Ep2[ix, 0], S.Cop.Ep3[ix, 0], S.Cop.Ep4[ix, 0] ]
        Cl = [ S.Cop.Ep1[ix, 1], S.Cop.Ep2[ix, 1], S.Cop.Ep3[ix, 1], S.Cop.Ep4[ix, 1] ]

    class O:
        vrt     = S.Pos.Vrt[ix]
        hor     = S.Pos.Hor[ix]
        ori     = S.Ori[ix]
        oriAbs  = abs(ori)

        axV     = S.LAGE['AxVrt'][ix]  # vertical
        axH     = S.LAGE['AxHor'][ix]  # horizontal

        Rgb     = [S.RGB.Red[ix], S.RGB.Grn[ix], S.RGB.Blu[ix]]

        ixBon   = S.IxBon[ix] 

    return Axe, Cor, O


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadDescStats   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR


"""
def ReadDescStats( file ):

    @dataclass
    class S:
        pass
    
    S.MaxSizScl = ReadDescTypSpcF( file );
    S.MenSizScl = ReadDescTypSpcF( file );
    S.MaxSizAbs = ReadDescTypSpcF( file );

    S.Ndsc  	  = ReadDescTypSpcI( file );
    S.IxMx   	  = ReadDescTypSpcI( file );

    nLev = S.Ndsc.nLev
    
    S.CvgBon    = ReadFeatCoverage( file, nLev );
    S.CvgShp    = ReadFeatCoverage( file, nLev );

    # ----------   Smoothness   ----------
    @dataclass
    class Smo:
        pass

    Smo.ArcMen = np.zeros(nLev, dtype=np.float32)
    Smo.ArcMax = np.zeros(nLev, dtype=np.float32)
    Smo.StrMen = np.zeros(nLev, dtype=np.float32)
    Smo.StrMax = np.zeros(nLev, dtype=np.float32)
    
    for l in range(nLev):

        arc  = ReadAttDom(file)
        strt = ReadAttDom(file)
        
        Smo.ArcMen[l] = arc.men
        Smo.ArcMax[l] = arc.max
        Smo.StrMen[l] = strt.men
        Smo.StrMax[l] = strt.max

    S.Smo = Smo

    idf = np.fromfile( file, dtype=np.int32, count=1)[0]
    if idf != -11111:
        raise ValueError("idf incorrect")
    
    # ----- shape2 -----
    S.AreShp    = np.fromfile(file, dtype=np.float32, count=nLev)
    S.ShpGrpSpc = np.fromfile(file, dtype=np.float32, count=3)

    # ----- appearance -----
    S.GryMmm   = np.fromfile(file, dtype=np.uint8, count=3).astype(np.int32)
    S.MxRngRR  = np.fromfile(file, dtype=np.uint8, count=nLev).astype(np.int32)
    S.MxRngEg  = np.fromfile(file, dtype=np.uint8, count=nLev).astype(np.int32)
    S.MxRngBon = np.fromfile(file, dtype=np.uint8, count=nLev).astype(np.int32)

    S.Nbon = np.fromfile(file, dtype=np.int32, count=nLev)
    S.Nrdg = np.fromfile(file, dtype=np.int32, count=nLev)
    S.Nriv = np.fromfile(file, dtype=np.int32, count=nLev)
    S.Nedg = np.fromfile(file, dtype=np.int32, count=nLev)

    S.NpxBon = np.fromfile(file, dtype=np.int32, count=nLev)
    S.NpxRdg = np.fromfile(file, dtype=np.int32, count=nLev)
    S.NpxRiv = np.fromfile(file, dtype=np.int32, count=nLev)
    S.NpxEdg = np.fromfile(file, dtype=np.int32, count=nLev)
    
    # ----------   Farbigkeit   ----------
    #print('bef Farbigkeit')
    S.Cnt = ReadAttFarbig( file )
    S.Bon = ReadAttFarbig( file )

    return S

    

