"""

Read various types of features.

def ReadFeatCoverage(file, nLev):
def ReadAttDom(file):

"""
import numpy as np
from dataclasses import dataclass



""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadFeatCoverage   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Read feature coverage, ie. of boundaries or shapes.

"""
def ReadFeatCoverage(file, nLev):

    @dataclass
    class S:
        pass
    
    S.Deg  = np.fromfile(file, dtype=np.float32, count=nLev)
    S.mx   = np.fromfile(file, dtype=np.float32, count=1)[0]
    S.ixMx = np.fromfile(file, dtype=np.int32, count=1)[0]
    S.Kt   = np.fromfile(file, dtype=np.int32, count=nLev)

    return S


""" RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR   ReadAttDom   RRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

Reads attribute dominance as saved under w_AttDom

cf LoadDescSalc.m

"""
def ReadAttDom(file):

    @dataclass
    class S:
        pass
    
    S.men   = np.fromfile(file, dtype=np.float32, count=1)[0]
    S.max   = np.fromfile(file, dtype=np.float32, count=1)[0]
    S.ixMax = np.fromfile(file, dtype=np.int32,  count=1)[0]

    return S
