%
% Paths, directories and global variables for Sehbau
% 
% dirXXX    one directory/folder, or relative path
% pthXXX    absolute (full) path
% fipaXXX   file path: fullpath | relpath + filename 
%
% sa cc_Globals.m
%
%% ------   Root   ------
rootSehBau      = 'c:/klab/ppc/SEHBAU/';    % modify to match your path...
%rootSehBau      = 'fullpath/SEHBAU/';      % ...like this

%% ------   Dirs Util   ------
if ~exist( [rootSehBau 'AdminMb'], 'dir' ),
    fprintf('globalsSB: adding paths to %s...', rootSehBau);
end

addpath( genpath( [rootSehBau 'AdminMb'] ) );

%% ------   Print Figures   --------
% we print some plots to directory Demos/Figures
bPRINTFIGS      = 0 ;       

%% ------   Dirs to Programs (and Demos)   ------
DirProg.descExtr = 'DescExtr/';
DirProg.descUtil = 'DescUtil/';
DirProg.mtchVec  = 'MtchVec/';
DirProg.mtchHst  = 'MtchHst/';
DirProg.mtchTxt  = 'MtchTxt/';
DirProg.focSel   = 'FocSel/';
DirProg.shpExtr  = 'ShpExtr/';
DirProg.shpMtch  = 'ShpMtch/';
DirProg.plcRec   = 'DemoPlcRec/';
DirProg.sgrRGB   = 'DemoSgrRGB/';
%DirProg.baum     = 'DemoBaum/';

dirFigs          = [rootSehBau 'Demos/Figures/'];

%% ------   Paths to Programs (prepends root)   ------
% used to set field pthProg of administrative structure, ie.:
%     Admin         = u_CmndAdmin();
%     Admin.pthProg = PthProg.focSel;
%
aFnDirs     = fieldnames( DirProg );
for f = 1 : length(aFnDirs)
    fn      = aFnDirs{f};
    PthProg.(fn) = [ rootSehBau DirProg.(fn) ];
    
    if ispc
        PthProg.(fn)   = u_PathToBackSlash( PthProg.(fn) ); 
    end
end

%% ------   Full Filepaths of Binaries/Executables   ------
FipaExe.dscx    = [ PthProg.descExtr 'dscx' ];
FipaExe.d2vmx   = [ PthProg.descExtr 'd2vmx' ];
FipaExe.dbn2vmx = [ PthProg.descExtr 'dbn2vmx' ];
FipaExe.h2arr   = [ PthProg.descExtr 'h2arr' ];
FipaExe.hf2arr  = [ PthProg.descExtr 'hf2arr' ];

FipaExe.collhimg= [ PthProg.descUtil 'collhimg' ];
FipaExe.collvec = [ PthProg.descUtil 'collvec' ];
FipaExe.collsalc= [ PthProg.descUtil 'collsalc' ];
FipaExe.topx    = [ PthProg.descUtil 'topx' ];
FipaExe.cntpat  = [ PthProg.descUtil 'cntpat' ];
FipaExe.ratkpt  = [ PthProg.descUtil 'readatkpt' ];
FipaExe.dbin    = [ PthProg.descUtil 'dbin' ];

FipaExe.mvec1   = [ PthProg.mtchVec  'mvec1' ];
FipaExe.mvecL   = [ PthProg.mtchVec  'mvecL' ];
FipaExe.motvec  = [ PthProg.mtchVec  'motvec' ];

FipaExe.mhstL   = [ PthProg.mtchHst  'mhstL' ];
FipaExe.mkolL   = [ PthProg.mtchHst  'mkolL' ];

FipaExe.mtxt1   = [ PthProg.mtchTxt  'mtxt1' ];
FipaExe.mtxtc   = [ PthProg.mtchTxt  'mtxtc' ];

FipaExe.focdsc1 = [ PthProg.focSel   'focdsc1' ];
FipaExe.fochst1 = [ PthProg.focSel   'fochst1' ];
FipaExe.fochstL = [ PthProg.focSel   'fochstL' ];

FipaExe.ptchxL  = [ PthProg.shpExtr  'ptchxL' ];
FipaExe.shpx    = [ PthProg.shpExtr  'shpx' ];
FipaExe.mshp1   = [ PthProg.shpMtch  'mshp1' ];

FipaExe.sgrRGB   = [ PthProg.sgrRGB  'sgrRGB' ];
%FipaExe.baumfarb = [ PthProg.baum    'baumfarb' ];
%FipaExe.baumgrau = [ PthProg.baum    'baumgrau' ];

% -------  Verify Existence  --------
aFldNa    = fieldnames( FipaExe );
for p = 1:length(aFldNa)
    
    fn      = aFldNa{p};
    prna    = FipaExe.(fn);
    
    if ispc, prna = [prna '.exe'];  end % append '.exe' for windows
    
    if ~exist( prna, 'file' ),
        warning('program %s not found\n', FipaExe.(fn) ); 
    end
end

%% ------   Parameter Files   ------
% contains both directory and names
FipaPrm.gen     = 'Params/';
FipaPrm.dscx    = [ PthProg.descExtr FipaPrm.gen ];
FipaPrm.vocab   = [ PthProg.descUtil 'Vocab/' ];
FipaPrm.ssGrps  = [ FipaPrm.vocab 'ListGroupSS' ];
FipaPrm.bookOtl = [ FipaPrm.vocab 'BookOutline' ];

%% -------   Load Attribute Labels   -------
% LabAtts  = LoadAttLabels( '/../../SEHQUL/Util/LabAtts.txt' );


