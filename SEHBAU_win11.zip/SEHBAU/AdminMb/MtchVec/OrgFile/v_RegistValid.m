%
% Verifies that the register contains filenames that exist. 
%
% same as v_FileLstExists.m
%
% IN   filename of a register
%
function bExist = v_RegistValid( fpRgst )

aLst    = LoadTextLineWise( fpRgst );

bExist  = 1;

cNot = 0;
for i = 1:length(aLst)
    
    if exist( aLst{i}, 'file' )==0
        
        if bExist==1,
            fprintf('Does not exist:\n');
        end
        
        bExist = 0;

        fprintf('%s\n', aLst{i} );
        cNot = cNot + 1;
    end
end

if cNot > 0
    warning('%d files do not exist\n', cNot);
end

return






