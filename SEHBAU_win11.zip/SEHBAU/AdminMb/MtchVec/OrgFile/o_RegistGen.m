%
% Generates a register, a list of numeric-based descriptor filenames from a
% filestem, a list of indices and an extension. No verification of their
% existence. 
%
% Two formats are implemented:
% - plain:  just number as string
% - 7 characters long, with leading zeros, ie. 5 as 0000005
%
%
% ai o_RegistSetSave, runMvecColl.m, runMhstKnn.m
% sa SaveFipaXXX, SaveFinaXXX, SaveRegistFoc.m
%
% sa o_RegistAnf.m
% cf o_RegistCatgWise.m
%
% IN  fist      filestem or path+filestem
%     IxImg     image indices
%     ext       extension
%     nameFrmt  name format: plain, or with leading zeros
%     
% OUT aLin      list of file paths (cell)
%
function aLin = o_RegistGen( fist, IxImg, ext, nameFrmt )

nImg    = length( IxImg );
aLin    = cell( nImg, 1);

if nargin==3
    nameFrmt = 0;
end

for i = 1:nImg

    ixi     = IxImg(i);

    if nameFrmt==0                  % --- plain numbers
        
        aLin{i} = [ fist num2str(ixi) ext ];
        
    elseif nameFrmt==7              % --- leading zeros
        
        aLin{i} = sprintf('%s%07d%s', fist, ixi, ext);
    else
        error('nameTyp=%d not implemented.\n', nameFrmt );
    end

end
    
end

