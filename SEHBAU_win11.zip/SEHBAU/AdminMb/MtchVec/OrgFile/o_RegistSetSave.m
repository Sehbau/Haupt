%
% Generates the registers for a set of representation formats, namely
% descfiles (vectors), kolumn, histogram and saliency (texture).
%
% cf plcCascIdf.m, plzMfast.m, lvngRunMcsc.m
% sa o_RegistAnf.m
%
% IN  RgstFp    struct with filepaths (o_RegistFileNames.m)
%     pthDsc    path of descriptor files
%     fist      filestem or path+filestem
%     IxImg     image indices
%     Fixt      extensions
%     nameFrmt  name format: none, or with leading zeros
%     
% OUT R         register info for dsc files (vectors)
%
function [Rdsc] = o_RegistSetSave( RgstFp, pthDsc, fist, IxImg, Fixt, ...
                                   nameFrmt )

if nargin==5
    nameFrmt = 0;  % if no format given, then just conversion of number
end

% desc:
aDsc        = o_RegistGen( fist, IxImg, Fixt.dsc, nameFrmt );
SaveFipaLstPrependPath( aDsc, pthDsc, RgstFp.dsc );

% hist:
aHst      	= o_RegistGen( fist, IxImg, Fixt.hsti, nameFrmt );
SaveFipaLstPrependPath( aHst, pthDsc, RgstFp.hst );

% kolm:
aKol      	= o_RegistGen( fist, IxImg, Fixt.kol, nameFrmt );
SaveFipaLstPrependPath( aKol, pthDsc, RgstFp.kol );

% salc: 
aSlc      	= o_RegistGen( fist, IxImg, Fixt.slc, nameFrmt );
SaveFipaLstPrependPath( aSlc, pthDsc, RgstFp.slc );

% dtop: is in o_RegistSetSaveDtop.m, because it requires a different
% identifier
%aDtop      	= o_RegistGen( fist, IxImg, Fixt.dtop, nameFrmt );
%SaveFipaLstPrependPath( aDtop, pthDsc, R.fpaDtop );

% -----  A2S  -----
Rdsc.aFipaDsc  = aDsc;         % saves only names (without path) 
Rdsc.pth       = pthDsc;

end

