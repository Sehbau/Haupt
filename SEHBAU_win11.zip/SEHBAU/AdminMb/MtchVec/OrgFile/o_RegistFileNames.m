%
% Filenames for registers.
%
function [R] = o_RegistFileNames( )

R.dsc       = 'RefDsc.txt' ;
R.hst       = 'RefHst.txt' ;
R.kol       = 'RefKol.txt' ;
R.slc       = 'RefSlc.txt' ;

R.dtop      = 'RefDtop.txt' ;
R.cntpat    = 'RefCntPat.txt' ;

end

