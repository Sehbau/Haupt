%
% Generates the register set for dtop files.
%
% cf plzMfast.m
% af o_RegistSetSave.m
% sa o_RegistAnf.m
%
% IN  RgstFp    struct with filepaths (o_RegistFileNames.m)
%     pthDsc    path of dtop files
%     fist      filestem or path+filestem
%     IxImg     image indices
%     Fixt      extensions
%     nameFrmt  name format: none, or with leading zeros
%     
% OUT R         register info
%
function [R] = o_RegistSetSaveDtop( RgstFp, pthDsc, fist, IxImg, Fixt, ...
                                    nameFrmt )

if nargin==5
    nameFrmt = 0;
end

% dtop: 
aDtop      	= o_RegistGen( fist, IxImg, Fixt.dtop, nameFrmt );
SaveFipaLstPrependPath( aDtop, pthDsc, RgstFp.dtop );

% -----  A2S  -----
R.aFipa     = aDtop;        % saves only names (without path)
R.pth       = pthDsc;

end

