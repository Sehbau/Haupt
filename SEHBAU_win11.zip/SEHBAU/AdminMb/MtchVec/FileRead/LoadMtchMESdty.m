%
% Loads matching results for each desctype column-wise [nMtc nDscTyp]
%
% cf MVECLXLfull.m, MtchVec/exsbMvecLimg.m, lvngRunMvec.m 
%
function [Mes] = LoadMtchMESdty( lfn ) 

fileID   = fopen(lfn, 'rt');

if fileID<0, error('Could not open file %s', lfn); end
    
%% -----  Header  -----
nMtc    = fscanf( fileID, '%d', 1);     % number of matches (ie. nImages)
nDty    = fscanf( fileID, '%d', 1);     % number of descriptor types

%fprintf('nMtc %d  nDty %d\n', nMtc, nDty );

%% -----  Data  -----
Mes = zeros(nMtc, nDty, 'single');
for l = 1:nMtc
    
    Row      = fscanf(fileID, '%f', nDty);
    %l
    %size(Row)
    Mes(l,:) = Row;
end

fclose(fileID);

end


