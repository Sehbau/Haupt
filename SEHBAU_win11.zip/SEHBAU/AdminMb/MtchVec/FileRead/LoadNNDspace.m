%
% Loads a space of NN indices and their measurement values, as saved under
% s_DescNNsSpc in DescNNio.h
%
% cf exsbFrames.m
%
function [ALev Ndsc nLev]= LoadNNDspace( lfn ) 

fid  = fopen(lfn, 'r');

if fid<0, error('Could not open file %s', lfn); end

nLev  = fread(fid, 1, 'uint8=>int');      % # of pyramid levels

fprintf('nLev %d:  ', nLev );

ALev = cell(nLev,1);
Ndsc = ones(nLev,1, 'int32');
for l = 1:nLev

    NN      = ReadDescNNs( fid );
    
    ALev{l} = NN;
    Ndsc(l) = NN.nDsc;
end

fclose(fid);

fprintf('\n');

end


