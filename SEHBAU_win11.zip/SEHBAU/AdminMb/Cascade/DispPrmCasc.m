%
% Dispaly parameters for cascade identifier.m
%
% o_CascIdfPrm.m
%
function [P] = DispPrmCasc( P )

fprintf('stgy %s   comb %d    prp %1.2f ', ...
    P.stgy, P.bCombMes, P.prpPre );

%PrmCasc.prmMtcTyp = ''; % ?







