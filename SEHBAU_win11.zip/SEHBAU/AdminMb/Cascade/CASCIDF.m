%
% Two-stage cascade identifier, 1 versus many. Takes a query image and
% matches it to a list of reference images, called a register. Assumes we
% are running in folder 'MtchVec'.
%
% Stage 1:  fast matching with mvec(dtop)|mtxt|mhst|mkol. 
%           > preselection
% Stage 2:  fine (detailed) matching with mvec(dsc).
%
% cf plcCascIdf.m, lvngRunMcsc.m, PLZMTCHCSC.m
%
% IN   FpExe    filepaths of executables. 
%      FpQuy    filepaths of query image (.dsc, .hst, .kolm)
%      Rgst     register. generated with o_RegistSetSave.m
%      Admn     paths, see o_CascIdfPth.m
%      Args     command arguments
%      Prm      parameters, see o_CascIdfPrm.m
%
% OUT  Res      matching results
%      Sto      standard output of commands
%      Fll      full results
%
function [Res Sto Fll] = CASCIDF( FpExe, FpQuy, RGST, Admn, Args, Prm )

% created in o_RegistSetSave.m
fpaRgstHst	= RGST.Fipa.hst;
fpaRgstSlc	= RGST.Fipa.slc;
fpaRgstKol 	= RGST.Fipa.kol;
fpaRgstDsc 	= RGST.Fipa.dsc;    
fpaRgstTop 	= RGST.Fipa.dtop;

% created in o_CascIdfPth.m
fpMesHst  	= Admn.fpMesHst;
fpMesTxt  	= Admn.fpMesTxt;    % in the future when we'll have mtxtL.cpp
fpMesKol  	= Admn.fpMesKol;
fpMesVec  	= Admn.fpMesVec;

nImg      	= Prm.nImg;
stgy        = Prm.stgy;

%% ----------------------------------------------------------------
%                       STAGE 1 (FAST)
% according to a selected strategy
% af lvngRunMhstKol.m
OrdPre      = [];
DisPreOrd   = [];

ixTxtg      = strfind( stgy, 'txtg' );

% ---------------------   Texturegrams Collected  -----------------------
% uses executable mtxtc
if ~isempty( ixTxtg ),
    
    typ     = stgy(ixTxtg+4:end);
    
    fidfTxt = 'Txtr';
    PthM    = o_FileNameMtxtc( 1, fidfTxt );
    
    if strcmp( typ, 'Band' )

        cmndBnd = sprintf('%s %s %s', FpExe.mtxtc, FpQuy.slc, Admn.FinaColl.txgb );
        [Sts OutBnd] = system( cmndBnd ); 
        v_CmndExec( Sts, OutBnd, cmndBnd, 1 );

        DisTxt    = LoadFltTxtEof( PthM.txtBand );

    elseif strcmp( typ, 'Grid' )
        
        cmndGrd = sprintf('%s %s %s', FpExe.mtxtc, FpQuy.slc, Admn.FinaColl.txgg );
        [Sts OutGrd] = system( cmndGrd ); 
        v_CmndExec( Sts, OutGrd, cmndGrd, 1 );
        
        DisTxt    = LoadFltTxtEof( PthM.txtGrid );
        
    elseif strcmp( typ, 'Comb' )
        
        cmndBnd = sprintf('%s %s %s', FpExe.mtxtc, FpQuy.slc, Admn.FinaColl.txgb );
        cmndGrd = sprintf('%s %s %s', FpExe.mtxtc, FpQuy.slc, Admn.FinaColl.txgg );
        [Sts OutBnd] = system( cmndBnd ); 
        [Sts OutGrd] = system( cmndGrd ); 
        v_CmndExec( Sts, OutBnd, cmndBnd, 1 );        
        v_CmndExec( Sts, OutGrd, cmndGrd, 1 );        

        % loads both:
        Mes         = LoadMeasMtxtc( PthM );  
        % inspiration in dis_Txtr.m
        DisTxt      = Mes.Txg.Grd + Mes.Txg.Bnd;
    else
        error('CASCIDF: stgy %s, typ %s not implemented', stgy, typ );
    end
    
    [DisOrd OrdPre] = sort( DisTxt, 'ascend' );
    OrdPre          = OrdPre( 1:Prm.nPre );  
    DisPreOrd       = DisOrd( 1:Prm.nPre );  
end

% ---------------------   Texturegrams Individual   -----------------------
% uses executable mtxt1 and wrapper script f_MtxtL.m
if strcmp( stgy,'txtgIdv' ),
    
    aFpSlc      = LoadTextLineWise( fpaRgstSlc );
    
    fidfTxt     = 'Txt1';
    PthM        = o_FileNameMtxt1( 1, fidfTxt );
    
    DisS        = f_MtxtL( FpExe.mtxt1, FpQuy.slc, aFpSlc, PthM, ...
                       Prm.WgtTxg );
                    
    Dis             = DisS.(Prm.txtgTyp);
    [DisOrd OrdPre] = sort( Dis, 'ascend' );
    OrdPre          = OrdPre( 1:Prm.nPre );    
    DisPreOrd       = DisOrd( 1:Prm.nPre );  
end

% ---------------------   TopDesc1st   -----------------------
% Res.DisTxgOrd   = DisOrd;
if ~isempty( strfind( stgy,'top' ) ),
    
    SaveFipaLstPrependPath( RGST.Top.aFipa, RGST.Top.pth, fpaRgstTop );

    cmndTop     = [ FpExe.mvecL ' ' FpQuy.dtop ' ' fpaRgstTop ]; % args 1 & 2
    cmndTop     = [ cmndTop ' ' Args.Vec.fpPrm ' ' fpMesVec ];  % args 3 & 4
    if ~isempty( Args.Vec.opt )
        cmndTop = [ cmndTop ' ' Args.Vec.opt ]; % long options
    end
    
    Sto.Mtop    = f_CmndExec( cmndTop );

    MesTop      = LoadMtchMes( fpMesVec, nImg );
    DisTop      = MesTop(:,1);
    
    [DisTopOrd OrdTop] = sort( DisTop, 'ascend' );
    
    OrdPre      = OrdTop( 1:Prm.nPre );

    Res.DisHisOrd = DisTopOrd;
    
    % macht weniger Sinn hier, weil es ja schon vector-based ist
    % DisPreOrd   = DisTopOrd( 1:Prm.nPre );  
    
    %MESdis      = LoadMtchMESdty( Admn.fpMesDtyDis );
    %MESsim      = LoadMtchMESdty( Admn.fpMesDtySim );
end

% ---------------------   Ensemble TxtgTop   -----------------------
if ~isempty( strfind( stgy,'enstoptxtg' ) )
    
    DisEns      = DisTxt .* DisTop;

    [DisEnsOrd OrdEns] = sort( DisEns, 'ascend' );
    
    OrdPre      = OrdEns( 1:Prm.nPre );
    
end

% ---------------------   Histograms   -----------------------
if strcmp( stgy,'hist1st' ),

    cmndHst = [ FpExe.mhstL ' ' FpQuy.hst ' ' fpaRgstHst ' ' fpMesHst ' ' Args.Hst ];

    Sto.Mhst = f_CmndExec( cmndHst );

    % load sorting and select
    [OrdHis DisHisOrd] = LoadSortFltTxt( fpMesHst, nImg );
    OrdPre	= OrdHis( 1:Prm.nPre );

    Res.DisHisOrd = DisHisOrd;

% ---------------------   Kolumns   -----------------------
elseif strcmp( stgy,'kolm1st' ),

    cmndKol	= [ FpExe.mkolL ' ' FpQuy.kol ' ' fpaRgstKol ' ' fpMesKol ];

    Sto.Mkol = f_CmndExec( cmndKol );

    % load sorting and select
    [OrdKol DisKolOrd] = LoadSortFltTxt( fpMesKol, nImg );
    OrdPre	= OrdKol( 1:Prm.nPre );

    Res.DisKolOrd = DisKolOrd;

elseif strcmp( stgy,'ensHstKolm' ),

    % we combine histograms and kolumns

    cmndHst = [ FpExe.mhstL ' ' FpQuy.hst ' ' fpaRgstHst ' ' fpMesHst ' ' Args.Hst ];
    cmndKol	= [ FpExe.mkolL ' ' FpQuy.kol ' ' fpaRgstKol ' ' fpMesKol ];

    Sto.Mhst        = f_CmndExec( cmndHst );
    Sto.Mkol        = f_CmndExec( cmndKol );

    % load UNsorted measurements array
    DisHisUor       = LoadFltTxt( fpMesHst, nImg );
    DisKolUor       = LoadFltTxt( fpMesKol, nImg );

    DisEns          = DisHisUor .* DisKolUor;
    [Dis OrdPre]    = sort( DisEns, 'ascend' );
    OrdPre          = OrdPre( 1:Prm.nPre );
end

Res.OrdPre    = OrdPre;

%% ----------------------------------------------------------------
%                           STAGE 2 (FINE/DETAILED)
%
nPre        = length( OrdPre );
if nPre==0, 
    error('CASCIDF: no preselection carried out: strategy %s', Prm.stgy ); 
end

% save reduced list
SaveFipaLstPrependPath( RGST.Dsc.aFipaDsc( OrdPre ), ...
                        RGST.Dsc.pth, fpaRgstDsc );

cmndVec     = [ FpExe.mvecL ' ' FpQuy.dsc ' ' fpaRgstDsc ]; % args 1 & 2
cmndVec     = [ cmndVec ' ' Args.Vec.fpPrm ' ' fpMesVec ];  % args 3 & 4
if ~isempty( Args.Vec.opt )
    cmndVec = [ cmndVec ' ' Args.Vec.opt ]; % long options
end

Sto.Mvec    = f_CmndExec( cmndVec );

%Sto.Mvec

MesTot      = LoadMtchMes( fpMesVec, nPre );
MESdis      = LoadMtchMESdty( Admn.fpMesDtyDis );
MESsim      = LoadMtchMESdty( Admn.fpMesDtySim );

nDty        = size(MESdis,2);

%% ---------------------------------------------------------------
%                             COMBINE 
% Weight by distances from fast matching
% o_CascIdfPrm.m
if Prm.bCombMes
    mxV         = max( DisPreOrd );
    SimPreOrd   = mxV - DisPreOrd;
    if ~isempty( DisPreOrd )
        MesTot(:,1) = MesTot(:,1) .* DisPreOrd;
        MesTot(:,2) = MesTot(:,2) .* SimPreOrd;
        
        for d = 1:nDty
            MESdis(:,d) = MESdis(:,d) .* DisPreOrd;
            MESsim(:,d) = MESsim(:,d) .* SimPreOrd;
        end
    end
end

%% --------------------    Track Full    -------------------------------
% keep full set of measurements for benchmarking
if Prm.mesFull > 0
    Fll.MesTot  = MesTot;
    Fll.MESdis  = MESdis;
    Fll.MESsim  = MESsim;
end

%% -------------------    Sort & Reorder   -----------------
% -----  total (MesTot)
Res.OrdDis  = uu_CascSortReorder( MesTot(:,1), 'ascend', OrdPre );
Res.OrdSim  = uu_CascSortReorder( MesTot(:,2), 'descend', OrdPre );

if ~isempty( DisPreOrd )
    %Res.OrdDis = uu_CascSortReorder( MesTot(:,1) .* DisPreOrd, 'ascend', OrdPre );
    %Res.OrdDisWgtPre = uu_CascSortReorder( MesTot(:,1) .* DisPreOrd, 'ascend', OrdPre );
end

% -----  desctype (MESdis, MESsim)
Res.ORDDty.Dis = zeros(nDty,nPre,'int32');
Res.ORDDty.Sim = zeros(nDty,nPre,'int32');
for d = 1:nDty

    Res.ORDDty.Dis(d,:) = uu_CascSortReorder( MESdis(:,d), 'ascend', OrdPre);
    Res.ORDDty.Sim(d,:) = uu_CascSortReorder( MESsim(:,d), 'descend', OrdPre );
    
    if ~isempty( DisPreOrd )
        %Res.ORDDty.Dis(d,:) = uu_CascSortReorder( MESdis(:,d) .* DisPreOrd, 'ascend', OrdPre );
    end    
end

% Res.OrdDis(1) is best ensemble index (distance)
% Res.OrdSim(1) is best ensemble index (similarity)
% Res.ORDDty.Dis(1,1) is best contour index (distance)
% Res.ORDDty.Sim(1,1) is best contour index (similarity)
% Res.ORDDty.Dis(2,1) is best rsg index (distance)
% Res.ORDDty.Sim(2,1) is best rsg index (similarity)

end

%% UUUUUUUUUUUUUUUUUUUUUUUUU   uu_CascSortReorder   UUUUUUUUUUUUUUUUUUUUUU
%
% Reorders the fine-matching indices according to the preselected indices
% from fast matching.
%
% IN   Mes     array of measurements, ie. from fine matching
%      dir     ascending | descending
%      OrdPre  preselected indices from fast matching
% OUT  OrdOrg  order of original indices (full set)
%
function OrdOrg = uu_CascSortReorder( Mes, dir, OrdPre )

[MesO, OrdFin] = sort( Mes, dir );

OrdOrg     = OrdPre( OrdFin );

end

