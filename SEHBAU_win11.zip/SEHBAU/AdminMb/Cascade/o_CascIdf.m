%
% Parameters and paths for cascade identifier in CASCIDF.m
%
function [P A] = o_CascIdf( pthMes, nImg, prpPre )

P.stgy          = 'hist1st';        % histogram first
P.prpPre        = prpPre;
P.nPre          = round ( nImg * prpPre );
P.nImg          = nImg;
P.mesFull       = 1;

A.fpMesHst      = [ pthMes 'Mes/CscHst.txt'];
A.fpMesKol      = [ pthMes 'Mes/CscKol.txt'];
A.fpMesVec      = [ pthMes 'Mes/CscVec.txt'];

A.fpMesDtyDis   = [ pthMes 'Mes/MesDtyDis.txt']; % unchangeable
A.fpMesDtySim   = [ pthMes 'Mes/MesDtySim.txt']; % unchangeable


