%
% Parameters for cascade identifier in CASCIDF.m
%
% Display with DispPrmCasc.m
%
function [P] = o_CascIdfPrm( nImg, prpPre, stgy, txtgTyp )

% ---------------   Complete Arguments   ---------------
if nargin==1
    prpPre  = 0.5;
    stgy    = 'txtgc';        % texturegrams first
    txtgTyp = 'TxgTot';
end
if nargin==2
    stgy    = 'txtgc';        % texturegrams first
    txtgTyp = 'TxgTot';
end

% ---------------   A2S   ---------------
P.stgy          = stgy;         % preselection strategy
P.prpPre        = prpPre;
P.nPre          = round ( nImg * prpPre );
P.nImg          = nImg;
P.bCombMes      = 1;            % combines distances of fast/detailed
P.mesFull       = 1;            % for benchmarking


% ---------------   Histogram   ---------------
if strcmp( stgy, 'hist1st' ), return; end


% ---------------   Texture   ---------------
% this is for strategy 'txtgIdv'

% -----  preselection options  -----
% see f_MtxtL.m, dis_Txtr.m
if nargin<4
    txtgTyp = 'TxgTot';
end
P.txtgTyp       = txtgTyp;

% verify
Bhit            = strcmp( txtgTyp, {'TxgGrid','Band','Blob'} );
if ~any(Bhit), 
%    error('texture preselection %s not possible', txtgTyp );
end

% -----  weights  -----
% only deployed in f_MtxtL.m, dis_Txtr.m
P.WgtTxg      = o_WgtTxtrMtch();




