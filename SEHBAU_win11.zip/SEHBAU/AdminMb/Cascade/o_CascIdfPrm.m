%
% Parameters for cascade identifier in CASCIDF.m
%
function [P] = o_CascIdfPrm( nImg, prpPre, stgy, txtgTyp )

% ---------------   Complete Arguments   ---------------
if nargin==1
    prpPre  = 0.5;
    stgy    = 'hist1st';        % histogram first
end
if nargin==2
    stgy    = 'hist1st';        % histogram first
end

% -----  verify strategy
% ...


% ---------------   A2S   ---------------
P.stgy          = stgy;         % preselection strategy
P.prpPre        = prpPre;
P.nPre          = round ( nImg * prpPre );
P.nImg          = nImg;
P.mesFull       = 1;

% ---------------   Texture   ---------------

% -----  preselection options  -----
if nargin<4
    txtgTyp = 'Grid';
end
% see f_MtxtL.m
Bhit            = strcmp( txtgTyp, {'Grid','Band','Blob'} );
if ~any(Bhit), 
    error('texture preselection %s not possible', txtgTyp );
end

P.txtgTyp       = txtgTyp;

% -----  weights  -----
Prm.WgtTxg      = o_WgtTxtrMtch();




