%
% Wrapper function for program txtra.
%
% af RennDbin.m
% 
% IN   fpCbnt   hsspa file run with PrmDbin_Fabric.txt
%      fpOut    output filestem
%      Args     .fpPrm   parameter filename (3rd argument)
%               .opt     options (o_CmndArgs) 
%      dirExec  directory of executable
%
% OUT  Out      standard output
% 
function [Out] = RennTxtra( fpTxm, fpOut, Args, dirExec )

if nargin==3, 
    dirExec = ''; 
end

fpExe   = [dirExec 'txtra'];

if exist( fpExe, 'file')==2,
    error('Program path not correct: %s', fpExe);
end

cmnd    = [ fpExe ' ' fpTxm ' ' fpOut ];%' ' Args.fpPrm, ' ' Args.opt ];

if ispc
    cmnd         = u_PathToBackSlash( cmnd );
    [status Out] = dos(cmnd);            % excecute as windows program
elseif isunix
    [status Out] = unix(cmnd);           % excecute as unix program
else
    error('OS not implemented');
end

%% ------  Status  ------
if status>0
    Out
    warning('status > 0: something went wrong');
end

%% ------  Verify Proper Termination  -----
ixEOP = strfind( Out, 'EndOfProgram');

if isempty(ixEOP)
    warning('Program txtra %s did not finish.', cmnd);
    Out    
    if isempty(Out)
        fprintf('Out empty. We try to debug '); 
        cmnd      = [cmnd ' --bDISP 2'];
        [stu Out] = system(cmnd);           % excecute program again
        Out    
    end
    fprintf('Paused');
    pause();
end


