%
% Descriptor types as short strings.
% 
% sa u_LabDscTyp.m
%
function [aDty nDty] = o_DescTypes( typ )

if nargin==0
    typ = 'Cfasstb';            % second choice
end

if strcmp( typ, 'cfasshp' )

    aDty    = {'Cnt' 'Frm' 'Arc' 'Str' 'Shp'};

elseif strcmp( typ, 'Cfasstb' )

    aDty    = {'Cnt' 'Frm' 'Arc' 'Str' 'Shp' 'Ttrg' 'Bndg'};

elseif strcmp( typ, 'cfas_crm' )

    aDty    = {'Cnt' 'Frm' 'Arc' 'Str' 'Crm'};

elseif strcmp( typ, 'cfass_crm' )

    aDty    = {'Cnt' 'Frm' 'Arc' 'Str' 'Shp' 'Crm'};

elseif strcmp( typ, 'cfasst' )

    aDty    = {'Skl' 'Frm' 'Arc' 'Str' 'Shp' 'Ttg'};

%elseif strcmp( typ, 'cfassb' )

%    aDty    = {'Skl' 'Frm' 'Arc' 'Str' 'Shp' 'Bnd'};

elseif strcmp( typ, 'cfasstb' ) % fka fixt?

    aDty    = {'Skl' 'Frm' 'Arc' 'Str' 'Shp' 'Ttrg' 'Bndg'};

elseif strcmp( typ, 'rre_all' )

    aDty    = {'Rdg' 'Riv' 'Edg' 'Skl' 'Frm' 'Arc' 'Str' 'Shp' 'Ttrg' 'Bndg'};

elseif strcmp( typ, 'sklfasshp' )

    aDty    = {'Skl' 'Frm' 'Arc' 'Str' 'Shp'};

elseif strcmp( typ, 'cfas' )

    aDty    = {'Skl' 'Frm' 'Arc' 'Str'};

else
    
    fprintf('typ %s not implemented (sa o_FileExtensVect)', typ);
    if typ(2)=='r'
        warning('r for radsig not in use anymore');
    end
end
    

nDty    = length(aDty);


end

