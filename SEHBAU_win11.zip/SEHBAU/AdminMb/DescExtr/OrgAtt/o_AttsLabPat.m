%
% Attribute names (labels) for the contour pattern.
%
% Must match routine wt_PatLin in PatIO.h
%
function [L] = o_AttsLabPat()

LbRgb    = { 'red' 'grn' 'blu' };

L        = [ 'vt1' 'hz1' 'vt2' 'hz2' 'vtm' 'hzm' ... % 6 
             'ori' 'len' LbRgb 'wgt' 'typ' 'lev'];   % 8

end % MAIN

