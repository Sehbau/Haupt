%
% Creates a struct with fieldnames from 'aLab' holding the index value to
% array 'aLab'.
%
% cf o_AttIxAsFields.m
% sa u_AttIxFromLab.m
% 
% IN    aLab    a list of attribute labels
%       bIxMode 0 = zero-indexing (C/Python)
%               1 = one-indexing (Mb)
%
% OUT   S       struct with fieldnames from labels holding index to aLab
%
function S = u_AttIxAsFields( aLab, bIxMode )

nLab    = length(aLab);

ixShift = 0;                % remains one-indexing
if bIxMode==0               % if zero-indexing chosen, 
    ixShift = -1;           % then subtract to make it zero-indexing
end

S   = struct;

for l = 1:nLab
    
    S.( aLab{l} ) = l + ixShift;
end

end % MAIN




