%
% Texture biases. For their weigts see o_WgtTxtrMtch.m
% 
% Passed to function u_BlobBbxRtrv().
% 
% They are also used in ReadTxtrMapStats.m (but NOT passed as variable).
%
% They must match with CntTxtAnf.h, w_CntTXTbis (CntTxtIO.h)
%
% Their color code for plotting is in u_ColBlob.m
%
function [aLsho nBis aLlon] = o_TxtrLabels()

% NB NVHAUK
%            1     2     3     4     5     6     7     8     9
aLsho   = {'Num' 'Blk' 'Nil' 'Vrt' 'Hor' 'Axi' 'Uni' 'Ken' 'Bnt'};

nBis    = length( aLsho );

aLlon   = { 'Num (count)' ...
            'Blank (void)' ...
            'Nil (no ori)' ...
            'Vertical' ...
            'Horizontal' ...
            'Axial (vrt&hor)'...
            'Uni (1 ori)' ...
            'Ken (contrast)'...
            'Bunt' };

end 

