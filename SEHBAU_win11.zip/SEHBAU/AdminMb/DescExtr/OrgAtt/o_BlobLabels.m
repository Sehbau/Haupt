function [aLsho nTyp aLlon] = o_BlobLabels()

error('deprecated - use o_TxtrLabels');


end 

