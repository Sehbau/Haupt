%
% Loads the attribute labels as saved by attlabels.cpp (Util)
%
function [G] = LoadAttLabels( lfn ) 

fileID      = fopen(lfn, 'r');

if fileID<0, error('Could not open attribute file %s', lfn); end

aLines      = ReadTextLineWise( fileID );

fclose(fileID);

%%
nLin    = length( aLines );
G       = struct;
for i = 1:nLin
    lin     = aLines{i};
    if strfind( lin, '-----')
        dty = lin(8:10);
    elseif strfind( lin, '>>>')
        % do nothing
    else
        ixColon = strfind( lin, ':');
        lbSet   = lin(1:ixColon-1);
        
        lbAtts  = lin(10:end);
        
        G.(dty).(lbSet) = u_AttLabArrToList( lbAtts );
    end
end

end


