%
% Angles
%
function [S] = o_Angles(  )

% ----------  8 orientations  ------------
% due to circularity we have 9 bin centers and 10 edges
CenO8          = -pi/2 : pi/8 : pi/2; % -1.57..0..1.57
S.BinCenOri8   = CenO8;
S.EdgOri8      = CenO8 - pi/16;       % 9 values
S.EdgOri8(end+1) = abs(S.EdgOri8(1)); % 10 values

end

