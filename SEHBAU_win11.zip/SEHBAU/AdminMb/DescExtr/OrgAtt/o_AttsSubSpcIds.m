%
% see o_QntSubSpcGrps
%
% deprecated: o_QntSubSpcIds
% 

