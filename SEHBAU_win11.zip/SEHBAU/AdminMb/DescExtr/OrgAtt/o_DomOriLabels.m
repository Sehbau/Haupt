%
% Biases for dominant orientations.
% 
function [aLsho nBis aLlon] = o_DomOriLabels( )


aLsho   = {'v' 'h' 'o' 'a' 'u' 'n'};

aLlon   = {'vrt' 'hor' 'obl' 'axi' 'uni' 'nil'};

nBis    = length(aLsho);




end 

