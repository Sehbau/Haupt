%
% Creates a struct with fields indicating index.
% 
% IN    Lb      o_AttsLabels.m, o_AttsLabBin.m
%       bIxMode 0 = zero-indexing (C/Python)
%               1 = one-indexing (Mb)
%
% OUT   S       struct with indices for each desctype
%
function S = o_AttIxAsFields( LB, bIxMode )

S.Cnt   = u_AttIxAsFields( LB.Cnt, bIxMode );
S.Frm   = u_AttIxAsFields( LB.Frm, bIxMode );
S.Arc   = u_AttIxAsFields( LB.Arc, bIxMode );
S.Str   = u_AttIxAsFields( LB.Str, bIxMode );
S.Shp   = u_AttIxAsFields( LB.Shp, bIxMode );

end % MAIN




