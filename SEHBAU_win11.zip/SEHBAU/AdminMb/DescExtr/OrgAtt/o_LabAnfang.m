%
% Informs about the different labels. No functionality. A mini man page.
%
% Labels for histogram-of-attributes are in the struct returned by
% LoadDescHist.m
%
function [] = o_LabAnfang( )

fprintf('\to_AttsLabels.m       attributes analogue (real)\n');
fprintf('\to_AttsLabBin.m       attributes discrete (binned)\n');

fprintf('\to_TxtrLabels.m       texture biases\n');

fprintf('\to_QntSubSpcLab.m     attribute groups for quants\n');

end

