%
% Attribute names (labels) for the float vectors, the descriptors in the
% .vec{Dsc} file.
%
% ungeschickt: two types of position labels. 
%
% Some are specified as a list of strings, others as a single
% (concatenated) string that is converted into a list here.
%
% An attribute label has at most 6 characters. 
%
% cf LoadDescVect.m, LoadCollVec.m, exsbPlotShape.m, f_ShpAlySpc.m
%
% Elsewhere:
% - o_AttsLabBin.m    labels for bin-vectors.
% - conversion matrix to struct-of-arrays: u_MtrxToStcArr.m
% - conversion for all desctypes in u_DescMxToStcOfArr.m
% - o_TxtrLabels for texture labels
%
% OUT    LB    labels as needed for the output of d2vmx
%        SG    labels as subgroups, as needed for u_AttsArrToStruct.m  
%
function [LB, SG] = o_AttsLabels()

LbPos       = { 'psv' 'psh' };
LbRgb       = { 'red' 'grn' 'blu' };
LbPosRgb    = [ LbPos LbRgb ];
LbLage      = { 'ori' 'psv' 'psh' }; % tetragon
% vpo and hpo deprecated
%LbPosRgb    = { 'vpo' 'hpo' 'red' 'grn' 'blu' }; % for shape

%SGL         = LoadAttLabels( '../../../../SEHQUL/Util/LabAtts.txt' );

%% ----------   contour   ---------  8
% wt_CntVec, CntIO.h
LB.Cnt = [ {'len' 'str' 'ori'} LbPos LbRgb ];
LB.Skl = LB.Cnt;

%% ----------   radial signature   ----------  10 + 7
% ReadRsgAtt.m
% wt_RsgVec, RsgIO.h
Lfrm.RdSig = {'rad' 'cir' 'eloR' 'eloF' 'bulk'   'bs1' 'bs2' 'bs3' 'bs4' 'bs5'...
              'star' 'dent' };

Lbs = 'AreN  HgtN  WthN  High  Wide  Higv  Widv  RtAre Axial Diamo Diag1 Diag2 EloSg EloRd Steh  Lieg  ';      
Lfrm.RospA = u_AttLabArrToList( Lbs );

Lbs = 'Volm  Haar  Lean  Eql3  Virs  FtD   Tri   Pllo  Rib   Pyr   Tud   Fuss  Hxgn  Hept  Octa  ';
Lfrm.RospB = u_AttLabArrToList( Lbs );

Lbs = 'EkTL  EkTT  EkTR  EkRR  EkBR  EkBB  EkBL  EkLL  ';
Lfrm.RoEck = u_AttLabArrToList( Lbs );

Lbs = 'Notw  Ninw  Glid  Side  Otwn  Inwn  Widv  RtAre Axial Diamo ';
Lfrm.BlgAspA = u_AttLabArrToList( Lbs );

Lbs = 'Circ  Unul  Bipo  Trip  Qudp  Pent  Hexp  Hept  Diec  ';
Lfrm.BlgGlid = u_AttLabArrToList( Lbs );

LB.Rsg  = [ Lfrm.RdSig(:); LbPos(:); LbRgb(:); ...
            Lfrm.RospA(:); Lfrm.RoEck(:) ];
      
%% ----------   arc   ---------  9 + 5
LB.Arc = [ {'len' 'krv' 'dir' 'am1' 'am2'   'smo' 'spz' 'run' 'eck' } ...
            LbPosRgb ];
      
%% ----------   str   ---------  10 + 5
LB.Str = [ {'les' 'str' 'ifx' 'wig' 'bog'   'amp' 'smo' } LbPosRgb ];
        
%%  ---------    bndg   ---------  10      
LB.Bndg = [ {'len' 'agx' 'tig' 'dns' 'ori' } LbPosRgb ];
      
%% ----------   shape   ---------   ShpAbstAtts.h

% ------ attsShpStrOri, ia Scors
Lbs = 'Vrt   Hor   Dg1   Dg2   Axi   Adg   Vab   Hab   Dab   Tri   Nil   ';
Lshp.Scors = u_AttLabArrToList( Lbs );

% ------ attsShpStrFin, ia Sfine
Lbs = 'Vrt   Hor   Vti   Hti   Vob   Hob   Dg2   Dg1   Axi   Uni   Dul   Cvg   Agx   Ori   Nil   Dre   Vir   Fnf   ';
Lshp.Sfine = u_AttLabArrToList( Lbs );

% ------ attsShpRadSeg, ia Ras
Lbs = 'Rad   Elo   Ron   Riss  SteUgfSteEngSteDowSteUppOpnDowOpnUpwLigUgfLigEngLigDowLigUppOpnRitOpnLef';
Lshp.Ras = u_AttLabArrToList( Lbs );
  
Lshp.Gol = {'rib' 'ori' 'elo' 'agx'};

LB.Shp = [ Lshp.Scors(:); Lshp.Sfine(:); Lshp.Ras(:); Lshp.Gol(:); ...
           LbPosRgb(:) ];
%LB.Shp = [ Lshp.Scors(:); LbsGen(:) ];
%LB.Shp = [ Lshp.Scors(:); Lshp.Sfine(:); Lshp.Ras(:); LbsGen(:) ];
%LB.Shp = {'vrt' 'hor' 'dg1' 'dg2' 'axi' 'vpo' 'hpo' 'red' 'grn' 'blu'};


%% ----------   tetragon   ---------   
Lttg.Geom = { 'Les'   'Elo'    'Wide'   'High'    'Rhom'  ...
              'Pllo'  'Tria'   'Irrg'   'PlHor'   'PlVrt' ...
              'Ger'   'Wth'
             };
Lttg.Lage = { 'AxVrt'  'AxHor'   'Axial'   'Lean1'  'Lean2'   ...
              'Neig1'  'Neig2'
            };
        
LB.Ttrg = [ Lttg.Geom(:); LbLage(:); Lttg.Lage(:) ];

%% ----------   texture biases   ---------   
% see o_TxtrLabels.m

%% ------------   SubGroups   ---------------
SG.Frm      = Lfrm;
SG.Shp      = Lshp;
SG.Ttg      = Lttg;

%% ------------   DOUBLES   ---------------
LB.Ttg      = LB.Ttrg;
LB.Bnd      = LB.Bndg;


%% ------------------------   Num of Labels   ----------------------
if 0
    aFldNas     =  fieldnames(LS);
    for f = 1:length(aFldNas)
        
        fl       = aFldNas{f};
        fln      = ['n' fl];
        aLabs    = LS.(fl);
        nAtt     = length( aLabs );
        
        LS.(fln) = nAtt;
    end
end



end % MAIN

