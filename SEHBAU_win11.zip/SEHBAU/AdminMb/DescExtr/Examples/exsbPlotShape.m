%
% Demonstrates characterized shapes. Loads a description (does not run an
% image)
%
% Run from WITHIN directory DescExtr/UtilMb/Examples
%
% We assume exsbDscxFull.m has been executed already.
%
clear;
run('../../../AdminMb/globalsSB');        

pthDesc     = '../../../DescExtr/Desc/img1.dsc';       % person
%pthDesc     = '../../Desc/img2.dsc';       % train
%pthDesc     = '../../Desc/aachen.dsc';       % city

[DUV Kt]        = LoadDescUniv(pthDesc);    % in directory 'Vect'
[APIX Nbon SzM] = LoadBonPixSpc( [pthDesc(1:end-4) '.bspx'] );

if Kt.nLev>6, Kt.nLev = 6; end      % limit to 6 levels

[LbAtts, LbAttSG]   = o_AttsLabels();
DUV                 = u_DescMxToStcOfArr( DUV, LbAttSG );

%% -----   Plot Shapes   -----
% we plot boundary pixels, and then colorize them according to attribute
% values
colGray     = [0.8 0.8 0.8];    % default for bounding boxes

hf = figure(1); clf; set(hf, 'name', 'shape'); 
for lev = 1:Kt.nLev
    
    SHPlv = DUV.ASHP{lev};         % extracting one level
    APix  = APIX{lev};
    szM   = SzM(lev,:);

    Scors = SHPlv.STR;
    Sfine = SHPlv.SFI;

    subplot(3, 2, lev); hold on;
    
    % the corresponding boundaries
    nShp = length(SHPlv.IxBon1);
    for b = 1:nShp
        
        ixBon   = SHPlv.IxBon1(b);  % already one-indexing (see loading rout)
        Pix     = APix{ ixBon };    % in (pixel) map coordinates

        hp  = plot( Pix.Cl, Pix.Rw, 'color', colGray );
        
        % extract attributes
        vrtCrs = Scors.Vrt(b);      % verticality coarse
        horCrs = Scors.Hor(b);      % horizontality coarse
        axiCrs = Scors.Axi(b);      % axiality coarse

        vrtFin = Sfine.Vrt(b);      % verticality fine
        horFin = Sfine.Hor(b);      % horizontality fine
        axiFin = Sfine.Axi(b);      % axiality fine
        
        if vrtCrs>0.5, set(hp, 'color', [0.8  0  0]); end % dark red
        if vrtFin>0.5, set(hp, 'color', [1.0  0  0]); end % full red
        
        %if ori==0, set(hp, 'color', [1.0 0 0]); end
        if horCrs>0.5, set(hp, 'color', [0  0.2  0.6]); end % dark blue
        if horFin>0.5, set(hp, 'color', [0  0    1.0]); end % full blue

        if axiCrs>0.5, set(hp, 'color', [0  0.5  0]); end % dark green
        if axiFin>0.5, set(hp, 'color', [0  1.0  0]); end % full green
    end
    
    axis ij;
    set(gca,'xlim',[1 szM(2)]);
    set(gca,'ylim',[1 szM(1)]);
    
end