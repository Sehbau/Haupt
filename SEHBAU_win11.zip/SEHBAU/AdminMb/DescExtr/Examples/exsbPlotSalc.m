%
% Example for loading and plotting the saliency info. 
%
% Run from WITHIN directory DescExtr/UtilMb/Examples
%
% Function scripts in directory 'Vect/'
%
% af cc_Dbas.m
%
clear;
run('../../../AdminMb/globalsSB.m');

pthSalc     = '../../../DescExtr/Desc/img1.slc';       % saliency file
%pthSalc     = '../../Desc/img2.slc';       
%pthSalc     = '../../Desc/aachen.slc';     

Irgb        = imread('../../../DescExtr/Imgs/img1.jpg');

SLC         = LoadDescSalc( pthSalc );  
Txa         = SLC.Txa;
BlbBbx      = SLC.Blb.Box;
Ens         = SLC.Ens;
Shp         = SLC.Shp;

% identify bounding boxes of some blobs
Bnum    = BlbBbx.Typ==1;        % numerous
Bbln    = BlbBbx.Typ==2;        % blank
Benk    = BlbBbx.Typ==8;        % high-contrast

%% ---------------   Salient Regions   ------------------
% taken from cc_Dbas.m
figure(20); clf; [nr nc]=deal(2,3);

% ------   Contours   ------
p_SUBtig(nr,nc,1); imagesc( Irgb ); hold on; p_Cross(128);
axgray;

p_BboxL( BlbBbx.Box( Bnum, :) );
p_BboxL( BlbBbx.Box( Benk, :), [1 0.5 0] ); % orange
%p_BboxL( Blb.Box( Bktc, :), [.2 .2 .2] );
imglabN( 'Cnt Num/Ken ', [nnz(Bnum) nnz(Benk)] );

% ------   Shapes ALL  ------
p_SUBtig(nr,nc,2); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
p_BboxL( Shp.Box );
imglabN( 'ShpAll ', Shp.nBox );

% ------   Shapes HighContrast  ------
BhihCtr  = Shp.Ctr > mean(Shp.Ctr) * 0.66;
BoxHiCtr = Shp.Box( BhihCtr, : );

p_SUBtig(nr,nc,4); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
p_BboxL( BoxHiCtr );
imglabN( 'ShpHiCtr ', size(BoxHiCtr,1));

% ------   Shapes HighCrowdedness  ------
BhihCwd  = Shp.Cwd > 8; % mean(Shp.Cwd) * 0.66;
BoxHiCwd = Shp.Box( BhihCwd, : );

p_SUBtig(nr,nc,3); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
p_BboxL( BoxHiCwd );
imglabN( 'ShpCwd ', size(BoxHiCwd,1));

% ------   Shapes Large  ------
[V Ord] = sort( Shp.Cvg, 'descend');
%Blrg    = Shp.Cvg > mean(Shp.Cvg) * 1.2;
nSel    = min( length(Ord), 35 );
BoxLrg  = Shp.Box( Ord(1:nSel), : );

p_SUBtig(nr,nc,5); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
p_BboxL( BoxLrg );
imglabN( 'ShpLrg ', size(BoxLrg,1));

% ------   Spots   -------
p_SUBtig(nr,nc,6); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
nSel    = min( 5, Txa.Spt.Px.nCo );
p_VisSearch( Txa.Spt.Px.Pt(1:nSel,:) );
imglabN( 'Spots ', nSel);

%% ------------------    Ensemble   --------------------
% 
figure(21); clf; [nr nc]=deal(1,2);

% ------   All   ------
p_SUBtig(nr,nc,1); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
p_BboxL( Ens.Box );
imglabN( 'EnsAll', Ens.nBox );

% ------   G to L   -------
p_SUBtig(nr,nc,2); imagesc( Irgb ); hold on; p_Cross(128);
axgray;
Ix      = Ens.OrdGtoL.Ix;
BoxGtoL = Ens.Box( Ix, :);
p_BboxL( BoxGtoL, 'var' );
imglabN( 'GtoL ', size(BoxGtoL,1));
