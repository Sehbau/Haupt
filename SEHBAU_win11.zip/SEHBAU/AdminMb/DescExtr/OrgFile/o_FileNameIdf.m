%
% Identifiers of image or collection filenames.
% Identifier can be located anywhere in a filename.
%
% ia Fidf  = o_FileNameIdf()
%
function [S] = o_FileNameIdf()

S.vocSeg    = 'VocSeg';     % for segments
S.vocTxt    = 'VocTxt';     % for texture

end




