%
% Filepaths/names for measurement files of program mvec.
%
% sa o_MvecAdmin.m
%
% IN   ppndPth    [optional] prepend a path or string
%
% USE 
% - for filestems only. No directory name prepended
%           FinaMes  = o_FileNameMvec( );     
%
% - for fixed finas/paths. Prepends directory 'Mes/'
%           FinaMes  = o_FileNameMvec( 1 );     
%
% - for user-defined finas. Prepends mesFil12:  
%           mesFil12 = 'Mes/Txt12';
%           Fina12   = o_FileNameMvec( mesFil12 );  
%
% sa o_FileNames
% 
function [S] = o_FileNameMvec( ppndPth )

%%          mvec1
% these are fixed (constant)
S.vecDtyDis     = 'MesDtyDis.txt';
S.vecDtySim     = 'MesDtySim.txt';

if nargin==0,       % if no path provided,      
    return;         % then return
end

%% ---------   prepend path   --------
if ischar( ppndPth )
    % we assume ppndPth is given
elseif isnumeric( ppndPth )
    if ppndPth>0
        ppndPth = 'Mes/';           % change to directory 'Mes/'
    else
        return;                     % user specified 0 (or less)
    end
else
    error('input %s not implemented', ppndPth );
end

aFldNa   = fieldnames( S );
nFldNa   = length( aFldNa );

for f = 1:nFldNa
    fn      = aFldNa{f};
    S.(fn)  = [ ppndPth S.(fn) ];
end

end




