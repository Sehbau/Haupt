%
% More file extensions, in particular features.
%
function [E] = o_FileExtensFeat()

E.regApp       = '.regAPP'; % should be under description (not features)
E.regHstRed    = '.regHSTred';
E.regHstGrn    = '.regHSTgrn';
E.regHstBlu    = '.regHSTblu';



