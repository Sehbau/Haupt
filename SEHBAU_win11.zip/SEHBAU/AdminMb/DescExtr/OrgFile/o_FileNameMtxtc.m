%
% Filepaths/names for measurement files outputted by executable mtxtc
% (matching a collection).
%
% sa o_FileNameMtxt1.m
%
% IN   ppndPth    [optional] prepend a path or string
%
% USE 
% - for filestems only. No directory name prepended
%           FinaMes  = o_FileNameMtxt( );     
%
% - for fixed finas/paths. Prepends directory 'Mes/'
%           FinaMes  = o_FileNameMtxt( 1 );     
%
% - for user-defined finas. Prepends mesFil12:  
%           mesFil12 = 'Txt12';
%           Fina12   = o_FileNameMtxt( 1, mesFil12 );  
%
% sa o_FileNames, o_FileNameMvec, etc.
% 
function [S] = o_FileNameMtxtc( ppndPth, fidfUser )

% these are fixed (constant) 
S.txtGridBis    = 'TxtrGridBis.txt';
S.txtBand       = 'TxtrBand.txt';       % ???? overwritten below!
%S.txtBandSnk    = 'TxtrBandSnk.txt';
%S.txtBandWag    = 'TxtrBandWag.txt';

S.frklLay       = 'TxtrFrklLay.txt';
S.frklGrt       = 'TxtrFrklGrt.txt';
S.frklSnk       = 'TxtrFrklSnk.txt';
S.frklWag       = 'TxtrFrklWag.txt';

% suffixes. appended to user-defined filestem (is default covered?)
S.txtGrid       = 'Grid.txt';
S.txtBand       = 'Band.txt';
S.txtBlob       = 'BlobBbx.txt';

if nargin==0,       % if no path provided,      
    return;         % then return
end

%% ---------   prepend filestem identifier   --------
if nargin==2
    S.txtGrid = [ fidfUser S.txtGrid ];
    S.txtBand = [ fidfUser S.txtBand ];
    S.txtBlob = [ fidfUser S.txtBlob ];
    S.fidfUser = fidfUser;
end

%% ---------   prepend path   --------
if ischar( ppndPth )
    % we assume ppndPth is given
elseif isnumeric( ppndPth )
    if ppndPth>0
        ppndPth = 'Mes/';           % change to directory 'Mes/'
    else
        return;                     % user specified 0 (or less)
    end
else
    error('input %s not implemented', ppndPth );
end

aFldNa   = fieldnames( S );
nFldNa   = length( aFldNa );

for f = 1:nFldNa
    fn      = aFldNa{f};
    S.(fn)  = [ ppndPth S.(fn) ];
end

end




