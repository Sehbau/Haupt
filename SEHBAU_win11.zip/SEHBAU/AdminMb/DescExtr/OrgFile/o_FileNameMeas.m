function [S] = o_FileNameMeas( ppndPth )

error('deprecated');

end




