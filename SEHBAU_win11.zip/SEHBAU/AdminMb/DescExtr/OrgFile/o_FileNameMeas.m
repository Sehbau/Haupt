%
% Filepaths/names for measurement files.
%
% IN   ppndPth    [optional] prepend a path or string
%
% USE 
% - for filestems only. No directory name prepended
%           FinaMes  = o_FileNameMeas( );     
%
% - for fixed finas/paths. Prepends directory 'Mes/'
%           FinaMes  = o_FileNameMeas( 1 );     
%
% - for user-defined finas. Prepends mesFil12:  
%           mesFil12 = 'Mes/Txt12';
%           Fina12   = o_FileNameMeas( mesFil12 );  
%
% sa o_FileNames
% 
function [S] = o_FileNameMeas( ppndPth )

%%          Mtch Vec (mvec1)
% these are fixed (constant)
S.vecDtyDis     = 'MesDtyDis.txt';
S.vecDtySim     = 'MesDtySim.txt';

%%          Mtch Txt (mtxt1)
% these are fixed (constant) 
S.txtGridBis    = 'TxtGridBis.txt';
S.txtBandSnk    = 'TxtBandSnk.txt';
S.txtBandWag    = 'TxtBandWag.txt';
S.txtNNMsRow    = 'Txt1NNMsRow.txt';
S.txtNNIxRow    = 'Txt1NNIxRow.txt';

% suffixes. appended to user-defined filestem (is default covered?)
S.txtGrid       = 'Grid.txt';
S.txtBand       = 'Band.txt';
S.txtBlob       = 'Blob.txt';

if nargin==0,       % if no path provided,      
    return;         % then return
end

%% ---------   prepend path   --------
if ischar( ppndPth )
    % we assume ppndPth is given
elseif isnumeric( ppndPth )
    if ppndPth>0
        ppndPth = 'Mes/';           % change to directory 'Mes/'
    else
        return;                     % user specified 0 (or less)
    end
else
    error('input %s not implemented', ppndPth );
end

aFldNa   = fieldnames( S );
nFldNa   = length( aFldNa );

for f = 1:nFldNa
    fn      = aFldNa{f};
    S.(fn)  = [ ppndPth S.(fn) ];
end

end




