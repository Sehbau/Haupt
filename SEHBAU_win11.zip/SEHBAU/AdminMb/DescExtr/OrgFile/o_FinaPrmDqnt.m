%
% Generates parameter filenames for program dqnt.
%
function [aF] = o_FinaPrmDqnt( idf, dty )

error('depcecated');

if nargin==1
    error('either no or two parameters');
end

if nargin==0
    [aDty nDty] = o_DescTypes( 'cfasshp' );
else
    if dty==5
        [aDty nDty] = o_DescTypes( 'cfasshp' );
    end
end

    
aF = cell(nDty,1);

if nargin==0
    
    for d = 1:nDty
        aF{d} = sprintf('Params/PrmDqnt_%s.txt', aDty{d} );
    end

elseif nargin==2
    
    for d = 1:nDty
        aF{d} = sprintf('Params/PrmDqnt_%s_%s.txt', aDty{d}, idf );
    end
end
