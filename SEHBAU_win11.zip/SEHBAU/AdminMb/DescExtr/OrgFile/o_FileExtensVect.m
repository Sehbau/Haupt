%
% File extensions for vector types and quants.
%
% sa o_FileExtensions.m
%    o_DescTypes.m
%
function [E nExt] = o_FileExtensVect()

E.cnt  = '.vecCnt';
E.frm  = '.vecFrm';
E.arc  = '.vecArc';
E.str  = '.vecStr';
E.shp  = '.vecShp';

E.bnd  = '.vecBnd';
E.ttg  = '.vecTtg';

E.vec    = '.vec';  % never deployed I think
E.vbn    = '.vbn';  % never deployed I think
E.lev    = '.lev';  % never deployed I think

E.qntCod = '.qcd';
E.qntDix = '.dix';
E.qntHst = '.qst';

E.aFna = fieldnames( E );
E.n    = length( E.aFna );

% as arrays without dot
E.aVec  = {'vecCnt' 'vecFrm' 'vecArc' 'vecStr' 'vecShp'...
           'vecTtg' 'vecBnd' };

E.aVbn  = {'vbnCnt' 'vbnFrm' 'vbnArc' 'vbnStr' 'vbnShp'...
           'vbnTtg' 'vbnBnd' };

E.aLev  = {'levCnt' 'levFrm' 'levArc' 'levStr' 'levShp'...
           'levTtg' 'levBnd' };
      
E.aQntVal  = {'qnvCnt' 'qnvFrm' 'qnvArc' 'qnvStr' 'qnvShp'...
              'qnvTtg' 'qnvBnd' };

nExt = length( E.aVec );      
