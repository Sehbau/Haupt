%
% Filepaths/names for measurement files outputted by executable Mtxt.
%
% IN   ppndPth    [optional] prepend a path or string
%
% USE 
% - for filestems only. No directory name prepended
%           FinaMes  = o_FileNameMtxt( );     
%
% - for fixed finas/paths. Prepends directory 'Mes/'
%           FinaMes  = o_FileNameMtxt( 1 );     
%
% - for user-defined finas. Prepends mesFil12:  
%           mesFil12 = 'Txt12';
%           Fina12   = o_FileNameMtxt( 1, mesFil12 );  
%
% sa o_FileNames, o_FileNameMvec, etc.
% 
function [S] = o_FileNameMtxt1( ppndPth, fidfUser )

% these are fixed (constant) 
S.txtGridBis    = 'Txt1GridBis.txt';
S.txtBandSnk    = 'Txt1BandSnk.txt';
S.txtBandWag    = 'Txt1BandWag.txt';

S.frklLay       = 'Txt1FrklLay.txt';
S.frklGrt       = 'Txt1FrklGrt.txt';
S.frklSnk       = 'Txt1FrklSnk.txt';
S.frklWag       = 'Txt1FrklWag.txt';

S.NNMsRow       = 'Txt1NNMsRow.txt';
S.NNIxRow       = 'Txt1NNIxRow.txt';

% suffixes. appended to user-defined filestem (is default covered?)
S.txtGrid       = 'Grid.txt';
S.txtBand       = 'Band.txt';
S.txtBlob       = 'BlobBbx.txt';

if nargin==0,       % if no path provided,      
    return;         % then return
end

%% ---------   prepend filestem identifier   --------
if nargin==2
    S.txtGrid = [ fidfUser S.txtGrid ];
    S.txtBand = [ fidfUser S.txtBand ];
    S.txtBlob = [ fidfUser S.txtBlob ];
    S.fidfUser = fidfUser;
end

%% ---------   prepend path   --------
if ischar( ppndPth )
    % we assume ppndPth is given
elseif isnumeric( ppndPth )
    if ppndPth>0
        ppndPth = 'Mes/';           % change to directory 'Mes/'
    else
        return;                     % user specified 0 (or less)
    end
else
    error('input %s not implemented', ppndPth );
end

aFldNa   = fieldnames( S );
nFldNa   = length( aFldNa );

for f = 1:nFldNa
    fn      = aFldNa{f};
    S.(fn)  = [ ppndPth S.(fn) ];
end

end




