%
% o_FileExtensXXX    for file extensions
%
% o_FileNameXXX      for file names
% o_FileNameFrmt     name format, ie. '1' or '000001' 
%
% o_FileStems.m      for filestems for one image
%
% o_FileNameIdf.m    for filename identifiers
% 





