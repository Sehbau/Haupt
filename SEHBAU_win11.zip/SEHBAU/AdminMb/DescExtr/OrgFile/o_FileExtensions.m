%
% File extensions with two output structures: one for description of image
% and one for focus. Use o_FinaApndExtDscx to generate a struct holding all
% filenames with those extensions. For filenames see o_FileNames().
%
% USE Fixt     = o_FileExtensions();
%     fpDSC    = o_FinaApndExtDscx( pthOut, Fixt ); 
%     u_FipaDateExt( fpDSC )   displays date for all files
%
% from struct stuFileExtn in FileNameDesc.h
%
function [D F] = o_FileExtensions()

%% -------------   IMAGE   ---------------

% -----  image 
D.dsc    = '.dsc';
D.dsbi   = '.dsb';
D.hsti   = '.hst';
%D.utzi   = '.utz';		% utilities (deployed yet?)

D.kol    = '.kol';		% kolumns
D.txm    = '.txm';		% texture maps
D.slc    = '.slc';		% saliency 

D.qbbx   = '.qbbx';		% proposals bbox
D.qdsc   = '.qdsc';		% proposals descriptors

% -----  descriptors
D.rre    = '.rre';      % RRE space (full set)
D.cvpf   = '.cvpf';		% curve partitions, full set
D.cvpo   = '.cvpo';		% curve partitions organization (deployed yet?)
D.cvps   = '.cvps';     % shape: sgrrgb
D.form   = '.form';		% form
D.cntPat = '.cntPat';

% -----  features
%D.cuv    = '.cuv';      % contour segment space 
D.cuvKpt = '.cuvKpt';
D.ruv    = '.ruv';      % region universe (LoadRegUnv.m)
D.bspx   = '.bspx';     % boundary space pixels
D.bsd    = '.bsd';

D.bonBbxRaw = '.bonBboxRaw'; % s_FunvBboxAll, ai dscx.cpp
D.bonBbx    = '.bonBbox';  % s_BonBboxPyr
D.bonAsp    = '.bonAsp';
D.bonPix    = '.bonPix';   % s_BonPixSegw, ai sgrRGB.cpp

% -----  shape
D.shp    = '.shp';

% -----  collection/conversion
D.collHst = '.hstc';    % attribute histogram collection (collHimg)
D.collTxt = '.htxc';    % texture histogram collection (collSalc)
D.hari    = '.hari';    % Hst-Of-Att as array for image
D.vbnmx   = '.vbnmx';
D.qnt     = '.qnt';

% -----  maps
D.mapUch  = '.mpu';

%% -------------   FOCUS   ---------------
F.dscf   = '.dsf';
F.hstf1  = '.hsf1'; 	% fochst1.cpp
F.hstfL  = '.hsfL';

% -----   conversion
F.harf   = '.harf';    % Hst-Of-Att as array for focus





