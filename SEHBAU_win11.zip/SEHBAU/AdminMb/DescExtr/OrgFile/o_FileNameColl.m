%
% Filepaths/names of collected description.
%
% USE 1
%      FinaSB  = o_FileNameColl();    will return only filename stems
% USE 2 
%      [Pths Jcoll]    = u_CollPaths( dbas );
%      Fixt            = o_FileExtensions();
%      Finas           = o_FileNameColl( Pths, Fixt );
%
function [S] = o_FileNameColl( Pths, Fixt )

% filestem histograms
S.hist          = 'HST_ATT'; % binary file created in Sb
S.txtr          = 'HST_TXT'; % binary file created in Sb
S.qust          = 'HST_QNT'; % mat file

if nargin==0, 
    return; 
end

% -----  Filestems  -----
S.salcFs        = [ Pths.Hist  S.txtr ];
S.histFs        = [ Pths.Hist  S.hist ];


% -----  Full Filepaths  -----
S.salc          = [ S.salcFs    Fixt.collTxt ];
S.hist          = [ S.histFs    Fixt.collHst ];
S.qust          = [ Pths.Hist   S.qust ];       % was saved as mat file

end




