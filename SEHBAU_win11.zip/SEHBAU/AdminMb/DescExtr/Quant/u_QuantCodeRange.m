%
% Simple quant code stats.
%
% cf iclQntVoc.m
%
function [St] = u_QuantCodeRange( Qvoc )

St.nWords   = length(Qvoc);
St.minV     = min(Qvoc);
St.maxV     = max(Qvoc);

fprintf('Qvoc, size %d   min-max  %d-%d\n', ...
    St.nWords, St.minV, St.maxV );  

end % MAIN


