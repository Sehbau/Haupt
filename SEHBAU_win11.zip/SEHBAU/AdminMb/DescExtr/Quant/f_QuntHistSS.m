%
% Calculates histograms of quants for a subspace (of ONE desctype)
%
% IN   BFLL   full attribute space, as loaded by LoadDescVebn
%      jSS    administrative struct for subspace selection
%      QSS    quant ids
% OUT  Qst    quistogram
%
function Qst = f_QuntHistSS( BFLL, jSS, QSS )

% --- selects subspace [nVec nAss]
BSUS    = f_AttSpcSub( BFLL, jSS.dty, jSS.id, jSS.LbAtt );
    
% --- subspace to quant id
Qid     = f_QuntValMx( BSUS.BIN, QSS.HashBase, QSS.QntHsh );

% --- qistogram
Qst     = single( histcounts( Qid, QSS.nQnt ) );
            
end






