%
% Version 1, where position is loaded for each call of subgroup. Not
% efficient.
%
function [ S ] = f_VocabImgV1( GSS, IxBeg, Admin, ffst )

Args        = o_CmndArgs('dqnt');
pthOut      = u_PathToBackSlash( Admin.pthOut ); 

Fidf        = o_FileNameIdf();
Fixt        = o_FileExtensVect();

AttsLabR    = o_AttsLabels();
AttsLabB    = o_AttsLabBin();
IXREAL      = o_AttIxAsFields( AttsLabR, 1 );
IXBIND      = o_AttIxAsFields( AttsLabB, 1 );

S.Img       = [];
S.PosBin    = uint8([]);
S.PosRel    = [];
S.Lev       = uint8([]);
S.AQst      = cell( GSS.ntGrp, 1 );

for g = 1:GSS.ntGrp
    
    jGrp.fina   = GSS.aFina{ g };
    jGrp.lab    = GSS.aLab{ g };
    
    Args.fpPrm  = [ '../DescUtil/Vocab/' jGrp.fina ];
    Args.fpVoc  = [ 'Vocab/' Fidf.vocSeg '_' jGrp.lab '.txt' ];
    
    if ~exist( Args.fpVoc, 'file' )
        fprintf('vocab %s does not exist\n', Args.fpVoc );
        continue;
    end
    
    [dty idSS]  = u_QuantGroupName( jGrp.fina );
    fpDsb       = [ ffst '.vbn' dty ];
    
    % ===========   Execute   ==========
    StdOut      = RennDqnt( fpDsb, pthOut, Args, Admin.pthExe );
    
    if Admin.ixi==1 && g==1,
        pso_OptUnrec(StdOut);
        StdOut
    end
    
    % -----------   Load Dix  ----------
    % dictionary indices
    lfn         = [ pthOut Fixt.qntDix dty ];
    [Dix HedDx] = LoadQuantArr( lfn );
    nDix        = HedDx.nQnt;
    
    if Admin.ixi==1 && g==1, DispLoad( lfn ); end
    
    % identify found quants
    if any( Dix==-1 )
        fprintf('Unknown quants present\n');
    end
    Bvld        = Dix > -1;         % valid (actual) words
    
    BixGrp      = Dix(Bvld)'+IxBeg(g); % book indices
    
    % -----------   Load Qst  ----------
    % quistograms (hist-of-quants)
    lfn         = [ pthOut Fixt.qntHst dty ];
    [Qst nHbin] = LoadArrIntTxt( lfn );
    
    S.AQst{g}   = Qst;      % collect the histograms
    
    
    % -----------------------   POS & LEVEL   --------------------
    % Position and levels. Three separate files.
    % Position is in vector matrix.
    
    % -----------   Load Bind Vmx  ----------
    [VBN Dim]   = LoadDescVebn( fpDsb );
    
    VBN         = VBN(Bvld,:);      % take only valid ones
    PsvB        = VBN(:,IXBIND.(dty).psv);
    PshB        = VBN(:,IXBIND.(dty).psh);
    PosBinGrp   = [PsvB PshB];

    assert( nDix==Dim.nDsc );
    
    % -----------   Load Real Vmx  ----------
    fpVmx       = [ ffst '.vec' dty ];
    [VMX Dim]   = LoadDescVect( fpVmx, 0 );
    
    VMX         = VMX(Bvld,:);      % take only valid ones
    PsvR        = VMX(:,IXREAL.(dty).psv);
    PshR        = VMX(:,IXREAL.(dty).psh);
    PosRelGrp   = [PsvR PshR];
    
    assert( nDix==Dim.nDsc );
    
    % -----------   Load LevelFile  ----------
    % holds the indices to the levels
    fpLev       = [ ffst '.lev' dty ];
    [Lev nDsc2] = LoadDescVectLev( fpLev, 0 );
    LevGrp      = Lev(Bvld);
    
    % -----------   Select   ---------------
    %Bsel        = Lev > 1;
    %PosRelGrp   = PosRelGrp( Bsel, : );
    %WrdGrp      = WrdGrp( Bsel );
    
    % ------------   Append to total   ------------
    S.Img       = [S.Img BixGrp];
    S.PosBin    = [S.PosBin; uint8(PosBinGrp)];
    S.PosRel    = [S.PosRel; PosRelGrp];
    S.Lev       = [S.Lev; uint8(LevGrp)];
end

S.ntQnt     = length( S.Img );

end

