%
% Saves the attribute subspace indices as parameter file for executable
% dqnt.
%
function [] = SaveAttSSIxAsPrmFile( aIx, aLb, labGrp, sfp )

fid     = fopen(sfp, 'wt' );

if fid==-1
    error('Could not open file %s', sfp );
end

% ----------   Comment Block   -------------
fprintf( fid, '#\n' );
fprintf( fid, '# %s\n', labGrp );
fprintf( fid, '#\n' );

% ----------   Index Values   -------------
nIx    = length( aIx );
for i = 1:nIx
    fprintf( fid, '%d ', aIx(i) );
end
fprintf( fid, '\n' );

% ----------   Attribute Labels   -------------
fprintf( fid, '#' );
for i = 1:nIx
    fprintf( fid, '%s ', aLb{i} );
end
fprintf( fid, '\n' );

fclose(fid);

fprintf('Written %s\n', sfp );

end % MAIN


