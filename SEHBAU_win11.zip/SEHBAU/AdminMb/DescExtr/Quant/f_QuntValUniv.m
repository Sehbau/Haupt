%
% Generates quant id for the descriptor types of an entire image.
%
% cf plcQntHist.m
% fka f_HashBinImg
%
% IN  VEB   struct with VEB for each desctype
%     Q     quant universe
% OUT V     quant ids
%
function V = f_QuntValUniv( VEB, Q )

V.Cnt  = f_QuntValMx( VEB.Cnt, Q.CNT.HashBase, Q.CNT.QntHsh );
V.Frm  = f_QuntValMx( VEB.Frm, Q.FRM.HashBase, Q.FRM.QntHsh );
V.Arc  = f_QuntValMx( VEB.Arc, Q.ARC.HashBase, Q.ARC.QntHsh );
V.Str  = f_QuntValMx( VEB.Str, Q.STR.HashBase, Q.STR.QntHsh );
V.Shp  = f_QuntValMx( VEB.Shp, Q.SHP.HashBase, Q.SHP.QntHsh );

%V.Crm  = f_HashVbnMx( VEB.Crm, Q.CRM.HashBase, Q.CRM.QntHsh );
    
end






