%
% Generates hash values (Val) for a matrix of binvectors.
%
% fka f_HashVbnMx, Consider renaming to f_VebToQntId | f_QntIdVmx
%
% cf plcQntHist.m, iclQntHist.m, qntApply.m
% 
% IN  VBN     matrix of binvectors [nVec nAtt], the keys
%     Base    hash base [1 nAtt], ie. [1 12 144] (as row vector)
%     HashQnt hash of quants [1 nQnts]
% OUT Val     the value [nVec 1]
%
function Val = f_QuntValMx( VBN, Base, HashQnt )

if isrow(Base)==0
    Base
    error('Hash base is not a row vector');
end

HashVec     = single( VBN ) * Base';

[tf, Val]   = ismember( HashVec, HashQnt );

% Convert 0 (not found) to NaN
Val(~tf)    = NaN;
    
end






