%
% The groups of attribute subspaces used for quants in iclDqnt.m The full
% set of labels is in o_AttsLabBin.m
%
% af f_AttSpcSubSelIdf.m
%
%
% cf quantInit.m, iclQntVoc.m
%
function [IX G] = o_QntSubSpcGrps()

[FLL SG]  	= o_AttsLabBin();
bIxMode     = 0;

%% ----------------   Contours   ------------------
% o_AttsLabBin.m
G.Cnt.Geo       = { 'len' 'ori' };
G.Cnt.Geox      = { 'len' 'ori' 'str' };
%G.Cnt.GeoPosV   = { G.Cnt.Geo{:} 'psv' };       % position vertical only
%G.Cnt.GeoPosVH  = { G.Cnt.Geo{:} 'psv' 'psh' }; % position vert & horz

IX.Cnt          = ff_AttIxSus( G.Cnt, FLL.Cnt, bIxMode ); % below


%% ----------------   Forms   ------------------
G.Frm.Cir       = { 'rad' 'cir'};
G.Frm.Geo       = { 'rad' 'elo' 'ori'};
G.Frm.Geob      = { 'rad' 'elo' 'ori' 'blk'};
G.Frm.RAE       = { 'rad' 'AreN' 'elo'};
%G.Frm.GeoPosV   = { G.Frm.Geo{:} 'psv' };       % position vertical only
%G.Frm.GeoPosVH  = { G.Frm.Geo{:} 'psv' 'psh' }; % position vert & horz

G.Frm           = uu_LabComb1vsM( G.Frm, 'AreN', 'Ar', SG.Frm.Asp(2:end) );

IX.Frm          = ff_AttIxSus( G.Frm, FLL.Frm, bIxMode ); 


%% ----------------   Arc   ------------------
G.Arc.Geo       = { 'les' 'krv' 'dir'};
G.Arc.Geox      = { 'les' 'krv' 'dir' 'spz'};
G.Arc.GeoE      = { 'les' 'krv' 'dir' 'eck'};
G.Arc.GeoR      = { 'les' 'krv' 'dir' 'run'};
%G.Arc.GeoPosV   = { G.Arc.Geo{:} 'psv' };       % position vertical only
%G.Arc.GeoPosVH  = { G.Arc.Geo{:} 'psv' 'psh' }; % position vert & horz

IX.Arc          = ff_AttIxSus( G.Arc, FLL.Arc, bIxMode ); 


%% ----------------   Str   ------------------
G.Str.Geo       = { 'les' 'ori' };
G.Str.Geox      = { 'les' 'ori' 'str' };
%G.Str.GeoPosV   = { G.Str.Geo{:} 'psv' };       % position vertical only
%G.Str.GeoPosVH  = { G.Str.Geo{:} 'psv' 'psh' }; % position vert & horz

IX.Str          = ff_AttIxSus( G.Str, FLL.Str, bIxMode ); % below


%% ----------------   Shape   ------------------
G.Shp.RE        = { 'Rad' 'Elo' };
G.Shp.REO       = { 'Rad' 'Elo' 'Ori' };
G.Shp.RV        = { 'Rad' 'Vrt' };
G.Shp.RH        = { 'Rad' 'Hor' };
G.Shp.RVH       = { 'Rad' 'Vrt' 'Hor' };

IX.Shp          = ff_AttIxSus( G.Shp, FLL.Shp, bIxMode ); % below


%% ----------------   Bundles   ------------------
G.Bnd.LO        = { 'len' 'ori' };
G.Bnd.LOA       = { 'len' 'ori' 'agx'};

IX.Bnd          = ff_AttIxSus( G.Bnd, FLL.Bnd, bIxMode ); % below

%% --------------------------   Abschluss   ------------------------
aFldNam         = fieldnames( G );
aFldIX          = fieldnames( IX );
nDty            = length(aFldNam);

if nDty~=length(aFldIX)
    aFldNam
    aFldIX
    error('nFields (desctypes) not matching');
end

IX.aDty     = aFldNam;
IX.nDty     = nDty;

end % MAIN


%% -----------------------   ff_AttIxSus   ---------------------
%
% u_AttIxFromLab for a list of subspaces in D.
% 
function Ix = ff_AttIxSus( L, aFll, bIxMode )

aNaSus      = fieldnames(L);
nSus        = length( aNaSus );

for f = 1:nSus
    sus     = aNaSus{f};
    
    Ix.(sus) = u_AttIxFromLab( L.(sus), aFll, bIxMode );
end

Ix.aSus     = aNaSus;
Ix.nSus     = nSus;
Ix.Ix       = (1:nSus)';

end % SUB

%% ----------------------   uu_LabComb1vsM   ------------------------
%
% Adds new labels to struct S.
%
function S = uu_LabComb1vsM( S, lab1, labSho, aOth )

nLb     = length( aOth );
for l = 1:nLb
    fn      = [ labSho aOth{l} ];
    S.(fn)  = { lab1 aOth{l} };
end

end