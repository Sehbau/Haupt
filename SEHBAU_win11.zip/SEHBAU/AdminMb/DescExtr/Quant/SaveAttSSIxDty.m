%
% Saves subspace indices for a list of groups for ONE descriptor type.
%
% cf quantInit.m, iclDqnt.h
%
function [S] = SaveAttSSIxDty( IXUNV, GUNV, dty, pth, bSave )

Grp     = IXUNV.(dty);
Lab     = GUNV.(dty);

aSus        = Grp.aSus;
S.aFina     = cell( Grp.nSus, 1);
S.aLab      = cell( Grp.nSus, 1);
S.aLabPlot  = cell( Grp.nSus, 1);
S.nSus      = Grp.nSus;
for g = 1:Grp.nSus

    sus         = aSus{g};
    
    labG        = sprintf( '%s_%s', dty, sus );
    labPlot     = sprintf( '%s %4s', dty, sus );
    fina        = sprintf( 'PrmDqnt_%s.txt', labG );

    S.aFina{g}  = fina;
    S.aLab{g}   = labG;
    
    
    S.aLabPlot{g} = labPlot;
    
    if bSave
        sfp     = [ pth fina ];
        SaveAttSSIxAsPrmFile( Grp.(sus), Lab.(sus), labG, sfp );
    end
end

S.Ix    = (1:Grp.nSus)';

end % MAIN


