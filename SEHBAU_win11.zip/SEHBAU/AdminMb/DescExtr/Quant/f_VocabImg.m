%
% Vocabulariztation of bin-vectors for an image using executable 'dqnt' and
% creating book index for each quant. Position and level index are provided
% as argument. For unknown quants, their values will be excluded.
%
function [ S ] = f_VocabImg( GSS, IxBeg, Admin, ffst, PosDunv )

Args        = o_CmndArgs('dqnt');
pthOut      = u_PathToBackSlash( Admin.pthOut ); 

Fidf        = o_FileNameIdf();
Fixt        = o_FileExtensVect();

%AttsLabR    = o_AttsLabels();
%AttsLabB    = o_AttsLabBin();
%IXREAL      = o_AttIxAsFields( AttsLabR, 1 );
%IXBIND      = o_AttIxAsFields( AttsLabB, 1 );

S.Img       = [];
S.PosBin    = uint8([]);
S.PosRel    = [];
S.Lev       = uint8([]);
S.AQst      = cell( GSS.ntGrp, 1 );

for g = 1:GSS.ntGrp
    
    jGrp.fina   = GSS.aFina{ g };
    jGrp.lab    = GSS.aLab{ g };
    
    Args.fpPrm  = [ '../DescUtil/Vocab/' jGrp.fina ];
    Args.fpVoc  = [ 'Vocab/' Fidf.vocSeg '_' jGrp.lab '.txt' ];
    
    if ~exist( Args.fpVoc, 'file' )
        fprintf('vocab %s does not exist\n', Args.fpVoc );
        continue;
    end
    
    [dty idSS]  = u_QuantGroupName( jGrp.fina );
    fpDsb       = [ ffst '.vbn' dty ];
    
    % ===========   Execute   ==========
    StdOut      = RennDqnt( fpDsb, pthOut, Args, Admin.pthExe );
    
    if Admin.ixi==1 && g==1,
        pso_OptUnrec(StdOut);
        StdOut
    end
    
    % -----------   Load Dix  ----------
    % dictionary indices
    lfn         = [ pthOut Fixt.qntDix dty ];
    [Dix HedDx] = LoadQuantArr( lfn );
    nDix        = HedDx.nQnt;
    
    if Admin.ixi==1 && g==1, DispLoad( lfn ); end
    
    % identify found quants
    if any( Dix==-1 )
        fprintf('Unknown quants present\n');
    end
    Bvld        = Dix > -1;         % valid (actual) words
    
    % ===========   Book Index   ==========
    BixGrp      = Dix(Bvld)' + IxBeg(g); 
    
    % -----------   Load Qst  ----------
    % quistograms (hist-of-quants)
    lfn         = [ pthOut Fixt.qntHst dty ];
    [Qst nHbin] = LoadArrIntTxt( lfn );
    
    S.AQst{g}   = Qst;      % collect the histograms
    
    
    % -----------------------   POS & LEVEL   --------------------
    % now we extract the valid ones
    PosBinGrp   = PosDunv.PosBin.(dty)(Bvld,:);
    PosRelGrp   = PosDunv.PosRel.(dty)(Bvld,:);
    LevGrp      = PosDunv.Lev.(dty)(Bvld);
    
    % -----------   Select   ---------------
    %Bsel        = Lev > 1;
    %PosRelGrp   = PosRelGrp( Bsel, : );
    %WrdGrp      = WrdGrp( Bsel );
    
    % ------------   Append to total   ------------
    S.Img       = [S.Img BixGrp];
    S.PosBin    = [S.PosBin; uint8(PosBinGrp)];
    S.PosRel    = [S.PosRel; PosRelGrp];
    S.Lev       = [S.Lev; uint8(LevGrp)];
end

S.ntQnt     = length( S.Img );

end

