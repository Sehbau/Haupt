%
% Quant subspace groupname from its filename.
%
% cf iclQntVoc.m
%
% IN   fina   filename, ie. PrmDqnt_Str_Geo.txt
%
function [dty idSS] = u_QuantGroupName( fina )

dty         = fina(9:11);

ixDot       = strfind( fina, '.' );

idSS        = fina( 13:ixDot-1 );

end % MAIN


