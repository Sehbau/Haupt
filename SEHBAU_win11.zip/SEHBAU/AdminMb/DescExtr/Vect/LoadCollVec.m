%
% Loads collected vectors (of MULTIPLE images) as saved under collVec.cpp.
%
% sa LoadDescVect.m, LoadVecColl.m
%
% Example in exsbCollVec.m
%
function [VEC ntDsc nDim] = LoadCollVec( lfpStem, dscTyp )

lfp = [ lfpStem 'VEC_' dscTyp '.txt' ];

% VEC = LoadTextLineWise( fpVec );

fileID      = fopen( lfp, 'rt');

if fileID==-1, 
    error('could not find %s', lfp); 
end

VEC     = fscanf( fileID, '%f' );   % read as entire block

fclose( fileID );

DispLoad(lfp);

%% -------   Last array entry contains ntDsc   -------
ntDsc = int32( VEC(end) );
fprintf('ntDsc %d, ', ntDsc );

%% -------    Reshape   -------
VEC(end) = [];              % exclude the last array entry
VEC     = single( VEC );    % save on memory

VEC     = reshape( VEC, [], ntDsc );
VEC     = VEC';

nDim    = size(VEC,2);

fprintf('matrix is [%d %d].\n', ntDsc, nDim );


