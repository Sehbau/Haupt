%
% Reads line pattern as vector matrix, as saved under PatIO.h-wt_PatLin
%
% cf LoadPatLinVmx.m
%
function [S] = ReadPatLinVmx(fileID)

S = [];

% ------------   Header   --------------
S.nLin   = fscanf( fileID, '%d', 1 );          % num of lines
S.nAtt   = fscanf( fileID, '%d', 1 );          % num of attributes

% ------------   Data   --------------
S.VEC    = fscanf( fileID, '%f', S.nLin*S.nAtt );

% reshape data
S.VEC    = reshape( S.VEC, S.nAtt, S.nLin )';

end

