%
% Loads the quants for one image.
%
% cf iclCollQuant.m
%
function [A H] = LoadDescQuant( lfn ) 




