%
% Loads the set of vector matrices as saved with wt_DescVMX (option sVMX in
% dscx.exe)
%
% af LoadDescVect.m
%
function [AVMX H] = LoadDescVMX( lfp, bDisp ) 

if nargin==1,
    bDisp = 1;
end
    
fileID      = fopen( lfp, 'rt');

if fileID==-1, 
    error('could not find %s', lfp); 
end

% --------------------   Header   ------------------------
H.nDty    = fscanf( fileID, '%d', 1 );          % num of desc
H.nLev    = fscanf( fileID, '%d', 1 );          % num of levels
H.NtVls   = fscanf( fileID, '%d', H.nDty );     % total num of values per type

%% -------------------   LOOP TYPES   ------------------------
AVMX = cell(H.nDty,1);
for d = 1:H.nDty

    % ----------   Header   ------------
    HedT    = ReadDescVectHead( fileID ); 
    ntDsc   = sum(HedT.Ndsc);
    neVls   = HedT.nAtt * ntDsc;

    % ----------   Data   ------------
    VMX     = fscanf( fileID, '%f', neVls );   % read as entire block
    VMX     = single( VMX );
    VMX     = reshape( VMX, HedT.nAtt, ntDsc );
    AVMX{d} = VMX';
    
end

fclose( fileID );

if bDisp, DispLoad(lfp); end

end


