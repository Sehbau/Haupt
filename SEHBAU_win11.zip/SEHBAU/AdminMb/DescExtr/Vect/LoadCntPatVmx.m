%
% Loads the set of vector matrices as saved with wt_DescVMX (option sVMX in
% dscx.exe)
%
% af LoadDescVect.m
%
function [P] = LoadCntPatVmx( lfp, bDisp ) 

if nargin==1,
    bDisp = 1;
end
    
fileID      = fopen( lfp, 'rt');

if fileID==-1, 
    error('could not find %s', lfp); 
end

% --------------------   Header   ------------------------
P.nSet    = fscanf( fileID, '%d', 1 );          % num of sets

% --------------------   Data   ------------------------
P.Vrt     = ReadPatLinVmx( fileID );
P.Hor     = ReadPatLinVmx( fileID );

fclose( fileID );

if bDisp, DispLoad(lfp); end

end


