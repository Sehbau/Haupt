%
% Loads the position values for the universe (from the set of vector
% files), as well as the level index.
%
% cfro plcBookApply.m
% afro f_VocabImg.m
%
% IN    ffst   filestem 
%       aDty   list of desctype labels
%
function [ S ] = LoadDunvPos( ffst, aDty )

Fidf        = o_FileNameIdf();
Fixt        = o_FileExtensVect();

AttsLabR    = o_AttsLabels();
AttsLabB    = o_AttsLabBin();
IXREAL      = o_AttIxAsFields( AttsLabR, 1 );
IXBIND      = o_AttIxAsFields( AttsLabB, 1 );

S.PosBin    = struct;
S.PosRel    = struct;
S.Lev       = struct;

nDty        = length(aDty);
for d = 1:nDty
    
    dty         = aDty{d};

    % -----------   Load Bind Vmx  ----------
    fpDsb       = [ ffst '.vbn' dty ];
    [VBN Dim]   = LoadDescVebn( fpDsb );

    PsvB        = VBN(:,IXBIND.(dty).psv);
    PshB        = VBN(:,IXBIND.(dty).psh);
    PosBinGrp   = [PsvB PshB];
    
    % -----------   Load Real Vmx  ----------
    fpVmx       = [ ffst '.vec' dty ];
    [VMX Dim2]  = LoadDescVect( fpVmx, 0 );
    
    PsvR        = VMX(:,IXREAL.(dty).psv);
    PshR        = VMX(:,IXREAL.(dty).psh);
    PosRelGrp   = [PsvR PshR];
    
    assert( Dim.nDsc==Dim2.nDsc );
    
    % -----------   Load LevelFile  ----------
    % holds the indices to the levels (of the image space)
    fpLev       = [ ffst '.lev' dty ];
    [LevGrp nDsc2] = LoadDescVectLev( fpLev, 0 );
    
    % -----------   Select   ---------------
    %Bsel        = Lev > 1;
    %PosRelGrp   = PosRelGrp( Bsel, : );
    %WrdGrp      = WrdGrp( Bsel );
    
    % ------------   Append to total   ------------
    S.PosBin.(dty)  = PosBinGrp;
    S.PosRel.(dty)  = PosRelGrp;
    S.Lev.(dty)     = LevGrp;
end

S.ntDsc     = length( S.Lev );

end

