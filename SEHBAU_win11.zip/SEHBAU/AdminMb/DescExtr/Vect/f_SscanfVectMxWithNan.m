%
% Scans a list of lines assuming we deal with a matrix.
%
% This is the backup procedure in case we were not able to properly read
% the file.
%
function [VMX nLin] = f_SscanfVectMxWithNan( aLin, neAtt ) 

nLin = length(aLin);

VMX  = zeros( nLin, neAtt, 'single' );
for l = 1:nLin
    
    Arr         = f_SscanfForFloatWnan( aLin{l}, neAtt );
    VMX(l,:)    = Arr;
    
end






