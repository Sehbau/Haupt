%
% Saves a quant array.
%
% Format in QuantAnf.h
%
% cf iclQntVoc.m
%
function [] = SaveQuantArr( A, H, sfn ) 

fid	= fopen( sfn, 'w');
if (fid<0), error('file %s not found', sfn); end

% ----------   Head   -------------
fprintf( fid, '%d ', H.nQnt );
fprintf( fid, '%d ', H.dimOrg );
fprintf( fid, '%d ', H.dimSus );
fprintf( fid, '%d',  H.maxV );
fprintf( fid, '\n' );

% ----------   Array   -------------
for i = 1:H.nQnt
    fprintf( fid, '%d ', A(i) );
end

fclose(fid);


