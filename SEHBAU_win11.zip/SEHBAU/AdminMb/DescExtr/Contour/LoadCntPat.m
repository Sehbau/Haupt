%
% Loads line pattern as saved under s_AxiCnt in AxiIO.h
%
% af LoadPatLin
%
function [Pat Hed] = LoadCntPat(lfn) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

Hed         = ReadDescFileHead( fileID, 101 );

Pat.Vrt     = ReadPatLin(fileID);
Pat.Hor     = ReadPatLin(fileID);

fclose(fileID);

