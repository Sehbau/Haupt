%
% Loads endpoints of contour universe as saved under
% CntIOrre.h:si_CntUnvKpt.
%
% Coordinates are NOT scaled and correspond to pyramid size.
%
% af LoadCntxSpc
%
function [CUV Ncnt] = LoadCntUnvKpt(lfn) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% ----- nLev
nLev  = fread(fileID, 1,  'uint8=>int');
fprintf('[nLev %d]\n', nLev);
assert( nLev < 10, 'nLev unreasonable. see line above');

%% =====  The space
Ncnt    = zeros(nLev,3);
[ARDG ARIV AEDG] = deal(cell(nLev,1));
for l = 1:nLev

    ARDG{l} = ReadCntKpt(fileID);   Ncnt(l,1)=ARDG{l}.nCnt;
    ARIV{l} = ReadCntKpt(fileID);   Ncnt(l,2)=ARIV{l}.nCnt;
    AEDG{l} = ReadCntKpt(fileID);   Ncnt(l,3)=AEDG{l}.nCnt;
    
end
fclose(fileID);

CUV.ARDG = ARDG;
CUV.ARIV = ARIV;
CUV.AEDG = AEDG;

%DispLoad(lfn);


