%
% Loads all contour spaces (RRE), also known as the full set of contours.
%
% Loads as saved under CntIOrre.h:si_RREspc.
%
function [RRE] = LoadCntRRE(lfn) 

fid   = fopen(lfn, 'r');
if (fid<0), error('file %s not found', lfn); end

% -------   FileHeader   --------
Hed         = ReadDescFileHead( fid, 100 );

% -------   RRE Space   --------
[nLev Nrdg] = ReadDescSpcHead( fid );
[nLev Nriv] = ReadDescSpcHead( fid );
[nLev Nedg] = ReadDescSpcHead( fid );

bWithPts    = 1;
RRE.ARDG    = ReadCntSpc( fid, bWithPts );
RRE.ARIV    = ReadCntSpc( fid, bWithPts );
RRE.AEDG    = ReadCntSpc( fid, bWithPts );

RRE.Longst  = fread( fid, Hed.nLev, 'float=>single'); 

fclose(fid);

DispLoad(lfn);


