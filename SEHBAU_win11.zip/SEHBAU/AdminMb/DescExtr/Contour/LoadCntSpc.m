%
% Loads one contour space as saved with si_CntSpcEss
%
% cf exsbCntx.m
%
function [S] = LoadCntSpc(lfn) 

fid   = fopen(lfn, 'r');
if (fid<0), error('file %s not found', lfn); end

bWithPts    = 0;
[S.ACnt Ncnt]   = ReadCntSpc( fid, bWithPts );

S.nLev          = length( S.ACnt );
S.Ncnt          = Ncnt;

fclose(fid);

DispLoad(lfn);


