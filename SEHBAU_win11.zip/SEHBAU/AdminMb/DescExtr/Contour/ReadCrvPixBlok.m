%
% Reads curve pixels blockwise as saved with w_CrvPixBlok() in CurveIO.h
%
% cf LoadCntUniv.m
% af ReadRegPixBlok.m 
%
function [S] = ReadCrvPixBlok( fid )

%% ====  sizes  ====
S.nCpx      = fread(fid, 1, 'int=>single');
S.nCrv      = fread(fid, 1, 'int=>single'); 
S.szV       = fread(fid, 1, 'int=>single'); 
S.szH       = fread(fid, 1, 'int=>single'); 

% S

%% ====  pixels  ====
S.Ix        = fread(fid, S.nCpx, 'int32=>single') + 1; % turn into one-indexing

S.Npx       = fread(fid, S.nCrv, 'int32=>single');
S.Anf       = fread(fid, S.nCrv, 'int32=>single') + 1; % exact. without +1

% --- verify
%idf     = fread(fid, 1, 'int=>single');
%assert(idf==-1);

end

