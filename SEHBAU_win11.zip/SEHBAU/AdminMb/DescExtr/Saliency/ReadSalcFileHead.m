%
% Reads saliency file header, namely struct fhedSalc in
% E_DESC/UtilIO/DescFileAnf.h.
%
% af ReadDescFileHead.m
% cf LoadDescSalc.m
%
% IN   typExp   type expected. 33
%
function [H] = ReadSalcFileHead( fileID, typExp )

versExp     = 1.03;          	% expected version (DescFilaAnf.h)

H.nRix = fread(fileID, 1,  'int=>int');      % 
H.szL  = fread(fileID, 2,  'int=>int');      % layer size
H.szI  = fread(fileID, 2,  'int=>int');      % image size
H.szG  = fread(fileID, 2,  'int=>int');      % grid size
typ    = fread(fileID, 1,  'uint8=>uint8');  % file typ (imag|focus)

H.szG  = H.szG';

versLod = fread(fileID, 1,  'float=>single');  % version loaded

assert(typ==typExp,'file idf not correct: %d, expected %d', typ, typExp);
assert( abs(versLod-versExp)<0.001, ...
        'Version depreciated: is %1.3f. new %1.3f', versLod, versExp);

end

