%
% Reads the global statistics of the ori-bias maps as saved under
% w_OtxMAPsts() in A_CONT/Itgr/Util/CntTxtIO.h
%
% cf LoadDescSalc, LoadSalcAly.m
%
% Use u_TxtrGstToArrs.m to convert to arrays.
%
% fka ReadBlobMapGlbSts.m
%
function [S] = ReadTxtrMapStats( fileID )

%% -----   Bias Labels   -----
% They must match with CntTxtAnf.h
% Must be same as in o_TxtrLabels.m

aBisLab  = {'Num' 'Blk' 'Nil' 'Vrt' 'Hor' 'Axi' 'Uni'};

nBis        = length( aBisLab );

for i = 1:nBis
    lb          = aBisLab{i}; 
    S.( lb )    = ReadMapStats( fileID );  % reads five values
end

% =====   Trailer   =====
idf    = fread(fileID, 1, 'int32=>int');

assert(idf==46593, 'idf not correct: %d', idf);

end

