%
% Loads descriptor attributes as saved under s_QnslDesc in ConslIO.h
% 
% cf exsbProposals.m, cc_Axial.m
%
function [DSC] = LoadDescPropAtts( lfn )

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

% --------------   Head   ---------------
DSC.nShp        = fread(fileID, 1, 'int=>single');
DSC.nTtg        = fread(fileID, 1, 'int=>single');

% --------------   Data   ---------------
DSC.ShpGen      = ReadShpAtt(  fileID );
DSC.TtgGen      = ReadTtrgAtt( fileID );

%Ord.OrdShp     = ReadIxsArr( fileID );
%Ord.OrdTtg     = ReadIxsArr( fileID );

% -----   idf  -----
idf1 = fread( fileID, 1,  'int=>int');

%% ------------   Close   -----------
fclose( fileID );

%% ----------  Verify  -----------
assert( idf1==78000, 'idf1 not correct');

%% ----------  Disp  -----------
% fprintf('LoadConslDesc: %d %d\n', DSC.ShpGen.nShp, DSC.TtgGen.nTtg );

end

