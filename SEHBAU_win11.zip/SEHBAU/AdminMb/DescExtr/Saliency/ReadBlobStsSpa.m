%
% Reads the freckle statistics (spatial blob kount) as written with
% wb_BlobStsSpa in BlobIO.h
%
% cf LoadDescSalc, LoadSalcAly.m
%
function [S] = ReadBlobStsSpa( fileID )

%% -----   Bias Labels   -----
% They must match with CntTxtAnf.h
% Must be same as in o_TxtrLabels.m

aBisLab  = {'Num' 'Blk' 'Nil' 'Vrt' 'Hor' 'Axi' 'Uni'};

nBis        = length( aBisLab );

for i = 1:nBis
    lb         = aBisLab{i}; 
    
    S.( lb )   = ReadDescStsSpa( fileID );  
end

end

