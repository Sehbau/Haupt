%
% Reads the stats for ONE texture bias as saved under w_MapBisStat
%
% It is an array of five float values
%
% cf ReadTxtrMapStats.m
%
function [S] = ReadTxtrMapStats1( fileID )

S.prpPres  	= fread( fileID, 1, 'float=>single');
S.min   	= fread( fileID, 1, 'float=>single');
S.max   	= fread( fileID, 1, 'float=>single');
S.men   	= fread( fileID, 1, 'float=>single');
S.sdv   	= fread( fileID, 1, 'float=>single');

end

