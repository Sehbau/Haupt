%
% Reads the stats for ONE texture bias as saved under w_MapBisStat
%
% It is an array of five float values
%
% cf ReadTxtrMapStats.m
%
function [S] = ReadTxtrMapStats1( fileID )

warning('deprecated - use ReadMapStats.m');

S       = ReadMapStats( fileID);


end

