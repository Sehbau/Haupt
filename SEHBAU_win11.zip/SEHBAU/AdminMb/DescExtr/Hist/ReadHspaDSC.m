%
% Reads spatial histograms.
%
% cf LoadDescHistClw.m
%
function [H Nbin] = ReadHspaDSC( fid )

%% =====    # of bins   =====
Nbin.uni    = fread(fid, 1, 'int=>int');
Nbin.biv    = fread(fid, 1, 'int=>int');
%Nbin

%% =====    Histograms  =====
H.Uni       = fread(fid, Nbin.uni, 'int=>int');
H.Biv       = fread(fid, Nbin.biv, 'int=>int');


end

