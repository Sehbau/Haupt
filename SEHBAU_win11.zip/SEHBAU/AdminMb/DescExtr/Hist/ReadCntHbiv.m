%
% Reads bivariate contour histograms as saved under CntIO.h-w_CntHimd
%
% cf LoadDescHist.m
%
function [Hcat H Nbin] = ReadCntHbiv( fid )

H    = struct;

%% =====    # of bins   =====
Nbin        = ReadStcOfField( fid, 'int=>int', '' );
Nbin.LS     = fread(fid, 1,  'int=>int');
Nbin.LO     = fread(fid, 1,  'int=>int');

%% =====   Histograms  =====
H.LS        = fread(fid, Nbin.LS, 'int=>int');
H.LO        = fread(fid, Nbin.LO, 'int=>int');

Hcat = [H.LO' H.LS'];

end

