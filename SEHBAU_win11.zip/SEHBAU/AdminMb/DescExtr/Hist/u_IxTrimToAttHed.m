%
% Generates the index array for reducing a feature matrix to a divisible
% number of components for a transformer (that requires equal
% dimensionality for attention heads).
% 
% IN   DAT   data [nSmp nFet(nCll*nEmb)]. used for verification only
%      nCll  nCells | sequence length
%      nEmb  embedding size
%      nHed  number of attention heads
% OUT  IxS   selected indices, to be applied DAT(:,IxS)
%
function [ S ] = u_IxTrimToAttHed( DAT, nCll, nEmb, nHed )

[nSmp nFet] = size(DAT);

nFetC       = nCll*nEmb;

assert(nFet==nFetC,'feature dimy not matching: %d (DAT) <> %d (calc)', ...
    nFet, nFetC );

vMod    = mod( nEmb, nHed );
if vMod==0
    S.Ix   = 1:nFet;           % no reduction necessary
    S.nSel = nFet;
    return;
end

nCll    = single(nCll);
nRed    = single(nEmb - vMod);
IxB     = 1:nRed;
SHF     = repelem( (0:nCll-1)*nRed, nRed, 1 );
IXB     = repelem( IxB', 1, nCll );
IxS     = SHF + IXB;

S.Ix    = IxS(:);
S.nSel  = nRed; 

ntNew   = nRed*nCll;

IxU     = unique(IxS);
assert( ntNew==length(IxU), 'selection not correct somehow');

assert( ntNew==length(S.Ix), 'reduced dimy not correct' );
fprintf('u_ArrEmbToDiv: reduced from %d to %d, new total %d\n', ...
    nEmb, nRed, ntNew);

end

