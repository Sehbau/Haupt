%
% Loads the universe of spatial histograms (orgd cellwise)
%
% cf LoadDescHistClw.m, LoadFabric.m
%
function [H] = ReadHspaDUNV(fid, szGrd ) 

nCells    = szGrd(1)*szGrd(2);

%% -----  data   ------
H.ACNT    = cell(nCells,1);
H.AFRM    = cell(nCells,1);
H.AARC    = cell(nCells,1);
H.ASTR    = cell(nCells,1);
H.ASHP    = cell(nCells,1);
for c = 1:nCells
    
    [H.ACNT{c} NbinCnt]  = ReadHspaDSC( fid );
    [H.AFRM{c} NbinFrm]  = ReadHspaDSC( fid );
    [H.AARC{c} NbinArc]  = ReadHspaDSC( fid );
    [H.ASTR{c} NbinStr]  = ReadHspaDSC( fid );
    [H.ASHP{c} NbinShp]  = ReadHspaDSC( fid );
end

%% -----  maps (trailer)   ------
H.Ncnt  	= fread( fid, nCells, 'int=>int');
H.Nfrm  	= fread( fid, nCells, 'int=>int');
H.Narc      = fread( fid, nCells, 'int=>int');
H.Nstr      = fread( fid, nCells, 'int=>int');
H.Nshp      = fread( fid, nCells, 'int=>int');

[nVer nHor] = deal( szGrd(1), szGrd(2) );
H.Ncnt      = reshape( H.Ncnt, nVer, nHor )';
H.Nfrm      = reshape( H.Nfrm, nVer, nHor )';
H.Narc      = reshape( H.Narc, nVer, nHor )';
H.Nstr      = reshape( H.Nstr, nVer, nHor )';
H.Nshp      = reshape( H.Nshp, nVer, nHor )';

H.nCells    = nCells;
H.szGrd     = szGrd;

%% -----   create one Nbin struct   -----
Nbin.Cnt    = NbinCnt;
Nbin.Frm    = NbinFrm;
Nbin.Arc    = NbinArc;
Nbin.Str    = NbinStr;
Nbin.Shp    = NbinShp;

H.Nbin      = Nbin;

