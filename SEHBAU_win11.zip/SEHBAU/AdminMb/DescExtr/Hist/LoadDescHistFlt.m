%
% Loads the flat descriptor histogram (of attributes).
%
% af LoadDescHist.m
% cf exsbDbin.m
% sa LoadDescHistClw.m
%
% IN    lfn     file path
% OUT   H.UNF   univariate, flat
%       H.BIF   bivariate, flat
%       H.Nbin  bin sizes
%       Head    general info
%
function [H Head] = LoadDescHistFlt(lfn) 

HISTIOIDF = 8888888;            % in-between identifier

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----  reads header file
Head     = ReadHistFileHead( fileID );

%% =====  flat univariate histograms  =====
[H.UNF.Rdg Nunf.Rdg] = ReadCntHist(fileID);
[H.UNF.Riv Nunf.Riv] = ReadCntHist(fileID);
[H.UNF.Edg Nunf.Edg] = ReadCntHist(fileID);

[H.UNF.Skl Nunf.Skl] = ReadCntHist(fileID);
%Nunf.Skl

[H.UNF.Frm Nunf.Frm]  = ReadFrmHuni(fileID);
%Nunf.Rsg

idf    = fread(fileID, 1,  'int=>int'); % identifier

[H.UNF.Arc Nunf.Arc]  = ReadArcHist(fileID);
%Nunf.Arc
idf    = fread(fileID, 1,  'int=>int'); % identifier

[H.UNF.Str Nunf.Str]  = ReadStrHist(fileID); 
idf    = fread(fileID, 1,  'int=>int'); % identifier

[H.UNF.Shp Nunf.Shp]  = ReadShpHist(fileID); 

[H.UNF.Ttg Nunf.Ttg]  = ReadTtrgHist(fileID); 

[H.UNF.Bndg Nunf.Bndg] = ReadBndgHist(fileID); 

[H.UNF.Lof Nunf.Lof]  = ReadHistLoft(fileID); % local feature histogram

idf    = fread(fileID, 1,  'int=>int'); % identifier
assert(idf==HISTIOIDF, 'Univariate falsch');

%% =====  flat bivariate histograms   =====
% HBIV is struct with original fields (NOT concatenated)
[H.BIF.Rdg HBIV.Rdg Nbif.Rdg] = ReadCntHbiv(fileID);
[H.BIF.Riv HBIV.Riv Nbif.Riv] = ReadCntHbiv(fileID);
[H.BIF.Edg HBIV.Edg Nbif.Edg] = ReadCntHbiv(fileID);

[H.BIF.Skl HBIV.Skl Nbif.Skl] = ReadCntHbiv(fileID);

% it is radsig only, actually. no bivariate form hists exist yet
[H.BIF.Frm HBIV.Frm Nbif.Frm] = ReadRsgHbiv(fileID);

[H.BIF.Arc HBIV.Arc Nbif.Arc] = ReadArcHbiv(fileID);

[H.BIF.Str HBIV.Str Nbif.Str] = ReadStrHbiv(fileID);

[H.BIF.Shp          Nbif.Shp] = ReadShpHbiv(fileID);

[H.BIF.Ttg          Nbif.Ttg] = ReadDescHbiv(fileID); 

[H.BIF.Bndg        Nbif.Bndg] = ReadDescHbiv(fileID); 

%% =====  trailer/idf   ======
idf    = fread(fileID, 1,  'int=>int'); % identifier
assert(idf==HISTIOIDF, 'Bivariate falsch');

fclose(fileID);

%% -----   create one Nbin struct   -----
H.Nbin.Uni    = Nunf;
H.Nbin.Biv    = Nbif;






