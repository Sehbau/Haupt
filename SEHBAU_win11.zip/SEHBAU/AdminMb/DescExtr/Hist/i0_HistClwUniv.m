%
% Sets up spatial histograms for cellwise organization.
%
function [H] = i0_HistClwUniv( Nbin, nCells )

Nbin.Cnt = f_HistClwNbinTotDty1( Nbin.Cnt );
Nbin.Frm = f_HistClwNbinTotDty1( Nbin.Frm );
Nbin.Arc = f_HistClwNbinTotDty1( Nbin.Arc );
Nbin.Str = f_HistClwNbinTotDty1( Nbin.Str );
Nbin.Shp = f_HistClwNbinTotDty1( Nbin.Shp );

nt  = Nbin.Cnt.nt + Nbin.Frm.nt + Nbin.Arc.nt + Nbin.Str.nt + Nbin.Shp.nt;

H   = zeros( nCells, nt, 'single' );

end

