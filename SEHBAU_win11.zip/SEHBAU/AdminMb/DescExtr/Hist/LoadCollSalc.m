%
% Loads the saliency array, [nImg nAsp], as collected with program
% collsalc. Does not verify file extension.
%
% As saved in C under E_DESC/CollSalc/CollSalcIO.h
%
function [SLC Dim] = LoadCollSalc( pthFile )

fileID      = fopen(pthFile, 'r');
if fileID<0, 
    error('could not open %s.', pthFile); 
end

%% -------   Header (Size)   --------
nImg        = fread(fileID, 1,  'int=>int');
nAsp        = fread(fileID, 1,  'int=>int');
fprintf('[%d %d]\n', nImg, nAsp);

%% -------   Data   --------
ntVal       = nImg*nAsp;

SLC         = fread( fileID, ntVal, 'float=>single');

fclose(fileID);

if length(SLC)~=ntVal
    error('read fewer values than expected: %d < %d', length(SLC), ntVal );
end

%% --------   Reshape to Matrix   -------
SLC         = reshape( SLC, nAsp, nImg )';

Dim.nImg    = nImg;
Dim.nAsp    = nAsp;

DispLoad(pthFile);

end

