% 
% Subselection from full spatial histogram.
%
% afro u_IxTrimToAttHed.m
%
% IN    H     histogram matrix [nImg nCell*nBin]
%       Nbin  number of bins
%       sel   selection type
% OUT   H     histogram matrix [nImg nCell*nBinSel]
%
function [H Nbin] = u_HspaSel( H, Nbin, sel )

[nImg nbFll] = size( H );
nCll         = Nbin.nCells;
nBpC         = Nbin.nBinPerCell;

if strcmp(sel,'cnt')==1         % contours only
    IxB     = 1:Nbin.Cnt.nt;

elseif strcmp(sel,'cntfrm')==1  % contours + forms
    IxB     = 1:(Nbin.Cnt.nt+Nbin.Frm.nt);
else
    error('selection %s not implemented', sel);
end
nRed    = length(IxB);

SHF     = repelem( (0:nCll-1)*nRed, nRed, 1 );
IXB     = repelem( IxB', 1, nCll );
IxS     = SHF + IXB;
IxS     = IxS(:);

H       = H(:,IxS);

ntNew   = nRed*nCll;
assert( ntNew==length(IxS), 'reduced dimy not correct' );

Nbin.nBinPerCell = nRed;
Nbin.ntBin       = ntNew;

fprintf('Subselection from %d to %d (per cell), new total %d\n', ...
    nBpC, Nbin.nBinPerCell, Nbin.ntBin );

end

