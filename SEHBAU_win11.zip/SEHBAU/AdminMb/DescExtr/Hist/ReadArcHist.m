%
% Reads contour histogramsas saved under ArcIOhist.h-w_ArcHuni
%
% cf LoadDescHist.m
%
function [Hcat Nbin] = ReadArcHist(fileID)

H    = struct;
Nbin = struct;

%% =====    # of bins   =====
Nbin.len  = fread(fileID, 1,  'uint8=>uint8');
Nbin.krv  = fread(fileID, 1,  'uint8=>uint8');
Nbin.dir  = fread(fileID, 1,  'uint8=>uint8');

Nbin.spz  = fread(fileID, 1,  'uint8=>uint8');
Nbin.eck  = fread(fileID, 1,  'uint8=>uint8');
Nbin.run  = fread(fileID, 1,  'uint8=>uint8');
Nbin.ifx  = fread(fileID, 1,  'uint8=>uint8');

Nbin.crm  = fread(fileID, 1,  'uint8=>uint8');

if Nbin.len > 25
    Nbin
    error('nBins unreasonable');
end

%% =====   Histograms  =====
H.Len   = fread(fileID, Nbin.len, 'int=>int');
H.Krv   = fread(fileID, Nbin.krv, 'int=>int');
H.Dir   = fread(fileID, Nbin.dir, 'int=>int');

H.Spz   = fread(fileID, Nbin.spz, 'int=>int');
H.Eck   = fread(fileID, Nbin.eck, 'int=>int');
H.Run   = fread(fileID, Nbin.run, 'int=>int');
H.Ifx   = fread(fileID, Nbin.ifx, 'int=>int');

H.Red   = fread(fileID, Nbin.crm, 'int=>int');
H.Grn   = fread(fileID, Nbin.crm, 'int=>int');
H.Blu   = fread(fileID, Nbin.crm, 'int=>int');

Hcat = [H.Len' H.Krv' H.Dir' H.Spz' H.Eck' H.Run' H.Ifx' H.Red' H.Grn' H.Blu'];

Nbin.crm = Nbin.crm*3;

end

