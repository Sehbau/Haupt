%
% Reads shape histograms as saved under ShpIOhist.h-w_ShpHuni
%
% cf LoadDescHist.m
%
function [Hcat Nbin] = ReadShpHist( fileID )

Nbin    = struct;

%% =====    # of bins   =====
Nbin.all = fread(fileID, 1,  'int=>int');

%% =====   Histograms  =====
HScors  = ReadMtrxDat( fileID, 'int32=>single' );
HSfine  = ReadMtrxDat( fileID, 'int32=>single' );
HRas    = ReadMtrxDat( fileID, 'int32=>single' );
HAto    = ReadMtrxDat( fileID, 'int32=>single' );

Hcat   = [ HScors(:)' HSfine(:)' HRas(:)' HAto(:)' ];

%HScors
Nbin.tot = length(Hcat);

end

