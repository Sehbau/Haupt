%
% Loads the spatial histogram as saved under h2arr.cpp. 
%
function [MX Dim] = LoadHistSpatArr( lfn ) 

fileID   = fopen(lfn, 'rt');
if (fileID<0), error('file %s not found', lfn); end

% -------   Header   -------
nCells  = fscanf( fileID, '%d', 1);
nBins   = fscanf( fileID, '%d', 1);

% -------   Data   -------
%fprintf('Reading %d x %d', nCells, nBins);
MX      = fscanf( fileID, '%d', nBins*nCells );

fclose(fileID);

% -------   Reshape   -------
Dim     = [ nCells nBins ];
MX      = int32( MX );
MX      = reshape( MX, nCells, nBins ) ;






