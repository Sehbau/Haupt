%
% Loads the collection files for one database.
%
% cf plzAlySalcAll.m
%
% IN  Fina   struct with filenames as generated in o_FileNameColl.m
%
function [S] = LoadCollSet( pthColl, idf )

FixtColl        = o_FileExtensColl();

FinaColl        = o_FileNameColl( pthColl, FixtColl, idf );
    
[S.TXTR S.Hed]  = LoadCollTxtr( FinaColl );
            
[S.APPC S.DimAppc S.StsAppc] = LoadCollSalc( FinaColl.appc );

[S.NFET S.DimNfet S.StsNfet] = LoadCollSalc( FinaColl.nfet );

[S.CVRG S.DimCvrg S.StsCvrg] = LoadCollSalc( FinaColl.cvrg );

S.Sts           = f_CollTxtrStats( S.TXTR );

end

