%
% Reads straighter histograms as saved under StrIO.h-w_StrHuni
%
% cf LoadDescHist.m
%
function [Hcat Nbin] = ReadStrHist(fileID)

Nbin = struct;

%% =====    # of bins   =====
Nbin.len  = fread(fileID, 1,  'int=>int');
Nbin.str  = fread(fileID, 1,  'int=>int');
Nbin.ori  = fread(fileID, 1,  'int=>int');
Nbin.crm  = fread(fileID, 1,  'int=>int');

if Nbin.crm > 25
    Nbin
    error('nBins unreasonable: %d', Nbin.crm );
end

%% =====   Histograms  =====
Hlen   = fread(fileID, Nbin.len, 'int=>int');
Hstr   = fread(fileID, Nbin.str, 'int=>int');
Hori   = fread(fileID, Nbin.ori, 'int=>int');

Hred   = fread(fileID, Nbin.crm, 'int=>int');
Hgrn   = fread(fileID, Nbin.crm, 'int=>int');
Hblu   = fread(fileID, Nbin.crm, 'int=>int');

Hcat = [Hlen' Hstr' Hori' Hred' Hgrn' Hblu'];

Nbin.crm = Nbin.crm*3;

end

