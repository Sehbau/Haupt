% 
% Concatenates univ and biva histograms for one desctype.
%
function [H] = u_HistCatClwDty1( D )

H   = [ D.Uni; D.Biv ];

end

