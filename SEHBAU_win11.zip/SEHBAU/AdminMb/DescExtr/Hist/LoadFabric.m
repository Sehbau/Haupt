%
% Loads the fabric.
%
%
function [F Head] = LoadFabric(lfn) 

fid   = fopen(lfn, 'r');
if (fid<0), error('file %s not found', lfn); end

%% -----------------------   HEAD   --------------------------
% It is a three-part header: general, maps dimensions, num of bins

%% -----  General  -----
Head        = ReadHistFileHead( fid );

%% -----  Map Dims  -----
ADim        = zeros(3,2,'single');
ADim(1,:)   = fread(fid, 2, 'int32=>int32');  
ADim(2,:)   = fread(fid, 2, 'int32=>int32');  
ADim(3,:)   = fread(fid, 2, 'int32=>int32');  
ADim(4,:)   = fread(fid, 2, 'int32=>int32');  
Head.ADim   = ADim;

%% -----  Nbin  -----
Head.Nbin   = ReadBnumSpat( fid );

%% -----------------------   DATA   --------------------------

% --------------   Hykos   -----------------
F.K1        = ReadHspaDUNV( fid, ADim(1,:) );
F.K2        = ReadHspaDUNV( fid, ADim(2,:) );
F.K3        = ReadHspaDUNV( fid, ADim(3,:) );
F.K4        = ReadHspaDUNV( fid, ADim(4,:) );

% --------------   Maps   -----------------
% sa o_TxtrLabels.m
LbOriBis    = {'Vrt' 'Hor' 'Dg1' 'Dg2' 'Axi' 'Nil' 'Uni'};
F.MP1.Cnt   = ReadStcMapFlt( fid, LbOriBis, F.K1.szGrd );
F.MP2.Cnt   = ReadStcMapFlt( fid, LbOriBis, F.K2.szGrd );
F.MP3.Cnt   = ReadStcMapFlt( fid, LbOriBis, F.K3.szGrd );
F.MP4.Cnt   = ReadStcMapFlt( fid, LbOriBis, F.K4.szGrd );

F.MP1.Frm   = ReadStcMapFlt( fid, LbOriBis, F.K1.szGrd );
F.MP2.Frm   = ReadStcMapFlt( fid, LbOriBis, F.K2.szGrd );
F.MP3.Frm   = ReadStcMapFlt( fid, LbOriBis, F.K3.szGrd );
F.MP4.Frm   = ReadStcMapFlt( fid, LbOriBis, F.K4.szGrd );

fclose(fid);

end

