%
% Loads the set of texture files as generated with collsalc, ie. with
% COLL_TXTR.m
%
% cf plzRun.m, iclDscx.m
%
% IN  Fina   struct with filenames as generated in o_FileNameColl.m
%
function [TXTR Hed] = LoadCollTxtr( Fina, bDispLoad )

if nargin==1,
    bDispLoad = 1;
end

[TXTR.GST Hed.Gs] = LoadBankVec( Fina.txgs, bDispLoad );
[TXTR.GRD Hed.Gg] = LoadBankVec( Fina.txgg, bDispLoad );
[TXTR.BND Hed.Gb] = LoadBankVec( Fina.txgb, bDispLoad ); 

[TXTR.DOMORI Hed.DomOri] = LoadBankVec( Fina.domori, bDispLoad ); 

end

