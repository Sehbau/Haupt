% 
% Concatenates histograms as loaded cellwise to a single matrix 
%
% IN   HCLW   struct with desctypes as field, each one with
%                    {nCells}.Uni/Biv
%
% OUT  HMX    matrix [nCells ntBin]
%
function [HMX] = u_HistCatClw( HCLW )

HMX     = i0_HistClwUniv( HCLW.Nbin, HCLW.nCells );

for c = 1:HCLW.nCells

    Hcnt = u_HistCatClwDty1( HCLW.ACNT{c} );
    Hfrm = u_HistCatClwDty1( HCLW.AFRM{c} );
    Harc = u_HistCatClwDty1( HCLW.AARC{c} );
    Hstr = u_HistCatClwDty1( HCLW.ASTR{c} );
    Hshp = u_HistCatClwDty1( HCLW.ASHP{c} );

    HMX(c,:) = [Hcnt' Hfrm' Harc' Hstr' Hshp'];
end

end

