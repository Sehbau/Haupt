%
% Loads the collection files, saliency, texture and histograms (for one
% database/collection).
%
% af LoadCollSet.m
% cf cscScout.m
%
% IN  pthColl   path to collection files
%
function [D H] = LoadCollDesc( pthColl, typH, idf, bDispLoad )

if nargin==3
    bDispLoad = 1;
end

FixtColl        = o_FileExtensColl();

FinaColl        = o_FileNameColl( pthColl, FixtColl, idf, 'post' );
    
%% -------------   Loading   ------------------
[TXTR H.HedTxtr]  = LoadCollTxtr( FinaColl, bDispLoad );
            
[APPC H.DimSlc]   = LoadCollSalc( FinaColl.appc, bDispLoad );

if strcmp( typH, 'fltuni')
    [HIST, H.Nbin]  = LoadCollHist( FinaColl.hsflt );
    HIST            = HIST( :, 1:H.Nbin.Tot(1) );
if strcmp( typH, 'fltfva')
    [HIST, H.Nbin]  = LoadCollHist( FinaColl.hsflt );
elseif strcmp( typH, 'spa')
    [HIST, H.Nbin]  = LoadCollHist( FinaColl.hsspa );
else
    error('not implemented %s. Available: fltuni, fltfva or spa.', typH);
end

%% --------------   Concatenate   ---------------
D   = [TXTR.GST TXTR.BND  APPC  HIST];

[nImg ntFet] = size(D);



if bDispLoad 
    fprintf('___ %4d %5d\n', nImg, ntFet );
end


end

