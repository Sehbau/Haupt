%
% Reads bundle histograms.
%
% cf LoadDescHist.m
%
function [Hcat Nbin] = ReadBndgHist( fileID )

HGeom   = ReadMtrxDat( fileID, 'int32=>single' );

Nbin    = struct;
Nbin.ori = fread(fileID, 1,  'int=>int');
H.Ori   = fread(fileID, Nbin.ori, 'int=>int');


Hcat    = [ HGeom(:)' H.Ori(:)'];
%Hcat   = [ Hgeom(:)' Hlage(:)' Hangs(:)' HDicv(:)' H.Ori(:)'];

Nbin.geo = length(HGeom(:));

end

