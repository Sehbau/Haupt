%
% Reads the bin numbers for ONE desctype as written by w_BnumDsc1 in
% DescBinAnf.h
%
% cf ReadBnumSpat.m
%
function [N] = ReadBnumDsc1( fileID )

N.nUni      = fread( fileID, 1,  'int=>int');  
N.nBiv      = fread( fileID, 1,  'int=>int');  
N.nt        = fread( fileID, 1,  'int=>int');  

end

