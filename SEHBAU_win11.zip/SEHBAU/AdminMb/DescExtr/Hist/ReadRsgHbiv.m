%
% Reads bivariate radsig histograms as saved under RsgIOhist.h.
%
% There are no bivariate form histograms yet.
%
% cf LoadDescHist.m
%
function [Hcat H Nbin] = ReadRsgHbiv( fid )

H    = struct;

%% =====    # of bins   =====
Nbin        = ReadStcOfField( fid, 'int=>int', '' );

% fprintf('RsgHbiv\n'); Nbin.Vls

Nbin.RO     = fread(fid, 1,  'int=>int');
Nbin.RE     = fread(fid, 1,  'int=>int');
Nbin.RC     = fread(fid, 1,  'int=>int');

Nbin.RV     = fread(fid, 1,  'int=>int');
Nbin.R1     = fread(fid, 1,  'int=>int');
Nbin.R2     = fread(fid, 1,  'int=>int');
Nbin.R3     = fread(fid, 1,  'int=>int');
Nbin.R4     = fread(fid, 1,  'int=>int');
Nbin.R5     = fread(fid, 1,  'int=>int');

Nbin.REO    = fread(fid, 1,  'int=>int');

%% =====   Histograms  =====
H.RO        = fread(fid, Nbin.RO, 'int=>int');
H.RE        = fread(fid, Nbin.RE, 'int=>int');
H.RC        = fread(fid, Nbin.RC, 'int=>int');

H.RV        = fread(fid, Nbin.RV, 'int=>int');
H.R1        = fread(fid, Nbin.R1, 'int=>int');
H.R2        = fread(fid, Nbin.R2, 'int=>int');
H.R3        = fread(fid, Nbin.R3, 'int=>int');
H.R4        = fread(fid, Nbin.R4, 'int=>int');
H.R5        = fread(fid, Nbin.R5, 'int=>int');

H.REO       = fread(fid, Nbin.REO, 'int=>int');


Hcat = [H.RO' H.RE' H.RC'  H.RV' H.R1' H.R2' H.R3' H.R4' H.R5' H.REO'];

end

