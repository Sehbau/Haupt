%
% Loads the collected fabrics.
%
% af LoadCollTxtr.m
% cf iclCollFbrc.m, cfHstEss.m
%
% IN  FinaColl   struct with filenames as generated in o_FileNameColl.m
%
function [F Hed] = LoadCollFbrc( FinaColl, bDispLoad )

if nargin==2,
    bDispLoad = 1;
end

[F.L1 Hed.L1]   = LoadBankVec( FinaColl.fbm1, bDispLoad );
[F.L2 Hed.L2]   = LoadBankVec( FinaColl.fbm2, bDispLoad );
[F.L3 Hed.L3]   = LoadBankVec( FinaColl.fbm3, bDispLoad );
[F.L4 Hed.L4]   = LoadBankVec( FinaColl.fbm4, bDispLoad );

end

