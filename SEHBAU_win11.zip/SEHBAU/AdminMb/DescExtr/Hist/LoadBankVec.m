%
% Loads a bank of vectors [nImg nFet].
%
function [MTX Hed] = LoadBankVec( pthFile, bDispLoad )

if nargin==1
    bDispLoad = 1;
end

fileID      = fopen(pthFile, 'r');
if fileID<0, 
    error('could not open %s.', pthFile); 
end

%% -------   Header (Size)   --------
nRow        = fread(fileID, 1,  'int=>int');
nCol        = fread(fileID, 1,  'int=>int');

Hed.idf     = fread(fileID, 1,  'int=>int');
Hed.szHed   = fread(fileID, 1,  'int=>int');
Hed.nGrp    = fread(fileID, 1,  'int=>int');
Hed.nDimGrp = fread(fileID, 1,  'int=>int');

Hed.vers    = fread(fileID, 1,  'float=>single');

if bDispLoad
    fprintf('[%4d %4d] ', nRow, nCol);
end

%% -------   Data   --------
ntVal       = nRow*nCol;

MTX         = fread( fileID, ntVal, 'float=>single');

fclose(fileID);

if length(MTX)~=ntVal
    Hed
    error('read fewer values than expected: %d < %d', length(MTX), ntVal );
end

%% --------   Reshape to Matrix   -------
MTX         = reshape( MTX, nCol, nRow )';

Hed.nVec    = nRow;
Hed.nDim    = nCol;

%% ---------------   DispLoad   -----------
if bDispLoad
    DispLoad(pthFile);
end

end

