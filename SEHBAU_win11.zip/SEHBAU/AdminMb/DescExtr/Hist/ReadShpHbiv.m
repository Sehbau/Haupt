%
% Reads bivariate shape histograms as saved under ShpIO.h-w_ShpHbiv
%
% cf LoadDescHist.m
%
function [H ntBin] = ReadShpHbiv(fileID)


%% =====    # of bins   =====
ntBin       = fread(fileID, 1,  'int=>int');

%% =====   Histograms  =====
H           = fread(fileID, ntBin, 'int=>int');

end