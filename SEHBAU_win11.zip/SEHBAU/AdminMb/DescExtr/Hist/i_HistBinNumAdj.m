%
% Adjusts histogram bin numbers for chromatics and skeleton (contours).
%
% Carried out only for flat, univariate bin count. It also verifies total
% bin count for flat (univariate) bins.
% 
% PRECEEDS    i_HistBinRanges.m

% cf cfHstEss.m, exsbCollHist.m
%
% IN    Nbin    as loaded by LoadCollHist.m
%       nFltUni = Nbin.Tot(1);
% OUT   Nbin    with two new fields      
%
function Nbin = i_HistBinNumAdj( Nbin ) %ATT, NfltUni, nFltUni )

NATT                = Nbin.ATT;

% --- adjust chromatics
NATT.CntUni(end)    = NATT.CntUni(end)*3;   % chromatics * 3

ixCrm    = 5;
NATT.RsgUni(ixCrm)  = NATT.RsgUni(ixCrm)*3; % chromatics * 3

ixCrm    = 8;
NATT.ArcUni(ixCrm)  = NATT.ArcUni(ixCrm)*3;

ixCrm    = 4;
NATT.StrUni(ixCrm)  = NATT.StrUni(ixCrm)*3;

% --- total bin count
ntbCnt   = sum(NATT.CntUni) * 4;  % including skeleton!

% no more modifications: from here on verification
ntbRsg   = sum(NATT.RsgUni);
ntbArc   = sum(NATT.ArcUni);
ntbStr   = sum(NATT.StrUni);

ntbShp   = NATT.shpUni;
ntbTtrg  = Nbin.FltUni(6);
ntbBndg  = Nbin.FltUni(7);

ntbFltUni = ntbCnt + ntbRsg + ntbArc + ntbStr + ntbShp + ntbTtrg + ntbBndg;

%% ---------   place back   --------
Nbin.ATT  = NATT;
%% ---------   two new fields   ------------
Nbin.ntCntFlt = ntbCnt;     

Nbin.bAdj   = 1;

%% ---------   verify   ---------
if ntbFltUni~=Nbin.Tot(1),
    NATT.CntUni
    NATT.RsgUni
    NATT.ArcUni
    NATT.StrUni
    warning('Uni not correct: CRASS %4d %4d %4d %4d %4d = %d ~= %d', ...
        ntbCnt, ntbRsg, ntbArc, ntbStr, ntbShp, ntbF1, FltUni);
end



end

