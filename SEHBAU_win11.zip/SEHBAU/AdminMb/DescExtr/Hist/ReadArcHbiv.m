%
% Reads bivariate arc histograms as saved under ArcIO.h-w_ArcHbiv
%
% cf LoadDescHist.m
%
function [Hcat H Nbin] = ReadArcHbiv( fid )

H    = struct;

%% =====    # of bins   =====
Nbin        = ReadStcOfField( fid, 'int=>int', '' );
Nbin.LK     = fread(fid, 1,  'int32=>int32');
Nbin.LD     = fread(fid, 1,  'int32=>int32');

Nbin.LKD    = fread(fid, 1,  'int32=>int');

%% =====   Histograms  =====
H.LK        = fread(fid, Nbin.LK, 'int=>int');
H.LD        = fread(fid, Nbin.LD, 'int=>int');

H.LKD       = fread(fid, Nbin.LKD, 'int=>int');


Hcat = [H.LK' H.LD' H.LKD'];

end