%
% Loads the descriptor bin numbers as saved in C under w_DescBinNum.
%
% Note: bin count not entirely correct. It lacks trippling the chromatic
% values. Use i_HistBinNumAdj.m for that.
%
% cf LoadCollHist.m
%
function [N] = ReadDescBinNum( fileID )

% ----------   Total   ---------------
% flat/biv/spaFlat/spaBiv
N.Tot    = fread(fileID, 4,  'int=>int');  % 4 integers

% ----------   Hist Type   ---------------
N.FltUni = fread(fileID, 7,  'int=>int');  % CRASSPB
N.FltBiv = fread(fileID, 7,  'int=>int');  % CRASSPB
N.SpaUni = fread(fileID, 7,  'int=>int');  % CRASSPB
N.SpaBiv = fread(fileID, 2,  'int=>int');  % CR
N.SpaBiv = [N.SpaBiv; 0; 0; 0]; % add three for ASS

% ----------   Individual DescTypes   ---------------
N.ATT    = ReadBnumATT( fileID );

% -----------   Trailer   -----------
idfEof      = fread(fileID, 1,  'int=>int');  
assert(idfEof==444);

end

