%
% Sets up spatial histograms for cellwise organization.
%
function [N] = f_HistClwNbinTotDty1( N )

N.nt  = N.uni + N.biv ;

end

