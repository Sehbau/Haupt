%
% Bin ranges for descriptor types as loaded with LoadCollHist.m
%
% Requires that i_HistBinNumAdj has been run before.
%
% SUCCEEDS    i_HistBinNumAdj.m
%
% For selecting ranges see also f_HistSelDscTypAll.m, f_HistTypSegr.m
%
function R = i_HistBinRanges(Nbin)

if ~isfield( Nbin, 'bAdj' ), 
    error(' not adjusted Nbin structure: use i_HistBinNumAdj');
end
assert( Nbin.bAdj>0 );

nFltUni 	= Nbin.Tot(1);
nFltBiv     = Nbin.Tot(2);
nSpaUni     = Nbin.Tot(3);
nSpaBiv     = Nbin.Tot(4);
tot         = sum(Nbin.Tot);

ntBin       = sum( nFltUni + nFltBiv + nSpaUni + nSpaBiv );

assert(tot==ntBin); % not a real assertion!

%% ------   HistType    -------
R.FltUni    = 1                           : nFltUni;
R.FltBiv    = nFltUni + 1                 : nFltUni + nFltBiv;
R.SpaUni    = nFltUni + nFltBiv + 1       : nFltUni + nFltBiv + nSpaUni;
R.SpaBiv    = nFltUni + nFltBiv + nSpaUni+1 : ntBin;

%% assert not overlapping:
IxAll       = [ R.FltUni R.FltBiv R.SpaUni R.SpaBiv ];
IxU         = unique(IxAll);
assert(length(IxU)==length(IxAll));

%% ------   DescTyps of FltUni   -------
ntbCnt   = Nbin.ntCntFlt;
ntbRsg   = sum(Nbin.ATT.RsgUni);
ntbArc   = sum(Nbin.ATT.ArcUni);
ntbStr   = sum(Nbin.ATT.StrUni);

ntbShp   = Nbin.ATT.shpUni;
ntbTtrg  = Nbin.FltUni(6);
ntbBndg  = Nbin.FltUni(7);

ntbFltUni = ntbCnt + ntbRsg + ntbArc + ntbStr + ntbShp + ntbTtrg + ntbBndg;

if ntbFltUni~=nFltUni,
    Nbin.CntUni
    Nbin.RsgUni
    Nbin.ArcUni
    Nbin.StrUni
    warning('Uni not correct: CRASS %4d %4d %4d %4d %4d = %d ~= %d', ...
        ntbCnt, ntbRsg, ntbArc, ntbStr, ntbShp, ntbF1, FltUni);
end

%% --------------   Ranges   ----------------
R.FltCnt  = 1:ntbCnt;

R.FltRsg  = (1:ntbRsg) + R.FltCnt(end);

R.FltArc  = (1:ntbArc) + R.FltRsg(end);

R.FltStr  = (1:ntbStr) + R.FltArc(end);

R.FltShp  = (1:ntbShp) + R.FltStr(end);

R.FltTtrg = (1:ntbTtrg) + R.FltShp(end);

R.FltBndg = (1:ntbBndg) + R.FltTtrg(end);

IxU  = unique( ...
        [ R.FltCnt R.FltRsg R.FltArc R.FltStr R.FltShp R.FltTtrg R.FltBndg ] );

if length(IxU)~=ntbFltUni,
    warning('lengths not correct');
end


end

