%
% Calculates bin count for loaded histogram.
%
% IN    Nbin    as loaded by LoadDescHist.m
% OUT   Kt
%
function Nbin = f_NbinCount( Nbin ) %ATT, NfltUni, nFltUni )

%% --------------   Univariate   ---------------
Nuni        = Nbin.Uni;

Uni.nRdg    = sof_Sum( Nuni.Rdg );
Uni.nRiv    = sof_Sum( Nuni.Riv );
Uni.nEdg    = sof_Sum( Nuni.Edg );
Uni.nSkl    = sof_Sum( Nuni.Skl );

Uni.nFrm    = sof_Sum( Nuni.Frm );
Uni.nArc    = sof_Sum( Nuni.Arc );
Uni.nStr    = sof_Sum( Nuni.Str );

Uni.nShp    = sof_Sum( Nuni.Shp );

Uni.nBndg   = sof_Sum( Nuni.Bndg );
Uni.nTtg    = sof_Sum( Nuni.Ttg );

%% --------------   Bivariate   ---------------
Biv         = Nbin.Biv;

nbRdg       = Biv.Rdg.LO + Biv.Rdg.LS;
nbRiv       = Biv.Riv.LO + Biv.Riv.LS;
nbEdg       = Biv.Edg.LO + Biv.Edg.LS;
nbSkl       = Biv.Skl.LO + Biv.Skl.LS;
%nbFrm       = 
%%
Kt.ntUni    = sof_Sum( Uni );

end

