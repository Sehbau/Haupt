%
% Reads bivariate straighter histograms as saved under StrIOhist.h-w_StrHimd
%
% cf LoadDescHist.m
%
function [Hcat H Nbin] = ReadStrHbiv( fid )

H    = struct;

%% =====    # of bins   =====
Nbin        = ReadStcOfField( fid, 'int=>int', '' );
Nbin.LS     = fread(fid, 1,  'int=>int');
Nbin.LO     = fread(fid, 1,  'int=>int');

%% =====   Histograms  =====
H.LS        = fread(fid, Nbin.LS, 'int=>int');
H.LO        = fread(fid, Nbin.LO, 'int=>int');

Hcat = [H.LO' H.LS'];

end

