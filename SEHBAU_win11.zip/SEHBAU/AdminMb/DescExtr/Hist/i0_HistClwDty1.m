%
% Sets up spatial histograms for cellwise organization.
%
function [H] = i0_HistClwDty1( nCells, Nbin )

H.UNI = zeros( nCells, Nbin.uni, 'int32' );
H.BIV = zeros( nCells, Nbin.biv, 'int32' );

end

