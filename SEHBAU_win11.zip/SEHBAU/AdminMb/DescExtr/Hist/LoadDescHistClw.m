%
% Loads the spatial hist-of-atts that were saved cellwise.
%
function [H Head] = LoadDescHistClw(lfn) 

fid   = fopen(lfn, 'r');
if (fid<0), error('file %s not found', lfn); end

%% -----  header   ------
Head 	= ReadHistFileHead( fid );

szGrd 	= [ Head.nVrtSph Head.nHorSph ];

%% -----  data  -----
H       = ReadHspaDUNV( fid, szGrd );

fclose(fid);

H.szG   = [ Head.nVrtSph Head.nHorSph ];

end

