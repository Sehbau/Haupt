%
% Reads contour histograms as saved under CntIOhist.h-w_CntHist
%
% cf LoadDescHist.m
%
function [Hcat Nbin] = ReadCntHist( fid )

%% =====    # of bins   =====
NbinL     = ReadStcOfField( fid, 'int=>int' );
Nbin.len  = NbinL.Vls(1);
Nbin.str  = NbinL.Vls(2);
Nbin.ori  = NbinL.Vls(3);
Nbin.crm  = NbinL.Vls(4);

%% =====   Histograms  =====
Hlen   = fread(fid, Nbin.len, 'int=>int');
Hstr   = fread(fid, Nbin.str, 'int=>int');
Hori   = fread(fid, Nbin.ori, 'int=>int');

Hred   = fread(fid, Nbin.crm, 'int=>int');
Hgrn   = fread(fid, Nbin.crm, 'int=>int');
Hblu   = fread(fid, Nbin.crm, 'int=>int');

Hcat = [Hlen' Hstr' Hori' Hred' Hgrn' Hblu'];

Nbin.crm = Nbin.crm*3;

end

