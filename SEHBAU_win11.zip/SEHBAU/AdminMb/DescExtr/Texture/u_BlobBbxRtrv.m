%
% Retrieves blob bboxes from struct SLC.Txa.Blb according to bias (type)
% and scales them if desired (3rd argument)
%
% SclFct calculated with f_LevToLaySclFct.m
%
% cf exsbTxtrMaps.m, evsbCntx.m
%
function [S] = u_BlobBbxRtrv( SBxAll, aLb, SclFct )

nTyp        = length( aLb );
mxTyp       = max( SBxAll.Typ );

bScale      = 0;
if nargin==3
    bScale = 1;
end

assert( mxTyp <= 9, 'Somehow too many types' );

for i = 1:nTyp

    Bsel        = SBxAll.Typ==i;
    
    Bbx         = single( SBxAll.Box(Bsel,:) );

    % Scale from original resolution to layer resolution
    if bScale
        Bbx(:,1) = Bbx(:,1) * SclFct(1);
        Bbx(:,2) = Bbx(:,2) * SclFct(1);
        Bbx(:,3) = Bbx(:,3) * SclFct(2);
        Bbx(:,4) = Bbx(:,4) * SclFct(2);
    end
    
    lb          = aLb{i}; 

    S.( lb )    = Bbx;

end

end

