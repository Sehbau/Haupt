%
% Texture statistics for a collection (or course/run).
%
% cf iclDscx.m, plzAlySalc.m
%
% fka f_TxtrStatCourse
% 
% IN   C    collection as loaded with LoadCollTxtr.m  
%
function [S] = f_CollTxtrStats( C )

S.Gst       = f_MtrxColStat( C.GST );
S.Bnd       = f_MtrxColStat( C.BND );
S.Grd       = f_MtrxColStat( C.GRD );

S.DomOri    = f_MtrxColStat( C.DOMORI );

end

