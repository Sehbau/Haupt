%
% Compares the texture stats for two runs.
%
% cf plzAlySalc.m
%
function [] = p_Cvrg2Runs( C1, C2, figNo, aLbCond, aCol )

figure(figNo); clf;

LbNfet = {'Dlv1' 'Dlv2' 'Dlv3' 'Dlv4' 'Klv1' 'Klv2' 'Klv3' 'Klv4'}; 

nFet    = 8;
nPlt    = nFet + 1;
[nr nc] = deal(nPlt,1);

%subplot(nr,nc,1);
%p_Dsrb2Runs( A1(:,1), A2(:,1), aCol, aLbCond );
%ylabel( LbTxtr{1} );

for p = 1 : nFet
    subplot(nr,nc,p);
    p_Dsrb2Runs( C1(:,p), C2(:,p), aCol, aLbCond );
    ylabel( LbNfet{p} );
end

for p = 1 : nFet
    Corr(p) = corr( C1(:,p), C2(:,p) );
end
%Corr

subplot(nr,nc,nPlt);
bar(Corr);
set(gca,'xticklabel', LbNfet );

end

