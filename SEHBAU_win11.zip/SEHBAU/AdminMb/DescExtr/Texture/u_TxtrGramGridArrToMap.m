%
% Rearranges the texturegram grids from a single array (as collected with
% collsalc) to a struct with maps.
%
% cf plcCollTxtg.m
% 
% IN    Arr     array, ie. one row of TXTR.GRD (LoadCollTxtr.m)
%       szG     size of the grid (is in header of saliency file)
%       aLb     array of texture bias labels (o_TxtrLabels.m)
% OUT   S       as matrix (for transformer) or struct (for plotting)
%
function [S] = u_TxtrGramGridArrToMap( Arr, szG, aLb )

nLb     = length( aLb );
nGu     = prod( szG );

assert( nLb*nGu == length(Arr), 'dimensions not matching somehow' );

Ix1     = 1:nGu;

S       = struct;
for i = 1:nLb
    
    IxL     = Ix1 + (i-1)*nGu;
    Mp      = reshape( Arr(IxL), szG ); 

    lb      = aLb{i};
    S.(lb)  = Mp';          % transpose for Matlab
end

S.mxV   = max(Arr);

end

