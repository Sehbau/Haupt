%
% Loads texture description of one image as saved as with
% si_TxtrDesc in TxtrIO.h
%
% cf evsbCntx.m, ...
%
function [S Hed] = LoadTxtrDesc( lfp )

bIxOne = 1;                 % we are in Matlab and use one-indexing

%% -----------   Open   ------------
fileID      = fopen(lfp, 'r');
if fileID<0, error('Could not open file %s', lfp); end

%% ------------   Header   -----------
Hed             = ReadTxtdFileHead( fileID, 35 );

%% ------------   GlobalStats  -----------
S.Gst           = ReadTxtrMapStats( fileID ); % map stats

%% ------------   Grams   -----------
% ----  Bandgrams (full)
S.Fll.Bvrt      = ReadMtrxDat( fileID, 'float=>single' ); 
S.Fll.Bhor      = ReadMtrxDat( fileID, 'float=>single' ); 

% ----  Texturegrams (compact)
S.Grm.Grid      = ReadMtrxDat( fileID, 'float=>single' ); 
S.Grm.Bvrt      = ReadMtrxDat( fileID, 'float=>single' ); 
S.Grm.Bhor      = ReadMtrxDat( fileID, 'float=>single' ); 

%% ------------   Blobs (Texture CC)  -----------
% bboxes & asps
S.Blb.Box       = ReadBlobOut( fileID, bIxOne  );       

% freckles
S.Blb.Frkl.Lay  = fread( fileID, 7, 'float=>single' ); 
S.Blb.Frkl.Spa  = ReadBlobStsSpa( fileID );

%% ------------   Spots/Bunt   -----------
S.Spt           = ReadPixvRCf( fileID );
S.Bnt.Pix       = ReadPixvRCf( fileID );
S.Bnt.mxVal     = fread(fileID, 1, 'float=>single');    

% blobgrams size
S.Frkl.Tot      = ReadMtrxDat( fileID, 'int32=>single' ); 
S.Frkl.Vrt      = ReadMtrxDat( fileID, 'int32=>single' ); 
S.Frkl.Hor      = ReadMtrxDat( fileID, 'int32=>single' ); 
S.Frkl.Grt      = ReadMtrxDat( fileID, 'int32=>single' ); 

%idf         = fread(fileID, 1,  'int=>int');    % identifier
%if idf~=-11111, error('idf incorrect'); end

%% ------------   Close   -----------
fclose( fileID );

%DispLoad( lfp );


