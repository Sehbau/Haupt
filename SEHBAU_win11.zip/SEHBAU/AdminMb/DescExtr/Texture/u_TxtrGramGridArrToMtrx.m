%
% Rearranges the texturegram grids from a single array (as collected with
% collsalc) to a matrix [nGrdUnits nTxtBis].
%
% cf plcCollTxtg.m
% 
% IN    Arr     array, ie. one row of TXTR.GRD (LoadCollTxtr.m)
%       szG     size of the grid (is in header of saliency file)
%       nTxtBis number of texture biases 
%       nrm     normalizing divideder for numerosity bias
% OUT   M       [nGrdUnits nTxtBis]
%
function [M] = u_TxtrGramGridArrToMtrx( Arr, szG, nTxtBis, nrm )

nGu     = prod( szG );

assert( nTxtBis*nGu == length(Arr), 'dimensions not matching somehow' );

Ix1     = 1:nGu;

M       = zeros(nGu,nTxtBis,'single');
for i = 1:nTxtBis
    
    IxL     = Ix1 + (i-1)*nGu;
    M(:,i)  = Arr(IxL);
end

% 4th argument is a normalizing divider for the numerosity bias
if nargin>3
    M(:,1) = M(:,1) / nrm;
end

end

