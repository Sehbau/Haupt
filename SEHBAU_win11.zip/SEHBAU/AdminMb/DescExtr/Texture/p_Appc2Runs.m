%
% Compares the texture stats for two runs.
%
% cf plzAlySalc.m
%
function [] = p_Appc2Runs( A1, A2, figNo, aLbCond, aCol )

figure(figNo); clf;

LbAppc = {'min' 'men' 'max' 'bnt' 'ctrRR' 'ctrEdg' 'ctrBon'}; % o_TxtrLabels();

nFet    = 7;
nPlt    = nFet + 1;
[nr nc] = deal(nPlt,1);

%subplot(nr,nc,1);
%p_Dsrb2Runs( A1(:,1), A2(:,1), aCol, aLbCond );
%ylabel( LbTxtr{1} );

for p = 1 : nFet
    subplot(nr,nc,p);
    p_Dsrb2Runs( A1(:,p), A2(:,p), aCol, aLbCond );
    ylabel( LbAppc{p} );
end

for p = 1 : nFet
    Corr(p) = corr( A1(:,p), A2(:,p) );
end
%Corr

subplot(nr,nc,nPlt);
bar(Corr);
set(gca,'xticklabel', LbAppc );

end

