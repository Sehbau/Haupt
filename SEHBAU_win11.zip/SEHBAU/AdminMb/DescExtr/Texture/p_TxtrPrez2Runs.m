%
% Comparse the texture stats for two runs.
%
% cf plzAlySalc.m
%
function [] = p_TxtrPrez2Runs( G1, G2, figNo, aLbCond, aCol )

figure(figNo); clf;

LbTxtr = o_TxtrLabels();

[nr nc] = deal(8,1);

subplot(nr,nc,1);
p_Dsrb2Runs( G1(:,1), G2(:,1), aCol, aLbCond );
ylabel( LbTxtr{1} );

for p = 2 : 7
    subplot(nr,nc,p);
    p_Dsrb2Runs( G1(:,p), G2(:,p), aCol );
    ylabel( LbTxtr{p} );
end

for p = 1 : 7
    Corr(p) = corr( G1(:,p), G2(:,p) );
end
%Corr

subplot(nr,nc,8);
bar(Corr);
set(gca,'xticklabel',LbTxtr);
title('Correlation');

end

