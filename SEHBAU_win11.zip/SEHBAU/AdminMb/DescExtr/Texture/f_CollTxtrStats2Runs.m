%
% Texture statistics for two runs
%
% cf plzAlySalcReso.m
%
% IN   C1, C2   two collection 
%
function [S] = f_CollTxtrStats2Runs( C1, C2 )

S.Gst.Men   = ( C1.Gst.Men + C2.Gst.Men ) / 2;

end

