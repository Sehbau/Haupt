%
% Retrieves freckleness stats from loaded data structure and overwrites the
% original format.
%
% af   u_TxtrGramRtrv.m
% cfro exsbTxtrDesc.m
% 
% IN    F       frecklness as loaded by LoadTxtrDesc.m
%       aLb     array of texture bias labels (o_TxtrLabels.m)
%
function [F] = u_TxtrFrklRtrv( F, aLb )

F.Tot 	= u_MtrxToStcArr( F.Tot, aLb );
F.Vrt 	= u_MtrxToStcArr( F.Vrt, aLb );   % returns [70 1]
F.Hor  	= u_MtrxToStcArr( F.Hor, aLb );
F.Grt  	= u_MtrxToStcArr( F.Grt, aLb );

BLOBGRAM_NBSIZ = 14;
BLOBGRAM_NBAND =  3;

szArr   = [ BLOBGRAM_NBSIZ BLOBGRAM_NBAND ];
szGrt   = [ BLOBGRAM_NBSIZ BLOBGRAM_NBAND BLOBGRAM_NBAND ];

nLab    = length( aLb );
for b = 1:nLab
    lb       	= aLb{b};
    F.Vrt.(lb) 	= reshape( F.Vrt.(lb), szArr );
    F.Hor.(lb) 	= reshape( F.Hor.(lb), szArr );
    F.Grt.(lb) 	= reshape( F.Grt.(lb), szGrt );
end

end

