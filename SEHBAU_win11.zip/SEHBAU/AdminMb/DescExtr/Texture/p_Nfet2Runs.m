%
% Compares the texture stats for two runs.
%
% cf plzAlySalc.m
%
function [] = p_Nfet2Runs( N1, N2, figNo, aLbCond, aCol )

figure(figNo); clf;

LbNfet = {'rdg' 'riv' 'edg' 'bon' }; % o_TxtrLabels();

nFet    = 4;
nPlt    = nFet + 1;
[nr nc] = deal(nPlt,1);

%subplot(nr,nc,1);
%p_Dsrb2Runs( A1(:,1), A2(:,1), aCol, aLbCond );
%ylabel( LbTxtr{1} );

for p = 1 : nFet
    subplot(nr,nc,p);
    p_Dsrb2Runs( N1(:,p), N2(:,p), aCol, aLbCond );
    ylabel( LbNfet{p} );
end

for p = 1 : nFet
    Corr(p) = corr( N1(:,p), N2(:,p) );
end
%Corr

subplot(nr,nc,nPlt);
bar(Corr);
set(gca,'xticklabel', LbNfet );

end

