%
% Rearranges the texturegram grids for a collection (as loaded with
% LoadCollTxtr.m) by calling utility function u_TxtrGramGridArrToMtrx.m
%
% cf plcCollTxtg.m
% 
% IN    TXG     collected grids [nImg x nTxtBis*nGrdUnits]
%       szG     size of the grid (is in header of saliency file)
%       nTxtBis number of texture biases 
%       nrm     normalizing divideder for numerosity bias
% OUT   TXG     [nImg x nGrdUnits*nTxtBis] overwritten
%
function [TXG] = u_TxtrGramGridCollReshape( TXG, szG, nTxtBis, nrm )

[nImg,nFet] = size( TXG );

for i = 1:nImg
    
    Mx      = u_TxtrGramGridArrToMtrx( TXG(i,:), szG, nTxtBis, nrm );
    
    Mx      = Mx';      % for Matlab column-major
    
    TXG(i,:) = Mx(:);
end


end

