%
% Retrieves the texturegram grids from a single array as collected with
% collsalc. Two modes: 
% - as matrix: [nGrdUnits nTxtBis] output useful for transformer
% - as maps: in a struct, output useful for verification by plotting
%
% cf plcCollTxtg.m
% 
% IN    Arr     array, ie. one row of TXTR.GRD (LoadCollTxtr.m)
%       szG     size of the grid (is in header of saliency file)
%       aLb     array of texture bias labels (o_TxtrLabels.m)
% OUT   S       as matrix (for transformer) or struct (for plotting)
%               matrix: nGridUnits (map pixels) x nTxtBiases
%
function [S] = u_TxtrGramGridFromArr( Arr, szG, aLb, bStruct )

nLb     = length( aLb );
nGu     = prod( szG );

assert( nLb*nGu == length(Arr), 'dimensions not matching somehow' );

if nargin==3
    bStruct = 0;
end
Ix1     = 1:nGu;

if not(bStruct)

    % ----------   As Matrix  ----------
    Mx  = zeros(nGu,nLb,'single');
    for i = 1:nLb
    
        IxL     = Ix1 + (i-1)*nGu;
        Mx(:,i) = Arr(IxL);
    end

    S = Mx;
    return;
else
    % ----------   As Individual Maps   ----------
    S       = struct;
    for i = 1:nLb
    
        IxL     = Ix1 + (i-1)*nGu;
        Mp      = reshape( Arr(IxL), szG ); 
    
        lb      = aLb{i};
        S.(lb)  = Mp';          % transpose for Matlab
    end
    S.mxV   = max(Arr);
end


end

