%
% Correlating two runs.
%
% cf plzAlySalcAll.m
%
function [S] = f_TxtrStat2Courses( C1, C2 )

nTxtBis     = size( C1, 2 );

for p = 1 : nTxtBis
    S.Corr(p) = corr( C1(:,p), C2(:,p) );
end

end

