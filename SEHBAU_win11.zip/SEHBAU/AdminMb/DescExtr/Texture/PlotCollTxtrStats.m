%
% Plots the texture stats for a collection as saved with collsalc.cpp and
% loaded with LoadBankVec.m
%
% cf plcMtcTxtColl.m
%
function [] = PlotCollTxtrStats( C, figNo )

if nargin==3, 
    figNo = 1;
end

aLb     = o_TxtrLabels( 1 );

figure(figNo); clf;
[nr,nc]=deal(4,1);
    
subplot(nr,nc,1); 
bar( C.Gst.Men ); 
title('Gst');
grid on;
set(gca, 'ygrid', 'on');
set(gca, 'ytick', [0 : 0.1 : 0.8]);
set(gca, 'ylim', [0 0.85] );
set(gca, 'xticklabel', aLb );
o_TxtrLabels();


subplot(nr,nc,2); 
bar( C.Grd.Men ); 
title('Grid');


subplot(nr,nc,3); 
bar( C.Bnd.Men ); 
title('Band');


subplot(nr,nc,4); 
bar( C.DomOri.Men ); 
[aLsho nBis aLlon] = o_DomOriLabels( );
set(gca, 'xtick', 1 : length(C.DomOri.Men ) );
set(gca, 'xticklabel',aLsho);

title('DomOri');

end

