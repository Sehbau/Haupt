%
% Extracts texture global stats as array [1 nTxtBis]
%
% cf evsbSalcBase.m
%
function [A] = u_TxtrGstToArrs( S )

aBlobLab    = fieldnames( S );

nTyp        = length( aBlobLab );

A.PrpPres   = zeros( nTyp, 1, 'single');
A.Men       = zeros( nTyp, 1, 'single');
A.Sdv       = zeros( nTyp, 1, 'single');

for i = 1:nTyp

    lb          =    aBlobLab{i}; 

    A.PrpPres(i) = S.( lb ).prpPres;
    A.Men(i)     = S.( lb ).men;
    A.Sdv(i)     = S.( lb ).sdv;
end

end

