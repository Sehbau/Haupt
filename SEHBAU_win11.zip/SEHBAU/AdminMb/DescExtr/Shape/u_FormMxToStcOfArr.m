%
% Turns arrays of structs (matrices) into struct of arrays given attribute
% names from o_AttsLabels.m, for form descriptor
%
% af u_DescMxToStcOfArr.m
%
% USE
%  [LbAtts, LbAttSG]   = o_AttsLabels();
%  AFRM                = u_DescMxToStcOfArr( FRM.AFRM, LbAttSG.Frm );
% 
%
function [AFRM] = u_FormMxToStcOfArr( AFRM, Lb ) 

nLev    = length( AFRM );

for l = 1:nLev

    % ----------  form   ----------
    FRM         = AFRM{l};         % extracting one level
    FRM.RdSig   = u_MtrxToStcArr( FRM.RdSig, Lb.RdSig );
    FRM.RospA   = u_MtrxToStcArr( FRM.RospA, Lb.RospA );
    FRM.RospB   = u_MtrxToStcArr( FRM.RospB, Lb.RospB );
    FRM.RoEck   = u_MtrxToStcArr( FRM.RoEck, Lb.RoEck );
    AFRM{l}     = FRM;

end

%% -----------------------   Shape Labels   ---------------------------
% reads them as one array
%D.LabShpScors = ReadAttLab( fileID, size(D.ASHP{1}.STR,2) );
%D.LabShpSfine = ReadAttLab( fileID, size(D.ASHP{1}.SFI,2) );

