%
% Load as saved with w_FeatCoverage.m in A_ANF/Feat/FeatAnf.h
%
function [Cvg] = ReadFeatCoverage( fileID, nLev )

Cvg.Deg      = fread( fileID, nLev, 'float=>single' );
Cvg.mx       = fread( fileID, 1,    'float=>single' );
Cvg.ixMx     = fread( fileID, 1,    'int32=>int32' );
Cvg.Kt       = fread( fileID, nLev, 'int32=>int32' );

