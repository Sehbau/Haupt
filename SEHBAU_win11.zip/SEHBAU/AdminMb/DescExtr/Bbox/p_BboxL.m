% 
% Plots a list of bounding boxes.
%
% see p_BboxLpal.m for plotting with weighted values.
%
% IN   ABbox   list of bboxes as 2D array [nBbx 4] TBLR
%      rgbOrIx 3 input options: rgb triplet, color index or variation
%
function [] = p_BboxL( ABbox, rgbOrIx, bJit )

nBox    = size(ABbox,1);

if nargin<=2
    bJit   	= 1;        % if jitter not specified then use it
end

%% ----------   Color   ----------
if nargin==1, 
    % rgbOrIx = 3;        % if no color specified then take beige
    RGB = repmat( [191 191 0]/255, nBox, 1 );
elseif ischar( rgbOrIx )
    
    if strcmp( rgbOrIx, 'var' )
        RGB = rand( nBox, 3 );
    end
    
elseif isscalar(rgbOrIx) % we use as index
    
    % first generate the palette
    Col(1,:) = [255 255   0]; % yellow
    Col(2,:) = [255 128   0]; % orange
    Col(3,:) = [191 191   0]; % beige
    Col(4,:) = [255 0     0]; % rot
    Col(5,:) = [170 0   255]; % magenta
    Col(6,:) = [0   255 255]; % cyan
    Col(7,:) = [0   0   255]; % blue
    Col(8,:) = [255 255 255]; % white
    
    Col      = Col ./ 255;
    
    % now select by inputted index
    rgbOrIx  = Col(rgbOrIx,:); % overwrites itself
    RGB = repmat( rgbOrIx, nBox, 1 );
    
else
    assert(length(rgbOrIx)==3); % must be a single rgb triplet
    RGB = repmat( rgbOrIx, nBox, 1 );
end

%% ==========   Plot   ==========

for i = 1:nBox
    p_BoundBox1( ABbox(i,:), RGB(i,:), bJit );    
end

end

