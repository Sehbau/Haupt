%
% Plots some of the fabric maps into one figure. 
%
function hf = PlotFbrcMapNum( NM0, NM1, NM2, NM3, figNo, Irgb )

aDty    = {'Cnt' 'Frm' 'Arc' 'Str' 'Shp'};
nDty    = length(aDty);
[nClls nDty] = size(NM0);

hf = figure(figNo); clf;
[nr nc]     = deal(5,nDty);

subplot(nr,nc,1);
imagesc( Irgb ); p_Cross(128);
set(gca,'fontsize',5);
%p_BboxL( SBbxOrg.Hor );
%p_BboxL( SBbxOrg.Vrt );

Lim(1)  = max( NM0(:) );
Lim(2)  = max( NM1(:) );
Lim(3)  = max( NM2(:) );
Lim(4)  = max( NM3(:) );

Dim     = [31 31; 15 15; 7 7; 3 3];

% -------------   Numerosity  ------------
for d = 1:nDty

    subplot(nr,nc,nDty+d);
    Mp = reshape(NM0(:,d), Dim(1,:))';
    imagesc( Mp, [0 Lim(1)] );  p_Cross(128);
    title( aDty{d} );

    subplot(nr,nc,2*nDty+d);
    Mp = reshape(NM1(:,d), Dim(2,:))';
    imagesc( Mp, [0 Lim(2)] ); 
    
    subplot(nr,nc,3*nDty+d);
    Mp = reshape(NM2(:,d), Dim(3,:))';
    imagesc( Mp, [0 Lim(3)] ); 

    subplot(nr,nc,4*nDty+d);
    Mp = reshape(NM3(:,d), Dim(4,:))';
    imagesc( Mp, [0 Lim(4)] ); 
end


end

