%
% Plots band histograms for texture.
%
function [] = p_TxtrBandHist( Hbnd, aLb )

nBand   = length( aLb );

MxV     = zeros(nBand);
for b = 1:nBand
    lb      = aLb{b};
    MxV(b)  = max( [Hbnd.Bvrt.(lb)(:); Hbnd.Bhor.(lb)(:) ] );
end

for b = 1:nBand
    lb      = aLb{b};
    mxN     = MxV(b)*1.05;
    
    % --------   LEFT SIDE   ---------
    subplot( nBand, 2, b*2-1 );
    bar( Hbnd.Bvrt.(lb) );

    set( gca, 'ylim', [0 mxN] );
    set( gca, 'xlim', [0 length(Hbnd.Bvrt.(lb))+1 ] );
    ylabel( lb );
    if b==1
        title( 'Vertical (left>right)', 'fontsize', 12 );
    end
    %if b==nBand
        %set( gca, 'xticklabel', {'left' '.' 'cen' '.' 'right'} );
    %end
    
    % --------   RITE SIDE   ---------
    subplot( nBand, 2, b*2 );
    bar( Hbnd.Bhor.(lb) );

    set( gca, 'ylim', [0 mxN] );
    set( gca, 'xlim', [0 length(Hbnd.Bhor.(lb))+1 ] );
    if b==1
        title( 'Horizontal (top>bottom)', 'fontsize', 12 );
    end
    %if b==nBand
        %set( gca, 'xticklabel', {'top' '.' 'cen' '.' 'bottom'} );
    %end
end

end

