%
% Plots band histograms for texture.
%
function [] = p_TxtrBandHist( Hbnd, aLb )

nBand   = length( aLb );

MxV     = zeros(nBand);
for b = 1:nBand
    lb      = aLb{b};
    MxV(b)  = max( [Hbnd.Bvrt.(lb)(:); Hbnd.Bhor.(lb)(:) ] );
end

for b = 1:nBand
    lb      = aLb{b};
    mxN     = MxV(b)*1.05;
    
    % --------   LEFT SIDE   ---------
    subplot( nBand, 2, b*2-1 );
    bar( Hbnd.Bvrt.(lb) );

    set( gca, 'ylim', [0 mxN] );
    ylabel( lb );
    if b==1
        title( 'Vertical', 'fontsize', 12 );
    end
    %if b==nBand
        set( gca, 'xticklabel', {'left' '.' 'cen' '.' 'right'} );
    %end
    
    % --------   RITE SIDE   ---------
    subplot( nBand, 2, b*2 );
    bar( Hbnd.Bhor.(lb) );

    set( gca, 'ylim', [0 mxN] );
    if b==1
        title( 'Horizontal', 'fontsize', 12 );
    end
    %if b==nBand
        set( gca, 'xticklabel', {'top' '.' 'cen' '.' 'bottom'} );
    %end
end

end

