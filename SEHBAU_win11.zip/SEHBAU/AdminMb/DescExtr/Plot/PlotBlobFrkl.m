%
% Plots freckleness into one figure.
%
% af PlotBlobGramSiz.m
%
% IN   TXM    texture maps as loaded with LoadTxtrMaps.m
%      GRM    blob grams as loaded with LoadDescSalc.m
%
function [] = PlotBlobFrkl( TXM, FRK, figNo, Irgb, aLb )

nLab    = length( aLb );
GRM     = FRK;

%% ---------   Max for each Band   -----------
MxBnd  = zeros(nLab);
MxGrt  = zeros(nLab);
for b = 1:nLab
    lb          = aLb{b};
    MxBnd(b)    = max( [GRM.Vrt.(lb)(:); GRM.Hor.(lb)(:) ] );
    MxGrt(b)    = max( GRM.Grt.(lb)(:) );
end

%% --------------------   Plot   --------------------
figure(figNo); clf;
[nr nc] = deal(nLab+1,4);

% ----------------   Top Row   ---------------
% image 
subplot(nr,nc,1);
imagesc( Irgb );
set(gca,'fontsize',5);
% image 
subplot(nr,nc,2);
%bar( FRK.Tot );
set(gca, 'ylim', [0 1.05] );
title( 'Total' );
set(gca,'xticklabel',aLb);

% -----------------  2nd Row -   -----------------
for b = 1:nLab

    lb      = aLb{b};
    mxN     = max( MxBnd(b)*1.05, 0.05 );
    
    ixL     = b*4+1;
    
    % --------   LEFT COL: Texture Map   ---------
    subplot( nr,nc, ixL );
    if b<3
        imagesc( TXM.KNT.(lb) ); 
    else
        imagesc( TXM.OTX.(lb) ); 
    end
    set( gca, 'fontsize', 5);
    ylabel( lb, 'fontsize', 12 );
    %colorbar;
    
    % --------   2ND COL: Grit   ---------
    subplot( nr,nc, ixL+1 );
    imagesc( GRM.Grt.(lb) ); 
    colorbar;
    set( gca, 'fontsize', 6);
    if b==1
        title( 'Grid', 'fontsize', 12 );
    end
    
    % --------   3RD COL: band vrt  ---------
    subplot( nr,nc, ixL+2 );
    bar( GRM.Vrt.(lb) );
    set( gca, 'ylim', [0 mxN] );
    %set( gca, 'xlim', [0.5 5.5] );
    set( gca, 'fontsize', 8);
    if b==1
        title( 'Vertical', 'fontsize', 12 );
    end
    %ylabel('Size');
    if b==nLab
        xlabel('Band');
        %set( gca, 'xticklabel', {'left' '.' 'cen' '.' 'right'} );
    end
    
    % --------   RITE COL: band hor   ---------
    subplot( nr,nc, ixL+3 );
    bar( GRM.Hor.(lb)' );
    set( gca, 'ylim', [0 mxN] );
    %set( gca, 'xlim', [0.5 5.5] );
    set( gca, 'fontsize', 8);
    if b==1
        title( 'Horizontal', 'fontsize', 12 );
    end
    %ylabel('Band');
    if b==nLab
        xlabel('Band');
        %set( gca, 'xticklabel', {'top' '.' 'cen' '.' 'bottom'} );
    end
    
end


end

