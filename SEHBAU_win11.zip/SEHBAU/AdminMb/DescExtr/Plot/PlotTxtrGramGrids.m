%
% Plots the texturegrams into one figure.
%
% sa p_TxtrBandHist.m, PlotTxtrGrids.m
%
% IN   TXM    texture maps as loaded with LoadTxtrMaps.m
%      GRM    texture grams as loaded with LoadDescSalc.m
%
function [] = PlotTxtrGramGrids( S, figNo, aLb, Irgb )

nLab   = length( aLb );

figure(figNo); clf;
[nr nc] = deal(4,2);

% ----------  the image  ----------
subplot(nr,nc,1);
imagesc( Irgb );
set(gca,'fontsize',5);

% ----------  the grids   ----------
for b = 1:nLab

    lb      = aLb{b};

    if b==1
        Scl = [0 S.mxV];
    else
        Scl = [0 1];
    end
    
    subplot( nr,nc, b+1 );
    imagesc( S.(lb), Scl ); 
    colorbar;
    set( gca, 'fontsize', 6);
    title( lb, 'fontsize', 12 );

end


end

