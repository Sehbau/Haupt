%
% Plots the texture maps into one figure, with or without bounding boxes.
%
function hf = PlotFbrcMaps( FB, HYKO, figNo, Irgb, SBbxLay )

if nargin==5, bBbx = 1; else bBbx = 0; end


hf = figure(figNo); clf;
[nr nc]     = deal(3,4);

subplot(nr,nc,1);
imagesc( Irgb );
set(gca,'fontsize',5);
%p_BboxL( SBbxOrg.Hor );
%p_BboxL( SBbxOrg.Vrt );

mxCnt   = 1; %max( Ndsc.Cnt(:) );
mxFrm   = 1; % max( Ndsc.Frm(:) );
limCnt  = [0 mxCnt];
limFrm  = [0 mxFrm];

fprintf('Lim by %1.3f  %1.3f\n', mxCnt, mxFrm );

Cnt     = FB.Cnt;
Frm     = FB.Frm;

subplot(nr,nc,2);
imagesc( HYKO.Ncnt ); title('Num (Cnt)');
if bBbx, p_BboxL( SBbxLay.Num ); end

subplot(nr,nc,3);
imagesc( HYKO.Nfrm ); title('Num (Frm)');
if bBbx, p_BboxL( SBbxLay.Num ); end


subplot(nr,nc,5);
imagesc( Cnt.Hor, limCnt ); title('Horizontal');
if bBbx, p_BboxL( SBbxLay.Hor ); end

subplot(nr,nc,9);
imagesc( Frm.Hor, limFrm ); %title('Horizontal');
if bBbx, p_BboxL( SBbxLay.Hor ); end


subplot(nr,nc,6);
imagesc( Cnt.Vrt, limCnt ); title('Vertical');
if bBbx, p_BboxL( SBbxLay.Vrt ); end

subplot(nr,nc,10);
imagesc( Frm.Vrt, limFrm ); %title('Horizontal');
if bBbx, p_BboxL( SBbxLay.Vrt ); end


subplot(nr,nc,7);
imagesc( Cnt.Axi, limCnt ); title('Axial');
if bBbx, p_BboxL( SBbxLay.Axi ); end

subplot(nr,nc,11);
imagesc( Frm.Axi, limFrm ); 
if bBbx, p_BboxL( SBbxLay.Axi ); end


subplot(nr,nc,8);
imagesc( Cnt.Nil, limCnt ); title('Nil-Ori');
if bBbx, p_BboxL( SBbxLay.Nil ); end

subplot(nr,nc,12);
imagesc( Frm.Nil, limFrm ); %title('Nil-Ori');
if bBbx, p_BboxL( SBbxLay.Nil ); end

end

