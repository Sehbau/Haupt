%
% Plots radsig space with boundaries into one figure according to some
% geometric conditions.
%
% IN   ARSG   radsig space as loaded by LoadDescImag.m
%      ABON   boundary space 'BSP' as loaded by LoadBonSpc
%
function [] = PlotRsgSpcBon( Irgb, ARSG, ABON, figNo, titStr )

hf = figure(figNo); 
clf; 
set(hf, 'name', ['RadSig ' titStr]);

nLev   = length(ARSG);
if nLev>6, nLev=6; end
[szV szH nCh] = size( Irgb );

% ----------------    Image in UpperLeft   --------------------
subplot(3, 2, 1); imagesc( Irgb );

% ----------------    Space   --------------------
for lev = 1:nLev
    
    RSGlv   = ARSG{lev};              % extracting one level
    ABonLv  = ABON{lev};
    
    subplot(3, 2, lev+1); hold on;
    
    Brou    = RSGlv.EloR < 0.4;       % rather round (not elongated)
    ABonSel = ABonLv( RSGlv.IxBon1(Brou) );
    p_BoundPixLij( ABonSel, 'r' );           

    Belo    = RSGlv.EloR > 0.9;       % elongated
    ABonSel = ABonLv( RSGlv.IxBon1(Belo) );
    p_BoundPixLij( ABonSel, 'b' );           

    Bcncv   = RSGlv.Cncv > 0.8;       % concave
    ABonSel = ABonLv( RSGlv.IxBon1(Bcncv) );
    p_BoundPixLij( ABonSel, 'g' );           
    
    axis ij;
    %set(gca,'xlim',[-0.02 1.02]);
    %set(gca,'ylim',[-0.02 1.02]);
end

end

