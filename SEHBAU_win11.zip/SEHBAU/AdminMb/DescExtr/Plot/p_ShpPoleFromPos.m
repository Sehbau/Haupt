%
% Plots poles of a list of shapes from pos array. 
% 
function [] = p_ShpPoleFromPos( SHP, szI ) 

bUrg    = 0;                        % NOT unit range is default
if nargin==1                        % if a map size is specified
    bUrg = 1;                       % then we deal with absolute coords
end

for i = 1:SHP.nShp

    posV    = SHP.Pos.Vrt(i);       % vertical position 
    posH    = SHP.Pos.Hor(i);       % horizontal position
    rds     = SHP.RAS(i,1);         % radius

    if rds==0                       % is possible if segments near
        rds=0.01;
    end
    
    if bUrg                         % unit range
        posV = 1-posV;              % (ij->Cartes.)
    else
        posV = posV * szI(1);       % scale to absolute coords
        posH = posH * szI(2);
        rds  = rds  * szI(1)/2;     % looks better with /2
    end
        
    wth     = rds*2;                % default for circle
    hgt     = rds*2;

    % plot
    hl = rectangle('position', [posH-rds  posV-rds wth hgt]);
    set(hl, 'curvature', [1 1]);

    % add color:
    red     = SHP.RGB.Red(i);
    grn     = SHP.RGB.Grn(i);
    blu     = SHP.RGB.Blu(i);
    set(hl, 'edgecolor', [red grn blu]);
    
end    
