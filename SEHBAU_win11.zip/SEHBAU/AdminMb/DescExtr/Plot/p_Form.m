%
% Plots forms: high, wide and axial.
%
% ReadRsgAtt.m
%
% af p_ShpAxial.m
%
% We plot boundary pixels, and then colorize them according to attribute
% values.
%
% For ONE level.
%
% IN   FRM   form descriptors for one level
%      ABon  boundaries for one level
% OUT  IxAxi boundary indices of those shapes that were considered axial
%
function [S] = p_Form( FRM, ABonPix )

colGray = [0.8 0.8 0.8];    % default for bounding boxes

drkRed  = [0.8  0  0];      % dark red
fllRed  = [1.0  0  0];      % brightest (full) red
    
drkBlu  = [0  0.2  0.6];    % blue
fllBlu  = [0  0    1.0];

drkGrn  = [0  0.5  0];      % green
fllGrn  = [0  1.0  0];

RospA       = FRM.RospA;

nFrm        = length(FRM.IxBon1);
S.IxAxi     = zeros(nFrm,1,'int32');
S.Typ       = zeros(nFrm,1,'int32');
c=0;
for f = 1:nFrm
    
    ixBon   = FRM.IxBon1(f);    % already one-indexing (see loading rout)
    BonPix  = ABonPix{ ixBon };    % in (pixel) map coordinates
    
    hp  = plot( BonPix.Cl, BonPix.Rw, 'color', colGray );

    if RospA.AreN(f) > 0.15, continue; end % skip very large forms
  
    % extract attributes
    higAny = RospA.High(f);      % high (elongation)
    widAny = RospA.Wide(f);      % wide (elongation)
    axiAny = RospA.Axial(f);     % axiality
    
    higVol = RospA.Higv(f);      % high volum
    widVol = RospA.Widv(f);      % wide volum
    axiFin = axiAny RospA.Volm(b); % axiality volm
    
    col = -1;
    if higAny>0.5,  col = drkRed; typ=1;  end % dark red
    if higVol>0.5,  col = fllRed; typ=2; end % full red
    
    %if ori==0, set(hp, 'color', [1.0 0 0]); end
    if widAny>0.5,  col = drkBlu; typ=3; end % dark blue
    if widVol>0.5,  col = fllBlu; typ=4; end % full blue
    
    if axiAny>0.5,  col = drkGrn; typ=5; end % dark green
    %if axiFin>0.5,  col = fllGrn; typ=6; end % full green
    
    if col(1)>-1
        set(hp, 'color', col);
        c = c+1;
        S.IxAxi(c) = ixBon;
        S.Typ(c)   = typ;
    end
end

% trim
S.IxAxi = S.IxAxi(1:c);
S.Typ   = S.Typ(1:c); 

end

