%
% Plots values at descriptor keypoints (absolute coordinates only).
%
% It's an extension of p_DescKeyPts.m
%
% IN       typ   'ep3_is_mip' 
%
function [] = p_DkypVls( PT, VL, StsV, typ )

if strcmp( typ, 'btw_is_mip' )
    PT.Mip   = PT.Btw;
    VL.Mip   = VL.Btw;
elseif strcmp( typ, 'ep3_is_mip' )
    PT.Mip   = PT.Ep3;
    VL.Mip   = VL.Ep3;
else
    error('typ %s not specified');
end

min = StsV.min; 
max = StsV.max; 
rng = max-min;

nDsc = size(PT.Ep1,1);

for i = 1:nDsc

    Ep1 = PT.Ep1(i,:);
    Ep2 = PT.Ep2(i,:);
    Mip = PT.Mip(i,:); 
    
    ve1 = VL.Ep1(i);
    ve2 = VL.Ep2(i);
    vmp = VL.Mip(i);
    
    ve1 = ( ve1-min ) / rng;
    ve2 = ( ve2-min ) / rng;
    vmp = ( vmp-min ) / rng;
    
    if strcmp( typ, 'btw_is_mip' )
        % absolute coordinates, ij format
        % X/Y, alora C/R
        %line([ Ep1(2)  Mip(2) ],  [ Ep1(1)  Mip(1) ], 'color', col);
        %line([ Mip(2)  Ep2(2) ],  [ Mip(1)  Ep2(1) ], 'color', col);
    
        col1 = [ve1 ve1 ve1];
        col2 = [ve2 ve2 ve2];
        colm = [vmp vmp vmp];
        
        % --- only the endpoints
        plot( Ep1(2), Ep1(1), '.', 'color', col1 );
        plot( Ep2(2), Ep2(1), '.', 'color', col2 );
        plot( Mip(2), Mip(1), '.', 'color', colm );
        
        % --- make it a line of 4 segments (4 quarters)
        Qp1     = ( Ep1 + Mip ) / 2;        % quarter point btw Ep1 and Mip
        Qp2     = ( Ep2 + Mip ) / 2;
        
        % the end quarter-segments in colors 'col1' and 'col2'
        % the two center quarter-segments in color 'colm'
        line([ Ep1(2)  Qp1(2) ],  [ Ep1(1)  Qp1(1) ], 'color', col1 );
        line([ Ep2(2)  Qp2(2) ],  [ Ep2(1)  Qp2(1) ], 'color', col2 );
        line([ Qp1(2)  Mip(2) ],  [ Qp1(1)  Mip(1) ], 'color', colm );
        line([ Qp2(2)  Mip(2) ],  [ Qp2(1)  Mip(1) ], 'color', colm );
        
    else
        error('typ %s not specified');
    end
    
end


end

