%
% Plots a list of rocts with values.
%
% cf PlotFormSpcBon.m, PlotCntSpcKeyPts.m
%
function [ ] = p_RoctVls( Roct, IxSel, VLS, StsV )

nCrv    = size( Roct.Topp, 1);

if nargin==1
    IxSel   = 1:nCrv;
    col     = 'rand';
elseif nargin==2
    nCrv    = length(IxSel);
    col     = 'rand';
else
    if isscalar( IxSel ) && IxSel==-1
        IxSel   = 1:nCrv;
    else
        nCrv    = length(IxSel);
    end
end

if isscalar( IxSel ) && IxSel==-1
    IxSel   = 1:nCrv;
end

min  = StsV.min; 
max  = StsV.max; 
rngV = max-min;

liwi = 1;
off  = 0.2;

for i = 1:nCrv

    ix   = IxSel(i);
    Vls  = VLS(ix,:);
    
    topp = single(Roct.Topp(ix)) - off;
    bott = single(Roct.Bott(ix)) + off;
    leff = single(Roct.Leff(ix)) - off;
    ritt = single(Roct.Ritt(ix)) + off;

    tole = single(Roct.Tole(ix)) - off;
    tori = single(Roct.Tori(ix)) + off;
    rito = single(Roct.Rito(ix)) - off;
    ribo = single(Roct.Ribo(ix)) + off;
    
    bole = single(Roct.Bole(ix)) - off;
    bori = single(Roct.Bori(ix)) + off;
    leto = single(Roct.Leto(ix)) - off;
    lebo = single(Roct.Lebo(ix)) + off;
    
    Xco = single( [tole tori ritt ritt bori bole leff leff] +1 );
    Yco = single( [topp topp rito ribo bott bott lebo leto] +1 );
    
    if 0
        
        hp = plot( single(Xco), single(Yco), '.-');
             plot( single(Xco), single(Yco), 'k.', 'markersize', 4 );
    else 
        
        Xco = [Xco tole];
        Yco = [Yco topp];
        Vls = [Vls Vls(1)];
        Vm  = ( Vls(1:8) + Vls(2:9) ) / 2 ;
        Vm  = ( Vm - min ) / rngV;
        %Vm
        for s = 1:8
            
            rg = [ s s+1 ];
            hp = plot( Xco(rg), Yco(rg), '.-');
                 plot( Xco(rg), Yco(rg), 'k.', 'markersize', 4 );
            
            col = [ Vm(s) Vm(s) Vm(s) ];
            set(hp, 'color', col);          
            set(hp, 'linewidth', liwi );

        end
    end
 
end

end

