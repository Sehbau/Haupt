%
% Plots region pixels of a universe as color by default or as gray-scale if
% specified with third argument
%
% IN   AREG   region universe {nLev}{depth}
% 
function [] = PlotRegUnv( AREG, SzM, bGray )

if nargin==2
    bGray = 0;
else
    bGray = strcmp( bGray, 'gray');
end

[nLev depth] = size( AREG );

%% -----   Compute Map Sizes   -------
% we compute pyramid level sizes. scale space would use same size for all
% maps.
if length(SzM)<=3

    szI     = SzM;
    SzM     = zeros( nLev, 2 );
    SzM(1,:) = szI(1:2);
    for l = 2:nLev
        SzM(l,:) = SzM(l-1,:) / 2;
    end
end

%% -----   Plot Pixels   ------
[nr nc]     = deal(nLev, depth);    % # of rows/cols for subplots
for l = 1:nLev
    
    szI         = SzM(l,:);
    [szV, szH]   = deal( szI(1), szI(2) );

    for d = 1:depth
        
        REG     = AREG{ l, d };
        
        [Mgry Irgb] = u_RegPixToMapD1( REG, szI );
        
        % -----------   Plot   -------------
        subplot(nr, nc, depth * (l-1) + d ); hold on;
        if bGray
            imagesc(Mgry); colormap(gray);
        else
            imagesc(Irgb);
        end
        
        axis tight;
        set(gca,'fontsize',5);
        if l==1, title( ['depth ' num2str(d-1)], 'fontsize', 12); end
        if d==1, ylabel(['Lev = ' num2str(l-1)], 'fontsize', 12); end
    end
    
end