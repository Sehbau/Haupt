%
% Plot a space of keypoints
%
% af PlotCntSpcKeyPts.m
%
function [] = PlotDescSpcKeyPts( Irgb, typSpc, AKey, figNo, titStr )

hf  = figure(figNo); clf;
set( hf, 'name', titStr );

if typSpc==1,
    [APyr nLev] = f_ImgPyr( Irgb );
else
    nLev = length(AKey);
    warning('scale space not verified yet');
end

for l = 1:nLev

    subplot( ceil(nLev/2), 2, l);

    if typSpc==1
        imagesc( APyr{l} );
    else
        imagesc( Irgb );
    end
    
    p_DescKeyPts( AKey{l}, 'k' );

end

end

