%
% Plots the descriptor keypoints given as four points. Absolute coordinates
% only.
%
% af p_CntKeyPts.m
% cf PlotDescSpcKeyPts.m
%
% IN    PT    struct with four fields, Ep1-4
%       col   color
%
function [] = p_DescKeyPts( PT, col )

nDsc = size(PT.Ep1,1);

for i = 1:nDsc

    Ep1 = PT.Ep1(i,:);
    Ep2 = PT.Ep2(i,:);
    Mip = PT.Btw(i,:); 
    
    % absolute coordinates, ij format
    % X/Y, alora C/R
    line([ Ep1(2)  Mip(2) ],  [ Ep1(1)  Mip(1) ], 'color', col);
    line([ Mip(2)  Ep2(2) ],  [ Mip(1)  Ep2(1) ], 'color', col);
    
end


end

