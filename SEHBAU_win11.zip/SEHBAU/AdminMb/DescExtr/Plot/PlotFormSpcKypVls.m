%
% Plot a space of keypoints for the form descriptor.
%
% af PlotCntSpcKeyPts.m
%
function [] = PlotFormSpcKypVls( typSpc, szI, StsMp, AKey, AVls, figNo, titStr )

hf = figure(figNo); clf;
set( hf, 'name', titStr );

nLev = length(AKey);

if typSpc==1,
    % do nothing
else
    warning('scale space not verified yet');
end


for l = 1:nLev

    subplot( ceil(nLev/2), 2, l);

    if typSpc==1
        imagesc( zeros( szI / (2^(l-1)) ) );    
    else
        imagesc( zeros( szI ) );
    end
    hold on;
    
    nRoct       = length( AKey{l}.Tole );
    
    p_RoctVls( AKey{l}, 1:nRoct, AVls{l}, StsMp );

end

end

