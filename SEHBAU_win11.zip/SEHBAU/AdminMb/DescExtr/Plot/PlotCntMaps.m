%
% Plots the contour MAP universe.
%
function [] = PlotCntMaps( C, figNo, Irgb )

fprintf('Plotting contour maps...');

hf = figure(figNo); 
clf; 
set(hf, 'name', 'CntMaps' );

nLev   = C.nLev;

%% ---------   Place image first if desired   -------------
if nargin==2
    st  = 1;
    nr  = nLev;
else
    st  = 0;
    nr  = nLev+1;
    subplot( nr, 3, 1 ); 
    imagesc( Irgb );
    set(gca,'fontsize',5);
end

%% ---------   The Levels   -------------
for l = 1:nLev
    
    % extracting one level
    RDGlv = C.ARDG{l};              
    RIVlv = C.ARIV{l};              
    EDGlv = C.AEDG{l};              
    
    ixP   = ( l - st ) * 3;          % plotting index
    %ixP
    subplot( nr, 3, ixP+1 ); 
    imagesc(RDGlv);
    set(gca,'fontsize',5);
    ylabel(['Lev ' num2str(l)], 'fontsize', 12 );
    
    if l==1, title('Ridge', 'fontsize', 12 ); end
    
    subplot( nr, 3, ixP+2 ); 
    imagesc(RIVlv);
    set(gca,'fontsize',5);
    if l==1, title('River', 'fontsize', 12 ); end
    
    subplot( nr, 3, ixP+3 ); 
    imagesc(EDGlv);
    set(gca,'fontsize',5);
    if l==1, title('Edge', 'fontsize', 12 ); end

    fprintf('%d', l);
end

fprintf('done\n');

end

