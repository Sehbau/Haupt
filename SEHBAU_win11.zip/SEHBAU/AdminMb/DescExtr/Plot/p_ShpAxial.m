%
% Plots axial shapes: vertical, horizontal and both (the latter is
% typically called axial, but the former two are also considered 'axial').
%
% We plot boundary pixels, and then colorize them according to attribute
% values.
%
% For ONE level.
%
% IN   SHP   shape descriptors for one level
%      ABon  boundaries for one level
% OUT  IxAxi boundary indices of those shapes that were considered axial
%
function [S] = p_ShpAxial( SHP, ABonPix )

colGray = [0.8 0.8 0.8];    % default for bounding boxes

drkRed  = [0.8  0  0];      % dark red
fllRed  = [1.0  0  0];      % brightest (full) red
    
drkBlu  = [0  0.2  0.6];    % blue
fllBlu  = [0  0    1.0];

drkGrn  = [0  0.5  0];      % green
fllGrn  = [0  1.0  0];

nShp   	= length(SHP.IxBon1);
S.IxAxi	= zeros(nShp,1,'int32');
S.Typ  	= zeros(nShp,1,'int32');
c=0;
for b = 1:nShp
    
    ixBon   = SHP.IxBon1(b);    % already one-indexing (see loading rout)
    BonPix  = ABonPix{ ixBon }; % in (pixel) map coordinates
    
    hp  = plot( BonPix.Cl, BonPix.Rw, 'color', colGray );

    Scors   = SHP.STR; 
    Sfine   = SHP.SFI; 
    
    % extract attributes
    vrtCrs  = Scors.Vrt(b);      % verticality coarse
    horCrs  = Scors.Hor(b);      % horizontality coarse
    axiCrs  = Scors.Axi(b);      % axiality coarse
    
    vrtFin  = Sfine.Vrt(b);      % verticality fine
    horFin  = Sfine.Hor(b);      % horizontality fine
    axiFin  = Sfine.Axi(b);      % axiality fine
    
    col = -1;
    if vrtCrs>0.5,  col = drkRed; typ=1;  end % dark red
    if vrtFin>0.5,  col = fllRed; typ=2; end % full red
    
    %if ori==0, set(hp, 'color', [1.0 0 0]); end
    if horCrs>0.5,  col = drkBlu; typ=3; end % dark blue
    if horFin>0.5,  col = fllBlu; typ=4; end % full blue
    
    if axiCrs>0.5,  col = drkGrn; typ=5; end % dark green
    if axiFin>0.5,  col = fllGrn; typ=6; end % full green
    
    if col(1)>-1
        set(hp, 'color', col);
        c = c+1;
        S.IxAxi(c) = ixBon;
        S.Typ(c)   = typ;
    end
end

% trim
S.IxAxi = S.IxAxi(1:c);
S.Typ   = S.Typ(1:c); 

end

