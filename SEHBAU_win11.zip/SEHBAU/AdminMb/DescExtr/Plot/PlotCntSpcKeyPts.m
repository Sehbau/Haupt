%
% Plot a space of keypoints. Used for RRE set.
%
function [] = PlotCntSpcKeyPts( Irgb, typSpc, ACNT, figNo )

figure(figNo); clf;

if typSpc==1,
    [APyr nLev] = f_ImgPyr( Irgb );
else
    nLev = length(ACNT);
    warning('scale space not verified yet');
end

for l = 1:nLev

    subplot( ceil(nLev/2), 2, l);

    if typSpc==1
        imagesc( APyr{l} );
    else
        imagesc( Irgb );
    end
    
    p_CntKeyPts( ACNT{l}, 'k', 'abs' );

end

end

