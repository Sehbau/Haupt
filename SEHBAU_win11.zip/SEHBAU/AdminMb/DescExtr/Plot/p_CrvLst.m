%
% Plots a list of curves from a struct as created with crvPix (CurveAnf.h)
% and as written by w_CrvPixBlok in CurveIO.h
%
% cf PlotCntCrvPix.m
%
function [ ] = p_CrvLst( S, col )

szM     = [S.szH S.szV];

for c = 1:S.nCrv
    
    nPx     = S.Npx(c);
    anf     = S.Anf(c);

    [I,J]   = ind2sub( szM, S.Ix( anf:anf+nPx-1 ) );
    
    hp      = plot( I, J );
    set( hp, 'color', col );
    
end

end

