%
% Plots a list of rocts.
%
% cf PlotFormSpcBon.m, PlotCntSpcKeyPts.m
%
function [ ] = p_RoctList( Roct, IxSel, col, bEckOnly )

nCrv    = size( Roct.Topp, 1);

if nargin==1
    IxSel   = 1:nCrv;
    col     = 'rand';
elseif nargin==2
    nCrv    = length(IxSel);
    col     = 'rand';
else
    if isscalar( IxSel ) && IxSel==-1
        IxSel   = 1:nCrv;
    else
        nCrv    = length(IxSel);
    end
end

if isscalar( IxSel ) && IxSel==-1
    IxSel   = 1:nCrv;
end

if ischar( col ) && strcmp( col, 'rand' )
    bRand = 1;
else
    bRand = 0;
end

if nargin < 4
    bEckOnly = 0;
end

liwi = 1;
off  = 0.2;

for i = 1:nCrv

    ix   = IxSel(i);
    
    topp = single(Roct.Topp(ix)) - off;
    bott = single(Roct.Bott(ix)) + off;
    leff = single(Roct.Leff(ix)) - off;
    ritt = single(Roct.Ritt(ix)) + off;

    tole = single(Roct.Tole(ix)) - off;
    tori = single(Roct.Tori(ix)) + off;
    rito = single(Roct.Rito(ix)) - off;
    ribo = single(Roct.Ribo(ix)) + off;
    
    bole = single(Roct.Bole(ix)) - off;
    bori = single(Roct.Bori(ix)) + off;
    leto = single(Roct.Leto(ix)) - off;
    lebo = single(Roct.Lebo(ix)) + off;
    
    Xco = [tole tori ritt ritt bori bole leff leff]+1;
    Yco = [topp topp rito ribo bott bott lebo leto]+1;
    
    if 0
        XaxV = [ single(tole+tori)/2  single(bole+bori)/2 ] + 1;
        YaxV = [  topp          bott  ] + 1;
        XaxH = [  leff          ritt  ] + 1;
        YaxH = [ single(leto+lebo)/2  single(rito+ribo)/2 ] + 1;
    end

    if bEckOnly
         plot( single(Xco), single(Yco), 'k.', 'markersize', 4 );
    else
        hp = plot( single(Xco), single(Yco), '.-');
             plot( single(Xco), single(Yco), 'k.', 'markersize', 4 );

        if 0
            haxV = plot( single(XaxV), single(YaxV), 'k:');
            haxH = plot( single(XaxH), single(YaxH), 'k:');
        end

    if bRand
        col = rand(1,3);
    end

    set(hp, 'color', col);          
    set(hp, 'linewidth', liwi );
    end
 
end

end

