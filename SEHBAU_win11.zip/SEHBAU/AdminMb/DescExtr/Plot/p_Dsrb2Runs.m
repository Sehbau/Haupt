%
% Comparse two distributions from two runs.
%
% cf plzAlySalc.m
%
function [] = p_Dsrb2Runs( R1, R2, aCol, aLb )

hold on;

plot( R1, 'color', aCol{1} );
plot( R2, 'color', aCol{2} );

if nargin>3
    legend(aLb);
end

end

