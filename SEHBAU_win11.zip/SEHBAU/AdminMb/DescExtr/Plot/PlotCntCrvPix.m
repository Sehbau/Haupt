%
% Plots the contour curve (segment) pixels for a universe.
%
function [] = PlotCntCrvPix( C, figNo, Irgb )

fprintf('Plotting contour curves...');

hf = figure(figNo); 
clf; 
set(hf, 'name', 'CntCrvPix ');

nLev    = C.nLev;

%% ---------   Place image first if desired   -------------
if nargin==2
    st  = 0;
    nr  = ceil( nLev/2);
else
    nr  = ceil( (nLev+1)/2);
    st  = 1;
    subplot( nr, 2, 1 ); 
    imagesc( Irgb );
    set(gca,'fontsize',5);
end

%% ---------   The Levels   -------------
for l = 1:nLev
    
    % extracting one level
    RDGlv = C.ARDG{l};      % ridges          
    RIVlv = C.ARIV{l};      % rivers
    EDGlv = C.AEDG{l};      % edges

    subplot( nr, 2, st+l ); hold on;
    
    p_CrvLst( EDGlv, 'c' );
    p_CrvLst( RDGlv, 'r' );
    p_CrvLst( RIVlv, 'b' );
    
    axis tight;
    axis ij;
    set(gca,'fontsize',5);
    set(gca,'xlim',[1 RDGlv.szH]);
    set(gca,'ylim',[1 RDGlv.szV]);

    fprintf('%d', l);
end

fprintf('done\n');

end

