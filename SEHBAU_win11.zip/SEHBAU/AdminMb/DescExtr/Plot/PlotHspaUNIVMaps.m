%
% cf evsbDbin.m evsbFabric.m
%
function [ ] = PlotHspaUNIVMaps( MNum, figNo, titStr )

hf = figure( figNo ); clf; set( hf, 'name', titStr );

[nr nc] = deal(3,2);

subplot( nr,nc,1); imagesc( MNum.Cnt ); colorbar(); title('Cnt');
subplot( nr,nc,2); imagesc( MNum.Frm ); colorbar(); title('Frm');
subplot( nr,nc,3); imagesc( MNum.Arc ); colorbar(); title('Arc');
subplot( nr,nc,4); imagesc( MNum.Str ); colorbar(); title('Str');
subplot( nr,nc,5); imagesc( MNum.Shp ); colorbar(); title('Shp');

end

