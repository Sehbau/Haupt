%
% Plot a space of values taken at keypoints
%
% af PlotCntSpcKeyPts.m
% cf evsbReadAtDpt.m
%
function [] = PlotDkypVlsSpc( typSpc, szI, StsMp, AKyp, AVls, figNo, figTit )

hf = figure(figNo); clf;
set(hf,'name',figTit);

nLev = length(AKyp);

if typSpc==1,
    % do nothing
else
    warning('scale space not verified yet');
end

for l = 1:nLev

    subplot( ceil(nLev/2), 2, l);

    if typSpc==1
        imagesc( zeros( szI / (2^(l-1)) ) );    
    else
        imagesc( zeros( szI ) );
    end
    hold on;
    
    p_DkypVls( AKyp{l}, AVls{l}, StsMp, 'btw_is_mip' );

end

end

