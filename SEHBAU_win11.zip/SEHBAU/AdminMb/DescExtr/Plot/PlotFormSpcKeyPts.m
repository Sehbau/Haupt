%
% Plot a space of keypoints for the form descriptor.
%
% af PlotCntSpcKeyPts.m
%
function [] = PlotFormSpcKeyPts( Irgb, typSpc, AKey, figNo, titStr )

hf = figure(figNo); clf;
set( hf, 'name', titStr );

if typSpc==1,
    [APyr nLev] = f_ImgPyr( Irgb );
else
    nLev = length(AKey);
    warning('scale space not verified yet');
end

for l = 1:nLev

    subplot( ceil(nLev/2), 2, l);

    if typSpc==1
        imagesc( APyr{l} );
    else
        imagesc( Irgb );
    end
    hold on;
    
    nRoct       = length( AKey{l}.Tole );
    
    bEckOnly    = 0;
    col         = double([0.5 0.5 0.5]);
    p_RoctList( AKey{l}, 1:nRoct, col, bEckOnly );

end

end

