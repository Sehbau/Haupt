%
% Plots a list of lines from structure patLin.
%
% IN  Pat   pattern as produced by cntpat.exe
%     col   either as vector [1 3] E [0..1] or as a list [nLin 3] E [0..1]
%
% af p_CntFromVect
%
function [] = p_PatLin( Pat, col ) 

%Les    = sqrt( sum( (Pat.Ep1-Pat.Ep2).^2, 2) );

%% --------------   Color Code for Lines   ----------------
bColByTyp    = 0;
if ischar( col )
    bColByTyp = strcmp(col,'typ');
elseif isstruct( col )
    Red     = col.Red;
    Grn     = col.Grn;
    Blu     = col.Blu;
elseif isvector(col)
    Red     = ones(Pat.nLin,1) * col(1);
    Grn     = ones(Pat.nLin,1) * col(2);
    Blu     = ones(Pat.nLin,1) * col(3);
else
    % we assume it is an array [nLin 3]
end

% in case we have a typ specified
if bColByTyp
    Col(1,:) = [1 0 0]; % ridge red
    Col(2,:) = [0 0 1]; % river blue
    Col(3,:) = [0 1 1]; % edge  cyan
end

%% --------------   Loop Lines   ----------------
Ep1     = Pat.Ep1;
Ep2     = Pat.Ep2;

for i = 1:Pat.nLin

    %ori     = Pat.Ori(i);       	% orientation angle
    %les     = Les(i);          	% length
    wgt     = Pat.Wgt(i);         	% weight
    typ     = Pat.Typ(i);
        
    hl = line( [ Ep1(i,2) Ep2(i,2) ], [ Ep1(i,1) Ep2(i,1) ] );
    
    % add color:
    if typ>0 && bColByTyp
        set(hl, 'color', Col(typ,:));
    else
        set(hl, 'color', [ Red(i) Grn(i) Blu(i) ]);
    end
    
    % make linewidth proportional to contrast:
    set(hl, 'linewidth', 0.2 + 4*wgt); % 0.2 is minimum width
    
end    
