%
% Plots form space with boundaries into one figure according to some
% geometric conditions.
%
% cf evsbRshd.m
%
% IN   AFRM   form space as loaded by LoadDescImag.m
%      ABON   boundary space 'BSP' as loaded by LoadBonSpc
%
function [] = PlotFrmSpcBon( Irgb, AFRM, ABON, type, figNo, titStr )

hf = figure(figNo); 
clf; 
set(hf, 'name', ['RadSig ' titStr]);

nLev   = length(AFRM);
if nLev>6, nLev=6; end
[szV szH nCh] = size( Irgb );

% ----------------    Image in UpperLeft   --------------------
subplot(3, 2, 1); imagesc( Irgb );

% ----------------    Space   --------------------
for lev = 1:nLev
    
    RSGlv   = AFRM{lev}.RdSig;        % extracting one level
    IxBon1  = AFRM{lev}.IxBon1;       % extracting indices
    ABonLv  = ABON{lev};
    
    subplot(3, 2, lev+1); hold on;
    
    if strcmp( type,'all' )
        
        ABon = ABonLv( IxBon1 );
        p_BoundPixLij( ABon, 'k' );           
        
    elseif strcmp( type, 'sel' );
        
        Brou    = RSGlv.EloR < 0.4;       % rather round (not elongated)
        ABonSel = ABonLv( IxBon1(Brou) );
        p_BoundPixLij( ABonSel, 'r' );
        
        Belo    = RSGlv.EloR > 0.9;       % elongated
        ABonSel = ABonLv( IxBon1(Belo) );
        p_BoundPixLij( ABonSel, 'b' );
        
        Bstar   = RSGlv.Star > 0.8;       % starness
        ABonSel = ABonLv( IxBon1(Bstar) );
        p_BoundPixLij( ABonSel, 'g' );
    else
        error('type not specified');
    end
    axis ij;
    %set(gca,'xlim',[-0.02 1.02]);
    %set(gca,'ylim',[-0.02 1.02]);
end

end

