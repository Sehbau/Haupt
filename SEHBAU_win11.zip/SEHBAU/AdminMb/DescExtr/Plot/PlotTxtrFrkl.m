%
% Plots the freckleness.
%
% sa p_TxtrBandHist.m, PlotTxtrGrids.m
%
% IN   TXM    texture maps as loaded with LoadTxtrMaps.m
%      F      frecklness as loaded with LoadTxtrDesc.m
%
function [] = PlotTxtrFrkl( TXM, F, figNo, Irgb, aLb )

nLab   = length( aLb );

%% ---------   Max for each Band   -----------
MxBnd  = zeros(nLab);
MxTot  = zeros(nLab);
for b = 1:nLab
    lb          = aLb{b};
    MxBnd(b)    = max( [F.Vrt.(lb)(:); F.Hor.(lb)(:) ] );
    MxTot(b)    = max( F.Tot.(lb)(:) );
end

%% --------------------   Plot   --------------------
figure(figNo); clf;
[nr nc] = deal(nLab+1,4);

subplot(nr,nc,1);
imagesc( Irgb );
set(gca,'fontsize',5);

for b = 1:nLab

    lb      = aLb{b};
    mxN     = max( MxBnd(b)*1.05, 0.05) ;
    
    ixL     = b*4+1;
    
    % --------   LEFT COL: Texture Map   ---------
    subplot( nr,nc, ixL );
    if b<3
        imagesc( TXM.KNT.(lb) ); 
    else
        imagesc( TXM.OTX.(lb) ); 
    end
    set( gca, 'fontsize', 5);
    ylabel( lb, 'fontsize', 12 );
    %colorbar;
    
    % --------   2ND COL: Sizegram   ---------
    subplot( nr,nc, ixL+1 );
    bar( F.Tot.(lb) ); 
    colorbar;
    set( gca, 'fontsize', 6);
    if b==1
        title( 'Size', 'fontsize', 12 );
    end
    
    % --------   3RD COL: band vrt  ---------
    subplot( nr,nc, ixL+2 );
    imagesc( F.Vrt.(lb), [0 mxN] );
    %set( gca, 'ylim', [0 mxN] );
    %set( gca, 'xlim', [0.5 5.5] );
    set( gca, 'fontsize', 8);
    if b==1
        title( 'Vertical', 'fontsize', 12 );
    end
    ylabel('Size');
    if b==nLab
        xlabel('Band');
        %set( gca, 'xticklabel', {'left' '.' 'cen' '.' 'right'} );
    end
    
    % --------   RITE COL: band hor   ---------
    subplot( nr,nc, ixL+3 );
    imagesc( F.Hor.(lb)', [0 mxN] );

    %set( gca, 'ylim', [0 mxN] );
    %set( gca, 'xlim', [0.5 5.5] );
    set( gca, 'fontsize', 8);
    if b==1
        title( 'Horizontal', 'fontsize', 12 );
    end
    ylabel('Band');
    if b==nLab
        xlabel('Size');
        %set( gca, 'xticklabel', {'top' '.' 'cen' '.' 'bottom'} );
    end
    
end


end

