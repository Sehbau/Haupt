%
% Reads a space of dominance biases (for orientations)
%
% cf ReadDescStats.m
%
function [S Mx] = ReadOriDomSpcF( fid )

S       = struct;

S.nLev  = fread( fid, 1, 'int=>single' );

Mx      = zeros( S.nLev, 6, 'single');

for l = 1:S.nLev
     
    [S.ALev(l) A] = ReadOriDomF( fid );
     
     Mx(l,:)    = A;
end

end

