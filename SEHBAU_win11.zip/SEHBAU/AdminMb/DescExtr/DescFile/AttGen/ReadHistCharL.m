%
% Reads histogram parameters as saved under w_HistCharL
%
% cf LoadRegAPPSTATS.m
%
function [S nReg] = ReadHistCharL( fid )

S       = [];

%%  ====================   Header   ====================
nReg    = fread( fid, 1, 'int=>single'); % # descriptors
%nReg

%%  ====================   Data   ====================

S.Nval  = fread(fid, nReg, 'int=>int32'); 
S.Nslp  = fread(fid, nReg, 'int=>int32'); 

S.Dom   = fread(fid, nReg, 'float=>single'); 
S.Flt   = fread(fid, nReg, 'float=>single'); 
S.Pkn   = fread(fid, nReg, 'float=>single'); 
S.Tig   = fread(fid, nReg, 'float=>single'); 

S.Thr   = fread(fid, nReg, 'int=>int32'); 
S.Ix2Reg= fread(fid, nReg, 'int=>int32'); 

% =====   Trailer   =====
%idf    = fread(fid, 1, 'int16=>int');
%assert(idf==1111);


end

