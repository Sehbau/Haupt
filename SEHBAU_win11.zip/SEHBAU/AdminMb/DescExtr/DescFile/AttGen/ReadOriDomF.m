%
% Reads the dominance biases for orientations
%
% cf ReadOriDomSpcF.m, ReadDescStats.m
%
function [S A] = ReadOriDomF( fid )

S.vrt     = fread( fid, 1, 'float=>single' );
S.hor     = fread( fid, 1, 'float=>single' );
S.obl     = fread( fid, 1, 'float=>single' );
S.axi     = fread( fid, 1, 'float=>single' );
S.uni     = fread( fid, 1, 'float=>single' );
S.nil     = fread( fid, 1, 'float=>single' );

A       = [S.vrt S.hor S.obl S.axi S.uni S.nil];

end

