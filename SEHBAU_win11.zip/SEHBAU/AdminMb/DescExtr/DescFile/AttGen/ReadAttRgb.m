%
% Reads rgb values as saved under Rgb.h-w_RgbArrF
% cf eg ReadCntAtt.m
% sa ReadAttPos.m
%
function [C] = ReadAttRgb(fileID, nDsc, conversion )

if nargin==2
    conversion = 'float=>single';
end

C       = [];

C.Red   = fread(fileID, nDsc, conversion );
C.Grn   = fread(fileID, nDsc, conversion );
C.Blu   = fread(fileID, nDsc, conversion );

end

