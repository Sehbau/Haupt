%
% Loads the contour maps of the universe. File extension .cntMps
%
% cf ??
%
function [S] = LoadCntMaps( lfn )

fid   = fopen(lfn, 'rb');
if (fid<0), error('file %s not found', lfn); end

S       = [];

%%  ====================   Header   ====================
S.nLev  = fread( fid, 1, 'int=>single'); % # levels
S.szM   = fread( fid, 2, 'int=>single'); % map size of original reso
S.Npix  = fread( fid, 10, 'int=>single'); % nPix for each level

%S
%S.szM
%S.Npix

%%  ====================   Data   ====================
S.ARDG = cell(S.nLev,1);
S.ARIV = cell(S.nLev,1);
S.AEDG = cell(S.nLev,1);
for l = 1:S.nLev
    S.ARDG{l}	= ReadMapStc( fid, 'uint8=>single' );
    S.ARIV{l}	= ReadMapStc( fid, 'uint8=>single' );
    S.AEDG{l}	= ReadMapStc( fid, 'uint8=>single' );
end

%% -----------------------   Trailer   ---------------------------
%idf    = fread(fileID, 1,  'int=>int'); % identifier

fclose(fid);

idf = 99999;
if isempty(idf) || (idf~=99999)
    fprintf('file identifier not correct %d. Expected 99999\n', idf);
    D.ASHP
    Kt.Nshp
    pause('pausing in LoadDescImag');
end

end

