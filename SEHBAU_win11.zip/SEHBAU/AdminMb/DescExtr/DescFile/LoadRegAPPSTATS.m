%
% Reads region appearance statistics as saved under s_REGAPP
% (ReadAtValsIO.h)
%
% cf evsbReadAtReg.m
%
function [S] = LoadRegAPPSTATS( lfn )

fid   = fopen(lfn, 'rb');
if (fid<0), error('file %s not found', lfn); end

S       = [];

%%  ====================   Header   ====================
S.depth  = fread( fid, 1, 'int=>single'); % # descriptors
%S.depth
%%  ====================   Data   ====================
S.RED = cell(S.depth,1);
S.GRN = cell(S.depth,1);
S.BLU = cell(S.depth,1);

for d = 1:S.depth
    
    S.RED{d}	= ReadHistCharL( fid );
    S.GRN{d}    = ReadHistCharL( fid );
    S.BLU{d}    = ReadHistCharL( fid );
end

%% -----------------------   Trailer   ---------------------------
%idf    = fread(fileID, 1,  'int=>int'); % identifier

fclose(fid);

idf = 99999;
if isempty(idf) || (idf~=99999)
    fprintf('file identifier not correct %d. Expected 99999\n', idf);
    D.ASHP
    Kt.Nshp
    pause('pausing in LoadDescImag');
end

end

