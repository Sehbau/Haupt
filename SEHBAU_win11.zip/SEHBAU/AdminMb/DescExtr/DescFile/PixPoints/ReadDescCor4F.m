%
% Reads the four corners as saved under DescIOanf.h-w_DescCor4F
%
% cf ReadTtrgAtt.m
%
function [P] = ReadDescCor4F( fileID )

P       = [];

P.nPts  = fread( fileID, 1, 'int=>single'); % # descriptors

nPts    = P.nPts;

P.Ep1   = fread( fileID, nPts*2, 'float=>single'); 
P.Ep2   = fread( fileID, nPts*2, 'float=>single'); 
P.Ep3   = fread( fileID, nPts*2, 'float=>single'); 
P.Ep4   = fread( fileID, nPts*2, 'float=>single'); 

% reshape points:
P.Ep1   = reshape( P.Ep1, 2, nPts )';
P.Ep2   = reshape( P.Ep2, 2, nPts )';
P.Ep3   = reshape( P.Ep3, 2, nPts )';
P.Ep4   = reshape( P.Ep4, 2, nPts )';

end

