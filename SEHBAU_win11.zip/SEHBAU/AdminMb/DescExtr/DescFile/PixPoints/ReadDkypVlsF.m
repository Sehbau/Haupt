%
% Reads the values saved with keypoints. Single array. 
%
% Its the same function as ReadDescPtsF.m but only for a single array, not
% two arrays (coordinates).
%
function [P] = ReadDkypVlsF( fileID, bPt4 )

P       = [];

P.nPts  = fread( fileID, 1, 'int=>single'); % # descriptors

nVls    = P.nPts;

P.Ep1   = fread( fileID, nVls, 'float=>single'); 
P.Ep2   = fread( fileID, nVls, 'float=>single'); 
P.Btw   = fread( fileID, nVls, 'float=>single'); 

if bPt4
    P.Ep4   = fread( fileID, nVls, 'float=>single'); 
end


end

