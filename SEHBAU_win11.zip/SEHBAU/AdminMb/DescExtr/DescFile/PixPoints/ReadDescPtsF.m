%
% Reads the keypoints of a descriptor as saved under DescIOanf.h-w_DescPtsF
%
% Ep1 and Ep2 correspond to the endpoints for a contour, arc or
% straighter descriptor.
%
% Ep3 corresonds to the midpoint for a contour, arc or straighter
% descriptor.
%
function [P] = ReadDescPtsF( fileID, bPt4 )

P       = [];

P.nPts  = fread( fileID, 1, 'int=>single'); % # descriptors

nPts    = P.nPts;

P.Ep1   = fread( fileID, nPts*2, 'float=>single'); 
P.Ep2   = fread( fileID, nPts*2, 'float=>single'); 
P.Btw   = fread( fileID, nPts*2, 'float=>single'); 

if bPt4
    P.Ep4   = fread( fileID, nPts*2, 'float=>single'); 
end

% reshape points:
P.Ep1   = reshape( P.Ep1, 2, nPts )';
P.Ep2   = reshape( P.Ep2, 2, nPts )';
P.Btw   = reshape( P.Btw, 2, nPts )';
if bPt4
    P.Ep4   = reshape( P.Ep4, 2, nPts )';
end

end

