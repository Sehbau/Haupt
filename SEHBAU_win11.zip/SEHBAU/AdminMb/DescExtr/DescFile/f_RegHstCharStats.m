%
% Statistics for one channel
%
% cf evsbReadAtReg.m
%
function [St] = f_RegHstCharStats( Chn )

St.Nval = f_ArrStat( single(Chn.Nval) );
St.Nslp = f_ArrStat( single(Chn.Nslp) );

St.Dom  = f_ArrStat( single(Chn.Dom) );
St.Flt  = f_ArrStat( single(Chn.Flt) );
St.Pkn  = f_ArrStat( single(Chn.Pkn) );
St.Tig  = f_ArrStat( single(Chn.Tig) );
St.Thr  = f_ArrStat( single(Chn.Thr) );

end

