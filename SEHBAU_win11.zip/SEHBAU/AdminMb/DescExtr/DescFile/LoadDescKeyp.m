%
% Loads the descriptor keypoints as generated with option --saveKeyp.
%
function [D Kt Hed] = LoadDescKeyp( lfn, vers ) 

if nargin==1, vers = 2; end % no version number provided, then 1st one

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----------------------   Header   ---------------------------
Hed             = ReadDescFileHead( fileID, 15 );

%% -----------------------   Spaces   ---------------------------
[D.ACNT Kt.Ncnt]	= ReadDescPtsSpcF( fileID ); % skelet

[D.AFRM Kt.Nfrm]    = ReadFrmKeyPtsSpc( fileID ); % form

[D.AARC Kt.Narc]    = ReadDescPtsSpcS( fileID ); % arcs
[D.ASTR Kt.Nstr]    = ReadDescPtsSpcS( fileID ); % strs

if 0
    [D.ASHP Kt.Nshp]  = ReadShpSpc(fileID); % shape
    
    idfSpc    = fread(fileID, 1,  'int=>int');    % identifier
    if (idfSpc~=66666)
        error('Spaces not properly read (see si_DescVect');
    end
    
    [D.ATTRG Kt.Nttrg] = ReadTtrgSpc(fileID); % tetragons
    [D.ABNDG Kt.Nbndg] = ReadBndgSpc(fileID); % bundles
end

%% -----------------------   Trailer   ---------------------------
idf    = fread(fileID, 1,  'int=>int'); % identifier

fclose(fileID);

if isempty(idf) || (idf~=99999)
    fprintf('file identifier not correct %d. Expected 99999\n', idf);
    %D.ASHP
    %Kt.Nshp
    pause('pausing in LoadDescImag');
end

%% ------   A2S   -------
%Kt.Ncnt
% cast to double: manipulation is easier in Matlab with double
Kt.nLev    = double(Hed.nLev);      
Kt.szV     = double(Hed.szV);
Kt.szH     = double(Hed.szH);
Kt.ntDsc   = double(Hed.ntDsc);

