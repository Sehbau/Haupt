%
% Reads space of tetragon attributes as saved under TtrgIObin.h-w_TTGbinSpc
%
function [AUNI Nttg] = ReadTtrgBinSpc(fid)

nLev  = fread(fid, 1,    'int=>int');      % # of levels

AUNI  = cell(nLev,1);
Nttg  = zeros(nLev,1);
for l = 1:nLev
    
    [AUNI{l} nTtg1] = ReadTtrgBinUni(fid);

    S.APOSA{l}    = ReadAttPos( fid, 'float=>single' );
    S.APOSQ{l}    = ReadAttPos( fid, 'uint8=>uint8' );       

    Nttg(l)     = nTtg1;
    
end

end

