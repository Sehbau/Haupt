%
% Reads contour bins as saved under CntIObin.h-w_CntBin1D
% cf LoadCntxSpc.m
%
function [S nCnt] = ReadCntBinUni(fileID)

S       = [];

%%  ====================   Header   ====================
nCnt    = fread( fileID, 1, 'int=>single'); % # descriptors
S.nCnt  = nCnt;

%%  ====================   Data   ====================

% =====   Geometry   =====
S.Les   = fread(fileID, nCnt, 'int=>int32'); % length
S.Str   = fread(fileID, nCnt, 'int=>int32'); % straightness
S.Ori   = fread(fileID, nCnt, 'int=>int32'); % orientation angle

% =====   Appearance   =====
S.Red   = fread(fileID, nCnt, 'int=>int32'); % red
S.Grn   = fread(fileID, nCnt, 'int=>int32'); % green
S.Blu   = fread(fileID, nCnt, 'int=>int32'); % blue



end

