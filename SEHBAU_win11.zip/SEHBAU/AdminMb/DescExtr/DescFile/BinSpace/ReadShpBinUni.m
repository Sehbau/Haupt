%
% Reads shape bins as saved under ShpIObin.h-w_ShpBinUni
%
% af ReadShpAtt.m
%
function [S nShp] = ReadShpBinUni(fileID)

%%  ====================   Header   ====================
%nShp    = fread( fileID, 1, 'int=>single'); % # descriptors

%%  ====================   Data   ====================
[S.Scors szD]  = ReadMtrxDat( fileID, 'uint8=>single' );
S.Sfine        = ReadMtrxDat( fileID, 'uint8=>single' );
S.Ras          = ReadMtrxDat( fileID, 'uint8=>single' );
S.Ato          = ReadMtrxDat( fileID, 'uint8=>single' );

nShp   = szD.nObs;

end

