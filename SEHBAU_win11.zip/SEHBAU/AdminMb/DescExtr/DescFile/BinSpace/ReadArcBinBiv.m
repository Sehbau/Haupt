%
% Reads arc bins as saved under ArcIObin.h-w_ArcBin2D
%
function [S nArc] = ReadArcBinBiv(fileID)

S       = [];

%%  ====================   Header   ====================
nArc    = fread( fileID, 1, 'int=>single'); % # descriptors
S.nArc  = nArc;

%%  ====================   Data   ====================
S.LK    = fread(fileID, nArc, 'int=>int32'); 
S.LD    = fread(fileID, nArc, 'int=>int32'); 
S.LKD   = fread(fileID, nArc, 'int=>int32'); 

end

