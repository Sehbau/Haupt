%
% Reads radsig bins as saved under RsgIObin.h-w_RsgBin2D
%
function [S nRsg] = ReadRsgBinBiv(fileID)

S       = [];

%%  ====================   Header   ====================
nRsg    = fread( fileID, 1, 'int=>single'); % # descriptors
S.nRsg  = nRsg;

%%  ====================   Data   ====================

% =====   Geometry   =====
S.RO    = fread(fileID, nRsg, 'int=>int32');
S.RE    = fread(fileID, nRsg, 'int=>int32');
S.RC    = fread(fileID, nRsg, 'int=>int32');
S.REO   = fread(fileID, nRsg, 'int=>int32');

end

