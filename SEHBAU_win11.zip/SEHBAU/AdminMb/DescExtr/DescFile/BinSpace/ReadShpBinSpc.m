%
% Reads space of shape attributes as saved under ShpIObin.h-w_SHPbinSpc
%
function [AUNI Nshp] = ReadShpBinSpc(fid)

nLev  = fread(fid, 1,    'int=>int');      % # of levels

AUNI  = cell(nLev,1);
Nshp  = zeros(nLev,1);
for l = 1:nLev
    
    [AUNI{l} nShp1] = ReadShpBinUni(fid);

    S.APOSA{l}    = ReadAttPos( fid, 'float=>single' );
    S.APOSQ{l}    = ReadAttPos( fid, 'uint8=>uint8' );     

    Nshp(l)     = nShp1;
    
end

end

