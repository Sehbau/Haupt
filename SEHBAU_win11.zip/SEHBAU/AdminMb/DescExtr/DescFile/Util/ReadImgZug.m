%
% Image Zugeh�rigkeit
%
function [Z] = ReadImgZug( fid )

lenFina = fread(fid, 1, 'uint64');   
Z.fina  = fread(fid, lenFina, 'char')';

Z.base  = fread(fid, 1, 'int32');   
Z.catg  = fread(fid, 1, 'int32');   


end

