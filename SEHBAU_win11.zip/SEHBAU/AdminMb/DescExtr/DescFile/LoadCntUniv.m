%
% Loads contour universe (the curve pixels). File extension .cuv
%
function [S] = LoadCntUniv( lfn )

fid   = fopen(lfn, 'rb');
if (fid<0), error('file %s not found', lfn); end

S       = [];

%%  ====================   Header   ====================
S.nLev  = fread( fid, 1, 'uint8=>single'); % # levels
S.NCpx  = fread( fid, S.nLev*3, 'int=>single'); % nPix for each level

%S

%%  ====================   Data   ====================
S.ARDG = cell(S.nLev,1);
S.ARIV = cell(S.nLev,1);
S.AEDG = cell(S.nLev,1);

for l = 1:S.nLev
    S.ARDG{l}	= ReadCrvPixBlok( fid );
    S.ARIV{l}	= ReadCrvPixBlok( fid );
    S.AEDG{l}	= ReadCrvPixBlok( fid );
end

%% -----------------------   Trailer   ---------------------------
%idf    = fread(fileID, 1,  'int=>int'); % identifier

fclose(fid);

% not deployed:
idf = 99999;
if isempty(idf) || (idf~=99999)
    fprintf('file identifier not correct %d. Expected 99999\n', idf);
    D.ASHP
    Kt.Nshp
    pause('pausing in LoadDescImag');
end

end

