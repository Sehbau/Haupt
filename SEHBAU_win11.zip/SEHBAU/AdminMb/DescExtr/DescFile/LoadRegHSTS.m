%
% Reads region histograms as saved under s_REGHSTinit/apnd.
% (ReadAtValsIO.h)
%
% cf evsbReadAtReg.m
%
function [AHST] = LoadRegHSTS( lfn )

fid   = fopen(lfn, 'rb');
if (fid<0), error('file %s not found', lfn); end

%%  ====================   Header   ====================
depth  = fread( fid, 1, 'int=>single'); % # descriptors

%%  ====================   Data   ====================
AHST = cell(depth,1);

for d = 1:depth
    AHST{d}	= ReadJarInt( fid );
end


end

