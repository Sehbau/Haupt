%
% Reads space of SHORT keypoints as saved under DescAttIO.h-w_DescPtsSpcS
%
% cf LoadDescKeyp.m
% af ReadDescPtsSpcF.m
%
function [ALev Npts] = ReadDescPtsSpcS( fid, bFll )

if nargin==1, bFll=0; end

[nLev Npts] = ReadDescSpcHead( fid );
%nLev
%Npts

ALev  = cell(nLev,1);
for l = 1:nLev
    
    ALev{l}  = ReadDescPtsS( fid );
    
    %ALev{l}.nPts
    
    assert( Npts(l)==ALev{l}.nPts, 'point count not matching' );
    
end

end

