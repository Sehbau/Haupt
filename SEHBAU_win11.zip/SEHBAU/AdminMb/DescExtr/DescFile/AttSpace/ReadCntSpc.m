%
% Reads space of contour attributes as saved with
% - w_CntSpc (CntIO.h) with bWithPts=1
% - w_CntSpcEss (CntIO.h) with bWithPts=0
%
% bWithPts is ON when loading RRE space in LoadCntRRE.m
%
function [ACNT Ncnt] = ReadCntSpc( fid, bWithPts )

if nargin==1, bWithPts=0; end

[nLev Ncnt] = ReadDescSpcHead( fid );

ACNT  = cell(nLev,1);
for l = 1:nLev
    
    [ACNT{l} nCnt] = ReadCntAtt( fid, bWithPts );
    
    assert( Ncnt(l)==nCnt, 'contour count not matching' );
    
end

end

