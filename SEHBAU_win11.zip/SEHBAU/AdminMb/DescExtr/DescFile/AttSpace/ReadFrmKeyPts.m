%
% Reads the keypoints of the form descriptor as saved under w_RsgRoCoo() in
% RsgIO.h
%
% cf ReadFrmKeyPtsSpc.m
%
function [S nFrm] = ReadFrmKeyPts(fileID)

nFrm  = fread(fileID, 1,  'int=>int');
%nFrm

[Mx szD] = ReadMtrxDat( fileID, 'short=>single' );

% from o_LabForm()
Lbls    = {'Tole' 'Tori' 'Rito' 'Ribo' ...
           'Bole' 'Bori' 'Leto' 'Lebo' ...
           'Topp' 'Bott' 'Leff' 'Ritt' };
        
S       = u_MtrxToStcArr( Mx, Lbls );        
end

