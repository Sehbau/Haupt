%
% Reads tetragon attributes as saved under TtrgIO.h-w_TtgAtt
%
% af ReadShpAtt
%
% cf LoadDescImag.m
%
function [V nTtg] = ReadTtrgAtt( fileID )

V       = [];

%%  ====================   Header   ====================
Hed     = ReadDescAttHead( fileID );
nTtg    = Hed.nDsc;
V.nTtg  = nTtg;

%Nfld    = fread(fileID, 5, 'uint8=>int');  % number of fields
%Nfld    = double(Nfld); % should be [11 18 4 16 7]

%%  ====================   Data   ====================
% better use o_AttsLabels
aLbGeom = { 'Les'   'Elo'    'Wide'   'High'    'Rhom'  ...
            'Pllo'   'Tria'   'Irrg'   'PlHor'   'PlVrt' ...
            'Ger'    'Wth'
            };
aLbLage = { 'AxVrt'  'AxHor'   'Axial'   'Lean1'  'Lean2'   ...
            'Neig1'  'Neig2'
            };       

% Dc:  direction of converging segments, horz, vert
% Agx: intersection angle
aLbAngs = { 'DcHo' 'DcVt' 'AgxH' 'AgxV' };

V.GEOM  = ReadStcArr( fileID, 'float=>single', aLbGeom );
V.LAGE  = ReadStcArr( fileID, 'float=>single', aLbLage );
V.ANGS  = ReadStcArr( fileID, 'float=>single', aLbAngs );
V.DICV  = ReadMtrxDat( fileID, 'float=>single' );

% ---  apnc & lage
V.RGB   = ReadAttRgb(fileID, nTtg);

V.Ori   = fread(fileID, nTtg, 'float=>single'); % orientation angle
V.Pos   = ReadAttPos(fileID);

% ---  points of elo-axis
V.Ax.Ep1 = fread(fileID, nTtg*2, 'float=>single');
V.Ax.Ep2 = fread(fileID, nTtg*2, 'float=>single');
% reshape points:
V.Ax.Ep1 = reshape( V.Ax.Ep1, 2, nTtg )';
V.Ax.Ep2 = reshape( V.Ax.Ep2, 2, nTtg )';

% ---  corner points as list
V.Cop  	= ReadDescCor4F( fileID );  

% ---  boundary indices
% + 1 to change from zero- to one indexing
V.IxBon1 = fread(fileID, nTtg, 'int=>int') + 1; 

%% =====  trailer/idf   ======
idf    = fread(fileID, 1,  'int16=>int'); % identifier
assert(idf==4444);

end

