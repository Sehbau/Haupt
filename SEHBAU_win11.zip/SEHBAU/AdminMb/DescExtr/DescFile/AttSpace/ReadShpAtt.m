%
% Reads attributes of the partitioned-shape descriptor as saved under
% ShpIO.h-w_ShpAtt
%
% cf ReadShpSpc.m
%
function [V nShp] = ReadShpAtt(fileID)

V       = [];

%%  ====================   Header   ====================
Hed     = ReadDescAttHead(fileID);
nShp    = Hed.nDsc;
V.nShp  = nShp;

%%  ====================   Data   ====================
V.Are   = fread(fileID, nShp, 'float=>single');

%  =====   Str   =====
[V.STR szL] = ReadMtrxDat(fileID, 'float=>single' );
V.SFI       = ReadMtrxDat(fileID, 'float=>single' );
assert( szL.nObs==nShp );

%  =====   Gol/Ras/Ato   =====
V.RAS       = ReadMtrxDat(fileID, 'float=>single' );
V.ATO       = ReadMtrxDat(fileID, 'float=>single' );
V.GOL       = ReadStcArr(fileID, 'float=>single', ...
                {'Rib' 'Ori' 'Elo' 'AgX'});

V.RGB       = ReadAttRgb(fileID, nShp);

V.Pos       = ReadAttPos(fileID);

% + 1 to change from zero- to one indexing
V.IxBon1    = fread(fileID, nShp, 'int=>int') + 1; 

idf     = fread(fileID, 1,  'int=>int'); % in-btw identifier
assert(idf==55555);

%  =====   Basic  =====
V.BAS       = ReadMtrxDat(fileID, 'float=>single' );

V.LGIx4str = fread(fileID, nShp*4, 'int16=>single');
V.SpkKrv   = fread(fileID, nShp*5, 'float=>single');

% rotation of matrices (because C saves rowwise)
V.LGIx4str = reshape(V.LGIx4str, 4, nShp)'; 
V.SpkKrv   = reshape(V.SpkKrv,   5, nShp)'; 

%% =====  trailer/idf   ======
idf    = fread(fileID, 1,  'int=>int'); % identifier
assert(idf==55555);

end

