%
% Reads spatial stats of descriptors, as saved with w_DescStsSpa of
% DescAttIO.h
%
% cf ReadBlobStsSpa.m
%
function [H] = ReadDescStsSpa( fileID )

H = [];

H.nBand     = fread( fileID, 1, 'int=>single'); % # bands

H.Grit = fread( fileID, H.nBand*H.nBand, 'float=>single') ;
H.Bsnk = fread( fileID, H.nBand, 'float=>single'); 
H.Bwag = fread( fileID, H.nBand, 'float=>single'); 

H.Grit = reshape(H.Grit, [3 3] )' ;

end

