%
% Reads space of form coordinates
%
% cf LoadDescKeyp.m
%
function [AFRM Nfrm] = ReadFrmKeyPtsSpc( fid )

[nLev Nfrm] = ReadDescSpcHead( fid );
%Nfrm

AFRM  = cell(nLev,1);
for l = 1:nLev
    
    [AFRM{l} nRsg] = ReadFrmKeyPts( fid );

    assert( Nfrm(l)==nRsg, 'rsg count not matching' );

end

end

