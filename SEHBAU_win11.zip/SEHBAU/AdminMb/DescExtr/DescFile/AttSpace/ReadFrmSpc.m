%
% Reads space of form attributes as saved under RsgIO.h-w_RsgSpc
%
function [ARSG Nrsg] = ReadFrmSpc(fid, vers )

[nLev Nrsg] = ReadDescSpcHead( fid );

ARSG  = cell(nLev,1);
for l = 1:nLev
    
    [ARSG{l} nRsg] = ReadFrmAtt(fid, vers );

    assert( Nrsg(l)==nRsg, 'rsg count not matching' );

end

end

