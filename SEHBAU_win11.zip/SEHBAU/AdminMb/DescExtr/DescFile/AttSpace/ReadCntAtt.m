%
% Reads contour attributes as saved under CntIO.h-w_CntAtt
%
% cf ReadCntSpc.m
%
function [S nCnt] = ReadCntAtt(fileID, bWithPts )

S       = [];

%%  ====================   Header   ====================
Hed     = ReadDescAttHead(fileID);
nCnt    = Hed.nDsc;
S.nCnt  = nCnt;

%%  ====================   Data   ====================

% =====   Geometry   =====
S.Les   = fread(fileID, nCnt, 'float=>single'); % length
S.Str   = fread(fileID, nCnt, 'float=>single'); % straightness

% =====   Position   =====
S.Ori   = fread(fileID, nCnt, 'float=>single'); % orientation angle

S.Pos   = ReadAttPos(fileID);

% =====   Appearance   =====
S.RGB   = ReadAttRgb(fileID, nCnt);
S.Ctr   = fread(fileID, nCnt, 'float=>single'); % contrast

% =====   Points  =====
% used for RRE in LoadCntUnvKpt.m
if bWithPts
    bPt4    = 0;
    S.Pts   = ReadDescPtsF( fileID, bPt4 );
end

% =====   Trailer   =====
idf    = fread(fileID, 1, 'int16=>int');
assert(idf==1111);


end

