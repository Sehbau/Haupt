%
% Reads space of form coordinates
%
% cf LoadDescKeyp.m
%
function [AFRM Nfrm] = ReadFrmKypVlsSpc( fid )

[nLev Nfrm] = ReadDescSpcHead( fid );
%Nfrm

AFRM  = cell(nLev,1);
for l = 1:nLev
    
    [AFRM{l} szD] = ReadMtrxDat( fid, 'float=>single' );
    
    %szD

    assert( Nfrm(l)==szD.nObs, 'frm count not matching' );

end

end

