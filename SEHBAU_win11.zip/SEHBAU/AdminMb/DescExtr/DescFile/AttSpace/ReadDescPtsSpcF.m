%
% Reads space of FLOAT keypoints as saved under DescAttIO.h-w_DescPtsSpcF
%
function [ALev Npts] = ReadDescPtsSpcF( fid, bFll )

if nargin==1, bFll=0; end

[nLev Npts] = ReadDescSpcHead( fid );
%nLev
%Npts

ALev  = cell(nLev,1);
for l = 1:nLev
    
    ALev{l}  = ReadDescPtsF( fid, bFll );
    
    %ALev{l}.nPts
    
    assert( Npts(l)==ALev{l}.nPts, 'point count not matching' );
    
end

end

