%
% Loads as saved under A_SEGM/Refined/Util/RfinIO.h-w_BonRfn().
%
function [APix nBonAll Org S] = LoadBonRfn(lfn) 

fileID  = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

nPtc  	= fread( fileID, 1, 'int=>single');

% Loads boundaries of ALL patches
% szM is useless: reflects LAST patch only
[APix nBonAll dmy Org] = ReadBonPix( fileID );

S.Bg   	= fread( fileID, nPtc, 'int32=>int') + 1;
S.IxOrg	= fread( fileID, nPtc, 'int16=>int') + 1; % short is loaded

S.CoUL 	= ReadPxRCs( fileID );
S.nPtc  = nPtc;

idf  	= fread( fileID, 1, 'int=>single');
assert(idf==88882);




