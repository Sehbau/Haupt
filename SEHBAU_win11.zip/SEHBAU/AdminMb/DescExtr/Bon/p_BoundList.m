%
% Plots a list of boundaries.
%
% sa p_BoundPix1ToImg in SgrRGB/UtilMb/
%
function hp = p_BoundList( aBon, modus, szV, col, bJit, ctr )

if nargin<=3, col = [0.6 0.6 0.6]; end % color
if nargin<=4, bJit = 0; end % jitter
if nargin<=5, ctr = 0; end % contrast

bColor = 0;
if isstruct( col )
    bColor  = 1;
    RGB     = col;
    col     = [0.6 0.6 0.6];        % first in gray
elseif length(col)==1
    col = [0.6 0.6 0.6];
end


nBon    = length(aBon);
fprintf('Plotting %4d boundaries...', nBon);

if strcmp(modus,'plot')==1 || strcmp(modus,'Plot')==1
    
    for b = 1:nBon
    
        % plotting in gray or other color
        hb  = p_BoundPix1ToPlot( aBon{b}, szV, col, bJit, ctr);
        
        % add color
        if bColor
            red     = RGB.Red(b) / 255;
            grn     = RGB.Grn(b) / 255;
            blu     = RGB.Blu(b) / 255;
            set(hb, 'color', [red grn blu]);
        end
    end

elseif strcmp(modus,'img')==1 || strcmp(modus,'Img')==1

    error('mode img not implemented yet' );
    
else
    error('mode %s not implemented. Use plot | img', modus);
end

fprintf('done\n');

end

