%
% Wrapper function for program fbrc2arr.
%
% af RennFbrc.m
% 
% IN   fpFbrc   fabric file
%      fpOut    output filestem
%      Args     .fpPrm   parameter filename (3rd argument)
%               .opt     options (o_CmndArgs) 
%      dirExec  directory of executable
%
% OUT  Out      standard output
% 
function [Out] = RennFbrc2Ar( fpFbrc, fpOut, Args, dirExec )

if nargin==3, 
    dirExec = ''; 
end

fpExe   = [dirExec 'fbrc2arr'];

if exist( fpExe, 'file')==2,
    error('Program path not correct: %s', fpExe);
end

cmnd    = [ fpExe ' ' fpFbrc ' ' fpOut  ];%' ' Args.fpPrm, ' ' Args.opt ];

if ispc
    cmnd         = u_PathToBackSlash( cmnd );
    [status Out] = dos(cmnd);            % excecute as windows program
elseif isunix
    [status Out] = unix(cmnd);           % excecute as unix program
else
    error('OS not implemented');
end

%% ------  Status  ------
if status>0
    Out
    warning('status > 0: something went wrong');
end

%% ------  Verify Proper Termination  -----
ixEOP = strfind( Out, 'EndOfProgram');

if isempty(ixEOP)
    warning('Program fbrc2arr %s did not finish.', cmnd);
    Out    
    if isempty(Out)
        fprintf('Out empty. We try to debug '); 
        cmnd      = [cmnd ' --bDISP 2'];
        [stu Out] = system(cmnd);           % excecute program again
        Out    
    end
    fprintf('Paused');
    pause();
end


