% 
% The argument structure for descriptor extraction program dscx.
%
% Minimal version.
%
% Default is that NO options will be modified and no string will be created
% in i_DscxArgs.
%
% IN    - 
% OUT   O   struct with options and parameters
%
function O = o_DscxArgs()

%% -----   Saving  -----
% A value of 0 means that no modification in i_DescArgs is desired and that
% the program's default is taken, ie. proposals are saved.
O.saveRRE       = 0;    % RRE space (full set)
O.saveCVP       = 0;    % full CVP space
O.saveKol       = 0;    % kolumns
O.saveTxm       = 0;    % texture maps

% setting the following two has no effect!!
O.saveBin       = 0;    % bins. default ON!!
O.saveProp      = 0;    % proposals. default ON!!

% feature
O.saveCntMps    = 0;    % contour MAP universe (.cntMps)
O.saveCntUnv    = 0;    % contour curve pixels universe (.cuv)
O.saveCuvKpt    = 0;    % keypoints (.cuvKpt)
O.saveRegUnv    = 0;    % region universe (.ruv)
O.saveBonSpc    = 0;    % boundary space of pixels

% other
O.saveBonBoxRaw = 0;    % .bonBboxRaw 
O.saveBonMore   = 0;    % .bonBbox, .bonAsp

O.noSave        = 0;    % saving of description % does this work?

%% -----  Archit  -----
% A value of -1 signals that no modification is desired. Default as
% specified in dscx remains.
O.nLev          = -1;
O.depth         = -1;
O.imgSpc        = -1;   % image space (pyramid or scale space)
O.imgFlt        = -1;   % image filtering

%% -----  Other   -----
O.optS          = '';

%% -----  For Verification   -----
aFldn           = fieldnames(O);
O.nFld          = length(aFldn) + 1;    % include self

end

