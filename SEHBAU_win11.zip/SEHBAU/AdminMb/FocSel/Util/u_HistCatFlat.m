% 
% Concatenates histograms loaded from focal selections (.hsf file)
%
% Flat means no spatial selection (as opposed to spatial histogramming)
%
function [H Nbin] = u_HistCatFlat( Uni, Biv )

Huni 	= [Uni.Skl Uni.Frm Uni.Arc Uni.Str];
Hbiv 	= [Biv.Skl Biv.Frm Biv.Arc Biv.Str];
H       = [Huni Hbiv]';

Nbin.uni = length(Huni);
Nbin.biv = length(Hbiv);
Nbin.tot = Nbin.uni + Nbin.biv;

end

