%
% Creates level directorys for focii.
%    - 'Lev1', 'Lev2', ... 'Levn' 
%    - 'DM1', 'DM2', ... 'DMn'
%
% For clearing see del_DirsLevels.m
%
% cf u_CollPathsAnnt.m, dirsForLevels.m
%
function [] = u_DirsLevels( pth, nLev, bPause )

for l = 1:nLev
    f_MkDir( [pth '/Lev' num2str(l) ],  bPause);
    f_MkDir( [pth '/DM' num2str(l)  ],  bPause);
end

end

