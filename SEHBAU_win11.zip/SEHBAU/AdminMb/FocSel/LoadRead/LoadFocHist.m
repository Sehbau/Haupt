%
% Loads the descriptor histogram as saved under si_FocHist
% af LoadDescHist.m    
%
% IN    lfn     filepath
% OUT   UNF     univariate, flat
%       BIF     bivariate, flat
%       Nbin    bin count
%       Hed     file head
%
function [UNF BIF Nbin Hed] = LoadFocHist(lfn) 

fileID   = fopen(lfn, 'r');
if (fileID<0), error('file %s not found', lfn); end

%% -----  header
Hed     = ReadFocHead( fileID );

%% =====  flat univariate histograms  =====
[UNF.Skl Nuni.Skl] = ReadCntHist(fileID);

[UNF.Frm Nuni.Frm] = ReadFrmHuni(fileID);

[UNF.Arc Nuni.Arc] = ReadArcHist(fileID);

[UNF.Str Nuni.Str] = ReadStrHist(fileID); 

% perhaps RRE in the future:
%[UNF.Rdg Nunf.Rdg] = ReadCntHist(fileID);
%[UNF.Riv Nunf.Riv] = ReadCntHist(fileID);
%[UNF.Edg Nunf.Edg] = ReadCntHist(fileID);


%% =====  flat bivariate histograms   =====
[BIF.Skl HBIV.Skl Nbiv.Skl] = ReadCntHbiv(fileID);

[BIF.Frm HBIV.Frm Nbiv.Frm] = ReadRsgHbiv(fileID);

[BIF.Arc HBIV.Arc Nbiv.Arc] = ReadArcHbiv(fileID);

[BIF.Str HBIV.Str Nbiv.Str] = ReadStrHbiv(fileID);

% perhaps RRE in the future:
%[BIF.Rdg HBIV.Rdg Nbif.Rdg] = ReadCntHbiv(fileID);
%[BIF.Riv HBIV.Riv Nbif.Riv] = ReadCntHbiv(fileID);
%[BIF.Edg HBIV.Edg Nbif.Edg] = ReadCntHbiv(fileID);

%% =====  trailer/eof   ======
eof    = fread(fileID, 1,  'int=>int'); % eof identifier
assert(eof==966);

fclose(fileID);


Nbin.Uni    = Nuni;
Nbin.Biv    = Nbiv;





