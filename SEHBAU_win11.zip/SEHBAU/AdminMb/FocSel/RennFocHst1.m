%
% Wrapper routine for program fochst1 (one histogram only)
%
% Same as RennFocDsc1 in organization, but different program name.
% 
function [Sz Out] = RennFocHst1( fipaDsc, Bbox, fipsOut, Args, pthProg )

bboxStr   = sprintf('%d %d %d %d', Bbox(1), Bbox(2), Bbox(3), Bbox(4));

if nargin==4, 
    pthProg = ''; 
end

fpProg  = [pthProg 'fochst1'];

if exist( fpProg, 'file')==2,
    error('Program path not correct: %s', fpProg);
end

cmnd  	= [ fpProg ' ' fipaDsc ' ' bboxStr ' ' fipsOut ' ' Args.opt ];

[status Out] = system(cmnd);            % excecute program

%% ------  Status  ------
if status>0
    Out
    warning('Command %s returns exit code > 0 (see Out above)', cmnd);
end

%% -----   Analyse StdOut  -----
ixLev    = strfind( Out, 'nLevFoc');
Sz.nLev  = str2num( Out(ixLev+8) );
ixDsc    = strfind( Out, 'ntDsc');
Sz.ntDsc = sscanf( Out(ixDsc+5:end), '%d', 1); %str2num(Out(ixDsc+6));

%% ------  Verify Proper Termination  -----
ixEOP = strfind( Out,'EndOfProgram');
if isempty(ixEOP)
    Sz
    Out
    fprintf('Paused');
    pause();
end



