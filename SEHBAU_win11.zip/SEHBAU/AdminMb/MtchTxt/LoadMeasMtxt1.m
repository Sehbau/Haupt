%
% Loads the measurement values of program mtxt1.
%
function [M] = LoadMeasMtxt1( Pth )

% --- TxtrGrams ---
M.Txg.Grd       = LoadFltTxtEof( Pth.txtGrid );
M.Txg.Snk       = LoadFltTxtEof( Pth.txtBandSnk );
M.Txg.Wag       = LoadFltTxtEof( Pth.txtBandWag );
% single value (sum of snk and wag)
M.Txg.desBand   = LoadFltTxtEof( Pth.txtBand ); % ensemble snk+wag

% --- Freckles
%M.Frk.LayDff    = LoadFltTxtEof( Pth.frklLay );    % difference
%M.Frk.Grd       = LoadFltTxtEof( Pth.frklGrt );    % distance
%M.Frk.Snk       = LoadFltTxtEof( Pth.frklSnk );
%M.Frk.Wag       = LoadFltTxtEof( Pth.frklWag );

% --- BlobBboxes ---
M.Bbx.Dis       = LoadFltTxtEof( Pth.txtBlob ); 

% correspondence
M.NNMs      = LoadFltTxtEof( Pth.NNMsRow );
M.NNIx      = LoadIntTxtEof( Pth.NNIxRow ) + 1;

end

