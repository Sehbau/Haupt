%
% Texture matching with texturegrams and bounding boxes for a list of
% images, one-versus-many. It uses executable mtxt1, loads the individual
% measures and weights them by values given in Wgt (wgt_TxtrMtch.m).
%
% cfro CASCIDF.m, plcMtcTxt.m, lvngRunMhstKol.m
%
% IN    fpMtxt1  filepath of executable
%       fp1st    filepath of one saliency file
%       aFpSlc   register of saliency files
%       PthM     paths as generated with o_FileNameMeas.m
%       Wgt      o_WgtTxtrMtch.m
% OUT   R        struct with fields for grid, bands and blobs
%
function R = f_MtxtL( fpMtxt1, fp1st, aFpSlc, PthM, Wgt )

dfLackBox   = 10e6;

nImg        = length( aFpSlc );
Arr         = zeros( nImg, 1, 'single');

R.TxgGrid   = Arr;
R.TxgSenk   = Arr;
R.TxgWaag   = Arr;
%R.TxgBand  = Arr;
R.TxgTot    = Arr;

%R.FrkLay    = Arr;
%R.FrkGrid   = Arr;
%R.FrkSenk   = Arr;
%R.FrkWaag   = Arr;
%R.FrkTot    = Arr;

R.Bbx       = Arr;

R.EnsTxgBbx   = Arr;
R.EnsTxgFgd   = Arr;
    
for i = 1:nImg,  
   
    fpOth  = aFpSlc{i};

    cmnd   = sprintf('%s %s %s %s %1.2f', ...
        fpMtxt1, fp1st, fpOth, PthM.fidfUser, dfLackBox );
    
    if ispc, cmnd = u_PathToBackSlash( cmnd ); end
    
    f_CmndExec( cmnd );

    Mes         = LoadMeasMtxt1( PthM );

    des         = dis_Txtr( Mes, Wgt );

    % --- texturegram
    R.TxgGrid(i)    = des.txtGrd;
    R.TxgSenk(i)    = des.txtSnk;
    R.TxgWaag(i)    = des.txtWag;
    %R.TxgBand(i)   = des.txgBand;
    R.TxgTot(i)     = des.txgTot; % grid+band
    
    % --- freckles
    %R.FrkLay(i)     = des.frkLay;
    %R.FrkGrid(i)    = des.frkGrd;
    %R.FrkSenk(i)    = des.frkSnk;
    %R.FrkWaag(i)    = des.frkWag;
    %R.FrkTot(i) 	= des.frkTot;

    % --- blob bbox
    R.Bbx(i)    	= des.bbx;

    R.EnsTxgBbx(i)  = des.ensTxgBbx;
    %R.EnsTxgFgd(i)  = des.ensTxgFgd;

end
