%
% Loads the measurement values of program mtxtc.
%
function [M] = LoadMeasMtxtc( Pth, bDisp )

% --- TxtrGrams ---
M.Txg.Grd       = LoadFltTxtEof( Pth.txtGrid );
M.Txg.Bnd       = LoadFltTxtEof( Pth.txtBand );

% ----------------   Disp   ---------------
if nargin==1, return; end

if bDisp
    DispLoad( Pth.txtGrid );
    DispLoad( Pth.txtBand );
end

end

