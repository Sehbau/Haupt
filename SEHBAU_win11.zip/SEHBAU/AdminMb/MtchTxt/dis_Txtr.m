%
% Metric values for texture measurements as outputted by mtxt1.m
%
% ai f_MtxtL.m
%
% IN   M   measurements, ie. from LoadMeasMtxt.m
%      W   weights, ie. from o_WgtTxtrMtch.m
% OUT  D   struct with metric values
%
function [D] = dis_Txtr( M, W )

% ------------------   Texturegram   ---------------------

% --- combining biases txt
D.txtGrd    = M.Txg.Grd' * W.Grid;
D.txtSnk    = M.Txg.Snk' * W.Band;
D.txtWag    = M.Txg.Wag' * W.Band;

% --- totaling grams tx*g*
D.txgBand   = D.txtSnk + D.txtWag;      % partial
%D.txgBand   = sqrt(D.txtSnk) + sqrt(D.txtWag);      % partial
D.txgTot    = D.txtGrd + D.txgBand;     % full

% ------------------   Blob   ---------------------

% --------   Freckles   ---------
% --- combining biases
%D.frkLay    = M.Frk.LayDff' * W.Frk;
%D.frkGrd    = M.Frk.Grd'    * W.Frk;    
%D.frkSnk    = M.Frk.Snk'    * W.Frk;    
%D.frkWag    = M.Frk.Wag'    * W.Frk; 

% --- totaling grams
%D.frkTot    = D.frkGrd + sqrt(D.frkSnk) + sqrt(D.frkWag);

% --------   Bounding Box   -----------
if length(M.Bbx.Dis)<9
    M.Bbx.Dis
    warning('Too few bbx values');
    D.bbx = mean(M.Bbx.Dis);
else
    D.bbx       = M.Bbx.Dis' * W.Bbox ;
end


D.ensTxgBbx   = D.txgTot + D.bbx;
%D.ensTxgFgd   = D.txgTot + D.frkGrd;
    
end

