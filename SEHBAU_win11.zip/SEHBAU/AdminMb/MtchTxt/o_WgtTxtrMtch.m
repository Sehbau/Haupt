%
% Weights for texture matching. As column vectors.
%
% Corresponds to labels in o_TxtrLabels.m
%
% ui dis_Txtr.m
%
function [ W ] = o_WgtTxtrMtch( )

%            num   blk  nil vrt hor axi uni 
W.Band   = [ 0.1   0.1   1  1  1  1  1 ]' ; % column vector!
W.Grid   = [ 0.1   0.1   1  1  1  1  1 ]' ;

W.Bbox   = ones(9,1);
%W.Bbox   = [ 0.1   0.1   1  1  1  1  1  1  1 ]' ;

W.Hom    = ones(7,1);    % homogen. same weights

W.Frk    = W.Hom;
%W.Frk    = [ 1  1  0.1  0.1  0.1  0.1  0.1]';    


end

