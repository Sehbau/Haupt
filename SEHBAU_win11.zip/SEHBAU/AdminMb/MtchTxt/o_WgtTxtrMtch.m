%
% Weights for texture matching. As column vectors.
%
% Corresponds to labels in o_TxtrLabels.m
%
function [ W ] = o_WgtTxtrMtch( )

%            num   blk   ...
W.Band   = [ 0.1   0.1   1  1  1  1  1 ]' ; % column vector!
W.Grid   = [ 0.1   0.1   1  1  1  1  1 ]' ;
W.Blob   = [ 0.1   0.1   1  1  1  1  1  1  1 ]' ;

end

