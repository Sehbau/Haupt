%
% Execute a command (program) given in line 'cmnd' that already includes
% all arguments.
%
% sa u_CmndArgs, u_CmndArgsCat, ...
%
% cf PLZDSCX.m, lvngRunDscx.m, lvngRunMvec.m, ...
%
function [Out] = f_CmndExec( cmnd, bTryDebug )

if nargin==1
    bTryDebug = 0;
end

if ispc
    cmnd  = u_PathToBackSlash( cmnd ); 
end

[status Out] = system( cmnd );      

%% -------------   Verify Status   -------------
% v_CmndExec( status, Out, cmd );
if (status~=0)
    
    cmnd
    
    Out              % display out
    
    if bTryDebug
        fprintf('status not 0: is %d. We try to debug', status); 
        cmnd      = [cmnd ' --bDISP 2'];
        [stu Out] = system(cmnd);           % excecute program again
        Out    
    else
        error('Command %s did not succeed (status = %d)', cmnd, status); 
    end
end

%% -------------   Verify Output   -------------
% should be caught by status, but since I've erroneously used exit(0)
% sometimes in my code, it may happen that we missed status!=0.
%
% af RennDscx.m
%

% The EOP string does not always appear at the end of @standard output. In
% particular matching programs contain additional print statements AFTER
% 'EndOfProgram', such as measurement values.
%
ixEOP = strfind(Out, 'EndOfProgram');       

if isempty(ixEOP)
    warning('Command %s not properly terminated - lacks EOP.', cmnd);
    Out    
    if bTryDebug
        fprintf('Out empty. We try to debug '); 
        cmnd      = [cmnd ' --bDISP 2'];
        [stu Out] = system(cmnd);           % excecute program again
        Out    
    end
    fprintf('paused'); 
    pause();
end

end

