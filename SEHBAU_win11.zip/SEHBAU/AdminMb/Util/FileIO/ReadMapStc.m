% 
% Load a map of any type with a simple map size header.
%
% sa ReadMapGen
%
% cf LoadCntMaps.m
%
% USE    M = ReadMapStc( fileID, 'float=>single' );
%
function M = ReadMapStc( fid, conversion )

szM     = fread( fid, 2, 'int=>int');

nPx     = szM(1)*szM(2);

M      = fread( fid, nPx, conversion );

szM    = szM';
M      = permute( reshape( M, szM([2 1]) ), [2 1] );

end
