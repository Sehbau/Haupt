%
% Input/Output of arrays. 
%
% For text see LoadText/SaveTextXXX
%

% ---------   One-Dim   ------------
%
% ReadIxsArr.m
% ReadIxvArr.m
% LoadFltTxt.m
% LoadIntTxtEof.m
%

% ---------   Matrices   ------------
%
% ReadMtrxDat.m (fka ReadRackFlt.m)
%

% ---------   Structures   ------------
%
% ReadStcArr.m