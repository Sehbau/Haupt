%
% Saves an array of integers with its length as head.
%
% cf iclCollQuant.m
%
function [] = SaveArrIntTxt( A, sfn ) 


%% =====  Opening File  =====
fid     = fopen( sfn, 'wt');

if fid==-1, error('Could not write to %s\n', sfn); end
    

%% -----  Header  -----
fprintf( fid, '%d ', length(A) );


%% -----  Array  -----
for i = 1:length(A)
    fprintf( fid, '%d ', A(i) );
end

fclose(fid);
    
%DispSave(sfn);



