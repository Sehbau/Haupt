%
% Loads a single array of ints (written as text), ie. as saved as in
% wt_ArrWszI (ArrayIO.h)
%
% cf iclCollQuant.m
%
function [A len] = LoadArrIntTxt( lfn ) 

fid	= fopen(lfn, 'rt');
if (fid<0), error('file %s not found', lfn); end

len = fscanf( fid, '%d', 1 );

A   = fscanf( fid, '%d', len );

A   = int32( A );

fclose(fid);


