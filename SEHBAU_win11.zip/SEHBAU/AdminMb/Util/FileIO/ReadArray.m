%
% Read arrays. See ArrayIO.m
%

