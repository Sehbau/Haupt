%
% Loads a float map as saved under s_MapFltX in MapIOx.h
%
% sa LoadMapUch, SaveMapF.m
%
function [M szM] = LoadMapFlt(lfn)

if ~exist(lfn, 'file'), error('cannot fine file %s', lfn); end

fileID      = fopen(lfn, 'r');

% --------   Header   ----------
szV         = fread(fileID, 1, 'int=>int');
szH         = fread(fileID, 1, 'int=>int');

% fprintf('[%3d %3d]', szV, szH);

% --------   Data   ----------
M           = fread(fileID, szV*szH, 'float=>single');

fclose(fileID);

%% === Bring Matrix to Shape ===
M       = reshape(M, [szH szV]);    % horizontal first, then vertical!!
M       = permute(M, [2 1]);

szM     = [szV szH];

DispLoad(lfn);

end
