%
% Reads the map stats as saved under w_MapStat
%
% It is an array of five float values
%
% cf ReadTxtrMapStats.m
%
function [S] = ReadMapStats( fileID )

S.prpPres  	= fread( fileID, 1, 'float=>single');
S.min   	= fread( fileID, 1, 'float=>single');
S.max   	= fread( fileID, 1, 'float=>single');
S.men   	= fread( fileID, 1, 'float=>single');
S.sdv   	= fread( fileID, 1, 'float=>single');

end

