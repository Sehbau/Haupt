%
% Reads contour histograms as saved under CntIOhist.h-w_CntHist
%
% IN   fid   fileid
%      conv  conversion, ie. 'int=>int'
%
% cf ReadCntHist.m, etc.
%
function [S] = ReadStcOfField( fid, conv, ret )

S       = struct;

%% =====    # of fields   =====
nFld    = fread(fid, 1,  'int=>int');

%% =====   Histograms  =====
Vls     = fread(fid, nFld, conv );

if nargin==2
    S.nFld = nFld;
    S.Vls  = Vls;
    return;
end

if strcmp( ret, '' )
    
    for f = 1:nFld
        
        S.( sprintf('f%d', f ) ) = Vls(f);
    end
end

end

