%
% Loads a textfile linewise.
%
% For reading only see ReadTextLineWise.m
% For saving see SaveTextLines.m
%
function [aLines cL] = LoadTextLineWise( lfn ) 

if isempty( lfn )
    warning('no file name provided - is empty');
    aLines  = [];
    cL      = 0;
    return;
end


fileID   = fopen(lfn, 'r');     % no 'rt' necessary?

if fileID<0, error('Could not open file %s', lfn ); end


%% ---------   Read   -----------
% also available as ReadTextLineWise.m
aLines  = cell(0,1);

tline   = fgetl(fileID);        % read first line
cL      = 0;
while ischar(tline)
    
    cL = cL+1;
    aLines{cL} = tline;

    tline = fgetl(fileID);
end

fclose(fileID);

end


