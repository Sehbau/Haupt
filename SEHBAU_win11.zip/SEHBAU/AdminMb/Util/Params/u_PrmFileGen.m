% 
% Generates filepath and name for parameter file.
%
% ai {plcrec}Run.m, ie. lvngRun.m
%
% IN   typ          identifier: 'RgbOff', 'PosTolTig', ...
%      pthPrmFile   directory of parameter file
%      kind         'Mtch' or 'Desc'
%
% USE   Args.fpPrm = u_PrmFileGen( prmMtcTyp, pthPrmFile, 'Mtch', 1 );
%
function fina = u_PrmFileGen( typ, pthPrmFile, kind, bInclPth )

if isempty( typ )
    fina = '';
    fprintf('No parameter filename provided.\n');
    return;
end

fina        = ['Prm' kind '_' typ '.txt'];  % concat

%% --------   return with path included   ----------
if nargin==4
    if bInclPth
        fina = [pthPrmFile fina];            % prepend path
    end
end

end

