%
% Sums values that are given as fields.
%
function sTot = f_SumFromFields( S )

aFn     = fieldnames( S );
nFn     = length( aFn );

sTot = 0;
for i = 1:nFn
    fn      = aFn{i};
    Fld     = S.(fn);
    
    if isstruct(Fld)
        sm1     = f_SumFromFields( Fld );
        sTot    = sTot + single(sm1);
    elseif isscalar(Fld)
        sTot    = sTot + single(Fld);
    else
        error('undetermined');
    end
end

end

