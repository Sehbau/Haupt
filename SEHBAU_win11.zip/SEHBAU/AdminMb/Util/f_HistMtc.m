%
% Histogram difference. Hamming only. For demo purposes only.
%
function dh = f_HistMtc(H1, H2)

%rdg = sum( abs( H1.Rdg-H2.Rdg ) );
%riv = sum( abs( H1.Riv-H2.Riv ) );
%edg = sum( abs( H1.Edg-H2.Edg ) );

skl = sum( abs( H1.Skl-H2.Skl ) );
frm = sum( abs( H1.Frm-H2.Frm ) );
arc = sum( abs( H1.Arc-H2.Arc ) );
str = sum( abs( H1.Str-H2.Str ) );

dh   = skl + frm + arc + str;

end

