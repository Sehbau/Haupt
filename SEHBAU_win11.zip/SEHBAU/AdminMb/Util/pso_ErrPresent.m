% 
% Determines if error messages have been written to stderr.
%
% IN    Out   standard output
% OUT   []
%
function [] = pso_ErrPresent( Out, cmnd )

if nargin==1
    cmnd = 'cmnd not provided';
end

ixErrPresent  = strfind(Out, 'errors present.');

if ~isempty( ixErrPresent )
    fprintf('errors present for command %s. check log file.\n', cmnd);
    Out
end

end

