%
% Shape-to-shape matching for two lists of shapes, ie. from two images,
% carried out with executable 'mshp1' (using matching between partition
% sets).
%
% Analogous to MFOCTOFOC.m. 
%
% cf plcMtcShp.m
%
% IN    aFipaQuy    list of query shape files
%       aFipaRef    list of reference shape files
%       PrmStS      parameters. not deployed yet.
% OUT   Mes         measurement struct
%       M           matrices (struct)
%
function [Mes M] = MSHPTOSHP( aFipaQuy, aFipaRef, PrmStS, Admin, bDISP )

nQuy = length( aFipaQuy );
nRef = length( aFipaRef );

if bDISP>0
    fprintf('MSHPTOSHP: %d x %d:\n', nQuy, nRef );
end

% --- create the mes matrices
M.DM    = nan( nQuy, nRef, 'single'); 
% keeping track of max for interest
MxVec   = zeros(3,1);
MxRts   = zeros(3,1);
MxSpk   = zeros(2,1);
for qq = 1:nQuy
    
    fpQuy  = [ Admin.dirShps aFipaQuy(qq).name ];
    
    for rr = 1:nRef
        
        % --------   create command   ---------
        fpRef   = [ Admin.dirShps aFipaRef(rr).name ];
        cmnd    = [ Admin.fpProg ' ' fpQuy ' ' fpRef ];

        % --------   execute command   ---------
        [sts, Out] 	= system( cmnd );
        
        v_CmndExec( sts, Out, cmnd, 1 );

        % --------   parse output   ---------
        [Msv Rts Spk]   = pso_Mshp1( Out );
        
        MxVec   = max( [MxVec Msv], [], 2 );
        MxRts   = max( [MxRts Rts], [], 2 );
        MxSpk   = max( [MxSpk Spk], [], 2 );
        
        % -----  A2M res  -----
        dis     = prod( [Msv; MxRts; MxSpk] );  % ensemble measure
        M.DM( qq, rr ) 	= dis;

    end % rr

end % qq

%M.SMbox

%% =====  analyze shape matches [lev]  =====
% default values
Mes.simBox      = 0;
Mes.disVecMul   = 0;
Mes.disVecMen   = 0;
Mes.MxVec       = MxVec;
Mes.MxRts       = MxRts;
Mes.MxSpk       = MxSpk;
%return;

if nQuy>0 && nRef>0
    
    [disVecLev ODIS] = f_MtrFromMM( M.DM, 'ascend' );
    
    Mes.disVecMul  = disVecLev.mul;
    Mes.disVecMen  = disVecLev.men;
end

end

